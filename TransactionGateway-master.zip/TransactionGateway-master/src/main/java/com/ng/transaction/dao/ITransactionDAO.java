package com.ng.transaction.dao;

import java.util.List;

import com.ng.sb.common.dao.IDAO;
import com.ng.sb.common.dataobject.BridgeDataObject;
import com.ng.sb.common.dataobject.CustomerAccountData;
import com.ng.sb.common.dataobject.TransactionData;
import com.ng.sb.common.model.CategoryProviderMapping;
import com.ng.sb.common.model.CustomerPreferredBiller;
import com.ng.sb.common.model.CustomerWallets;
import com.ng.sb.common.model.OverlayMerchants;
import com.ng.sb.common.model.Partner;
import com.ng.sb.common.model.PayeeDetails;
import com.ng.sb.common.model.Subscriber;
import com.ng.sb.common.model.TransactionInfo;

public interface ITransactionDAO  extends IDAO
{
	public TransactionInfo saveTransactionInfo(BridgeDataObject bridgeDataObject);
	public Object[] customerDetails(TransactionData transactionData);
	public List<Object[]> serviceInfoDataList(String code,TransactionData transactionData);
	public Partner getPartnerByNickName(String nickName);
	
	public CustomerAccountData getCustomerDetails(String customerMsisdn);

	public List<PayeeDetails> getPayeeList(String customerMsisdn);
	
	public List<OverlayMerchants> getMerchantList(String customerMsisdn);
	
	public List<Partner> getPartners(String partnerType);
	
	public List<CategoryProviderMapping> getCategoryProviders();
	
	public List<CustomerWallets> getMyWallets(String customerMsisdn);
	
	public List<CustomerPreferredBiller> getBillerList(String customerMsisdn);
	
	public CategoryProviderMapping getCategoryProviderInfo(Integer providerCode);
	
	public Object[] customerDetailsByInventory(TransactionData transactionData);
	
	Subscriber updateCustomer(String msisdn) throws Exception;
}

