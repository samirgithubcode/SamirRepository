package com.ng.sb.common.dataobject;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "WalletListRequestData")
public class WalletListRequestData extends BaseObjectData {
	
	private static final long serialVersionUID = 1L;
private String userMobile;
private String wPin;
public String getUserMobile() {
	return userMobile;
}
public void setUserMobile(String userMobile) {
	this.userMobile = userMobile;
}

public String getwPin() {
	return wPin;
}
public void setwPin(String wPin) {
	this.wPin = wPin;
}


}
