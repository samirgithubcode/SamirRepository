package com.ng.sb.common.dataobject;




/**
 * @author amardeep
 *
 */
public class InventoryTrackingData  extends BaseObjectData
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long externalSerialNumber;
	private String versionNumber;
	private String sellingdate;
	private String currentStatus;
	private String hostName;
	private String acountType;
	
	public Long getExternalSerialNumber() {
		return externalSerialNumber;
	}
	public void setExternalSerialNumber(Long externalSerialNumber) {
		this.externalSerialNumber = externalSerialNumber;
	}
	public String getVersionNumber() {
		return versionNumber;
	}
	public void setVersionNumber(String versionNumber) {
		this.versionNumber = versionNumber;
	}
	public String getSellingdate() {
		return sellingdate;
	}
	public void setSellingdate(String sellingdate) {
		this.sellingdate = sellingdate;
	}
	public String getCurrentStatus() {
		return currentStatus;
	}
	public void setCurrentStatus(String currentStatus) {
		this.currentStatus = currentStatus;
	}
	public String getHostName() {
		return hostName;
	}
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}
	public String getAcountType() {
		return acountType;
	}
	public void setAcountType(String acountType) {
		this.acountType = acountType;
	}

 
}
