/**
 * 
 */
package com.ng.bridge.service.impl;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ng.bridge.util.ServiceMappingsMetaData;
import com.ng.sb.common.dataobject.BankAccount;
import com.ng.sb.common.dataobject.BridgeDataObject;
import com.ng.sb.common.dataobject.FSPServiceInstrumentData;
import com.ng.sb.common.dataobject.HostSubVersionData;
import com.ng.sb.common.dataobject.BridgeDataObject.ServiceType;
import com.ng.sb.common.dataobject.HostSubVersionData.ProviderRelation;
import com.ng.sb.common.dataobject.IConstants;
import com.ng.sb.common.dataobject.InstrumentData;
import com.ng.sb.common.dataobject.InstrumentData.Sequence;
import com.ng.sb.common.dataobject.PartnerData;
import com.ng.sb.common.dataobject.PartnerData.BankRelation;
import com.ng.sb.common.dataobject.PartnerPreferenceData;
import com.ng.sb.common.dataobject.PartnerSequence;
import com.ng.sb.common.dataobject.ProvidersData;
import com.ng.sb.common.dataobject.SelectedPartnerData;
import com.ng.sb.common.dataobject.ServiceMappingDef.BankSide;
import com.ng.sb.common.dataobject.ServiceMappingDef.Type;
import com.ng.sb.common.exception.BridgeObjectDataException;
import com.ng.sb.common.util.SystemConstant;

/**
 * @author gaurav
 *
 */
public class PartnerRetrievalService {

	private static final Logger LOGGER = LoggerFactory.getLogger(PartnerRetrievalService.class);
	
	//BANK CHECK FLAG
	private final static boolean CHECK_BANK=false; 
	private static PartnerRetrievalService instance = new PartnerRetrievalService();
	private PartnerRetrievalService(){
		
	}
	
	public static PartnerRetrievalService getInstance(){
		return instance;
	}
	
	public Map<Integer,SelectedPartnerData> getPartners(BridgeDataObject bridgeDataObject) throws BridgeObjectDataException{
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge PartnerRetrievalService -  getPartners method. ");
		SelectedPartnerData selectedPartnerData = getPartnerBuckets(bridgeDataObject);
		Map<Integer,SelectedPartnerData> partnerSeqMap = new HashMap<>();
		HostSubVersionData hostSubVersionData = bridgeDataObject.getHostSubVersionData();
		//HostSubVersionData hostSubVersionData = CacheHolder.getInstance().getHostSubVersion(bridgeDataObject.getTransactionData().getHostSubVersionCode());
		if(hostSubVersionData!=null && hostSubVersionData.getPartnerPreferences()!=null){
			
		}else{
			LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " No Partner Preference has been selected. Cannot Proceed. ");
		}
		
		int noPartnerCount=0;
		if(selectedPartnerData!=null){
			if(selectedPartnerData.getRegInstFspPartnerSequence()==null 
					|| (selectedPartnerData.getRegInstFspPartnerSequence()!=null 
						&& selectedPartnerData.getRegInstFspPartnerSequence().getPartnerMap()!=null 
						&& selectedPartnerData.getRegInstFspPartnerSequence().getPartnerMap().isEmpty())){
				noPartnerCount=noPartnerCount+1;
				LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " No Partner selected for RI FSP Service. ");
			}
		}
		if(selectedPartnerData!=null){
			if(selectedPartnerData.getFspPartnerSequence()==null 
					|| (selectedPartnerData.getFspPartnerSequence()!=null 
						&& selectedPartnerData.getFspPartnerSequence().getPartnerMap()!=null 
						&& selectedPartnerData.getFspPartnerSequence().getPartnerMap().isEmpty())){
				noPartnerCount=noPartnerCount+1;
				LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " No Partner selected for FSP Service. ");
			}
		}
		if(selectedPartnerData!=null){
			if(selectedPartnerData.getDirectPartnerMap()==null 
					|| (selectedPartnerData.getDirectPartnerMap()!=null 
						 && selectedPartnerData.getDirectPartnerMap().isEmpty())){
				noPartnerCount=noPartnerCount+1;
				LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " No Partner selected for Direct Instrument/Providers Service. ");
			}
		}
		if(noPartnerCount==3){
			LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " There is no partner for service ###  " + bridgeDataObject.getServiceType());
		}
		int count=1;
		if(hostSubVersionData.getPartnerPreferences()==null || (hostSubVersionData.getPartnerPreferences()!=null && hostSubVersionData.getPartnerPreferences().isEmpty())){
			LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " There is no partner Preference set for this HostSubVersion  " + hostSubVersionData.getName() + " Cannot Proceed further. ");
		}
		for(PartnerPreferenceData partnerPreference : hostSubVersionData.getPartnerPreferences()){
			switch (partnerPreference.getType()) {
			case SystemConstant.SEQ_RI_FSP:
				if(selectedPartnerData.getRegInstFspPartnerSequence()!=null){
					SelectedPartnerData partnerData = new SelectedPartnerData();
					partnerData.setCallingSeqType(SystemConstant.SEQ_RI_FSP);
					partnerData.setRegInstFspPartnerSequence(selectedPartnerData.getRegInstFspPartnerSequence());
					partnerSeqMap.put(count++, partnerData);
				}
				break;
			case SystemConstant.SEQ_FSP:
				if(selectedPartnerData.getFspPartnerSequence()!=null){
					SelectedPartnerData partnerData = new SelectedPartnerData();
					partnerData.setCallingSeqType(SystemConstant.SEQ_FSP);
					partnerData.setFspPartnerSequence(selectedPartnerData.getFspPartnerSequence());
					partnerSeqMap.put(count++, partnerData);
				}
				break;
			case SystemConstant.SEQ_TWO_CALLS:
				if(selectedPartnerData.getDirectPartnerMap()!=null && !selectedPartnerData.getDirectPartnerMap().isEmpty()){
					SelectedPartnerData partnerData = new SelectedPartnerData();
					partnerData.setCallingSeqType(SystemConstant.SEQ_TWO_CALLS);
					partnerData.setDirectPartnerMap(selectedPartnerData.getDirectPartnerMap());
					partnerSeqMap.put(count++, partnerData);
				}
				break;
			case SystemConstant.SEQ_COMMISSION:
				//TODO Need to create algorithm for this
				break;
			default:
				break;
			}
		}
		return partnerSeqMap;
	}
	
	private SelectedPartnerData getPartnerBuckets(BridgeDataObject bridgeDataObject) throws BridgeObjectDataException{
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge PartnerRetrievalService -  getPartnerBuckets method. ");
		if(bridgeDataObject!=null && bridgeDataObject.getServiceType()!=null){
			FSPServiceInstrumentData fspServiceInstrumentData = ServiceMappingsMetaData.getInstance().getFSPServiceAndInstruments(bridgeDataObject.getServiceType());
			if(fspServiceInstrumentData==null || (fspServiceInstrumentData.getType()== null && bridgeDataObject.getTransactionData()==null)){
				throw new BridgeObjectDataException("ServiceMappings are not properly defined");
			}
			if(fspServiceInstrumentData.getType().equals(Type.FUND_TRANSFER)){
				return getFundTransferPartners(bridgeDataObject,fspServiceInstrumentData);
			}else if(fspServiceInstrumentData.getType().equals(Type.FUND_TRANSFER_TO_BILLER)){
				return getFundTransferPartnersToBillers(bridgeDataObject,fspServiceInstrumentData);
			}else if(fspServiceInstrumentData.getType().equals(Type.OTHER_SERVICE)){
				return getOtherServicePartners(bridgeDataObject,fspServiceInstrumentData);
			}
		}
		throw new BridgeObjectDataException("bridgeDataObject is null or ServiceType/TransactionData is null.");
	}
	
	
	private String getFirst4Chars(BankAccount bankAccount){
		if(bankAccount!=null && bankAccount.getIfscCode()!=null && !bankAccount.getIfscCode().isEmpty()){
			return bankAccount.getIfscCode().substring(0,4).toUpperCase();
		}
		return null;
	}
	
	private boolean checkBankIFSCExistence(PartnerData partner,BankSide bankIncluded,BridgeDataObject bridgeDataObject,BankRelation bankRelation){
		if(!CHECK_BANK){
			return true;
		}
		BankAccount payerBankAccount = bridgeDataObject.getPayerBankAccount();
		BankAccount payeeBankAccount = bridgeDataObject.getPayeeBankAccount();
		if((bankIncluded==BankSide.PAYER_ONLY || bankIncluded==BankSide.PAYEE_ONLY || bankIncluded==BankSide.BOTH) 
				&&  (bankRelation==BankRelation.REGISTERED_INSTRUMENT_FSP_SERVICE)){
			bankIncluded=BankSide.PAYEE_ONLY;
		}else if((bankIncluded==BankSide.PAYER_ONLY || bankIncluded==BankSide.PAYEE_ONLY || bankIncluded==BankSide.BOTH) 
				&&  (bankRelation==BankRelation.REGISTERED_INSTRUMENT_FSP_PROVIDER)){
			bankIncluded=BankSide.NO_BANK;
		}
		switch (bankIncluded) {
		case NO_BANK:
			return true;
		case PAYER_ONLY:
			if(partner.getBankBranchesMap()!=null && partner.getBankBranchesMap().get(bankRelation)!=null){
				return partner.getBankBranchesMap().get(bankRelation).containsKey(getFirst4Chars(payerBankAccount));
			}else{
				return false;
			}
		case PAYEE_ONLY:
			if(partner.getBankBranchesMap()!=null && partner.getBankBranchesMap().get(bankRelation)!=null){
				return partner.getBankBranchesMap().get(bankRelation).containsKey(getFirst4Chars(payeeBankAccount));
			}else{
				return false;
			}
			
		case BOTH:
			if(partner.getBankBranchesMap()!=null && partner.getBankBranchesMap().get(bankRelation)!=null){
				return partner.getBankBranchesMap().get(bankRelation).containsKey(getFirst4Chars(payerBankAccount)) 
						&& partner.getBankBranchesMap().get(bankRelation).containsKey(getFirst4Chars(payeeBankAccount));
			}else{
				return false;
			}
			
		}
		return false;
	}
	
	enum PartnerType{
		FSP,
		FIRST,
		SECOND
	}
	private Set<PartnerData> getFundTransferPartners(BridgeDataObject bridgeDataObject,Set<PartnerData> mappedPartners,PartnerType partnerType){
		Set<PartnerData> partners = new TreeSet<PartnerData>();
		
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " Now check whether Its Partners provides the same Instrument require for this call ");
		for(PartnerData mappedpartner : mappedPartners){
			if(bridgeDataObject.getPayerWallet()!=null && bridgeDataObject.getPayerWallet().getWalletCode()!=null 
					&& bridgeDataObject.getPayerWallet().getWalletCode()!=0 
					&& bridgeDataObject.getPayeeWallet()!=null && bridgeDataObject.getPayeeWallet().getWalletCode()!=null 
					&& bridgeDataObject.getPayeeWallet().getWalletCode()!=0 && partnerType==PartnerType.FSP){ // means Wallet-Wallet Service
				if(mappedpartner.getCode().equals(bridgeDataObject.getPayerWallet().getWalletCode()) 
						&& mappedpartner.getCode().equals(bridgeDataObject.getPayeeWallet().getWalletCode())){
					addPartner(partners, mappedpartner, bridgeDataObject);
				}
			}else if(bridgeDataObject.getPayerWallet()!=null && bridgeDataObject.getPayerWallet().getWalletCode()!=null 
					&& bridgeDataObject.getPayerWallet().getWalletCode()!= 0 
					&& bridgeDataObject.getPayeeBankAccount() !=null && bridgeDataObject.getPayeeBankAccount().getAccountNumber() !=null 
					&& bridgeDataObject.getPayeeBankAccount().getIfscCode() != null && partnerType==PartnerType.FSP){ // means Wallet-Wallet Service
				if(mappedpartner.getCode().equals(bridgeDataObject.getPayerWallet().getWalletCode()))
				{
					addPartner(partners, mappedpartner, bridgeDataObject);
				}
			}else if(bridgeDataObject.getPayerWallet()!=null && bridgeDataObject.getPayerWallet().getWalletCode()!=null 
					&& bridgeDataObject.getPayerWallet().getWalletCode()!=0 &&  partnerType==PartnerType.FIRST){ // means Wallet-Other Instrument Service
				if(mappedpartner.getCode().equals(bridgeDataObject.getPayerWallet().getWalletCode())){
					addPartner(partners, mappedpartner, bridgeDataObject);
				}
			}else if(bridgeDataObject.getPayeeWallet()!=null && bridgeDataObject.getPayeeWallet().getWalletCode()!=null 
					&& bridgeDataObject.getPayeeWallet().getWalletCode()!=0 && partnerType==PartnerType.SECOND){ // means Other Instrument-Wallet Service
				if(mappedpartner.getCode().equals(bridgeDataObject.getPayeeWallet().getWalletCode())){
					addPartner(partners, mappedpartner, bridgeDataObject);
				}
			}else if((bridgeDataObject.getPayerBankAccount()!=null 
					  && bridgeDataObject.getPayerBankAccount().getAccountNumber()!=null)
					|| (bridgeDataObject.getPayerCC()!=null 
					     && bridgeDataObject.getPayerCC().getCardNumber()!=null)
					|| (bridgeDataObject.getPayerIMPS()!=null
						&& bridgeDataObject.getPayerIMPS().getMmid()!=null)
					){ // means other fund transfer service
					addPartner(partners, mappedpartner, bridgeDataObject);
			}
		}
		return partners;
	}
	
	private SelectedPartnerData getFundTransferPartners(BridgeDataObject bridgeDataObject,FSPServiceInstrumentData fspSIData) throws BridgeObjectDataException {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge PartnerRetrievalService -  getFundTransferPartners method. ");
		SelectedPartnerData partnerData =  new SelectedPartnerData();
		partnerData.setType(fspSIData.getType());
		//HostSubVersionData hostSubVersionData = CacheHolder.getInstance().getHostSubVersion(bridgeDataObject.getTransactionData().getHostSubVersionCode());
		HostSubVersionData hostSubVersionData = bridgeDataObject.getHostSubVersionData();
		if(hostSubVersionData==null){
			throw new BridgeObjectDataException("Requested HostSubVersion ##  " + bridgeDataObject.getTransactionData().getHostSubVersionCode() + " is not there in cache");
		}
		// Work on FSP FundTransfer Service
		if(fspSIData.getFspServicesData()==null){
			throw new BridgeObjectDataException(" FSPService (FundTransfer ) ServiceMappings are not properly defined");
		}
		else{
			if(hostSubVersionData.getFspServiceMap()!=null && !hostSubVersionData.getFspServiceMap().isEmpty() 
					&& hostSubVersionData.getFspServiceMap().get(fspSIData.getFspServicesData())!=null 
					&& hostSubVersionData.getFspServiceMap().get(fspSIData.getFspServicesData()).getPartners()!=null 
					&& !hostSubVersionData.getFspServiceMap().get(fspSIData.getFspServicesData()).getPartners().isEmpty()){
				LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge PartnerRetrievalService -  getFundTransferPartners method- Filling FSP Services Partners ");
				
				Set<PartnerData> partners = getFundTransferPartners(bridgeDataObject, hostSubVersionData.getFspServiceMap().get(fspSIData.getFspServicesData()).getPartners(),PartnerType.FSP);
				
				partnerData.setFspPartnerSequence(fillPartnerSequence(BankRelation.FSP_SERVICE, partners, bridgeDataObject, fspSIData));
				if(partnerData.getFspPartnerSequence()!=null 
						&& partnerData.getFspPartnerSequence().getPartnerMap()!=null 
						&& !partnerData.getFspPartnerSequence().getPartnerMap().isEmpty()){
					LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " Going to check partner List for  FSP Fund Transfer Service... Size is >> " + partnerData.getFspPartnerSequence().getPartnerMap().size());
					for(Iterator<Integer> itr=partnerData.getFspPartnerSequence().getPartnerMap().keySet().iterator();itr.hasNext();){
						Integer order = itr.next();
						LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " FSP Service Partner ##  Priority ##  " + order + " is " +  partnerData.getFspPartnerSequence().getPartnerMap().get(order).getMappingName());
					}
					
				}
				
			}
		}
		
		// Work on Registered Instrument FSP Service
		if(fspSIData.getRegInstrFspServicesData()==null){
			throw new BridgeObjectDataException("RI_FSPService (FundTransfer ) ServiceMappings are not properly defined");
		}
		else{
			if(hostSubVersionData.getFspServiceMap()!=null && !hostSubVersionData.getFspServiceMap().isEmpty() && hostSubVersionData.getFspServiceMap().get(fspSIData.getRegInstrFspServicesData())!=null && hostSubVersionData.getFspServiceMap().get(fspSIData.getRegInstrFspServicesData()).getPartners()!=null && !hostSubVersionData.getFspServiceMap().get(fspSIData.getRegInstrFspServicesData()).getPartners().isEmpty()){
				LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge PartnerRetrievalService -  getFundTransferPartners method- Filling RI FSP Services Partners ");
				
				Set<PartnerData> partners = getFundTransferPartners(bridgeDataObject, hostSubVersionData.getFspServiceMap().get(fspSIData.getRegInstrFspServicesData()).getPartners(),PartnerType.FSP);
				
				partnerData.setRegInstFspPartnerSequence(fillPartnerSequence(BankRelation.REGISTERED_INSTRUMENT_FSP_SERVICE, partners, bridgeDataObject, fspSIData));
				if(partnerData.getRegInstFspPartnerSequence()!=null 
						&& partnerData.getRegInstFspPartnerSequence().getPartnerMap()!=null 
						&& !partnerData.getRegInstFspPartnerSequence().getPartnerMap().isEmpty()){
					LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " Going to check partner List for  RI FSP Fund Transfer Service... Size is >> " + partnerData.getRegInstFspPartnerSequence().getPartnerMap().size());
					for(Iterator<Integer> itr=partnerData.getRegInstFspPartnerSequence().getPartnerMap().keySet().iterator();itr.hasNext();){
						Integer order = itr.next();
						LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " RI FSP Service Partner ##  Priority ##  " + order + " is " +  partnerData.getRegInstFspPartnerSequence().getPartnerMap().get(order).getMappingName());
					}
					
				}
			}
		}
		// Work on Independent instruments
		if(fspSIData.getInstrumentMap()==null && (fspSIData.getInstrumentMap()!=null && fspSIData.getInstrumentMap().isEmpty()) && (fspSIData.getInstrumentMap()!=null && fspSIData.getInstrumentMap().size()<2)){
			throw new BridgeObjectDataException("Direct Instruments (FundTransfer) ServiceMappings are not properly defined");
		}else{
			if(hostSubVersionData.getInstrumentMap()!=null && !hostSubVersionData.getInstrumentMap().isEmpty() && hostSubVersionData.getInstrumentMap().get(fspSIData.getInstrumentMap().get(Sequence.FIRST))!=null && hostSubVersionData.getInstrumentMap().get(fspSIData.getInstrumentMap().get(Sequence.FIRST)).getPartners()!=null && !hostSubVersionData.getInstrumentMap().get(fspSIData.getInstrumentMap().get(Sequence.FIRST)).getPartners().isEmpty()){
				LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge PartnerRetrievalService -  getFundTransferPartners method- Filling Direct Instruements Partners resp. ");
				
				Set<PartnerData> partnersSet1 = getFundTransferPartners(bridgeDataObject, hostSubVersionData.getInstrumentMap().get(fspSIData.getInstrumentMap().get(Sequence.FIRST)).getPartners(),PartnerType.FIRST);
				Set<PartnerData> partnersSet2 = getFundTransferPartners(bridgeDataObject, hostSubVersionData.getInstrumentMap().get(fspSIData.getInstrumentMap().get(Sequence.SECOND)).getPartners(),PartnerType.SECOND);
				
				partnerData.getDirectPartnerMap().put(Sequence.FIRST, fillPartnerSequence(BankRelation.DIRECT_INSTRUMENT, partnersSet1, bridgeDataObject, fspSIData));
				partnerData.getDirectPartnerMap().put(Sequence.SECOND, fillPartnerSequence(BankRelation.DIRECT_INSTRUMENT, partnersSet2, bridgeDataObject, fspSIData));	
			
				LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " Going to check Direct partner List for Fund Transfer Service... ");
				if(partnerData.getDirectPartnerMap()!=null && !partnerData.getDirectPartnerMap().isEmpty()
						&& partnerData.getDirectPartnerMap().get(Sequence.FIRST)!=null
						&& partnerData.getDirectPartnerMap().get(Sequence.FIRST).getPartnerMap()!=null
						&& !partnerData.getDirectPartnerMap().get(Sequence.FIRST).getPartnerMap().isEmpty()
						&& partnerData.getDirectPartnerMap().get(Sequence.SECOND)!=null
						&& partnerData.getDirectPartnerMap().get(Sequence.SECOND).getPartnerMap()!=null 
						&& !partnerData.getDirectPartnerMap().get(Sequence.SECOND).getPartnerMap().isEmpty()
						){
							LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " First Instrument Partner List Size is >> " + partnerData.getDirectPartnerMap().get(Sequence.FIRST).getPartnerMap().size());
							LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " Second Instrument Partner List Size is >> " + partnerData.getDirectPartnerMap().get(Sequence.SECOND).getPartnerMap().size());
							LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " Going to check partner List for  First Instrument ");
							for(Iterator<Integer> itr=partnerData.getDirectPartnerMap().get(Sequence.FIRST).getPartnerMap().keySet().iterator();itr.hasNext();){
								Integer order = itr.next();
								LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " First Instrument Partner ##  Priority ##  " + order + " is " +  partnerData.getDirectPartnerMap().get(Sequence.FIRST).getPartnerMap().get(order).getMappingName());
							}
							LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " Going to check partner List for  Second Instrument ");
							for(Iterator<Integer> itr=partnerData.getDirectPartnerMap().get(Sequence.SECOND).getPartnerMap().keySet().iterator();itr.hasNext();){
								Integer order = itr.next();
								LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " Second Instrument Partner ##  Priority ##  " + order + " is " +  partnerData.getDirectPartnerMap().get(Sequence.SECOND).getPartnerMap().get(order).getMappingName());
							}
					
				}
			
			}
			
		}
		return partnerData;
	}
	
	private PartnerSequence fillPartnerSequence(BankRelation bankRelation,Set<PartnerData> partners,BridgeDataObject bridgeDataObject,FSPServiceInstrumentData fspSIData){
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge PartnerRetrievalService -  fillPartnerSequence method ");
		PartnerSequence partnerSequence = new PartnerSequence();
		int counter=1;
		for(PartnerData partner : partners){
			
			if(bankRelation!=null){
				if(checkBankIFSCExistence(partner, fspSIData.getBankIncluded(), bridgeDataObject, bankRelation)){
					partnerSequence.getPartnerMap().put(counter++, partner);
				}
			}else{
				partnerSequence.getPartnerMap().put(counter++, partner);
			}
			
		}
		return partnerSequence;
	}
	
	private void addPartner(Set<PartnerData> partners,PartnerData mappedpartner,BridgeDataObject bridgeDataObject){
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + "  Instrument Code is ##  " + mappedpartner.getCode()+ "  : " + mappedpartner.getMappingName()); 
		partners.add(mappedpartner);
	}
	
	private Set<PartnerData> getFSPPartners(BridgeDataObject bridgeDataObject,HostSubVersionData hostSubVersionData,FSPServiceInstrumentData fspSIData,ProviderRelation providerRelation){
		Set<PartnerData> partners = new TreeSet<PartnerData>();
		ProvidersData providersData = hostSubVersionData.getProviderMap().get(providerRelation).get(new ProvidersData(bridgeDataObject.getProvider().getCode()));
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " Provider ##  " + providersData.getCode() + " is present in HostSubVersion ..");
		
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " Now check whether Its Partners provides the same Instrument require for this call ");
		for(PartnerData mappedpartner : providersData.getPartners()){
			if(bridgeDataObject.getPayerBankAccount()!=null && bridgeDataObject.getPayerBankAccount().getAccountNumber()!=null && !bridgeDataObject.getPayerBankAccount().getAccountNumber().isEmpty()){ // means Payer is Bank
				if(mappedpartner.getInstrumentMap()!=null && !mappedpartner.getInstrumentMap().isEmpty() && mappedpartner.getInstrumentMap().get(new InstrumentData(IConstants.BANK))!=null){
					addPartner(partners, mappedpartner, bridgeDataObject);
				}
			}
			else if(bridgeDataObject.getPayerCC()!=null && bridgeDataObject.getPayerCC().getCardNumber()!=null && !bridgeDataObject.getPayerCC().getCardNumber().isEmpty()){ // means Payer is CreditCard
				if(mappedpartner.getInstrumentMap()!=null && !mappedpartner.getInstrumentMap().isEmpty() && mappedpartner.getInstrumentMap().get(new InstrumentData(IConstants.CREDITCARD))!=null){
					addPartner(partners, mappedpartner, bridgeDataObject);
				}
			}
			else if(bridgeDataObject.getPayerIMPS()!=null && bridgeDataObject.getPayerIMPS().getMmid()!=null && !bridgeDataObject.getPayerIMPS().getMmid().isEmpty()){ // means Payer is IMPS
				if(mappedpartner.getInstrumentMap()!=null && !mappedpartner.getInstrumentMap().isEmpty() && mappedpartner.getInstrumentMap().get(new InstrumentData(IConstants.IMPS))!=null){
					addPartner(partners, mappedpartner, bridgeDataObject);
				}
			}
			else if(bridgeDataObject.getPayerWallet()!=null && bridgeDataObject.getPayerWallet().getWalletCode()!=null && bridgeDataObject.getPayerWallet().getWalletCode()!=0){ // means Payer is Wallet
				if(mappedpartner.getInstrumentMap()!=null && !mappedpartner.getInstrumentMap().isEmpty() && mappedpartner.getInstrumentMap().get(new InstrumentData(IConstants.WALLET))!=null && mappedpartner.getCode().intValue() == bridgeDataObject.getPayerWallet().getWalletCode().intValue()){
					addPartner(partners, mappedpartner, bridgeDataObject);
				}
			}
		}
		return partners;
	}
	
	private SelectedPartnerData getFundTransferPartnersToBillers(BridgeDataObject bridgeDataObject,FSPServiceInstrumentData fspSIData) throws BridgeObjectDataException{
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge PartnerRetrievalService -  getFundTransferPartnersToBillers method ");
		SelectedPartnerData partnerData =  new SelectedPartnerData();
		partnerData.setType(fspSIData.getType());
		//HostSubVersionData hostSubVersionData = CacheHolder.getInstance().getHostSubVersion(bridgeDataObject.getTransactionData().getHostSubVersionCode());
		HostSubVersionData hostSubVersionData = bridgeDataObject.getHostSubVersionData();
		if(hostSubVersionData==null){
			throw new BridgeObjectDataException("Requested HostSubVersion ##  " + bridgeDataObject.getTransactionData().getHostSubVersionCode() + " is not there in cache");
		}
		// Work on FSP Providers Service
		if(fspSIData.getFspProvider()==null){
			throw new BridgeObjectDataException("FSPProvider (FundTransferToBiller ) ServiceMappings are not properly defined");
		}
		else{
			if(hostSubVersionData.getProviderMap()!=null 
					&& !hostSubVersionData.getProviderMap().isEmpty() 
					&& hostSubVersionData.getProviderMap().get(fspSIData.getFspProvider())!=null 
					&& !hostSubVersionData.getProviderMap().get(fspSIData.getFspProvider()).isEmpty() 
					&& hostSubVersionData.getProviderMap().get(fspSIData.getFspProvider()).get(new ProvidersData(bridgeDataObject.getProvider().getCode()))!=null
					&& hostSubVersionData.getProviderMap().get(fspSIData.getFspProvider()).get(new ProvidersData(bridgeDataObject.getProvider().getCode())).getPartners()!=null){
				LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge PartnerRetrievalService -  getFundTransferPartnersToBillers method - Filling FSP Provider Partners ");
				ProvidersData provider = hostSubVersionData.getProviderMap().get(fspSIData.getFspProvider()).get(new ProvidersData(bridgeDataObject.getProvider().getCode()));
				bridgeDataObject.getProvider().setCategory(provider.getCategory());
				Set<PartnerData> partners = getFSPPartners(bridgeDataObject, hostSubVersionData, fspSIData,fspSIData.getFspProvider());
				if(partners!=null && !partners.isEmpty()){
					partnerData.setFspPartnerSequence(fillPartnerSequence(BankRelation.FSP_PROVIDER, partners, bridgeDataObject, fspSIData));
					
					if(partnerData.getFspPartnerSequence()!=null && partnerData.getFspPartnerSequence().getPartnerMap()!=null && !partnerData.getFspPartnerSequence().getPartnerMap().isEmpty()){
						LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " Going to check partner List for  FSP Fund TransferToBillers Service... Size is >> " + partnerData.getFspPartnerSequence().getPartnerMap().size());
						for(Iterator<Integer> itr=partnerData.getFspPartnerSequence().getPartnerMap().keySet().iterator();itr.hasNext();){
							Integer order = itr.next();
							LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " FSP TransferToBillers Service Partner ##  Priority ##  " + order + " is " +  partnerData.getFspPartnerSequence().getPartnerMap().get(order).getMappingName());
						}
						
					}
				}
			
			}
		}
		// Work on Registered Instrument FSP Service
		if(fspSIData.getRegInstrFspProvider()==null){
			throw new BridgeObjectDataException("RI_FSPProvider  (FundTransferToBiller ) ServiceMappings are not properly defined");
		}else{
			if(hostSubVersionData.getProviderMap()!=null && !hostSubVersionData.getProviderMap().isEmpty() 
					&& hostSubVersionData.getProviderMap().get(fspSIData.getRegInstrFspProvider())!=null 
					&& hostSubVersionData.getProviderMap().get(fspSIData.getRegInstrFspProvider()).get(new ProvidersData(bridgeDataObject.getProvider().getCode()))!=null 
					&& hostSubVersionData.getProviderMap().get(fspSIData.getRegInstrFspProvider()).get(new ProvidersData(bridgeDataObject.getProvider().getCode())).getPartners()!=null){
				LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge PartnerRetrievalService -  getFundTransferPartnersToBillers method - Filling RI FSP Provider Partners ");
				
				ProvidersData provider = hostSubVersionData.getProviderMap().get(fspSIData.getRegInstrFspProvider()).get(new ProvidersData(bridgeDataObject.getProvider().getCode()));
				bridgeDataObject.getProvider().setCategory(provider.getCategory());
				
				Set<PartnerData> partners = getFSPPartners(bridgeDataObject, hostSubVersionData, fspSIData,fspSIData.getRegInstrFspProvider());
				
				if(partners!=null && !partners.isEmpty()){
					partnerData.setRegInstFspPartnerSequence(fillPartnerSequence(BankRelation.REGISTERED_INSTRUMENT_FSP_PROVIDER, hostSubVersionData.getProviderMap().get(fspSIData.getRegInstrFspProvider()).get(new ProvidersData(bridgeDataObject.getProvider().getCode())).getPartners(), bridgeDataObject, fspSIData));
				
					if(partnerData.getRegInstFspPartnerSequence()!=null	&& partnerData.getRegInstFspPartnerSequence().getPartnerMap()!=null && !partnerData.getRegInstFspPartnerSequence().getPartnerMap().isEmpty()){
						LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " Going to check partner List for  RI FSP TransferToBillers Service... Size is >> " + partnerData.getRegInstFspPartnerSequence().getPartnerMap().size());
						for(Iterator<Integer> itr=partnerData.getRegInstFspPartnerSequence().getPartnerMap().keySet().iterator();itr.hasNext();){
							Integer order = itr.next();
							LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " RI FSP TransferToBillers Service Partner ##  Priority ##  " + order + " is " +  partnerData.getRegInstFspPartnerSequence().getPartnerMap().get(order).getMappingName());
						}
								
					}
			}
			}
		}
		
		// Work on Independent instrument and Provider
		if(fspSIData.getInstrumentProviderMap()==null && (fspSIData.getInstrumentProviderMap()!=null && fspSIData.getInstrumentProviderMap().isEmpty()) && (fspSIData.getInstrumentProviderMap()!=null && fspSIData.getInstrumentProviderMap().size()<2)){
			throw new BridgeObjectDataException("Independent_instrument_and_Provider  (FundTransferToBiller ) ServiceMappings are not properly defined");
		}else{
			if(hostSubVersionData.getInstrumentMap()!=null 
					&& hostSubVersionData.getInstrumentMap().get(fspSIData.getInstrumentProviderMap().get(Sequence.FIRST).getInstrumentData())!=null
					&& hostSubVersionData.getInstrumentMap().get(fspSIData.getInstrumentProviderMap().get(Sequence.FIRST).getInstrumentData()).getPartners()!=null
					&& !hostSubVersionData.getInstrumentMap().get(fspSIData.getInstrumentProviderMap().get(Sequence.FIRST).getInstrumentData()).getPartners().isEmpty()
					&& hostSubVersionData.getProviderMap().get(fspSIData.getInstrumentProviderMap().get(Sequence.SECOND).getDirectProvider())!=null
					&& hostSubVersionData.getProviderMap().get(fspSIData.getInstrumentProviderMap().get(Sequence.SECOND).getDirectProvider()).get(new ProvidersData(bridgeDataObject.getProvider().getCode()))!=null
					&& hostSubVersionData.getProviderMap().get(fspSIData.getInstrumentProviderMap().get(Sequence.SECOND).getDirectProvider()).get(new ProvidersData(bridgeDataObject.getProvider().getCode())).getPartners()!=null 
					&& !hostSubVersionData.getProviderMap().get(fspSIData.getInstrumentProviderMap().get(Sequence.SECOND).getDirectProvider()).get(new ProvidersData(bridgeDataObject.getProvider().getCode())).getPartners().isEmpty()
					){
						LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge PartnerRetrievalService -  getFundTransferPartnersToBillers method - Filling Instrument and Direct Provider Partners resp ");
						partnerData.getDirectPartnerMap().put(Sequence.FIRST, fillPartnerSequence(BankRelation.DIRECT_INSTRUMENT,hostSubVersionData.getInstrumentMap().get(fspSIData.getInstrumentProviderMap().get(Sequence.FIRST).getInstrumentData()).getPartners(),bridgeDataObject, fspSIData));
						partnerData.getDirectPartnerMap().put(Sequence.SECOND, fillPartnerSequence(null, hostSubVersionData.getProviderMap().get(fspSIData.getInstrumentProviderMap().get(Sequence.SECOND).getDirectProvider()).get(new ProvidersData(bridgeDataObject.getProvider().getCode())).getPartners(), bridgeDataObject, fspSIData));
						
						
						ProvidersData provider = hostSubVersionData.getProviderMap().get(fspSIData.getInstrumentProviderMap().get(Sequence.SECOND).getDirectProvider()).get(new ProvidersData(bridgeDataObject.getProvider().getCode()));
						bridgeDataObject.getProvider().setCategory(provider.getCategory());
						
						LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " Going to check Direct partner List for Fund TransferToBillers Service... ");
						if(partnerData.getDirectPartnerMap()!=null && !partnerData.getDirectPartnerMap().isEmpty()
								&& partnerData.getDirectPartnerMap().get(Sequence.FIRST)!=null
								&& partnerData.getDirectPartnerMap().get(Sequence.FIRST).getPartnerMap()!=null
								&& !partnerData.getDirectPartnerMap().get(Sequence.FIRST).getPartnerMap().isEmpty()
								&& partnerData.getDirectPartnerMap().get(Sequence.SECOND)!=null
								&& partnerData.getDirectPartnerMap().get(Sequence.SECOND).getPartnerMap()!=null 
								&& !partnerData.getDirectPartnerMap().get(Sequence.SECOND).getPartnerMap().isEmpty()
								){
									LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " First Instrument Partner List Size is >> " + partnerData.getDirectPartnerMap().get(Sequence.FIRST).getPartnerMap().size());
									LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " Second Provider Partner List Size is >> " + partnerData.getDirectPartnerMap().get(Sequence.SECOND).getPartnerMap().size());
									LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " Going to check partner List for  First Instrument ");
									for(Iterator<Integer> itr=partnerData.getDirectPartnerMap().get(Sequence.FIRST).getPartnerMap().keySet().iterator();itr.hasNext();){
										Integer order = itr.next();
										LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " First Instrument Partner ##  Priority ##  " + order + " is " +  partnerData.getDirectPartnerMap().get(Sequence.FIRST).getPartnerMap().get(order).getMappingName());
									}
									LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " Going to check partner List for  Second Provider ");
									for(Iterator<Integer> itr=partnerData.getDirectPartnerMap().get(Sequence.SECOND).getPartnerMap().keySet().iterator();itr.hasNext();){
										Integer order = itr.next();
										LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " Second Provider Partner ##  Priority ##  " + order + " is " +  partnerData.getDirectPartnerMap().get(Sequence.SECOND).getPartnerMap().get(order).getMappingName());
									}
							
						}
			
			}
		}
		return partnerData;
	}
	
	private SelectedPartnerData getOtherServicePartners(BridgeDataObject bridgeDataObject,FSPServiceInstrumentData fspSIData) throws BridgeObjectDataException{
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge PartnerRetrievalService -  getOtherServicePartners method ");
		SelectedPartnerData partnerData =  new SelectedPartnerData();
		partnerData.setType(fspSIData.getType());
		//HostSubVersionData hostSubVersionData = CacheHolder.getInstance().getHostSubVersion(bridgeDataObject.getTransactionData().getHostSubVersionCode());
		HostSubVersionData hostSubVersionData = bridgeDataObject.getHostSubVersionData();
		if(fspSIData.getFspServicesData()==null){
			throw new BridgeObjectDataException("OtherService ServiceMappings are not properly defined");
		}else{
			if(hostSubVersionData.getFspServiceMap()!=null && hostSubVersionData.getFspServiceMap().get(fspSIData.getFspServicesData())!=null && hostSubVersionData.getFspServiceMap().get(fspSIData.getFspServicesData()).getPartners()!=null){
				if(fspSIData.getBankRelation()==BankRelation.REGISTERED_INSTRUMENT_FSP_SERVICE){
					LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge PartnerRetrievalService -  getOtherServicePartners method in case of REGISTERED_INSTRUMENT_FSP_SERVICE");
					partnerData.setRegInstFspPartnerSequence(fillPartnerSequence(fspSIData.getBankRelation(), hostSubVersionData.getFspServiceMap().get(fspSIData.getFspServicesData()).getPartners(), bridgeDataObject, fspSIData));
				}else{
					LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge PartnerRetrievalService -  getOtherServicePartners method else case");
					
					// If Wallet Check balance service,We need to pick the same wallet company
					
					/*if(bridgeDataObject.getServiceType().name().equals(ServiceType.SETTINGS_MY_PAYEE_ADD.name()) || bridgeDataObject.getServiceType().name().equals(ServiceType.SETTINGS_MY_PAYEE_EDIT.name()) || bridgeDataObject.getServiceType().name().equals(ServiceType.SETTINGS_MY_PAYEE_DELETE.name()) ||
							bridgeDataObject.getServiceType().name().equals(ServiceType.SETTINGS_MY_MERCHANT_ADD.name()) || bridgeDataObject.getServiceType().name().equals(ServiceType.SETTINGS_MY_MERCHANT_EDIT.name()) || bridgeDataObject.getServiceType().name().equals(ServiceType.SETTINGS_MY_MERCHANT_DELETE.name()))
					{
						partnerData.setFspPartnerSequence(fillPartnerSequence(fspSIData.getBankRelation(), hostSubVersionData.getFspServiceMap().get(fspSIData.getFspServicesData()).getPartners(), bridgeDataObject, fspSIData));
						
					}else if(bridgeDataObject.getPayerWallet()!=null && bridgeDataObject.getPayerWallet().getWalletCode()!=null 
							&& bridgeDataObject.getPayerWallet().getWalletCode()!=0 && bridgeDataObject.getPayeeWallet()==null)
					{
						Set<PartnerData> partners = getOtherServicePartners(bridgeDataObject, hostSubVersionData.getFspServiceMap().get(fspSIData.getFspServicesData()).getPartners(),PartnerType.FSP);
						
						partnerData.setFspPartnerSequence(fillPartnerSequence(fspSIData.getBankRelation(), partners, bridgeDataObject, fspSIData));
					}
					*/
					
					
					
					if(!bridgeDataObject.getServiceType().name().equals(ServiceType.SETTINGS_MY_PAYEE_ADD.name()) && !bridgeDataObject.getServiceType().name().equals(ServiceType.SETTINGS_MY_PAYEE_EDIT.name()) &&!bridgeDataObject.getServiceType().name().equals(ServiceType.SETTINGS_MY_PAYEE_DELETE.name()) && !bridgeDataObject.getServiceType().name().equals(ServiceType.SETTINGS_MY_MERCHANT_ADD.name()) && !bridgeDataObject.getServiceType().name().equals(ServiceType.SETTINGS_MY_MERCHANT_EDIT.name()) &&!bridgeDataObject.getServiceType().name().equals(ServiceType.SETTINGS_MY_MERCHANT_DELETE.name()) && 
							bridgeDataObject.getPayerWallet()!=null && bridgeDataObject.getPayerWallet().getWalletCode()!=null && bridgeDataObject.getPayerWallet().getWalletCode()!=0 && bridgeDataObject.getPayeeWallet()==null){
						Set<PartnerData> partners = getOtherServicePartners(bridgeDataObject, hostSubVersionData.getFspServiceMap().get(fspSIData.getFspServicesData()).getPartners(),PartnerType.FSP);
						
						partnerData.setFspPartnerSequence(fillPartnerSequence(fspSIData.getBankRelation(), partners, bridgeDataObject, fspSIData));
					}
					else{
						partnerData.setFspPartnerSequence(fillPartnerSequence(fspSIData.getBankRelation(), hostSubVersionData.getFspServiceMap().get(fspSIData.getFspServicesData()).getPartners(), bridgeDataObject, fspSIData));
					}
					
					
				}
				
			}
		}
		return partnerData;
	}
	
	
	
	private Set<PartnerData> getOtherServicePartners(BridgeDataObject bridgeDataObject,Set<PartnerData> mappedPartners,PartnerType partnerType){
		Set<PartnerData> partners = new TreeSet<PartnerData>();
		
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " Now check whether Its Partners provides the same Instrument require for this call ");
		for(PartnerData mappedpartner : mappedPartners){
			if(bridgeDataObject.getPayerWallet()!=null && bridgeDataObject.getPayerWallet().getWalletCode()!=null 
					&& bridgeDataObject.getPayerWallet().getWalletCode()!=0 
					&& partnerType==PartnerType.FSP
					){ // means Wallet check balance Service
				if(mappedpartner.getCode().equals(bridgeDataObject.getPayerWallet().getWalletCode())){
					addPartner(partners, mappedpartner, bridgeDataObject);
				}
			}
		}
		return partners;
	}
}
