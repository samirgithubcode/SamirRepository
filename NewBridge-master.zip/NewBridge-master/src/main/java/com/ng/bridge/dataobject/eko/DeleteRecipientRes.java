package com.ng.bridge.dataobject.eko;

public class DeleteRecipientRes {
	private String responseTypeid;

    private String message;

    private String responseStatusId;

    private String status;


    public String getResponseTypeid() {
		return responseTypeid;
	}


	public void setResponseTypeid(String responseTypeid) {
		this.responseTypeid = responseTypeid;
	}

	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}

	

	public String getResponseStatusId() {
		return responseStatusId;
	}


	public void setResponseStatusId(String responseStatusId) {
		this.responseStatusId = responseStatusId;
	}
	public String getMessage() {
		return message;
	}


	public void setMessage(String message) {
		this.message = message;
	}


	

	@Override
    public String toString()
    {
        return "ClassPojo [response_type_id = "+responseTypeid+", message = "+message+", response_status_id = "+responseStatusId+", status = "+status+"]";
    }
}
