package com.ng.pnb.invoker.util;

import java.util.List;

public class MiniStatementResponse {

	Header header = null;;
	
	List<TransactionData> data = null;;

	public Header getHeader() {
		return header;
	}

	public void setHeader(Header header) {
		this.header = header;
	}

	public List<TransactionData> getData() {
		return data;
	}

	public void setData(List<TransactionData> data) {
		this.data = data;
	}

}

class TransactionData{

	private String transactionDate;
	
	private Balance amount;
	
	private String transactionRemarks;
	
	private Balance availableBalance;

	public String getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}

	public Balance getAmount() {
		return amount;
	}

	public void setAmount(Balance amount) {
		this.amount = amount;
	}

	public String getTransactionRemarks() {
		return transactionRemarks;
	}

	public void setTransactionRemarks(String transactionRemarks) {
		this.transactionRemarks = transactionRemarks;
	}

	
	public Balance getAvailableBalance() {
		return availableBalance;
	}

	public void setAvailableBalance(Balance availableBalance) {
		this.availableBalance = availableBalance;
	}

	@Override
	public String toString() {
		return "TransactionData [transactionDate=" + transactionDate
				+ ", amount=" + amount + ", transactionRemarks="
				+ transactionRemarks + ", availableBalance=" + availableBalance
				+ "]";
	}

	public String getOverlayFormat(){
		return transactionDate + " " + amount.getAmount() + " " + availableBalance.getAmount() + " " +  (amount.getAmount()>0 ? "CR" : "DR");
	}

}

