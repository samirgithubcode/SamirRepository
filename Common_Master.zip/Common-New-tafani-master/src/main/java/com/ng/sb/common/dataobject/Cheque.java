package com.ng.sb.common.dataobject;

/**
 * @author gaurav
 *
 */
public class Cheque extends BaseObjectData {
	private static final long serialVersionUID = 1L;
	private Integer chequeNumber;

	public Integer getChequeNumber() {
		return chequeNumber;
	}

	public void setChequeNumber(Integer chequeNumber) {
		this.chequeNumber = chequeNumber;
	}

}
