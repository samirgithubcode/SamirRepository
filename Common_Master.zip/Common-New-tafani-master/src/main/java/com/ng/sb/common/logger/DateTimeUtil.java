/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.logger;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/***
 * 
 * @author himanshu
 *
 */
public class DateTimeUtil 
{
	private DateTimeUtil()
	{
	  throw new UnsupportedOperationException("Initialization Not Allowed");
	}
	
	public static Date modifyDate(Date date){
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.DATE ,date.getDate());
		cal.set(Calendar.HOUR_OF_DAY,23);
		cal.set(Calendar.MINUTE,59);
		cal.set(Calendar.SECOND,59);

		return cal.getTime();
	}
    //**************Function For Getting Current Date - Time Format**********************
    public static String getDateTime()
    {
        String dateNow;
        Calendar currentDate = Calendar.getInstance();
        SimpleDateFormat formatter = new SimpleDateFormat(" E yyyy-MMM-dd 'at' HH:mm:ss a ");
        dateNow = formatter.format(currentDate.getTime());
        return dateNow;
    }
    
    public static String getDateTime(String format,Date date)
    {
        String dateNow;
        SimpleDateFormat formatter = new SimpleDateFormat(format);
        dateNow = formatter.format(date.getTime());
        return dateNow;
    }
    
    public static String getDateAndTime(String format,Date date)
    {
        String dateNow;
        SimpleDateFormat formatter = new SimpleDateFormat(format);
        dateNow = formatter.format(date.getTime());
        return dateNow;
    }
    
   
    //****************End*******************************************************************
   
   
}
