package com.ng.sc.dao;

import java.sql.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.ng.sb.common.dataobject.TransactionRequestData;
import com.ng.sb.common.model.Address;
import com.ng.sb.common.model.CardWallets;
import com.ng.sb.common.model.CountryCode;
import com.ng.sb.common.model.CustomerQueryLog;
import com.ng.sb.common.model.CustomerSubQuery;
import com.ng.sb.common.model.InventoryMgmt;
import com.ng.sb.common.model.Otp;
import com.ng.sb.common.model.PinCodeInfo;
import com.ng.sb.common.model.Products;
import com.ng.sb.common.model.SignUpOtp;
import com.ng.sb.common.model.Subscriber;
import com.ng.sb.common.model.UserWalletDetails;

public interface IScUserMgmntDAO extends ISelfCareDAO {

	public Integer saveNewPassword(Subscriber subscriber) throws Exception;
	public Map<String,Integer> validateSecurityQuestionCheck(String emailorusername,Date date,String answer) throws Exception;

	public List<CountryCode> getCountryCodeMap();

	public Subscriber getSubscriberById(Integer subscriberid) throws Exception;
	
	public Subscriber saveSubscriberDetails(Subscriber subscriber) throws Exception;
	
	public Subscriber validateMobile(String mobileNo) throws Exception;

	public Otp getOtp(Otp otp) throws Exception;

	public Subscriber getSubscriber(String mobileNo) throws Exception;

	public Otp addOtp(Otp otp) throws Exception;

	public Otp getOtpByVal(Subscriber subscriber, Integer confirmationOtp) throws Exception;
	public int getSubscriberExist(String mobile, String dob, String emailId,String userPassword) throws Exception;

	public List<Address> fetchAddress(String pinCode) throws Exception;
	public UserWalletDetails getwallet(Integer subscriberid) throws Exception;
	public List<Products> getproducttype() throws Exception;
	public List<CustomerSubQuery> getsubquerylist(String productType) throws Exception;
	public List<Integer> getProductTypeId(String loginId) throws Exception;
	public List<CardWallets> getWalletList(List<Integer> productTypeId) throws Exception;
	public CustomerQueryLog saveMyQuery(CustomerQueryLog customerQueryLog) throws Exception;
	public int checkfiled(String value, String tablename, String field)throws Exception;
	public SignUpOtp validateOtp(String mobileNo, String dateOfBirth, Integer otp) throws Exception;
	public List<CustomerQueryLog> getqueryLog(String mobileNo, TransactionRequestData transactionRequestData);
	public Products getProductId(String instrument);
	public CustomerSubQuery getListOfLinks(Integer subqueryid);
	public List<UserWalletDetails> getAllwalletList(Integer subscriberid);
	public List<InventoryMgmt> getProductDetail(String mobile);
	public boolean getProductDetailById(String productId, String comment);
	public void updateWalletStatus(Integer id);
	public List<Products> getproductList();
	public List<CustomerQueryLog> queryStatus(HttpSession session, String subscriberMobNo);
	public void saveNewPinCode(PinCodeInfo addressinfo);
	public boolean checkWallet(String userMobile, String walletId);
	
	public boolean updateWalletDetails(UserWalletDetails userWallet);
}

