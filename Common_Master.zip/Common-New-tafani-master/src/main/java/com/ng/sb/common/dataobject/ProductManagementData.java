package com.ng.sb.common.dataobject;

import java.util.Date;

import org.springframework.web.multipart.MultipartFile;


public class ProductManagementData  extends BaseObjectData{

	private static final long serialVersionUID = 1L;
	private String status;
	private String briefDesc;
	private String fullDesc;
	private String buyPrice;
	private String sellPrice;
	private String image1Url;
	private String image2Url;
	private Date addDatetime;
	private Date editDatetime;
	private String addbyId;
	private String editbyId;
	private String images2;
	private int pCatgid;
	private int unitsId;
	private String productCatName;
	private String productSubType;
	private transient MultipartFile uploadProductImage;
	private String productImage;
	private Integer productCode;
	private String[] ussdCheck;
	private String description;
	private String typeId;
	private Integer commission;
		public Integer getCommission() {
		return commission;
	}
	public void setCommission(Integer commission) {
		this.commission = commission;
	}
		public String getTypeId() {
		return typeId;
	}
	public void setTypeId(String typeId) {
		this.typeId = typeId;
	}
		public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
		public String[] getUssdCheck() {
		return ussdCheck;
	}
	public void setUssdCheck(String[] ussdCheck) {
		this.ussdCheck = ussdCheck;
	}
	
	public String getProductSubType() {
		return productSubType;
	}
	public void setProductSubType(String productSubType) {
		this.productSubType = productSubType;
	}
	public MultipartFile getUploadProductImage() {
		return uploadProductImage;
	}
	public void setUploadProductImage(MultipartFile uploadProductImage) {
		this.uploadProductImage = uploadProductImage;
	}
	public String getProductImage() {
		return productImage;
	}
	public void setProductImage(String productImage) {
		this.productImage = productImage;
	}
	public Integer getProductCode() {
		return productCode;
	}
	public void setProductCode(Integer productCode) {
		this.productCode = productCode;
	}
	public String getProductCatName() {
		return productCatName;
	}
	public void setProductCatName(String productCatName) {
		this.productCatName = productCatName;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getBriefDesc() {
		return briefDesc;
	}
	public void setBriefDesc(String briefDesc) {
		this.briefDesc = briefDesc;
	}
	public String getFullDesc() {
		return fullDesc;
	}
	public void setFullDesc(String fullDesc) {
		this.fullDesc = fullDesc;
	}
	public String getBuyPrice() {
		return buyPrice;
	}
	public void setBuyPrice(String buyPrice) {
		this.buyPrice = buyPrice;
	}
	public String getSellPrice() {
		return sellPrice;
	}
	public void setSellPrice(String sellPrice) {
		this.sellPrice = sellPrice;
	}
	public String getImage1Url() {
		return image1Url;
	}
	public void setImage1Url(String image1Url) {
		this.image1Url = image1Url;
	}
	public String getImage2Url() {
		return image2Url;
	}
	public void setImage2Url(String image2Url) {
		this.image2Url = image2Url;
	}
	public Date getAddDatetime() {
		return addDatetime;
	}
	public void setAddDatetime(Date addDatetime) {
		this.addDatetime = addDatetime;
	}
	public Date getEditDatetime() {
		return editDatetime;
	}
	public void setEditDatetime(Date editDatetime) {
		this.editDatetime = editDatetime;
	}
	public String getAddbyId() {
		return addbyId;
	}
	public void setAddbyId(String addbyId) {
		this.addbyId = addbyId;
	}
	public String getEditbyId() {
		return editbyId;
	}
	public void setEditbyId(String editbyId) {
		this.editbyId = editbyId;
	}
	public String getImages2() {
		return images2;
	}
	public void setImages2(String images2) {
		this.images2 = images2;
	}
	public int getpCatgid() {
		return pCatgid;
	}
	public void setpCatgid(int pCatgid) {
		this.pCatgid = pCatgid;
	}
	public int getUnitsId() {
		return unitsId;
	}
	public void setUnitsId(int unitsId) {
		this.unitsId = unitsId;
	}
	
	
	
	
}
