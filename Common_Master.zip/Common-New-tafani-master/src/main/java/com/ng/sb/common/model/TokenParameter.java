



package com.ng.sb.common.model;


import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;



	@Entity
	@Table(name = "tokenparameter")
	@XmlRootElement
	@NamedQueries({
		@NamedQuery(name="TokenParameter.findAll", query="SELECT t FROM TokenParameter t where status=1"),
		
	})
	public class TokenParameter implements Serializable {
		private static final long serialVersionUID = 1L;
		
		
		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		@Basic(optional = false)
		@Column(name = "id")
		private Integer id;
		
		@Column(name = "name")
		private String name;
		
	   
		@Column(name = "status")
	    private Integer status;
		@Column(name = "product_type")
	    private String productType;
		@Column(name = "added_on")
	    private Date addedOn;
		@Column(name = "added_by")
	    private String addedBy;
		@Column(name = "modified_by")
	    private String modifiedBy;
		@Column(name = "modified_on")
	    private Date modifiedOn;
		
		
		
		
		
		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getProductType() {
			return productType;
		}

		public void setProductType(String productType) {
			this.productType = productType;
		}

		public Date getAddedOn() {
			return addedOn;
		}

		public void setAddedOn(Date addedOn) {
			this.addedOn = addedOn;
		}

		public String getAddedBy() {
			return addedBy;
		}

		public void setAddedBy(String addedBy) {
			this.addedBy = addedBy;
		}

		public String getModifiedBy() {
			return modifiedBy;
		}

		public void setModifiedBy(String modifiedBy) {
			this.modifiedBy = modifiedBy;
		}

		public Date getModifiedOn() {
			return modifiedOn;
		}

		public void setModifiedOn(Date modifiedOn) {
			this.modifiedOn = modifiedOn;
		}

		public TokenParameter() {
	    	//empty
	    }

	    public TokenParameter(Integer id) {
	        this.id = id;
	    }
		

	    

		public Integer getStatus() {
			return status;
		}

		public void setStatus(Integer status) {
			this.status = status;
		}
		
	    

	    
		
		public Integer getId() {
			return id;
		}

		public void setId(Integer id) {
			this.id = id;
		}


		@Override
		public boolean equals(Object object) {
			boolean checkStatus = true;
			if (object != null) {
				if (!(object instanceof TokenParameter)) {
					checkStatus = false;
				}
				TokenParameter other = (TokenParameter) object;
				if ((this.id == null && other.id != null)
						|| (this.id != null && !this.id.equals(other.id))) {
					checkStatus = false;
				}
			}
			return checkStatus;
		}

		@Override
		public int hashCode() {
			int hash = 0;
			hash += (id != null ? id.hashCode() : 0);
			return hash;
		}

		

	}
	
	
	
	
	