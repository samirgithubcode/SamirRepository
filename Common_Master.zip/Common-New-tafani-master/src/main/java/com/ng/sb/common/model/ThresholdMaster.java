package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the Threshold_Master database table.
 * 
 */
@Entity
@Table(name="risk_fraud_threshold")
@NamedQueries({
	@NamedQuery(name = "Threshold_Master.findByWalletType", query = "SELECT t FROM ThresholdMaster t WHERE t.walletType = :walletType"),
})
public class ThresholdMaster implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false)
	private Integer id;
	@Basic(optional = false)
	@Column(name="category_name")
	private String categoryName;
	@Column(name="category_description")
	private String categoryDescription;
	@Basic(optional = false)
	@Column(name="per_trx_min_amount")
	private Integer perTrxMinAmount;
	@Basic(optional = false)
	@Column(name="per_trx_max_amount")
	private Integer perTrxMaxAmount;
	@Basic(optional = false)
	@Column(name="daily_debit_limit")
	private Integer dailyDebitLimit;
	@Basic(optional = false)
	@Column(name="daily_credit_limit")
	private Integer dailyCreditLimit;
	@Basic(optional = false)
	@Column(name="daily_trx_count")
	private Integer dailyTrxCount;
	@Basic(optional = false)
	@Column(name="monthly_debit_limit")
	private Integer monthlyDebitLimit;
	@Basic(optional = false)
	@Column(name="monthly_credit_limit")
	private Integer monthlyCreditLimit;
	@Basic(optional = false)
	@Column(name="monthly_trx_count")
	private Integer monthlyTrxCount;
	@Basic(optional = false)
	@Column(name="yearly_debit_limit")
	private Integer yearlyDebitLimit;
	@Basic(optional = false)
	@Column(name="yearly_credit_limit")
	private Integer yearlyCreditLimit;
	@Basic(optional = false)
	@Column(name="yearly_trx_count")
	private Integer yearlyTrxCount;
	@Basic(optional = false)
    @Column(name = "status", nullable = false)
    private boolean status;
	
	@Column(name = "start_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date startDate;
	@Column(name = "end_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date endDate;
    
    @Column(name = "last_udpated_on")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUdpatedOn;
    
	@Column(name="modified_by")
	private Integer modifiedBy;
	@JoinColumn(name = "wallet_type_id", referencedColumnName = "id")
	@OneToOne(optional = false)
	private WalletType walletType;	
	public ThresholdMaster() {
		super();
	}
	
    public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Date getLastUdpatedOn() {
		return lastUdpatedOn;
	}

	public void setLastUdpatedOn(Date lastUdpatedOn) {
		this.lastUdpatedOn = lastUdpatedOn;
	}

	public Integer getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public String getCategoryDescription() {
		return categoryDescription;
	}

	public void setCategoryDescription(String categoryDescription) {
		this.categoryDescription = categoryDescription;
	}

	public Integer getPerTrxMinAmount() {
		return perTrxMinAmount;
	}

	public void setPerTrxMinAmount(Integer perTrxMinAmount) {
		this.perTrxMinAmount = perTrxMinAmount;
	}

	public Integer getPerTrxMaxAmount() {
		return perTrxMaxAmount;
	}

	public void setPerTrxMaxAmount(Integer perTrxMaxAmount) {
		this.perTrxMaxAmount = perTrxMaxAmount;
	}

	public Integer getDailyDebitLimit() {
		return dailyDebitLimit;
	}

	public void setDailyDebitLimit(Integer dailyDebitLimit) {
		this.dailyDebitLimit = dailyDebitLimit;
	}

	public Integer getDailyCreditLimit() {
		return dailyCreditLimit;
	}

	public void setDailyCreditLimit(Integer dailyCreditLimit) {
		this.dailyCreditLimit = dailyCreditLimit;
	}

	public Integer getDailyTrxCount() {
		return dailyTrxCount;
	}

	public void setDailyTrxCount(Integer dailyTrxCount) {
		this.dailyTrxCount = dailyTrxCount;
	}

	public Integer getMonthlyDebitLimit() {
		return monthlyDebitLimit;
	}

	public void setMonthlyDebitLimit(Integer monthlyDebitLimit) {
		this.monthlyDebitLimit = monthlyDebitLimit;
	}

	public Integer getMonthlyCreditLimit() {
		return monthlyCreditLimit;
	}

	public void setMonthlyCreditLimit(Integer monthlyCreditLimit) {
		this.monthlyCreditLimit = monthlyCreditLimit;
	}

	public Integer getMonthlyTrxCount() {
		return monthlyTrxCount;
	}

	public void setMonthlyTrxCount(Integer monthlyTrxCount) {
		this.monthlyTrxCount = monthlyTrxCount;
	}

	public Integer getYearlyDebitLimit() {
		return yearlyDebitLimit;
	}

	public void setYearlyDebitLimit(Integer yearlyDebitLimit) {
		this.yearlyDebitLimit = yearlyDebitLimit;
	}

	public Integer getYearlyCreditLimit() {
		return yearlyCreditLimit;
	}

	public void setYearlyCreditLimit(Integer yearlyCreditLimit) {
		this.yearlyCreditLimit = yearlyCreditLimit;
	}

	public Integer getYearlyTrxCount() {
		return yearlyTrxCount;
	}

	public void setYearlyTrxCount(Integer yearlyTrxCount) {
		this.yearlyTrxCount = yearlyTrxCount;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public WalletType getWalletType() {
		return walletType;
	}

	public void setWalletType(WalletType walletType) {
		this.walletType = walletType;
	}

	
	

	@Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
    	boolean check =false;
    	if(object!=null){
        if (!(object instanceof ThresholdMaster)) {
        	check= false;
        }
        ThresholdMaster other = (ThresholdMaster) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
    	}
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.Threshold_Master[ id=" + id + " ]";
    }
	
}
