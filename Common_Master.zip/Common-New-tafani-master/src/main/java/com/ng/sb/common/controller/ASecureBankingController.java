/**
 * 
 */
package com.ng.sb.common.controller;

import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
/**
 * @author gaurav
 *
 */
public class ASecureBankingController  {
	@Autowired
	@Qualifier("messageSource")
	private MessageSource systemMessageSource;
	


	public String getProperty(String key)
	 {
	        return systemMessageSource.getMessage(key, null, Locale.getDefault());
	 }
	
	
	
	
	
}
