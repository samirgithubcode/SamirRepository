package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="outletInfo")
@NamedQueries
({
	@NamedQuery(name="OutletInfo.findByContactNumber", query ="SELECT m FROM OutletInfo m where m.contactNumber = :contactNumber"),
	@NamedQuery(name="OutletInfo.findAll", query ="SELECT m FROM OutletInfo m"),
	@NamedQuery(name="OutletInfo.findById", query ="SELECT m FROM OutletInfo m where m.id = :id "),
	@NamedQuery(name="OutletInfo.findByMerchantId", query ="SELECT m FROM OutletInfo m where m.merchantName = :merchantName "),
})
public class OutletInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "id", unique=true, nullable=false)
	private Integer id;

	@ManyToOne
	@JoinColumn(name="merchantName")
	private MerchantInfo merchantName;
	
	@Column(name = "dbaName")
	private String dbaName;
	@Column(name="pinCode", nullable=false)
	private Integer pinCode;
	@Column(name="address")
	private String address;
	@Column(name = "city", nullable=false, length=30)
	private String city;
	@Column(name = "locality")
	private String locality;
	@Column(name = "district")
	private String district;	
	@Column(name = "region")
	private String region;
	@Column(name="state", nullable=false)
	private String state;

	@Column(name = "country", nullable=false)
	private String country;


	@Column(name="contactNumber")
	private String contactNumber;
	@ManyToOne
    @JoinColumn(name="addressId", referencedColumnName="id")
	private Address addressId;
	
	
	@Column(name = "longitude")
	private String longitude;

	@Column(name = "latitude")
	private String latitude;
	
	@Column(name = "accountNumber")
	private String accountNumber;

	@Column(name = "ifsc")
	private String ifsc;
	
	@Column(name = "email")
	private String email;

	@Column(name="status", nullable=false)
	private String status;

	@Column(name="addedOn")
	private  Date addedOn;
	
	@Column(name="updatedOn")
	private  Date updatedOn;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public MerchantInfo getMerchantName() {
		return merchantName;
	}

	public void setMerchantName(MerchantInfo merchantName) {
		this.merchantName = merchantName;
	}

	public String getDbaName() {
		return dbaName;
	}

	public void setDbaName(String dbaName) {
		this.dbaName = dbaName;
	}

	public Integer getPinCode() {
		return pinCode;
	}

	public void setPinCode(Integer pinCode) {
		this.pinCode = pinCode;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getLocality() {
		return locality;
	}

	public void setLocality(String locality) {
		this.locality = locality;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public Address getAddressId() {
		return addressId;
	}

	public void setAddressId(Address addressId) {
		this.addressId = addressId;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getIfsc() {
		return ifsc;
	}

	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getAddedOn() {
		return addedOn;
	}

	public void setAddedOn(Date addedOn) {
		this.addedOn = addedOn;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}
	
}
