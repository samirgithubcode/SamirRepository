package com.ng.sb.common.dataobject;

import java.util.List;

public class RestResponseEntityUtils<T> {

	
	private Integer statusCode;
	private String statusMessage;
	private T responseEntity;
	private List<T> responseEntities;
	
	public RestResponseEntityUtils(Integer statusCode,String statusMessage,T responseEntity) {
		this.statusCode=statusCode;
		this.statusMessage=statusMessage;
		this.responseEntity=responseEntity;
	}
	
	public RestResponseEntityUtils(Integer statusCode,String statusMessage,List<T> responseEntities) {
		this.statusCode=statusCode;
		this.statusMessage=statusMessage;
		this.responseEntities=responseEntities;
	}

	public Integer getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(Integer statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatusMessage() {
		return statusMessage;
	}

	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}

	public T getResponseEntity() {
		return responseEntity;
	}

	public void setResponseEntity(T responseEntity) {
		this.responseEntity = responseEntity;
	}

	public List<T> getResponseEntities() {
		return responseEntities;
	}

	public void setResponseEntities(List<T> responseEntities) {
		this.responseEntities = responseEntities;
	}
	
}
