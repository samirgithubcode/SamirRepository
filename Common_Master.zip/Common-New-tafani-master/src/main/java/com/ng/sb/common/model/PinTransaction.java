/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "PinTransaction")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "PinTransaction.findAll", query = "SELECT p FROM PinTransaction p"),
    @NamedQuery(name = "PinTransaction.findById", query = "SELECT p FROM PinTransaction p WHERE p.id = :id"),
    @NamedQuery(name = "PinTransaction.findByTransactionId", query = "SELECT p FROM PinTransaction p WHERE p.transactionId = :transactionId"),
    @NamedQuery(name = "PinTransaction.findByTrnxDate", query = "SELECT p FROM PinTransaction p WHERE p.trnxDate = :trnxDate"),
    @NamedQuery(name = "PinTransaction.findByTotalAmount", query = "SELECT p FROM PinTransaction p WHERE p.totalAmount = :totalAmount"),
    @NamedQuery(name = "PinTransaction.findByCommission", query = "SELECT p FROM PinTransaction p WHERE p.grossCommission = :commission"),
    @NamedQuery(name = "PinTransaction.findByNetCommission", query = "SELECT p FROM PinTransaction p WHERE p.netCommission = :netCommission"),
    @NamedQuery(name = "PinTransaction.findByNetAmount", query = "SELECT p FROM PinTransaction p WHERE p.netAmount = :netAmount"),
    @NamedQuery(name = "PinTransaction.findByPortalTrnxStatus", query = "SELECT p FROM PinTransaction p WHERE p.portalTrnxStatus = :portalTrnxStatus"),
    @NamedQuery(name = "PinTransaction.findByStatus", query = "SELECT p FROM PinTransaction p WHERE p.status = :status"),
    @NamedQuery(name = "PinTransaction.findByDescription", query = "SELECT p FROM PinTransaction p WHERE p.description = :description"),
    @NamedQuery(name = "PinTransaction.findRecords", query = "SELECT p FROM PinTransaction p WHERE p.trnxDate >= :fromDate AND p.trnxDate <= :toDate"),
    @NamedQuery(name = "PinTransaction.findRecordsWithPortalId", query = "SELECT p FROM PinTransaction p WHERE p.trnxDate >= :fromDate AND p.trnxDate <= :toDate AND p.portalId= :portalId "),
    //@NamedQuery(name = "PinTransaction.findRecordsWithPortalId", query = "SELECT p FROM PinTransaction p where DATE_FORMAT(p.trnxDate,'%d-%m-%Y') >= :fromDate AND DATE_FORMAT(p.trnxDate,'%d-%m-%Y') <= :toDate ORDER BY DATE_FORMAT(p.trnxDate,'%d-%m-%Y') ASC"),
})


public class PinTransaction implements Serializable {
	 private static final long serialVersionUID = 1L;
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Basic(optional = false)
	    @Column(name = "id")
	    private Integer id;
	    @Basic(optional = false)
	    @Column(name = "transactionId")
	    private String transactionId;
	    @Basic(optional = false)
	    @Column(name = "trnxDate")
	    @Temporal(TemporalType.TIMESTAMP)
	    private Date trnxDate;
	    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
	    @Column(name = "totalAmount")
	    private Float totalAmount;
	    @Column(name = "grossCommission")
	    private Float grossCommission;
	    @Column(name = "netCommission")
	    private Float netCommission;
	    @Column(name = "netAmount")
	    private Float netAmount;
	    @Column(name = "portalTrnxStatus")
	    private String portalTrnxStatus;
	    @Column(name = "status")
	    private String status;
	    @Column(name = "description")
	    private String description;
	    @Column(name = "noOfPins")
	    private Integer noOfPins;
	    @Basic(optional = false)
	    @Column(name = "ip")
	    private String ip;
	    @Column(name = "commissionType")
	    private String commissionType;
	    @Column(name = "commissionValueType")
	    private String commissionValueType;
	    @Column(name = "tax")
	    private Float tax;
	    @Column(name = "surcharge")
	    private Float surcharge;
	    @JoinColumn(name = "portalId", referencedColumnName = "id")
	    @ManyToOne(optional = false)
	    private PortalRegistration portalId;
	    @OneToMany(cascade = CascadeType.ALL, mappedBy = "pinTrnxId")
	    private Collection<PinTrnxInfo> pinTrnxInfoCollection;

	    public PinTransaction() {
	    	//empty
	    }

	    public PinTransaction(Integer id) {
	        this.id = id;
	    }

	    public PinTransaction(Integer id, String transactionId, Date trnxDate, String ip) {
	        this.id = id;
	        this.transactionId = transactionId;
	        this.trnxDate = trnxDate;
	        this.ip = ip;
	    }

	    public Integer getId() {
	        return id;
	    }

	    public void setId(Integer id) {
	        this.id = id;
	    }

	    public String getTransactionId() {
	        return transactionId;
	    }

	    public void setTransactionId(String transactionId) {
	        this.transactionId = transactionId;
	    }

	    public Date getTrnxDate() {
	        return trnxDate;
	    }

	    public void setTrnxDate(Date trnxDate) {
	        this.trnxDate = trnxDate;
	    }

	    public Float getTotalAmount() {
	        return totalAmount;
	    }

	    public void setTotalAmount(Float totalAmount) {
	        this.totalAmount = totalAmount;
	    }


	    public Float getNetCommission() {
			return netCommission;
		}

		public void setNetCommission(Float netCommission) {
			this.netCommission = netCommission;
		}


	    public Float getGrossCommission() {
	        return grossCommission;
	    }

	    public void setGrossCommission(Float grossCommission) {
	        this.grossCommission = grossCommission;
	    }
		public Float getNetAmount() {
	        return netAmount;
	    }

	    public void setNetAmount(Float netAmount) {
	        this.netAmount = netAmount;
	    }

	    public String getPortalTrnxStatus() {
	        return portalTrnxStatus;
	    }

	    public void setPortalTrnxStatus(String portalTrnxStatus) {
	        this.portalTrnxStatus = portalTrnxStatus;
	    }

	    public String getStatus() {
	        return status;
	    }

	    public void setStatus(String status) {
	        this.status = status;
	    }

	    public String getDescription() {
	        return description;
	    }

	    public void setDescription(String description) {
	        this.description = description;
	    }

	    public Integer getNoOfPins() {
	        return noOfPins;
	    }

	    public void setNoOfPins(Integer noOfPins) {
	        this.noOfPins = noOfPins;
	    }

	    public String getIp() {
	        return ip;
	    }

	    public void setIp(String ip) {
	        this.ip = ip;
	    }

	    public String getCommissionType() {
	        return commissionType;
	    }

	    public void setCommissionType(String commissionType) {
	        this.commissionType = commissionType;
	    }

	    public String getCommissionValueType() {
	        return commissionValueType;
	    }

	    public void setCommissionValueType(String commissionValueType) {
	        this.commissionValueType = commissionValueType;
	    }

	    public Float getTax() {
	        return tax;
	    }

	    public void setTax(Float tax) {
	        this.tax = tax;
	    }

	    public Float getSurcharge() {
	        return surcharge;
	    }

	    public void setSurcharge(Float surcharge) {
	        this.surcharge = surcharge;
	    }

	    public PortalRegistration getPortalId() {
	        return portalId;
	    }

	    public void setPortalId(PortalRegistration portalId) {
	        this.portalId = portalId;
	    }

	    @XmlTransient
	    public Collection<PinTrnxInfo> getPinTrnxInfoCollection() {
	        return pinTrnxInfoCollection;
	    }

	    public void setPinTrnxInfoCollection(Collection<PinTrnxInfo> pinTrnxInfoCollection) {
	        this.pinTrnxInfoCollection = pinTrnxInfoCollection;
	    }

	    @Override
	    public int hashCode() {
	        int hash = 0;
	        hash += (id != null ? id.hashCode() : 0);
	        return hash;
	    }

	    @Override
	    public boolean equals(Object object) {
	    	boolean check=true;
	    	if(object!=null){
	        if (!(object instanceof PinTransaction)) {
	        	check= false;
	        }
	        PinTransaction other = (PinTransaction) object;
	        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
	        	check= false;
	        }
	    	}
	        return check;
	    }

	    @Override
	    public String toString() {
	        return "com.ng.sb.common.model.PinTransaction[ id=" + id + " ]";
	    }
    
}
