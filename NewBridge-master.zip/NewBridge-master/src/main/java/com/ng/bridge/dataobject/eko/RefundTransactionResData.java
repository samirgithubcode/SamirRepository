package com.ng.bridge.dataobject.eko;

public class RefundTransactionResData {

	private String amount;

    private String fee;

    private String timestamp;

    private String refundedAmount;

    private String state;

    private String tid;

    private String serviceTax;

    private String clientRefId;

    private String refundTid;
    private InvalidParam invalidParam;

    public String getAmount ()
    {
        return amount;
    }

    public void setAmount (String amount)
    {
        this.amount = amount;
    }

    public String getFee ()
    {
        return fee;
    }

    public void setFee (String fee)
    {
        this.fee = fee;
    }

    public String getTimestamp ()
    {
        return timestamp;
    }

    public void setTimestamp (String timestamp)
    {
        this.timestamp = timestamp;
    }

    public String getRefundedAmount ()
    {
        return refundedAmount;
    }

    public void setRefundedAmount (String refundedAmount)
    {
        this.refundedAmount = refundedAmount;
    }

    public String getState ()
    {
        return state;
    }

    public void setState (String state)
    {
        this.state = state;
    }

    public String getTid ()
    {
        return tid;
    }

    public void setTid (String tid)
    {
        this.tid = tid;
    }

    public String getServiceTax ()
    {
        return serviceTax;
    }

    public void setServiceTax (String serviceTax)
    {
        this.serviceTax = serviceTax;
    }

    public String getClientRefId ()
    {
        return clientRefId;
    }

    public void setClientRefId (String clientRefId)
    {
        this.clientRefId = clientRefId;
    }

    public String getRefundTid ()
    {
        return refundTid;
    }

    public void setRefundTid (String refundTid)
    {
        this.refundTid = refundTid;
    }

    
    
    public InvalidParam getInvalidParams() {
		return invalidParam;
	}

	public void setInvalidParams(InvalidParam invalidParam) {
		this.invalidParam = invalidParam;
	}

	@Override
    public String toString()
    {
        return "ClassPojo [amount = "+amount+", fee = "+fee+", timestamp = "+timestamp+", refunded_amount = "+refundedAmount+", state = "+state+", tid = "+tid+", service_tax = "+serviceTax+", client_ref_id = "+clientRefId+", refund_tid = "+refundTid+"]";
    }
}
