/**
 * 
 */
package com.ng.transaction.dao;

/**
 * @author gaurav
 *
 */
public interface IMyBillerDAO extends ISettingsDAO {

}
