/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "serviceConfig")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "ServiceConfig.findAll", query = "SELECT s FROM ServiceConfig s"),
    @NamedQuery(name = "ServiceConfig.findById", query = "SELECT s FROM ServiceConfig s WHERE s.id = :id"),
    @NamedQuery(name = "ServiceConfig.findByServiceName", query = "SELECT s FROM ServiceConfig s WHERE s.serviceName = :serviceName"),
    @NamedQuery(name = "ServiceConfig.findByServiceDescription", query = "SELECT s FROM ServiceConfig s WHERE s.serviceDescription = :serviceDescription"),
    @NamedQuery(name = "ServiceConfig.findByServiceDefination", query = "SELECT s FROM ServiceConfig s WHERE s.serviceDefination = :serviceDefination"),
    @NamedQuery(name = "ServiceConfig.findByCreateDate", query = "SELECT s FROM ServiceConfig s WHERE s.createDate = :createDate"),
    @NamedQuery(name = "ServiceConfig.findByRequieredInputParams", query = "SELECT s FROM ServiceConfig s WHERE s.requieredInputParams = :requieredInputParams"),
    @NamedQuery(name = "ServiceConfig.findByStatus", query = "SELECT s FROM ServiceConfig s WHERE s.status = :status"),
    @NamedQuery(name = "ServiceConfig.findByStkCode", query = "SELECT s FROM ServiceConfig s WHERE s.stkCode = :stkCode"),
    @NamedQuery(name = "ServiceConfig.findByValidationReq", query = "SELECT s FROM ServiceConfig s WHERE s.validationReq = :validationReq"),
    @NamedQuery(name = "ServiceConfig.findByLevel", query = "SELECT s FROM ServiceConfig s WHERE s.level = :level"),
    @NamedQuery(name = "ServiceConfig.findByServiceType", query = "SELECT s FROM ServiceConfig s WHERE s.serviceType = :serviceType"),
    @NamedQuery(name = "ServiceConfig.findByPidNullAndMvId", query = "SELECT s FROM ServiceConfig s where s.pId is NULL and s.mvId =:mvId and s.level =1"),
    @NamedQuery(name = "ServiceConfig.findAllbypid", query = "SELECT s FROM ServiceConfig s where s.pId =:pId AND s.status=1"),
    @NamedQuery(name = "ServiceConfig.findByPidNullAndMvIdNull", query = "SELECT s FROM ServiceConfig s where s.pId is NULL and s.mvId is NULL and s.level=1"),
    @NamedQuery(name = "ServiceConfig.findByPidNull", query = "SELECT s FROM ServiceConfig s where s.pId is NULL and s.level=1 AND s.status=1"),
    @NamedQuery(name = "ServiceConfig.findAllbyMVID", query = "SELECT s FROM ServiceConfig s where s.mvId is NULL"),
    @NamedQuery(name = "ServiceConfig.findAllbyMultipleMvId", query = "SELECT s FROM ServiceConfig s where s.id IN :ids"),
    @NamedQuery(name = "ServiceConfig.updateServiceConfigWithMvId", query = "update ServiceConfig s set s.mvId = :mvId where s.id IN :ids"),
    @NamedQuery(name = "ServiceConfig.updateServiceConfigWithMvIdNull", query = "update ServiceConfig s set s.mvId = NULL where s.id NOT IN :ids"),
    
})
public class ServiceConfig implements Serializable {
	private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    
    @Basic(optional = false)
    @Column(name = "service_name")
    private String serviceName;
    
    @Column(name = "service_description", length = 250)
    private String serviceDescription;
    
    @Column(name = "service_defination", length = 50)
    private String serviceDefination;
    
    @Basic(optional = false)
    @Column(name = "create_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createDate;
    
    @Column(name = "requiered_input_params")
    private Integer requieredInputParams;
    
    @Column(name = "status")
    private Boolean status;
    
    @Basic(optional = false)
    @Column(name = "stk_code")
    private String stkCode;
    
    @Basic(optional = false)
    @Column(name = "validation_req")
    private Boolean validationReq;
    
    @Column(name = "level")
    private Integer level;
    
    @Column(name = "service_type", length = 7)
    private String serviceType;
    
    @OneToMany(mappedBy = "serviceConfigId")
    private Collection<HostSVServiceConfigMapping> hostSVServiceConfigMappingCollection;
    
    @OneToMany(mappedBy = "pId")
    private Collection<ServiceConfig> serviceConfigCollection;
    
    @JoinColumn(name = "p_id", referencedColumnName = "id")
    @ManyToOne
    private ServiceConfig pId;
    
    @JoinColumn(name = "mvId", referencedColumnName = "id")
    @ManyToOne
    private MasterVersion mvId;
    
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "serviceId")
    private Collection<ServiceParamMapping> serviceParamMappingCollection;
    
    @Column(name = "menuId")
    private String menuId; 
    
    @ManyToOne
	@JoinColumn(name="category_id", referencedColumnName="id")
    private Categories categoryId;
    
    public ServiceConfig() {
    	//default constructor
    }

    public ServiceConfig(Integer id, String serviceName, Date createDate, String stkCode, boolean validationReq) {
        this.id = id;
        this.serviceName = serviceName;
        this.createDate = createDate;
        this.stkCode = stkCode;
        this.validationReq = validationReq;
    }

    public ServiceConfig getpId() {
		return pId;
	}

	public void setpId(ServiceConfig pId) {
		this.pId = pId;
	}

	public String getMenuId() {
		return menuId;
	}

	public void setMenuId(String menuId) {
		this.menuId = menuId;
	}

	public ServiceConfig(Integer id) {
        this.id = id;
    }


	public Categories getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(Categories categoryId) {
		this.categoryId = categoryId;
	}

	public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public String getServiceDescription() {
        return serviceDescription;
    }

    public void setServiceDescription(String serviceDescription) {
        this.serviceDescription = serviceDescription;
    }

    public String getServiceDefination() {
        return serviceDefination;
    }

    public void setServiceDefination(String serviceDefination) {
        this.serviceDefination = serviceDefination;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Integer getRequieredInputParams() {
        return requieredInputParams;
    }

    public void setRequieredInputParams(Integer requieredInputParams) {
        this.requieredInputParams = requieredInputParams;
    }

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }

    public String getStkCode() {
        return stkCode;
    }

    public void setStkCode(String stkCode) {
        this.stkCode = stkCode;
    }

    public Boolean getValidationReq() {
        return validationReq;
    }

    public void setValidationReq(Boolean validationReq) {
        this.validationReq = validationReq;
    }

    public Integer getLevel() {
        return level;
    }

    public void setLevel(Integer level) {
        this.level = level;
    }

    public String getServiceType() {
        return serviceType;
    }

    public void setServiceType(String serviceType) {
        this.serviceType = serviceType;
    }

    @XmlTransient
    public Collection<HostSVServiceConfigMapping> getHostSVServiceConfigMappingCollection() {
        return hostSVServiceConfigMappingCollection;
    }

    public void setHostSVServiceConfigMappingCollection(Collection<HostSVServiceConfigMapping> hostSVServiceConfigMappingCollection) {
        this.hostSVServiceConfigMappingCollection = hostSVServiceConfigMappingCollection;
    }

    @XmlTransient
    public Collection<ServiceConfig> getServiceConfigCollection() {
        return serviceConfigCollection;
    }

    public void setServiceConfigCollection(Collection<ServiceConfig> serviceConfigCollection) {
        this.serviceConfigCollection = serviceConfigCollection;
    }

    public MasterVersion getMvId() {
        return mvId;
    }

    public void setMvId(MasterVersion mvId) {
        this.mvId = mvId;
    }

    @XmlTransient
    public Collection<ServiceParamMapping> getServiceParamMappingCollection() {
        return serviceParamMappingCollection;
    }

    public void setServiceParamMappingCollection(Collection<ServiceParamMapping> serviceParamMappingCollection) {
        this.serviceParamMappingCollection = serviceParamMappingCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof ServiceConfig)) {
            return false;
        }
        ServiceConfig other = (ServiceConfig) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.ServiceConfig[ id=" + id + " ]\n";
    }
}