package com.ng.sb.common.dataobject;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

public class CustomerCareData extends BaseObjectData implements ValidationBean {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer days;
	private String backButton;
	private String realPath;
	private String filePath;
	private String ticketNumber;
	private transient List<MultipartFile> uploadFilePath;
	private String secretQuestion;
	private Integer weightage;
	private Map<Integer, String> usertypemap;
	private String usertype;
	private String description;
	private String descriptions;
	private String names;
	private String historyComment;
	private Integer querytypeId;
	private String productTypeId;
	private String checkBox;
	private String address;
	private String executiveName;
	private String executiveLevel;
	private String subquery;
	private String subquerys;
	private String userStatus;
	private String userProductName;
	private String mobileNumberService;
	private Float walletBalance;
	private String walletName;
	private List<CustomerCareData> walletList;
	private List<CustomerCareData> txnList;
	private String[] checkedLinks;
	private String pendingAt;
	private String startDate;
	private String endDate;
	private String searchTxt;
	private String txnStatus;
	private Integer kycVerificationId;
	private String commissionRadioValue;
	private String transactionRadioValue;
	private String priority;
	private String customerpriority;
	private String refundComment;
	private String customerpriorityId;
	private String modifiedBy;
	private Integer querylogId;
	private Integer walletid;
	private Integer subscriberid;
	private String trxAmount;
	private String trxType;
	private String trxDate;
	private Long refTxnId;
	private Integer refundRefTxnId;
	private Integer wallettypeid;
	private List<CustomerCareData> calllist;
	private String createdon;
	private String ticketno;
	private String date;
	private Map<Integer, String> productmap;
	private String customerid;
	private String mobilenumber;
	private String email;
	private String status;
	private Integer subqueryid;
	private String subquerydescription;
	private String subquerycomment;
	private List<CustomerCareData> subscriberlist;
	private List<CustomerCareData> subquerylist;
	private List<CustomerCareData> carelist;
	private List<CustomerCareData> querytypelist;
	private Map<String, String> querytypemap;
	private Map<Integer, String> queryIdmap;
	private Map<Integer, String> querypriority;
	private List<CustomerCareData> allquerylist;
	private List<CustomerCareData> reslist;
	private transient Object issuerName;
	private String issueDate;
	private String expiryDate;
	private String voucherValue;
	private List<CustomerCareData> vPinHistoryList;
	private String platformName;
	private String platformType;
	private String transactionDate;
	private float transactionAmount;
	private String statu;
	private String statusDesc;
	private Integer accountTypeId;
	private String serialNumber;
	private List<CustomerCareData> queryloghis;
	private Integer critical;
	private Integer high;
	private Integer medium;
	private Integer low;
	private Integer allpriority;
	private WalletListResponseData[] txnResponse;
	private String userMobile;
	private List<CustomerCareData> voucherlist;
	private Integer querytime;
	private Integer resolutionTime;
	private String customername;
	private Integer accountId;
	private String finaldescription;
	private String todate;
	private String fromdate;
	private String product;
	private String toUser;
	private String externalNum;
	private String bankName;
	private String action;
	private String productType;
	private String msisdnComment;
	private String otp;
	private String transactionStatus;
	private String newMobilenumber;
	private String resionCode;
	private String remarks;
	private String newExternalNum;
	private String oldExternalNum;
	private String kycId;

	
	
	
	
	
	public String getKycId() {
		return kycId;
	}

	public void setKycId(String kycId) {
		this.kycId = kycId;
	}

	public String getOldExternalNum() {
		return oldExternalNum;
	}

	public void setOldExternalNum(String oldExternalNum) {
		this.oldExternalNum = oldExternalNum;
	}

	public String getNewExternalNum() {
		return newExternalNum;
	}

	public void setNewExternalNum(String newExternalNum) {
		this.newExternalNum = newExternalNum;
	}

	public String getResionCode() {
		return resionCode;
	}

	public void setResionCode(String resionCode) {
		this.resionCode = resionCode;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public List<MultipartFile> getUploadFilePath() {
		return uploadFilePath;
	}

	public void setUploadFilePath(List<MultipartFile> uploadFilePath) {
		this.uploadFilePath = uploadFilePath;
	}

	public String getWalletName() {
		return walletName;
	}

	public void setWalletName(String walletName) {
		this.walletName = walletName;
	}

	public Float getWalletBalance() {
		return walletBalance;
	}

	public String getCheckBox() {
		return checkBox;
	}

	public void setCheckBox(String checkBox) {
		this.checkBox = checkBox;
	}

	public String getToUser() {
		return toUser;
	}

	public void setToUser(String toUser) {
		this.toUser = toUser;
	}

	public void setWalletBalance(Float walletBalance) {
		this.walletBalance = walletBalance;
	}

	public String getMobileNumberService() {
		return mobileNumberService;
	}

	public void setMobileNumberService(String mobileNumberService) {
		this.mobileNumberService = mobileNumberService;
	}

	public String getUserStatus() {
		return userStatus;
	}

	public void setUserStatus(String userStatus) {
		this.userStatus = userStatus;
	}

	public String getUserProductName() {
		return userProductName;
	}

	public void setUserProductName(String userProductName) {
		this.userProductName = userProductName;
	}

	public String getSubquerys() {
		return subquerys;
	}

	public void setSubquerys(String subquerys) {
		this.subquerys = subquerys;
	}

	public List<CustomerCareData> getWalletList() {
		return walletList;
	}

	public String getFromdate() {
		return fromdate;
	}

	public void setFromdate(String fromdate) {
		this.fromdate = fromdate;
	}

	public String getTodate() {
		return todate;
	}

	public void setTodate(String todate) {
		this.todate = todate;
	}

	public String getDescriptions() {
		return descriptions;
	}

	public void setDescriptions(String descriptions) {
		this.descriptions = descriptions;
	}

	public String getNames() {
		return names;
	}

	public void setNames(String names) {
		this.names = names;
	}

	public String getFinaldescription() {
		return finaldescription;
	}

	public void setFinaldescription(String finaldescription) {
		this.finaldescription = finaldescription;
	}

	public Integer getAccountId() {
		return accountId;
	}

	public void setAccountId(Integer accountId) {
		this.accountId = accountId;
	}

	public String getCustomerpriorityId() {
		return customerpriorityId;
	}

	public void setCustomerpriorityId(String customerpriorityId) {
		this.customerpriorityId = customerpriorityId;
	}

	public String getCustomerpriority() {
		return customerpriority;
	}

	public void setCustomerpriority(String customerpriority) {
		this.customerpriority = customerpriority;
	}

	public Integer getAccountTypeId() {
		return accountTypeId;
	}

	public void setAccountTypeId(Integer accountTypeId) {
		this.accountTypeId = accountTypeId;
	}

	public String getSecretQuestion() {
		return secretQuestion;
	}

	public void setSecretQuestion(String secretQuestion) {
		this.secretQuestion = secretQuestion;
	}

	public List<CustomerCareData> getVoucherlist() {
		return voucherlist;
	}

	public void setVoucherlist(List<CustomerCareData> voucherlist) {
		this.voucherlist = voucherlist;
	}

	public String getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}

	public Float getTransactionAmount() {
		return transactionAmount;
	}

	public void setTransactionAmount(Float transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	public String getStatu() {
		return statu;
	}

	public void setStatu(String statu) {
		this.statu = statu;
	}

	public String getStatusDesc() {
		return statusDesc;
	}

	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	public String getPlatformType() {
		return platformType;
	}

	public void setPlatformType(String platformType) {
		this.platformType = platformType;
	}

	public String getPlatformName() {
		return platformName;
	}

	public void setPlatformName(String platformName) {
		this.platformName = platformName;
	}

	public List<CustomerCareData> getvPinHistoryList() {
		return vPinHistoryList;
	}

	public void setvPinHistoryList(List<CustomerCareData> vPinHistoryList) {
		this.vPinHistoryList = vPinHistoryList;
	}

	public String getVoucherValue() {
		return voucherValue;
	}

	public void setVoucherValue(String voucherValue) {
		this.voucherValue = voucherValue;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public Object getIssuerName() {
		return issuerName;
	}

	public void setIssuerName(Object object) {
		this.issuerName = object;
	}

	public String getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(String issueDate) {
		this.issueDate = issueDate;
	}

	public List<CustomerCareData> getReslist() {
		return reslist;
	}

	public void setReslist(List<CustomerCareData> reslist) {
		this.reslist = reslist;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public Integer getResolutionTime() {
		return resolutionTime;
	}

	public void setResolutionTime(Integer resolutionTime) {
		this.resolutionTime = resolutionTime;
	}

	public String getUserMobile() {
		return userMobile;
	}

	public Integer getWeightage() {
		return weightage;
	}

	public void setWeightage(Integer weightage) {
		this.weightage = weightage;
	}

	public List<CustomerCareData> getCarelist() {
		return carelist;
	}

	public void setCarelist(List<CustomerCareData> carelist) {
		this.carelist = carelist;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Map<Integer, String> getUsertypemap() {
		return usertypemap;
	}

	public void setUsertypemap(Map<Integer, String> map) {
		this.usertypemap = map;
	}

	public String getUsertype() {
		return usertype;
	}

	public void setUsertype(String usertype) {
		this.usertype = usertype;
	}

	public List<CustomerCareData> getQuerytypelist() {
		return querytypelist;
	}

	public void setQuerytypelist(List<CustomerCareData> querytypelist) {
		this.querytypelist = querytypelist;
	}

	public Map<String, String> getQuerytypemap() {
		return querytypemap;
	}

	public void setQuerytypemap(Map<String, String> querytypemap) {
		this.querytypemap = querytypemap;
	}

	public Map<Integer, String> getQuerypriority() {
		return querypriority;
	}

	public void setQuerypriority(Map<Integer, String> querypriority) {
		this.querypriority = querypriority;
	}

	public String getSubquery() {
		return subquery;
	}

	public void setSubquery(String subquery) {
		this.subquery = subquery;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public List<CustomerCareData> getSubquerylist() {
		return subquerylist;
	}

	public void setSubquerylist(List<CustomerCareData> subquerylist) {
		this.subquerylist = subquerylist;
	}

	public String getCustomerid() {
		return customerid;
	}

	public void setCustomerid(String customerid) {
		this.customerid = customerid;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<CustomerCareData> getSubscriberlist() {
		return subscriberlist;
	}

	public void setSubscriberlist(List<CustomerCareData> subscriberlist) {
		this.subscriberlist = subscriberlist;
	}

	public String getMobilenumber() {
		return mobilenumber;
	}

	public void setMobilenumber(String mobilenumber) {
		this.mobilenumber = mobilenumber;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public Map<Integer, String> getProductmap() {
		return productmap;
	}

	public void setProductmap(Map<Integer, String> productmap) {
		this.productmap = productmap;
	}

	public Integer getSubqueryid() {
		return subqueryid;
	}

	public void setSubqueryid(Integer subqueryid) {
		this.subqueryid = subqueryid;
	}

	public String getSubquerydescription() {
		return subquerydescription;
	}

	public void setSubquerydescription(String subquerydescription) {
		this.subquerydescription = subquerydescription;
	}

	public String getCreatedon() {
		return createdon;
	}

	public void setCreatedon(String createdon) {
		this.createdon = createdon;
	}

	public String getTicketno() {
		return ticketno;
	}

	public void setTicketno(String ticketno) {
		this.ticketno = ticketno;
	}

	public List<CustomerCareData> getCalllist() {
		return calllist;
	}

	public void setCalllist(List<CustomerCareData> calllist) {
		this.calllist = calllist;
	}

	public String getSubquerycomment() {
		return subquerycomment;
	}

	public void setSubquerycomment(String subquerycomment) {
		this.subquerycomment = subquerycomment;
	}

	public Integer getQuerylogId() {
		return querylogId;
	}

	public void setQuerylogId(Integer querylogId) {
		this.querylogId = querylogId;
	}

	public Integer getWallettypeid() {
		return wallettypeid;
	}

	public void setWallettypeid(Integer wallettypeid) {
		this.wallettypeid = wallettypeid;
	}

	public Integer getWalletid() {
		return walletid;
	}

	public void setWalletid(Integer walletid) {
		this.walletid = walletid;
	}

	public String getTrxAmount() {
		return trxAmount;
	}

	public void setTrxAmount(String trxAmount) {
		this.trxAmount = trxAmount;
	}

	public String getTrxType() {
		return trxType;
	}

	public void setTrxType(String trxType) {
		this.trxType = trxType;
	}

	public String getTrxDate() {
		return trxDate;
	}

	public void setTrxDate(String trxDate) {
		this.trxDate = trxDate;
	}

	public Long getRefTxnId() {
		return refTxnId;
	}

	public void setRefTxnId(Long refTxnId) {
		this.refTxnId = refTxnId;
	}

	public Integer getRefundRefTxnId() {
		return refundRefTxnId;
	}

	public void setRefundRefTxnId(Integer refundRefTxnId) {
		this.refundRefTxnId = refundRefTxnId;
	}

	public Integer getSubscriberid() {
		return subscriberid;
	}

	public void setSubscriberid(Integer subscriberid) {
		this.subscriberid = subscriberid;
	}

	public Integer getCritical() {
		return critical;
	}

	public void setCritical(Integer critical) {
		this.critical = critical;
	}

	public Integer getHigh() {
		return high;
	}

	public void setHigh(Integer high) {
		this.high = high;
	}

	public Integer getMedium() {
		return medium;
	}

	public void setMedium(Integer medium) {
		this.medium = medium;
	}

	public Integer getLow() {
		return low;
	}

	public void setLow(Integer low) {
		this.low = low;
	}

	public Integer getAllpriority() {
		return allpriority;
	}

	public void setAllpriority(Integer allpriority) {
		this.allpriority = allpriority;
	}

	public List<CustomerCareData> getAllquerylist() {
		return allquerylist;
	}

	public void setAllquerylist(List<CustomerCareData> allquerylist) {
		this.allquerylist = allquerylist;
	}

	public List<CustomerCareData> getQueryloghis() {
		return queryloghis;
	}

	public void setQueryloghis(List<CustomerCareData> queryloghis) {
		this.queryloghis = queryloghis;
	}

	public String getCustomername() {
		return customername;
	}

	public void setCustomername(String customername) {
		this.customername = customername;
	}

	public String getTicketNumber() {
		return ticketNumber;
	}

	public void setTicketNumber(String ticketNumber) {
		this.ticketNumber = ticketNumber;
	}

	public Integer getQuerytime() {
		return querytime;
	}

	public void setQuerytime(Integer querytime) {
		this.querytime = querytime;
	}

	public Object getTxnResponse() {
		return txnResponse;
	}

	public void setWalletList(List<CustomerCareData> walletList) {
		this.walletList = walletList;
	}

	public void setTxnResponse(WalletListResponseData[] txnResponse) {
		this.txnResponse = txnResponse;

	}

	public void setUserMobile(String userMobile) {
		this.userMobile = userMobile;

	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getTxnStatus() {
		return txnStatus;
	}

	public void setTxnStatus(String txnStatus) {
		this.txnStatus = txnStatus;
	}

	public String getSearchTxt() {
		return searchTxt;
	}

	public void setSearchTxt(String searchTxt) {
		this.searchTxt = searchTxt;
	}

	public String getHistoryComment() {
		return historyComment;
	}

	public void setHistoryComment(String historyComment) {
		this.historyComment = historyComment;
	}

	public String getExecutiveName() {
		return executiveName;
	}

	public void setExecutiveName(String executiveName) {
		this.executiveName = executiveName;
	}

	public String getPendingAt() {
		return pendingAt;
	}

	public void setPendingAt(String pendingAt) {
		this.pendingAt = pendingAt;
	}

	public String getExecutiveLevel() {
		return executiveLevel;
	}

	public void setExecutiveLevel(String executiveLevel) {
		this.executiveLevel = executiveLevel;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getCommissionRadioValue() {
		return commissionRadioValue;
	}

	public void setCommissionRadioValue(String commissionRadioValue) {
		this.commissionRadioValue = commissionRadioValue;
	}

	public String getTransactionRadioValue() {
		return transactionRadioValue;
	}

	public void setTransactionRadioValue(String transactionRadioValue) {
		this.transactionRadioValue = transactionRadioValue;
	}

	public String getRefundComment() {
		return refundComment;
	}

	public void setRefundComment(String refundComment) {
		this.refundComment = refundComment;
	}

	public String[] getCheckedLinks() {
		return checkedLinks;
	}

	public void setCheckedLinks(String[] checkedLinks) {
		this.checkedLinks = checkedLinks;
	}

	public String getBackButton() {
		return backButton;
	}

	public void setBackButton(String backButton) {
		this.backButton = backButton;
	}

	public String getRealPath() {
		return realPath;
	}

	public void setRealPath(String realPath) {
		this.realPath = realPath;
	}

	public Integer getDays() {
		return days;
	}

	public void setDays(Integer days) {
		this.days = days;
	}

	public List<CustomerCareData> getTxnList() {
		return txnList;
	}

	public void setTxnList(List<CustomerCareData> txnList) {
		this.txnList = txnList;
	}

	public void setTransactionAmount(float transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public Integer getQuerytypeId() {
		return querytypeId;
	}

	public void setQuerytypeId(Integer querytypeId) {
		this.querytypeId = querytypeId;
	}

	public Map<Integer, String> getQueryIdmap() {
		return queryIdmap;
	}

	public void setQueryIdmap(Map<Integer, String> queryIdmap) {
		this.queryIdmap = queryIdmap;
	}

	public String getExternalNum() {
		return externalNum;
	}

	public void setExternalNum(String externalNum) {
		this.externalNum = externalNum;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}
	public Integer getKycVerificationId() {
		return kycVerificationId;
	}

	public void setKycVerificationId(Integer kycVerificationId) {
		this.kycVerificationId = kycVerificationId;
	}

	public String getMsisdnComment() {
		return msisdnComment;
	}

	public void setMsisdnComment(String msisdnComment) {
		this.msisdnComment = msisdnComment;
	}

	public String getOtp() {
		return otp;
	}

	public void setOtp(String otp) {
		this.otp = otp;
	}

	public String getProductTypeId() {
		return productTypeId;
	}

	public void setProductTypeId(String productTypeId) {
		this.productTypeId = productTypeId;
	}

	public String getTransactionStatus() {
		return transactionStatus;
	}

	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("CustomerCareData [days=");
		builder.append(days);
		builder.append(", backButton=");
		builder.append(backButton);
		builder.append(", realPath=");
		builder.append(realPath);
		builder.append(", filePath=");
		builder.append(filePath);
		builder.append(", ticketNumber=");
		builder.append(ticketNumber);
		builder.append(", secretQuestion=");
		builder.append(secretQuestion);
		builder.append(", weightage=");
		builder.append(weightage);
		builder.append(", usertypemap=");
		builder.append(usertypemap);
		builder.append(", usertype=");
		builder.append(usertype);
		builder.append(", description=");
		builder.append(description);
		builder.append(", descriptions=");
		builder.append(descriptions);
		builder.append(", names=");
		builder.append(names);
		builder.append(", historyComment=");
		builder.append(historyComment);
		builder.append(", querytypeId=");
		builder.append(querytypeId);
		builder.append(", productTypeId=");
		builder.append(productTypeId);
		builder.append(", checkBox=");
		builder.append(checkBox);
		builder.append(", address=");
		builder.append(address);
		builder.append(", executiveName=");
		builder.append(executiveName);
		builder.append(", executiveLevel=");
		builder.append(executiveLevel);
		builder.append(", subquery=");
		builder.append(subquery);
		builder.append(", subquerys=");
		builder.append(subquerys);
		builder.append(", userStatus=");
		builder.append(userStatus);
		builder.append(", userProductName=");
		builder.append(userProductName);
		builder.append(", mobileNumberService=");
		builder.append(mobileNumberService);
		builder.append(", walletBalance=");
		builder.append(walletBalance);
		builder.append(", walletName=");
		builder.append(walletName);
		builder.append(", walletList=");
		builder.append(walletList);
		builder.append(", txnList=");
		builder.append(txnList);
		builder.append(", checkedLinks=");
		builder.append(Arrays.toString(checkedLinks));
		builder.append(", pendingAt=");
		builder.append(pendingAt);
		builder.append(", startDate=");
		builder.append(startDate);
		builder.append(", endDate=");
		builder.append(endDate);
		builder.append(", searchTxt=");
		builder.append(searchTxt);
		builder.append(", txnStatus=");
		builder.append(txnStatus);
		builder.append(", kycVerificationId=");
		builder.append(kycVerificationId);
		builder.append(", commissionRadioValue=");
		builder.append(commissionRadioValue);
		builder.append(", transactionRadioValue=");
		builder.append(transactionRadioValue);
		builder.append(", priority=");
		builder.append(priority);
		builder.append(", customerpriority=");
		builder.append(customerpriority);
		builder.append(", refundComment=");
		builder.append(refundComment);
		builder.append(", customerpriorityId=");
		builder.append(customerpriorityId);
		builder.append(", modifiedBy=");
		builder.append(modifiedBy);
		builder.append(", querylogId=");
		builder.append(querylogId);
		builder.append(", walletid=");
		builder.append(walletid);
		builder.append(", subscriberid=");
		builder.append(subscriberid);
		builder.append(", trxAmount=");
		builder.append(trxAmount);
		builder.append(", trxType=");
		builder.append(trxType);
		builder.append(", trxDate=");
		builder.append(trxDate);
		builder.append(", refTxnId=");
		builder.append(refTxnId);
		builder.append(", refundRefTxnId=");
		builder.append(refundRefTxnId);
		builder.append(", wallettypeid=");
		builder.append(wallettypeid);
		builder.append(", calllist=");
		builder.append(calllist);
		builder.append(", createdon=");
		builder.append(createdon);
		builder.append(", ticketno=");
		builder.append(ticketno);
		builder.append(", date=");
		builder.append(date);
		builder.append(", productmap=");
		builder.append(productmap);
		builder.append(", customerid=");
		builder.append(customerid);
		builder.append(", mobilenumber=");
		builder.append(mobilenumber);
		builder.append(", email=");
		builder.append(email);
		builder.append(", status=");
		builder.append(status);
		builder.append(", subqueryid=");
		builder.append(subqueryid);
		builder.append(", subquerydescription=");
		builder.append(subquerydescription);
		builder.append(", subquerycomment=");
		builder.append(subquerycomment);
		builder.append(", subscriberlist=");
		builder.append(subscriberlist);
		builder.append(", subquerylist=");
		builder.append(subquerylist);
		builder.append(", carelist=");
		builder.append(carelist);
		builder.append(", querytypelist=");
		builder.append(querytypelist);
		builder.append(", querytypemap=");
		builder.append(querytypemap);
		builder.append(", queryIdmap=");
		builder.append(queryIdmap);
		builder.append(", querypriority=");
		builder.append(querypriority);
		builder.append(", allquerylist=");
		builder.append(allquerylist);
		builder.append(", reslist=");
		builder.append(reslist);
		builder.append(", issueDate=");
		builder.append(issueDate);
		builder.append(", expiryDate=");
		builder.append(expiryDate);
		builder.append(", voucherValue=");
		builder.append(voucherValue);
		builder.append(", vPinHistoryList=");
		builder.append(vPinHistoryList);
		builder.append(", platformName=");
		builder.append(platformName);
		builder.append(", platformType=");
		builder.append(platformType);
		builder.append(", transactionDate=");
		builder.append(transactionDate);
		builder.append(", transactionAmount=");
		builder.append(transactionAmount);
		builder.append(", statu=");
		builder.append(statu);
		builder.append(", statusDesc=");
		builder.append(statusDesc);
		builder.append(", accountTypeId=");
		builder.append(accountTypeId);
		builder.append(", serialNumber=");
		builder.append(serialNumber);
		builder.append(", queryloghis=");
		builder.append(queryloghis);
		builder.append(", critical=");
		builder.append(critical);
		builder.append(", high=");
		builder.append(high);
		builder.append(", medium=");
		builder.append(medium);
		builder.append(", low=");
		builder.append(low);
		builder.append(", allpriority=");
		builder.append(allpriority);
		builder.append(", txnResponse=");
		builder.append(Arrays.toString(txnResponse));
		builder.append(", userMobile=");
		builder.append(userMobile);
		builder.append(", voucherlist=");
		builder.append(voucherlist);
		builder.append(", querytime=");
		builder.append(querytime);
		builder.append(", resolutionTime=");
		builder.append(resolutionTime);
		builder.append(", customername=");
		builder.append(customername);
		builder.append(", accountId=");
		builder.append(accountId);
		builder.append(", finaldescription=");
		builder.append(finaldescription);
		builder.append(", todate=");
		builder.append(todate);
		builder.append(", fromdate=");
		builder.append(fromdate);
		builder.append(", product=");
		builder.append(product);
		builder.append(", toUser=");
		builder.append(toUser);
		builder.append(", externalNum=");
		builder.append(externalNum);
		builder.append(", bankName=");
		builder.append(bankName);
		builder.append(", action=");
		builder.append(action);
		builder.append(", productType=");
		builder.append(productType);
		builder.append(", msisdnComment=");
		builder.append(msisdnComment);
		builder.append(", otp=");
		builder.append(otp);
		builder.append(", transactionStatus=");
		builder.append(transactionStatus);
		builder.append("]");
		return builder.toString();
	}

	public String getNewMobilenumber() {
		return newMobilenumber;	
	}

	public void setNewMobilenumber(String newMobilenumber) {
		this.newMobilenumber = newMobilenumber;
	}
	
	

	
	
}
