/**
 * 
 */
package com.ng.bridge.dataobject.euronet.otherservice;

import java.io.Serializable;

/**
 * @author gaurav
 *
 */
public class EuroNetResponse implements Serializable {

	private static final long serialVersionUID = 1L;
	private String responseCode;
	private String responseMsg;
	private String merchantRefNo;
	private String enRefNo;
	private String operatorRefNo;
	
	public String getMerchantRefNo() {
		return merchantRefNo;
	}
	
	public void setMerchantRefNo(String merchantRefNo) {
		this.merchantRefNo = merchantRefNo;
	}
	
	public String getEnRefNo() {
		return enRefNo;
	}
	
	public void setEnRefNo(String enRefNo) {
		this.enRefNo = enRefNo;
	}
	
	public String getOperatorRefNo() {
		return operatorRefNo;
	}
	
	public void setOperatorRefNo(String operatorRefNo) {
		this.operatorRefNo = operatorRefNo;
	}
	
	public String getResponseCode() {
		return responseCode;
	}
	
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	
	public String getResponseMsg() {
		return responseMsg;
	}
	
	public void setResponseMsg(String responseMsg) {
		this.responseMsg = responseMsg;
	}

}
