/**
 * 
 */
package com.ng.sb.common.exception;

public class BoxDetailsException  extends RuntimeException {
	private static final long serialVersionUID = 1L;
	
	public BoxDetailsException(String message){
		super(message);
	}
}