/**
 * 
 */
package com.ng.user.dto;

import org.hibernate.validator.constraints.NotBlank;

import com.ng.sb.common.dataobject.ValidationBean;
import com.ng.sb.common.util.UserType;

/**
 * @author gopal
 *
 */
public class ForgotPasswordRequest implements ValidationBean {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1505854664500426527L;

	
	
	@NotBlank(message="Channel Id cannot be blank")
	private String channelId;
	
	
	private int userTypeId = UserType.AGENT.getUserTypeId();
	
	@NotBlank(message="User Id cannot be blank")
	private String userId;
	
	private String dateOfBirth;
	
	private String answerString;
	
	private String otpValue;
	
	private Integer stepNo;
	
	private String newPassword;
	
	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getAnswerString() {
		return answerString;
	}

	public void setAnswerString(String answerString) {
		this.answerString = answerString;
	}

	public Integer getStepNo() {
		return stepNo;
	}

	public void setStepNo(Integer stepNo) {
		this.stepNo = stepNo;
	}

	public String getNewPassword() {
		return newPassword;
	}

	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}

	public int getUserTypeId() {
		return userTypeId;
	}

	public void setUserTypeId(int userTypeId) {
		this.userTypeId = userTypeId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public String getOtpValue() {
		return otpValue;
	}

	public void setOtpValue(String otpValue) {
		this.otpValue = otpValue;
	}
	
	
}
