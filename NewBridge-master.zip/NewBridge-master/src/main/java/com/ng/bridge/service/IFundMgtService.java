/**
 * 
 */
package com.ng.bridge.service;

/**
 * @author gaurav
 *
 */
public interface IFundMgtService extends IBridgeService {

}
