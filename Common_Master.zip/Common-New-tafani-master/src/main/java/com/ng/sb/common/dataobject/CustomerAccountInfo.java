/**
 * 
 */
package com.ng.sb.common.dataobject;

import java.io.Serializable;
import java.util.Date;

/**
 * @author gopal
 *
 */
public class CustomerAccountInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2559398049894951716L;

	private String customerId;
	
	private Long accountNumber;
	
	private Long cardNumber;
	
	private String accountName;
	
	private Date accountOpenDate;

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public Long getAccountNumber() {
		return accountNumber;
	}

	

	public void setCardNumber(Long cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getAccountName() {
		return accountName;
	}
	
	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public Long getCardNumber() {
		return cardNumber;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public Date getAccountOpenDate() {
		return accountOpenDate;
	}

	public void setAccountOpenDate(Date accountOpenDate) {
		this.accountOpenDate = accountOpenDate;
	} 
	
	
}
