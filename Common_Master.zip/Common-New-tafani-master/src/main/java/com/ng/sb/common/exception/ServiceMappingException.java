/**
 * 
 */
package com.ng.sb.common.exception;

/**
 * @author gaurav
 *
 */
public class ServiceMappingException extends Exception {
	private static final long serialVersionUID = 1L;
	
	public ServiceMappingException(String message){
		super(message);
	}
}