package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author abhishek
 *
 */
@Entity
@Table(name = "KYCLevel")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "KYCLevel.findAll", query = "SELECT kd FROM KYCLevel kd order by kd.weightage "),
    @NamedQuery(name = "KYCLevel.findALLKycValues", query = "SELECT kd FROM KYCLevel kd where kd.weightage!=0 order by kd.weightage "),
    @NamedQuery(name = "KYCLevel.findallkyc", query = "SELECT kd FROM KYCLevel kd order by kd.weightage "),
    })
public class KYCLevel implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
    @Basic(optional = false)
    @Column(name = "name")
    private String name;
    @Basic(optional = false)
    @Column(name = "weightage")
    private Integer weightage;
    
    public KYCLevel(){
    	//empty
    }
    
    public KYCLevel(Integer id){
    	this.id = id;
    }
    
    public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getWeightage() {
		return weightage;
	}

	public void setWeightage(Integer weightage) {
		this.weightage = weightage;
	}

	@Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof KYCLevel)) {
            return false;
        }
        KYCLevel other = (KYCLevel) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.KYCLevel[ id=" + id + " ]";
    }
}
