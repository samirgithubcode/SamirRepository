package com.ng.sc.dao;

import java.util.List;

import com.ng.sb.common.dataobject.LoginData;
import com.ng.sb.common.model.AccountLoginInfo;
import com.ng.sb.common.model.AccountSessionInfoSelfCare;
import com.ng.sb.common.model.CountryCode;
import com.ng.sb.common.model.SecurityQuestion;
import com.ng.sb.common.model.SignUpOtp;
import com.ng.sb.common.model.Subscriber;
import com.ng.sb.common.model.SysAccountGroup;
import com.ng.sb.common.model.SysAccountType;

public interface IScLoginDAO extends ISelfCareDAO {

	AccountSessionInfoSelfCare accountSessionInfo(LoginData loginData) throws Exception;

	boolean updateAccountLoginInfo(Subscriber subscriber);

	boolean insertAccountSessionInfo(AccountSessionInfoSelfCare accountSessionInfo);

	boolean updateAccountSessionInfo(AccountSessionInfoSelfCare accountSessionInfo);

	List<AccountSessionInfoSelfCare> sessionInfo(int accountId);

	List<SysAccountGroup> accountGroupList();

	List<SysAccountGroup> SysAccountGroupByName(String groupName);

	List<SysAccountType> accountById(int groupId);

	List<SysAccountType> accountList();

	AccountLoginInfo accountLoginInfo(String loginName) throws Exception;

	Subscriber accountByLoginInfo(String loginName) throws Exception;

	List<SecurityQuestion> getSecurityQuestion() throws Exception;

	AccountLoginInfo validatePassExp(String username) throws Exception;

	public List<SysAccountType> getRoleAccountistByWeightage(Integer loginWeightage) throws Exception;

	public List<Subscriber> checkUniqueMobileNo(String userMobile) throws Exception;

	public List<AccountLoginInfo> checkUniqueEmailId(String userEmailId) throws Exception;

	public List<AccountLoginInfo> checkUniqueLoginId(String userLoginName) throws Exception;

	public Subscriber saveUserCreation(Subscriber subscriber) throws Exception;

	public List<CountryCode> getCountryCodeMap() throws Exception;

	public void saveSignupDetails(SignUpOtp signupDetails) throws Exception;

	public SignUpOtp getSignUpinfo(String mobile) throws Exception ;

	public void updateSignUpDetails(String mobile) throws Exception;

	public void updateTimeoutOtp(int otp) throws Exception;

	Subscriber updateSubscriberInfo(Subscriber subscriber);

}
