package com.ng.bridge.dataobject.euronet.otherservice;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class IService1Proxy implements com.ng.bridge.dataobject.euronet.otherservice.IService1 {
	private static final Logger LOGGER = LoggerFactory.getLogger(IService1Proxy.class);
  private String endpoint = null;
	private static final  String URL="javax.xml.rpc.service.endpoint.address";
  private com.ng.bridge.dataobject.euronet.otherservice.IService1 iService1 = null;
  
  public IService1Proxy() {
    initService1Proxy();
  }
  
  public IService1Proxy(String endpoint) {
   this.endpoint = endpoint;
    initService1Proxy();
  }
  
  private void initService1Proxy() {
    try {
      iService1 = (new com.ng.bridge.dataobject.euronet.otherservice.Service1Locator()).getBasicHttpBindingIService1();
      if (iService1 != null) {
        if (endpoint != null)
          ((javax.xml.rpc.Stub)iService1)._setProperty(URL, endpoint);
        else
          endpoint = (String)((javax.xml.rpc.Stub)iService1)._getProperty(URL);
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {
    	 LOGGER.debug("exception occured:"+serviceException);
    }
  }
  
  public String getEndpoint() {
    return endpoint;
  }
  
  public void setEndpoint(String endpoint) {
   this.endpoint = endpoint;
    if (iService1 != null)
      ((javax.xml.rpc.Stub)iService1)._setProperty(URL, endpoint);
    
  }
  
  public com.ng.bridge.dataobject.euronet.otherservice.IService1 getIService1() {
    if (iService1 == null)
      initService1Proxy();
    return iService1;
  }
  
  public java.lang.String sendEuroVasRequest(java.lang.String request) throws java.rmi.RemoteException{
    if (iService1 == null)
      initService1Proxy();
    return iService1.sendEuroVasRequest(request);
  }
  
  
}