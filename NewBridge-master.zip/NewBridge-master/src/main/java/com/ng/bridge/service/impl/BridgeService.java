/**
 * 
 */
package com.ng.bridge.service.impl;

import org.springframework.stereotype.Service;

import com.ng.bridge.service.IBridgeService;
import com.ng.sb.common.service.impl.SuperParentService;
import com.ng.sb.common.util.SystemConstant;

/**
 * @author gaurav
 *
 */
@Service(SystemConstant.BRIDGE_SERVICE)
public class BridgeService extends SuperParentService implements IBridgeService {

}
