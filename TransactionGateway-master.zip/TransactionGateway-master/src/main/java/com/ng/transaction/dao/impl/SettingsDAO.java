/**
 * 
 */
package com.ng.transaction.dao.impl;

import org.springframework.stereotype.Repository;

import com.ng.sb.common.util.SystemConstant;
import com.ng.transaction.dao.ISettingsDAO;

/**
 * @author gaurav
 *
 */
@Repository(value=SystemConstant.SETTINGS_DAO)
public class SettingsDAO extends TransactionDAO implements ISettingsDAO {
	private static final long serialVersionUID = 1L;

}
