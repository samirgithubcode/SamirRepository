package com.ng.bridge.dataobject.eko;

public class AccountInfoRes {
	private String responsetypeid;

    private String message;

    private String responsestatusid;

    private String status;

    private AccountResData data;

    public String getResponsetypeid ()
    {
        return responsetypeid;
    }

    public void setResponsetypeid (String responsetypeid)
    {
        this.responsetypeid = responsetypeid;
    }

    public String getMessage ()
    {
        return message;
    }

    public void setMessage (String message)
    {
        this.message = message;
    }

    public String getResponsestatusid ()
    {
        return responsestatusid;
    }

    public void setResponsestatusid (String responsestatusid)
    {
        this.responsestatusid = responsestatusid;
    }

    public String getStatus ()
    {
        return status;
    }

    public void setStatus (String status)
    {
        this.status = status;
    }

	public AccountResData getData() {
		return data;
	}

	public void setData(AccountResData data) {
		this.data = data;
	}

    
   


}
