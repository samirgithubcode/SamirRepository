/**
 * 
 */
package com.ng.user.rest;

import java.util.Iterator;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.ng.sb.common.cache.MemCacheManager;
import com.ng.sb.common.cache.MemCacheUtils;
import com.ng.sb.common.dataobject.PlatformLoginData;
import com.ng.sb.common.dataobject.RequestObject;
import com.ng.sb.common.dataobject.ResponseObject;
import com.ng.sb.common.dataobject.UserAccountData;
import com.ng.sb.common.dataobject.ValidationBean;
import com.ng.sb.common.util.ErrorCodes;
import com.ng.sb.common.util.ExceptionUtils;
import com.ng.sb.common.util.KeyEncryptionUtils;
import com.ng.sb.common.util.ProcessFiledError;
import com.ng.sb.common.util.SystemConstant;
import com.ng.user.dto.ActivationCodeRequest;
import com.ng.user.dto.ChangePasswordRequest;
import com.ng.user.dto.ForgotPasswordRequest;
import com.ng.user.dto.ForgotPasswordResponse;
import com.ng.user.dto.LoginRequset;
import com.ng.user.dto.LoginResponse;
import com.ng.user.dto.OtpRequest;
import com.ng.user.dto.SignUpRequest;
import com.ng.user.logger.UserServiceLogger;
import com.ng.user.service.IUserService;
import com.ng.user.utils.CommonUtils;
import com.ng.user.utils.UserServiceConstants;

/**
 * @author gopal
 *
 */
@RestController
@RequestMapping("user/auth/")
public class AuthController {

	@Autowired
    private MemCacheManager cacheManager;
	
	@Autowired
	ProcessFiledError fieldError;
	
	@Autowired
	IUserService userService;
	
	@Autowired
	PlatformLoginData platformLoginData;
	
	@RequestMapping(value = "/login", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	public @ResponseBody LoginResponse authenticateUser(@RequestBody LoginRequset loginRequest, HttpServletRequest request) 
	{
		LoginResponse loginResponse = null;
	
		try
		{
		UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.INFO, UserServiceConstants.LOGGING_REQUEST + UserServiceConstants.LOGGING_METHOD_NAME +Thread.currentThread().getStackTrace()[1].getMethodName()+ UserServiceConstants.LOGGING_LOGIN_ID +loginRequest.getUserId()+ UserServiceConstants.LOGGING_DEVICE_ID + loginRequest.getDeviceId() + UserServiceConstants.LOGGING_REQUEST_FROM +request.getRemoteAddr() + UserServiceConstants.LOGGING_USER_ADDRESS + request.getHeader(SystemConstant.USER_IP_ADDRESS));
		
		Set<ConstraintViolation<ValidationBean>> validationError = KeyEncryptionUtils.validateBean(loginRequest);
		
		if(validationError != null && !validationError.isEmpty())
	  	{
			
			loginResponse = new LoginResponse();
			
			loginResponse.setStatus(ErrorCodes.REQUIRED_PARAMETERS_MISSING.getCode());
			
			String errorMessage = getErrorMessage(validationError);
			
			loginResponse.setMessage(errorMessage);
		
			 UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_RESPONSE + UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+ UserServiceConstants.LOGGING_ACCESS_CHANNEL  + loginRequest.getChannelId() + UserServiceConstants.LOGGING_REQUEST_FROM +request.getRemoteAddr() + UserServiceConstants.LOGGING_USER_ADDRESS + request.getHeader(SystemConstant.USER_IP_ADDRESS) + UserServiceConstants.LOGGING_ERROR +errorMessage);
			 
			 return loginResponse;
		}
		
		loginResponse = userService.authenticateUser(loginRequest);
		
		UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.INFO, UserServiceConstants.LOGGING_RESPONSE + UserServiceConstants.LOGGING_METHOD_NAME + Thread.currentThread().getStackTrace()[1].getMethodName()+ UserServiceConstants.LOGGING_ACCESS_CHANNEL  + loginRequest.getChannelId() + UserServiceConstants.LOGGING_REQUEST_FROM +request.getRemoteAddr() + UserServiceConstants.LOGGING_USER_ADDRESS + request.getHeader(SystemConstant.USER_IP_ADDRESS) +UserServiceConstants.LOGGING_RESPONSE +  loginResponse.getStatus() +  UserServiceConstants.LOGGING_RESPONSE_STRING + loginResponse.getTokenId());
		
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), UserServiceConstants.PACKAGE_FOR_EXCEPTION);
			
			UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
		}
		
		return loginResponse;
	}
	
	private String getErrorMessage(Set<ConstraintViolation<ValidationBean>> validationError) 
	{
		 Iterator<ConstraintViolation<ValidationBean>>  itr =  validationError.iterator();
		 StringBuilder builder = new StringBuilder();
		 
		 int counter = 1;
		 while(itr.hasNext())
		 {
			 builder.append(counter+". "+itr.next().getMessage()+" ");
			 
			 counter++;
		 }
		 
		return builder.toString();
	}

	@RequestMapping(value = "/resetPassword", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	public @ResponseBody ResponseObject resetPassword(@RequestBody RequestObject requstObject, HttpServletRequest request) 
	{
		return null;
	}
	
	@RequestMapping(value = "/forgotPassword", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	public @ResponseBody ForgotPasswordResponse fogotPassword(@RequestBody ForgotPasswordRequest forgotPasswordRequest, HttpServletRequest request) 
	{

		UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.INFO, UserServiceConstants.LOGGING_REQUEST + UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+ UserServiceConstants.LOGGING_ACCESS_CHANNEL  + forgotPasswordRequest.getChannelId() + UserServiceConstants.LOGGING_REQUEST_FROM +request.getRemoteAddr() + UserServiceConstants.LOGGING_USER_ADDRESS + request.getHeader(SystemConstant.USER_IP_ADDRESS));
		
		ForgotPasswordResponse responseObject = new ForgotPasswordResponse();
		
		/* 
		 * Get Agent details from tokenId
		 * requestObject.getTokenId()
		 * 
		 */
		try
		{
			 Set<ConstraintViolation<ValidationBean>> validationError = KeyEncryptionUtils.validateBean(forgotPasswordRequest);
				
						if(validationError != null && !validationError.isEmpty())
						{
							 responseObject.setStatus(ErrorCodes.REQUIRED_PARAMETERS_MISSING.getCode());
							 
							 String errorMessage = getErrorMessage(validationError);
							 
							
							 responseObject.setMessage(errorMessage);
						
							 UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_RESPONSE + UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+ UserServiceConstants.LOGGING_ACCESS_CHANNEL  + forgotPasswordRequest.getChannelId() + UserServiceConstants.LOGGING_REQUEST_FROM +request.getRemoteAddr() + UserServiceConstants.LOGGING_USER_ADDRESS + request.getHeader(SystemConstant.USER_IP_ADDRESS) + UserServiceConstants.LOGGING_ERROR +errorMessage);
							 
							 return responseObject;
						}
						
						responseObject =  userService.forgotPassword(forgotPasswordRequest);
			 
			  
			  UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.INFO, UserServiceConstants.LOGGING_RESPONSE + UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+ UserServiceConstants.LOGGING_ACCESS_CHANNEL  + forgotPasswordRequest.getChannelId() + UserServiceConstants.LOGGING_REQUEST_FROM +request.getRemoteAddr() + UserServiceConstants.LOGGING_USER_ADDRESS + request.getHeader(SystemConstant.USER_IP_ADDRESS) + UserServiceConstants.LOGGING_RESPONSE +responseObject.getStatus() +  UserServiceConstants.LOGGING_RESPONSE_STRING +responseObject.getMessage());
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), UserServiceConstants.PACKAGE_FOR_EXCEPTION);
			
			UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			responseObject.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseObject.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e.getMessage());
		}
		
		return responseObject;
	}
	
	@RequestMapping(value = "/changePassword", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	public @ResponseBody ResponseObject changePassword(@RequestBody RequestObject requestObject, HttpServletRequest request) 
	{
		UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.INFO, UserServiceConstants.LOGGING_REQUEST + UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+ UserServiceConstants.LOGGING_TOKEN_STRING +requestObject.getTokenId()+ UserServiceConstants.LOGGING_ACCESS_CHANNEL  + requestObject.getChannelId() + UserServiceConstants.LOGGING_REQUEST_FROM +request.getRemoteAddr() + UserServiceConstants.LOGGING_USER_ADDRESS + request.getHeader(SystemConstant.USER_IP_ADDRESS));
		
		ResponseObject responseObject = new ResponseObject();
		
		/* 
		 * Get Agent details from tokenId
		 * requestObject.getTokenId()
		 * 
		 */
		ChangePasswordRequest changePasswordRequest = null;
		Object payload =  requestObject.getPayload();
		UserAccountData accountData = null;
		try
		{
			//Check token Validity
			accountData = cacheManager.getFromCache(requestObject.getTokenId(), UserAccountData.class, MemCacheUtils.AUTHTOKENCACHE);
			
			responseObject = CommonUtils.validateRequest(accountData, requestObject, request, false);
			
			if(responseObject.getStatus() != null)
			{
				return responseObject;
			}
			  changePasswordRequest = KeyEncryptionUtils.jsonStringToObject(KeyEncryptionUtils.decryptUsingKey(accountData.getSecretKey(), payload), ChangePasswordRequest.class);
				
			  responseObject = CommonUtils.validateRequestData(changePasswordRequest, requestObject, request);
			 
			  if(changePasswordRequest == null || responseObject.getStatus() != null)
			  {
					return responseObject;
			  }
			  changePasswordRequest.setUserId("" + accountData.getLoginId());
			  changePasswordRequest.setUserTypeId(accountData.getUserType());
			  
			  responseObject =  userService.changePassword(changePasswordRequest);
			  
			  UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.INFO, UserServiceConstants.LOGGING_RESPONSE + UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+ UserServiceConstants.LOGGING_ACCESS_CHANNEL  + requestObject.getChannelId() + UserServiceConstants.LOGGING_REQUEST_FROM +request.getRemoteAddr() + UserServiceConstants.LOGGING_USER_ADDRESS + request.getHeader(SystemConstant.USER_IP_ADDRESS) + UserServiceConstants.LOGGING_RESPONSE +responseObject.getStatus() +  UserServiceConstants.LOGGING_RESPONSE_STRING +responseObject.getMessage());
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), UserServiceConstants.PACKAGE_FOR_EXCEPTION);
			
			UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			responseObject.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseObject.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e.getMessage());
		}
		
		return responseObject;
	}
	
	@RequestMapping(value = "/sendOTP", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	public @ResponseBody ResponseObject sendOTP(@RequestBody RequestObject requestObject, HttpServletRequest request) 
	{
		UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.INFO, UserServiceConstants.LOGGING_REQUEST + UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+ UserServiceConstants.LOGGING_TOKEN_STRING +requestObject.getTokenId()+ UserServiceConstants.LOGGING_ACCESS_CHANNEL  + requestObject.getChannelId() + UserServiceConstants.LOGGING_REQUEST_FROM +request.getRemoteAddr() + UserServiceConstants.LOGGING_USER_ADDRESS + request.getHeader(SystemConstant.USER_IP_ADDRESS));
			
			ResponseObject responseObject = new ResponseObject();
			
			/* 
			 * Get Agent details from tokenId
			 * requestObject.getTokenId()
			 * 
			 */
			OtpRequest otpRequest = null;
			Object payload =  requestObject.getPayload();
			UserAccountData accountData = null;
			try
			{
				//Check token Validity
				accountData = cacheManager.getFromCache(requestObject.getTokenId(), UserAccountData.class, MemCacheUtils.AUTHTOKENCACHE);
				
				responseObject = CommonUtils.validateRequest(accountData, requestObject, request, false);
				
				if(responseObject.getStatus() != null)
					return responseObject;
				
				otpRequest = KeyEncryptionUtils.jsonStringToObject(KeyEncryptionUtils.decryptUsingKey(accountData.getSecretKey(), payload), OtpRequest.class);
				
				responseObject = CommonUtils.validateRequestData(otpRequest, requestObject, request);
				  
				if(responseObject.getStatus() != null)
					return responseObject;
				
				  responseObject = userService.sendOtp(otpRequest);
				  
				  UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.INFO, UserServiceConstants.LOGGING_RESPONSE + UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+ UserServiceConstants.LOGGING_ACCESS_CHANNEL  + requestObject.getChannelId() + UserServiceConstants.LOGGING_REQUEST_FROM +request.getRemoteAddr() + UserServiceConstants.LOGGING_USER_ADDRESS + request.getHeader(SystemConstant.USER_IP_ADDRESS) + UserServiceConstants.LOGGING_RESPONSE +responseObject.getStatus() +  UserServiceConstants.LOGGING_RESPONSE_STRING +responseObject.getMessage());
				  
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), UserServiceConstants.PACKAGE_FOR_EXCEPTION);
			
			UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			responseObject.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseObject.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e.getMessage());
		}
		return responseObject;
	}
	
	
	@RequestMapping(value = "/logout", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	public @ResponseBody ResponseObject logoutUser(@RequestBody RequestObject requestObject, HttpServletRequest request)
	{
		ResponseObject responseObject = new ResponseObject();
		
		try
		{
		UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.INFO, UserServiceConstants.LOGGING_REQUEST + UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+" [CHANNEL_ID] "+requestObject.getChannelId()+" [TOKEN_ID] "+ requestObject.getTokenId() + UserServiceConstants.LOGGING_REQUEST_FROM +request.getRemoteAddr() + UserServiceConstants.LOGGING_USER_ADDRESS + request.getHeader(SystemConstant.USER_IP_ADDRESS));
		
		UserAccountData accountData = null;
		
			//Check token Validity
			accountData = cacheManager.getFromCache(requestObject.getTokenId(), UserAccountData.class, MemCacheUtils.AUTHTOKENCACHE);
			
			if(accountData == null)
			{
				responseObject.setStatus(ErrorCodes.AUTH_TOKEN_EXPIRED.getCode());
				responseObject.setMessage(ErrorCodes.AUTH_TOKEN_EXPIRED.getMessage());
				
				UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_RESPONSE + UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+ UserServiceConstants.LOGGING_TOKEN_STRING +requestObject.getTokenId()+ UserServiceConstants.LOGGING_ACCESS_CHANNEL  + requestObject.getChannelId() + UserServiceConstants.LOGGING_REQUEST_FROM +request.getRemoteAddr() + UserServiceConstants.LOGGING_USER_ADDRESS + request.getHeader(SystemConstant.USER_IP_ADDRESS) + UserServiceConstants.LOGGING_ERROR_CODE +responseObject.getStatus()+ UserServiceConstants.LOGGING_ERROR_MESSAGE +responseObject.getMessage());
				 
				return responseObject;
			}
		
			String cacheKey = accountData.getMobileNo() + "" + accountData.getChannelId();
			
			cacheManager.removeFromCache(cacheKey, MemCacheUtils.USERCACHE);
			cacheManager.removeFromCache(requestObject.getTokenId(), MemCacheUtils.AUTHTOKENCACHE);
		
			responseObject.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
			responseObject.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
		
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), UserServiceConstants.PACKAGE_FOR_EXCEPTION);
			
			UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			responseObject.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseObject.setMessage(ErrorCodes.REQUEST_FAILED.getMessage());
		}
		
		return responseObject;
	}
	
	
	
	@RequestMapping(value = "/deviceSignUp", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	public @ResponseBody ResponseObject signUpForDevice(@RequestBody SignUpRequest signUpRequest, HttpServletRequest request) 
	{
		ResponseObject responseObject = null;
		
		try
		{
			UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.INFO, UserServiceConstants.LOGGING_REQUEST + UserServiceConstants.LOGGING_METHOD_NAME +Thread.currentThread().getStackTrace()[1].getMethodName()+ " [ACTIVATION_CODE] " +signUpRequest.getActivationCode()+ UserServiceConstants.LOGGING_DEVICE_ID + signUpRequest.getDeviceSerialNumber() + UserServiceConstants.LOGGING_REQUEST_FROM +request.getRemoteAddr() + UserServiceConstants.LOGGING_USER_ADDRESS + request.getHeader(SystemConstant.USER_IP_ADDRESS));
		
			Set<ConstraintViolation<ValidationBean>> validationError = KeyEncryptionUtils.validateBean(signUpRequest);
		
			if(validationError != null && !validationError.isEmpty())
			{
			
				responseObject = new ResponseObject();
			
				responseObject.setStatus(ErrorCodes.REQUIRED_PARAMETERS_MISSING.getCode());
			
				String errorMessage = getErrorMessage(validationError);
			
				responseObject.setMessage(errorMessage);
		
				UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_RESPONSE + UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+ UserServiceConstants.LOGGING_ACCESS_CHANNEL  + signUpRequest.getChannelId() + UserServiceConstants.LOGGING_REQUEST_FROM +request.getRemoteAddr() + UserServiceConstants.LOGGING_USER_ADDRESS + request.getHeader(SystemConstant.USER_IP_ADDRESS) + UserServiceConstants.LOGGING_ERROR +errorMessage);
			 
				return responseObject;
			}
		
			responseObject = userService.signUpUserOnDevice(signUpRequest);
		
			UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.INFO, UserServiceConstants.LOGGING_RESPONSE + UserServiceConstants.LOGGING_METHOD_NAME + Thread.currentThread().getStackTrace()[1].getMethodName()+ UserServiceConstants.LOGGING_ACCESS_CHANNEL  + signUpRequest.getChannelId() + UserServiceConstants.LOGGING_REQUEST_FROM +request.getRemoteAddr() + UserServiceConstants.LOGGING_USER_ADDRESS + request.getHeader(SystemConstant.USER_IP_ADDRESS) +UserServiceConstants.LOGGING_RESPONSE +  responseObject.getStatus() +  UserServiceConstants.LOGGING_RESPONSE_STRING + responseObject.getMessage());
		
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), UserServiceConstants.PACKAGE_FOR_EXCEPTION);
			
			UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
		}
		
		return responseObject;
	}
	
	@RequestMapping(value = "/getActivationCode", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	public @ResponseBody ResponseObject getActivationCode(@RequestBody ActivationCodeRequest activationRequest, HttpServletRequest request) 
	{
		ResponseObject responseObject = null;
		try
		{
			UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.INFO, UserServiceConstants.LOGGING_REQUEST + UserServiceConstants.LOGGING_METHOD_NAME +Thread.currentThread().getStackTrace()[1].getMethodName() + " [USER_MSISDN] " + activationRequest.getUserMsisdn() + " [SKU_ID] " + activationRequest.getSkuId() + UserServiceConstants.LOGGING_REQUEST_FROM +request.getRemoteAddr() + UserServiceConstants.LOGGING_USER_ADDRESS + request.getHeader(SystemConstant.USER_IP_ADDRESS));
		
			Set<ConstraintViolation<ValidationBean>> validationError = KeyEncryptionUtils.validateBean(activationRequest);
		
			if(validationError != null && !validationError.isEmpty())
			{
			
				responseObject = new ResponseObject();
			
				responseObject.setStatus(ErrorCodes.REQUIRED_PARAMETERS_MISSING.getCode());
			
				String errorMessage = getErrorMessage(validationError);
			
				responseObject.setMessage(errorMessage);
		
				UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_RESPONSE + UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+ UserServiceConstants.LOGGING_ACCESS_CHANNEL  + activationRequest.getChannelId() + UserServiceConstants.LOGGING_REQUEST_FROM +request.getRemoteAddr() + UserServiceConstants.LOGGING_USER_ADDRESS + request.getHeader(SystemConstant.USER_IP_ADDRESS) + UserServiceConstants.LOGGING_ERROR +errorMessage);
			 
				return responseObject;
			}
		
			responseObject = userService.getActivationCode(activationRequest);
		
			UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.INFO, UserServiceConstants.LOGGING_RESPONSE + UserServiceConstants.LOGGING_METHOD_NAME + Thread.currentThread().getStackTrace()[1].getMethodName()+ UserServiceConstants.LOGGING_REQUEST_FROM +request.getRemoteAddr() + UserServiceConstants.LOGGING_USER_ADDRESS + request.getHeader(SystemConstant.USER_IP_ADDRESS) +UserServiceConstants.LOGGING_RESPONSE +  responseObject.getStatus() +  UserServiceConstants.LOGGING_RESPONSE_STRING + responseObject.getMessage());
		
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), UserServiceConstants.PACKAGE_FOR_EXCEPTION);
			
			UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
		}
		
		return responseObject;
	}

	@RequestMapping(value = "/subscriberProfile", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	public @ResponseBody ResponseObject getSubscriberProfile(@RequestBody RequestObject requestObject, HttpServletRequest request) 
	{
		UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.INFO, UserServiceConstants.LOGGING_REQUEST + UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+ UserServiceConstants.LOGGING_TOKEN_STRING +requestObject.getTokenId()+ UserServiceConstants.LOGGING_ACCESS_CHANNEL  + requestObject.getChannelId() + UserServiceConstants.LOGGING_REQUEST_FROM +request.getRemoteAddr() + UserServiceConstants.LOGGING_USER_ADDRESS + request.getHeader(SystemConstant.USER_IP_ADDRESS));
			
		ResponseObject responseObject = new ResponseObject();
			
			/* 
			 * Get Agent details from tokenId
			 * requestObject.getTokenId()
			 * 
			 */
		
		UserAccountData accountData = null;
		try
		{
			//Check token Validity
			accountData = cacheManager.getFromCache(requestObject.getTokenId(), UserAccountData.class, MemCacheUtils.AUTHTOKENCACHE);
			
			responseObject = CommonUtils.validateRequest(accountData, requestObject, request, false);
			
			if(responseObject.getStatus() != null)
				return responseObject;
			
			responseObject = userService.getUserProfile(accountData);
			  
			UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.INFO, UserServiceConstants.LOGGING_RESPONSE + UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+ UserServiceConstants.LOGGING_ACCESS_CHANNEL  + requestObject.getChannelId() + UserServiceConstants.LOGGING_REQUEST_FROM +request.getRemoteAddr() + UserServiceConstants.LOGGING_USER_ADDRESS + request.getHeader(SystemConstant.USER_IP_ADDRESS) + UserServiceConstants.LOGGING_RESPONSE +responseObject.getStatus() +  UserServiceConstants.LOGGING_RESPONSE_STRING +responseObject.getMessage());
				  
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), UserServiceConstants.PACKAGE_FOR_EXCEPTION);
			
			UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			responseObject.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseObject.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e.getMessage());
		}
		return responseObject;
	}
	
	
	@RequestMapping(value = "/uploadProfileImage", method = RequestMethod.POST, produces="application/json", headers=("content-type=multipart/*"))
	public @ResponseBody ResponseObject uploadProfileImage(@RequestParam("file") MultipartFile uploadedFile,@RequestParam("tokenId") String tokenId, HttpServletRequest request) 
	{
		UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.INFO, UserServiceConstants.LOGGING_REQUEST + UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+ UserServiceConstants.LOGGING_TOKEN_STRING +tokenId+ UserServiceConstants.LOGGING_REQUEST_FROM +request.getRemoteAddr() + UserServiceConstants.LOGGING_USER_ADDRESS + request.getHeader(SystemConstant.USER_IP_ADDRESS));
			
		ResponseObject responseObject = new ResponseObject();
			
		//Object payload = requestObject.getPayload();
		UserAccountData accountData = null;
		
		
		try
		{
			//Check token Validity
			accountData = cacheManager.getFromCache(tokenId, UserAccountData.class, MemCacheUtils.AUTHTOKENCACHE);
			
			if(accountData == null)
			{
				responseObject.setStatus(ErrorCodes.AUTH_TOKEN_EXPIRED.getCode());
				responseObject.setMessage(ErrorCodes.AUTH_TOKEN_EXPIRED.getMessage());
				
				UserServiceLogger.log(CommonUtils.class.getSimpleName(), UserServiceLogger.ERROR,  UserServiceConstants.LOGGING_RESPONSE  + UserServiceConstants.LOGGING_METHOD_NAME +Thread.currentThread().getStackTrace()[1].getMethodName()+ UserServiceConstants.LOGGING_TOKEN_STRING +tokenId+ UserServiceConstants.LOGGING_REQUEST_FROM +request.getRemoteAddr() + UserServiceConstants.LOGGING_ERROR_CODE +responseObject.getStatus()+UserServiceConstants.LOGGING_ERROR_MESSAGE +responseObject.getMessage());
				 
				return responseObject;
			}
			
			if(uploadedFile == null || uploadedFile.getBytes() == null || uploadedFile.getBytes().length <= 0)
			{
				responseObject.setStatus(ErrorCodes.INVALID_REQUEST.getCode());
				responseObject.setMessage(ErrorCodes.INVALID_REQUEST.getMessage());
			}
			
			responseObject = userService.saveUpdateProfileImage(uploadedFile, accountData);
			  
			
			  
			UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.INFO, UserServiceConstants.LOGGING_RESPONSE + UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+ UserServiceConstants.LOGGING_REQUEST_FROM +request.getRemoteAddr() + UserServiceConstants.LOGGING_USER_ADDRESS + request.getHeader(SystemConstant.USER_IP_ADDRESS) + UserServiceConstants.LOGGING_RESPONSE +responseObject.getStatus() +  UserServiceConstants.LOGGING_RESPONSE_STRING +responseObject.getMessage());
				  
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), UserServiceConstants.PACKAGE_FOR_EXCEPTION);
			
			UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			responseObject.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseObject.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e.getMessage());
		}
		return responseObject;
	}
}