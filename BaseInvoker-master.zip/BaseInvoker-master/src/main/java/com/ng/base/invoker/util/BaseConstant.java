package com.ng.base.invoker.util;
public class BaseConstant {


	
	public static final String CONTENTTYPE= "Content-Type";
	public static final String TRANSACTIONID  = "TransactionId ";
	private BaseConstant(){}
	
}