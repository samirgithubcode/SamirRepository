package com.ng.sb.common.dataobject;

import java.io.Serializable;

public class HostRangeFeeConfigurationData implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Double startRange;
	private Double endRange;
	private Double amount;
	
	public Double getStartRange() {
		return startRange;
	}
	public void setStartRange(Double startRange) {
		this.startRange = startRange;
	}
	public Double getEndRange() {
		return endRange;
	}
	public void setEndRange(Double endRange) {
		this.endRange = endRange;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
}
