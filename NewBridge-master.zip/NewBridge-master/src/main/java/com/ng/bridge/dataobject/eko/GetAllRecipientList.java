package com.ng.bridge.dataobject.eko;

public class GetAllRecipientList {
	 private String recipientIdtype;

	    private String recipientId;

	    private String account;

	    private String ifscStatus;

	    private String bank;

	    private String recipientMobile;

	    private String recipientName;

	    private String channel;

	    private String ifsc;

	    public String getRecipientIdType ()
	    {
	        return recipientIdtype;
	    }

	    public void setRecipientIdType (String recipientIdtype)
	    {
	        this.recipientIdtype = recipientIdtype;
	    }

	    public String getRecipientId ()
	    {
	        return recipientId;
	    }

	    public void setRecipientId (String recipientId)
	    {
	        this.recipientId = recipientId;
	    }

	    public String getAccount ()
	    {
	        return account;
	    }

	    public void setAccount (String account)
	    {
	        this.account = account;
	    }

	    public String getIfscStatus ()
	    {
	        return ifscStatus;
	    }

	    public void setIfscStatus (String ifscStatus)
	    {
	        this.ifscStatus = ifscStatus;
	    }

	    public String getBank ()
	    {
	        return bank;
	    }

	    public void setBank (String bank)
	    {
	        this.bank = bank;
	    }

	    public String getRecipientMobile ()
	    {
	        return recipientMobile;
	    }

	    public void setRecipientMobile (String recipientMobile)
	    {
	        this.recipientMobile = recipientMobile;
	    }

	    public String getRecipientName ()
	    {
	        return recipientName;
	    }

	    public void setRecipientName (String recipientName)
	    {
	        this.recipientName = recipientName;
	    }

	    public String getChannel ()
	    {
	        return channel;
	    }

	    public void setChannel (String channel)
	    {
	        this.channel = channel;
	    }

	    public String getIfsc ()
	    {
	        return ifsc;
	    }

	    public void setIfsc (String ifsc)
	    {
	        this.ifsc = ifsc;
	    }

	    @Override
	    public String toString()
	    {
	        return "ClassPojo [recipient_id_type = "+recipientIdtype+", recipient_id = "+recipientId+", account = "+account+", ifsc_status = "+ifscStatus+", bank = "+bank+", recipient_mobile = "+recipientMobile+", recipient_name = "+recipientName+", channel = "+channel+", ifsc = "+ifsc+"]";
	    }
}
