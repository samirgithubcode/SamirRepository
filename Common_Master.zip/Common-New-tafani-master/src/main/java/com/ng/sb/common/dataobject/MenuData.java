package com.ng.sb.common.dataobject;

import java.util.List;

public class MenuData  extends BaseObjectData{

	private static final long serialVersionUID = 1L;
	private String menuName;
	private List<SubMenuData> subMenuName;
	
	public String getMenuName() {
		return menuName;
	}
	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}
	public List<SubMenuData> getSubMenuName() {
		return subMenuName;
	}
	public void setSubMenuName(List<SubMenuData> subMenuName) {
		this.subMenuName = subMenuName;
	}
}
