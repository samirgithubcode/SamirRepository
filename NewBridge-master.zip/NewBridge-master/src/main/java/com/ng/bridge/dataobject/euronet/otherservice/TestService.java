package com.ng.bridge.dataobject.euronet.otherservice;

import java.rmi.RemoteException;

import javax.xml.rpc.ServiceException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class TestService {
	private static final Logger LOGGER = LoggerFactory.getLogger(TestService.class);
	private TestService() {
		
	} 
	
	static{
		 System.setProperty("org.apache.commons.logging.Log", "org.apache.commons.logging.impl.Log4JLogger");
		  System.setProperty("org.apache.commons.logging.LogFactory", "org.apache.commons.logging.impl.LogFactoryImpl");
	}
	public static void main(String[] args) {
		Service1Locator service = new Service1Locator();
		service.setBasicHttpBindingIService1EndpointAddress("https://invas01.euronetworldwide.com/Eurovas2Client/ART/Service1.svc");
		String response = null;
	
		
		String request ="requesttype=service&merchantrefno=adwsssd&merchantcode=NGT&username=NGT_01&userpass=NGT_01"+
						"&paymentprovider=NGT&paymentmode=CA&channelcode=INR&servicecode=MR&storecode=NGT_01&terminalc"+
						"ode=NGT_01&customerid=NGT_11111&tcflag=1&optional1=default&optional2=&optional3=&optional4=&optional5"+
						"=&consumerno=9930310679&amount=20&spcode=VOD";	
		
		try {
			response = service.getBasicHttpBindingIService1().sendEuroVasRequest(request);
			LOGGER.info(response);
		} catch (RemoteException | ServiceException e) {
			LOGGER.info(""+e);
		}

	}
}
