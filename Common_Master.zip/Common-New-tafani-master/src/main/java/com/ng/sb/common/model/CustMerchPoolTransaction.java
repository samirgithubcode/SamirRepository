package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "custMerchPoolTransaction")
@NamedQueries({ @NamedQuery(name = "CustMerchPoolTransaction.findAll", query = "SELECT c FROM CustMerchPoolTransaction c"),

})
public class CustMerchPoolTransaction implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(unique = true)
	private Integer id;

	@Column(name = "netAmount")
	private Integer netAmount;
	@Column(name = "status")
	private String status;

	@Column(name = "grossAmount")
	private Integer grossAmount;

	@Column(name = "updationDate")
	@Temporal(TemporalType.DATE)
	private Date updationDate;

	public CustMerchPoolTransaction() {
		// empty
	}

	public CustMerchPoolTransaction(Integer id) {
		this.id = id;
	}

	public Integer getNetAmount() {
		return netAmount;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setNetAmount(Integer netAmount) {
		this.netAmount = netAmount;
	}

	public Integer getGrossAmount() {
		return grossAmount;
	}

	public void setGrossAmount(Integer grossAmount) {
		this.grossAmount = grossAmount;
	}

	public Date getUpdationDate() {
		return updationDate;
	}

	public void setUpdationDate(Date updationDate) {
		this.updationDate = updationDate;
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
}
