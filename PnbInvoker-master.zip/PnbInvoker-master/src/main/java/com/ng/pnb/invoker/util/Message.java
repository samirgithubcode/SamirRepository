package com.ng.pnb.invoker.util;

public class Message {

	private String message_TYPE = null;
    private String messageCode = null;
    private String messageDesc = null;
    
	public String getMessage_TYPE() {
		return message_TYPE;
	}
	
	public void setMessage_TYPE(String message_TYPE) {
		this.message_TYPE = message_TYPE;
	}
	
	public String getMessageCode() {
		return messageCode;
	}
	
	public void setMessageCode(String messageCode) {
		this.messageCode = messageCode;
	}
	
	public String getMessageDesc() {
		return messageDesc;
	}
	
	public void setMessageDesc(String messageDesc) {
		this.messageDesc = messageDesc;
	}

	@Override
	public String toString() {
		return "Message [message_TYPE=" + message_TYPE + ", messageCode="
				+ messageCode + ", messageDesc=" + messageDesc + "]";
	}
    
}
