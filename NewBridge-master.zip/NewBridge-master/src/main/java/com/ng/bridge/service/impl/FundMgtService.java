/**
 * 
 */
package com.ng.bridge.service.impl;

import org.springframework.stereotype.Service;

import com.ng.bridge.service.IFundMgtService;
import com.ng.sb.common.util.SystemConstant;

/**
 * @author gaurav
 *
 */
@Service(value=SystemConstant.BRIDGE_FUND_MGT_SERVICE)
public class FundMgtService extends BridgeService implements IFundMgtService {
	public String getDeplyementType(){
		return null;
	}
}
