package com.ng.transaction.util;

import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SealedObject;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import com.ng.transaction.dto.sbi.CustomerRegistrationRequestDTO;

public class CryptoUtil {
	public String AESEncryption(CustomerRegistrationRequestDTO dto) throws Exception {
		KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
        keyGenerator.init(256);
        
        SecretKey key = keyGenerator.generateKey();
     
        byte[] IV = new byte[16];
        SecureRandom random = new SecureRandom();
        random.nextBytes(IV);
                
        byte[] cipherText = encrypt(dto, key, IV);
        System.out.println("Encrypted Text : "+Base64.getEncoder().encodeToString(cipherText));
        return Base64.getEncoder().encodeToString(cipherText);
	}
	
	public void AESDecryption(byte[] cipherText) throws Exception {
		KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
        keyGenerator.init(256);
        
        SecretKey key = keyGenerator.generateKey();
     
        byte[] IV = new byte[16];
        SecureRandom random = new SecureRandom();
        random.nextBytes(IV);
                
        String decryptedText = decrypt(cipherText,key, IV);
        System.out.println("DeCrypted Text : "+decryptedText);
	}
	
	public static byte[] encrypt (CustomerRegistrationRequestDTO dto,SecretKey key,byte[] IV ) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");        
        SecretKeySpec keySpec = new SecretKeySpec(key.getEncoded(), "AES");
        IvParameterSpec ivSpec = new IvParameterSpec(IV);
        cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivSpec);
        SealedObject so = new SealedObject(dto,cipher);
        
        byte[] cipherText = cipher.doFinal(so.toString().getBytes());
        
        return cipherText;
    }
    
    public static String decrypt (byte[] cipherText, SecretKey key,byte[] IV) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        SecretKeySpec keySpec = new SecretKeySpec(key.getEncoded(), "AES");
        IvParameterSpec ivSpec = new IvParameterSpec(IV);
        cipher.init(Cipher.DECRYPT_MODE, keySpec, ivSpec);
        byte[] decryptedText = cipher.doFinal(cipherText);
        
        return new String(decryptedText);
    }
    
    // Used for encrypting secret key.
    // Param1: secret key
    // Param2: public key shared by sbi for encrypting secret key
    public byte[] RSAEncryption(String data, String publicKey) throws Exception {
    	Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
    	cipher.init(Cipher.ENCRYPT_MODE, getPublicKey(publicKey));
    	return cipher.doFinal(data.getBytes());
    }
    
    public static PublicKey getPublicKey(String base64PublicKey){
        PublicKey publicKey = null;
        try{
            X509EncodedKeySpec keySpec = new X509EncodedKeySpec(Base64.getDecoder().decode(base64PublicKey.getBytes()));
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            publicKey = keyFactory.generatePublic(keySpec);
            return publicKey;
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (InvalidKeySpecException e) {
            e.printStackTrace();
        }
        return publicKey;
    }
}
