package com.ng.sb.common.dataobject;

import java.util.Map;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;

import com.fasterxml.jackson.annotation.JsonProperty;


public class WalletRequest implements ValidationBean {
	private static final long serialVersionUID = 1L;
	private Integer channelId;
	private int accessChannel;
	private String userMobile;
	private String fullName;
	private String emailId;
	private String customerId;
	private Integer agentId;
	private Integer agentCompanyId;
	private Integer otp;
	private String amount;
	private String commAmount ="0.00";
	@JsonProperty("wallet_type_id")
	private Integer[] walletTypeId;
	private String service;
	@Length(min=6, max=6) 
	@Pattern(regexp="[0-9]+")
	private String wPin;
	@JsonProperty("wallet_id")
	private Integer walletId;// for topup
	private Integer bankId;
	private String token;
	private String openingBalance; 
	private String closingBalance;
	private Long refTxnId;
	private Long refTxnRefundId;
	private String transactionType;
	private String fromDate;
	private String consumptionType;
	private Integer transactionQuantity;
	private String toDate;
	private Map<Integer,Integer> rechargeAmountOnCreation;
	private boolean isSelfCare;
	private Wallet txnResponse;
	private WalletResponse walletResponse;
	private String source;
	private String creationDate;
	private String creationTime;
	private String walletbalance;
	private transient Object payload;
	private String message;
	private String agentMobile;
	private String deviceId;
	
	public String getAgentMobile() {
		return agentMobile;
	}
	public void setAgentMobile(String agentMobile) {
		this.agentMobile = agentMobile;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}

	
	
	public Wallet getTxnResponse() {
		return txnResponse;
	}
	public void setTxnResponse(Wallet txnResponse) {
		this.txnResponse = txnResponse;
	}
	public WalletResponse getWalletResponse() {
		return walletResponse;
	}
	public void setWalletResponse(WalletResponse walletResponse) {
		this.walletResponse = walletResponse;
	}
	public Object getPayload() {
		return payload;
	}
	public void setPayload(Object payload) {
		this.payload = payload;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}

	public boolean isSelfCare() {
		return isSelfCare;
	}
	public void setSelfCare(boolean isSelfCare) {
		this.isSelfCare = isSelfCare;
	}

	public Map<Integer, Integer> getRechargeAmountOnCreation() {
		return rechargeAmountOnCreation;
	}
	public void setRechargeAmountOnCreation(Map<Integer, Integer> rechargeAmountOnCreation) {
		this.rechargeAmountOnCreation = rechargeAmountOnCreation;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public Integer getChannelId() {
		return channelId;
	}
	public void setChannelId(Integer channelId) {
		this.channelId = channelId;
	}
	public String getClosingBalance() {
		return closingBalance;
	}
	public void setClosingBalance(String closingBalance) {
		this.closingBalance = closingBalance;
	}
	
	public int getAccessChannel() {
		return accessChannel;
	}
	public void setAccessChannel(int accessChannel) {
		this.accessChannel = accessChannel;
	}
	public String getUserMobile() {
		return userMobile;
	}
	public void setUserMobile(String userMobile) {
		this.userMobile = userMobile;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public Integer getAgentId() {
		return agentId;
	}
	public void setAgentId(Integer agentId) {
		this.agentId = agentId;
	}
	public Integer getOtp() {
		return otp;
	}
	public void setOtp(Integer otp) {
		this.otp = otp;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public Integer[] getWalletTypeId() {
		return walletTypeId;
	}
	public void setWalletTypeId(Integer[] walletTypeId) {
		this.walletTypeId = walletTypeId;
	}
	public String getService() {
		return service;
	}
	public void setService(String service) {
		this.service = service;
	}
	public String getwPin() {
		return wPin;
	}
	public void setwPin(String wPin) {
		this.wPin = wPin;
	}
	public Integer getWalletId() {
		return walletId;
	}
	public void setWalletId(Integer walletId) {
		this.walletId = walletId;
	}
	public Integer getBankId() {
		return bankId;
	}
	public void setBankId(Integer bankId) {
		this.bankId = bankId;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public String getOpeningBalance() {
		return openingBalance;
	}
	public void setOpeningBalance(String openingBalance) {
		this.openingBalance = openingBalance;
	}
	public Long getRefTxnId() {
		return refTxnId;
	}
	public void setRefTxnId(Long refTxnId) {
		this.refTxnId = refTxnId;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	
	public String getConsumptionType() {
		return consumptionType;
	}
	public void setConsumptionType(String consumptionType) {
		this.consumptionType = consumptionType;
	}
	public Integer getTransactionQuantity() {
		return transactionQuantity;
	}
	public void setTransactionQuantity(Integer transactionQuantity) {
		this.transactionQuantity = transactionQuantity;
	}
	public String getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}
	public String getCreationTime() {
		return creationTime;
	}
	public void setCreationTime(String creationTime) {
		this.creationTime = creationTime;
	}
	
	public String getWalletbalance() {
		return walletbalance;
	}
	public void setWalletbalance(String walletbalance) {
		this.walletbalance = walletbalance;
	}
	public Integer getAgentCompanyId() {
		return agentCompanyId;
	}
	public void setAgentCompanyId(Integer agentCompanyId) {
		this.agentCompanyId = agentCompanyId;
	}
	public Long getRefTxnRefundId() {
		return refTxnRefundId;
	}
	public void setRefTxnRefundId(Long refTxnRefundId) {
		this.refTxnRefundId = refTxnRefundId;
	}
	public String getCommAmount() {
		return commAmount;
	}
	public void setCommAmount(String commAmount) {
		this.commAmount = commAmount;
	}
	public String getDeviceId() {
		return deviceId;
	}
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	
}
