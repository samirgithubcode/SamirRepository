/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "OTAServiceConfigMapping")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "OTAServiceConfigMapping.findAll", query = "SELECT o FROM OTAServiceConfigMapping o"),
    @NamedQuery(name = "OTAServiceConfigMapping.findById", query = "SELECT o FROM OTAServiceConfigMapping o WHERE o.id = :id"),
    @NamedQuery(name = "OTAServiceConfigMapping.findBySIdOtaId", query = "SELECT o FROM OTAServiceConfigMapping o WHERE o.serviceConfigId = :serviceConfigId AND o.otaMgmtId = :otaMgmtId")})
public class OTAServiceConfigMapping implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "serviceStatus")
    private boolean serviceStatus;
    @JoinColumn(name = "serviceConfigId", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private ServiceConfig serviceConfigId;
    @JoinColumn(name = "otaMgmtId", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private OTAManagement otaMgmtId;

    public OTAServiceConfigMapping() { 
    	//empty
    }

    public OTAServiceConfigMapping(Integer id) {
        this.id = id;
    }

    public OTAServiceConfigMapping(Integer id, boolean serviceStatus) {
        this.id = id;
        this.serviceStatus = serviceStatus;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public boolean getServiceStatus() {
        return serviceStatus;
    }

    public void setServiceStatus(boolean serviceStatus) {
        this.serviceStatus = serviceStatus;
    }

    public ServiceConfig getServiceConfigId() {
        return serviceConfigId;
    }

    public void setServiceConfigId(ServiceConfig serviceConfigId) {
        this.serviceConfigId = serviceConfigId;
    }

   

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }
    
    public OTAManagement getOtaMgmtId() {
        return otaMgmtId;
    }

    public void setOtaMgmtId(OTAManagement otaMgmtId) {
        this.otaMgmtId = otaMgmtId;
    }

    @Override
    public boolean equals(Object object) {
    	boolean check=true;
    	if(object!=null)
    	{
        if (!(object instanceof OTAServiceConfigMapping)) {
        	check= false;
        }
        OTAServiceConfigMapping other = (OTAServiceConfigMapping) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
    	}
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.OTAServiceConfigMapping[ id=" + id + " ]";
    }
    
}
