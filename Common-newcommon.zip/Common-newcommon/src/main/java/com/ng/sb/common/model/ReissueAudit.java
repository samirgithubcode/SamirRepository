package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="reissueaudit")
@NamedQueries({ @NamedQuery(name = "ReissueAudit.findAll", query = "SELECT r FROM ReissueAudit r"),
@NamedQuery(name="ReissueAudit.customerMSISDN", query="SELECT r FROM ReissueAudit r where r.customerMSISDN= :customerMSISDN"),

})

public class ReissueAudit implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	@Column(name = "customerMSISDN")
	private String customerMSISDN;
	
	
	@Column(name="oldExternalNo")
	private String oldExternalNo;
	
	/*
	 * @Column(name = "newExternalNo") private String newExternalNo;
	 */
	
	@Column(name="resionCode")
	private String resionCode;
	
	@Column(name="remarks")
	private String remarks;
	
	@Column(name="status")
	private String status;
	
	@Column(name = "addedOn")
    @Temporal(TemporalType.TIMESTAMP)    
    private Date addedOn=new Date();;
	
	 
	public ReissueAudit() {
		
	}
	

	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCustomerMSISDN() {
		return customerMSISDN;
	}

	public void setCustomerMSISDN(String customerMSISDN) {
		this.customerMSISDN = customerMSISDN;
	}

	public String getOldExternalNo() {
		return oldExternalNo;
	}

	public void setOldExternalNo(String oldExternalNo) {
		this.oldExternalNo = oldExternalNo;
	}

	public String getResionCode() {
		return resionCode;
	}

	public void setResionCode(String resionCode) {
		this.resionCode = resionCode;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Date getAddedOn() {
		return addedOn;
	}

	public void setAddedOn(Date addedOn) {
		this.addedOn = addedOn;
	}

	/*
	 * public String getNewExternalNo() { return newExternalNo; }
	 * 
	 * public void setNewExternalNo(String newExternalNo) { this.newExternalNo =
	 * newExternalNo; }
	 */
	
	
	
	

}
