/**
 * 
 */
package com.ng.bridge.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ng.bridge.dao.ICustomerDAO;
import com.ng.bridge.service.ICustomerService;
import com.ng.sb.common.dataobject.BridgeDataObject;
import com.ng.sb.common.model.ThirdPartySubsRecipient;
import com.ng.sb.common.model.ThirdPartySubscriber;
import com.ng.sb.common.util.SystemConstant;

/**
 * @author ram
 *
 */
@Service(value=SystemConstant.CUSTOMER_SERVICE)
public class CustomerService implements ICustomerService {
	private static final Logger LOGGER = LoggerFactory.getLogger(CustomerService.class);
	@Autowired
	ICustomerDAO customerDAO;
	
	@Override
	public ThirdPartySubscriber checkMobileNumber(BridgeDataObject bridgeDataObject){
		ThirdPartySubscriber tps=null;
		try {
			tps=customerDAO.checkMobileNumber(bridgeDataObject.getPayeeBankAccount().getMsisdn(), bridgeDataObject.getPayerWallet().getId());
		} catch (Exception e) {
			LOGGER.info(" "+e);
		}
		return tps;
	}
	
	@Override
	public ThirdPartySubsRecipient checkRecipient(BridgeDataObject bridgeDataObject,int tpsId){
		ThirdPartySubsRecipient recipient=null;
		try {
			recipient=customerDAO.getRecipient(tpsId,bridgeDataObject.getPayeeBankAccount().getAccountNumber(), bridgeDataObject.getPayeeBankAccount().getIfscCode());		
		} catch (Exception e) {
			LOGGER.info(" "+e);
		}
		return recipient;
	}
	
	
}
