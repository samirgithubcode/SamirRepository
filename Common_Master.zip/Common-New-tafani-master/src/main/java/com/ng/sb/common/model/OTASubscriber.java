/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "OTASubscriber")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "OTASubscriber.findAll", query = "SELECT o FROM OTASubscriber o"),
    @NamedQuery(name = "OTASubscriber.findById", query = "SELECT o FROM OTASubscriber o WHERE o.id = :id"),
    @NamedQuery(name = "OTASubscriber.findByOtaDate", query = "SELECT o FROM OTASubscriber o WHERE o.otaDate = :otaDate")})
public class OTASubscriber implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "otaDate")
    @Temporal(TemporalType.TIME)
    private Date otaDate;
    @JoinColumn(name = "subscriberId", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Subscriber subscriberId;
    @JoinColumn(name = "otaMgmtId", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private OTAManagement otaMgmtId;

    public OTASubscriber() {
    	//default constructor
    }

    public OTASubscriber(Integer id) {
        this.id = id;
    }

    public OTASubscriber(Integer id, Date otaDate) {
        this.id = id;
        this.otaDate = otaDate;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getOtaDate() {
        return otaDate;
    }

    public void setOtaDate(Date otaDate) {
        this.otaDate = otaDate;
    }

    public Subscriber getSubscriberId() {
        return subscriberId;
    }

    public void setSubscriberId(Subscriber subscriberId) {
        this.subscriberId = subscriberId;
    }

    public OTAManagement getOtaMgmtId() {
        return otaMgmtId;
    }

    public void setOtaMgmtId(OTAManagement otaMgmtId) {
        this.otaMgmtId = otaMgmtId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof OTASubscriber)) {
            return false;
        }
        OTASubscriber other = (OTASubscriber) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.OTASubscriber[ id=" + id + " ]";
    }
    
}
