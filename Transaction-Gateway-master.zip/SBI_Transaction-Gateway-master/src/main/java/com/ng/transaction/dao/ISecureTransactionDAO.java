package com.ng.transaction.dao;

import java.util.List;

import com.ng.sb.common.dataobject.OverlayIssuance;
import com.ng.sb.common.model.AccountInfo;
import com.ng.sb.common.model.CustMerchFinInstMapping;
import com.ng.sb.common.model.CustomerAccountHistory;
import com.ng.sb.common.model.CustomerDetails;
import com.ng.sb.common.model.HostSubVersion;
import com.ng.sb.common.model.InventoryMgmt;
import com.ng.sb.common.model.MasterVersion;
import com.ng.sb.common.model.MerchantInfo;
import com.ng.sb.common.model.Partner;
import com.ng.sb.common.model.Provider;
import com.ng.sb.common.model.Subscriber;
import com.ng.sb.common.model.TransactionSecureService;
public interface ISecureTransactionDAO extends ITransactionDAO 
{
	public void saveTransactionServiceData(TransactionSecureService securerTansactionService) throws Exception;
	public TransactionSecureService updateTransactionServiceData(TransactionSecureService securerTansactionService) throws Exception;
	public MerchantInfo checkKey(String key) throws Exception;
	public CustMerchFinInstMapping getPayeeDetails(String walletId,Partner wId) throws Exception;
	public Partner checkWalletStatus(Integer walletCode) throws Exception;
	public CustMerchFinInstMapping updateCustMerch(CustMerchFinInstMapping custMerchFinInstMapping) throws Exception;
	public Provider findProviderByCode(Integer providerCode) throws Exception;
	public CustMerchFinInstMapping getPayerDetails(Partner wId) throws Exception;
	
	public InventoryMgmt fetchInventoryDetails(String overlayExternalNumber) throws Exception;
	public Subscriber fetchSubscriberDetails(String customerMsisdn) throws Exception;
	
	public boolean updateSubscriber(Subscriber subscriber) throws Exception;
	public boolean updateInventory(InventoryMgmt inventory) throws Exception;
	
	public HostSubVersion getHostSubVersion(MasterVersion masterVersionId, AccountInfo hostId)  throws Exception;
	
	public boolean addCustomerDetails(CustomerDetails customerDetails) throws Exception;

	public Subscriber fetchSubscriberDetailsByCustId(String customerId) throws Exception;
	
	public List<OverlayIssuance> fetchIssuedList(OverlayIssuance overlayIssuanceData) throws Exception;
	public boolean updateEntity(Object entityObject) throws Exception;
	public boolean addEntity(Object entityObject) throws Exception;
	public CustomerDetails fetchCustomerAccountDetails(String customerId, String accountNumber, String bankId) throws Exception;
	
	public Subscriber fetchSubscriberDetails(String customerMsisdn, String customerId) throws Exception;
	
	public List<CustomerAccountHistory> fetchSubscriberAccountDetails(String bankId, String customerId, String customerMsisdn) throws Exception;
	
	public boolean isValidIfscCodeBankMapping(String ifscCode, String bankId) throws Exception;
		
	public List<CustomerDetails> fetchCustomerDetailsByMsisdn(String msisdn) throws Exception;
	
	public boolean removeObject(Object objectEntity) throws Exception;
	
	public List<InventoryMgmt> fetchInventoryDetailsByMsisdn(String msisdn) throws Exception;
	
}
