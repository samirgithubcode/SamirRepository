/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "walletTransaction")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "WalletTransaction.findAll", query = "SELECT w FROM WalletTransaction w"),
    @NamedQuery(name = "WalletTransaction.findById", query = "SELECT w FROM WalletTransaction w WHERE w.id = :id"),
    @NamedQuery(name = "WalletTransaction.findByMsisdn", query = "SELECT w FROM WalletTransaction w WHERE w.msisdn = :msisdn"),
    @NamedQuery(name = "WalletTransaction.findByTxnId", query = "SELECT w FROM WalletTransaction w WHERE w.txnId = :txnId"),
    @NamedQuery(name = "WalletTransaction.findByBalBeforTxn", query = "SELECT w FROM WalletTransaction w WHERE w.balBeforTxn = :balBeforTxn"),
    @NamedQuery(name = "WalletTransaction.findByBalAfterTxn", query = "SELECT w FROM WalletTransaction w WHERE w.balAfterTxn = :balAfterTxn"),
    @NamedQuery(name = "WalletTransaction.findByDate", query = "SELECT w FROM WalletTransaction w WHERE w.date = :date")})
public class WalletTransaction implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
    @Basic(optional = false)
    @Column(name = "msisdn", nullable = false, length = 25)
    private String msisdn;
    @Column(name = "txnId", length = 25)
    private String txnId;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "balBeforTxn", precision = 12)
    private Float balBeforTxn;
    @Column(name = "balAfterTxn", precision = 12)
    private Float balAfterTxn;
    @Basic(optional = false)
    @Column(name = "date", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date date;
    @JoinColumn(name = "userId", referencedColumnName = "id", nullable = false)
    @ManyToOne(optional = false)
    private Subscriber userId;

    public WalletTransaction() {
    	//default constructor
    }

    public WalletTransaction(Integer id) {
        this.id = id;
    }

    public WalletTransaction(Integer id, String msisdn, Date date) {
        this.id = id;
        this.msisdn = msisdn;
        this.date = date;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMsisdn() {
        return msisdn;
    }

    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }

    public String getTxnId() {
        return txnId;
    }

    public void setTxnId(String txnId) {
        this.txnId = txnId;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
    
    public Float getBalBeforTxn() {
        return balBeforTxn;
    }

    public void setBalBeforTxn(Float balBeforTxn) {
        this.balBeforTxn = balBeforTxn;
    }

    public Float getBalAfterTxn() {
        return balAfterTxn;
    }

    public void setBalAfterTxn(Float balAfterTxn) {
        this.balAfterTxn = balAfterTxn;
    }

   

    public Subscriber getUserId() {
        return userId;
    }

    public void setUserId(Subscriber userId) {
        this.userId = userId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof WalletTransaction)) {
            return false;
        }
        WalletTransaction other = (WalletTransaction) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.WalletTransaction[ id=" + id + " ]";
    }
    
}
