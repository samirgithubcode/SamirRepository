package com.ng.sb.common.exception;
/**
 * @author gaurav
 * Exceptions for Banking Services
 */
public class BankingException extends Exception {
	private static final long serialVersionUID = 1L;
	
	public BankingException(String message){
		super(message);
	}
}