package com.ng.sb.common.dataobject;

public class CentralWarehouseInfoData extends BaseObjectData {

	private static final long serialVersionUID = 1L;
	private WareHouseDetails wareHouseDetails;
	public WareHouseDetails getWareHouseDetails() {
		return wareHouseDetails;
	}
	public void setWareHouseDetails(WareHouseDetails wareHouseDetails) {
		this.wareHouseDetails = wareHouseDetails;
	}

}
