package com.ng.sc.service.impl;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ng.sb.common.model.Country;
import com.ng.sb.common.model.State;
import com.ng.sb.common.service.impl.SuperParentService;
import com.ng.sb.common.util.SystemConstant;
import com.ng.sc.dao.ISelfCareDAO;
import com.ng.sc.service.ISelfCareService;
import com.ng.sc.service.impl.SelfCareService;

/**
 * 
 * @author 
 *
 */
@Service(value = SystemConstant.SELF_CARE_SERVICE)
public class SelfCareService extends SuperParentService implements ISelfCareService {
	private static final Logger LOGGER = LoggerFactory.getLogger(SelfCareService.class);
	@Autowired
	ISelfCareDAO selfCareDAO;
	
	public Map<Integer, String> getCountries() throws Exception {
		Map<Integer, String> map = new HashMap<>();
		try {
			List<Country> list = selfCareDAO.getCountries();
			for (Country country : list) {
				map.put(country.getId(), country.getCountryName());
			}
		} catch (Exception e) {
			LOGGER.info(""+e);
		}
		return map;
	}

	public Map<Integer, String> getState(Integer countryId) throws Exception {
		Map<Integer, String> map = new LinkedHashMap<>();
		try {
			List<State> list = selfCareDAO.getState(countryId);
			for (State state : list) {
				map.put(state.getId(), state.getStateName());
			}
		} catch (Exception e) {
			LOGGER.info(""+e);
		}
		return map;
	}



}
