/**
 * 
 */
package com.ng.sb.common.dataobject;

import java.io.Serializable;
import java.util.Date;

/**
 * @author gaurav
 * Base class for all Data transfer objects.
 */
public class BaseObjectData implements Serializable{

	private static final long serialVersionUID = 1L;
	protected Integer id;
	protected String name;
	protected String message;
	protected Integer code;
	protected Integer vendorId;
	protected Integer productId;
	protected String productName;
	protected Integer payCardTypeId;
	protected Integer noOfProducts;
	protected String cardName;
	protected String shippingDate;
	protected String orderNumber;
	private String productDescription;
	private String url;
	
	
	
	

	
	/**
	 * @return the productDescription
	 */
	public String getProductDescription() {
		return productDescription;
	}
	
	/**
	 * @param productDescription the productDescription to set
	 */
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	public enum UserType {
		CUSTOMER,
		RETAILER
	}
	/**
	 * Enum depicting Mapping being done in AccountInfoMapping Table
	 */
	public enum MappingEnum {
		HOST_PARTNER_MAPPING, 
		HOST_DISTBR_MAPPING, 
		DISTBR_SUBDISTBR_MAPPING, 
		DISTBR_HOST_MAPPING, 
		SUBDISTBR_RETAILER_MAPPING, 
		RETAILER_BC_MAPPING, 
		HOST_IWALLET_MAPPING, 
		HOST_EWALLET_MAPPING, 
		HOST_FSP_MAPPING,
		HOST_ALL_WALLETS_MAPPING,
		HOST_ALL_WALLETS_AND_PARTNERS_MAPPING
	}
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getCode() {
		return code;
	}
	public void setCode(Integer code) {
		this.code = code;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}

	public Integer getVendorId() {
		return vendorId;
	}
	public void setVendorId(Integer vendorId) {
		this.vendorId = vendorId;
	}
	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Integer getPayCardTypeId() {
		return payCardTypeId;
	}
	public void setPayCardTypeId(Integer payCardTypeId) {
		this.payCardTypeId = payCardTypeId;
	}

	public Integer getNoOfProducts() {
		return noOfProducts;
	}
	public void setNoOfProducts(Integer noOfProducts) {
		this.noOfProducts = noOfProducts;
	}
	public String getCardName() {
		return cardName;
	}
	public void setCardName(String cardName) {
		this.cardName = cardName;
	}
	public String getShippingDate() {
		return shippingDate;
	}
	public void setShippingDate(String shippingDate) {
		this.shippingDate = shippingDate;
	}
	public String getOrderNumber() {
		return orderNumber;
	}
	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
}
