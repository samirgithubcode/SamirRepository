/**
 * 
 */
package com.ng.bridge.service.impl;

import java.lang.reflect.InvocationTargetException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ng.bridge.invoker.IServiceInvoker;
import com.ng.sb.common.dataobject.BridgeDataObject;
import com.ng.sb.common.dataobject.ReflectionData;

/**
 * @author gaurav
 *
 */
public class ServiceInvoker extends BridgeService implements IServiceInvoker {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ServiceInvoker.class);
	
	private static IServiceInvoker instance = new ServiceInvoker();
	public ServiceInvoker(){
		//default
	}
	
	public static IServiceInvoker getInstance(){
		return instance;
	}
	
	@Override
	public BridgeDataObject invoke(String partnerServiceName,BridgeDataObject bridgeDataObject,String methodCallType){
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge ServiceInvoker -  invoke method. ");
		
		if( bridgeDataObject.getServiceType()!=null && partnerServiceName!=null && !partnerServiceName.isEmpty()){
			try {
				return invoker(partnerServiceName,bridgeDataObject,methodCallType);
			} catch (IllegalAccessException|InvocationTargetException e) {
				LOGGER.debug("exception occured"+ e);
			} 
		}
		return null;
	}
	
	
	private BridgeDataObject invoker(String partnerServiceName,BridgeDataObject bridgeDataObject,String methodCallType)throws IllegalAccessException,InvocationTargetException{
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge ServiceInvoker -  invoker method. ");
		ReflectionData reflectionData = com.ng.bridge.util.ServiceIdentifierMetaData.getInstance().getMethodToInvoke(bridgeDataObject,partnerServiceName,bridgeDataObject.getServiceType(),methodCallType);
			if(reflectionData!=null && reflectionData.getClassIdentifier()!=null && reflectionData.getMethod()!=null){
				return (BridgeDataObject)reflectionData.getMethod().invoke(reflectionData.getClassIdentifier(), bridgeDataObject);
			}
		return null;
	}
	
}
