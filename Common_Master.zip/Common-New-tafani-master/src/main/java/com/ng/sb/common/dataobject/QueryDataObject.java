package com.ng.sb.common.dataobject;

public class QueryDataObject extends BaseObjectData
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private String valueType;
	private String stringValue;
	private int intValue;
	private String parameterName;
	
	
	public String getParameterName() {
		return parameterName;
	}
	public void setParameterName(String parameterName) {
		this.parameterName = parameterName;
	}
	public String getValueType() {
		return valueType;
	}
	public void setValueType(String valueType) {
		this.valueType = valueType;
	}
	public String getStringValue() {
		return stringValue;
	}
	public void setStringValue(String stringValue) {
		this.stringValue = stringValue;
	}
	public int getIntValue() {
		return intValue;
	}
	public void setIntValue(int intValue) {
		this.intValue = intValue;
	}
}
