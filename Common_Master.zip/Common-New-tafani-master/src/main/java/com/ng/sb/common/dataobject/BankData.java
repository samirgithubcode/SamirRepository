package com.ng.sb.common.dataobject;

import java.io.Serializable;

public class BankData implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int id;
	private String name;
	private String bankCode;
	private String quantity; 
	
	private String seriesfrom;
	
	private String seriesto;
	
	
	public String getSeriesfrom() {
		return seriesfrom;
	}
	public void setSeriesfrom(String seriesfrom) {
		this.seriesfrom = seriesfrom;
	}
	public String getSeriesto() {
		return seriesto;
	}
	public void setSeriesto(String seriesto) {
		this.seriesto = seriesto;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	public String getBankCode() {
		return bankCode;
	}
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
