/**
 * 
 */
package com.ng.bridge.service;

/**
 * @author gaurav
 *
 */
public interface IFundTransferMgtService extends IFundMgtService {

}
