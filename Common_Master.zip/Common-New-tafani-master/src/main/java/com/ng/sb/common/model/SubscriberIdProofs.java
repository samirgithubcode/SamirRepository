/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "SubscriberIdProofs", uniqueConstraints = {
    @UniqueConstraint(columnNames = {"userIdProofId"})})
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "SubscriberIdProofs.findAll", query = "SELECT s FROM SubscriberIdProofs s"),
    @NamedQuery(name = "SubscriberIdProofs.findById", query = "SELECT s FROM SubscriberIdProofs s WHERE s.id = :id"),
    @NamedQuery(name = "SubscriberIdProofs.findByUserIdProofId", query = "SELECT s FROM SubscriberIdProofs s WHERE s.userIdProofId = :userIdProofId"),
    @NamedQuery(name = "SubscriberIdProofs.findBysubscriberId", query = "SELECT s FROM SubscriberIdProofs s WHERE s.subscriberId = :subscriberId"),
    
    @NamedQuery(name = "SubscriberIdProofs.updateUserIdProofIdByIdAndSubscriberId", 
    	query = "UPDATE SubscriberIdProofs s SET s.userIdProofId = :idNum WHERE s.subscriberId = :subId AND s.userIdProofId = :userId"),
    	
	@NamedQuery(name = "SubscriberIdProofs.updateUserIdProofStatusByIdAndSubscriberId", 
    	query = "UPDATE SubscriberIdProofs s SET s.status = :status WHERE s.subscriberId = :subId AND s.userIdProofId = :userId"),
    @NamedQuery(name = "SubscriberIdProofs.findBysubscriberIdAndStatus", query = "SELECT s FROM SubscriberIdProofs s WHERE s.subscriberId = :subscriberId AND s.status = :status"),
    @NamedQuery(name = "SubscriberIdProofs.findByPendingStatusPendingCount", query = "SELECT s.subscriberId, count(s.subscriberId) FROM SubscriberIdProofs s WHERE s.status = 'PENDING' AND (s.createdBy.hId.id = :accountId OR s.createdBy.dId.id = :accountId OR s.createdBy.sdId.id = :accountId) group by s.subscriberId"),

    @NamedQuery(name = "SubscriberIdProofs.findByPendingStatus", query = "SELECT s FROM SubscriberIdProofs s WHERE s.status = 'PENDING' AND (s.createdBy.hId.id = :accountId OR s.createdBy.dId.id = :accountId OR s.createdBy.sdId.id = :accountId)"),
    @NamedQuery(name = "SubscriberIdProofs.findBysubscriberIdnAccountId", query = "SELECT s FROM SubscriberIdProofs s WHERE s.subscriberId = :subscriberId AND (s.createdBy.hId.id = :accountId OR s.createdBy.dId.id = :accountId OR s.createdBy.sdId.id = :accountId)")
})

public class SubscriberIdProofs implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
    @Basic(optional = false)
    @Column(name = "userIdProofId", nullable = false, length = 50)
    private String userIdProofId;
    @JoinColumn(name = "subscriberId", referencedColumnName = "id", nullable = false)
    @ManyToOne(fetch=FetchType.LAZY)
    private Subscriber subscriberId;
    @JoinColumn(name = "idProofId", referencedColumnName = "id", nullable = false)
    @ManyToOne(fetch=FetchType.LAZY)
    private IdProofs idProofId;
//    @Basic(optional = false)
//	@Column(name="document")
//	private String document;
    @Basic(optional = false)
    @Column(name="documentName")
    private String documentName;
    @Basic(optional = false)
    @Column(name="status")
    private String status;
    @Temporal(TemporalType.TIMESTAMP)
    @Basic(optional = false)
    @Column(name="createdOn")
    private Date createdOn;
    
    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name = "createdBy", referencedColumnName = "id", nullable = false)
    private AccountLoginInfo createdBy;
    
    @Temporal(TemporalType.TIMESTAMP)
    @Basic(optional = false)
    @Column(name="verifiedOn")
    private Date modifiedOn;
    
    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name = "verifiedBy", referencedColumnName = "id", nullable = false)
    private AccountLoginInfo modifiedBy;
    
    @Basic(optional = false)
    @Column(name="comment")
    private String comment;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name="validFrom")
    private Date validFrom;
    
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name="validTo")
    private Date validTo;
    

    public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public AccountLoginInfo getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(AccountLoginInfo createdBy) {
		this.createdBy = createdBy;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public AccountLoginInfo getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(AccountLoginInfo modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public SubscriberIdProofs() {
    	//default constructor
    }

    public SubscriberIdProofs(Integer id) {
        this.id = id;
    }

    public SubscriberIdProofs(Integer id, String userIdProofId) {
        this.id = id;
        this.userIdProofId = userIdProofId;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUserIdProofId() {
        return userIdProofId;
    }

    public void setUserIdProofId(String userIdProofId) {
        this.userIdProofId = userIdProofId;
    }

    public Subscriber getSubscriberId() {
        return subscriberId;
    }

    public void setSubscriberId(Subscriber subscriberId) {
        this.subscriberId = subscriberId;
    }

    public IdProofs getIdProofId() {
        return idProofId;
    }

    public void setIdProofId(IdProofs idProofId) {
        this.idProofId = idProofId;
    }

//    public String getDocument() {
//		return document;
//	}
//
//	public void setDocument(String document) {
//		this.document = document;
//	}

	public String getDocumentName() {
		return documentName;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	@Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }
	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	public String getStatus() {
		return status;
	}



    @Override
    public boolean equals(Object object) {
        if (!(object instanceof SubscriberIdProofs)) {
            return false;
        }
        SubscriberIdProofs other = (SubscriberIdProofs) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.SubscriberIdProofs[ id=" + id + " ]";
    }

	public Date getValidFrom() {
		return validFrom;
	}

	public void setValidFrom(Date validFrom) {
		this.validFrom = validFrom;
	}

	public Date getValidTo() {
		return validTo;
	}

	public void setValidTo(Date validTo) {
		this.validTo = validTo;
	}
    
}
