package com.ng.sb.common.dataobject;

import java.io.Serializable;
import java.util.List;

public class ServiceProviderData implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int serviceProviderId;
	private Integer serviceProviderCode;
	private List<ServicePartnerData> servicePartnerDatas;
	
	public int getServiceProviderId() {
		return serviceProviderId;
	}
	public void setServiceProviderId(int serviceProviderId) {
		this.serviceProviderId = serviceProviderId;
	}
	public Integer getServiceProviderCode() {
		return serviceProviderCode;
	}
	public void setServiceProviderCode(Integer serviceProviderCode) {
		this.serviceProviderCode = serviceProviderCode;
	}
	public List<ServicePartnerData> getServicePartnerDatas() {
		return servicePartnerDatas;
	}
	public void setServicePartnerDatas(List<ServicePartnerData> servicePartnerDatas) {
		this.servicePartnerDatas = servicePartnerDatas;
	}
}
