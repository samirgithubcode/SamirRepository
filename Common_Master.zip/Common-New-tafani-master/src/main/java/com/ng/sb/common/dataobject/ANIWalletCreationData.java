package com.ng.sb.common.dataobject;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "WalletRequestData")
public class ANIWalletCreationData extends PlatformRequestData {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer channelId;
	private String  tokenId;
	private transient Object payload;
	
	public String getTokenId() {
		return tokenId;
	}
	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}

	public Integer getChannelId() {
		return channelId;
	}
	public void setChannelId(Integer channelId) {
		this.channelId = channelId;
	}
	
	
	public Object getPayload() {
		return payload;
	}
	public void setPayload(Object payload) {
		this.payload = payload;
	}
}
