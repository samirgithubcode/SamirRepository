/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "masterVersion", uniqueConstraints = {
    @UniqueConstraint(columnNames = {"code"})})
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "MasterVersion.findAll", query = "SELECT m FROM MasterVersion m"),
    @NamedQuery(name = "MasterVersion.findById", query = "SELECT m FROM MasterVersion m WHERE m.id = :id"),
    @NamedQuery(name = "MasterVersion.findByName", query = "SELECT m FROM MasterVersion m WHERE m.name = :name"),
    @NamedQuery(name = "MasterVersion.findIdByName", query = "SELECT m.id FROM MasterVersion m WHERE m.name = :name"),
    @NamedQuery(name = "MasterVersion.findByCode", query = "SELECT m FROM MasterVersion m WHERE m.code = :code"),
    @NamedQuery(name = "MasterVersion.findMaxVersionCode", query = "SELECT MAX(m.code) FROM MasterVersion m"),
    @NamedQuery(name = "MasterVersion.findByDescription", query = "SELECT m FROM MasterVersion m WHERE m.description = :description"),
    @NamedQuery(name = "MasterVersion.findCodeById", query = "SELECT m FROM MasterVersion m WHERE m.id = :mvId"),
    @NamedQuery(name = "MasterVersion.findBysmscode", query = "SELECT m FROM MasterVersion m WHERE m.smsCode = :smsCode"),
    @NamedQuery(name = "MasterVersion.countbysmscode", query = "SELECT count(*) FROM MasterVersion m WHERE m.smsCode =:smsCode"),
    @NamedQuery(name = "MasterVersion.countbysmscodeandId", query = "SELECT count(*) FROM MasterVersion m WHERE m.smsCode =:smsCode and m.id =:id"),
    @NamedQuery(name = "MasterVersion.countbymvname", query = "SELECT count(*) FROM MasterVersion m WHERE m.name =:name"),
    @NamedQuery(name = "MasterVersion.countbymvnameandId", query = "SELECT count(*) FROM MasterVersion m WHERE m.name =:name and m.id =:id"),
    @NamedQuery(name = "MasterVersion.findIdbycode", query = "SELECT m FROM MasterVersion m WHERE m.code =:mcode"),
    @NamedQuery(name = "MasterVersion.updateStatus", query = "UPDATE MasterVersion m set m.status=:status where m.id = :id"),
        
})
public class MasterVersion implements Serializable {
	
	
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    
    @Basic(optional = false)
    @Column(name = "code")
    private Integer code;
    
    @Basic(optional = false)
    @Column(name = "name")
    private String name;
    
    @Column(name = "smsCode")
    private String smsCode;
    
    @Basic(optional = false)
    @Column(name = "description")
    private String description;
    
//    @Basic(optional = false)
    @Column(name = "createdOn")
    private Date createdOn;
    
//    @Basic(optional = false)
    @Column(name = "createdBy")
    private String createdBy;
    
//    1 for Active and 0 for Inactive
    @Column(name = "status")
    private Integer status;
    @Column(name = "comment")
    private String comment;
    
    
    
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "mvId")
    private Collection<InventoryMgmt> inventoryMgmtCollection;
    
    @OneToMany(mappedBy = "mvId")
    private Collection<InventoryOrder> inventoryOrderCollection;
    
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "mvId")
    private Collection<MasterVersionCategory> masterVersionCategoryCollection;
    
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "mvId")
    private Collection<RangeDetails> rangeDetailsCollection;
    
    @OneToMany(mappedBy = "mvId")
    private Collection<ServiceConfig> serviceConfigCollection;
    
    @OneToMany(mappedBy = "mvId")
    private Collection<MasterVersionAllocatedService> masterVersionAllocatedService;
    
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "mvId")
    private Collection<Inventory> inventoryCollection;
    
    @OneToMany(mappedBy = "mvId")
    private Collection<InventorySummary> inventorySummaryCollection;
    
    @OneToMany(mappedBy = "mvId")
    private Collection<ProductInventorySummary> productInventorySummaryCollection;
    
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "mvId", fetch = FetchType.EAGER)
    @Fetch(FetchMode.SELECT)
    private Collection<HostSubVersion> hostSubVersionCollection;
    
    @OneToMany(mappedBy = "mvId")
    private Collection<TransactionInfo> transactionInfoCollection;
    
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "mvId")
    private Collection<InventoryOrderHistory> inventoryOrderHistoryCollection;
    
    @OneToMany(cascade = CascadeType.ALL, mappedBy="mvId")
    private Collection<MVWalletMapping> mvWalletCollection;

    public MasterVersion() {
    	//default constructor
    }

    public MasterVersion(Integer id) {
        this.id = id;
    }

    public MasterVersion(Integer id, String name, Integer code, String description) {
        this.id = id;
        this.name = name;
        this.code = code;
        this.description = description;
    }

    public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Integer getId() {
        return id;
    }

    public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}
	
	@XmlTransient
	public Collection<MasterVersionAllocatedService> getMasterVersionAllocatedService() {
		return masterVersionAllocatedService;
	}

	public void setMasterVersionAllocatedService(Collection<MasterVersionAllocatedService> masterVersionAllocatedService) {
		this.masterVersionAllocatedService = masterVersionAllocatedService;
	}

	public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getSmsCode() {
        return smsCode;
    }

    public void setSmsCode(String smsCode) {
        this.smsCode = smsCode;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    
    public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}


    @XmlTransient
    public Collection<InventoryMgmt> getInventoryMgmtCollection() {
        return inventoryMgmtCollection;
    }

    public void setInventoryMgmtCollection(Collection<InventoryMgmt> inventoryMgmtCollection) {
        this.inventoryMgmtCollection = inventoryMgmtCollection;
    }

    @XmlTransient
    public Collection<InventoryOrder> getInventoryOrderCollection() {
        return inventoryOrderCollection;
    }

    public void setInventoryOrderCollection(Collection<InventoryOrder> inventoryOrderCollection) {
        this.inventoryOrderCollection = inventoryOrderCollection;
    }

    @XmlTransient
    public Collection<MasterVersionCategory> getMasterVersionCategoryCollection() {
        return masterVersionCategoryCollection;
    }

    public void setMasterVersionCategoryCollection(Collection<MasterVersionCategory> masterVersionCategoryCollection) {
        this.masterVersionCategoryCollection = masterVersionCategoryCollection;
    }

    @XmlTransient
    public Collection<RangeDetails> getRangeDetailsCollection() {
        return rangeDetailsCollection;
    }

    public void setRangeDetailsCollection(Collection<RangeDetails> rangeDetailsCollection) {
        this.rangeDetailsCollection = rangeDetailsCollection;
    }

    @XmlTransient
    public Collection<ServiceConfig> getServiceConfigCollection() {
        return serviceConfigCollection;
    }

    public void setServiceConfigCollection(Collection<ServiceConfig> serviceConfigCollection) {
        this.serviceConfigCollection = serviceConfigCollection;
    }

    @XmlTransient
    public Collection<Inventory> getInventoryCollection() {
        return inventoryCollection;
    }

    public void setInventoryCollection(Collection<Inventory> inventoryCollection) {
        this.inventoryCollection = inventoryCollection;
    }

    @XmlTransient
    public Collection<InventorySummary> getInventorySummaryCollection() {
        return inventorySummaryCollection;
    }

    public void setInventorySummaryCollection(Collection<InventorySummary> inventorySummaryCollection) {
        this.inventorySummaryCollection = inventorySummaryCollection;
    }

    @XmlTransient
    public Collection<ProductInventorySummary> getProductInventorySummaryCollection() {
        return productInventorySummaryCollection;
    }

    public void setProductInventorySummaryCollection(Collection<ProductInventorySummary> productInventorySummaryCollection) {
        this.productInventorySummaryCollection = productInventorySummaryCollection;
    }

    @XmlTransient
    public Collection<HostSubVersion> getHostSubVersionCollection() {
        return hostSubVersionCollection;
    }

    public void setHostSubVersionCollection(Collection<HostSubVersion> hostSubVersionCollection) {
        this.hostSubVersionCollection = hostSubVersionCollection;
    }

    @XmlTransient
    public Collection<TransactionInfo> getTransactionInfoCollection() {
        return transactionInfoCollection;
    }

    public void setTransactionInfoCollection(Collection<TransactionInfo> transactionInfoCollection) {
        this.transactionInfoCollection = transactionInfoCollection;
    }

    @XmlTransient
    public Collection<InventoryOrderHistory> getInventoryOrderHistoryCollection() {
        return inventoryOrderHistoryCollection;
    }

    public void setInventoryOrderHistoryCollection(Collection<InventoryOrderHistory> inventoryOrderHistoryCollection) {
        this.inventoryOrderHistoryCollection = inventoryOrderHistoryCollection;
    }

    public Collection<MVWalletMapping> getMvWalletCollection() {
		return mvWalletCollection;
	}

	public void setMvWalletCollection(Collection<MVWalletMapping> mvWalletCollection) {
		this.mvWalletCollection = mvWalletCollection;
	}

	

	public Collection<MasterVersionAllocatedService> getMasterVersionAllocatedServices() {
		return masterVersionAllocatedService;
	}

	public void setMasterVersionAllocatedServices(
			Collection<MasterVersionAllocatedService> masterVersionAllocatedServices) {
		this.masterVersionAllocatedService = masterVersionAllocatedServices;
	}

	@Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }
	
	

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof MasterVersion)) {
            return false;
        }
        MasterVersion other = (MasterVersion) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

	@Override
	public String toString() {
		return "MasterVersion [id=" + id + ", code=" + code + ", name=" + name
				+ "]";
	}
    
    
    
}