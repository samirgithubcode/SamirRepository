/**
 * 
 */
package com.ng.pnb.invoker.util;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

/**
 * @author gopal
 *
 */
@PropertySource("classpath:ChannelIntegration.properties")
//@PropertySource("file:${catalina.home}/properties/SystemProperties.properties")
@Qualifier(value = "propertyHolder")
@Component
public class PropertyHolder 
{

	@Value("${BANKING_INTEGRATION_PROTOCOL}")
	private String integrationProtocol;
	
	@Value("${ISO_STRUCTURE_DEFINITION_FILE}")
	private String definitionFile;
	
	@Value("${ISO_MSG_PACKAGER}")
	private String isoPackager;
	
	@Value("${ISO_MSG_CHANNEL}")
	private String isoChannel;
	
	@Value("${ISO_SERVER}")
	private String isoServer;
	
	@Value("${ISO_PORT}")
	private int isoPort;
	
	@Value("${ISO_STRUCTURE_REQUIRED_IN_PACKAGER}")
	private boolean structureRequired;

	@Value("${DEPLOYMENT_FOR}")
	private String deploymentFor;
	
	public String getIntegrationProtocol() {
		return integrationProtocol;
	}

	public void setIntegrationProtocol(String integrationProtocol) {
		this.integrationProtocol = integrationProtocol;
	}

	public String getDefinitionFile() {
		return definitionFile;
	}

	public void setDefinitionFile(String definitionFile) {
		this.definitionFile = definitionFile;
	}

	public String getIsoPackager() {
		return isoPackager;
	}

	public void setIsoPackager(String isoPackager) {
		this.isoPackager = isoPackager;
	}

	public String getIsoChannel() {
		return isoChannel;
	}

	public void setIsoChannel(String isoChannel) {
		this.isoChannel = isoChannel;
	}

	public String getIsoServer() {
		return isoServer;
	}

	public void setIsoServer(String isoServer) {
		this.isoServer = isoServer;
	}

	public int getIsoPort() {
		return isoPort;
	}

	public void setIsoPort(int isoPort) {
		this.isoPort = isoPort;
	}

	public boolean isStructureRequired() {
		return structureRequired;
	}

	public void setStructureRequired(boolean structureRequired) {
		this.structureRequired = structureRequired;
	}

	public String getDeploymentFor() {
		return deploymentFor;
	}

	public void setDeploymentFor(String deploymentFor) {
		this.deploymentFor = deploymentFor;
	}
	
	
}
