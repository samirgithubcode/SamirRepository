package com.ng.sb.common.dataobject;

import java.sql.Date;
import java.util.Map;

public class TransactionServiceData extends BaseObjectData{
	private static final long serialVersionUID = 1L;
	private Integer chkFor;
	private Integer providers;
	private Date toDate;
	private Date fromDate;
	private Integer transactionType;
	private Integer debitAmount;
	private Integer creditAmount;
	private Integer netAmount;
	
	private String date;
	private String initiator;
	private String payeeWalletName;
	
	private String payeeWalletId;
	private String payerWalletName;
	private String payerWalletId;
	private String transactionTypes;
	private String debit;
	private String credit;
	private String hostTxnId;
	private String payerTxnId;
	private String payeeTxnId;
	private String providerCode;
	private String providerId;
	private String partnerId;
	private String subscriberId;
	private String status;
	private String payerTelcoId;
	private Map<Integer,String> providerMap;
	public String getPartnerId() {
		return partnerId;
	}
	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}
	
	
	public String getPayeeWalletName() {
		return payeeWalletName;
	}
	public void setPayeeWalletName(String payeeWalletName) {
		this.payeeWalletName = payeeWalletName;
	}
	public String getPayerWalletName() {
		return payerWalletName;
	}
	public void setPayerWalletName(String payerWalletName) {
		this.payerWalletName = payerWalletName;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getInitiator() {
		return initiator;
	}
	public void setInitiator(String initiator) {
		this.initiator = initiator;
	}
	
	public String getPayeeWalletId() {
		return payeeWalletId;
	}
	public void setPayeeWalletId(String payeeWalletId) {
		this.payeeWalletId = payeeWalletId;
	}
	
	public String getPayerWalletId() {
		return payerWalletId;
	}
	public void setPayerWalletId(String payerWalletId) {
		this.payerWalletId = payerWalletId;
	}
	public String getTransactionTypes() {
		return transactionTypes;
	}
	public void setTransactionTypes(String transactionTypes) {
		this.transactionTypes = transactionTypes;
	}
	
	public String getHostTxnId() {
		return hostTxnId;
	}
	public void setHostTxnId(String hostTxnId) {
		this.hostTxnId = hostTxnId;
	}
	public String getPayerTxnId() {
		return payerTxnId;
	}
	public void setPayerTxnId(String payerTxnId) {
		this.payerTxnId = payerTxnId;
	}
	public String getPayeeTxnId() {
		return payeeTxnId;
	}
	public void setPayeeTxnId(String payeeTxnId) {
		this.payeeTxnId = payeeTxnId;
	}
	
	public String getSubscriberId() {
		return subscriberId;
	}
	public String getDebit() {
		return debit;
	}
	public void setDebit(String debit) {
		this.debit = debit;
	}
	public String getCredit() {
		return credit;
	}
	public void setCredit(String credit) {
		this.credit = credit;
	}
	public String getProviderCode() {
		return providerCode;
	}
	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}
	public String getProviderId() {
		return providerId;
	}
	public void setProviderId(String providerId) {
		this.providerId = providerId;
	}
	public void setSubscriberId(String subscriberId) {
		this.subscriberId = subscriberId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getPayerTelcoId() {
		return payerTelcoId;
	}
	public void setPayerTelcoId(String payerTelcoId) {
		this.payerTelcoId = payerTelcoId;
	}
	
	
	public Map<Integer, String> getProviderMap() {
		return providerMap;
	}
	public void setProviderMap(Map<Integer, String> providerMap) {
		this.providerMap = providerMap;
	}
	public Integer getChkFor() {
		return chkFor;
	}
	public void setChkFor(Integer chkFor) {
		this.chkFor = chkFor;
	}
	public Integer getProviders() {
		return providers;
	}
	public void setProviders(Integer providers) {
		this.providers = providers;
	}
	public Date getToDate() {
		return toDate;
	}
	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}
	public Date getFromDate() {
		return fromDate;
	}
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}
	public Integer getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(Integer transactionType) {
		this.transactionType = transactionType;
	}
	public Integer getDebitAmount() {
		return debitAmount;
	}
	public void setDebitAmount(Integer debitAmount) {
		this.debitAmount = debitAmount;
	}
	public Integer getCreditAmount() {
		return creditAmount;
	}
	public void setCreditAmount(Integer creditAmount) {
		this.creditAmount = creditAmount;
	}
	public Integer getNetAmount() {
		return netAmount;
	}
	public void setNetAmount(Integer netAmount) {
		this.netAmount = netAmount;
	}
	
}
