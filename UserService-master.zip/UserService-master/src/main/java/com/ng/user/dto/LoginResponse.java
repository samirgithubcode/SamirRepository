/**
 * 
 */
package com.ng.user.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.ng.sb.common.dataobject.BankAccount;
import com.ng.sb.common.util.CustomJsonDateSerializer;

/**
 * @author gopal
 *
 */
@JsonInclude(Include.NON_NULL)	
public class LoginResponse implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3833147460885684405L;

    private Integer status;
    
    private int userTypeId;
	
	private String message;
	
	private String tokenId;
	
	private String userId;
	
	private String userCompanyId;
	
	private Integer accountId; 
	
	private Integer parentId;
	
	private int accountTypeId;
	
	private String accountTypeWeight;
	
	private String accountTypeCode; 
	
	private String userName;
	
	@JsonSerialize(using = CustomJsonDateSerializer.class)
	private Date lastPasswordDate;
	
	private String groupId;
	
	private String groupCode;
	
	private String groupWeight;
	
	private String hostCode;
	
	private String contactPersonName;
	
	private String txnNature;
	
	private String cardSubscriptionAmount;
	
	private String key;
	
	private boolean isFirstLogin;

	private String currentBalance;
	
	private String merchantName;
	
	private String merchantCity;
	
	private String merchantCategoryCode;
	
	private String countryCode;
	
	private BankAccount accountDetails;
	
	private String merchantId;
	
	private String userType;
	
	private String userRole;
	
	private String merchantType;
	
	private String merchantCurrencyCode;
	
	@JsonProperty("commissionList")
	private List<CommissionData> commInfoList = new ArrayList<>();

	private List<ServiceDeails> mappedServices;
	
	private String userProfileImage;
	
	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getTokenId() {
		return tokenId;
	}

	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public int getUserTypeId() {
		return userTypeId;
	}

	public void setUserTypeId(int userTypeId) {
		this.userTypeId = userTypeId;
	}

	public int getAccountTypeId() {
		return accountTypeId;
	}

	public void setAccountTypeId(int accountTypeId) {
		this.accountTypeId = accountTypeId;
	}

	public boolean isFirstLogin() {
		return isFirstLogin;
	}

	public void setFirstLogin(boolean isFirstLogin) {
		this.isFirstLogin = isFirstLogin;
	}

	public Date getLastPasswordDate() {
		return lastPasswordDate;
	}

	public void setLastPasswordDate(Date lastPasswordDate) {
		this.lastPasswordDate = lastPasswordDate;
	}

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public String getGroupCode() {
		return groupCode;
	}

	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}

	public String getGroupWeight() {
		return groupWeight;
	}

	public void setGroupWeight(String groupWeight) {
		this.groupWeight = groupWeight;
	}

	public String getHostCode() {
		return hostCode;
	}

	public void setHostCode(String hostCode) {
		this.hostCode = hostCode;
	}

	public String getContactPersonName() {
		return contactPersonName;
	}

	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}

	public Integer getAccountId() {
		return accountId;
	}

	public void setAccountId(Integer accountId) {
		this.accountId = accountId;
	}

	public Integer getParentId() {
		return parentId;
	}

	public void setParentId(Integer parentId) {
		this.parentId = parentId;
	}

	public String getUserCompanyId() {
		return userCompanyId;
	}

	public void setUserCompanyId(String userCompanyId) {
		this.userCompanyId = userCompanyId;
	}

	public String getAccountTypeCode() {
		return accountTypeCode;
	}

	public void setAccountTypeCode(String accountTypeCode) {
		this.accountTypeCode = accountTypeCode;
	}
	
	public List<CommissionData> getCommInfoList() {
		return commInfoList;
	}

	public void setCommInfoList(List<CommissionData> commInfoList) {
		this.commInfoList = commInfoList;
	}

	public String getCardSubscriptionAmount() {
		return cardSubscriptionAmount;
	}

	public void setCardSubscriptionAmount(String cardSubscriptionAmount) {
		this.cardSubscriptionAmount = cardSubscriptionAmount;
	}

	public String getTxnNature() {
		return txnNature;
	}

	public void setTxnNature(String txnNature) {
		this.txnNature = txnNature;
	}

	public String getAccountTypeWeight() {
		return accountTypeWeight;
	}

	public void setAccountTypeWeight(String accountTypeWeight) {
		this.accountTypeWeight = accountTypeWeight;
	}

	public String getCurrentBalance() {
		return currentBalance;
	}

	public void setCurrentBalance(String currentBalance) {
		this.currentBalance = currentBalance;
	}

	public List<ServiceDeails> getMappedServices() {
		return mappedServices;
	}

	public void setMappedServices(List<ServiceDeails> mappedServices) {
		this.mappedServices = mappedServices;
	}

	public String getMerchantName() {
		return merchantName;
	}

	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}

	public String getMerchantCity() {
		return merchantCity;
	}

	public void setMerchantCity(String merchantCity) {
		this.merchantCity = merchantCity;
	}

	public String getMerchantCategoryCode() {
		return merchantCategoryCode;
	}

	public void setMerchantCategoryCode(String merchantCategoryCode) {
		this.merchantCategoryCode = merchantCategoryCode;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public BankAccount getAccountDetails() {
		return accountDetails;
	}

	public void setAccountDetails(BankAccount accountDetails) {
		this.accountDetails = accountDetails;
	}

	public String getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getUserProfileImage() {
		return userProfileImage;
	}

	public void setUserProfileImage(String userProfileImage) {
		this.userProfileImage = userProfileImage;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	public String getMerchantType() {
		return merchantType;
	}

	public void setMerchantType(String merchantType) {
		this.merchantType = merchantType;
	}

	public String getMerchantCurrencyCode() {
		return merchantCurrencyCode;
	}

	public void setMerchantCurrencyCode(String merchantCurrencyCode) {
		this.merchantCurrencyCode = merchantCurrencyCode;
	}
	
}
