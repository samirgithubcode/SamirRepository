package com.ng.sb.common.dataobject;

import java.util.List;

public class TransactionData {
	
	private Long requestTime;
	private boolean skipNumeric=false;
	private String dKeyChar;
	private String serviceCode;
	private Integer hostSubVersionCode;
	private boolean gatewaystatus;
	private String userIp;
	private String transactionId;
	private String hostID;
	private String callerMobileNumber;
	private String callerAadharNumber;
	private String clientReferenceId;
	private String token;
	private String internalNumberRequest;
	private String shortCodeRequest;
	private String menuVersionRequest;
	private String msisdn;
	private String dateTime;
	private String responseMessage;
	private String serviceCodeRequest;
	private String operationalCommand;
	private String requestMessage;
	private String decryptedMessage;
	private String combinedParamString;
	private byte[] combinedParamByteArray;
	private String serviceId;
	private List parametersDetails;
	private SubsAccountDetails subsAccountDetails;
	private String reqStkCode;
	private List<ServiceParamsMappingData> serviceParamsMappingList;
	private boolean chkCustValidation;
	

	
	private String simVersion;
	private String menuVersion;
	private String decriptionKey;
	private String simSerialNumber;
	
	private String transactionAmount;
	private String serviceCharge;
	private String openingBalance;
	private String closingBalance;
	private int transactionStatus;
	private String transactionStatusMessage;
	private String transactionType;
	private String agentCode;
	private String agentName;
	private Integer noOfTransactions;
	private String deviceId;
	private String agentCity;
	private String toltalPayAmount;
	private String productStatus;
	
	
	public String getProductStatus() {
		return productStatus;
	}
	public void setProductStatus(String productStatus) {
		this.productStatus = productStatus;
	}
	public String getToltalPayAmount() {
		return toltalPayAmount;
	}
	public void setToltalPayAmount(String toltalPayAmount) {
		this.toltalPayAmount = toltalPayAmount;
	}
	public String getAgentCity() {
		return agentCity;
	}
	public void setAgentCity(String agentCity) {
		this.agentCity = agentCity;
	}
	public String getDeviceId() {
		return deviceId;
	}
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	public Integer getNoOfTransactions() {
		return noOfTransactions;
	}
	public void setNoOfTransactions(Integer noOfTransactions) {
		this.noOfTransactions = noOfTransactions;
	}
	public String getAgentCode() {
		return agentCode;
	}
	public void setAgentCode(String agentCode) {
		this.agentCode = agentCode;
	}
	public String getAgentName() {
		return agentName;
	}
	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getTransactionAmount() {
		return transactionAmount;
	}
	public void setTransactionAmount(String transactionAmount) {
		this.transactionAmount = transactionAmount;
	}
	public String getServiceCharge() {
		return serviceCharge;
	}
	public void setServiceCharge(String serviceCharge) {
		this.serviceCharge = serviceCharge;
	}
	public String getOpeningBalance() {
		return openingBalance;
	}
	public void setOpeningBalance(String openingBalance) {
		this.openingBalance = openingBalance;
	}
	public String getClosingBalance() {
		return closingBalance;
	}
	public void setClosingBalance(String closingBalance) {
		this.closingBalance = closingBalance;
	}
	public int getTransactionStatus() {
		return transactionStatus;
	}
	public void setTransactionStatus(int transactionStatus) {
		this.transactionStatus = transactionStatus;
	}
	public String getTransactionStatusMessage() {
		return transactionStatusMessage;
	}
	public void setTransactionStatusMessage(String transactionStatusMessage) {
		this.transactionStatusMessage = transactionStatusMessage;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public String getdKeyChar() {
		return dKeyChar;
	}
	public void setdKeyChar(String dKeyChar) {
		this.dKeyChar = dKeyChar;
	}
	public String getClientReferenceId() {
		return clientReferenceId;
	}
	public void setClientReferenceId(String clientReferenceId) {
		this.clientReferenceId = clientReferenceId;
	}
	public String getCallerMobileNumber() {
		return callerMobileNumber;
	}
	public void setCallerMobileNumber(String callerMobileNumber) {
		this.callerMobileNumber = callerMobileNumber;
	}
	public String getCallerAadharNumber() {
		return callerAadharNumber;
	}
	public void setCallerAadharNumber(String callerAadharNumber) {
		this.callerAadharNumber = callerAadharNumber;
	}
	public String getInternalNumberRequest() {
		return internalNumberRequest;
	}
	public void setInternalNumberRequest(String internalNumberRequest) {
		this.internalNumberRequest = internalNumberRequest;
	}
	public String getShortCodeRequest() {
		return shortCodeRequest;
	}
	public void setShortCodeRequest(String shortCodeRequest) {
		this.shortCodeRequest = shortCodeRequest;
	}
	public String getMenuVersionRequest() {
		return menuVersionRequest;
	}
	public void setMenuVersionRequest(String menuVersionRequest) {
		this.menuVersionRequest = menuVersionRequest;
	}
	public String getServiceCodeRequest() {
		return serviceCodeRequest;
	}
	public void setServiceCodeRequest(String serviceCodeRequest) {
		this.serviceCodeRequest = serviceCodeRequest;
	}
	public SubsAccountDetails getSubsAccountDetails() {
		return subsAccountDetails;
	}
	public void setSubsAccountDetails(SubsAccountDetails subsAccountDetails) {
		this.subsAccountDetails = subsAccountDetails;
	}
	public String getReqStkCode() {
		return reqStkCode;
	}
	public void setReqStkCode(String reqStkCode) {
		this.reqStkCode = reqStkCode;
	}
	public List<ServiceParamsMappingData> getServiceParamsMappingList() {
		return serviceParamsMappingList;
	}
	public void setServiceParamsMappingList(List<ServiceParamsMappingData> serviceParamsMappingList) {
		this.serviceParamsMappingList = serviceParamsMappingList;
	}
	public boolean isChkCustValidation() {
		return chkCustValidation;
	}
	public void setChkCustValidation(boolean chkCustValidation) {
		this.chkCustValidation = chkCustValidation;
	}
	
	
	public Integer getHostSubVersionCode() {
		return hostSubVersionCode;
	}
	public void setHostSubVersionCode(Integer hostSubVersionCode) {
		this.hostSubVersionCode = hostSubVersionCode;
	}
	
	
	public String getRequestMessage() {
		return requestMessage;
	}
	public void setRequestMessage(String requestMessage) {
		this.requestMessage = requestMessage;
	}
	public String getSimVersion() {
		return simVersion;
	}
	public void setSimVersion(String simVersion) {
		this.simVersion = simVersion;
	}
	public String getMenuVersion() {
		return menuVersion;
	}
	public void setMenuVersion(String menuVersion) {
		this.menuVersion = menuVersion;
	}
	public String getDecriptionKey() {
		return decriptionKey;
	}
	public void setDecriptionKey(String decriptionKey) {
		this.decriptionKey = decriptionKey;
	}
	public String getSimSerialNumber() {
		return simSerialNumber;
	}
	public void setSimSerialNumber(String simSerialNumber) {
		this.simSerialNumber = simSerialNumber;
	}
	public String getCombinedParamString() {
		return combinedParamString;
	}
	public void setCombinedParamString(String combinedParamString) {
		this.combinedParamString = combinedParamString;
	}
	public byte[] getCombinedParamByteArray() {
		return combinedParamByteArray;
	}
	public void setCombinedParamByteArray(byte[] combinedParamByteArray) {
		this.combinedParamByteArray = combinedParamByteArray;
	}
	public String getServiceId() {
		return serviceId;
	}
	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}
	public List getParametersDetails() {
		return parametersDetails;
	}
	public void setParametersDetails(List parametersDetails) {
		this.parametersDetails = parametersDetails;
	}
	public boolean isGatewaystatus() {
		return gatewaystatus;
	}
	public void setGatewaystatus(boolean gatewaystatus) {
		this.gatewaystatus = gatewaystatus;
	}
	public String getUserIp() {
		return userIp;
	}
	public void setUserIp(String userIp) {
		this.userIp = userIp;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getHostID() {
		return hostID;
	}
	public void setHostID(String hostID) {
		this.hostID = hostID;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public String getDateTime() {
		return dateTime;
	}
	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public String getServiceCode() {
		return serviceCode;
	}
	public void setServiceCode(String serviceCode) {
		this.serviceCode = serviceCode;
	}
	public String getOperationalCommand() {
		return operationalCommand;
	}
	public void setOperationalCommand(String operationalCommand) {
		this.operationalCommand = operationalCommand;
	}
	public boolean isSkipNumeric() {
		return skipNumeric;
	}
	public void setSkipNumeric(boolean skipNumeric) {
		this.skipNumeric = skipNumeric;
	}
	public Long getRequestTime() {
		return requestTime;
	}
	public void setRequestTime(Long requestTime) {
		this.requestTime = requestTime;
	}
	public String getDecryptedMessage() {
		return decryptedMessage;
	}
	public void setDecryptedMessage(String decryptedMessage) {
		this.decryptedMessage = decryptedMessage;
	}
	

}
