package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author sonu
 */

@Entity
@Table(name="ShippedProduct")
@XmlRootElement
@NamedQueries({
	  @NamedQuery(name = "ShippedProduct.findAll", query = "SELECT a FROM ShippedProduct a  order by a.shippeddate"),
	  @NamedQuery(name = "ShippedProduct.findorderNoBYId", query = "SELECT a FROM ShippedProduct a  WHERE a.shippeddate=:shippedDate AND a.shippedfor=:shippedfor"),
	  @NamedQuery(name = "ShippedProduct.findpodateByid", query = "SELECT a FROM ShippedProduct a  WHERE a.id=:id"),
	  @NamedQuery(name = "ShippedProduct.findpodateByorderid", query = "SELECT a FROM ShippedProduct a  WHERE a.orderId=:id"),
	  })

public class ShippedProduct implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name="id")
	private Integer id;
	@JoinColumn(name = "productId", referencedColumnName = "id")
	@ManyToOne
	private Products  productId; 
	@JoinColumn(name = "masterversionId", referencedColumnName = "id")
	@ManyToOne
	private MasterVersion masterversionId;
	@JoinColumn(name = "shippedfor", referencedColumnName = "id")
	@ManyToOne
	private AccountInfo shippedfor;
	@Basic(optional = false)
	@Column(name = "shippedunits")
	private Integer shippedunits;
	@Column(name = "ShippedDate")
	//@Temporal(TemporalType.TIMESTAMP)
	@Temporal(TemporalType.DATE)
	private java.util.Date shippeddate;
	@JoinColumn(name = "accountId", referencedColumnName = "id")
	@ManyToOne
	private AccountInfo accountId;
	@Basic(optional=false)
	@JoinColumn(name="createdBy", referencedColumnName="id")
	@ManyToOne
	private AccountLoginInfo createdBy;

	@JoinColumn(name="orderNumber", referencedColumnName="id")
	@ManyToOne
	private Order orderId;
	
	
	public Order getOrderId() {
		return orderId;
	}
	public void setOrderId(Order orderId) {
		this.orderId = orderId;
	}
	public AccountLoginInfo getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(AccountLoginInfo createdBy) {
		this.createdBy = createdBy;
	}
	public AccountInfo getAccountId() {
		return accountId;
	}
	public void setAccountId(AccountInfo accountId) {
		this.accountId = accountId;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Products getProductId() {
		return productId;
	}
	public void setProductId(Products productId) {
		this.productId = productId;
	}
	public MasterVersion getMasterversionId() {
		return masterversionId;
	}
	public void setMasterversionId(MasterVersion masterversionId) {
		this.masterversionId = masterversionId;
	}
	public AccountInfo getShippedfor() {
		return shippedfor;
	}
	public void setShippedfor(AccountInfo shippedfor) {
		this.shippedfor = shippedfor;
	}
	public Integer getShippedunits() {
		return shippedunits;
	}
	public void setShippedunits(Integer shippedunits) {
		this.shippedunits = shippedunits;
	}
	
	
	public java.util.Date getShippeddate() {
		return shippeddate;
	}
	public void setShippeddate(java.util.Date shippeddate) {
		this.shippeddate = shippeddate;
	}
	@Override
	public int hashCode() {
		int hash = 0;
		hash += (id != null ? id.hashCode() : 0);
		return hash;
	}
	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof ShippedProduct)) {
			return false;
		}
		ShippedProduct other = (ShippedProduct) obj;
		   boolean check=true;
	        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
	        	check= false;
	        }
	        return check;

	}



}
