/**
 * 
 */
package com.ng.sb.common.jms;

import java.util.Arrays;

import javax.jms.Session;

import org.apache.activemq.spring.ActiveMQConnectionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.core.JmsTemplate;

import com.ng.sb.common.dataobject.PlatformLoginData;

/**
 * @author gopal
 *
 */
@Configuration
public class MessagingConfiguration {

	@Autowired
	PlatformLoginData platformLoginData;
	
	//private static final String DEFAULT_BROKER_URL = "tcp://localhost:61616";
    
	private static final String DISTRIBUTION_QUEUE = "distribution-queue";
 
    @Bean
    public ActiveMQConnectionFactory connectionFactory(){
        ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory();
        String DEFAULT_BROKER_URL = platformLoginData.getJmsServerAddress();
        connectionFactory.setBrokerURL(DEFAULT_BROKER_URL);
        connectionFactory.setTrustedPackages(Arrays.asList("com.ng.sb.common.jms", "java"));
        connectionFactory.setSendAcksAsync(true);
        return connectionFactory;
    }
     
    @Bean				
    public JmsTemplate jmsTemplate(){
        JmsTemplate template = new JmsTemplate();
        template.setConnectionFactory(connectionFactory());
        template.setDefaultDestinationName(DISTRIBUTION_QUEUE);
        template.setSessionAcknowledgeMode(Session.AUTO_ACKNOWLEDGE);
        return template;
    }
}
