package com.ng.sb.common.dataobject;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

public class SEEntriesUploadData {


	private MultipartFile uploadedSEFile;
	
	List<SEInvoiceDetailsData> invoiceDetailsData;
	
	
	

	public MultipartFile getUploadedSEFile() {
		return uploadedSEFile;
	}

	public void setUploadedSEFile(MultipartFile uploadedSEFile) {
		this.uploadedSEFile = uploadedSEFile;
	}

	/**
	 * @return the invoiceDetailsData
	 */
	public List<SEInvoiceDetailsData> getInvoiceDetailsData() {
		return invoiceDetailsData;
	}

	/**
	 * @param invoiceDetailsData the invoiceDetailsData to set
	 */
	public void setInvoiceDetailsData(List<SEInvoiceDetailsData> invoiceDetailsData) {
		this.invoiceDetailsData = invoiceDetailsData;
	}

	
	
	
}
