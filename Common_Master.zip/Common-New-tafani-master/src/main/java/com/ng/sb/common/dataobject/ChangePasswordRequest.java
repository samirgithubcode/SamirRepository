package com.ng.sb.common.dataobject;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties
public class ChangePasswordRequest implements ValidationBean {
	
	private static final long serialVersionUID = 1399593624627585064L;

	private Integer userTypeId;
	private String currentPasswd;
	private String newPasswd;
	
	public Integer getUserTypeId() {
		return userTypeId;
	}
	public void setUserTypeId(Integer userTypeId) {
		this.userTypeId = userTypeId;
	}
	public String getCurrentPasswd() {
		return currentPasswd;
	}
	public void setCurrentPasswd(String currentPasswd) {
		this.currentPasswd = currentPasswd;
	}
	public String getNewPasswd() {
		return newPasswd;
	}
	public void setNewPasswd(String newPasswd) {
		this.newPasswd = newPasswd;
	}
	
	
}
