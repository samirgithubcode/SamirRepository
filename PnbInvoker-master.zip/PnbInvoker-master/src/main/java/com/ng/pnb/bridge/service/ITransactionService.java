/**
 * 
 */
package com.ng.pnb.bridge.service;

import com.ng.sb.common.dataobject.BridgeDataObject;
import com.ng.sb.common.dataobject.BridgeDataResponse;

/**
 * @author gopal
 *
 */
public interface ITransactionService {

	public BridgeDataResponse processRequest(BridgeDataObject requestData);
}
