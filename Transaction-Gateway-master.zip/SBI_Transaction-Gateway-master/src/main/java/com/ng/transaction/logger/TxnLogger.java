/**
 * 
 */
package com.ng.transaction.logger;


/**
 * @author gopal
 *
 */
public class TxnLogger extends Log4jImpl 
{
	TxnLogger(Class arg0) {
		super(arg0);
	}
	
	/**
	 * 
	 */
	private static TxnLogger loggerInstance;
    /**
     * This method return an instance of Logger class, if instance is already created then return that otherwise create new one.
     * @return Logger - Instance of Logger class
     */
	private static TxnLogger getInstance() {
    	if(loggerInstance == null) {
    		loggerInstance = new TxnLogger(TxnLogger.class);
    	}
    	return loggerInstance;
    }
    /**
     * This method is used to make logs.
     * @param className - Name of the class where Logger called
     * @param level - level of log like DEBUG,INFO,WARN......
     * @param message - Message which is about to log.
     */
	public static void log(String className, int level, String message) {
		getInstance().getLogger().log(debugLevels[level], "[" + className + "] " + debugLevels[level] + ": "+ message);
	}
}