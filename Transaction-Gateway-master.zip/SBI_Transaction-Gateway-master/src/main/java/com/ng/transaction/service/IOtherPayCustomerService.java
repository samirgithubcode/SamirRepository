/**
 * 
 */
package com.ng.transaction.service;

import com.ng.sb.common.dataobject.BridgeDataObject;

/**
 * @author gaurav
 *
 */
public interface IOtherPayCustomerService  extends IWalletService {
	
	public BridgeDataObject payIndividualBankToBank(BridgeDataObject bridgeDataObject);
	public BridgeDataObject payIndividualBankToWallet(BridgeDataObject bridgeDataObject);
	public BridgeDataObject payIndividualBankToCC(BridgeDataObject bridgeDataObject);
	public BridgeDataObject payIndividualBankToIMPS(BridgeDataObject bridgeDataObject);
	
	public BridgeDataObject payIndividualIMPSToBank(BridgeDataObject bridgeDataObject);
	public BridgeDataObject payIndividualIMPSToWallet(BridgeDataObject bridgeDataObject);
	public BridgeDataObject payIndividualIMPSToCC(BridgeDataObject bridgeDataObject);
	public BridgeDataObject payIndividualIMPSToIMPS(BridgeDataObject bridgeDataObject);
	
	public BridgeDataObject payIndividualCCToBank(BridgeDataObject bridgeDataObject);
	public BridgeDataObject payIndividualCCToWallet(BridgeDataObject bridgeDataObject);
	public BridgeDataObject payIndividualCCToCC(BridgeDataObject bridgeDataObject);
	public BridgeDataObject payIndividualCCToIMPS(BridgeDataObject bridgeDataObject);
	
	
	public BridgeDataObject payIndividualWalletToWallet(BridgeDataObject bridgeDataObject);
	public BridgeDataObject payIndividualWalletToBank(BridgeDataObject bridgeDataObject);
}
