function getInfo(){
	resetPassword();
		
}

function resetPassword(){
	
	
	var selectedRadioType=$("#selectedRadioTypeId").text().trim();
	var email=$("#emailOrUserId").val();
	var mobile=$("#emailOrUserId").val();
	var userName=$("#emailOrUserId").val();
	var completeCheck = true;
	if(!($('#email').is(":checked")) && (!($('#mobile').is(":checked"))) && (!($('#userName').is(":checked"))))
	{
		$('#resetByErrorId').html("");
		$('#resetByErrorId').html("<b><font color='red'>Kindly check atleast one radio button </font></b>");
		completeCheck = false;
	}
	if(($('#email').is(":checked")) && (!($('#mobile').is(":checked"))) && (!($('#userName').is(":checked"))))
	{
		if(email.length==0)
		{
		$('#lable_emailOrUserIdErrorId').html("<b><font color='red'>Kindly enter E-Mail</font></b>");
		completeCheck = false;
		}
		$("#tbodyid").empty();
		$.ajax({
			  url: 'getInfo',
			  type: 'post',
			  dataType: 'json',
			  data: 'email='+email,
			 success: function(response){
				$('#template_details').append('<tr><td align="right"  width="46%">Name :</td><td align="left"> &nbsp; '+response.name+'</td></tr>');
				$('#template_details').append('<tr><td align="right"  width="46%">Email :</td><td align="left"> &nbsp; '+response.emailId+'</td></tr>');
				$('#template_details').append('<tr><td align="right"  width="46%">Mobile Number :</td><td align="left"> &nbsp; '+response.mobileNo+'</td></tr>');
			 },
			 error: function(e) {
				
				  }
			
		});
		
		
	}
	if(!($('#email').is(":checked")) && (($('#mobile').is(":checked"))) && (!($('#userName').is(":checked"))))
	{
		if(mobile.length==0)
		{
		$('#lable_emailOrUserIdErrorId').html("<b><font color='red'>Kindly enter Mobile Number</font></b>");
		}
		$("#tbodyid").empty();
		$.ajax({
			  url: 'getInfoByMobile',
			  type: 'post',
			  dataType: 'json',
			  data: 'mobile='+mobile,
			 success: function(response){
				$('#template_details').append('<tr><td align="right"  width="46%">Name :</td><td align="left"> &nbsp; '+response.name+'</td></tr>');
				$('#template_details').append('<tr><td align="right"  width="46%">Email :</td><td align="left"> &nbsp; '+response.emailId+'</td></tr>');
				$('#template_details').append('<tr><td align="right"  width="46%">Mobile Number :</td><td align="left"> &nbsp; '+response.mobileNo+'</td></tr>');
			 },
			 error: function(e) {
				
				  }
			
		});
		
		
	}
	
	if(!($('#email').is(":checked")) && (!($('#mobile').is(":checked"))) && (($('#userName').is(":checked"))))
	{
		
		if(userName.length==0)
			{
			$('#lable_emailOrUserIdErrorId').html("<b><font color='red'>Kindly enter UserName</font></b>");
			//$('#resetByErrorId').html();
			//return false;
			}
		// $("#buttonId").attr("disabled", true);
		$("#tbodyid").empty();
		//$('#resetByErrorId').html("");
		$.ajax({
			  url: 'getInfoByUserName',
			  type: 'post',
			  dataType: 'json',
			  data: 'userName='+userName,
			 success: function(response){
			
				$('#template_details').append('<tr><td align="right"  width="46%">Name :</td><td align="left"> &nbsp; '+response.name+'</td></tr>');
				$('#template_details').append('<tr><td align="right"  width="46%">Email :</td><td align="left"> &nbsp; '+response.emailId+'</td></tr>');
				$('#template_details').append('<tr><td align="right"  width="46%">Mobile Number :</td><td align="left"> &nbsp; '+response.mobileNo+'</td></tr>');
				
					 },
			 error: function(e) {
				  }
			
		});
		
		
	}
	
	function refresh(){
		
		
	}
	
	//********************************* Check Radio Button ************************************************
	/*if(!($('#email').is(":checked")) && (!($('#mobile').is(":checked"))) && (!($('#userName').is(":checked"))))
	{
		$('#resetByErrorId').html("");
		$('#resetByErrorId').html("<b><font color='red'>Kindly check atleast one radio button </font></b>");
		completeCheck = false;
	}
	else{
		var emailMobileUserId=$("#emailOrUserId").val().trim();
		var selectedRadioType=$("#selectedRadioTypeId").text().trim();
		if(emailMobileUserId.length<=0){
			
			$("#lable_emailOrUserIdErrorId").html('<b><font color=red>Kindly Enter  '+selectedRadioType+ '</font></b>');
			 completeCheck = false;
		}
	}*/
}