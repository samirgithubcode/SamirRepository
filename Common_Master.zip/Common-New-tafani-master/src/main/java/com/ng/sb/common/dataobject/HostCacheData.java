package com.ng.sb.common.dataobject;

import java.io.Serializable;
import java.util.List;
import java.util.Map;


public class HostCacheData implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int hostId;
	private int hostType;
	private int hostTps;
	private String contantType;
	private Map<String, VersionDataObject> versionDataObjectMap;
	private List<String> hostIp;
	private int currentTps;
	private boolean smsgetwayStatus;
	private String tranDesKey;
	
	public int getHostId() {
		return hostId;
	}
	public void setHostId(int hostId) {
		this.hostId = hostId;
	}
	public int getHostType() {
		return hostType;
	}
	public void setHostType(int hostType) {
		this.hostType = hostType;
	}
	public int getHostTps() {
		return hostTps;
	}
	public void setHostTps(int hostTps) {
		this.hostTps = hostTps;
	}
	public String getContantType() {
		return contantType;
	}
	public void setContantType(String contantType) {
		this.contantType = contantType;
	}
	public Map<String, VersionDataObject> getVersionDataObjectMap() {
		return versionDataObjectMap;
	}
	public void setVersionDataObjectMap(
			Map<String, VersionDataObject> versionDataObjectMap) {
		this.versionDataObjectMap = versionDataObjectMap;
	}
	public List<String> getHostIp() {
		return hostIp;
	}
	public void setHostIp(List<String> hostIp) {
		this.hostIp = hostIp;
	}
	public int getCurrentTps() {
		return currentTps;
	}
	public void setCurrentTps(int currentTps) {
		this.currentTps = currentTps;
	}
	public boolean isSmsgetwayStatus() {
		return smsgetwayStatus;
	}
	public void setSmsgetwayStatus(boolean smsgetwayStatus) {
		this.smsgetwayStatus = smsgetwayStatus;
	}
	public String getTranDesKey() {
		return tranDesKey;
	}
	public void setTranDesKey(String tranDesKey) {
		this.tranDesKey = tranDesKey;
	}
}
