package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.*;

import java.sql.Timestamp;
import java.util.Date;


/**
 * The persistent class for the CustMerchFinInstMapping database table.
 * 
 */
@Entity
@Table(name="CustMerchFinInstMapping")
@NamedQueries({
@NamedQuery(name="CustMerchFinInstMapping.findAll", query="SELECT c FROM CustMerchFinInstMapping c"),
@NamedQuery(name="CustMerchFinInstMapping.findById", query="SELECT c FROM CustMerchFinInstMapping c WHERE c.id=:id"),
@NamedQuery(name="CustMerchFinInstMapping.removeByMerchantInfo", query="DELETE FROM CustMerchFinInstMapping c WHERE c.merchantId = :merchantId"),
@NamedQuery(name="CustMerchFinInstMapping.findByWalletIdAndWId", query ="SELECT c FROM CustMerchFinInstMapping c where c.wId= :wId AND c.walletId= :walletId"),
@NamedQuery(name="CustMerchFinInstMapping.findByMerchantIdandPartner", query ="SELECT c FROM CustMerchFinInstMapping c where c.merchantId= :merchantId AND c.wId= :wId"),
@NamedQuery(name="CustMerchFinInstMapping.findByWalletId", query ="SELECT c FROM CustMerchFinInstMapping c where c.walletId= :walletId"),
@NamedQuery(name="CustMerchFinInstMapping.findByMobileNumber", query ="SELECT c FROM CustMerchFinInstMapping c where c.walletId= :walletId"),
@NamedQuery(name="CustMerchFinInstMapping.findByCustomerId", query ="SELECT c FROM CustMerchFinInstMapping c where c.customerId= :customerId"),
@NamedQuery(name="CustMerchFinInstMapping.findByWalletCodeAndId", query ="SELECT c FROM CustMerchFinInstMapping c where c.walletId= :walletId AND c.wId= :wId"),
@NamedQuery(name="CustMerchFinInstMapping.findByWalletCode", query ="SELECT c FROM CustMerchFinInstMapping c where c.wId= :wId"),
})
public class CustMerchFinInstMapping implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false)
	private Integer id;

	@Column(name="balance")
	private Integer balance;

	@Column(name="bankAccountNo", length=30)
	private String bankAccountNo;

	@Column(name="cardHolderName", length=100)
	private String cardHolderName;

	@Column(name="creditCardNo")
	private Integer creditCardNo;

	@Column(name="expiryDate")
	private Date expiryDate;

	@Column(name="ifsc", length=30)
	private String ifsc;

	@Column(name="instrumentType", nullable=false, length=1)
	private String instrumentType;

	@Column(name="mmid")
	private int mmid;

	@Column(name="status", length=1)
	private String status;

	@Column(name="type", length=1)
	private String type;

	@Column(name="walletId", nullable=false, length=20)
	private String walletId;

	@Column(name="walletType", length=1)
	private String walletType;

	//bi-directional many-to-one association to Customer
	@ManyToOne
	@JoinColumn(name="customerId" , referencedColumnName="id")
	private Customer customerId;

	//bi-directional many-to-one association to MerchantInfo
	@ManyToOne
	@JoinColumn(name="merchantId" , referencedColumnName="id")
	private MerchantInfo merchantId;

	//bi-directional many-to-one association to Partner
	@ManyToOne
	@JoinColumn(name="wId")
	private Partner wId;

	public CustMerchFinInstMapping() {
		//empty
	}

	public CustMerchFinInstMapping(Integer id)
	{
		this.id = id;
	}
	
	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getBalance() {
		return this.balance;
	}

	public void setBalance(Integer balance) {
		this.balance = balance;
	}

	public String getBankAccountNo() {
		return this.bankAccountNo;
	}

	public void setBankAccountNo(String bankAccountNo) {
		this.bankAccountNo = bankAccountNo;
	}

	public String getCardHolderName() {
		return this.cardHolderName;
	}

	public void setCardHolderName(String cardHolderName) {
		this.cardHolderName = cardHolderName;
	}

	public int getCreditCardNo() {
		return this.creditCardNo;
	}

	public void setCreditCardNo(int creditCardNo) {
		this.creditCardNo = creditCardNo;
	}

	public Date getExpiryDate() {
		return this.expiryDate;
	}

	public void setExpiryDate(Timestamp expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getIfsc() {
		return this.ifsc;
	}

	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}

	public String getInstrumentType() {
		return this.instrumentType;
	}

	public void setInstrumentType(String instrumentType) {
		this.instrumentType = instrumentType;
	}

	public Integer getMmid() {
		return this.mmid;
	}

	public void setMmid(Integer mmid) {
		this.mmid = mmid;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getWalletId() {
		return this.walletId;
	}

	public void setWalletId(String walletId) {
		this.walletId = walletId;
	}

	public String getWalletType() {
		return this.walletType;
	}

	public void setWalletType(String walletType) {
		this.walletType = walletType;
	}

	public Customer getCustomerId() {
		return this.customerId;
	}

	public void setCustomerId(Customer customerId) {
		this.customerId = customerId;
	}

	public MerchantInfo getMerchantId() {
		return this.merchantId;
	}

	public void setMerchantId(MerchantInfo merchantId) {
		this.merchantId = merchantId;
	}

	public Partner getWId() {
		return this.wId;
	}

	public void setWId(Partner wId) {
		this.wId = wId;
	}

}