package com.ng.sb.common.cache;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.ng.sb.common.dataobject.CacheBean;

public class MyCache {
	private MyCache() {
		// default
	}
static Map<String,CacheBean> cacheBean=new ConcurrentHashMap<>();

public static void putInCache(String key,CacheBean bean){
	cacheBean.put(key, bean);
}
public static Map<String,CacheBean> getFromCache(){
	return cacheBean;
}
public static void removeFromCache(String key,CacheBean bean){
	cacheBean.clear();
}
}
