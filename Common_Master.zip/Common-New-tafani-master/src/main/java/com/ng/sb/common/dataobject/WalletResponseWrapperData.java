/**
 * 
 */
package com.ng.sb.common.dataobject;

/**
 * @author himanshu
 *
 */
public class WalletResponseWrapperData extends BaseObjectData{
	private static final long serialVersionUID = 1L;
	WalletResponseData walletResponseData;
	Boolean response;

	public Boolean getResponse() {
		return response;
	}

	public void setResponse(Boolean response) {
		this.response = response;
	}

	public WalletResponseData getWalletResponseData() {
		return walletResponseData;
	}

	public void setWalletResponseData(WalletResponseData walletResponseData) {
		this.walletResponseData = walletResponseData;
	}
	
}
