package com.ng.pnb.invoker.util;

public class ISOConstant 
{
	private ISOConstant(){}

	public static final String DATE_TIME_FORMAT = "MMddhhmmss";
	
	public static final String TIME_FORMAT = "hhmmss";
	
	public static final String DATE_FORMAT = "MMdd";
	
	public static final int PROCESS_CODE_INDEX = 3;
	
	public static final String PROCESS_CODE_BALNACE_ENQUIRY = "310000";
	
	public static final String PROCESS_CODE_MINI_STATEMENT = "380000";
	
	public static final String PROCESS_CODE_FUND_TRANSFER = "400000";
	
	public static final String PROCESS_CODE_TRANSFER_DEBIT = "480000";
	
	public static final String PROCESS_CODE_TRANSFER_CREDIT = "490000";
	
	public static final String PROCESS_CODE_BILL_PAYMENT = "510000";
	
	public static final String PROCESS_CODE_GENERAL_ACCOUNT_ENQUIRY = "820000";
	
	public static final String PROCESS_CODE_CHEQUE_STATUS = "940000";
	
	public static final String PROCESS_CODE_STOP_CHEQUE = "950000";
	
	/**
	 * Transaction Types
	 */
	
	public static final String DEBIT_TRANSACTION = "DR";
	
	public static final String CREDIT_TRANSACTION = "CR";
	
	public static final String OFF_US_FUND_TRANSFER = "OFF_US_FUND_TRANSFER : ";
	
	public static final String ON_US_FUND_TRANSFER = "ON_US_FUND_TRANSFER : ";
	
	public static final String BILL_PAY_FUND_TRANSFER = "BILL_PAY_FUND_TRANSFER : ";
	
	public static final String REFUND_AGAINST_FUND_TRANSFER = "REFUND_AGAINST_FUND_TRANSFER : ";
	
	public static final String LOG4J_FILE_PATH_KEY = "LOG4J_FILE_PATH";
	
	/*
	 * Fields Length
	 */
	
	public static final int SYSTEM_TRACE_AUDIT_NUMBER_LENGTH = 6;
	
	public static final int CUSTOMER_ID_LENGTH = 9;
	
	public static final int CUSTOMER_NAME_LENGTH = 80;
	
	public static final int ACCOUNT_NAME_LENGTH = 80;
	
	public static final int SCHEME_CODE_LENGTH = 5;
	
	public static final int OPERATION_CODE_LENGTH = 5;
	
	public static final int JOIN_HOLDER_NAME = 80;
	
	public static final int GL_SUB_HEAD_LENGTH = 5;
	
	public static final int ACCOUNT_SOL_ID_lENGTH = 8;
	
    public static final int DRAWING_POWER_LENGTH = 17;
	
	public static final int LEIN_AMOUNT_LENGTH = 17;
	
	public static final int ACCOUNT_BALANCE_LENGTH = 16;
	
	public static final String ACTIVE_STATUS = "ACTIVE";
}
