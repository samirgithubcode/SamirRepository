package com.ng.bridge.dataobject.eko;

public class HoldCommitTrnxRes {
	
	 private String responseTypeId;

	    private String message;

	    private String responseStatusId;

	    private String status;

	    private HoldCommitTrnxResData data;
	    
	    private InvalidParam invalidParam;

	    

	    public String getMessage ()
	    {
	        return message;
	    }

	    public void setMessage (String message)
	    {
	        this.message = message;
	    }

	    public String getResponseStatusId ()
	    {
	        return responseStatusId;
	    }

	    public void setResponseStatusId (String responseStatusId)
	    {
	        this.responseStatusId = responseStatusId;
	    }

	    public String getStatus ()
	    {
	        return status;
	    }

	    public void setStatus (String status)
	    {
	        this.status = status;
	    }

		public HoldCommitTrnxResData getData() {
			return data;
		}

		public void setData(HoldCommitTrnxResData data) {
			this.data = data;
		}

		public InvalidParam getInvalidParams() {
			return invalidParam;
		}

		public void setInvalidParams(InvalidParam invalidParams) {
			this.invalidParam = invalidParams;
		}
	    
		public String getResponseTypeId ()
	    {
	        return responseTypeId;
	    }

	    public void setResponseTypeId (String responseTypeId)
	    {
	        this.responseTypeId = responseTypeId;
	    } 
	 

	
}
