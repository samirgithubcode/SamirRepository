package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "product_vendor_mapping")
@XmlRootElement
@NamedQueries({
	@NamedQuery(name = "productvendor.getId", query = "SELECT a1 FROM ProductVendorMapping a1 where a1.vendorid=:vendorid and a1.productid=:productid" ),
	@NamedQuery(name="ProductVendorMapping.getAll",query="SELECT p FROM ProductVendorMapping p"),
	@NamedQuery(name="ProductVendorMapping.getById",query="SELECT p FROM ProductVendorMapping p WHERE p.id=:id"),
	//@NamedQuery(name="ProductVendorMapping.getProductVendors",query="SELECT p FROM ProductVendorMapping p WHERE p.vendorid.accountGroupId.id=:accountGroupId AND p.productid.id=:productId AND p.productid.type=:productType"),
	@NamedQuery(name="ProductVendorMapping.getProductVendors",query="SELECT p FROM ProductVendorMapping p WHERE p.vendorid.accountGroupId.id=:accountGroupId AND p.productid.id=:productId"),
	
})
public class ProductVendorMapping implements Serializable {
	    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

		@Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Basic(optional = false)
	    @Column(name = "id")
	    private Integer id;
	   
		@ManyToOne(optional = true)
		@JoinColumn(name="vendor_id", referencedColumnName="id")
		private AccountInfo vendorid;
		
		@ManyToOne(optional = true)
		@JoinColumn(name="product_id", referencedColumnName="id")
	     private Products productid;
	   
	  	   
	    @Column(name="created_by")
	    private Integer createdby;
	    
	    @Column(name="edited_by")
	    private Integer editedby;
	   
	    public static long getSerialversionuid() {
			return serialVersionUID;
		}

		@Column(name="create_on_date")
	    private Date createondate;
	   
	    @Column(name = "edit_on_date")
	    private Date editondate;
	    
	    
	    
	    public AccountInfo getVendorid() {
			return vendorid;
		}

		public void setVendorid(AccountInfo vendorid) {
			this.vendorid = vendorid;
		}

		public Products getProductid() {
			return productid;
		}

		public void setProductid(Products productid) {
			this.productid = productid;
		}

		public Integer getId() {
			return id;
		}

		public void setId(Integer id) {
			this.id = id;
		}

	

		public Integer getCreatedby() {
			return createdby;
		}

		public void setCreatedby(Integer createdby) {
			this.createdby = createdby;
		}

		public Integer getEditedby() {
			return editedby;
		}

		public void setEditedby(Integer editedby) {
			this.editedby = editedby;
		}

		public Date getCreateondate() {
			return createondate;
		}

		public void setCreateondate(Date createondate) {
			this.createondate = createondate;
		}

		public Date getEditondate() {
			return editondate;
		}

		public void setEditondate(Date editondate) {
			this.editondate = editondate;
		}

		
	    
	 
	
}
