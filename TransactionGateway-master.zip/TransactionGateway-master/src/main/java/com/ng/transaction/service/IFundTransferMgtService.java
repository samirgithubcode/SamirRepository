/**
 * 
 */
package com.ng.transaction.service;

/**
 * @author gaurav
 *
 */
public interface IFundTransferMgtService extends INonFundTransferBankingService {

}
