/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "PartnerFspServiceMapping")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "PartnerFspServiceMapping.findAll", query = "SELECT p FROM PartnerFspServiceMapping p"),
    @NamedQuery(name = "PartnerFspServiceMapping.findById", query = "SELECT p FROM PartnerFspServiceMapping p WHERE p.id = :id"),
    @NamedQuery(name = "PartnerFspServiceMapping.findByPartnerId", query = "SELECT p FROM PartnerFspServiceMapping p WHERE p.partnerId = :partnerId"),
    @NamedQuery(name = "PartnerFspServiceMapping.findByProviderIdAndRelationShipType", query = "SELECT p FROM PartnerFspServiceMapping p WHERE p.relationshipType = :relationshipType and p.fspServiceId =:fspServiceId"),
    @NamedQuery(name = "PartnerFspServiceMapping.findByServiceIdAndRelationShipType", query = "SELECT p FROM PartnerFspServiceMapping p WHERE p.relationshipType = :relationshipType and p.fspServiceId =:fspServiceId"),
    @NamedQuery(name = "PartnerFspServiceMapping.findByfspServiceId", query = "SELECT p FROM PartnerFspServiceMapping p WHERE  p.fspServiceId =:fspServiceId")
    
    //PartnerProviderMapping.findByProviderIdAndRelationShipType    
})
public class PartnerFspServiceMapping implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
    @JoinColumn(name = "partnerId", referencedColumnName = "id", nullable = false)
    @ManyToOne(optional = false)
    private Partner partnerId;
    @JoinColumn(name = "fspServiceId", referencedColumnName = "id", nullable = false)
    @ManyToOne(optional = false)
    private FSPServices fspServiceId;
    @Column(name = "relationshipType", length = 12)
    private String relationshipType;
    

    

	public PartnerFspServiceMapping() {
		//default constructor
    }

    public PartnerFspServiceMapping(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Partner getPartnerId() {
        return partnerId;
    }

    public void setPartnerId(Partner partnerId) {
        this.partnerId = partnerId;
    }

    public FSPServices getFspServiceId() {
        return fspServiceId;
    }

    public void setFspServiceId(FSPServices fspServiceId) {
        this.fspServiceId = fspServiceId;
    }
    
    public String getRelationshipType() {
		return relationshipType;
	}

	public void setRelationshipType(String relationshipType) {
		this.relationshipType = relationshipType;
	}

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof PartnerFspServiceMapping)) {
            return false;
        }
        PartnerFspServiceMapping other = (PartnerFspServiceMapping) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.PartnerFspServiceMapping[ id=" + id + " ]";
    }
    
}
