/**
 * 
 */
package com.ng.transaction.service;

import java.lang.reflect.InvocationTargetException;

import com.ng.sb.common.dataobject.BridgeDataObject;

/**
 * @author gaurav
 * Service Caller 
 */
public interface IServiceInvoker extends ITransactionService {
	public BridgeDataObject invoke(BridgeDataObject bridgeDataObject) throws IllegalAccessException,IllegalArgumentException,InvocationTargetException;
	
}
