/**
 * 
 */
package com.ng.transaction.util;

import java.util.Date;

import org.jpos.iso.ISOMsg;
import org.jpos.iso.ISOPackager;
import org.jpos.iso.packager.XMLPackager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.ng.pnb.bridge.service.ISocketService;
import com.ng.sb.common.dataobject.ResponseObject;
import com.ng.sb.common.model.CustomerDetails;
import com.ng.sb.common.util.KeyEncryptionUtils;
import com.ng.transaction.service.ISecureTransactionService;


/**
 * @author gopal
 *
 */
@Component
@Scope("prototype")
public class SyncingThread extends Thread {

	@Autowired
	ISocketService socketService;
	
	@Autowired
	ISecureTransactionService transactionService;
		
	private String customerId;
	
	
	public SyncingThread() 
	{
	     
	}
	
	@Override
	public void run() 
	{
		ISOPackager packager = null;
		ISOMsg response = null;
		ISOMsg request = null;
		
		try {

			packager = new XMLPackager();
			
			// Create ISO Message
			request = new ISOMsg();
			request.setPackager(packager);
				
			request.setMTI("1204");
				
			
			
			request.set(0, "1204");
			request.set(3, "820000"); //Processing Code
			request.set(4, "0000000000000000");
			
			request.set(11, "004207320085"); // 8 Length Unique Number
			request.set(12, KeyEncryptionUtils.dateToString(new Date(), "yyyyMMddHHmmss"));
			request.set(17, KeyEncryptionUtils.dateToString(new Date(), "yyyyMMdd"));
			request.set(24, "200");
			
			request.set(32, "504511");
			
			request.set(34, this.customerId); // 8 Length Unique Number
			
			request.set(41, "BANKAWAY"); // 8 Length Unique Number
			request.set(42, "BANKAWAY"); // External Number
			
			request.set(49, "INR");
			
			request.set(102, this.customerId);
			request.set(123, "CNN");
			
			response = socketService.submitNGetResponse(request);
			
			if(response != null)
			{
			   CustomerDetails customerDetails = new CustomerDetails();
				
			   String field48 = response.getString(48);
			   String field125 = response.getString(125);
			   
			   String field48Data[] = field48.split("\\+");
			   
			   String cardNumber = field48Data[1].split("-")[0];
			   String accountNumber = field48Data[1].split("-")[1];
			   String accountIFSC = field48Data[1].split("-")[2];
			   
			   customerDetails.setCardNumber(Long.parseLong(cardNumber));
			   customerDetails.setAccountNumber(accountNumber);
			   customerDetails.setIfscCode(accountIFSC);
			   
			   if(field125 != null)
			   {
				   String customerId = field125.substring(0, 9);
				   String customerName = field125.substring(9, (9+80));
				   String accountName =  field125.substring((9+80), (9+80+80));
				   String accountOpenDate = field125.substring((9+80+80), (9+80+80+8));
				   String schemeCode = field125.substring((9+80+80+8), (9+80+80+8+5));
				   String accountType = field125.substring((9+80+80+8+5), (9+80+80+8+5+3));
				   String accountStatus = field125.substring((9+80+80+8+5+3), (9+80+80+8+5+3+1));
				   String operationCode = field125.substring((9+80+80+8+5+3+1), (9+80+80+8+5+3+1+5));
				   String jointHolder1 = field125.substring((9+80+80+8+5+3+1+5), (9+80+80+8+5+3+1+5+80));
				   String jointHolder2 = field125.substring((9+80+80+8+5+3+1+5+80), (9+80+80+8+5+3+1+5+80+80));
				   String jointHolder3 = field125.substring((9+80+80+8+5+3+1+5+80+80), (9+80+80+8+5+3+1+5+80+80+80));
				   String subHeadCode = field125.substring((9+80+80+8+5+3+1+5+80+80+80), (9+80+80+8+5+3+1+5+80+80+80+5));
				   String accountSolId = field125.substring((9+80+80+8+5+3+1+5+80+80+80+5), (9+80+80+8+5+3+1+5+80+80+80+5+8));
				   String drawingPower = field125.substring((9+80+80+8+5+3+1+5+80+80+80+5+8), (9+80+80+8+5+3+1+5+80+80+80+5+8+17));
				   String lienAmount = field125.substring((9+80+80+8+5+3+1+5+80+80+80+5+8+17), (9+80+80+8+5+3+1+5+80+80+80+5+8+17+17));
				   
				   customerDetails.setCustomerId(customerId.trim());
				   customerDetails.setCustomerName(customerName.trim());
				   customerDetails.setAccountName(accountName.trim());
				 //  customerDetails.setAccountOpenDate(KeyEncryptionUtils.StringToDate(accountOpenDate, "yyyyMMdd"));
				   customerDetails.setSchemeCode(schemeCode.trim());
				   customerDetails.setAccountType(accountType.trim());
				   customerDetails.setAccountStatus(accountStatus.trim());
				   customerDetails.setOperationCode(operationCode.trim());
				   customerDetails.setJointHolderName1(jointHolder1.trim());
				   customerDetails.setJointHolderName2(jointHolder2.trim());
				   customerDetails.setJointHolderName3(jointHolder3.trim());
				   customerDetails.setSubHeadCode(subHeadCode.trim());
				   customerDetails.setAccountSoleId(accountSolId.trim());
				   customerDetails.setDrawingPower(drawingPower.trim());
				   customerDetails.setLienAmount(lienAmount);
				   
				   ResponseObject resp = transactionService.addCustomerDetails(customerDetails);
				   
				   System.out.println(resp.getStatus());
			   }
			}
			
			
	}catch(Exception e)
		{
		 e.printStackTrace();
		}

	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	
	
}
