/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "mvCatProvider")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "MasterVersionCategory.findAll", query = "SELECT m FROM MasterVersionCategory m"),
    @NamedQuery(name = "MasterVersionCategory.findBymvId", query = "SELECT m FROM MasterVersionCategory m WHERE m.mvId=:mvId"),
    @NamedQuery(name = "MasterVersionCategory.findById", query = "SELECT m FROM MasterVersionCategory m WHERE m.id = :id"),
    @NamedQuery(name = "MasterVersionCategory.findByAddDate", query = "SELECT m FROM MasterVersionCategory m WHERE m.addDate = :addDate"),
    @NamedQuery(name = "MasterVersionCategory.findByMvId", query = "SELECT m FROM MasterVersionCategory m WHERE m.mvId = :mvId"),
    @NamedQuery(name = "MasterVersionCategory.DeleteBymvId", query = "DELETE FROM MasterVersionCategory m WHERE m.mvId= :mvId"),
    })
public class MasterVersionCategory implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
   
    @Column(name = "providerName")
    private String providerName;
    
    @Column(name = "categoryName")
    private String categoryName;
    
    @Basic(optional = false)
    @Column(name = "addDate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date addDate;
    
    @JoinColumn(name = "providerId", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Provider providerId;
    
    @JoinColumn(name = "categoryId", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Categories categoryId;
    
    @JoinColumn(name = "mvId", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private MasterVersion mvId;

    public MasterVersionCategory() {
    	//empty
    }

    public MasterVersionCategory(Integer id) {
        this.id = id;
    }

    public MasterVersionCategory(Integer id, Date addDate) {
        this.id = id;
        this.addDate = addDate;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    

    public String getProviderName() {
        return providerName;
    }

    public void setProviderName(String providerName) {
        this.providerName = providerName;
    }
    
    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public Date getAddDate() {
        return addDate;
    }

    public void setAddDate(Date addDate) {
        this.addDate = addDate;
    }

    public Provider getProviderId() {
        return providerId;
    }

    public void setProviderId(Provider providerId) {
        this.providerId = providerId;
    }

    public Categories getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Categories categoryId) {
        this.categoryId = categoryId;
    }

    public MasterVersion getMvId() {
        return mvId;
    }

    public void setMvId(MasterVersion mvId) {
        this.mvId = mvId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof MasterVersionCategory)) {
            return false;
        }
        MasterVersionCategory other = (MasterVersionCategory) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.MasterVersionCategory[ id=" + id + " ]";
    }
    
}