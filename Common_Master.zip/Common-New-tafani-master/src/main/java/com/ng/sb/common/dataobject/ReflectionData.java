/**
 * 
 */
package com.ng.sb.common.dataobject;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

/**
 * @author gaurav
 *
 */
public class ReflectionData extends BaseObjectData {

	private static final long serialVersionUID = 1L;
	private Method method;
	private Object classIdentifier;
	private Map<String, Method> methodMap = new HashMap<>();
	private String className;
	public ReflectionData() {
		//default constructor
	}

	public ReflectionData(String className, Object classIdentifier,Map<String, Method> methodMap) {
		this.className = className;
		this.methodMap = methodMap;
		this.classIdentifier=classIdentifier;
	}

	public ReflectionData(Object classIdentifier,Method method) {
		this.classIdentifier = classIdentifier;
		this.method = method;
	}
	public Map<String, Method> getMethodMap() {
		return methodMap;
	}

	public void setMethodMap(Map<String, Method> methodMap) {
		this.methodMap = methodMap;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public Method getMethod() {
		return method;
	}

	public void setMethod(Method method) {
		this.method = method;
	}

	public Object getClassIdentifier() {
		return classIdentifier;
	}

	public void setClassIdentifier(Object classIdentifier) {
		this.classIdentifier = classIdentifier;
	}

}
