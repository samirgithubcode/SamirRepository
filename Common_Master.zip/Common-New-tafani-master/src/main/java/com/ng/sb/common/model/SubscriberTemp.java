/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "Subscriber_temp")
@XmlRootElement
@NamedQueries({
	@NamedQuery(name = "Subscriber_temp.findByMsisdn", query = "SELECT s FROM SubscriberTemp s WHERE s.msisdn = :msisdn"),
	@NamedQuery(name = "Subscriber_temp.findBySubsAndOTP", query = "SELECT s FROM SubscriberTemp s WHERE s.msisdn = :msisdn AND s.userOtp=:user_otp"),
})
public class SubscriberTemp implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Column(name = "mobileCode")
    private Integer mobileCode;
    @Basic(optional = false)
    @Column(name = "msisdn")
    private String msisdn;
    @Column(name = "name")
    private String name;
    @Column(name = "surname")
    private String surname;
    @Column(name = "dateOfBirth")
    @Temporal(TemporalType.DATE)
    private Date dateOfBirth;
    @Column(name = "emailId")
    private String emailId;
    @Column(name = "addDate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date addDate;
    @Column(name = "editDate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date editDate;
    @Column(name = "status")
    private String status;
    @Column(name = "custId")
    private String custId;
    @Column(name = "agent_id")
    private Integer agentId;
    @Column(name = "user_otp")
    private Integer userOtp;
    @ManyToOne
	@JoinColumn(name="bank_id", referencedColumnName="id")
	private Banks bankId;
    @Column(name = "wallet_type_id")
    private String walletTypeId;
    
    @Column(name = "access_channel")
    private Integer accessChannel;
    public SubscriberTemp() {
    	//default constructor
    }

    public SubscriberTemp(Integer id) {
        this.id = id;
    }

    public SubscriberTemp(Integer id, String msisdn, String name, Date addDate, String status) {
        this.id = id;
        this.msisdn = msisdn;
        this.name = name;
        this.addDate = addDate;
        this.status = status;
    }
    public Integer getAccessChannel() {
		return accessChannel;
	}
	public void setAccessChannel(Integer accessChannel) {
		this.accessChannel = accessChannel;
	}
	public Banks getBankId() {
		return bankId;
	}
	public void setBankId(Banks bankId) {
		this.bankId = bankId;
	}

    public Integer getUserOtp() {
		return userOtp;
	}

	public void setUserOtp(Integer userOtp) {
		this.userOtp = userOtp;
	}

	public Integer getAgentId() {
		return agentId;
	}

	public void setAgentId(Integer agentId) {
		this.agentId = agentId;
	}

	public String getWalletTypeId() {
		return walletTypeId;
	}

	public void setWalletTypeId(String walletTypeId) {
		this.walletTypeId = walletTypeId;
	}

	

  

    

    public Integer getMobileCode() {
        return mobileCode;
    }

    public void setMobileCode(Integer mobileCode) {
        this.mobileCode = mobileCode;
    }
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
    public String getMsisdn() {
        return msisdn;
    }

    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }



    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

	

    public Date getAddDate() {
        return addDate;
    }

    public void setAddDate(Date addDate) {
        this.addDate = addDate;
    }
    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }
    public Date getEditDate() {
        return editDate;
    }

    public void setEditDate(Date editDate) {
        this.editDate = editDate;
    }
	public String getCustId() {
		return custId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}
	public String getStatus() {
	        return status;
	}

	public void setStatus(String status) {
	        this.status = status;
	   }

	@Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
    	boolean check=false;
    	if(object!=null){
        if (!(object instanceof SubscriberTemp)) {
        	check= false;
        }
        SubscriberTemp other = (SubscriberTemp) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
    	}
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.Subscriber_temp[ id=" + id + " ]";
    }
    
}
