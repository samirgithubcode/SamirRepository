/**
 * 
 */
package com.ng.sb.common.dataobject;

import java.util.List;

import com.ng.sb.common.model.BoxSize;

public class OrderShipData extends BaseObjectData {
	private static final long serialVersionUID = 1L;

	private Integer productId;
	private String productName;
	private String orderNumber;
	private Integer orderId;
	private Integer mvId;
	private String mvName;
	private String successMessage;
	private String errorMessage;
	private Integer orderQty;
	private Integer orderShippedQty;
	private Integer orderPendingQty;
	private String toAccountName;
	private String fromAccountName;
	private String orderDate;
	private String shippingDate;
	private List<OrderShipData> selectedBoxList;
	private String selectedBoxInfo;
	private String challanNumber;
	private String fromRange;
	private String toRange;
	private Integer totalBoxCount;
	private Integer availableBoxCount;
	private Integer totalSeCount;
	private String boxStartRange;
	private String boxEndRange;
	private String boxNumber;
	private BoxSize boxQtyType;
	private Integer availableStock;

	public Integer getTotalSeCount() {
		return totalSeCount;
	}

	public void setTotalSeCount(Integer totalSeCount) {
		this.totalSeCount = totalSeCount;
	}

	public String getChallanNumber() {
		return challanNumber;
	}

	public void setChallanNumber(String challanNumber) {
		this.challanNumber = challanNumber;
	}

	public Integer getOrderQty() {
		return orderQty;
	}

	public void setOrderQty(Integer orderQty) {
		this.orderQty = orderQty;
	}

	public String getFromRange() {
		return fromRange;
	}

	public void setFromRange(String fromRange) {
		this.fromRange = fromRange;
	}

	public String getToRange() {
		return toRange;
	}

	public void setToRange(String toRange) {
		this.toRange = toRange;
	}

	public Integer getTotalBoxCount() {
		return totalBoxCount;
	}

	public void setTotalBoxCount(Integer totalBoxCount) {
		this.totalBoxCount = totalBoxCount;
	}

	public Integer getAvailableBoxCount() {
		return availableBoxCount;
	}

	public void setAvailableBoxCount(Integer availableBoxCount) {
		this.availableBoxCount = availableBoxCount;
	}

	public String getBoxStartRange() {
		return boxStartRange;
	}

	public void setBoxStartRange(String boxStartRange) {
		this.boxStartRange = boxStartRange;
	}

	public String getBoxEndRange() {
		return boxEndRange;
	}

	public void setBoxEndRange(String boxEndRange) {
		this.boxEndRange = boxEndRange;
	}

	public String getBoxNumber() {
		return boxNumber;
	}

	public void setBoxNumber(String boxNumber) {
		this.boxNumber = boxNumber;
	}

	public BoxSize getBoxQtyType() {
		return boxQtyType;
	}

	public void setBoxQtyType(BoxSize boxSize) {
		this.boxQtyType = boxSize;
	}

	public Integer getAvailableStock() {
		return availableStock;
	}

	public void setAvailableStock(Integer availableStock) {
		this.availableStock = availableStock;
	}

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public Integer getMvId() {
		return mvId;
	}

	public void setMvId(Integer mvId) {
		this.mvId = mvId;
	}

	public String getMvName() {
		return mvName;
	}

	public void setMvName(String mvName) {
		this.mvName = mvName;
	}

	public String getSuccessMessage() {
		return successMessage;
	}

	public void setSuccessMessage(String successMessage) {
		this.successMessage = successMessage;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public Integer getOrderShippedQty() {
		return orderShippedQty;
	}

	public void setOrderShippedQty(Integer orderShippedQty) {
		this.orderShippedQty = orderShippedQty;
	}

	public Integer getOrderPendingQty() {
		return orderPendingQty;
	}

	public void setOrderPendingQty(Integer orderPendingQty) {
		this.orderPendingQty = orderPendingQty;
	}

	public String getToAccountName() {
		return toAccountName;
	}

	public void setToAccountName(String toAccountName) {
		this.toAccountName = toAccountName;
	}

	public String getFromAccountName() {
		return fromAccountName;
	}

	public void setFromAccountName(String fromAccountName) {
		this.fromAccountName = fromAccountName;
	}

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	public String getShippingDate() {
		return shippingDate;
	}

	public void setShippingDate(String shippingDate) {
		this.shippingDate = shippingDate;
	}

	public List<OrderShipData> getSelectedBoxList() {
		return selectedBoxList;
	}

	public void setSelectedBoxList(List<OrderShipData> selectedBoxList) {
		this.selectedBoxList = selectedBoxList;
	}

	public String getSelectedBoxInfo() {
		return selectedBoxInfo;
	}

	public void setSelectedBoxInfo(String selectedBoxInfo) {
		this.selectedBoxInfo = selectedBoxInfo;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
