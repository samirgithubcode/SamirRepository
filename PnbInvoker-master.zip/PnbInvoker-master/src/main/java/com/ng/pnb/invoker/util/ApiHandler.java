/**
 * 
 */
package com.ng.pnb.invoker.util;

import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.net.ssl.SSLContext;

import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLContexts;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.ng.sb.common.dataobject.BankAccount;
import com.ng.sb.common.dataobject.BridgeDataObject;
import com.ng.sb.common.dataobject.BridgeDataResponse;
import com.ng.sb.common.dataobject.BridgeDataResponse.Status;
import com.ng.sb.common.dataobject.ResponseObject;
import com.ng.sb.common.util.CommonUtils;


/**
 * @author gopal
 *
 */
@Component("apiHandler")
public class ApiHandler 
{

	public BridgeDataResponse processChequeStatus(BridgeDataObject bridgeDataObject)
	{
		return null;
	}
	
	public BridgeDataResponse processBankBalanceCheck(BridgeDataObject bridgeDataObject) 
	{
		System.out.println(">>>>>>>>> Process balance check <<<<<<<<<<<<");
		BridgeDataResponse response = new BridgeDataResponse();
	 
		try{
			
			BankAccount payerBankAccount = bridgeDataObject.getPayerBankAccount();
			
			String accountNumber = payerBankAccount.getAccountNumber();
			String userId = payerBankAccount.getUserId();
			String userPwd = payerBankAccount.getbPin();
			
			
			String requestUri = "https://finacle.evoncloud.com/fintech/rest/v1/banks/AUS/users/" + userId +"/accounts/operativeaccounts/" + CommonUtils.getFormattedAccountNumber(accountNumber);
			
		    String encodedAuth = getAuthToken(userId, userPwd);
		    
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set("authorization", encodedAuth);
			
			
			RestTemplate restTemplate = getRestTemplate();
		     
			HttpEntity<String> entity = new HttpEntity<>("parameters", headers);
			
		    ResponseEntity<BalanceEnquiryResponse> respEntity = restTemplate.exchange(requestUri, HttpMethod.GET, entity, BalanceEnquiryResponse.class);
		    
		    BalanceEnquiryResponse balanceResponse = respEntity.getBody();
		    
		    Message responsemessage = balanceResponse.getHeader().getStatus().getMessage().get(0);
		    
		    System.out.println(" responsemessage : "+responsemessage);
		    
		    if(responsemessage.getMessageCode().equals("0000")){
		    	
				response.setMsidnToSendMsg(bridgeDataObject.getTransactionData().getMsisdn());
				
				String balance = String.valueOf(balanceResponse.getData().getAvailableBalance().getAmount());
					
				String maskedAccountNum= getMaskedAccountNumber(accountNumber);
					
				response.setResponseMsg("Your account " + maskedAccountNum + "  has balance of " + balanceResponse.getData().getAvailableBalance().getCurrency() + " " + balance);
					
				System.out.println(" Response Message : "+response.getResponseMsg());
				bridgeDataObject.setBridgeResponse(response);
				
				 response = bridgeDataObject.getBridgeResponse();
				 response.setStatus(Status.SUCCESS);
		    }
		    else{
		    	
		    	createErrorResponse(bridgeDataObject);
		    	
		    	response = bridgeDataObject.getBridgeResponse();
				response.setStatus(Status.FAILED);
		    }
		}
	    catch(Exception e)
		{
			createErrorResponse(bridgeDataObject);
			
			response = bridgeDataObject.getBridgeResponse();
			response.setStatus(Status.FAILED);
			
		}
		
		return response;
	}
	
	public BridgeDataResponse processWalletBalanceCheck(BridgeDataObject bridgeDataObject) 
	{
		return null;
	}
	
	public BridgeDataResponse processBankingTxnHistory(BridgeDataObject bridgeDataObject) 
	{
		
		BridgeDataResponse response = new BridgeDataResponse();
		
		response.setMsidnToSendMsg(bridgeDataObject.getTransactionData().getMsisdn());
		
		try{
		     BankAccount payerBankAccount = bridgeDataObject.getPayerBankAccount();
					
			 String accountNumber = payerBankAccount.getAccountNumber();
			 String userId = payerBankAccount.getUserId();
			 String userPwd = payerBankAccount.getbPin();
			 
			 String requestUri = "https://finacle.evoncloud.com/fintech/rest/v1/banks/AUS/users/" + userId +"/accounts/operativeaccounts/" + CommonUtils.getFormattedAccountNumber(accountNumber) + "/ministatement";
				
			 String encodedAuth = getAuthToken(userId, userPwd);
			    
		     System.out.println(encodedAuth);
			
			 HttpHeaders headers = new HttpHeaders();
			 headers.setContentType(MediaType.APPLICATION_JSON);
			 headers.set("authorization", encodedAuth);
			
			 RestTemplate restTemplate = getRestTemplate();
		     
			 HttpEntity<String> entity = new HttpEntity<>("parameters", headers);
			
		     ResponseEntity<MiniStatementResponse> respEntity = restTemplate.exchange(requestUri, HttpMethod.GET, entity, MiniStatementResponse.class);
		    
		     MiniStatementResponse miniStatementResponse = respEntity.getBody() ;
		     
		     Message responsemessage = miniStatementResponse.getHeader().getStatus().getMessage().get(0);

		     System.out.println(" responsemessage : "+responsemessage);
		     
		     if(responsemessage.getMessageCode().equals("0000")){
			    
		    	 List<TransactionData> data = miniStatementResponse.getData();
		    	 
		    	 StringBuilder miniStatementSb = new StringBuilder();
		    	 
		    	 for(TransactionData td : data){
		    		 miniStatementSb.append(td.getOverlayFormat()).append("\n");
		    	 }
		    	 
		    	 response.setResponseMsg(miniStatementSb.toString());
		    	 
		    	 System.out.println(" Response Message  : "+response.getResponseMsg());
		    	 
		    	 bridgeDataObject.setBridgeResponse(response);
		    	 
		    	 response = bridgeDataObject.getBridgeResponse();
					
		     }
		     else{
		    	
		    	createErrorResponse(bridgeDataObject);
		    	
		    	response = bridgeDataObject.getBridgeResponse();
				response.setStatus(Status.FAILED);
		     }

		}
	    catch(Exception e)
		{
			createErrorResponse(bridgeDataObject);
			
			response = bridgeDataObject.getBridgeResponse();
			response.setStatus(Status.FAILED);
			
		}
		
		return response;
	}
	
	public BridgeDataResponse processUtilityPaymentsFromBank(BridgeDataObject bridgeDataObject) 
	{
		return null;
	}
	
	public BridgeDataResponse processFundTransferWalletToBank(BridgeDataObject bridgeDataObject) 
	{
		return null;
	}
	
	public BridgeDataResponse processFundTransferBankToWallet(BridgeDataObject bridgeDataObject) 
	{
		return null;
	}
	
	public BridgeDataResponse processFundTransferBankToBank(BridgeDataObject bridgeDataObject) 
	{
		System.out.println(">>>>>>>>>>>>> processFundTransferBankToBank <<<<<<<<<<<<<<<<");
		BridgeDataResponse response = new BridgeDataResponse();
		
		response.setMsidnToSendMsg(bridgeDataObject.getTransactionData().getMsisdn());
		
		try{
			
			BankAccount payerBankAccount = bridgeDataObject.getPayerBankAccount();
			BankAccount payeeBankAccount = bridgeDataObject.getPayeeBankAccount();
			
			String payerAccountNumber = payerBankAccount.getAccountNumber();
			String userId = payerBankAccount.getUserId();
			String userPwd = payerBankAccount.getbPin();
			
			String payeeAccountNumber = payeeBankAccount.getAccountNumber();
			 
			String maskedAccountNumPayer= getMaskedAccountNumber(payerAccountNumber);
			String maskedAccountNumPayee= getMaskedAccountNumber(payeeAccountNumber);
			
			double transactionAmount = bridgeDataObject.getAmount();
			String networkType = "WIB";
			String transactionDate = getFormatedDate();
			String transactionType = "XFR";
			
			
			String transactionCurrency = "AUD";
		    String frequencyType = "O";
		    String transactionRemarks = "Nextgen Testing";
		    
		    String requestUri = "https://finacle.evoncloud.com/fintech/rest/v1/banks/AUS/users/"+userId+"/transactionsrequests/transfers";
			
			FundTransferData fundTransferData = new FundTransferData();
			
			TransactionDetails transactionDetails = new TransactionDetails();
			
			transactionDetails.setFromAccountId(CommonUtils.getFormattedAccountNumber(payerAccountNumber));		
			transactionDetails.setNetworkType(networkType);
			transactionDetails.setToAccountId(CommonUtils.getFormattedAccountNumber(payeeAccountNumber));		
			transactionDetails.setTransactionAmount(transactionAmount);
			transactionDetails.setTransactionDate(transactionDate);
			transactionDetails.setTransactionType(transactionType);
			
			AdditionalDetails additionalDetails = new AdditionalDetails();
			
			additionalDetails.setFrequencyType(frequencyType);
			additionalDetails.setTransactionCurrency(transactionCurrency);
			additionalDetails.setTransactionRemarks(transactionRemarks);
			
			fundTransferData.setAdditionalDetails(additionalDetails);
			fundTransferData.setTransactionDetails(transactionDetails);
			
			
			FundTransferRequest fundTransferRequest = new FundTransferRequest();
			fundTransferRequest.setData(fundTransferData);
			
			String encodedAuth = getAuthToken(userId, userPwd);
	        
	        HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set("authorization", encodedAuth);
			
			HttpEntity<FundTransferRequest> request = new HttpEntity<>(fundTransferRequest, headers);
			
			RestTemplate restTemplate = getRestTemplate();
			
			try{
				restTemplate.postForEntity(requestUri, request, String.class);
			}catch(Exception ex){
				//ex.printStackTrace();
			}
		
			String acceptTermsAndConditions = "Y";
			String primaryAccessCode = "1234";
			String secondaryAccessCode = "";
			
			AuthorizationDetails authorizationDetails = new AuthorizationDetails();
			
			authorizationDetails.setAcceptTermsAndConditions(acceptTermsAndConditions);
			authorizationDetails.setPrimaryAccessCode(primaryAccessCode);
			authorizationDetails.setSecondaryAccessCode(secondaryAccessCode);
			authorizationDetails.setUserId(userId);
			
			FTHeader header = new FTHeader();
			header.setAuthorizationDetails(authorizationDetails);
			
			
			fundTransferRequest.setHeader(header);
			
			request = new HttpEntity<>(fundTransferRequest, headers);
			
			ResponseEntity<FundTransferResponse> respEntity = restTemplate.postForEntity(requestUri, request, FundTransferResponse.class);
			
			int reqeustStatus = respEntity.getStatusCode().value();
			System.out.println("Status ================== :" + respEntity);
//			FundTransferResponse fundTransferResponse = respEntity.getBody() ;
		     
//		    String responseCode = fundTransferResponse.getData().getResponseData().getResponseCode();

		//	ResponseEntity<String> respEntity = restTemplate.postForEntity(requestUri, request, String.class);
			
			System.out.println("Fund Transfer Request:" + respEntity);
		    
			/*ObjectMapper mapper = new ObjectMapper();
			
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
					
			FundTransferResponse fundTransferResponse = mapper.convertValue(respEntity.getBody(), FundTransferResponse.class);*/
			
			// String responseCode = fundTransferResponse.getData().getResponseData().getResponseCode();
		    
		     if(reqeustStatus == 201 || reqeustStatus == 200){
			    
		    	 response.setResponseMsg(PnbConstants.AC + maskedAccountNumPayer + "  has been debited successfully with AUD "+ bridgeDataObject.getAmount()+" for Fund transfer to "+ PnbConstants.AC_NO + maskedAccountNumPayee);
		    	 
		    	 System.out.println(" Response Message  : "+response.getResponseMsg());
		    	 
		    	 bridgeDataObject.setBridgeResponse(response);
		    	 
		    	 response = bridgeDataObject.getBridgeResponse();
					
		     }
		     else{
		    	
		    	createErrorResponse(bridgeDataObject);
		    	
		    	response = bridgeDataObject.getBridgeResponse();
				response.setStatus(Status.FAILED);
		     }

		}
		catch(Exception e)
		{
			createErrorResponse(bridgeDataObject);
			
			e.printStackTrace();
			response = bridgeDataObject.getBridgeResponse();
			response.setStatus(Status.FAILED);
			
		}
		
		return response;
	}
	
	public ResponseObject processRestRequest(String requestUri, String requstObject)
	{
		RestTemplate restTemplate = new RestTemplate();
		
		ResponseEntity<ResponseObject> response = restTemplate.postForEntity(requestUri, requstObject, ResponseObject.class);
		
		return response.getBody();
	}
	
	public ResponseObject processSOAPRequest(String requestUri, String requstObject)
	{
		RestTemplate restTemplate = new RestTemplate();
		
		ResponseEntity<ResponseObject> response = restTemplate.postForEntity(requestUri, requstObject, ResponseObject.class);
		
		return response.getBody();
	}
	
	
	private String getAuthToken(String userPrincipal, String accessCode){
		
		String requestUri = "https://finacle.evoncloud.com/oauth/token";
		
		/*if(userPrincipal != null && userPrincipal.equalsIgnoreCase("PATRICK"))
			accessCode = "d@@demo";*/
		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		
		MultiValueMap<String, String> map= new LinkedMultiValueMap<>();
		
		map.add("grant_type", "password");
		map.add("BANK_ID", "AUS");
		map.add("LANGUAGE_ID", "001");
		map.add("CHANNEL_ID", "I");
		map.add("LOGIN_FLAG", "1");
		map.add("USER_PRINCIPAL", userPrincipal);
		map.add("ACCESS_CODE", accessCode);
		map.add("STATEMODE", "N");
		map.add("client_id", "finacle");
		map.add("client_secret", "finacle123");
		map.add("LOGIN_TYPE", "1");
		
		HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(map, headers);
		
		RestTemplate restTemplate = getRestTemplate();
		
		ResponseEntity<TokenResponse> response = restTemplate.postForEntity(requestUri, request , TokenResponse.class);
		
		TokenResponse tokenResponse = response.getBody();
		
		System.out.println("Token Response:" + tokenResponse);
		
		return tokenResponse.getAccess_token();
	}
	
	public String getMaskedAccountNumber(String acNo){
		String acNoToSend="";
		if(acNo==null){
			//ToDo
		}
		if(acNo!=null && !acNo.isEmpty() && acNo.length()>=4){
			String endAcNo = acNo.substring(acNo.length()-4, acNo.length());
			String initialAcNo="";
			for(int i=0;i<acNo.length()-4;i++){
					initialAcNo=initialAcNo+"X";	
			}
			acNoToSend=initialAcNo+endAcNo;
		}
		
		if(acNo!=null && acNo.length()<4){
			acNoToSend=acNo;
		}
		return acNoToSend;
	}
	
	public void createErrorResponse(BridgeDataObject bridgeDataObject)
	{
		BridgeDataResponse response = new BridgeDataResponse();
		response.setResponseMsg("Sorry, System is under maintenance, please try after some time");
		response.setMsidnToSendMsg(bridgeDataObject.getTransactionData().getMsisdn());
		bridgeDataObject.setBridgeResponse(response);
	}
	
	private String getFormatedDate(){
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss");
		
		return format.format(new Date());
	}
	
	public RestTemplate getRestTemplate()  {
	    try {
			TrustStrategy acceptingTrustStrategy = new TrustStrategy() {
			    @Override
			    public boolean isTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
			        return true;
			    }
			};
			SSLContext sslContext = SSLContexts.custom().loadTrustMaterial(null, acceptingTrustStrategy).build();
			SSLConnectionSocketFactory csf = new SSLConnectionSocketFactory(sslContext);
			CloseableHttpClient httpClient = HttpClients.custom().setSSLSocketFactory(csf).build();
			HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
			requestFactory.setHttpClient(httpClient);
			RestTemplate restTemplate = new RestTemplate(requestFactory);
			return restTemplate;
		} catch (KeyManagementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (KeyStoreException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    return new RestTemplate();
	}
}
