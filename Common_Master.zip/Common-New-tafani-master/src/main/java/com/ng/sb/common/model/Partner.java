/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Collection;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "Partner")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Partner.findAll", query = "SELECT p FROM Partner p"),
    @NamedQuery(name = "Partner.findById", query = "SELECT p FROM Partner p WHERE p.id = :id"),
    @NamedQuery(name = "Partner.findByName", query = "SELECT p FROM Partner p WHERE p.name = :name"),
    @NamedQuery(name = "Partner.findByPartnerCode", query = "SELECT p FROM Partner p WHERE p.partnerCode = :partnerCode"),
    @NamedQuery(name = "Partner.findByNickName", query = "SELECT p FROM Partner p WHERE p.nickName = :nickName"),
    @NamedQuery(name = "Partner.findByMode", query = "SELECT p FROM Partner p WHERE p.mode = :mode"),
    @NamedQuery(name = "Partner.findByFundTransferFSP", query = "SELECT p FROM Partner p WHERE p.fundTransferFSP = :fundTransferFSP"),
    @NamedQuery(name = "Partner.findByProviderFSP", query = "SELECT p FROM Partner p WHERE p.providerFSP = :providerFSP"),
    @NamedQuery(name = "Partner.findByType", query = "SELECT p FROM Partner p WHERE p.type = :type"),
    @NamedQuery(name = "Partner.findByTypeAndHostId", query = "SELECT p FROM Partner p WHERE p.type = :type  and p.hostId =:hostId"),
    @NamedQuery(name = "Partner.findByMappingName", query = "SELECT count(*) FROM Partner p WHERE p.mappingName =:mappingName"),
    @NamedQuery(name = "Partner.findByMaxCode", query = "SELECT p.partnerCode FROM Partner p ORDER BY p.partnerCode DESC"),
    @NamedQuery(name = "Partner.findAllInternalWallets", query = "SELECT p FROM Partner p WHERE p.walletType = :walletType"),
    @NamedQuery(name = "Partner.findByIdAndMappingName", query = "SELECT count(*) FROM Partner p WHERE p.mappingName =:mappingName and p.id =:id")
})
public class Partner implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
    
    @Basic(optional = false)
    @Column(name = "partnerCode", nullable = false)
    private Integer partnerCode;
    @Basic(optional = false)
    @Column(name = "name", nullable = false, length = 40)
    private String name;
    @Column(name = "nickName", length = 40)
    private String nickName;
    @Basic(optional = false)
    @Column(name = "mode", nullable = false, length = 7)
    private String mode;
    @Basic(optional = false)
    @Column(name = "fundTransferFSP", nullable = false)
    private Integer fundTransferFSP;
    @Basic(optional = false)
    @Column(name = "providerFSP", nullable = false)
    private Integer providerFSP;
    @Basic(optional = false)
    @Column(name = "type", nullable = false, length = 16)
    private String type;
    @Basic(optional = false)
    @Column(name="mappingName")
    private String mappingName;
    @Column(name="branchCode")
    private String branchCode;
    @Column(name="accountNumber")
    private String accountNumber;
    @Column(name="walletType")
    private String walletType;
	@OneToMany(mappedBy = "partnerId")
    private Collection<CommFinInstrumentMapping> commConfFinInstrumentMappingCollection;
    @OneToMany(mappedBy = "partnerId")
    private Collection<HostSVProviderPartnerMapping> hostSVProviderPartnerMappingCollection;
    @OneToMany(mappedBy = "walletId")
    private Collection<HostSVWalletMapping> hostSVWalletMappingCollection;
    @OneToMany(mappedBy = "partnerId")
    private Collection<HostSVFinInstrumentPartnerMapping> hostSVFinInstrumentPartnerMappingCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "walletId")
    private Collection<SubscriberWallet> subscriberWalletCollection;
    @OneToMany(mappedBy = "partnerId" , fetch = FetchType.EAGER)
    @Fetch(FetchMode.SELECT)
    private Collection<PartnerFspServiceMapping> partnerFspServiceMappingCollection;
    @OneToMany(mappedBy = "walletId")
    private Collection<MerchantDetail> merchantDetailCollection;
    @OneToMany( mappedBy = "partnerId", fetch = FetchType.EAGER)
    @Fetch(FetchMode.SELECT)
    private Collection<PartnerBankMapping> partnerBankMappingCollection;
    @OneToMany(mappedBy = "partnerId", fetch = FetchType.EAGER)
    @Fetch(FetchMode.SELECT)
    private Collection<PartnerProviderMapping> partnerProviderMappingCollection;
    @OneToMany(mappedBy = "partnerId")
    private Collection<CommProvPartMapping> commConfProvPartMappingCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "parentPartnerId")
    private Collection<Partner> partnerCollection;
    @JoinColumn(name = "parentPartnerId", referencedColumnName = "id")
    @ManyToOne
    private Partner parentPartnerId;
    @JoinColumn(name = "hostId", referencedColumnName = "id")
    @ManyToOne
    private AccountInfo hostId;
    @OneToMany(mappedBy = "partnerId")
    private Collection<HostSVFspServicesPartnerMapping> hostSVFspServicesPartnerMappingCollection;
    @OneToMany(mappedBy = "partnerId", fetch = FetchType.EAGER)
    @Fetch(FetchMode.SELECT)
    private Collection<PartnerFinInstrumentMapping> partnerFinInstrumentMappingCollection;
    @OneToMany(mappedBy = "partnerId")
    private Collection<CommFspServiceMapping> commConfFspServiceMappingCollection;

    public Partner() {
    	//empty
    }

    public Partner(Integer id) {
        this.id = id;
    }

    public Partner(Integer id, String name, int partnerCode, String mode, int fundTransferFSP, int providerFSP, String type) {
        this.id = id;
        this.name = name;
        this.partnerCode = partnerCode;
        this.mode = mode;
        this.fundTransferFSP = fundTransferFSP;
        this.providerFSP = providerFSP;
        this.type = type;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPartnerCode() {
        return partnerCode;
    }

    public void setPartnerCode(int partnerCode) {
        this.partnerCode = partnerCode;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    public int getFundTransferFSP() {
        return fundTransferFSP;
    }

    public void setFundTransferFSP(int fundTransferFSP) {
        this.fundTransferFSP = fundTransferFSP;
    }

    public int getProviderFSP() {
        return providerFSP;
    }

    public void setProviderFSP(int providerFSP) {
        this.providerFSP = providerFSP;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getMappingName() {
		return mappingName;
	}

	public void setMappingName(String mappingName) {
		this.mappingName = mappingName;
	}
	
	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	
	public String getWalletType() {
		return walletType;
	}

	public void setWalletType(String walletType) {
		this.walletType = walletType;
	}

	
    @XmlTransient
    public Collection<CommFinInstrumentMapping> getCommConfFinInstrumentMappingCollection() {
        return commConfFinInstrumentMappingCollection;
    }

    public void setCommConfFinInstrumentMappingCollection(Collection<CommFinInstrumentMapping> commConfFinInstrumentMappingCollection) {
        this.commConfFinInstrumentMappingCollection = commConfFinInstrumentMappingCollection;
    }

    @XmlTransient
    public Collection<HostSVProviderPartnerMapping> getHostSVProviderPartnerMappingCollection() {
        return hostSVProviderPartnerMappingCollection;
    }

    public void setHostSVProviderPartnerMappingCollection(Collection<HostSVProviderPartnerMapping> hostSVProviderPartnerMappingCollection) {
        this.hostSVProviderPartnerMappingCollection = hostSVProviderPartnerMappingCollection;
    }

    @XmlTransient
    public Collection<HostSVWalletMapping> getHostSVWalletMappingCollection() {
        return hostSVWalletMappingCollection;
    }

    public void setHostSVWalletMappingCollection(Collection<HostSVWalletMapping> hostSVWalletMappingCollection) {
        this.hostSVWalletMappingCollection = hostSVWalletMappingCollection;
    }

    @XmlTransient
    public Collection<HostSVFinInstrumentPartnerMapping> getHostSVFinInstrumentPartnerMappingCollection() {
        return hostSVFinInstrumentPartnerMappingCollection;
    }

    public void setHostSVFinInstrumentPartnerMappingCollection(Collection<HostSVFinInstrumentPartnerMapping> hostSVFinInstrumentPartnerMappingCollection) {
        this.hostSVFinInstrumentPartnerMappingCollection = hostSVFinInstrumentPartnerMappingCollection;
    }

    @XmlTransient
    public Collection<SubscriberWallet> getSubscriberWalletCollection() {
        return subscriberWalletCollection;
    }

    public void setSubscriberWalletCollection(Collection<SubscriberWallet> subscriberWalletCollection) {
        this.subscriberWalletCollection = subscriberWalletCollection;
    }

    @XmlTransient
    public Collection<PartnerFspServiceMapping> getPartnerFspServiceMappingCollection() {
        return partnerFspServiceMappingCollection;
    }

    public void setPartnerFspServiceMappingCollection(Collection<PartnerFspServiceMapping> partnerFspServiceMappingCollection) {
        this.partnerFspServiceMappingCollection = partnerFspServiceMappingCollection;
    }

    @XmlTransient
    public Collection<MerchantDetail> getMerchantDetailCollection() {
        return merchantDetailCollection;
    }

    public void setMerchantDetailCollection(Collection<MerchantDetail> merchantDetailCollection) {
        this.merchantDetailCollection = merchantDetailCollection;
    }

    @XmlTransient
    public Collection<PartnerBankMapping> getPartnerBankMappingCollection() {
        return partnerBankMappingCollection;
    }

    public void setPartnerBankMappingCollection(Collection<PartnerBankMapping> partnerBankMappingCollection) {
        this.partnerBankMappingCollection = partnerBankMappingCollection;
    }

    @XmlTransient
    public Collection<PartnerProviderMapping> getPartnerProviderMappingCollection() {
        return partnerProviderMappingCollection;
    }

    public void setPartnerProviderMappingCollection(Collection<PartnerProviderMapping> partnerProviderMappingCollection) {
        this.partnerProviderMappingCollection = partnerProviderMappingCollection;
    }

    @XmlTransient
    public Collection<CommProvPartMapping> getCommConfProvPartMappingCollection() {
        return commConfProvPartMappingCollection;
    }

    public void setCommConfProvPartMappingCollection(Collection<CommProvPartMapping> commConfProvPartMappingCollection) {
        this.commConfProvPartMappingCollection = commConfProvPartMappingCollection;
    }

    @XmlTransient
    public Collection<Partner> getPartnerCollection() {
        return partnerCollection;
    }

    public void setPartnerCollection(Collection<Partner> partnerCollection) {
        this.partnerCollection = partnerCollection;
    }

    public Partner getParentPartnerId() {
        return parentPartnerId;
    }

    public void setParentPartnerId(Partner parentPartnerId) {
        this.parentPartnerId = parentPartnerId;
    }

    public AccountInfo getHostId() {
        return hostId;
    }

    public void setHostId(AccountInfo hostId) {
        this.hostId = hostId;
    }

    @XmlTransient
    public Collection<HostSVFspServicesPartnerMapping> getHostSVFspServicesPartnerMappingCollection() {
        return hostSVFspServicesPartnerMappingCollection;
    }

    public void setHostSVFspServicesPartnerMappingCollection(Collection<HostSVFspServicesPartnerMapping> hostSVFspServicesPartnerMappingCollection) {
        this.hostSVFspServicesPartnerMappingCollection = hostSVFspServicesPartnerMappingCollection;
    }

    @XmlTransient
    public Collection<PartnerFinInstrumentMapping> getPartnerFinInstrumentMappingCollection() {
        return partnerFinInstrumentMappingCollection;
    }

    public void setPartnerFinInstrumentMappingCollection(Collection<PartnerFinInstrumentMapping> partnerFinInstrumentMappingCollection) {
        this.partnerFinInstrumentMappingCollection = partnerFinInstrumentMappingCollection;
    }

    @XmlTransient
    public Collection<CommFspServiceMapping> getCommConfFspServiceMappingCollection() {
        return commConfFspServiceMappingCollection;
    }

    public void setCommConfFspServiceMappingCollection(Collection<CommFspServiceMapping> commConfFspServiceMappingCollection) {
        this.commConfFspServiceMappingCollection = commConfFspServiceMappingCollection;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.Partner[ id=" + id + " ]";
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof Partner)) {
            return false;
        }
        Partner other = (Partner) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }
    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

   
    
}
