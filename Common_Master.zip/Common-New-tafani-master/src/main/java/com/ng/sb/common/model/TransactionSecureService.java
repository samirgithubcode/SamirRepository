package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
@Table(name="transactionService")
@NamedQueries({
	 @NamedQuery(name="TransactionSecureService.findAll", query="SELECT t FROM TransactionSecureService t"),
	 @NamedQuery(name = "TransactionSecureService.findById", query = "SELECT t FROM TransactionSecureService t where t.id = :id"),
	 @NamedQuery(name = "TransactionSecureService.findForTelco", query = "SELECT t FROM TransactionSecureService t where t.payerTelcoId = :payerTelcoId AND t.transactionType = :transactionType AND  t.transationDate >= :fromDate AND t.transationDate <= :toDate "),
	 @NamedQuery(name = "TransactionSecureService.findForPartner", query = "SELECT t FROM TransactionSecureService t where t.partnerId = :partnerId AND t.transactionType = :transactionType AND  t.transationDate >= :fromDate AND t.transationDate <= :toDate "),
})
public class TransactionSecureService implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false)
	private Integer id;
	
	@Column(name="initiator", length=100)
	private String initiator;
	
	@Column(name="payerWalletCode", length=100)
	private Integer payerWalletCode;
	
	@Column(name="payerWalletId", length=100)
	private String payerWalletId;
	
	@Column(name="payeeWalletCode", length=100)
	private Integer payeeWalletCode;
	
	@Column(name="payeeWalletId", length=100)
	private String payeeWalletId;
	
	@Column(name="transactionType", length=100)
	private String transactionType;
	
	@Column(name="debitAmount", length=100)
	private Integer debitAmount;
	
	@Column(name="creditAmount", length=100)
	private Integer creditAmount;
	
	@Column(name="hostTransactionId", length=100)
	private String hostTransactionId;
	
	@Column(name="subscriberId", length=100)
	private String subscriberId;
	
	@Column(name="payerTransactionId", length=100)
	private String payerTransactionId;
	
	@Column(name="payeeTransactionId", length=100)
	private String payeeTransactionId;
	
	@Column(name="providerCode", length=100)
	private Integer providerCode;
	
	@JoinColumn(name = "providerId", referencedColumnName = "id")
	@ManyToOne
	private Provider providerId;
	
	@JoinColumn(name = "payerTelcoId", referencedColumnName = "id")
	@ManyToOne
	private MerchantInfo payerTelcoId;
	
	@JoinColumn(name = "partnerId", referencedColumnName = "id")
	@OneToOne(optional = false)
    private Partner partnerId;	
	
	@Column(name="status", length=100)
	private String status;
	
	@Basic(optional = false)
	@Column(name = "transationDate")
	@Temporal(TemporalType.TIMESTAMP)
	private Date transationDate;
	public String getPayeeWalletId() {
		return payeeWalletId;
	}
	public void setPayeeWalletId(String payeeWalletId) {
		this.payeeWalletId = payeeWalletId;
	}
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getInitiator() {
		return initiator;
	}

	public void setInitiator(String initiator) {
		this.initiator = initiator;
	}

	public Integer getPayerWalletCode() {
		return payerWalletCode;
	}

	public void setPayerWalletCode(Integer payerWalletCode) {
		this.payerWalletCode = payerWalletCode;
	}

	public String getPayerWalletId() {
		return payerWalletId;
	}

	public void setPayerWalletId(String payerWalletId) {
		this.payerWalletId = payerWalletId;
	}

	public Integer getPayeeWalletCode() {
		return payeeWalletCode;
	}

	public void setPayeeWalletCode(Integer payeeWalletCode) {
		this.payeeWalletCode = payeeWalletCode;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public Integer getDebitAmount() {
		return debitAmount;
	}

	public void setDebitAmount(Integer debitAmount) {
		this.debitAmount = debitAmount;
	}

	public Integer getCreditAmount() {
		return creditAmount;
	}

	public void setCreditAmount(Integer creditAmount) {
		this.creditAmount = creditAmount;
	}

	public String getHostTransactionId() {
		return hostTransactionId;
	}

	public void setHostTransactionId(String hostTransactionId) {
		this.hostTransactionId = hostTransactionId;
	}

	public String getPayerTransactionId() {
		return payerTransactionId;
	}

	public void setPayerTransactionId(String payerTransactionId) {
		this.payerTransactionId = payerTransactionId;
	}

	public String getPayeeTransactionId() {
		return payeeTransactionId;
	}

	public void setPayeeTransactionId(String payeeTransactionId) {
		this.payeeTransactionId = payeeTransactionId;
	}

	public Integer getProviderCode() {
		return providerCode;
	}

	public void setProviderCode(Integer providerCode) {
		this.providerCode = providerCode;
	}

	public Provider getProviderId() {
		return providerId;
	}

	public void setProviderId(Provider providerId) {
		this.providerId = providerId;
	}

	public Partner getPartnerId() {
		return partnerId;
	}

	public void setPartnerId(Partner partnerId) {
		this.partnerId = partnerId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getTransationDate() {
		return transationDate;
	}

	public void setTransationDate(Date transationDate) {
		this.transationDate = transationDate;
	}

	public String getSubscriberId() {
		return subscriberId;
	}

	public void setSubscriberId(String subscriberId) {
		this.subscriberId = subscriberId;
	}

	public MerchantInfo getPayerTelcoId() {
		return payerTelcoId;
	}

	public void setPayerTelcoId(MerchantInfo payerTelcoId) {
		this.payerTelcoId = payerTelcoId;
	}

	
		

}
