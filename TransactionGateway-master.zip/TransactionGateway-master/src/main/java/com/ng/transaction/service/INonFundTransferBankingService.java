/**
 * 
 */
package com.ng.transaction.service;

import com.ng.sb.common.dataobject.BridgeDataObject;

/**
 * @author gaurav
 *
 */
public interface INonFundTransferBankingService extends ITransactionService {
	public BridgeDataObject balanceEnquiry(BridgeDataObject bridgeDataObject);
	public BridgeDataObject chequeBookRequest(BridgeDataObject bridgeDataObject);
	public BridgeDataObject chequeStatus(BridgeDataObject bridgeDataObject);
	public BridgeDataObject stopCheque(BridgeDataObject bridgeDataObject);
	public BridgeDataObject last5Transaction(BridgeDataObject bridgeDataObject);
}
