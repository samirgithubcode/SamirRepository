/**
 * 
 */
package com.ng.pnb.bridge.iso;

import org.jpos.iso.ISOException;
import org.jpos.iso.ISOMsg;

import com.ng.sb.common.dataobject.BridgeDataObject;

/**
 * @author gaurav
 *
 */
public interface IISOMessageCreator 
{
	public ISOMsg createBalEnquiryMessage(BridgeDataObject bridgeDataObject) throws ISOException ;
	public ISOMsg createMiniStatementMessage(BridgeDataObject bridgeDataObject) throws ISOException ;
	public ISOMsg createFundTransferMessage(BridgeDataObject bridgeDataObject) throws ISOException ;
	public ISOMsg createFundDebitMessage(BridgeDataObject bridgeDataObject, String transactionDetails) throws ISOException ;
	public ISOMsg createChequeStatusMessage(BridgeDataObject bridgeDataObject) throws ISOException ;
	public ISOMsg createStopChequeMessage(BridgeDataObject bridgeDataObject) throws ISOException ;
	public ISOMsg createFundCreditMessage(BridgeDataObject bridgeDataObject, String transactionDetails) throws ISOException ;
	
	public ISOMsg createWalletDebitMessage(BridgeDataObject bridgeDataObject, String transactionDetails) throws ISOException ;
	public ISOMsg createWalletCreditMessage(BridgeDataObject bridgeDataObject, String transactionDetails) throws ISOException ;
	public ISOMsg createWalletBalanceEnquiryMessage(BridgeDataObject bridgeDataObject) throws ISOException ;
	public ISOMsg createWalletFundTransfer(BridgeDataObject bridgeDataObject) throws ISOException ;
	public ISOMsg createWalletBillPay(BridgeDataObject bridgeDataObject) throws ISOException ;
	public ISOMsg createWalletMiniStatementMessage(BridgeDataObject bridgeDataObject) throws ISOException ;

}
