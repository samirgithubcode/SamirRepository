package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the custMerchTransaction database table.
 * 
 */
@Entity
@Table(name="custMerchTransaction")
@NamedQueries({
@NamedQuery(name="CustMerchTransaction.findAll", query="SELECT c FROM CustMerchTransaction c"),
@NamedQuery(name="CustMerchTransaction.findAllOrderByDate", query="SELECT c FROM CustMerchTransaction c ORDER BY c.id DESC"),
@NamedQuery(name="CustMerchTransaction.findByTransactionId", query="SELECT c FROM CustMerchTransaction c WHERE c.transactionId=:transactionId"),
@NamedQuery(name="CustMerchTransaction.findByPreviousTransactionId", query="SELECT c FROM CustMerchTransaction c WHERE c.clientTransactionId=:clientTransactionId"),
@NamedQuery(name="CustMerchTransaction.findByTransactionIdOurId", query="SELECT c FROM CustMerchTransaction c WHERE c.transactionId=:transactionId AND c.status=:status"),
@NamedQuery(name="CustMerchTransaction.findByPreviousTransactionIdAndStatus", query="SELECT c FROM CustMerchTransaction c WHERE c.clientTransactionId=:clientTransactionId AND c.status=:status AND c.transactionType=:transactionType"),
})
public class CustMerchTransaction implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false)
	private Integer id;
	@Column(name="clientBusinessDate")
	private String clientBusinessDate;

	@Column(name="clientCounterNo")
	private String clientCounterNo;

	@Column(name="clientStoreId")
	private String clientStoreId;

	@Column(name="clientTransactionId")
	private String clientTransactionId;

	@Column(name="contactNumber")
	private String contactNumber;

	@Column(name="ip")
	private String ip;

	@Column(name="otp")
	private Integer otp;

	@Column(name="payeeWalletBalAftrTxn")
	private Integer payeeWalletBalAftrTxn;

	@Column(name="payeeWalletBalBfrTxn")
	private Integer payeeWalletBalBfrTxn;

	@Column(name="payerWalletBalAftrTxn")
	private Integer payerWalletBalAftrTxn;

	@Column(name="payerWalletBalBfrTxn")
	private Integer payerWalletBalBfrTxn;

	@Column(name="status")
	private String status;

	@Column(name="transactionAmount")
	private Integer transactionAmount;

	@Column(name="transactionId")
	private String transactionId;

	@Column(name="transactionInitiator")
	private String transactionInitiator;

	@Column(name="transactionType")
	private String transactionType;

	@Column(name="walletTxnType")
	private String walletTxnType;

	@Column(name="walletType")
	private String walletType;

	//bi-directional many-to-one association to MerchantInfo
	@ManyToOne
	@JoinColumn(name="payerMerchantId")
	private MerchantInfo payermerchantId;

	//bi-directional many-to-one association to Customer
	@ManyToOne
	@JoinColumn(name="payeeCustId")
	private Customer payeeCustId;

	//bi-directional many-to-one association to MerchantInfo
	@ManyToOne
	@JoinColumn(name="payeeMerchantId")
	private MerchantInfo payeeMerchantId;

	//bi-directional many-to-one association to Customer
	@ManyToOne
	@JoinColumn(name="payerCustId")
	private Customer payerCustId;

	 @Column(name = "updationDate")
	 @Temporal(TemporalType.DATE)
	 private Date updationDate;
	 
	 @ManyToOne(cascade = {CascadeType.ALL},fetch= FetchType.EAGER)
	 @JoinColumn(name="poolTxnId")
	 private CustMerchPoolTransaction poolTxnId;


	
	@Column(name="clientOpId")
	private String clientOpId;
	@ManyToOne
	@JoinColumn(name="payeeWalletId")
	private CustMerchFinInstMapping payeeWalletId;
	
	@ManyToOne
	@JoinColumn(name="payerWalletId")
	private CustMerchFinInstMapping payerWalletId;

	public CustMerchTransaction() {
		/*
		 * 
		 */
	}

	public String getClientOpId() {
		return clientOpId;
	}

	public void setClientOpId(String clientOpId) {
		this.clientOpId = clientOpId;
	}

		
	public CustMerchPoolTransaction getPoolTxnId() {
		return poolTxnId;
	}

	public void setPoolTxnId(CustMerchPoolTransaction poolTxnId) {
		this.poolTxnId = poolTxnId;
	}

	public Date getUpdationDate() {
		return updationDate;
	}

	public void setUpdationDate(Date updationDate) {
		this.updationDate = updationDate;
	}

	public CustMerchFinInstMapping getPayeeWalletId() {
		return payeeWalletId;
	}

	public void setPayeeWalletId(CustMerchFinInstMapping payeeWalletId) {
		this.payeeWalletId = payeeWalletId;
	}

	public CustMerchFinInstMapping getPayerWalletId() {
		return payerWalletId;
	}

	public void setPayerWalletId(CustMerchFinInstMapping payerWalletId) {
		this.payerWalletId = payerWalletId;
	}

	
	
	
	

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	


	public String getClientBusinessDate() {
		return clientBusinessDate;
	}

	public void setClientBusinessDate(String clientBusinessDate) {
		this.clientBusinessDate = clientBusinessDate;
	}

	public String getClientCounterNo() {
		return this.clientCounterNo;
	}

	public void setClientCounterNo(String clientCounterNo) {
		this.clientCounterNo = clientCounterNo;
	}

	

	public String getClientTransactionId() {
		return this.clientTransactionId;
	}

	public void setClientTransactionId(String clientTransactionId) {
		this.clientTransactionId = clientTransactionId;
	}

	public String getClientStoreId() {
		return this.clientStoreId;
	}

	public void setClientStoreId(String clientStoreId) {
		this.clientStoreId = clientStoreId;
	}
	
	

	public String getIp() {
		return this.ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getContactNumber() {
		return this.contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	
	public Integer getOtp() {
		return this.otp;
	}

	public void setOtp(Integer otp) {
		this.otp = otp;
	}

	public Integer getPayeeWalletBalAftrTxn() {
		return this.payeeWalletBalAftrTxn;
	}

	public void setPayeeWalletBalAftrTxn(Integer payeeWalletBalAftrTxn) {
		this.payeeWalletBalAftrTxn = payeeWalletBalAftrTxn;
	}

	public Integer getPayeeWalletBalBfrTxn() {
		return this.payeeWalletBalBfrTxn;
	}

	public void setPayeeWalletBalBfrTxn(Integer payeeWalletBalBfrTxn) {
		this.payeeWalletBalBfrTxn = payeeWalletBalBfrTxn;
	}

	public Integer getPayerWalletBalAftrTxn() {
		return this.payerWalletBalAftrTxn;
	}

	public void setPayerWalletBalAftrTxn(Integer payerWalletBalAftrTxn) {
		this.payerWalletBalAftrTxn = payerWalletBalAftrTxn;
	}

	public Integer getPayerWalletBalBfrTxn() {
		return this.payerWalletBalBfrTxn;
	}

	public void setPayerWalletBalBfrTxn(Integer payerWalletBalBfrTxn) {
		this.payerWalletBalBfrTxn = payerWalletBalBfrTxn;
	}

	

	public Integer getTransactionAmount() {
		return this.transactionAmount;
	}

	public void setTransactionAmount(Integer transactionAmount) {
		this.transactionAmount = transactionAmount;
	}
	
	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getTransactionId() {
		return this.transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public String getTransactionInitiator() {
		return this.transactionInitiator;
	}

	public void setTransactionInitiator(String transactionInitiator) {
		this.transactionInitiator = transactionInitiator;
	}

	public String getTransactionType() {
		return this.transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getWalletTxnType() {
		return this.walletTxnType;
	}

	public void setWalletTxnType(String walletTxnType) {
		this.walletTxnType = walletTxnType;
	}

	public String getWalletType() {
		return this.walletType;
	}

	public void setWalletType(String walletType) {
		this.walletType = walletType;
	}

	public MerchantInfo getPayerMerchantId() {
		return this.payermerchantId;
	}

	public void setPayerMerchantId(MerchantInfo payermerchantId) {
		this.payermerchantId = payermerchantId;
	}

	public Customer getPayeeCustomerId() {
		return this.payeeCustId;
	}

	public void setPayeeCustomerId(Customer payeeCustId) {
		this.payeeCustId = payeeCustId;
	}

	public MerchantInfo getPayeeMerchantId() {
		return this.payeeMerchantId;
	}

	public void setPayeeMerchantId(MerchantInfo payeeMerchantId) {
		this.payeeMerchantId = payeeMerchantId;
	}

	public Customer getPayerCustomerId() {
		return this.payerCustId;
	}

	public void setPayerCustomerId(Customer payerCustId) {
		this.payerCustId = payerCustId;
	}

	

}