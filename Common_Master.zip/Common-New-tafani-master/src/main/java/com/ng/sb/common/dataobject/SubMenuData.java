package com.ng.sb.common.dataobject;

public class SubMenuData  extends BaseObjectData {

	private static final long serialVersionUID = 1L;
	private String subMenuName;
	private String action;

	
	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getSubMenuName() {
		return subMenuName;
	}

	public void setSubMenuName(String subMenuName) {
		this.subMenuName = subMenuName;
	}
}
