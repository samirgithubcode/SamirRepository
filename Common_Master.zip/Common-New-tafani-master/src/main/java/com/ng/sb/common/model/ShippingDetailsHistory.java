package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the ShippingDetailsHistory database table.
 * 
 */
@Entity
@Table(name="ShippingDetailsHistory")
@NamedQuery(name="ShippingDetailsHistory.findAll", query="SELECT s FROM ShippingDetailsHistory s")
public class ShippingDetailsHistory implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(unique=true, nullable=false)
	private Integer id;

	@Column(name="boxNumber")
	private String boxNumber;

	@Column(name="boxSrsFrom")
	private String boxSrsFrom;

	@Column(name="boxSrsTo")
	private String boxSrsTo;

	
	
	@Basic(optional=true) 
	@ManyToOne
	@JoinColumn(name="shippingDetailId")
	private ShippingDetail shippingDetailId;
	
	@Column(name="unitsReceived")
	private Integer unitsReceived;

	//bi-directional many-to-one association to OrderDetail
	@ManyToOne
	@JoinColumn(name="orderDetailId")
	private OrderDetail orderDetailId;
	
	
	

	public ShippingDetailsHistory() {
		//empty
	}
	
	public ShippingDetailsHistory(Integer id) {
		this.id = id;
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getBoxNumber() {
		return this.boxNumber;
	}

	public void setBoxNumber(String boxNumber) {
		this.boxNumber = boxNumber;
	}

	public String getBoxSrsFrom() {
		return this.boxSrsFrom;
	}

	public void setBoxSrsFrom(String boxSrsFrom) {
		this.boxSrsFrom = boxSrsFrom;
	}

	public String getBoxSrsTo() {
		return this.boxSrsTo;
	}

	public void setBoxSrsTo(String boxSrsTo) {
		this.boxSrsTo = boxSrsTo;
	}


	public ShippingDetail getShippingDetailId() {
		return this.shippingDetailId;
	}

	public void setShippingDetailId(ShippingDetail shippingDetailId) {
		this.shippingDetailId = shippingDetailId;
	}

	public Integer getUnitsReceived() {
		return this.unitsReceived;
	}

	public void setUnitsReceived(Integer unitsReceived) {
		this.unitsReceived = unitsReceived;
	}

	public OrderDetail getOrderDetailId() {
		return this.orderDetailId;
	}

	public void setOrderDetailId(OrderDetail orderDetailId) {
		this.orderDetailId = orderDetailId;
	}

	@Override
	public String toString() {
		return "ShippingDetailsHistory [id=" + id + "]";
	}
}