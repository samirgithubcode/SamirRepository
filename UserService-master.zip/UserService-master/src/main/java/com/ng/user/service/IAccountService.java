/**
 * 
 */
package com.ng.user.service;

import com.ng.sb.common.dataobject.ResponseObject;
import com.ng.user.dto.BalanceRequest;
import com.ng.user.dto.TxnHistoryRequest;

/**
 * @author gopal
 *
 */
public interface IAccountService {

	public ResponseObject getTxnHistory(TxnHistoryRequest txnHistoryRequest);
	
	public ResponseObject getAccountBalance(BalanceRequest balanceRequest);
}
