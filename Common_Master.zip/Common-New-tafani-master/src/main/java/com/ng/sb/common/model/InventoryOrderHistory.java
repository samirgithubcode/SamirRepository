/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author amardeep
 */
@Entity
@Table(name = "inventoryOrderHistory")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "InventoryOrderHistory.findAll", query = "SELECT i FROM InventoryOrderHistory i"),
    @NamedQuery(name = "InventoryOrderHistory.findById", query = "SELECT i FROM InventoryOrderHistory i WHERE i.id = :id"),
    @NamedQuery(name = "InventoryOrderHistory.findByOrderNumber", query = "SELECT i FROM InventoryOrderHistory i WHERE i.orderNumber = :orderNumber"),
    @NamedQuery(name = "InventoryOrderHistory.findByNumberofSKUordered", query = "SELECT i FROM InventoryOrderHistory i WHERE i.numberofSKUordered = :numberofSKUordered"),
    @NamedQuery(name = "InventoryOrderHistory.findByNumberofSKUshipped", query = "SELECT i FROM InventoryOrderHistory i WHERE i.numberofSKUshipped = :numberofSKUshipped"),
    @NamedQuery(name = "InventoryOrderHistory.findByNumberofpendingSKU", query = "SELECT i FROM InventoryOrderHistory i WHERE i.numberofpendingSKU = :numberofpendingSKU"),
    @NamedQuery(name = "InventoryOrderHistory.findByDate", query = "SELECT i FROM InventoryOrderHistory i WHERE i.date = :date"),
    @NamedQuery(name = "InventoryOrderHistory.findByStatus", query = "SELECT i FROM InventoryOrderHistory i WHERE i.status = :status")})
public class InventoryOrderHistory implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "number_of_SKU_ordered")
    private int numberofSKUordered;
    @Basic(optional = false)
    @Column(name = "number_of_SKU_shipped")
    private int numberofSKUshipped;
    @Basic(optional = false)
    @Column(name = "number_of_pending_SKU")
    private int numberofpendingSKU;
    @Basic(optional = false)
    @Column(name = "date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date date;
    @Column(name = "status")
    private String status;
    @Column(name = "reason")
    private String reason;
    @Column(name = "actionBy")
    private String actionBy;
    @JoinColumn(name = "fromId", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private AccountInfo fromId;
    @JoinColumn(name = "shippingId", referencedColumnName = "id")
    @ManyToOne
    private ShippingDetails shippingId;
    @JoinColumn(name = "onBehalfId", referencedColumnName = "id")
    @ManyToOne
    private AccountInfo onBehalfId;
    @JoinColumn(name = "orderNumber", referencedColumnName = "orderNumber")
    @ManyToOne(optional = false)
    private InventoryOrder orderNumber;
    @JoinColumn(name = "hostId", referencedColumnName = "id")
    @ManyToOne
    private AccountInfo hostId;
    @JoinColumn(name = "productId", referencedColumnName = "id")
    @ManyToOne
    private Products productId;
    @JoinColumn(name = "mvId", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private MasterVersion mvId;
    @JoinColumn(name = "toId", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private AccountInfo toId;

    public InventoryOrderHistory() {
    	//default constructor
    }

    public InventoryOrderHistory(Integer id) {
        this.id = id;
    }

    public InventoryOrderHistory(Integer id, int numberofSKUordered, int numberofSKUshipped, int numberofpendingSKU, Date date) {
        this.id = id;
        this.numberofSKUordered = numberofSKUordered;
        this.numberofSKUshipped = numberofSKUshipped;
        this.numberofpendingSKU = numberofpendingSKU;
        this.date = date;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public int getNumberofSKUordered() {
        return numberofSKUordered;
    }

    public void setNumberofSKUordered(int numberofSKUordered) {
        this.numberofSKUordered = numberofSKUordered;
    }

    public int getNumberofSKUshipped() {
        return numberofSKUshipped;
    }

    public void setNumberofSKUshipped(int numberofSKUshipped) {
        this.numberofSKUshipped = numberofSKUshipped;
    }

    public int getNumberofpendingSKU() {
        return numberofpendingSKU;
    }

    public void setNumberofpendingSKU(int numberofpendingSKU) {
        this.numberofpendingSKU = numberofpendingSKU;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getActionBy() {
        return actionBy;
    }

    public void setActionBy(String actionBy) {
        this.actionBy = actionBy;
    }

    public AccountInfo getFromId() {
        return fromId;
    }

    public void setFromId(AccountInfo fromId) {
        this.fromId = fromId;
    }

    public ShippingDetails getShippingId() {
        return shippingId;
    }

    public void setShippingId(ShippingDetails shippingId) {
        this.shippingId = shippingId;
    }

    public AccountInfo getOnBehalfId() {
        return onBehalfId;
    }

    public void setOnBehalfId(AccountInfo onBehalfId) {
        this.onBehalfId = onBehalfId;
    }

    public InventoryOrder getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(InventoryOrder orderNumber) {
        this.orderNumber = orderNumber;
    }

    public AccountInfo getHostId() {
        return hostId;
    }

    public void setHostId(AccountInfo hostId) {
        this.hostId = hostId;
    }

    public Products getProductId() {
        return productId;
    }

    public void setProductId(Products productId) {
        this.productId = productId;
    }

    public MasterVersion getMvId() {
        return mvId;
    }

    public void setMvId(MasterVersion mvId) {
        this.mvId = mvId;
    }

    public AccountInfo getToId() {
        return toId;
    }

    public void setToId(AccountInfo toId) {
        this.toId = toId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof InventoryOrderHistory)) {
            return false;
        }
        InventoryOrderHistory other = (InventoryOrderHistory) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.InventoryOrderHistory[ id=" + id + " ]";
    }
    
}
