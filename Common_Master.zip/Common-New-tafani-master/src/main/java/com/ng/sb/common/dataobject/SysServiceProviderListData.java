package com.ng.sb.common.dataobject;

import java.util.List;

public class SysServiceProviderListData {

	private Integer providerId;
	private String providerName;
	private String providerDescription;
	private List serviceCategories;
	private String phoneNumber;
	private String altPhoneNumber;
	private String emailId;
	private Integer countryCodeId;
	private Integer altCountryCodeId;
	private Integer numberofrow;
	private Integer gotopage;
	private String providerNameAuto;
	
	
	public String getProviderNameAuto() {
		return providerNameAuto;
	}
	public void setProviderNameAuto(String providerNameAuto) {
		this.providerNameAuto = providerNameAuto;
	}
	public Integer getNumberofrow() {
		return numberofrow;
	}
	public void setNumberofrow(Integer numberofrow) {
		this.numberofrow = numberofrow;
	}
	public Integer getGotopage() {
		return gotopage;
	}
	public void setGotopage(Integer gotopage) {
		this.gotopage = gotopage;
	}
	public Integer getCountryCodeId() {
		return countryCodeId;
	}
	public void setCountryCodeId(Integer countryCodeId) {
		this.countryCodeId = countryCodeId;
	}
	public Integer getAltCountryCodeId() {
		return altCountryCodeId;
	}
	public void setAltCountryCodeId(Integer altCountryCodeId) {
		this.altCountryCodeId = altCountryCodeId;
	}
	public String getAltPhoneNumber() {
		return altPhoneNumber;
	}
	public void setAltPhoneNumber(String altPhoneNumber) {
		this.altPhoneNumber = altPhoneNumber;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public Integer getProviderId() {
		return providerId;
	}
	public void setProviderId(Integer providerId) {
		this.providerId = providerId;
	}
	public String getProviderName() {
		return providerName;
	}
	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}
	public String getProviderDescription() {
		return providerDescription;
	}
	public void setProviderDescription(String providerDescription) {
		this.providerDescription = providerDescription;
	}
	public List getServiceCategories() {
		return serviceCategories;
	}
	public void setServiceCategories(List serviceCategories) {
		this.serviceCategories = serviceCategories;
	}
}
