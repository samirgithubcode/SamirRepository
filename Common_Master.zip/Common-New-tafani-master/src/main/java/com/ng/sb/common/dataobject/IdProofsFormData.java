package com.ng.sb.common.dataobject;

public class IdProofsFormData {

	private Integer id;
	private String idProofName;
	private String idProofDescription;
	
	public Integer getId() {
		return id;
	}
	
	public void setId(Integer id) {
		this.id = id;
	}
	
	public String getIdProofName() {
		return idProofName;
	}
	
	public void setIdProofName(String idProofName) {
		this.idProofName = idProofName;
	}
	
	public String getIdProofDescription() {
		return idProofDescription;
	}
	
	public void setIdProofDescription(String idProofDescription) {
		this.idProofDescription = idProofDescription;
	}
}
