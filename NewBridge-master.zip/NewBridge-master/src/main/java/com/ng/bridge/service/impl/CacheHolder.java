/**
 * 
 */
package com.ng.bridge.service.impl;

import java.util.HashMap;
import java.util.Map;

import com.ng.sb.common.dataobject.HostSubVersionData;
import com.ng.sb.common.dataobject.ServiceConfigData;
import com.ng.bridge.service.ICacheHolder;

/**
 * @author gaurav
 *
 */
public class CacheHolder implements ICacheHolder {

	private Map<ServiceConfigData,ServiceConfigData> serviceConfigMap=new HashMap<>();
	private Map<HostSubVersionData,HostSubVersionData> hostSubVersionMap = new HashMap<>();
	private static CacheHolder instance = new CacheHolder();

	

	public static CacheHolder getInstance(){
		return instance;
	}
	
	@Override
	public ServiceConfigData getServiceInfo(Integer mvCode,String serviceCode){
		if(mvCode!=null && mvCode!=0){
			return serviceConfigMap.get(new ServiceConfigData(mvCode, serviceCode));
		}
		return null;
	}
	
	@Override
	public HostSubVersionData getHostSubVersion(Integer code){
		if(code!=null && code!=0){
			return hostSubVersionMap.get(new HostSubVersionData(code));
		}
		return null;
	}
}
