/**
 * 
 */
package com.ng.pnb.bridge.iso.impl;

import java.util.HashMap;
import java.util.Map;

import org.jpos.iso.ISOException;
import org.jpos.iso.ISOMsg;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.ng.pnb.bridge.iso.IISOMessageParser;
import com.ng.pnb.invoker.util.PnbConstants;

/**
 * @author gaurav
 *
 */
@Service(value="isoMessageParser")
public class ISOMessageParser extends ISODefiner implements IISOMessageParser {

	private static final Logger LOGGER = LoggerFactory.getLogger(ISOMessageParser.class);
	
	
	private byte[] hexStringToByteArray(String s) {
	    int len = s.length();
	    byte[] data = new byte[len / 2];
	    for (int i = 0; i < len; i += 2) {
	        data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4)
	                             + Character.digit(s.charAt(i+1), 16));
	    }
	    return data;
	}
	
	
	/* (non-Javadoc)
	 * @see com.ng.bridge.iso.builder.IISOMessageParser#parseMessage(java.lang.String)
	 */
	@Override
	public Map<Integer, String> parseMessage(String txnId,String message) throws ISOException {
		LOGGER.info(PnbConstants.TRANSACTIONID +" : "+txnId + " In ISOMessageParser -  parseMessage method. ");
		ISOMsg isoMsg=null;
		try {
			isoMsg = getISOMsg(txnId,false);
			byte[] byt = hexStringToByteArray(message);
			isoMsg.unpack(byt);
		} catch (ISOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER.error(PnbConstants.TRANSACTIONID +" : "+txnId + " Error In ISOMessageParser -  parseMessage method. " + e);
			throw e;
		}
		return logAndParseISOMsg(txnId, isoMsg);
	}
	
	private Map<Integer, String> logAndParseISOMsg(String txnId,ISOMsg msg) {
		LOGGER.info(PnbConstants.TRANSACTIONID +" : "+txnId + " In ISOMessageParser -  parseMessage method. ");
		Map<Integer, String> map = new HashMap<Integer, String>();
		try {
			LOGGER.info(PnbConstants.TRANSACTIONID +" : "+txnId + "  MTI : " + msg.getMTI());
			for (int i=1;i<=msg.getMaxField();i++) {
				if (msg.hasField(i)) {
					LOGGER.info(PnbConstants.TRANSACTIONID +" : "+txnId  +  "  Field - "+i+" : " +msg.getString(i));
					map.put(i, msg.getString(i));
				}
			}
		} catch (ISOException e) {
			LOGGER.info(""+e);
		} 
			LOGGER.info(PnbConstants.TRANSACTIONID +" : "+txnId + " coming out of ISOMessageParser -  logAndParseISOMsg method. ");
			return map;
 
	}


	@Override
	public Map<Integer, String> parseMessage(String txnId, ISOMsg message)
			throws ISOException {
		// TODO Auto-generated method stub
		return logAndParseISOMsg(txnId,message);
	}

}
