package com.ng.sb.common.cache;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Ehcache;
import net.sf.ehcache.Element;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ng.sb.common.dataobject.BankCcData;
import com.ng.sb.common.dataobject.BankData;
import com.ng.sb.common.dataobject.HostCacheData;
import com.ng.sb.common.dataobject.VersionDataObject;
import com.ng.sb.common.dataobject.WalletData;
import com.ng.sb.common.util.SystemConstant;

/**
 *	
 * @author amardeep
 */

public class CacheUtil 
{
	private static CacheManager cacheMgr = null;
	private static   CacheUtil cacheUtil = null;
	private static Ehcache cache = null;
	private static final Logger LOGGER = LoggerFactory.getLogger(CacheUtil.class);
	/**
	 * 
	 * @param cacheName
	 * @return
	 */
	private CacheUtil(){}
	public static CacheUtil getInstance() 
	{
		try
		{
			LOGGER.info("<*********** getInstance() start execution in CacheUtil **************>");
			if (cacheUtil == null) {
				cacheUtil = new CacheUtil();
			}
		}
		catch(Exception ex)
		{
			LOGGER.error("Exception accur in getInstance() ===>>>"+ex);
		}
		return cacheUtil;
	}
	//*****************************************************************
	public static Ehcache getCache(String cacheName) 
	{
		try
		{
			LOGGER.info("<************ getCache() start execution in CacheUtil **************>");
			if (cacheMgr == null) 
			{
				LOGGER.info("<************ cacheMgr null **************>", 14);
				ClassLoader contextClassLoader = Thread.currentThread().getContextClassLoader();
				InputStream resourceAsStream = contextClassLoader.getResourceAsStream("ehcache.xml");
				cacheMgr = CacheManager.create(resourceAsStream);
			}
	
			if (cacheMgr != null) 
			{
				LOGGER.info("<************ cacheMgr not null **************>", 14);
				cache = cacheMgr.getEhcache(cacheName);
			}
		}
		catch(Exception ex)
		{
			LOGGER.error("Exception accur in getCache() ===>>>"+ex);
		}
		return cache;
	}

	/**
	 * @param using ip get host data
	 * @return host cache data
	 */
	public static HostCacheData getHostCacheData(String ip) 
	{
		LOGGER.info("<************ Mehtod getHostCacheData **************>");
		HostCacheData hostCacheData = null;
		
			LOGGER.info("<************ getHostCacheData() start execution in CacheUtil **************>");
			CacheUtil cacheUtil = getInstance();
			if(cacheUtil == null)
			{
				return hostCacheData;
			}
			
			Ehcache ehcache = cacheUtil.getCache(SystemConstant.CACHE_NAME);
			ehcache.get("cacheVersionMap");
			Element ipMapElement = ehcache.get("cacheipMap");
			Element hostMapElement = ehcache.get("cacheHostMap");
			Map ipMap = (Map) ipMapElement.getValue();
			LOGGER.info("ipMap value ===>>>",ipMap, 13);
			if (ipMap.containsKey(ip)) {
				LOGGER.info("<**host ip *>",ip, 14);
				int hostId = Integer.parseInt(ipMap.get(ip).toString());
				Map hostCacheMap = (Map) hostMapElement.getValue();
				if (hostCacheMap.containsKey(hostId)) {
					LOGGER.info("<************ host id **************>",hostId);
					hostCacheData = (HostCacheData) hostCacheMap.get(hostId);
					Map<String, VersionDataObject> versionDataObjects = hostCacheData.getVersionDataObjectMap();
					if(versionDataObjects!=null){
						hostCacheData.setVersionDataObjectMap(getVersionDataObjectsList(versionDataObjects));
					}
				}
			}
			
		return hostCacheData;
	}
	/**
	 * @param get Version Data Objects
	 * @return list of Version Data
	 */
	public static Map<String, VersionDataObject> getVersionDataObjectsList(Map<String, VersionDataObject> versionDataObjects)
	{
		LOGGER.info("<************ Method getVersionDataObjectsList start execution **************>");
		
		Map<String, VersionDataObject> versionDataObjectsMap = new HashMap<>();
		try
		{
			CacheUtil cacheUtil = getInstance();
			if(cacheUtil == null)
			{
			return 	versionDataObjectsMap;
			}
				
			Ehcache ehcache = cacheUtil.getCache(SystemConstant.CACHE_NAME);
			
			VersionDataObject versionDataObject;
			Element versionWithHostFeeMapElement = ehcache.get("versionWithHostFeeMap");
			Map versionMapElementMap = (Map) versionWithHostFeeMapElement.getValue();
			 Iterator it = versionDataObjects.entrySet().iterator();
			    while (it.hasNext()) {
			        Map.Entry pair = (Map.Entry)it.next();
			        
			        if(versionMapElementMap.containsKey(pair.getKey()))
			        {
			        	versionDataObject = (VersionDataObject) versionMapElementMap.get(pair.getKey());
			        	versionDataObjectsMap.put(pair.getKey().toString(), versionDataObject);
			        }
			     }
		}
		catch(Exception ex)
		{
			LOGGER.error("Exception accur in getVersionDataObjectsList() ===>>>"+ex);
		}
		return versionDataObjectsMap;
	}
	/**
	 * @param version
	 * @return
	 */
	public static HostCacheData getVersionData(String version) 
	{
		HostCacheData hostCacheData = null;
		try
		{
			LOGGER.info("<************ getVersionData() start execution in CacheUtil **************>");
			CacheUtil cacheUtil = getInstance();
			if(cacheUtil ==null)
			{
				return hostCacheData;
			}
				
			Ehcache ehcache = cacheUtil.getCache(SystemConstant.CACHE_NAME);
			Element versionMapElement = ehcache.get("cacheVersionMap");
			Element versionDataObjectMapnMapElement = ehcache.get("versionDataObjectMap");
			Map versionMapElementMap = (Map) versionMapElement.getValue();
			Map versionDataObjectMapnMap = (Map)versionDataObjectMapnMapElement.getValue();
			if (versionMapElementMap.containsKey(version)) {
				LOGGER.info("<************HostCacheData using version ****>",version, 14);
				hostCacheData = (HostCacheData) versionMapElementMap.get(version);
				
				if (versionDataObjectMapnMap.containsKey(version)) {
					VersionDataObject dataObject = (VersionDataObject) versionDataObjectMapnMap.get(version);
					Map<String, VersionDataObject> versionDataObjectMap = new HashMap<>();
					versionDataObjectMap.put(version, dataObject);
				hostCacheData.setVersionDataObjectMap(versionDataObjectMap);
				}
			}
			
		}
		catch(Exception ex)
		{
			LOGGER.error("Exception accur in getVersionData() ===>>>"+ex);
		}
		return hostCacheData;
	}
	
	public static BankData getBankDetail(String ifsc){
		LOGGER.info("<************ getBankDetail() start execution in CacheUtil *************>");
		CacheUtil cacheUtil = getInstance();
		Map bankMap2 =null;
		if(cacheUtil!=null){
		Ehcache ehcache = cacheUtil.getCache(SystemConstant.CACHE_NAME);
		Element bankMap = ehcache.get("bankMap");
		bankMap2 = (Map) bankMap.getValue();
		}
		BankData bankData = new BankData();
		if (bankMap2 != null && bankMap2.containsKey(ifsc)) {
			LOGGER.info("<************HostCacheData using version **************>",ifsc);
			bankData = (BankData) bankMap2.get(ifsc);
		}
		
		return bankData;
	}
	public static List<BankCcData> getBankCCList(){
		LOGGER.info("<************ getBankDetail() start execution in CacheUtil **************>");
		CacheUtil cacheUtil = getInstance();
		List<BankCcData> bankCcDatas=null;
		if(cacheUtil!=null){
		Ehcache ehcache = cacheUtil.getCache(SystemConstant.CACHE_NAME);
		Element bankMap = ehcache.get("bankBinMap");
		bankCcDatas = (List<BankCcData>) bankMap.getValue();
		}
		return bankCcDatas;
	}
	
	
	
	public static List<WalletData> getWalletDataList(){
		LOGGER.info("<************ getBankDetail() start execution in CacheUtil **************>");
		CacheUtil cacheUtil = getInstance();
		List<WalletData> bankCcDatas=null;
		if(cacheUtil!=null){
		Ehcache ehcache = cacheUtil.getCache(SystemConstant.CACHE_NAME);
		Element bankMap = ehcache.get("walletMap");
		bankCcDatas = (List<WalletData>) bankMap.getValue();
		}
		return bankCcDatas;
	}
	
	
	
}
