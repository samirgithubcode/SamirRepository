/**
 * 
 */
package com.ng.user.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ng.sb.common.dataobject.ResponseObject;
import com.ng.sb.common.util.ErrorCodes;
import com.ng.sb.common.util.ExceptionUtils;
import com.ng.user.db.IAccountDao;
import com.ng.user.dto.BalanceRequest;
import com.ng.user.dto.TxnHistoryRequest;
import com.ng.user.dto.TxnHistoryResponse;
import com.ng.user.logger.UserServiceLogger;
import com.ng.user.service.IAccountService;
import com.ng.user.utils.UserServiceConstants;

/**
 * @author gopal
 *
 */
@Service("accountService")
public class AccountService implements IAccountService {

	@Autowired
	IAccountDao accountDao;
	
	
	@Override
	public ResponseObject getTxnHistory(TxnHistoryRequest txnHistoryRequest) 
	{
		ResponseObject response = new ResponseObject();
		
		try{
			
			List<TxnHistoryResponse> txnList = accountDao.getTxnHistory(txnHistoryRequest);
			
			response.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
			response.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
			
			response.setPayload(txnList);
			
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), UserServiceConstants.PACKAGE_FOR_EXCEPTION);
			
			UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
		}
		
		return response;
	}

	@Override
	public ResponseObject getAccountBalance(BalanceRequest balanceRequest) {
		return null;
	}

}
