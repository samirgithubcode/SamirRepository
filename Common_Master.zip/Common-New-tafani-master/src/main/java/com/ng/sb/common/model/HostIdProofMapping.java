/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "hostIdProofMapping")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "HostIdProofMapping.findAll", query = "SELECT h FROM HostIdProofMapping h"),
    @NamedQuery(name = "HostIdProofMapping.findById", query = "SELECT h FROM HostIdProofMapping h WHERE h.id = :id")})
public class HostIdProofMapping implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
    @JoinColumn(name = "hostId", referencedColumnName = "id", nullable = false)
    @ManyToOne(optional = false)
    private AccountInfo hostId;
    @JoinColumn(name = "idProofId", referencedColumnName = "id", nullable = false)
    @ManyToOne(optional = false)
    private IdProofs idProofId;

    public HostIdProofMapping() {
    	//default constructor
    }

    public HostIdProofMapping(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public AccountInfo getHostId() {
        return hostId;
    }

    public void setHostId(AccountInfo hostId) {
        this.hostId = hostId;
    }

    public IdProofs getIdProofId() {
        return idProofId;
    }

    public void setIdProofId(IdProofs idProofId) {
        this.idProofId = idProofId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof HostIdProofMapping)) {
            return false;
        }
        HostIdProofMapping other = (HostIdProofMapping) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.HostIdProofMapping[ id=" + id + " ]";
    }
    
}
