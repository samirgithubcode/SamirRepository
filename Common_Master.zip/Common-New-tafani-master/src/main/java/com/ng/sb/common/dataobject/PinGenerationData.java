package com.ng.sb.common.dataobject;

import java.sql.Date;
import java.util.Arrays;
import java.util.Map;

public class PinGenerationData extends BaseObjectData{

	private static final long serialVersionUID = 1L;
	
	private String templateName;


	private String templateDescription;
	private Integer[] denominator;
	private Integer[] quantity;
	private Date[] expiryDate;
	private Map<Integer,Integer> denominatorData;
	
	public String getTemplateName() {
		return templateName;
	}
	
	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}
	
	public String getTemplateDescription() {
		return templateDescription;
	}
	
	public void setTemplateDescription(String templateDescription) {
		this.templateDescription = templateDescription;
	}
	
	public Integer[] getDenominator() {
		return denominator;
	}
	
	public void setDenominator(Integer[] denominator) {
		this.denominator = denominator;
	}
	
	public Integer[] getQuantity() {
		return quantity;
	}
	
	public void setQuantity(Integer[] quantity) {
		this.quantity = quantity;
	}
	
	public Date[] getExpiryDate() {
		return expiryDate;
	}
	
	public void setExpiryDate(Date[] expiryDate) {
		this.expiryDate = expiryDate;
	}

	public Map<Integer, Integer> getDenominatorData() {
		return denominatorData;
	}

	public void setDenominatorData(Map<Integer, Integer> denominatorData) {
		this.denominatorData = denominatorData;
	} 
	@Override
	public String toString() {
		return "PinGenerationData [templateName=" + templateName + ", templateDescription=" + templateDescription
				+ ", denominator=" + Arrays.toString(denominator) + ", quantity=" + Arrays.toString(quantity)
				+ ", expiryDate=" + Arrays.toString(expiryDate) + ", denominatorData=" + denominatorData + "]";
	}
}
