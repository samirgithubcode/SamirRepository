/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "serviceParamMapping")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "ServiceParamMapping.findAll", query = "SELECT s FROM ServiceParamMapping s"),
    @NamedQuery(name = "ServiceParamMapping.findById", query = "SELECT s FROM ServiceParamMapping s WHERE s.id = :id"),
    @NamedQuery(name = "ServiceParamMapping.findByObjectMapping", query = "SELECT s FROM ServiceParamMapping s WHERE s.objectMapping = :objectMapping"),
    @NamedQuery(name = "ServiceParamMapping.findByDescription", query = "SELECT s FROM ServiceParamMapping s WHERE s.description = :description"),
    @NamedQuery(name = "ServiceParamMapping.findBySequence", query = "SELECT s FROM ServiceParamMapping s WHERE s.sequence = :sequence"),
    @NamedQuery(name = "ServiceParamMapping.findByIsNumeric", query = "SELECT s FROM ServiceParamMapping s WHERE s.isNumeric = :isNumeric")})
public class ServiceParamMapping implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
    @Column(name = "object_mapping", length = 100)
    private String objectMapping;
    @Column(name = "description", length = 50)
    private String description;
    @Basic(optional = false)
    @Column(name = "sequence", nullable = false)
    private int sequence;
    @Column(name = "isNumeric")
    private Boolean isNumeric;
    @JoinColumn(name = "service_id", referencedColumnName = "id", nullable = false)
    @ManyToOne(optional = false)
    private ServiceConfig serviceId;

    public ServiceParamMapping() {
    	//default constructor
    }

    public ServiceParamMapping(Integer id) {
        this.id = id;
    }

    public ServiceParamMapping(Integer id, int sequence) {
        this.id = id;
        this.sequence = sequence;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getObjectMapping() {
        return objectMapping;
    }

    public void setObjectMapping(String objectMapping) {
        this.objectMapping = objectMapping;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getSequence() {
        return sequence;
    }

    public void setSequence(int sequence) {
        this.sequence = sequence;
    }

    public Boolean getIsNumeric() {
        return isNumeric;
    }

    public void setIsNumeric(Boolean isNumeric) {
        this.isNumeric = isNumeric;
    }

    public ServiceConfig getServiceId() {
        return serviceId;
    }

    public void setServiceId(ServiceConfig serviceId) {
        this.serviceId = serviceId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof ServiceParamMapping)) {
            return false;
        }
        ServiceParamMapping other = (ServiceParamMapping) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.ServiceParamMapping[ id=" + id + " ]";
    }
    
}
