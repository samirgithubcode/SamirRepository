package com.ng.sb.common.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
@Entity
@Table(name="uploded_file_status")
@NamedQueries({
@NamedQuery(name="FileHistory.findAll", query="SELECT fileHistory FROM FileHistory fileHistory"),
@NamedQuery(name="FileHistory.findById", query="SELECT fh FROM FileHistory fh WHERE fh.id =:id"),
})
public class FileHistory {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer id;
	@Column(name="file_name")
	private String fileName;
	@Column(name="mismatch_errors")
	private String mismatchErrors;
	@Column(name="creation_date")
	private Date creationDate;
	@Column(name="file_uploaded_by")
	private Integer uploadedBy;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getMismatchErrors() {
		return mismatchErrors;
	}
	public void setMismatchErrors(String mismatchErrors) {
		this.mismatchErrors = mismatchErrors;
	}
	public Date getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}
	public Integer getUploadedBy() {
		return uploadedBy;
	}
	public void setUploadedBy(Integer uploadedBy) {
		this.uploadedBy = uploadedBy;
	}
}
