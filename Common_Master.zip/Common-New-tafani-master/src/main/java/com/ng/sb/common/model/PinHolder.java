package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;



/**
 * @author abhishek
 *
 */
@Entity
@Table(name = "PinHolder")
@XmlRootElement
@NamedQueries({
	@NamedQuery(name="PinHolder.findById", query="SELECT p FROM PinHolder p where p.id=:id"),
	@NamedQuery(name="PinHolder.findAll", query="SELECT p FROM PinHolder p"),
	@NamedQuery(name="PinHolder.findByPin", query="SELECT p FROM PinHolder p where p.pin in (:pin)"),
	@NamedQuery(name="PinHolder.findCount", query="SELECT count(p) FROM PinHolder p"),
	@NamedQuery(name="PinHolder.findByPinMgmntID", query="SELECT p FROM PinHolder p where p.pinManagement=:pinManagement"),
})
public class PinHolder implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Basic(optional=false)
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	@Column(name="createDate")
	@Basic(optional=false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date createDate;
	@Column(name="expiryDate")
	@Basic(optional=false)
	private Date expiryDate;
	@Column(name="pin")
	@Basic(optional=false)
	private String pin;
	@Column(name="status")
	@Basic(optional=false)
	private String status;

	//bi-directional many-to-one association to PinManagement
	@ManyToOne
	@JoinColumn(name="pinMgmtId")
	private PinManagement pinManagement;

	//bi-directional many-to-one association to Denomination
	@ManyToOne
	@JoinColumn(name="denominationId")
	private Denomination denomination;

	public PinHolder() {
		//default
	}
	
	public PinHolder(Long id) {
		this.id = id;
	}

	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getCreateDate() {
		return this.createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getExpiryDate() {
		return this.expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getPin() {
		return this.pin;
	}

	public void setPin(String pin) {
		this.pin = pin;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public PinManagement getPinManagement() {
		return this.pinManagement;
	}

	public void setPinManagement(PinManagement pinManagement) {
		this.pinManagement = pinManagement;
	}

	public Denomination getDenomination() {
		return this.denomination;
	}

	public void setDenomination(Denomination denomination) {
		this.denomination = denomination;
	}

}