/**
 * 
 */
package com.ng.pnb.bridge.iso;

import java.util.Map;

import org.jpos.iso.ISOException;
import org.jpos.iso.ISOMsg;

/**
 * @author gaurav
 *
 */

public interface IISOMessageParser 
{
	public Map<Integer,String> parseMessage(String txnId,String message)throws ISOException;
	
	public Map<Integer,String> parseMessage(String txnId,ISOMsg message)throws ISOException;
}
