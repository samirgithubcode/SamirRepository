/**
 * 
 */
package com.ng.sb.common.dataobject;

/**
 * @author gaurav
 *
 */
public class PartnerPreferenceData extends BaseObjectData  implements Comparable<PartnerPreferenceData>  {
	private static final long serialVersionUID = 1L;
	private String type;
	private Integer sequence;
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Integer getSequence() {
		return sequence;
	}
	public void setSequence(Integer sequence) {
		this.sequence = sequence;
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj==null){
			return false;
		}
		boolean check=false;
		if(obj instanceof PartnerPreferenceData){
			PartnerPreferenceData other = (PartnerPreferenceData)obj;
			 if(this.id!=null && other.getId()!=null && this.id.equals(other.getId())){
				 check= true;
			}
			return check;
		}
		return super.equals(obj);
	}
	
	@Override
	public int hashCode() {
		if( this.id!=null){
			return this.id*7;	
		}else{
			return 0;
		}
		
	}
	
	
	@Override
	public int compareTo(PartnerPreferenceData other) {
		if( other!=null){
			if(this.getSequence()==other.getSequence()){
				return 0;		
			}
			return this.getSequence()>other.getSequence()?1:-1;
		}
		return 0;	
	}
	

}
