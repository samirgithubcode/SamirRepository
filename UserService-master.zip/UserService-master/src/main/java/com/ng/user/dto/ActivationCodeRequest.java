/**
 * 
 */
package com.ng.user.dto;

import org.hibernate.validator.constraints.NotBlank;

import com.ng.sb.common.dataobject.ValidationBean;

/**
 * @author gopal
 *
 */
public class ActivationCodeRequest implements ValidationBean {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1194423032986396512L;

	@NotBlank(message="Channel Id cannot be blank")
	private String channelId;
	
	@NotBlank(message="User MSISDN cannot be blank")
	private String userMsisdn;

	//@NotBlank(message="SKU Id cannot be blank")
	private String skuId;
	
	private String custId;

	public String getUserMsisdn() {
		return userMsisdn;
	}

	public void setUserMsisdn(String userMsisdn) {
		this.userMsisdn = userMsisdn;
	}

	public String getSkuId() {
		return skuId;
	}

	public void setSkuId(String skuId) {
		this.skuId = skuId;
	}

	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public String getCustId() {
		return custId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}

}
