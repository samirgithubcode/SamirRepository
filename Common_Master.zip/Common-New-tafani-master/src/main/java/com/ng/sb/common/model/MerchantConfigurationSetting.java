package com.ng.sb.common.model;

import java.io.Serializable;




import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


@Entity
@Table(name="merchantconfigurationsetting")
@NamedQueries({
	
@NamedQuery(name="merchantconfigurationsetting.findAll", query="SELECT m FROM MerchantConfigurationSetting m"),
@NamedQuery(name="MerchantConfigurationSetting.findByMerchantId", query="SELECT m FROM MerchantConfigurationSetting m where m.merchantId=:id AND m.value=1 AND m.group= 'channel'"),
@NamedQuery(name="MerchantConfigurationSetting.findInvoiceByMerchantId", query="SELECT m FROM MerchantConfigurationSetting m where m.merchantId=:id AND m.value=1 AND m.group= 'invoice'"),

})




public class MerchantConfigurationSetting implements Serializable {
private static final long serialVersionUId=1L;

@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
@Column(name = "id", unique=true, nullable=false)
private Integer id;

@Column(name = "merchantId")
private Integer merchantId;

@Column(name = "value")
private boolean value;

@Column(name = "ParameterName")
private String ParameterName;

@Column(name = "grop")
private String group;

public String getGroup() {
	return group;
}

public void setGroup(String group) {
	this.group = group;
}

public Integer getMerchantId() {
	return merchantId;
}

public void setMerchantId(Integer merchantId) {
	this.merchantId = merchantId;
}

public boolean getValue() {
	return value;
}

public void setValue(boolean value) {
	this.value = value;
}

public String getParameterName() {
	return ParameterName;
}

public void setParameterName(String parameterName) {
	ParameterName = parameterName;
}

public Integer getId() {
	return id;
}

public void setId(Integer id) {
	this.id = id;
}


}
