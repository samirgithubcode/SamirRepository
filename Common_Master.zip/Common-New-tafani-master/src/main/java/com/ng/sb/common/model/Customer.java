package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * @author abhishek
 *
 */
@Entity
@Table(name="Customer")
@NamedQueries({
	 @NamedQuery(name="Customer.findAll", query="SELECT c FROM Customer c"),
	 @NamedQuery(name = "Customer.findById", query = "SELECT c FROM Customer c where c.id = :id"),
	 @NamedQuery(name="Customer.findCountByPhoneNumber", query = "SELECT c FROM Customer c where c.contactNumber = :contactNumber"),
	 @NamedQuery(name = "Customer.findByContactNumber", query = "SELECT c FROM Customer c where c.contactNumber = :contactNumber"),
})
public class Customer implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false)
	private Integer id;

	@Column(name="city", length=100)
	private String city;

	@Column(name="contactNumber", nullable=false, length=25)
	private String contactNumber;

	 @Basic(optional = false)
	 @Column(name = "createDate")
	 @Temporal(TemporalType.TIMESTAMP)
	 private Date createDate;
	 @Column(name = "editDate")
	 @Temporal(TemporalType.TIMESTAMP)
	 private Date editDate;
	
	@Column(name="firstName",nullable=false, length=30)
	private String firstName;

	@Column(name="houseNoStreet",length=200)
	private String houseNoStreet;

	@Column(name="landmark",length=200)
	private String landmark;

	@Column(name="lastName",nullable=false, length=30)
	private String lastName;

	@Column(name="pincode")
	private Integer pincode;

	@Column(name="status",nullable=false, length=1)
	private String status;

	//bi-directional many-to-one association to Country
	@ManyToOne
	@JoinColumn(name="country")
	private Country country;

	//bi-directional many-to-one association to State
	@ManyToOne
	@JoinColumn(name="state")
	private State state;

	//bi-directional many-to-one association to CustomerTransaction
	@OneToMany(mappedBy="customer")
	private List<CustomerTransaction> customerTransactions;

	//bi-directional many-to-one association to CustomerWallet
	@OneToMany(mappedBy="customerId")
	private List<CustomerWallet> customerWallets;
	 public Customer() {
			//empty
		}
		
		public Customer(Integer id) {
			this.id = id;
		}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getEditDate() {
		return editDate;
	}

	public void setEditDate(Date editDate) {
		this.editDate = editDate;
	}

	

	

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getContactNumber() {
		return this.contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getHouseNoStreet() {
		return this.houseNoStreet;
	}

	public void setHouseNoStreet(String houseNoStreet) {
		this.houseNoStreet = houseNoStreet;
	}

	public String getLandmark() {
		return this.landmark;
	}

	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}

	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Integer getPincode() {
		return this.pincode;
	}

	public void setPincode(Integer pincode) {
		this.pincode = pincode;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Country getCountry() {
		return this.country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public State getState() {
		return this.state;
	}

	public void setState(State state) {
		this.state = state;
	}

	public List<CustomerTransaction> getCustomerTransactions() {
		return this.customerTransactions;
	}

	public void setCustomerTransactions(List<CustomerTransaction> customerTransactions) {
		this.customerTransactions = customerTransactions;
	}

	public CustomerTransaction addCustomerTransaction(CustomerTransaction customerTransaction) {
		getCustomerTransactions().add(customerTransaction);
		customerTransaction.setCustomer(this);

		return customerTransaction;
	}

	public CustomerTransaction removeCustomerTransaction(CustomerTransaction customerTransaction) {
		getCustomerTransactions().remove(customerTransaction);
		customerTransaction.setCustomer(null);

		return customerTransaction;
	}

	public List<CustomerWallet> getCustomerWallets() {
		return this.customerWallets;
	}

	public void setCustomerWallets(List<CustomerWallet> customerWallets) {
		this.customerWallets = customerWallets;
	}

	public CustomerWallet addCustomerWallet(CustomerWallet customerWallet) {
		getCustomerWallets().add(customerWallet);
		customerWallet.setCustomerId(this);

		return customerWallet;
	}

	public CustomerWallet removeCustomerWallet(CustomerWallet customerWallet) {
		getCustomerWallets().remove(customerWallet);
		customerWallet.setCustomerId(null);

		return customerWallet;
	}

}