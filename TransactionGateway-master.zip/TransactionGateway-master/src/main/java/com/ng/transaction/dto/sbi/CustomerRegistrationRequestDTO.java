package com.ng.transaction.dto.sbi;

import java.io.Serializable;
import java.util.ArrayList;

public class CustomerRegistrationRequestDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private RequestInfo requestInfo;
	private UserInfo userInfo;
	private DeviceInfo deviceInfo;
	private AddInfo addInfo;
	private ArrayList<AccountList> accountList;
	
	public CustomerRegistrationRequestDTO() {
		this.requestInfo = new RequestInfo();
		this.userInfo = new UserInfo();
		this.deviceInfo = new DeviceInfo();
		this.addInfo = new AddInfo();
		this.accountList = new ArrayList<>();
	}

	public RequestInfo getRequestInfo() {
		return requestInfo;
	}

	public void setRequestInfo(RequestInfo requestInfo) {
		this.requestInfo = requestInfo;
	}

	public UserInfo getUserInfo() {
		return userInfo;
	}

	public void setUserInfo(UserInfo userInfo) {
		this.userInfo = userInfo;
	}

	public DeviceInfo getDeviceInfo() {
		return deviceInfo;
	}

	public void setDeviceInfo(DeviceInfo deviceInfo) {
		this.deviceInfo = deviceInfo;
	}

	public AddInfo getAddInfo() {
		return addInfo;
	}

	public void setAddInfo(AddInfo addInfo) {
		this.addInfo = addInfo;
	}

	public ArrayList<AccountList> getAccountList() {
		return accountList;
	}
	
	public AccountList getAccount() {
		return new AccountList();
	}

	public void setAccountList(ArrayList<AccountList> accountList) {
		this.accountList = accountList;
	}

	public class RequestInfo {
		private Integer pspId;
		private String pspRefNo;
		public Integer getPspId() {
			return pspId;
		}
		public void setPspId(Integer pspId) {
			this.pspId = pspId;
		}
		public String getPspRefNo() {
			return pspRefNo;
		}
		public void setPspRefNo(String pspRefNo) {
			this.pspRefNo = pspRefNo;
		}
	}
	
	public class UserInfo {
		private String virtualAddress;
		private String name;
		private String email;
		public String getVirtualAddress() {
			return virtualAddress;
		}
		public void setVirtualAddress(String virtualAddress) {
			this.virtualAddress = virtualAddress;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
	}

	public class DeviceInfo {
		private String deviceId;
		private String mobileNo;
		private String simId;
		private String geoCode;
		private String location;
		private String ip;
		private String os;
		private String deviceType;
		private String appName;
		private String capability;
		private String androidId;
		private String bluetoothMac;
		private String wifiMac;
		public String getDeviceId() {
			return deviceId;
		}
		public void setDeviceId(String deviceId) {
			this.deviceId = deviceId;
		}
		public String getMobileNo() {
			return mobileNo;
		}
		public void setMobileNo(String mobileNo) {
			this.mobileNo = mobileNo;
		}
		public String getSimId() {
			return simId;
		}
		public void setSimId(String simId) {
			this.simId = simId;
		}
		public String getGeoCode() {
			return geoCode;
		}
		public void setGeoCode(String geoCode) {
			this.geoCode = geoCode;
		}
		public String getLocation() {
			return location;
		}
		public void setLocation(String location) {
			this.location = location;
		}
		public String getIp() {
			return ip;
		}
		public void setIp(String ip) {
			this.ip = ip;
		}
		public String getOs() {
			return os;
		}
		public void setOs(String os) {
			this.os = os;
		}
		public String getDeviceType() {
			return deviceType;
		}
		public void setDeviceType(String deviceType) {
			this.deviceType = deviceType;
		}
		public String getAppName() {
			return appName;
		}
		public void setAppName(String appName) {
			this.appName = appName;
		}
		public String getCapability() {
			return capability;
		}
		public void setCapability(String capability) {
			this.capability = capability;
		}
		public String getAndroidId() {
			return androidId;
		}
		public void setAndroidId(String androidId) {
			this.androidId = androidId;
		}
		public String getBluetoothMac() {
			return bluetoothMac;
		}
		public void setBluetoothMac(String bluetoothMac) {
			this.bluetoothMac = bluetoothMac;
		}
		public String getWifiMac() {
			return wifiMac;
		}
		public void setWifiMac(String wifiMac) {
			this.wifiMac = wifiMac;
		}
	}
	
	public class AddInfo {
		private String addInfo1;		// Optional

		public String getAddInfo1() {
			return addInfo1;
		}

		public void setAddInfo1(String addInfo1) {
			this.addInfo1 = addInfo1;
		}
	}
	
	public class AccountList {
		private String accountNumber;
		private String preferredFlag;
		private String ifscCode;
		private String accountType;
		private String accountName;
		public String getAccountNumber() {
			return accountNumber;
		}
		public void setAccountNumber(String accountNumber) {
			this.accountNumber = accountNumber;
		}
		public String getPreferredFlag() {
			return preferredFlag;
		}
		public void setPreferredFlag(String preferredFlag) {
			this.preferredFlag = preferredFlag;
		}
		public String getIfscCode() {
			return ifscCode;
		}
		public void setIfscCode(String ifscCode) {
			this.ifscCode = ifscCode;
		}
		public String getAccountType() {
			return accountType;
		}
		public void setAccountType(String accountType) {
			this.accountType = accountType;
		}
		public String getAccountName() {
			return accountName;
		}
		public void setAccountName(String accountName) {
			this.accountName = accountName;
		}
	}
}
