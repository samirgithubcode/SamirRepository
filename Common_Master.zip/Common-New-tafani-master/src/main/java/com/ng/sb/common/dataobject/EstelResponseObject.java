
package com.ng.sb.common.dataobject;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "response")
public class EstelResponseObject {

	private String resultcode;
	private String resultdescription;
	private String agentcode;
	private String amount;
	private String transid;
	private String requestcts;
	private String responsects;
	private String responsevalue;
	private String destination;
	private String vendorcode;
	private String walletbalance;
	private String prewalletbalance;
	private String clienttype;
	private String language;
	private String agentname;
	private String oprwallet;
	private String preoprwallet;
	private String source;
	private String accountname;
	private String idproof;
	private String address1;
	private String address2;
	private String state;
	private String city;
	private String country;
	private String email;
	private String mobileno;
	private String destagentname;
	private String predestinationwallet;
	private String destinationwallet;
	private String fee;
	private String agenttransid;
	private String title;
	private String parent;
	private String region;
	private String agenttype;
	private String idproofreceived;
	private String postcode;
	private String template;
	private String faxno;
	private String companyName;
	private String request;
	private String response;
	private String comments;
	@XmlElement(name = "agenttransid")
	public String getAgenttransid() {
		return agenttransid;
	}

	public void setAgenttransid(String agenttransid) {
		this.agenttransid = agenttransid;
	}
	@XmlElement(name = "title")
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}
	@XmlElement(name = "parent")
	public String getParent() {
		return parent;
	}

	public void setParent(String parent) {
		this.parent = parent;
	}
	@XmlElement(name = "region")
	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}
	@XmlElement(name = "agenttype")
	public String getAgenttype() {
		return agenttype;
	}

	public void setAgenttype(String agenttype) {
		this.agenttype = agenttype;
	}
	@XmlElement(name = "idproofreceived")
	public String getIdproofreceived() {
		return idproofreceived;
	}

	public void setIdproofreceived(String idproofreceived) {
		this.idproofreceived = idproofreceived;
	}
	@XmlElement(name = "postcode")
	public String getPostcode() {
		return postcode;
	}

	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}
	@XmlElement(name = "template")
	public String getTemplate() {
		return template;
	}

	public void setTemplate(String template) {
		this.template = template;
	}
	@XmlElement(name = "faxno")
	public String getFaxno() {
		return faxno;
	}

	public void setFaxno(String faxno) {
		this.faxno = faxno;
	}
	@XmlElement(name = "companyName")
	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	
	@XmlElement(name = "fee")
	public String getFee() {
		return fee;
	}

	public void setFee(String fee) {
		this.fee = fee;
	}

	@XmlElement(name = "destinationwallet")
	public String getDestinationwallet() {
		return destinationwallet;
	}

	public void setDestinationwallet(String destinationwallet) {
		this.destinationwallet = destinationwallet;
	}

	@XmlElement(name = "predestinationwallet")
	public String getPredestinationwallet() {
		return predestinationwallet;
	}

	public void setPredestinationwallet(String predestinationwallet) {
		this.predestinationwallet = predestinationwallet;
	}

	@XmlElement(name = "destagentname")
	public String getDestagentname() {
		return destagentname;
	}

	public void setDestagentname(String destagentname) {
		this.destagentname = destagentname;
	}

	@XmlElement(name = "mobileno")
	public String getMobileno() {
		return mobileno;
	}

	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}

	@XmlElement(name = "address1")
	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	@XmlElement(name = "address2")
	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	@XmlElement(name = "state")
	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}
	@XmlElement(name = "city")
	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}
	@XmlElement(name = "country")
	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}
	@XmlElement(name = "email")
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@XmlElement(name = "idproof")
	public String getIdproof() {
		return idproof;
	}

	public void setIdproof(String idproof) {
		this.idproof = idproof;
	}

	@XmlElement(name = "accountname")
	public String getAccountname() {
		return accountname;
	}

	public void setAccountname(String accountname) {
		this.accountname = accountname;
	}

	@XmlElement(name = "source")
	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	@XmlElement(name = "resultcode")
	public String getResultcode() {
		return resultcode;
	}

	public void setResultcode(String resultcode) {
		this.resultcode = resultcode;
	}

	@XmlElement(name = "resultdescription")
	public String getResultdescription() {
		return resultdescription;
	}

	public void setResultdescription(String resultdescription) {
		this.resultdescription = resultdescription;
	}

	@XmlElement(name = "agentcode")
	public String getAgentcode() {
		return agentcode;
	}

	public void setAgentcode(String agentcode) {
		this.agentcode = agentcode;
	}

	@XmlElement(name = "transid")
	public String getTransid() {
		return transid;
	}

	public void setTransid(String transid) {
		this.transid = transid;
	}

	@XmlElement(name = "requestcts")
	public String getRequestcts() {
		return requestcts;
	}

	public void setRequestcts(String requestcts) {
		this.requestcts = requestcts;
	}

	@XmlElement(name = "responsects")
	public String getResponsects() {
		return responsects;
	}

	public void setResponsects(String responsects) {
		this.responsects = responsects;
	}

	@XmlElement(name = "responsevalue")
	public String getResponsevalue() {
		return responsevalue;
	}

	public void setResponsevalue(String responsevalue) {
		this.responsevalue = responsevalue;
	}

	@XmlElement(name = "vendorcode")
	public String getVendorcode() {
		return vendorcode;
	}

	public void setVendorcode(String vendorcode) {
		this.vendorcode = vendorcode;
	}

	@XmlElement(name = "walletbalance")
	public String getWalletbalance() {
		return walletbalance;
	}

	public void setWalletbalance(String walletbalance) {
		this.walletbalance = walletbalance;
	}

	@XmlElement(name = "prewalletbalance")
	public String getPrewalletbalance() {
		return prewalletbalance;
	}

	public void setPrewalletbalance(String prewalletbalance) {
		this.prewalletbalance = prewalletbalance;
	}

	@XmlElement(name = "clienttype")
	public String getClienttype() {
		return clienttype;
	}

	public void setClienttype(String clienttype) {
		this.clienttype = clienttype;
	}

	@XmlElement(name = "agentname")
	public String getAgentname() {
		return agentname;
	}

	public void setAgentname(String agentname) {
		this.agentname = agentname;
	}

	@XmlElement(name = "oprwallet")
	public String getOprwallet() {
		return oprwallet;
	}

	public void setOprwallet(String oprwallet) {
		this.oprwallet = oprwallet;
	}

	@XmlElement(name = "preoprwallet")
	public String getPreoprwallet() {
		return preoprwallet;
	}

	public void setPreoprwallet(String preoprwallet) {
		this.preoprwallet = preoprwallet;
	}

	@XmlElement(name = "amount")
	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	@XmlElement(name = "destination")
	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	@XmlElement(name = "language")
	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getRequest() {
		return request;
	}

	public void setRequest(String request) {
		this.request = request;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	@XmlElement(name = "comments")
	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

}
