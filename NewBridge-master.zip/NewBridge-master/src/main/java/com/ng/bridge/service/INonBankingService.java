/**
 * 
 */
package com.ng.bridge.service;

import com.ng.sb.common.dataobject.BridgeDataObject;

/**
 * @author gaurav
 *
 */
public interface INonBankingService extends IFundTransferMgtService {
	public BridgeDataObject balanceEnquiry(BridgeDataObject bridgeDataObject);
	public BridgeDataObject chequeBookRequest(BridgeDataObject bridgeDataObject);
	public BridgeDataObject chequeStatus(BridgeDataObject bridgeDataObject);
	public BridgeDataObject stopCheque(BridgeDataObject bridgeDataObject);
	public BridgeDataObject last5Transaction(BridgeDataObject bridgeDataObject);
}
