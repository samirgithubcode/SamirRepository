package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
*
* @author Simran
* 
* The persistent class for the customer kyc mapping database table.
*/
@Entity
@Table(name = "customer_kyc_mapping")
@XmlRootElement
@NamedQueries({
	/*@NamedQuery(name = "CustomerKYC.findnameandweightage", query = "SELECT c FROM CustomerKYC c  ORDER BY c.order ")*/
})
public class CustomerKycMapping  implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = true)
	@JoinColumn(name = "verification_id", referencedColumnName = "id")
	@ManyToOne
	private KycVerificationDetails verificationId;
    @Column(name = "kyc")
    private String kYC ;
    @Column(name = "txn_id")
    private String transactionID ;
    @Column(name = "weightage")
    private Integer weightage ;
    public CustomerKycMapping() {
 		//default
 	}
    public CustomerKycMapping(Integer id) {
        this.id = id;
    }
 
	@Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
    	boolean check=true;
    	if(object!=null){
        if (!(object instanceof CustomerKycMapping)) {
        	check= false;
        }
        CustomerKycMapping other = (CustomerKycMapping) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
    	}
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.CustomerKycMapping[ id=" + id + " ]";
    }
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public KycVerificationDetails getVerificationId() {
		return verificationId;
	}
	public void setVerificationId(KycVerificationDetails verificationId) {
		this.verificationId = verificationId;
	}
	public String getkYC() {
		return kYC;
	}
	public void setkYC(String kYC) {
		this.kYC = kYC;
	}
	public String getTransactionID() {
		return transactionID;
	}
	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}
	public Integer getWeightage() {
		return weightage;
	}
	public void setWeightage(Integer weightage) {
		this.weightage = weightage;
	}
	

}
