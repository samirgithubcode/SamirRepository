/**
 * 
 */
package com.ng.transaction.util;

/**
 * @author gopal
 *
 */
public class TransactionConstants 
{
 private TransactionConstants(){}
 
	public static final int BANK_ONLY  = 1001;
	
	public static final int WALLET_ONLY  = 1002;
	
	public static final int PAYEE_ONLY  = 1003;
	
	public static final int MERCHANT_ONLY  = 1004;
	
	public static final String LOG4J_FILE_PATH_KEY = "LOG4J_FILE_PATH";
}
