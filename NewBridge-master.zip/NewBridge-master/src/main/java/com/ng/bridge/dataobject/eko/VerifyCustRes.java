package com.ng.bridge.dataobject.eko;

public class VerifyCustRes {
	 private String responseTypeId;

	    private String message;

	    private String responseStatusId;

	    private String status;

	    private VerifyCustResData verifyCustResData;
	    
	    public String getStatus ()
	    {
	        return status;
	    }

	    public void setStatus (String status)
	    {
	        this.status = status;
	    }

	 

	    public String getMessage ()
	    {
	        return message;
	    }

	    public void setMessage (String message)
	    {
	        this.message = message;
	    }
	    public String getResponseTypeId ()
	    {
	        return responseTypeId;
	    }

	    public void setResponseTypeId (String responseTypeId)
	    {
	        this.responseTypeId = responseTypeId;
	    }
	    public VerifyCustResData getVerifyCustResData() {
			return verifyCustResData;
		}

		public void setVerifyCustResData(VerifyCustResData verifyCustResData) {
			this.verifyCustResData = verifyCustResData;
		}

	    public String getResponseStatusId ()
	    {
	        return responseStatusId;
	    }

	    public void setResponseStatusId (String responseStatusId)
	    {
	        this.responseStatusId = responseStatusId;
	    }

	   

	  

	    
		@Override
	    public String toString()
	    {
	        return "ClassPojo [response_type_id = "+responseTypeId+", message = "+message+", response_status_id = "+responseStatusId+", status = "+status+", verifyCustResData = "+verifyCustResData+"]";
	    }
}
