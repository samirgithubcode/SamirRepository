/**
 * 
 */
package com.ng.pnb.bridge.iso.impl;

import java.io.InputStream;

import org.jpos.iso.ISOException;
import org.jpos.iso.ISOMsg;
import org.jpos.iso.packager.GenericPackager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.ng.pnb.invoker.util.PnbConstants;
import com.ng.pnb.invoker.util.PropertyHolder;

/**
 * @author gaurav
 *
 */
public class ISODefiner {
	
	@Autowired
	PropertyHolder propertyHolder;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ISODefiner.class);
	
	protected ISOMsg getISOMsg(String txnId,boolean setMTI) throws ISOException{

		ISOMsg isoMsg = null;
		LOGGER.info(PnbConstants.TRANSACTIONID +" : "+txnId + " In ISODefiner -  getISOMsg method. ");
		try{
			InputStream ips = ISOMessageCreator.class.getClassLoader().getResourceAsStream("default_iso8583.xml");
			if(ips!=null)
			{
				GenericPackager packager = new GenericPackager(propertyHolder.getDefinitionFile());
				//GenericPackager packager = new GenericPackager(ips);
				
				// Create ISO Message
				isoMsg = new ISOMsg();
				isoMsg.setPackager(packager);
				if(setMTI){
					isoMsg.setMTI("0200");
				}
			}else{
				LOGGER.info(PnbConstants.TRANSACTIONID +" : "+txnId + " Error in reading ISO xml file In ISODefiner -  getISOMsg method. ");
			}
			
		}catch(Exception e){
			e.printStackTrace();
			LOGGER.error(PnbConstants.TRANSACTIONID +" : "+txnId + " Error In ISODefiner -  getISOMsg method. " + e);
		}
		return isoMsg;
	}
	
	
}
