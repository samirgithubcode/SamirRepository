/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "customer_call_verification_info")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CustomerCallVerificationInfo.findAll", query = "SELECT c FROM CustomerCallVerificationInfo c"),
    @NamedQuery(name = "CustomerCallVerificationInfo.findById", query = "SELECT c FROM CustomerCallVerificationInfo c WHERE c.id = :id"),
    @NamedQuery(name = "CustomerCallVerificationInfo.findByCustomerId", query = "SELECT c FROM CustomerCallVerificationInfo c WHERE c.customerId = :customerId"),
    @NamedQuery(name = "CustomerCallVerificationInfo.findByCustomerName", query = "SELECT c FROM CustomerCallVerificationInfo c WHERE c.customerName = :customerName"),
    @NamedQuery(name = "CustomerCallVerificationInfo.findByNameVerification", query = "SELECT c FROM CustomerCallVerificationInfo c WHERE c.nameVerification = :nameVerification"),
    @NamedQuery(name = "CustomerCallVerificationInfo.findByEmailidVerification", query = "SELECT c FROM CustomerCallVerificationInfo c WHERE c.emailidVerification = :emailidVerification"),
    @NamedQuery(name = "CustomerCallVerificationInfo.findByDateOfBirthVerification", query = "SELECT c FROM CustomerCallVerificationInfo c WHERE c.dateOfBirthVerification = :dateOfBirthVerification"),
    @NamedQuery(name = "CustomerCallVerificationInfo.findByAddressVerification", query = "SELECT c FROM CustomerCallVerificationInfo c WHERE c.addressVerification = :addressVerification"),
    @NamedQuery(name = "CustomerCallVerificationInfo.findByLoginNameVerification", query = "SELECT c FROM CustomerCallVerificationInfo c WHERE c.loginNameVerification = :loginNameVerification"),
    @NamedQuery(name = "CustomerCallVerificationInfo.findByDocTypeVerification", query = "SELECT c FROM CustomerCallVerificationInfo c WHERE c.docTypeVerification = :docTypeVerification"),
    @NamedQuery(name = "CustomerCallVerificationInfo.findByDocNumberVerification", query = "SELECT c FROM CustomerCallVerificationInfo c WHERE c.docNumberVerification = :docNumberVerification"),
    @NamedQuery(name = "CustomerCallVerificationInfo.findByAltMsisdnNo", query = "SELECT c FROM CustomerCallVerificationInfo c WHERE c.altMsisdnNo = :altMsisdnNo"),
    @NamedQuery(name = "CustomerCallVerificationInfo.findByAltEmailId", query = "SELECT c FROM CustomerCallVerificationInfo c WHERE c.altEmailId = :altEmailId")})
public class CustomerCallVerificationInfo implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
    @Basic(optional = false)
    @Column(name = "customer_id", nullable = false)
    private int customerId;
    @Column(name = "customer_name", length = 200)
    private String customerName;
    @Basic(optional = false)
    @Column(name = "name_verification", nullable = false)
    private boolean nameVerification;
    @Basic(optional = false)
    @Column(name = "emailid_verification", nullable = false)
    private boolean emailidVerification;
    @Basic(optional = false)
    @Column(name = "date_of_birth_verification", nullable = false)
    private boolean dateOfBirthVerification;
    @Basic(optional = false)
    @Column(name = "address_verification", nullable = false)
    private boolean addressVerification;
    @Basic(optional = false)
    @Column(name = "login_name_verification", nullable = false)
    private boolean loginNameVerification;
    @Basic(optional = false)
    @Column(name = "doc_type_verification", nullable = false)
    private boolean docTypeVerification;
    @Basic(optional = false)
    @Column(name = "doc_number_verification", nullable = false)
    private boolean docNumberVerification;
    @Column(name = "alt_msisdn_no", length = 12)
    private String altMsisdnNo;
    @Column(name = "alt_email_id", length = 50)
    private String altEmailId;
    @JoinColumn(name = "call_id", referencedColumnName = "id", nullable = false)
    @ManyToOne(optional = false)
    private CustomerCallDetails callId;
    @JoinColumn(name = "doc_type", referencedColumnName = "id")
    @ManyToOne
    private IdProofs docType;

    public CustomerCallVerificationInfo() {
    	//default constructor
    }

    public CustomerCallVerificationInfo(Integer id) {
        this.id = id;
    }

    public CustomerCallVerificationInfo(Integer id, int customerId, boolean nameVerification, boolean emailidVerification, boolean dateOfBirthVerification, boolean addressVerification, boolean loginNameVerification) {
        this.id = id;
        this.customerId = customerId;
        this.nameVerification = nameVerification;
        this.emailidVerification = emailidVerification;
        this.dateOfBirthVerification = dateOfBirthVerification;
        this.addressVerification = addressVerification;
        this.loginNameVerification = loginNameVerification;
        
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public boolean getNameVerification() {
        return nameVerification;
    }

    public void setNameVerification(boolean nameVerification) {
        this.nameVerification = nameVerification;
    }

    public boolean getEmailidVerification() {
        return emailidVerification;
    }

    public void setEmailidVerification(boolean emailidVerification) {
        this.emailidVerification = emailidVerification;
    }

    public boolean getDateOfBirthVerification() {
        return dateOfBirthVerification;
    }

    public void setDateOfBirthVerification(boolean dateOfBirthVerification) {
        this.dateOfBirthVerification = dateOfBirthVerification;
    }

    public boolean getAddressVerification() {
        return addressVerification;
    }

    public void setAddressVerification(boolean addressVerification) {
        this.addressVerification = addressVerification;
    }

    public boolean getLoginNameVerification() {
        return loginNameVerification;
    }

    public void setLoginNameVerification(boolean loginNameVerification) {
        this.loginNameVerification = loginNameVerification;
    }

    public boolean getDocTypeVerification() {
        return docTypeVerification;
    }

    public void setDocTypeVerification(boolean docTypeVerification) {
        this.docTypeVerification = docTypeVerification;
    }

    public boolean getDocNumberVerification() {
        return docNumberVerification;
    }

    public void setDocNumberVerification(boolean docNumberVerification) {
        this.docNumberVerification = docNumberVerification;
    }

    public String getAltMsisdnNo() {
        return altMsisdnNo;
    }

    public void setAltMsisdnNo(String altMsisdnNo) {
        this.altMsisdnNo = altMsisdnNo;
    }

    public String getAltEmailId() {
        return altEmailId;
    }

    public void setAltEmailId(String altEmailId) {
        this.altEmailId = altEmailId;
    }

    public CustomerCallDetails getCallId() {
        return callId;
    }

    public void setCallId(CustomerCallDetails callId) {
        this.callId = callId;
    }

    public IdProofs getDocType() {
        return docType;
    }

    public void setDocType(IdProofs docType) {
        this.docType = docType;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof CustomerCallVerificationInfo)) {
            return false;
        }
        CustomerCallVerificationInfo other = (CustomerCallVerificationInfo) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.CustomerCallVerificationInfo[ id=" + id + " ]";
    }
    
}
