 
	package com.ng.sb.common.dataobject;
	
	import java.util.Arrays;

import com.ng.sb.common.model.Menu;
	
	/**
	 * @author himanshu
	 *
	 */
	public class MenuDetails  extends BaseObjectData
	{
		private static final long serialVersionUID = 1L;
		private Integer id;
		
		
		private String  menuName;
		private String  action;
		private String description;
		private Menu  parentMenu;
		private String accountType;
		private String groupName;
		private String[] roleList;
		private String parentId;
		private String subMenuId;
		private Integer[] roleIdList;
		
		
		public String getSubMenuId() {
			return subMenuId;
		}

		
		public String getDescription() {
			return description;
		}


		public void setDescription(String description) {
			this.description = description;
		}


		public void setSubMenuId(String subMenuId) {
			this.subMenuId = subMenuId;
		}
		public String getParentId() {
			return parentId;
		}

		public void setParentId(String parentId) {
			this.parentId = parentId;
		}

		public Integer[] getRoleIdList() {
			return roleIdList;
		}

		public void setRoleIdList(Integer[] roleIdList) {
			this.roleIdList = roleIdList;
		}

		public String[] getRoleList() {
			return roleList;
		}

		public void setRoleList(String[] roleList) {
			this.roleList = roleList;
		}

		public String getGroupName() {
			return groupName;
		}

		public void setGroupName(String groupName) {
			this.groupName = groupName;
		}

		public Integer getId() {
			return id;
		}
		
		public void setId(Integer id) {
			this.id = id;
		}
		public String getMenuName() {
			return menuName;
		}
		public void setMenuName(String menuName) {
			this.menuName = menuName;
		}
		public String getAction() {
			return action;
		}
		public void setAction(String action) {
			this.action = action;
		}
		public Menu getParentMenu() {
			return parentMenu;
		}
		public void setParentMenu(Menu parentMenu) {
			this.parentMenu = parentMenu;
		}

		public String getAccountType() {
			return accountType;
		}

		public void setAccountType(String accountType) {
			this.accountType = accountType;
		}


		@Override
		public String toString() {
			StringBuilder builder = new StringBuilder();
			builder.append("MenuDetails [id=");
			builder.append(id);
			builder.append(", menuName=");
			builder.append(menuName);
			builder.append(", action=");
			builder.append(action);
			builder.append(", description=");
			builder.append(description);
			builder.append(", parentMenu=");
			builder.append(parentMenu);
			builder.append(", accountType=");
			builder.append(accountType);
			builder.append(", groupName=");
			builder.append(groupName);
			builder.append(", roleList=");
			builder.append(Arrays.toString(roleList));
			builder.append(", parentId=");
			builder.append(parentId);
			builder.append(", subMenuId=");
			builder.append(subMenuId);
			builder.append(", roleIdList=");
			builder.append(Arrays.toString(roleIdList));
			builder.append("]");
			return builder.toString();
		}

		
		
		
		
		
	}
