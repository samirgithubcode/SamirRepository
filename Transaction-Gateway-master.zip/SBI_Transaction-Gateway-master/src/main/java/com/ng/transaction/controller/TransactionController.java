/**
 * 
 */
package com.ng.transaction.controller;

import java.io.UnsupportedEncodingException;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.MDC;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ng.sb.common.cache.MemCacheManager;
import com.ng.sb.common.cache.MemCacheUtils;
import com.ng.sb.common.dataobject.CustomerAccountData;
import com.ng.sb.common.dataobject.IConstants;
import com.ng.sb.common.dataobject.OverlayIssuance;
import com.ng.sb.common.dataobject.PlatformLoginData;
import com.ng.sb.common.dataobject.RequestObject;
import com.ng.sb.common.dataobject.ResponseObject;
import com.ng.sb.common.dataobject.TransactionData;
import com.ng.sb.common.dataobject.TransactionRequestData;
import com.ng.sb.common.dataobject.UserAccountData;
import com.ng.sb.common.logger.DateTimeUtil;
import com.ng.sb.common.util.CommonUtils;
import com.ng.sb.common.util.ErrorCodes;
import com.ng.sb.common.util.ExceptionUtils;
import com.ng.sb.common.util.KeyEncryptionUtils;
import com.ng.sb.common.util.TransactionIdGenerator;
import com.ng.transaction.data.SecureServiceResponse;
import com.ng.transaction.data.SecureTransactionResponse;
import com.ng.transaction.logger.TxnLogger;
import com.ng.transaction.service.ISecureTransactionService;
import com.ng.transaction.service.ITransactionService;


/**
 * @author gopal
 *
 */
@RestController
@RequestMapping("Transaction/services/secureservice/")
public class TransactionController 
{

	private static final Logger LOGGER = LoggerFactory.getLogger(TransactionController.class);

	@Autowired
    private MemCacheManager cacheManager;
	
	@Autowired
	ITransactionService transactionService;
	
	@Autowired
	PlatformLoginData platformLoginData;
	
	@Autowired
	ISecureTransactionService iSecureTransactionService;
	 
	 @RequestMapping(value = "/transferAmount", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	 public SecureTransactionResponse transferAmount(TransactionRequestData transactionRequestData) 
	 {
		 LOGGER.info("************* transferAmount() starts executing in SecureTransaction **************");
		 SecureTransactionResponse responseData=new SecureTransactionResponse();
		 responseData=iSecureTransactionService.transferMoneyToWallet(transactionRequestData);
		 return responseData;
	 }

	 
	 
	 @RequestMapping(value = "/overlayIssuance", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	 public @ResponseBody ResponseObject overlayIssuance(@RequestBody OverlayIssuance overlayIssuanceData) 
	 {
		 MDC.put("requestId", CommonUtils.getRandomNumber(15));
		 
		 TxnLogger.log(this.getClass().getSimpleName(), TxnLogger.INFO, " [REQUEST] [METHOD_NAME] "+Thread.currentThread().getStackTrace()[1].getMethodName()+" [EXTERNAL_NO] "+overlayIssuanceData.getExternalNumber()+" [MSISDN] "+overlayIssuanceData.getCustomerMsisdn()+" [ACCOUNT_DATA_SIZE] "+overlayIssuanceData.getAccountList().size());
		 
		 ResponseObject responseData = null;
		 
		 try {
			responseData=iSecureTransactionService.overlayIssuance(overlayIssuanceData);
		} catch (Exception e) {
			
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), "com.ng.transaction");

			TxnLogger.log(this.getClass().getSimpleName(), TxnLogger.ERROR, "[ERROR_MESSAGE] " + e + " [CLASS_NAME] " + exceptionData[0] + " [FILE_NAME] " + exceptionData[1] + " [METHOD_NAME] " + exceptionData[2] + " [LINE_NUMBER] " + exceptionData[3]);

			
			// TODO Auto-generated catch block
			responseData = new ResponseObject();
			responseData.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseData.setMessage(e.getMessage());
			e.printStackTrace();
		}
		 
		 TxnLogger.log(this.getClass().getSimpleName(), TxnLogger.INFO, " [RESPONSE] [METHOD_NAME] "+Thread.currentThread().getStackTrace()[1].getMethodName()+" [EXTERNAL_NO] "+overlayIssuanceData.getExternalNumber()+" [MSISDN] "+overlayIssuanceData.getCustomerMsisdn()+" [RESPONSE_STATUS] "+responseData.getStatus()+"  [RESPONSE_MESSAGE] "+responseData.getMessage());
		 MDC.remove("requestId");
		 return responseData;
	 }
	 
	 @RequestMapping(value = "/manageAccounts", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	 public @ResponseBody ResponseObject manageAccounts(@RequestBody OverlayIssuance overlayIssuanceData) 
	 {
		 MDC.put("requestId", CommonUtils.getRandomNumber(15));
		 
		 TxnLogger.log(this.getClass().getSimpleName(), TxnLogger.INFO, " [REQUEST] [METHOD_NAME] "+Thread.currentThread().getStackTrace()[1].getMethodName()+" [ACTION_TYPE] "+overlayIssuanceData.getActionType()+" [MSISDN] "+overlayIssuanceData.getCustomerMsisdn());
		 
		 ResponseObject responseData = null;
		 
		 try {
			responseData=iSecureTransactionService.manageAccounts(overlayIssuanceData);
		} catch (Exception e) {
			
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), "com.ng.transaction");

			TxnLogger.log(this.getClass().getSimpleName(), TxnLogger.ERROR, "[ERROR_MESSAGE] " + e + " [CLASS_NAME] " + exceptionData[0] + " [FILE_NAME] " + exceptionData[1] + " [METHOD_NAME] " + exceptionData[2] + " [LINE_NUMBER] " + exceptionData[3]);

			
			responseData = new ResponseObject();
			responseData.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseData.setMessage(e.getMessage());
			e.printStackTrace();
		}
		 
		 TxnLogger.log(this.getClass().getSimpleName(), TxnLogger.INFO, " [RESPONSE] [METHOD_NAME] "+Thread.currentThread().getStackTrace()[1].getMethodName()+" [ACTION_TYPE] "+overlayIssuanceData.getActionType()+" [MSISDN] "+overlayIssuanceData.getCustomerMsisdn()+" [RESPONSE_STATUS] "+responseData.getStatus()+"  [RESPONSE_MESSAGE] "+responseData.getMessage());
		 MDC.remove("requestId");
		 return responseData;
	 }
	 
	 @RequestMapping(value = "/deActivateOverlay", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	 public @ResponseBody ResponseObject deActivateOverlay(@RequestBody OverlayIssuance overlayIssuanceData) 
	 {
		 MDC.put("requestId", CommonUtils.getRandomNumber(15));
		 
		 TxnLogger.log(this.getClass().getSimpleName(), TxnLogger.INFO, " [REQUEST] [METHOD_NAME] "+Thread.currentThread().getStackTrace()[1].getMethodName()+" [EXTERNAL_NO] "+overlayIssuanceData.getExternalNumber()+" [MSISDN] "+overlayIssuanceData.getCustomerMsisdn());
		 ResponseObject responseData = null;
		 
		 try {
			responseData=iSecureTransactionService.deActivateOverlay(overlayIssuanceData);
		} catch (Exception e) {
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), "com.ng.transaction");

			TxnLogger.log(this.getClass().getSimpleName(), TxnLogger.ERROR, "[ERROR_MESSAGE] " + e + " [CLASS_NAME] " + exceptionData[0] + " [FILE_NAME] " + exceptionData[1] + " [METHOD_NAME] " + exceptionData[2] + " [LINE_NUMBER] " + exceptionData[3]);

			
			responseData = new ResponseObject();
			responseData.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseData.setMessage(e.getMessage());
			e.printStackTrace();
		}
		 
		 TxnLogger.log(this.getClass().getSimpleName(), TxnLogger.INFO, " [RESPONSE] [METHOD_NAME] "+Thread.currentThread().getStackTrace()[1].getMethodName()+" [EXTERNAL_NO] "+overlayIssuanceData.getExternalNumber()+" [MSISDN] "+overlayIssuanceData.getCustomerMsisdn()+" [RESPONSE_STATUS] "+responseData.getStatus()+"  [RESPONSE_MESSAGE] "+responseData.getMessage());
		 MDC.remove("requestId");
		 return responseData;
	 }
	 
	 @RequestMapping(value = "/fetchCustomerDetails", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	 public @ResponseBody ResponseObject fetchCustomerDetails(@RequestBody OverlayIssuance overlayIssuanceData) 
	 {
		 MDC.put("requestId", CommonUtils.getRandomNumber(15));
		 
		 TxnLogger.log(this.getClass().getSimpleName(), TxnLogger.INFO, " [REQUEST] [METHOD_NAME] "+Thread.currentThread().getStackTrace()[1].getMethodName()+" [CUSTOMER_ID] "+overlayIssuanceData.getCustomerID()+" [MSISDN] "+overlayIssuanceData.getCustomerMsisdn() +" [BANK_ID] "+overlayIssuanceData.getBankId());
		 
		 ResponseObject responseData = null;
		 
		 try {
			responseData=iSecureTransactionService.fetchCustomerDetails(overlayIssuanceData);
		} catch (Exception e) {
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), "com.ng.transaction");

			TxnLogger.log(this.getClass().getSimpleName(), TxnLogger.ERROR, "[ERROR_MESSAGE] " + e + " [CLASS_NAME] " + exceptionData[0] + " [FILE_NAME] " + exceptionData[1] + " [METHOD_NAME] " + exceptionData[2] + " [LINE_NUMBER] " + exceptionData[3]);

			
			responseData = new ResponseObject();
			responseData.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseData.setMessage(e.getMessage());
			e.printStackTrace();
		}
		
		 TxnLogger.log(this.getClass().getSimpleName(), TxnLogger.INFO, " [RESPONSE] [METHOD_NAME] "+Thread.currentThread().getStackTrace()[1].getMethodName()+" [CUSTOMER_ID] "+overlayIssuanceData.getCustomerID()+" [MSISDN] "+overlayIssuanceData.getCustomerMsisdn() +" [BANK_ID] "+overlayIssuanceData.getBankId() +" [RESPONSE_STATUS] "+responseData.getStatus()+"  [RESPONSE_MESSAGE] "+responseData.getMessage());
		 MDC.remove("requestId");
		 return responseData;
	 }
	 
	 @RequestMapping(value = "/activateOverlay", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	 public @ResponseBody ResponseObject activateOverlay(@RequestBody OverlayIssuance overlayIssuanceData) 
	 {
		 MDC.put("requestId", CommonUtils.getRandomNumber(15));
		 
		 TxnLogger.log(this.getClass().getSimpleName(), TxnLogger.INFO, " [REQUEST] [METHOD_NAME] "+Thread.currentThread().getStackTrace()[1].getMethodName()+" [EXTERNAL_NO] "+overlayIssuanceData.getExternalNumber()+" [MSISDN] "+overlayIssuanceData.getCustomerMsisdn());
		 
		 ResponseObject responseData = null;
		 
		 try {
			responseData=iSecureTransactionService.activateOverlay(overlayIssuanceData);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			responseData = new ResponseObject();
			responseData.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseData.setMessage(e.getMessage());
			e.printStackTrace();
		}
		 
		 TxnLogger.log(this.getClass().getSimpleName(), TxnLogger.INFO, " [RESPONSE] [METHOD_NAME] "+Thread.currentThread().getStackTrace()[1].getMethodName()+" [EXTERNAL_NO] "+overlayIssuanceData.getExternalNumber()+" [MSISDN] "+overlayIssuanceData.getCustomerMsisdn()+" [RESPONSE_STATUS] "+responseData.getStatus()+"  [RESPONSE_MESSAGE] "+responseData.getMessage());
		 MDC.remove("requestId");
		 return responseData;
	 }
	 
	 @RequestMapping(value = "/issuanceList", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	 public @ResponseBody ResponseObject issuanceList(@RequestBody OverlayIssuance overlayIssuanceData) 
	 {
		 MDC.put("requestId", CommonUtils.getRandomNumber(15));
		 
		 TxnLogger.log(this.getClass().getSimpleName(), TxnLogger.INFO, " [REQUEST] [METHOD_NAME] "+Thread.currentThread().getStackTrace()[1].getMethodName()+" [EXTERNAL_NO] "+overlayIssuanceData.getExternalNumber()+" [MSISDN] "+overlayIssuanceData.getCustomerMsisdn() +" [STATUS] "+overlayIssuanceData.getStatus());
		 
		 ResponseObject responseData = null;
		 
		 try {
			responseData=iSecureTransactionService.issuedList(overlayIssuanceData);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			responseData = new ResponseObject();
			responseData.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseData.setMessage(e.getMessage());
			e.printStackTrace();
		}
		 
		 TxnLogger.log(this.getClass().getSimpleName(), TxnLogger.INFO, " [REQUEST] [METHOD_NAME] "+Thread.currentThread().getStackTrace()[1].getMethodName()+" [EXTERNAL_NO] "+overlayIssuanceData.getExternalNumber()+" [MSISDN] "+overlayIssuanceData.getCustomerMsisdn() +" [STATUS] "+overlayIssuanceData.getStatus()+" [RESPONSE_STATUS] "+responseData.getStatus()+"  [RESPONSE_MESSAGE] "+responseData.getMessage());
		 
		 MDC.remove("requestId");
		 return responseData;
	 }
	 
	 
	 @RequestMapping(value = "/purgeAllData", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	 public @ResponseBody ResponseObject removeAllData(@RequestBody OverlayIssuance overlayIssuanceData) 
	 {
		 MDC.put("requestId", CommonUtils.getRandomNumber(15));
		 
		 TxnLogger.log(this.getClass().getSimpleName(), TxnLogger.INFO, " [REQUEST] [METHOD_NAME] "+Thread.currentThread().getStackTrace()[1].getMethodName()+" [MSISDN] "+overlayIssuanceData.getCustomerMsisdn());
		 
		 ResponseObject responseData = null;
		 
		 try {
			responseData=iSecureTransactionService.removeAllData(overlayIssuanceData);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			responseData = new ResponseObject();
			responseData.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseData.setMessage(e.getMessage());
			e.printStackTrace();
		}
		 
		 TxnLogger.log(this.getClass().getSimpleName(), TxnLogger.INFO, " [REQUEST] [METHOD_NAME] "+Thread.currentThread().getStackTrace()[1].getMethodName()+" [MSISDN] "+overlayIssuanceData.getCustomerMsisdn() +" [RESPONSE_STATUS] "+responseData.getStatus()+"  [RESPONSE_MESSAGE] "+responseData.getMessage());
		 
		 MDC.remove("requestId");
		 return responseData;
	 }
	 
	    @RequestMapping(value = "/encrypted/starttransaction/local/mkey", method = RequestMethod.GET, produces="application/json")
		public SecureServiceResponse startTransactionLocalMKey(@RequestParam(IConstants.SERVICE_PARAM1) String param1,
				@RequestParam(IConstants.SERVICE_PARAM2) String param2,
				@RequestParam(IConstants.SERVICE_PARAM3) String param3,
				@RequestParam(IConstants.SERVICE_SMSCID) String smscid,
				@RequestParam(IConstants.SERVICE_CHARSET) String charset,
				@RequestParam(IConstants.SERVICE_BMSG) String bmsg) {
			LOGGER.info("In SecureService - method - startTransaction ===>>");
			System.out.println("Hello - " + new Date() + " ---- param1-->  " + param1 + " param2--> " + param2 + " param3-->  " + param3 + "  smscid-->  " + smscid + "charset--> " + charset + "  bmsg-->  " + bmsg);
 			TransactionData transactionData = createTransactionData(param1, param2, param3, smscid, charset, bmsg,false);
			try {
				// Get and adding dkey from encrypted String
				transactionData.setdKeyChar(param1.substring(0, 1));
				transactionData.setInternalNumberRequest(param1.substring(1, param1.length()));
				
				//MOProcessingThread processingThread = getMOProcessingThread();
				
				//processingThread.setTransactionData(transactionData);
				transactionData.setRequestTime(System.currentTimeMillis());
				//processingThread.start();
				transactionService.requestFacade(transactionData);
			} catch (Exception e) {
				e.printStackTrace();
			}
			/*SecureServiceResponse response = new SecureServiceResponse();
			response.setResponseCode(200);
			response.setResponseString("Transaction is successful.");*/
			return null;
		}
	    
	    
	    private TransactionData createTransactionData(String param1, String param2,String param3, String smscid, String charset, String bmsg,boolean withoutEncryption){
			TransactionData transactionData = new TransactionData();
			String dateTime=DateTimeUtil.getDateAndTime("dd-MM-yyyy", new Date());
			String transactionId=new TransactionIdGenerator().genTransId();
			String clientRefId=new TransactionIdGenerator().getClientRefId();
			transactionData.setClientReferenceId(clientRefId);
			
			
			String operationalCommand=null;
			try {
				if(withoutEncryption){
					transactionData.setSkipNumeric(true);
					if(param1!=null && !param1.isEmpty() && param1.contains("@"))
					{
						param1 = param1.replaceAll("@", "+");
					
						// Internal Number
						String interNum = param1.substring(param1.lastIndexOf("-")+1, param1.length());
						transactionData.setInternalNumberRequest(interNum);
						
						// serviceSTKCode
						String serviceSTKCode = param1.substring(0, param1.indexOf("-"));
						transactionData.setReqStkCode(serviceSTKCode);
						
						// CommandString
						String combinedParamString = param1.substring(param1.indexOf("-")+1, param1.lastIndexOf("-"));
						combinedParamString = combinedParamString.substring(0, combinedParamString.lastIndexOf("-"));
						transactionData.setCombinedParamString(combinedParamString);
					}
					operationalCommand = param1;
				}else{
					transactionData.setSkipNumeric(true);
					operationalCommand = new String(param1.getBytes("iso-8859-1"), "UTF-8");
				}
				
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			transactionData.setDateTime(dateTime);
			transactionData.setGatewaystatus(true);
			transactionData.setUserIp(null);
			transactionData.setTransactionId(transactionId);
			transactionData.setOperationalCommand(operationalCommand);
			
			/*if(param2.length()==13)
				transactionData.setMsisdn(param2.substring(3,13));
			else if (param2.length()==12) 
				transactionData.setMsisdn(param2.substring(2,12));
			else if (param2.length()==10) 
				transactionData.setMsisdn(param2);
			*/
			
			int mobileNumberLength = platformLoginData.getMobileNumberLength();
			
			int subStringStartIndex = (param2.length() - mobileNumberLength);
			
			transactionData.setMsisdn(param2.substring(subStringStartIndex));
			
			transactionData.setServiceCode(param3);
			LOGGER.info("TransactionId : "+ transactionId + " SMS LongCode ##  " + param3 + " WalletId/MSISDN ##  " + param2);
			LOGGER.info("TransactionId : "+ transactionId + " In SecureService -  createTransactionData method. ");
			return transactionData;
		}
	    
	    @RequestMapping(value = "/getCustomerAccountDetails", method = RequestMethod.POST, consumes="application/json",produces="application/json")
		public @ResponseBody ResponseObject getCustomerAccountDetails(@RequestBody RequestObject requestObject, HttpServletRequest request) 
		 {
			 LOGGER.info("************* getCustomerAccountDetails() starts executing in TransactionController **************");
			 ResponseObject responseObject = new ResponseObject();
			 
			// AccountDetailRequest otpRequest = null;
				Object payload =  requestObject.getPayload();
				UserAccountData accountData = null;
				try
				{
					//Check token Validity
					accountData = cacheManager.getFromCache(requestObject.getTokenId(), UserAccountData.class, MemCacheUtils.AUTHTOKENCACHE);
					
					responseObject = com.ng.transaction.util.CommonUtils.validateRequest(accountData, requestObject, request);
					
					if(responseObject.getStatus() != null)
						return responseObject;
					
					//otpRequest = KeyEncryptionUtils.jsonStringToObject(KeyEncryptionUtils.decryptUsingKey(accountData.getSecretKey(), payload), AccountDetailRequest.class);
					
					//responseObject = com.ng.transaction.util.CommonUtils.validateRequestData(otpRequest, requestObject, request);
					  
					/*if(responseObject.getStatus() != null)
						return responseObject;*/
					
					 TransactionData transactionData = new TransactionData();
					 
					 	transactionData.setMsisdn(accountData.getMobileNo());
					 	
					 CustomerAccountData customerData =	transactionService.getCustomerAccountInfo(transactionData);
					 
					 if(customerData != null)
					 {
						 responseObject.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
						 responseObject.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
						 
						 String encryptedData = KeyEncryptionUtils.encryptUsingKey(accountData.getSecretKey(), customerData);
						 
						 responseObject.setPayload(encryptedData);
						 
					 }else{
						 responseObject.setStatus(ErrorCodes.NO_RECORDS_FOUND.getCode());
						 responseObject.setMessage(ErrorCodes.NO_RECORDS_FOUND.getMessage());
					 }
					 
					  LOGGER.info("[RESPONSE]  [METHOD_NAME] "+Thread.currentThread().getStackTrace()[1].getMethodName()+ " [ACCESS_CHANNEL] "  + requestObject.getChannelId() + " [REQUEST_FROM] " +request.getRemoteAddr() + " [RESPONSE_CODE] " +responseObject.getStatus() +  " [RESPONSE_MESSAGE] " +responseObject.getMessage());
					  
			}catch(Exception e)
			{
				String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), "com.ng");
				
				LOGGER.error("[METHOD_NAME] "+Thread.currentThread().getStackTrace()[1].getMethodName()+" [ERROR_MESSAGE] "+e+ " [CLASS_NAME] " +exceptionData[0]+ " [FILE_NAME] "+exceptionData[1]+ " [METHOD_NAME] "+exceptionData[2]+" [LINE_NUMBER] "+exceptionData[3]);
				
				responseObject.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
				responseObject.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e.getMessage());
			}
			return responseObject;
		 }
}
