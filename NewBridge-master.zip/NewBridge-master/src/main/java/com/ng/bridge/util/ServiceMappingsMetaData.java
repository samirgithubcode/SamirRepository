package com.ng.bridge.util;

import java.util.HashMap;
import java.util.Map;

import com.ng.sb.common.dataobject.BaseObjectData;
import com.ng.sb.common.dataobject.BridgeDataObject;
import com.ng.sb.common.dataobject.FSPServiceInstrumentData;
import com.ng.sb.common.dataobject.IConstants;
import com.ng.sb.common.dataobject.MethodMappings;
import com.ng.sb.common.dataobject.ServiceMappingDef;
import com.ng.sb.common.dataobject.BridgeDataObject.ServiceType;
import com.ng.sb.common.dataobject.HostSubVersionData.ProviderRelation;
import com.ng.sb.common.dataobject.PartnerData.BankRelation;
import com.ng.sb.common.dataobject.ServiceMappingDef.BankSide;
import com.ng.sb.common.util.SystemConstant;

public class ServiceMappingsMetaData extends BaseObjectData {
	private static final long serialVersionUID = 1L;
	Map<ServiceType, ServiceMappingDef> serviceMap = new HashMap<BridgeDataObject.ServiceType, ServiceMappingDef>();
	private static ServiceMappingsMetaData instance = new ServiceMappingsMetaData();

	private ServiceMappingsMetaData() {
		fillData();
	}

	private void fillData(){
		//FundTransfer
		serviceMap.put(ServiceType.BANKING_FT_B_TO_B, new ServiceMappingDef(IConstants.B_T_B,IConstants.RI_T_B,IConstants.BANK,IConstants.BANK,BankSide.BOTH));
		serviceMap.put(ServiceType.BANKING_FT_B_TO_CC, new ServiceMappingDef(IConstants.B_T_CC,IConstants.RI_T_CC,IConstants.BANK,IConstants.CREDITCARD,BankSide.PAYER_ONLY));
		serviceMap.put(ServiceType.BANKING_FT_B_TO_IMPS, new ServiceMappingDef(IConstants.B_T_IMPS,IConstants.RI_T_IMPS,IConstants.BANK,IConstants.IMPS,BankSide.PAYER_ONLY));
		serviceMap.put(ServiceType.BANKING_FT_B_TO_WALLET, new ServiceMappingDef(IConstants.B_T_W,IConstants.RI_T_W,IConstants.BANK,IConstants.WALLET,BankSide.PAYER_ONLY));
		
		// For Mom
		serviceMap.put(ServiceType.MWALLET_AG_TOP_UP_ONLINE_W_T_W,  new ServiceMappingDef(IConstants.W_T_W,IConstants.RI_T_W,IConstants.WALLET,IConstants.WALLET,BankSide.NO_BANK));

		
		//MWALLET_AG_CHK_BAL,
		//MWALLET_CUST_CHK_BAL,
		//
		// M-WALLET
		
		serviceMap.put(ServiceType.MWALLET_AG_CHK_BAL, new ServiceMappingDef(IConstants.MWALLET_CHECK_BALANCE,BankSide.PAYER_ONLY,BankRelation.FSP_SERVICE));
		serviceMap.put(ServiceType.MWALLET_CUST_CHK_BAL, new ServiceMappingDef(IConstants.MWALLET_CHECK_BALANCE,BankSide.PAYER_ONLY,BankRelation.FSP_SERVICE));
		serviceMap.put(ServiceType.MWALLET_CUST_TOP_UP_ONLINE_B_T_W, new ServiceMappingDef(IConstants.B_T_W,IConstants.RI_T_W,IConstants.BANK,IConstants.WALLET,BankSide.PAYER_ONLY));

		serviceMap.put(ServiceType.MWALLET_CUST_CASH_OUT_WALLET, new ServiceMappingDef(IConstants.WALLET_CASH_OUT_TO_WALLET,IConstants.W_T_W,IConstants.WALLET,IConstants.WALLET,BankSide.NO_BANK));
		
		serviceMap.put(ServiceType.MWALLET_AG_TOP_UP_ONLINE_B_T_W, new ServiceMappingDef(IConstants.B_T_W,IConstants.RI_T_W,IConstants.BANK,IConstants.WALLET,BankSide.PAYER_ONLY));
		
		serviceMap.put(ServiceType.MWALLET_AG_TOP_UP_ACCOUNT_B_T_W, new ServiceMappingDef(IConstants.B_T_W,IConstants.RI_T_W,IConstants.BANK,IConstants.WALLET,BankSide.PAYER_ONLY));
		serviceMap.put(ServiceType.MWALLET_AG_TOP_UP_ACCOUNT_B_T_B, new ServiceMappingDef(IConstants.B_T_B,IConstants.RI_T_B,IConstants.BANK,IConstants.BANK,BankSide.BOTH));
		
		//New 
		serviceMap.put(ServiceType.OTH_PAY_RET_B_TO_B, new ServiceMappingDef(IConstants.B_T_B,IConstants.RI_T_B,IConstants.BANK,IConstants.BANK,BankSide.BOTH));
		serviceMap.put(ServiceType.OTH_PAY_RET_B_TO_WALLET,new ServiceMappingDef(IConstants.B_T_W,IConstants.RI_T_W,IConstants.BANK,IConstants.WALLET,BankSide.PAYER_ONLY));
		serviceMap.put(ServiceType.OTH_PAY_RET_WALLET_TO_WALLET,new ServiceMappingDef(IConstants.W_T_W,IConstants.RI_T_W,IConstants.WALLET,IConstants.WALLET,BankSide.NO_BANK));
		serviceMap.put(ServiceType.OTH_PAY_RET_WALLET_TO_B,new ServiceMappingDef(IConstants.W_T_B,IConstants.RI_T_B,IConstants.WALLET,IConstants.BANK,BankSide.PAYEE_ONLY));
		
		serviceMap.put(ServiceType.OTH_PAY_INDI_B_TO_B,   new ServiceMappingDef(IConstants.B_T_B,IConstants.RI_T_B,IConstants.BANK,IConstants.BANK,BankSide.BOTH));
		serviceMap.put(ServiceType.OTH_PAY_INDI_B_TO_WALLET, new ServiceMappingDef(IConstants.B_T_W,IConstants.RI_T_W,IConstants.BANK,IConstants.WALLET,BankSide.PAYER_ONLY));
		serviceMap.put(ServiceType.OTH_PAY_INDI_WALLET_TO_WALLET, new ServiceMappingDef(IConstants.W_T_W,IConstants.RI_T_W,IConstants.WALLET,IConstants.WALLET,BankSide.NO_BANK));
		serviceMap.put(ServiceType.OTH_PAY_INDI_WALLET_TO_B, new ServiceMappingDef(IConstants.W_T_B,IConstants.RI_T_B,IConstants.WALLET,IConstants.BANK,BankSide.PAYEE_ONLY));
		
		
		//FundTransferToBiller - BillPay
		serviceMap.put(ServiceType.BILL_PAY_BY_B, new ServiceMappingDef(ProviderRelation.FSP_PROVIDER,ProviderRelation.REGISTERED_INSTRUMENT_FSP_PROVIDER,IConstants.BANK,ProviderRelation.DIRECT_PROVIDER,BankSide.PAYER_ONLY));
		serviceMap.put(ServiceType.BILL_PAY_BY_CC, new ServiceMappingDef(ProviderRelation.FSP_PROVIDER,ProviderRelation.REGISTERED_INSTRUMENT_FSP_PROVIDER,IConstants.CREDITCARD,ProviderRelation.DIRECT_PROVIDER,BankSide.NO_BANK));
		serviceMap.put(ServiceType.BILL_PAY_BY_IMPS, new ServiceMappingDef(ProviderRelation.FSP_PROVIDER,ProviderRelation.REGISTERED_INSTRUMENT_FSP_PROVIDER,IConstants.IMPS,ProviderRelation.DIRECT_PROVIDER,BankSide.NO_BANK));
		serviceMap.put(ServiceType.BILL_PAY_BY_WALLET, new ServiceMappingDef(ProviderRelation.FSP_PROVIDER,ProviderRelation.REGISTERED_INSTRUMENT_FSP_PROVIDER,IConstants.WALLET,ProviderRelation.DIRECT_PROVIDER,BankSide.NO_BANK));
		
		//Recharge by Wallet - TopUp
		serviceMap.put(ServiceType.TOP_UP_RECH_BY_WALLET, new ServiceMappingDef(ProviderRelation.FSP_PROVIDER,ProviderRelation.REGISTERED_INSTRUMENT_FSP_PROVIDER,IConstants.WALLET,ProviderRelation.DIRECT_PROVIDER,BankSide.NO_BANK));
		serviceMap.put(ServiceType.TOP_UP_RECH_BY_CC, new ServiceMappingDef(ProviderRelation.FSP_PROVIDER,ProviderRelation.REGISTERED_INSTRUMENT_FSP_PROVIDER,IConstants.CREDITCARD,ProviderRelation.DIRECT_PROVIDER,BankSide.NO_BANK));
		serviceMap.put(ServiceType.TOP_UP_RECH_BY_B, new ServiceMappingDef(ProviderRelation.FSP_PROVIDER,ProviderRelation.REGISTERED_INSTRUMENT_FSP_PROVIDER,IConstants.BANK,ProviderRelation.DIRECT_PROVIDER,BankSide.PAYEE_ONLY));
		serviceMap.put(ServiceType.TOP_UP_RECH_BY_IMPS, new ServiceMappingDef(ProviderRelation.FSP_PROVIDER,ProviderRelation.REGISTERED_INSTRUMENT_FSP_PROVIDER,IConstants.IMPS,ProviderRelation.DIRECT_PROVIDER,BankSide.NO_BANK));
		
		
		//OtherServices
		serviceMap.put(ServiceType.BANKING_CHQ_STATUS, new ServiceMappingDef(IConstants.CHEQUE_STATUS,BankSide.PAYER_ONLY,BankRelation.OTHER_SERVICE));
		serviceMap.put(ServiceType.SETTINGS_MMID_GENERATE, new ServiceMappingDef(IConstants.GENERATE_MPIN,BankSide.NO_BANK,BankRelation.OTHER_SERVICE));
		serviceMap.put(ServiceType.SETTINGS_MMID_GENERATE, new ServiceMappingDef(IConstants.GENERATE_MPIN,BankSide.NO_BANK,BankRelation.OTHER_SERVICE));
		serviceMap.put(ServiceType.SETTINGS_CREATE_PIN_TRANSACTION, new ServiceMappingDef(IConstants.CREATE_PIN,BankSide.PAYER_ONLY,BankRelation.OTHER_SERVICE));
		serviceMap.put(ServiceType.SETTINGS_CHANGE_PIN_TRANSACTION, new ServiceMappingDef(IConstants.CHANGE_PIN,BankSide.PAYER_ONLY,BankRelation.OTHER_SERVICE));
		serviceMap.put(ServiceType.SETTINGS_CREATE_PIN_WALLET, new ServiceMappingDef(IConstants.CREATE_WALLET_PIN,BankSide.PAYER_ONLY,BankRelation.OTHER_SERVICE));
		serviceMap.put(ServiceType.SETTINGS_CHANGE_PIN_WALLET, new ServiceMappingDef(IConstants.CHANGE_WALLET_PIN,BankSide.PAYER_ONLY,BankRelation.OTHER_SERVICE));
		
		// MONEY TRANSFER
		serviceMap.put(ServiceType.MONEY_TRANSFER, new ServiceMappingDef(IConstants.MONEY_TRANSFER,BankSide.PAYEE_ONLY,BankRelation.OTHER_SERVICE));
		
		// FSP OTHER SERVICES
		serviceMap.put(ServiceType.SETTINGS_BANK_ACC_ADD, new ServiceMappingDef(IConstants.ADD_BANK_ACCOUNT,BankSide.PAYER_ONLY,BankRelation.FSP_SERVICE));
		serviceMap.put(ServiceType.SETTINGS_MY_PAYEE_ADD, new ServiceMappingDef(IConstants.ADD_MY_PAYEE,BankSide.PAYER_ONLY,BankRelation.FSP_SERVICE));
		serviceMap.put(ServiceType.SETTINGS_MY_MERCHANT_ADD, new ServiceMappingDef(IConstants.ADD_MY_MERCHANT,BankSide.PAYER_ONLY,BankRelation.FSP_SERVICE));
		serviceMap.put(ServiceType.SETTINGS_MY_BILLER_ADD, new ServiceMappingDef(IConstants.ADD_MY_BILLER,BankSide.PAYER_ONLY,BankRelation.OTHER_SERVICE));
		
		serviceMap.put(ServiceType.SETTINGS_MY_PAYEE_EDIT, new ServiceMappingDef(IConstants.EDIT_MY_PAYEE,BankSide.PAYER_ONLY,BankRelation.FSP_SERVICE));
		serviceMap.put(ServiceType.SETTINGS_MY_MERCHANT_EDIT, new ServiceMappingDef(IConstants.EDIT_MY_MERCHANT,BankSide.PAYER_ONLY,BankRelation.FSP_SERVICE));
		serviceMap.put(ServiceType.SETTINGS_MY_BILLER_EDIT, new ServiceMappingDef(IConstants.EDIT_MY_BILLER,BankSide.PAYER_ONLY,BankRelation.OTHER_SERVICE));
		
		serviceMap.put(ServiceType.SETTINGS_MY_PAYEE_DELETE, new ServiceMappingDef(IConstants.DELETE_MY_PAYEE,BankSide.PAYER_ONLY,BankRelation.FSP_SERVICE));
		serviceMap.put(ServiceType.SETTINGS_MY_MERCHANT_DELETE, new ServiceMappingDef(IConstants.DELETE_MY_MERCHANT,BankSide.PAYER_ONLY,BankRelation.FSP_SERVICE));
		serviceMap.put(ServiceType.SETTINGS_MY_BILLER_DELETE, new ServiceMappingDef(IConstants.DELETE_MY_BILLER,BankSide.PAYER_ONLY,BankRelation.OTHER_SERVICE));
		
		serviceMap.put(ServiceType.BANKING_CHECK_BAL, new ServiceMappingDef(IConstants.CHECK_BALANCE,BankSide.PAYER_ONLY,BankRelation.FSP_SERVICE));
		serviceMap.put(ServiceType.BANKING_STOP_CHEQUE, new ServiceMappingDef(IConstants.STOP_CHEQUE,BankSide.PAYER_ONLY,BankRelation.FSP_SERVICE));
		serviceMap.put(ServiceType.BANKING_LAST_5_TRANS, new ServiceMappingDef(IConstants.BANKING_LAST_5_TRANS,BankSide.PAYER_ONLY,BankRelation.FSP_SERVICE));
		serviceMap.put(ServiceType.BANKING_CHQ_BOOK_REQUEST, new ServiceMappingDef(IConstants.CHQ_BOOK_REQUEST,BankSide.PAYER_ONLY,BankRelation.FSP_SERVICE));
		serviceMap.put(ServiceType.BANKING_FT_UPI_TO_UPI, new ServiceMappingDef(IConstants.CHECK_BALANCE,BankSide.PAYER_ONLY,BankRelation.FSP_SERVICE));		
		
	}
	public static ServiceMappingsMetaData getInstance() {
		return instance;
	}
	
	public FSPServiceInstrumentData getFSPServiceAndInstruments(ServiceType serviceType){
		if(serviceType==null){
			return null;
		}
		return serviceMap.get(serviceType).getFSPServiceAndInstrument();
	}
}

