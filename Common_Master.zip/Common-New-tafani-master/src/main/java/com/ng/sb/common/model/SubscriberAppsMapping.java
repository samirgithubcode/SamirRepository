/**
 * 
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author gopal
 *
 */
public class SubscriberAppsMapping implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "id")
	private Integer id;
	

	@Column(name = "customer_id")
	private String customerId;

	@Column(name = "subscriber_id")
	private Integer subscriberId;
	
	@JoinColumn(name = "paycard_id", referencedColumnName = "id")
	@ManyToOne
	private InventoryMgmt paycardId;
	
	@JoinColumn(name = "paycard_type_id", referencedColumnName = "id")
	@ManyToOne
	private CardDetails productTypeId;


	@JoinColumn(name = "paycard_app_id", referencedColumnName = "id")
	@ManyToOne
	private PayCardApps payCardApp;
	
	@Column(name = "paycard_constant_id")
	private String payCardConstantId;
	
	@Column(name = "added_on")
    @Temporal(TemporalType.DATE)
    private Date startDate;
    
    @Column(name = "status")
    private Boolean mappingStatus;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public Integer getSubscriberId() {
		return subscriberId;
	}

	public void setSubscriberId(Integer subscriberId) {
		this.subscriberId = subscriberId;
	}

	public InventoryMgmt getPaycardId() {
		return paycardId;
	}

	public void setPaycardId(InventoryMgmt paycardId) {
		this.paycardId = paycardId;
	}

	public CardDetails getProductTypeId() {
		return productTypeId;
	}

	public void setProductTypeId(CardDetails productTypeId) {
		this.productTypeId = productTypeId;
	}

	public PayCardApps getPayCardApp() {
		return payCardApp;
	}

	public void setPayCardApp(PayCardApps payCardApp) {
		this.payCardApp = payCardApp;
	}

	public String getPayCardConstantId() {
		return payCardConstantId;
	}

	public void setPayCardConstantId(String payCardConstantId) {
		this.payCardConstantId = payCardConstantId;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Boolean getMappingStatus() {
		return mappingStatus;
	}

	public void setMappingStatus(Boolean mappingStatus) {
		this.mappingStatus = mappingStatus;
	}
	
    
}
