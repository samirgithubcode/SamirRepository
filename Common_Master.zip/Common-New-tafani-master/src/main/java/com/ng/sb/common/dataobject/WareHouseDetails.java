package com.ng.sb.common.dataobject;

public class WareHouseDetails  extends BaseObjectData {
	private static final long serialVersionUID = 1L;
	private String orderNumber;
	private String productName;
	private String masterVersion;
	private String unitsOrdered;
	private String unitsDispatched;
	private String boxReceived;
	private String unitsPending;
	private String boxPending;
	public String getOrderNumber() {
		return orderNumber;
	}
	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getMasterVersion() {
		return masterVersion;
	}
	public void setMasterVersion(String masterVersion) {
		this.masterVersion = masterVersion;
	}
	public String getUnitsOrdered() {
		return unitsOrdered;
	}
	public void setUnitsOrdered(String unitsOrdered) {
		this.unitsOrdered = unitsOrdered;
	}
	public String getUnitsDispatched() {
		return unitsDispatched;
	}
	public void setUnitsDispatched(String unitsDispatched) {
		this.unitsDispatched = unitsDispatched;
	}
	public String getBoxReceived() {
		return boxReceived;
	}
	public void setBoxReceived(String boxReceived) {
		this.boxReceived = boxReceived;
	}
	public String getUnitsPending() {
		return unitsPending;
	}
	public void setUnitsPending(String unitsPending) {
		this.unitsPending = unitsPending;
	}
	public String getBoxPending() {
		return boxPending;
	}
	public void setBoxPending(String boxPending) {
		this.boxPending = boxPending;
	}
}
