/**
 * 
 */
package com.ng.bridge.util;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ng.sb.common.dataobject.BridgeDataObject;
import com.ng.sb.common.dataobject.BridgeDataObject.ServiceType;
import com.ng.sb.common.dataobject.ServiceMappingDef.BankSide;
import com.ng.sb.common.dataobject.IConstants;
import com.ng.sb.common.dataobject.MethodMappings;
import com.ng.sb.common.dataobject.ReflectionData;
import com.ng.sb.common.dataobject.ServiceMappingDef;
import com.ng.sb.common.util.SpringContextUtil;
import com.ng.sb.common.util.SystemConstant;

/**
 * @author gaurav
 *
 */
public class ServiceIdentifierMetaData {
	private static final Logger LOGGER = LoggerFactory.getLogger(ServiceIdentifierMetaData.class);
	private Map<String, String> serviceMap = new HashMap<>();
	private Map<ServiceType, MethodMappings> serviceMethodMap = new HashMap<>();
	private Map<String,ReflectionData> callableServiceMethodsMap = new HashMap<>();

	private static ServiceIdentifierMetaData instance = new ServiceIdentifierMetaData();

	private ServiceIdentifierMetaData() {
		fillMaps();
		addMethods(this.serviceMap, this.callableServiceMethodsMap);
	}

	public static ServiceIdentifierMetaData getInstance() {
		return instance;
	}

	private void fillMaps() {
		fillServiceMap();
		fillServiceMethodsMap();
	}


	private void fillServiceMap() {

		// For Partner Services
		
		serviceMap.put(SystemConstant.PARTNER_PNB, SystemConstant.PNB_INVOKER);
//		serviceMap.put(SystemConstant.PARTNER_OROMIA, SystemConstant.OROMIA_INVOKER);
		serviceMap.put(SystemConstant.PARTNER_HDFC_TRANSIT, SystemConstant.HDFC_TRANSIT_INVOKER);
		serviceMap.put(SystemConstant.PARTNER_HDFC_SHOPPING, SystemConstant.HDFC_SHOPPING_INVOKER);
		serviceMap.put(SystemConstant.PARTNER_SBI_PAYMENT, SystemConstant.SBI_PAYMENT_INVOKER);
		serviceMap.put(SystemConstant.PARTNER_ICICI_BANKING, SystemConstant.ICICI_BANKING_INVOKER);
		
			
	}
	
	private void fillServiceMethodsMap() {

		//WALLET TO WALLET - FUND TRANSFER 
		serviceMethodMap.put(ServiceType.MWALLET_AG_CHK_BAL, new MethodMappings(SystemConstant.FSP_WALLET_BAL_ENQUIRY_METHOD, null, null, null));
		serviceMethodMap.put(ServiceType.MWALLET_CUST_CHK_BAL, new MethodMappings(SystemConstant.FSP_WALLET_BAL_ENQUIRY_METHOD, null, null, null));
		serviceMethodMap.put(ServiceType.MWALLET_CUST_TOP_UP_ONLINE_B_T_W, new MethodMappings(SystemConstant.FSP_BANK_TO_WALLET_METHOD, SystemConstant.DIRECT_DEDUCT_AMOUNT_THRU_BANK_METHOD, SystemConstant.DIRECT_ADD_AMOUNT_IN_WALLET_METHOD, null));
		
		serviceMethodMap.put(ServiceType.MWALLET_CUST_CASH_OUT_WALLET, new MethodMappings(SystemConstant.FSP_WALLET_TO_WALLET_METHOD, SystemConstant.DIRECT_DEDUCT_AMOUNT_THRU_WALLET_METHOD, SystemConstant.DIRECT_ADD_AMOUNT_IN_WALLET_METHOD, null));
		
		serviceMethodMap.put(ServiceType.MWALLET_AG_TOP_UP_ONLINE_W_T_W, new MethodMappings(SystemConstant.FSP_WALLET_TO_WALLET_METHOD, SystemConstant.DIRECT_DEDUCT_AMOUNT_THRU_WALLET_METHOD, SystemConstant.DIRECT_ADD_AMOUNT_IN_WALLET_METHOD, null)); 
		serviceMethodMap.put(ServiceType.MWALLET_AG_TOP_UP_ONLINE_B_T_W, new MethodMappings(SystemConstant.FSP_BANK_TO_WALLET_METHOD, SystemConstant.DIRECT_DEDUCT_AMOUNT_THRU_BANK_METHOD, SystemConstant.DIRECT_ADD_AMOUNT_IN_WALLET_METHOD, null));
		
		serviceMethodMap.put(ServiceType.MWALLET_AG_TOP_UP_ACCOUNT_B_T_W, new MethodMappings(SystemConstant.FSP_BANK_TO_WALLET_METHOD, SystemConstant.DIRECT_DEDUCT_AMOUNT_THRU_BANK_METHOD, SystemConstant.DIRECT_ADD_AMOUNT_IN_WALLET_METHOD, null)); 
		serviceMethodMap.put(ServiceType.MWALLET_AG_TOP_UP_ACCOUNT_B_T_B, new MethodMappings(SystemConstant.FSP_BANK_TO_BANK_METHOD, SystemConstant.DIRECT_DEDUCT_AMOUNT_THRU_BANK_METHOD, SystemConstant.DIRECT_ADD_AMOUNT_IN_BANK_METHOD, null));
		
		
		//New
		serviceMethodMap.put(ServiceType.OTH_PAY_RET_B_TO_B, new MethodMappings(SystemConstant.FSP_BANK_TO_BANK_METHOD, SystemConstant.DIRECT_DEDUCT_AMOUNT_THRU_BANK_METHOD, SystemConstant.DIRECT_ADD_AMOUNT_IN_BANK_METHOD, null));
		serviceMethodMap.put(ServiceType.OTH_PAY_RET_B_TO_WALLET, new MethodMappings(SystemConstant.FSP_BANK_TO_WALLET_METHOD, SystemConstant.DIRECT_DEDUCT_AMOUNT_THRU_BANK_METHOD, SystemConstant.DIRECT_ADD_AMOUNT_IN_WALLET_METHOD, null));
		serviceMethodMap.put(ServiceType.OTH_PAY_RET_WALLET_TO_WALLET, new MethodMappings(SystemConstant.FSP_WALLET_TO_WALLET_METHOD, SystemConstant.DIRECT_DEDUCT_AMOUNT_THRU_WALLET_METHOD, SystemConstant.DIRECT_ADD_AMOUNT_IN_WALLET_METHOD, null));
		serviceMethodMap.put(ServiceType.OTH_PAY_RET_WALLET_TO_B, new MethodMappings(SystemConstant.FSP_WALLET_TO_BANK_METHOD, SystemConstant.DIRECT_DEDUCT_AMOUNT_THRU_WALLET_METHOD, SystemConstant.DIRECT_ADD_AMOUNT_IN_BANK_METHOD, null));
		
		serviceMethodMap.put(ServiceType.OTH_PAY_INDI_B_TO_B,   new MethodMappings(SystemConstant.FSP_BANK_TO_BANK_METHOD, SystemConstant.DIRECT_DEDUCT_AMOUNT_THRU_BANK_METHOD, SystemConstant.DIRECT_ADD_AMOUNT_IN_BANK_METHOD, null));
		serviceMethodMap.put(ServiceType.OTH_PAY_INDI_B_TO_WALLET,   new MethodMappings(SystemConstant.FSP_BANK_TO_WALLET_METHOD, SystemConstant.DIRECT_DEDUCT_AMOUNT_THRU_BANK_METHOD, SystemConstant.DIRECT_ADD_AMOUNT_IN_WALLET_METHOD, null));
		serviceMethodMap.put(ServiceType.OTH_PAY_INDI_WALLET_TO_WALLET,  new MethodMappings(SystemConstant.FSP_WALLET_TO_WALLET_METHOD, SystemConstant.DIRECT_DEDUCT_AMOUNT_THRU_WALLET_METHOD, SystemConstant.DIRECT_ADD_AMOUNT_IN_WALLET_METHOD, null));
		serviceMethodMap.put(ServiceType.OTH_PAY_INDI_WALLET_TO_B,  new MethodMappings(SystemConstant.FSP_WALLET_TO_BANK_METHOD, SystemConstant.DIRECT_DEDUCT_AMOUNT_THRU_WALLET_METHOD, SystemConstant.DIRECT_ADD_AMOUNT_IN_BANK_METHOD, null));
		
		
		// BILL PAY
		serviceMethodMap.put(ServiceType.BILL_PAY_BY_B, new MethodMappings(SystemConstant.FSP_BILL_PAYMENT_BY_BANK_METHOD, SystemConstant.DIRECT_DEDUCT_AMOUNT_THRU_BANK_METHOD, SystemConstant.DIRECT_BILL_PAYMENT_TO_BILLER_METHOD, null));
		serviceMethodMap.put(ServiceType.BILL_PAY_BY_CC, new MethodMappings(SystemConstant.FSP_BILL_PAYMENT_BY_CREDITCARD_METHOD, SystemConstant.DIRECT_DEDUCT_AMOUNT_THRU_CREDITCARD_METHOD, SystemConstant.DIRECT_BILL_PAYMENT_TO_BILLER_METHOD, null));
		serviceMethodMap.put(ServiceType.BILL_PAY_BY_IMPS, new MethodMappings(SystemConstant.FSP_BILL_PAYMENT_BY_IMPS_METHOD, SystemConstant.DIRECT_DEDUCT_AMOUNT_THRU_IMPS_METHOD, SystemConstant.DIRECT_BILL_PAYMENT_TO_BILLER_METHOD, null));
		serviceMethodMap.put(ServiceType.BILL_PAY_BY_WALLET, new MethodMappings(SystemConstant.FSP_BILL_PAYMENT_BY_WALLET_METHOD, SystemConstant.DIRECT_DEDUCT_AMOUNT_THRU_WALLET_METHOD, SystemConstant.DIRECT_BILL_PAYMENT_TO_BILLER_METHOD, null));
		
		// TOP UP
		serviceMethodMap.put(ServiceType.TOP_UP_RECH_BY_B, new MethodMappings(SystemConstant.FSP_TOPUP_RECHARGE_BY_BANK_METHOD, SystemConstant.DIRECT_DEDUCT_AMOUNT_THRU_BANK_METHOD, SystemConstant.DIRECT_TOPUP_RECHARGE_TO_BILLER_METHOD, null));
		serviceMethodMap.put(ServiceType.TOP_UP_RECH_BY_CC, new MethodMappings(SystemConstant.FSP_TOPUP_RECHARGE_BY_CREDITCARD_METHOD, SystemConstant.DIRECT_DEDUCT_AMOUNT_THRU_CREDITCARD_METHOD, SystemConstant.DIRECT_TOPUP_RECHARGE_TO_BILLER_METHOD, null));
		serviceMethodMap.put(ServiceType.TOP_UP_RECH_BY_IMPS, new MethodMappings(SystemConstant.FSP_TOPUP_RECHARGE_BY_IMPS_METHOD, SystemConstant.DIRECT_DEDUCT_AMOUNT_THRU_IMPS_METHOD, SystemConstant.DIRECT_TOPUP_RECHARGE_TO_BILLER_METHOD, null));
		serviceMethodMap.put(ServiceType.TOP_UP_RECH_BY_WALLET, new MethodMappings(SystemConstant.FSP_TOPUP_RECHARGE_BY_WALLET_METHOD, SystemConstant.DIRECT_DEDUCT_AMOUNT_THRU_WALLET_METHOD, SystemConstant.DIRECT_TOPUP_RECHARGE_TO_BILLER_METHOD, null));
		
		// SOURCE IS BANK - FUND TRANSFER - TO ALL OTHER INSTRUMENT
		serviceMethodMap.put(ServiceType.BANKING_FT_B_TO_B, new MethodMappings(SystemConstant.FSP_BANK_TO_BANK_METHOD, SystemConstant.DIRECT_DEDUCT_AMOUNT_THRU_BANK_METHOD, SystemConstant.DIRECT_ADD_AMOUNT_IN_BANK_METHOD, null));
		serviceMethodMap.put(ServiceType.BANKING_FT_B_TO_CC, new MethodMappings(SystemConstant.FSP_BANK_TO_CREDITCARD_METHOD, SystemConstant.DIRECT_DEDUCT_AMOUNT_THRU_BANK_METHOD, SystemConstant.DIRECT_ADD_AMOUNT_IN_CREDITCARD_METHOD, null));
		serviceMethodMap.put(ServiceType.BANKING_FT_B_TO_IMPS, new MethodMappings(SystemConstant.FSP_BANK_TO_IMPS_METHOD, SystemConstant.DIRECT_DEDUCT_AMOUNT_THRU_BANK_METHOD, SystemConstant.DIRECT_ADD_AMOUNT_IN_IMPS_METHOD, null));
		serviceMethodMap.put(ServiceType.BANKING_FT_B_TO_WALLET, new MethodMappings(SystemConstant.FSP_BANK_TO_WALLET_METHOD, SystemConstant.DIRECT_DEDUCT_AMOUNT_THRU_BANK_METHOD, SystemConstant.DIRECT_ADD_AMOUNT_IN_WALLET_METHOD, null));
		
		// SOURCE IS IMPS - FUND TRANSFER - TO ALL OTHER INSTRUMENT
		serviceMethodMap.put(ServiceType.BANKING_IMPS_IMPS_TO_B, new MethodMappings(SystemConstant.FSP_IMPS_TO_BANK_METHOD, SystemConstant.DIRECT_DEDUCT_AMOUNT_THRU_IMPS_METHOD, SystemConstant.DIRECT_ADD_AMOUNT_IN_BANK_METHOD, null));
		serviceMethodMap.put(ServiceType.BANKING_IMPS_IMPS_TO_CC, new MethodMappings(SystemConstant.FSP_IMPS_TO_CREDITCARD_METHOD, SystemConstant.DIRECT_DEDUCT_AMOUNT_THRU_IMPS_METHOD, SystemConstant.DIRECT_ADD_AMOUNT_IN_CREDITCARD_METHOD, null));
		serviceMethodMap.put(ServiceType.BANKING_IMPS_IMPS_TO_IMPS, new MethodMappings(SystemConstant.FSP_IMPS_TO_IMPS_METHOD, SystemConstant.DIRECT_DEDUCT_AMOUNT_THRU_IMPS_METHOD, SystemConstant.DIRECT_ADD_AMOUNT_IN_IMPS_METHOD, null));
		serviceMethodMap.put(ServiceType.BANKING_IMPS_IMPS_TO_WALLET, new MethodMappings(SystemConstant.FSP_IMPS_TO_WALLET_METHOD, SystemConstant.DIRECT_DEDUCT_AMOUNT_THRU_IMPS_METHOD, SystemConstant.DIRECT_ADD_AMOUNT_IN_WALLET_METHOD, null));
		
		// MONEY TRANSFER - SOURCE IS WALLET AND DESTINATION IS BANK - PART OF FUND TRANSFER FSP SERVICE
		serviceMethodMap.put(ServiceType.MONEY_TRANSFER, new MethodMappings(SystemConstant.FSP_MONEY_TRANSFER_METHOD, null, null, null));
		
		// FSP OTHER SERVICES
		
		
		serviceMethodMap.put(ServiceType.SETTINGS_CHANGE_PIN_WALLET, new MethodMappings(SystemConstant.FSP_CHANGE_WALLET_PIN_METHOD, null, null, null));
		serviceMethodMap.put(ServiceType.SETTINGS_CREATE_PIN_WALLET, new MethodMappings(SystemConstant.FSP_CREATE_WALLET_PIN_METHOD, null, null, null));
		serviceMethodMap.put(ServiceType.SETTINGS_CREATE_PIN_TRANSACTION, new MethodMappings(SystemConstant.FSP_CREATE_PIN_METHOD, null, null, null));
		serviceMethodMap.put(ServiceType.SETTINGS_CHANGE_PIN_TRANSACTION, new MethodMappings(SystemConstant.FSP_CHANGE_PIN_METHOD, null, null, null));
		
		serviceMethodMap.put(ServiceType.SETTINGS_BANK_ACC_ADD, new MethodMappings(SystemConstant.FSP_ADD_BANK_ACCOUNT_METHOD, null, null, null));
		serviceMethodMap.put(ServiceType.SETTINGS_MY_PAYEE_ADD, new MethodMappings(SystemConstant.FSP_ADD_MY_PAYEES_METHOD, null, null, null));
		serviceMethodMap.put(ServiceType.SETTINGS_MY_MERCHANT_ADD, new MethodMappings(SystemConstant.FSP_ADD_MY_MERCHANT_METHOD, null, null, null));
		serviceMethodMap.put(ServiceType.SETTINGS_MY_BILLER_ADD, new MethodMappings(SystemConstant.FSP_ADD_MY_BILLER_METHOD, null, null, null));
		
		serviceMethodMap.put(ServiceType.SETTINGS_MY_PAYEE_EDIT, new MethodMappings(SystemConstant.FSP_ADD_MY_PAYEES_METHOD, null, null, null));
		serviceMethodMap.put(ServiceType.SETTINGS_MY_MERCHANT_EDIT, new MethodMappings(SystemConstant.FSP_ADD_MY_MERCHANT_METHOD, null, null, null));
		serviceMethodMap.put(ServiceType.SETTINGS_MY_BILLER_EDIT, new MethodMappings(SystemConstant.FSP_ADD_MY_BILLER_METHOD, null, null, null));
		
		serviceMethodMap.put(ServiceType.SETTINGS_MY_PAYEE_DELETE, new MethodMappings(SystemConstant.FSP_ADD_MY_PAYEES_METHOD, null, null, null));
		serviceMethodMap.put(ServiceType.SETTINGS_MY_MERCHANT_DELETE, new MethodMappings(SystemConstant.FSP_ADD_MY_MERCHANT_METHOD, null, null, null));
		serviceMethodMap.put(ServiceType.SETTINGS_MY_BILLER_DELETE, new MethodMappings(SystemConstant.FSP_ADD_MY_BILLER_METHOD, null, null, null));
		
		serviceMethodMap.put(ServiceType.BANKING_CHECK_BAL, new MethodMappings(SystemConstant.FSP_BAL_ENQUIRY_METHOD, null, null, null));
		serviceMethodMap.put(ServiceType.BANKING_STOP_CHEQUE, new MethodMappings(SystemConstant.FSP_CANCEL_CHEQUE_METHOD, null, null, null));
		serviceMethodMap.put(ServiceType.BANKING_CHQ_STATUS, new MethodMappings(SystemConstant.FSP_CHEQUE_STATUS_METHOD, null, null, null));
		serviceMethodMap.put(ServiceType.BANKING_LAST_5_TRANS, new MethodMappings(SystemConstant.FSP_LAST_5_TXN_METHOD, null, null, null));
		serviceMethodMap.put(ServiceType.BANKING_CHQ_BOOK_REQUEST, new MethodMappings(SystemConstant.FSP_CHEQUE_BOOK_REQ_METHOD, null, null, null));
		serviceMethodMap.put(ServiceType.BANKING_FT_UPI_TO_UPI, new MethodMappings(SystemConstant.FSP_BAL_ENQUIRY_METHOD, null, null, null));
	}



	private void addMethods(Map<String, String> serviceMap,Map<String, ReflectionData> callableServiceMethodsMap) {
		for (Iterator<String> itr = serviceMap.keySet().iterator(); itr.hasNext();) {
				String partnerServiceName = itr.next();
				String strClassIdentifier = serviceMap.get(partnerServiceName);
				if (callableServiceMethodsMap.containsKey(partnerServiceName.toLowerCase()) == false) {
					Object classIdentifier = new SpringContextUtil().getBean(strClassIdentifier);
					callableServiceMethodsMap.put(partnerServiceName.toLowerCase(),new ReflectionData(strClassIdentifier, classIdentifier,getMethods(classIdentifier)));
				}
		}
	}

	private Map<String, Method> getMethods(Object classIdentifier) {
		if (classIdentifier != null) {
			Method[] methods = classIdentifier.getClass().getDeclaredMethods();
			Map<String, Method> methodMap = new HashMap<>();
			for (Method method : methods) {
				if (method != null) {
					methodMap.put(method.getName().toLowerCase(), method);
				}
			}
			return methodMap;
		}
		return null;
	}


	public ReflectionData getMethodToInvoke(BridgeDataObject bridgeDataObject,String partnerServiceName,ServiceType serviceType,String methodCallType) {
		boolean condition1=false;
		if(partnerServiceName != null && !partnerServiceName.isEmpty() &&  serviceType != null){
			condition1=true;
		}
		
		if (condition1 && methodCallType!=null && !methodCallType.isEmpty()) {
			ReflectionData rd = callableServiceMethodsMap.get(partnerServiceName.toLowerCase());
			if(rd!=null){
				if(serviceMethodMap.get(serviceType)!=null && serviceMethodMap.get(serviceType).getMethodMap()!=null 
						&& serviceMethodMap.get(serviceType).getMethodMap().get(methodCallType)!=null && !serviceMethodMap.get(serviceType).getMethodMap().get(methodCallType).isEmpty()){
					String methodToCall = serviceMethodMap.get(serviceType).getMethodMap().get(methodCallType);
					LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " ServiceClass ## " + serviceMap.get(partnerServiceName) + " Method ## " + methodToCall + " is going to call.",NewConstants.TRANSACTIONID);
					return new ReflectionData(rd.getClassIdentifier(), rd.getMethodMap().get(methodToCall.toLowerCase()));
				}
				else{
					LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " No Class/Method combination found for Class ##  " 
							+ rd.getClassName() + "  and Service ## " + serviceType.name(),NewConstants.TRANSACTIONID);
				}
			}
		}
		return null;
	}

}
