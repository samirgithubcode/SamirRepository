/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "HostSVProviderPartnerMapping")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "HostSVProviderPartnerMapping.findAll", query = "SELECT h FROM HostSVProviderPartnerMapping h"),
    @NamedQuery(name = "HostSVProviderPartnerMapping.findByHostIdAndHsvId", query = "SELECT h FROM HostSVProviderPartnerMapping h WHERE h.hostId=:hostId AND h.hsvId=:hsvId"),
    @NamedQuery(name = "HostSVProviderPartnerMapping.findById", query = "SELECT h FROM HostSVProviderPartnerMapping h WHERE h.id = :id"),
    @NamedQuery(name = "HostSVProviderPartnerMapping.findByMappingType", query = "SELECT h FROM HostSVProviderPartnerMapping h WHERE h.mappingType = :mappingType"),
    @NamedQuery(name = "HostSVProviderPartnerMapping.findAllPartnersForSubVersion", query = "SELECT h FROM HostSVProviderPartnerMapping h WHERE h.hsvId = :hsvId")})

public class HostSVProviderPartnerMapping implements Serializable {
	private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Column(name = "MappingType")
    private String mappingType;
    @Column(name = "sequence")
    private Integer sequence;
    @JoinColumn(name = "partnerId", referencedColumnName = "id")
    @ManyToOne
    private Partner partnerId;
    @JoinColumn(name = "instrumentId", referencedColumnName = "id")
    @ManyToOne
    private FinancialInstrument instrumentId;
    @JoinColumn(name = "hostId", referencedColumnName = "id")
    @ManyToOne
    private AccountInfo hostId;
    @JoinColumn(name = "hsvId", referencedColumnName = "id")
    @ManyToOne
    private HostSubVersion hsvId;
    @JoinColumn(name = "catId", referencedColumnName = "id")
    @ManyToOne
    private Categories catId;
    @JoinColumn(name = "providerId", referencedColumnName = "id")
    @ManyToOne
    private Provider providerId;
    
    @JoinColumn(name = "commissionId", referencedColumnName = "id")
    @ManyToOne
    private CommissionTemplate commissionId;

    public CommissionTemplate getCommissionId() {
		return commissionId;
	}

	public void setCommissionId(CommissionTemplate commissionId) {
		this.commissionId = commissionId;
	}

    public HostSVProviderPartnerMapping() {
    	//default constructor
    }

    public HostSVProviderPartnerMapping(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMappingType() {
        return mappingType;
    }

    public void setMappingType(String mappingType) {
        this.mappingType = mappingType;
    }

    public Integer getSequence() {
        return sequence;
    }

    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }

    public Partner getPartnerId() {
        return partnerId;
    }

    public void setPartnerId(Partner partnerId) {
        this.partnerId = partnerId;
    }

    public FinancialInstrument getInstrumentId() {
        return instrumentId;
    }

    public void setInstrumentId(FinancialInstrument instrumentId) {
        this.instrumentId = instrumentId;
    }

    public AccountInfo getHostId() {
        return hostId;
    }

    public void setHostId(AccountInfo hostId) {
        this.hostId = hostId;
    }

    public HostSubVersion getHsvId() {
        return hsvId;
    }

    public void setHsvId(HostSubVersion hsvId) {
        this.hsvId = hsvId;
    }

    public Categories getCatId() {
        return catId;
    }

    public void setCatId(Categories catId) {
        this.catId = catId;
    }

    public Provider getProviderId() {
        return providerId;
    }

    public void setProviderId(Provider providerId) {
        this.providerId = providerId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof HostSVProviderPartnerMapping)) {
            return false;
        }
        boolean check=true;
        HostSVProviderPartnerMapping other = (HostSVProviderPartnerMapping) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.HostSVProviderPartnerMapping[ id=" + id + " ]";
    }
    
}
