package com.ng.sb.common.dataobject;

import java.sql.Date;
import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.ng.sb.common.model.PayCardApps;

public class CardData extends BaseObjectData{
	private static final long serialVersionUID=1L;
	
	private String bankName;
	private Integer cardId;
	private Integer deactivateid;
	private String fileName;
	private String cardType;
	private String apName;
	private String product;
	private Integer amount;
	private String empty;
	private  String appDesc;

	private Integer bankId;
	private Integer payCardApp;
	private List<CardData> cardListDetails;
	private List<String> walletName;
	private List<String> appName;
	private String statusValue;
	private String payCardPartner1;
	private String payCardPartner2;
	private String payCardPartner3;
	private String payCardPartner4;
	private List<List<String>> partnerList;
	private String walletType;
	private Integer check;
	private Integer radio;
	private Date startDate;
	private Integer status;
	private Date endDate;
	private Map<Integer,String> payCardPartnerNameMap;
	private transient List<PayCardApps> paycardDetails;
	private transient MultipartFile uploadFilePath;
	public Integer getAmount() {
		return amount;
	}
	public void setAmount(Integer amount) {
		this.amount = amount;
	}
	
	public String getEmpty() {
		return empty;
	}
	public void setEmpty(String empty) {
		this.empty = empty;
	}
	
	
	public List<PayCardApps> getPaycardDetails() {
		return paycardDetails;
	}
	public void setPaycardDetails(List<PayCardApps> paycardDetails) {
		this.paycardDetails = paycardDetails;
	}
	

	public String getAppDesc() {
		return appDesc;
	}
	public void setAppDesc(String appDesc) {
		this.appDesc = appDesc;
	}
	public String getApName() {
		return apName;
	}
	public void setApName(String apName) {
		this.apName = apName;
	}
	public String getCardType() {
		return cardType;
	}
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}
	
	public List<List<String>> getPartnerList() {
		return partnerList;
	}
	public void setPartnerList(List<List<String>> partnerList) {
		this.partnerList = partnerList;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public Integer getDeactivateid() {
		return deactivateid;
	}
	public void setDeactivateid(Integer deactivateid) {
		this.deactivateid = deactivateid;
	}
	public Integer getCardId() {
		return cardId;
	}
	public void setCardId(Integer cardId) {
		this.cardId = cardId;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	
	public String getStatusValue() {
		return statusValue;
	}
	public void setStatusValue(String statusValue) {
		this.statusValue = statusValue;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public void setCheck(Integer check) {
		this.check = check;
	}
	public List<String> getAppName() {
		return appName;
	}
	public void setAppName(List<String> appName) {
		this.appName = appName;
	}
	public List<String> getWalletName() {
		return walletName;
	}
	public void setWalletName(List<String> walletName) {
		this.walletName = walletName;
	}
	public List<CardData> getCardListDetails() {
		return cardListDetails;
	}
	public void setCardListDetails(List<CardData> cardListDetails) {
		this.cardListDetails = cardListDetails;
	}
	public Integer getPayCardApp() {
		return payCardApp;
	}
	
	public void setPayCardApp(Integer payCardApp) {
		this.payCardApp = payCardApp;
	}
	public MultipartFile getUploadFilePath() {
		return uploadFilePath;
	}
	public void setUploadFilePath(MultipartFile uploadFilePath) {
		this.uploadFilePath = uploadFilePath;
	}
	public Integer getBankId() {
		return bankId;
	}
	public void setBankId(Integer bankId) {
		this.bankId = bankId;
	}
	
	public String getPayCardPartner1() {
		return payCardPartner1;
	}
	public void setPayCardPartner1(String payCardPartner1) {
		this.payCardPartner1 = payCardPartner1;
	}
	public String getPayCardPartner2() {
		return payCardPartner2;
	}
	public void setPayCardPartner2(String payCardPartner2) {
		this.payCardPartner2 = payCardPartner2;
	}
	public String getPayCardPartner3() {
		return payCardPartner3;
	}
	public void setPayCardPartner3(String payCardPartner3) {
		this.payCardPartner3 = payCardPartner3;
	}
	
	
	public String getPayCardPartner4() {
		return payCardPartner4;
	}
	public void setPayCardPartner4(String payCardPartner4) {
		this.payCardPartner4 = payCardPartner4;
	}
	
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	
	public Map<Integer, String> getPayCardPartnerNameMap() {
		return payCardPartnerNameMap;
	}
	public void setPayCardPartnerNameMap(Map<Integer, String> payCardPartnerNameMap) {
		this.payCardPartnerNameMap = payCardPartnerNameMap;
	}
	public Integer getRadio() {
		return radio;
	}
	public void setRadio(Integer radio) {
		this.radio = radio;
	}
	public Integer getCheck() {
		return check;
	}
	public void setCheck1(Integer check) {
		this.check = check;
	}
	public String getWalletType() {
		return walletType;
	}
	public void setWalletType(String walletType) {
		this.walletType = walletType;
	}

	

}
