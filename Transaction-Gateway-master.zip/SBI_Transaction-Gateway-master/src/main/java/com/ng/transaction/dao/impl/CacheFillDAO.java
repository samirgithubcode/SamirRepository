package com.ng.transaction.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.ng.sb.common.dao.impl.SuperParentDAO;
import com.ng.sb.common.model.Categories;
import com.ng.sb.common.model.FSPServices;
import com.ng.sb.common.model.FinancialInstrument;
import com.ng.sb.common.model.HostSubVersion;
import com.ng.sb.common.model.MasterVersion;
import com.ng.sb.common.model.Partner;
import com.ng.sb.common.model.PartnerPreference;
import com.ng.sb.common.model.ServiceConfig;
import com.ng.transaction.dao.ICacheFillDAO;

@Transactional
@Repository(value="cacheFillDAO")
public class CacheFillDAO extends SuperParentDAO implements ICacheFillDAO {
	private static final long serialVersionUID = 1L;
	public List<HostSubVersion> getHostSubVersionList() throws Exception{
		List<HostSubVersion> list=new ArrayList<>();
		try {
			TypedQuery<HostSubVersion> query=entityManager.createNamedQuery("HostSubVersion.findAll", HostSubVersion.class);
			list=query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return list;
	}
	
	@Override
	public List<Categories> getCategoriesList() throws Exception{
		List<Categories> list=new ArrayList<>();
		try {
			TypedQuery<Categories> query=entityManager.createNamedQuery("Categories.findAll", Categories.class);
			list=query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return list;
	}
	
	@Override
	public List<FSPServices> getFSPServicesList() throws Exception{
		List<FSPServices> list=new ArrayList<>();
		try {
			TypedQuery<FSPServices> query=entityManager.createNamedQuery("FSPServices.findAll", FSPServices.class);
			list=query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return list;
	}
	@Override
	public List<Partner> getPartnerList() throws Exception{
		List<Partner> list=new ArrayList<>();
	try {
		TypedQuery<Partner> query=entityManager.createNamedQuery("Partner.findAll", Partner.class);
		list=query.getResultList();
	} catch (Exception e) {
		e.printStackTrace();
		throw e;
	}
	return list;
	}
	
	@Override
	public List<FinancialInstrument> getFinancialInstrument() throws Exception{
		List<FinancialInstrument> list=new ArrayList<>();
		try {
			TypedQuery<FinancialInstrument> query=entityManager.createNamedQuery("FinancialInstrument.findAll", FinancialInstrument.class);
			list=query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return list;
	}
	
	@Override
	public List<MasterVersion> getMasterVersion() throws Exception{
		List<MasterVersion> list=new ArrayList<>();
		try {
			TypedQuery<MasterVersion> query=entityManager.createNamedQuery("MasterVersion.findAll", MasterVersion.class);
			list=query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return list;
	}
	@Override
	public PartnerPreference getPartnerPreferenceByHostVersion(Integer hostSubVersion) throws Exception{
		PartnerPreference partnerPreference=new PartnerPreference();
		try {
			TypedQuery<PartnerPreference> query=entityManager.createNamedQuery("PartnerPreference.findByHostVersion", PartnerPreference.class);
			query.setParameter("hsvId",new HostSubVersion(hostSubVersion));
			List<PartnerPreference> list=query.getResultList();
			if(list.size()>0){
				partnerPreference=list.get(0);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return partnerPreference;
	}
	
	@Override
	public List<ServiceConfig> getServiceConfigList() throws Exception{
		List<ServiceConfig> list=new ArrayList<>();
		try {
			TypedQuery<ServiceConfig> query=entityManager.createNamedQuery("ServiceConfig.findAllNotNullMVid", ServiceConfig.class);
			list=query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return list;
	}
}
