package com.ng.sb.common.dataobject;

import java.util.List;


/**
 * @author amardeep
 *
 */
public class HostPartnerPreferenceDatas  extends BaseObjectData{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String hsvName;
	private Integer hsvId;
	List<HostPartnerPreferenceData> partnerPreferenceDatas;
	
	public Integer getHsvId() {
		return hsvId;
	}
	public void setHsvId(Integer hsvId) {
		this.hsvId = hsvId;
	}
	public String getHsvName() {
		return hsvName;
	}
	public void setHsvName(String hsvName) {
		this.hsvName = hsvName;
	}
	public List<HostPartnerPreferenceData> getPartnerPreferenceDatas() {
		return partnerPreferenceDatas;
	}
	public void setPartnerPreferenceDatas(List<HostPartnerPreferenceData> partnerPreferenceDatas) {
		this.partnerPreferenceDatas = partnerPreferenceDatas;
	}
}
