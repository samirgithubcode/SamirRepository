/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Collection;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "FSPServices")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "FSPServices.findAll", query = "SELECT f FROM FSPServices f"),
    @NamedQuery(name = "FSPServices.findById", query = "SELECT f FROM FSPServices f WHERE f.id = :id"),
    @NamedQuery(name = "FSPServices.findByName", query = "SELECT f FROM FSPServices f WHERE f.name = :name"),
    @NamedQuery(name = "FSPServices.findByDesc", query = "SELECT f FROM FSPServices f WHERE f.desc = :desc"),
    @NamedQuery(name = "FSPServices.findByType", query = "SELECT f FROM FSPServices f WHERE f.type = :type"),
    @NamedQuery(name = "FSPServices.findByInstId", query = "SELECT f FROM FSPServices f WHERE f.instrumentId = :instrumentId"),
    @NamedQuery(name = "FSPServices.findByInstIdList", query = "SELECT f FROM FSPServices f WHERE f.instrumentId IN :instrumentId"),
    @NamedQuery(name = "FSPServices.findByServiceId", query = "SELECT f FROM FSPServices f WHERE f.serviceId IS NOT NULL"),
    @NamedQuery(name = "FSPServices.findByIsBankIncluded", query = "SELECT f FROM FSPServices f WHERE f.isBankIncluded = :isBankIncluded")})
public class FSPServices implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
    @Basic(optional = false)
    @Column(name = "name", nullable = false, length = 50)
    private String name;
    @Column(name = "desc", length = 50)
    private String desc;
    @Basic(optional = false)
    @Column(name = "type", nullable = false, length = 8)
    private String type;
    @Basic(optional = false)
    @Column(name = "isBankIncluded", nullable = false)
    private Integer isBankIncluded;
    @Basic(optional = false)
    @Column(name = "instrument")
    private String instrument;
    @ManyToOne
   	@JoinColumn(name="instrumentId", referencedColumnName="id")
    private FinancialInstrument instrumentId;
    @ManyToOne
   	@JoinColumn(name="serviceId", referencedColumnName="id")
    private ServiceConfig serviceId;
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "fspServiceId")
    private Collection<PartnerFspServiceMapping> partnerFspServiceMappingCollection;
    @OneToMany(mappedBy = "fspServicesId")
    private Collection<HostSVFspServicesPartnerMapping> hostSVFspServicesPartnerMappingCollection;
    @OneToMany(mappedBy = "fspServicesId")
    private Collection<CommFspServiceMapping> commConfFspServiceMappingCollection;

    public FSPServices() {
    	//default constructor
    }

    public FSPServices(Integer id) {
        this.id = id;
    }

    public FSPServices(Integer id, String name, String type, Integer isBankIncluded) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.isBankIncluded = isBankIncluded;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public FinancialInstrument getInstrumentId() {
		return instrumentId;
	}

	public ServiceConfig getServiceId() {
		return serviceId;
	}

	public void setServiceId(ServiceConfig serviceId) {
		this.serviceId = serviceId;
	}

	public void setInstrumentId(FinancialInstrument instrumentId) {
		this.instrumentId = instrumentId;
	}

	public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Integer getIsBankIncluded() {
        return isBankIncluded;
    }

    public void setIsBankIncluded(Integer isBankIncluded) {
        this.isBankIncluded = isBankIncluded;
    }

    public String getInstrument() {
		return instrument;
	}

	public void setInstrument(String instrument) {
		this.instrument = instrument;
	}
	
    @XmlTransient
    public Collection<PartnerFspServiceMapping> getPartnerFspServiceMappingCollection() {
        return partnerFspServiceMappingCollection;
    }

    public void setPartnerFspServiceMappingCollection(Collection<PartnerFspServiceMapping> partnerFspServiceMappingCollection) {
        this.partnerFspServiceMappingCollection = partnerFspServiceMappingCollection;
    }

    @XmlTransient
    public Collection<HostSVFspServicesPartnerMapping> getHostSVFspServicesPartnerMappingCollection() {
        return hostSVFspServicesPartnerMappingCollection;
    }

    public void setHostSVFspServicesPartnerMappingCollection(Collection<HostSVFspServicesPartnerMapping> hostSVFspServicesPartnerMappingCollection) {
        this.hostSVFspServicesPartnerMappingCollection = hostSVFspServicesPartnerMappingCollection;
    }

    @XmlTransient
    public Collection<CommFspServiceMapping> getCommConfFspServiceMappingCollection() {
        return commConfFspServiceMappingCollection;
    }

    public void setCommConfFspServiceMappingCollection(Collection<CommFspServiceMapping> commConfFspServiceMappingCollection) {
        this.commConfFspServiceMappingCollection = commConfFspServiceMappingCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof FSPServices)) {
            return false;
        }
        FSPServices other = (FSPServices) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.FSPServices[ id=" + id + " ]";
    }
    
}
