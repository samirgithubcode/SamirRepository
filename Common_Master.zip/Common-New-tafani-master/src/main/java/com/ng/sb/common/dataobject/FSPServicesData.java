/**
 * 
 */
package com.ng.sb.common.dataobject;

import java.util.Set;

import com.ng.sb.common.dataobject.AccountInfoData;

/**
 * @author gaurav
 *
 */
public class FSPServicesData extends BaseObjectData {
	private static final long serialVersionUID = 1L;

	private Integer isBankIncluded;
	private String desc;
	private String descType;
	private String type;
	private String instrument;
	private AccountInfoData host;
	private Integer showPartnerData;
	private Integer showPartner;
	private Set<PartnerData> partners;
	private Integer instrumentId;
	private String instrumentName;
	private Integer serviceId;
	public FSPServicesData() {
		//default constructor
	}

	public FSPServicesData(String name) {
		super.setName(name);
	}
	public Integer getShowPartner() {
		return showPartner;
	}

	public void setShowPartner(Integer showPartner) {
		this.showPartner = showPartner;
	}

	public Integer getShowPartnerData() {
		return showPartnerData;
	}

	public void setShowPartnerData(Integer showPartnerData) {
		this.showPartnerData = showPartnerData;
	}

	public Integer getInstrumentId() {
		return instrumentId;
	}

	public Integer getServiceId() {
		return serviceId;
	}

	public void setServiceId(Integer serviceId) {
		this.serviceId = serviceId;
	}

	public String getInstrumentName() {
		return instrumentName;
	}

	public void setInstrumentName(String instrumentName) {
		this.instrumentName = instrumentName;
	}

	public void setInstrumentId(Integer instrumentId) {
		this.instrumentId = instrumentId;
	}

	public String getDescType() {
		return descType;
	}

	public void setDescType(String descType) {
		this.descType = descType;
	}
	
	public AccountInfoData getHost() {
		return host;
	}

	public void setHost(AccountInfoData host) {
		this.host = host;
	}

	public Set<PartnerData> getPartners() {
		return partners;
	}

	public void setPartners(Set<PartnerData> partners) {
		this.partners = partners;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getInstrument() {
		return instrument;
	}

	public void setInstrument(String instrument) {
		this.instrument = instrument;
	}

	public Integer getIsBankIncluded() {
		return isBankIncluded;
	}

	public void setIsBankIncluded(Integer isBankIncluded) {
		this.isBankIncluded = isBankIncluded;
	}
	
	@Override
	public int hashCode() {
		if (super.getName()!=null && !super.getName().isEmpty()) {
			return super.getName().hashCode()*7;
		} else {
			return 0;
		}

	}
	
	@Override
	public boolean equals(Object obj) {
		boolean condition1=false;
		boolean condition3=false;
		
		if (obj == null) {
			return false;
		}
		boolean check=false;
		if ( obj instanceof FSPServicesData) {
			FSPServicesData other = (FSPServicesData) obj;
			if(super.getName()!=null && !super.getName().isEmpty()){
				condition1=true;
			}
			if(other.getName()!=null && !other.getName().isEmpty()){
				condition3=true;
			}
			if(condition1 && condition3 && super.getName().equalsIgnoreCase(other.getName())) {
				check= true;
			}
			return check;
		}
		return super.equals(obj);
	}

	
}
