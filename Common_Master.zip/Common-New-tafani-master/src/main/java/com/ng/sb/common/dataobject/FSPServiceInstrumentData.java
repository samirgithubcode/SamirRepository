package com.ng.sb.common.dataobject;

import java.util.HashMap;
import java.util.Map;

import  com.ng.sb.common.dataobject.HostSubVersionData.ProviderRelation;
import  com.ng.sb.common.dataobject.InstrumentData.Sequence;
import com.ng.sb.common.dataobject.PartnerData.BankRelation;
import  com.ng.sb.common.dataobject.ServiceMappingDef.BankSide;
import  com.ng.sb.common.dataobject.ServiceMappingDef.Type;

public class FSPServiceInstrumentData extends BaseObjectData {

	private static final long serialVersionUID = 1L;
	private ProviderRelation fspProvider;
	private ProviderRelation regInstrFspProvider;
	private BankSide bankIncluded;
	private Map<Sequence,InstrumentProviderData> instrumentProviderMap=  new HashMap<>();
	private Map<Sequence,InstrumentData> instrumentMap=  new HashMap<>();
	private FSPServicesData fspServicesData;
	private FSPServicesData regInstrFspServicesData;
	private Type type;
	private BankRelation bankRelation;
	public Map<Sequence, InstrumentData> getInstrumentMap() {
		return instrumentMap;
	}

	public void setInstrumentMap(Map<Sequence, InstrumentData> instrumentMap) {
		this.instrumentMap = instrumentMap;
	}

	public ProviderRelation getFspProvider() {
		return fspProvider;
	}

	public void setFspProvider(ProviderRelation fspProvider) {
		this.fspProvider = fspProvider;
	}

	public FSPServicesData getFspServicesData() {
		return fspServicesData;
	}

	public void setFspServicesData(FSPServicesData fspServicesData) {
		this.fspServicesData = fspServicesData;
	}

	public Map<Sequence, InstrumentProviderData> getInstrumentProviderMap() {
		return instrumentProviderMap;
	}

	public void setInstrumentProviderMap(
			Map<Sequence, InstrumentProviderData> instrumentProviderMap) {
		this.instrumentProviderMap = instrumentProviderMap;
	}

	public Type getType() {
		return type;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public BankSide getBankIncluded() {
		return bankIncluded;
	}

	public void setBankIncluded(BankSide bankIncluded) {
		this.bankIncluded = bankIncluded;
	}

	public FSPServicesData getRegInstrFspServicesData() {
		return regInstrFspServicesData;
	}

	public void setRegInstrFspServicesData(FSPServicesData regInstrFspServicesData) {
		this.regInstrFspServicesData = regInstrFspServicesData;
	}

	public ProviderRelation getRegInstrFspProvider() {
		return regInstrFspProvider;
	}

	public void setRegInstrFspProvider(ProviderRelation regInstrFspProvider) {
		this.regInstrFspProvider = regInstrFspProvider;
	}

	public BankRelation getBankRelation() {
		return bankRelation;
	}

	public void setBankRelation(BankRelation bankRelation) {
		this.bankRelation = bankRelation;
	}

}
