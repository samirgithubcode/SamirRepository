package com.ng.transaction.data;

import com.ng.sb.common.dataobject.TransactionProviderData;
import com.ng.sb.common.dataobject.Wallet;

public class SecureTransactionResponse extends BaseObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer responseCode;
	private String responseMessage;
	private String transactionType;
	private String hostTransactionType;
	private Integer amount;
	private TransactionProviderData providerData;
	private Wallet payerWallet;
	private Wallet payeeWallet;
	private String transactionId;
	
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public Wallet getPayerWallet() {
		return payerWallet;
	}
	public void setPayerWallet(Wallet payerWallet) {
		this.payerWallet = payerWallet;
	}
	public Wallet getPayeeWallet() {
		return payeeWallet;
	}
	public void setPayeeWallet(Wallet payeeWallet) {
		this.payeeWallet = payeeWallet;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getHostTransactionType() {
		return hostTransactionType;
	}
	public void setHostTransactionType(String hostTransactionType) {
		this.hostTransactionType = hostTransactionType;
	}
	public Integer getAmount() {
		return amount;
	}
	public void setAmount(Integer amount) {
		this.amount = amount;
	}
	public TransactionProviderData getProviderData() {
		return providerData;
	}
	public void setProviderData(TransactionProviderData providerData) {
		this.providerData = providerData;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public Integer getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(Integer responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseString(String responseMessage) {
		this.responseMessage = responseMessage;
	}

}
