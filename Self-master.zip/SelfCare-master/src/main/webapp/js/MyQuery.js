function showsubquery(event)
{
	
	$("#subquerydivid").show();
	
	var products=$("#querytypeId").val();
	var productdetail=products.split("#");
	var productType=productdetail[1];
	if(products!='0')
		{
	$.ajax({
		type: "post",
		url: "findsubquery",
		dataType: 'json',
		data: 'products='+productType,
		success: function(response){
			var obj=response;
		/*	var obj=JSON.parse(response);*/
			var select = $('#subqueryid');
			select.find('option').remove();
			$('<option>').val('').text('').appendTo(select);
			$.each(obj, function( index, value ) {
				$('<option>').val(index).text(value).appendTo(select);
			});
		
			
		}
	});
		}
	$('#smsDiv').hide();
	$('#linkstableId').hide();
	
}




function getCheck()
{
	$('#hideElemnt').show();
	$('#subb').show();
	/*  $("#productId0").val($("#productId0 option:eq(1)").val());*/
}

function validateform(event){
	

	var completeCheck=true;
	var querytypeId=$('#querytypeId').val();
	var subqueryid=$('#subqueryid').val();
	var descriptiondivid=$('#subquerydescription').val();
	var subquerydescription= $('#subquerydescription').val().trim();
	if((querytypeId.length==0)||(subquerydescription.length==0)){
		$('#statusMessage1').show();
	$('#statusMessage1').html("<font color='red'>Select details before submit.</font>");
	 event.preventDefault();
	 return false;
	 }
	
	
if(querytypeId.length==0)
    {
	$('#label_querytype').removeClass('valid');
	 $('#querytypeIdDiv').addClass('has-error');
      completeCheck = false;
    }
if(querytypeId.length!=0){
	
if(subqueryid==null)
{
  $('#subQueryIdDiv').addClass('has-error');
  completeCheck = false;
}
}
if(descriptiondivid.length==0)
{
  $('#descriptiondivid').addClass('has-error');
  completeCheck = false;
}
if(subquerydescription.length==0)
{
  $('#descriptiondivid').addClass('has-error');
  completeCheck = false;
}

	
	if(completeCheck==false){
		event.preventDefault();
	}
	return completeCheck;
	
}
function getDocumentList(){
	var subqueryid=$("#subqueryid").val();

	if(subqueryid!="")
	{
$.ajax({
	type: "post",
	url: "findUrlList",
	data: 'subqueryid='+subqueryid,
	
	async:false,
	success: function(response){
		if (response.length > 1) {
			   var data=response.split("#");
			   
			   var array=data[0].split(",");
			   var names=data[1].split(",");
			   var len=array.length;

			   $('#linkstableId')
				.html(
						'<thead><tr><th colspan=2><b>Attached Documents</b></th></tr></thead><tbody>');
			   for (var i = 0; i < len; i++) {
			    if(names[i]=="")
			     names[i]=array[i];
			    $('#linkstableId').append(
			      '<tr><td align="center"><input type=checkbox class=cbx id=checkedLinks onclick=checkboxes(event) name=checkedLinks value='+array[i]+'>&nbsp;&nbsp</td><td align="left"><a  href="downloadDoc?docName='
			      +array[i]+'" target="_blank" >'+names[i] +'</a></td></tr>');

			      /*      '<tr><td align="center"><input type=checkbox class=cbx id=checkedLinks onclick=checkboxes(event) name=checkedLinks value='+array[i]+'>&nbsp;&nbsp</td><td align="left">'
			        + array[i]
			        +'</td></tr>');
			*/   
			   }
			   $('#linkstableId').show();
			     $('#smsDiv').show();
		/*var obj=response;
		var valuess = obj;
		length=valuess.length;*/
		
		/*if (length > 0) {
			
			$('#linkstableId')
					.html(
							'<thead><tr><th colspan=2><b>Attached Documents</b></th></tr></thead><tbody>');
			for (var i = 0; i < valuess.length; i++) {
				var array=	valuess[i].split("#");
				
				$('#linkstableId').append(
						'<tr><td ><input type=checkbox class=cbx onclick=checkboxes() id='+array[0]+' name=checkedLinks value='+array[1]+'></td><td align="left" >'
								+array[1]
								+ '</td></tr>');
				$('#smsDiv').show();
				$('#linkstableId').show();
			}
			$('#smsDiv').show();
			$('#linkstableId').show();
		}*/
		
			  }else {
			$('#transactiontableId').html('<br><p align="center">No record found</p>');
		}
		
	
		
	}
});
	}
	else{
		
		$('#smsDiv').hide();
		$('#linkstableId').hide();	
	}
	
}
function clrmsg(){
	 //$('#linkstableId').html('');
	
}

function checkboxes(){
	 
	 /*if($('#'+chk+'').is(":checked"))*/
	 if($('.cbx').is(":checked")){
		 $('#smsDiv').show();
	  $('#sms').prop('checked',true);
	  $('#mail').prop('checked',true);
	  }
	 else{
	  $('#sms').prop('checked',false);
	  $('#mail').prop('checked',false);
	  $('#smsDiv').hide();
	 }
}
function clearstatus(){
	$('#statusMessage').html("");
}

function getPuk(){

	var productId=$('#productId0').val();
alert(productId)
$.ajax({
	async: false,
	url: 'getPUK',
	type:'POST',
	data:'productId='+productId,
	success:function(response)
	{
	
		var a=response;
		/*alert(a);*/
		$("#iderror").show();
		$("#iderror").html("<font color='green'>"+a+"</font>");
	},
	  error: function(e) {
										
			  }
});

 event.preventDefault();
 return true;
}
function clearmsg1(){
	$("#iderror").html("");
	$("#statusMessage1").html("");
}