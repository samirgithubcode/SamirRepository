/**
 * 
 */
package com.ng.sb.common.dataobject;

/**
 * @author abhishek
 *
 */


import java.sql.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PartnerData extends BaseObjectData  implements Comparable<PartnerData> {

	private static final long serialVersionUID = 1L;
	public enum BankRelation{
		DIRECT_INSTRUMENT,
		FSP_SERVICE,
		REGISTERED_INSTRUMENT_FSP_SERVICE,
		FSP_PROVIDER,
		REGISTERED_INSTRUMENT_FSP_PROVIDER,
		OTHER_SERVICE
	}
	private String mappingId;
	private Integer showWallet;
	private Map<InstrumentData,InstrumentData> instrumentMap = new HashMap<>();
	private Map<String,String> sequenceMap = new HashMap<>();
	private String partnerType;
	private Integer[] otherServices;
	private Integer[] fspotherServices;
	private Integer[] financialInstrument;
	private String bank;
	private String fspfundTransferBank;
	private String fspBank;
	private String rifundTransferBank;
	private String otherBank;
	private String[] providers;
	private String[] fspproviders;
	private String[] riFspproviders;
	private Integer[] fspfinancialInstrument;
	private String[] riFspProviderCode;
	private String[] fspProviderCode;
	private String[] providerCode;
	private Integer fsp;
	private Integer rifspfinancialInstrument;
	private String walletType;
	private Map<String,String> walletTypes;
	private String companyName;
	private Integer partnerCode;
	private String nickName;
	private PartnerData parentPartner;
	private String mode;
	private Map<String,Integer> priorityMap;
	private AccountInfoData host;
	private boolean fundTransferFSP;
	private boolean providerFSP;
	private String type;
	private Integer sequence;
	private Map<BankRelation,Map<String,String>> bankBranchesMap;
	private Map<CategoryData,List<ProvidersData>> categoryProviderMapping;
	private String mappingName;
	private Map<Integer,String> providerMap = new HashMap<>();
	private String branchCode;
	private String accountNumber;
	
	private String partnerInstrumentMappingId;
	private Map<String,String> partnerSequenceMappingId;
	private Integer directBankCount;
	private Integer fspProviderBankCount;
	private Integer directBankInstCount;
	private Integer fspProvBankInstCount;
	private String fspProviderfspotherServicesShowStatus;
	private String otherServicesShowStatus;
	private transient Map partnerSequenceMap;
	private transient List<Map> partnerForFsp;
	private Map<String,String> partnerCommissionMappingId;
	private String partnerCommissionId;
	private Map<Integer,Integer> noofwallet;
	private Map<String ,Integer> dropDownValues;
	private String walletstatus;
	public PartnerData(){
		//default constructor
	}
	public PartnerData(Integer partnerCode){
		this.partnerCode=partnerCode;
	}
	public Map<String, Integer> getPriorityMap() {
		return priorityMap;
	}
	public void setPriorityMap(Map<String, Integer> priorityMap) {
		this.priorityMap = priorityMap;
	}
	public Map getPartnerSequenceMap() {
		return partnerSequenceMap;
	}
	public void setPartnerSequenceMap(Map partnerSequenceMap) {
		this.partnerSequenceMap = partnerSequenceMap;
	}

	public List<Map> getPartnerForFsp() {
		return partnerForFsp;
	}
	public void setPartnerForFsp(List<Map> partnerForFsp) {
		this.partnerForFsp = partnerForFsp;
	}

	public String getPartnerCommissionId() {
		return partnerCommissionId;
	}
	public void setPartnerCommissionId(String partnerCommissionId) {
		this.partnerCommissionId = partnerCommissionId;
	}
	public Map<String, String> getPartnerCommissionMappingId() {
		return partnerCommissionMappingId;
	}
	public void setPartnerCommissionMappingId(Map<String, String> partnerCommissionMappingId) {
		this.partnerCommissionMappingId = partnerCommissionMappingId;
	}

	
	public Map<String, Integer> getDropDownValues() {
		return dropDownValues;
	}
	public void setDropDownValues(Map<String, Integer> dropDownValues) {
		this.dropDownValues = dropDownValues;
	}
	public Integer getShowWallet() {
		return showWallet;
	}
	public void setShowWallet(Integer showWallet) {
		this.showWallet = showWallet;
	}

	
	public String getMappingId() {
		return mappingId;
	}
	public Map<Integer, Integer> getNoofwallet() {
		return noofwallet;
	}
	public void setNoofwallet(Map<Integer, Integer> noofwallet) {
		this.noofwallet = noofwallet;
	}
	public void setMappingId(String mappingId) {
		this.mappingId = mappingId;
	}
	public Map<String, String> getSequenceMap() {
		return sequenceMap;
	}
	public void setSequenceMap(Map<String, String> sequenceMap) {
		this.sequenceMap = sequenceMap;
	}
	public Map<String, String> getPartnerSequenceMappingId() {
		return partnerSequenceMappingId;
	}
	public void setPartnerSequenceMappingId(
			Map<String, String> partnerSequenceMappingId) {
		this.partnerSequenceMappingId = partnerSequenceMappingId;
	}
	public String getPartnerInstrumentMappingId() {
		return partnerInstrumentMappingId;
	}
	public void setPartnerInstrumentMappingId(String partnerInstrumentMappingId) {
		this.partnerInstrumentMappingId = partnerInstrumentMappingId;
	}
	
	
	public Map<InstrumentData, InstrumentData> getInstrumentMap() {
		return instrumentMap;
	}

	public void setInstrumentMap(Map<InstrumentData, InstrumentData> instrumentMap) {
		this.instrumentMap = instrumentMap;
	}

	public String getRifundTransferBank() {
		return rifundTransferBank;
	}

	public void setRifundTransferBank(String rifundTransferBank) {
		this.rifundTransferBank = rifundTransferBank;
	}

	public String getOtherBank() {
		return otherBank;
	}

	public void setOtherBank(String otherBank) {
		this.otherBank = otherBank;
	}
	public String[] getRiFspProviderCode() {
		return riFspProviderCode;
	}

	public void setRiFspProviderCode(String[] riFspProviderCode) {
		this.riFspProviderCode = riFspProviderCode;
	}

	public String[] getFspProviderCode() {
		return fspProviderCode;
	}

	public void setFspProviderCode(String[] fspProviderCode) {
		this.fspProviderCode = fspProviderCode;
	}

	public String[] getProviderCode() {
		return providerCode;
	}

	public void setProviderCode(String[] providerCode) {
		this.providerCode = providerCode;
	}

	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	
	public Map<String, String> getWalletTypes() {
		return walletTypes;
	}

	public void setWalletTypes(Map<String, String> walletTypes) {
		this.walletTypes = walletTypes;
	}

	public Map<Integer, String> getProviderMap() {
		return providerMap;
	}

	public void setProviderMap(Map<Integer, String> providerMap) {
		this.providerMap = providerMap;
	}

	public String getMappingName() {
		return mappingName;
	}

	public void setMappingName(String mappingName) {
		this.mappingName = mappingName;
	}

	public Map<CategoryData, List<ProvidersData>> getCategoryProviderMapping() {
		return categoryProviderMapping;
	}

	public void setCategoryProviderMapping(Map<CategoryData, List<ProvidersData>> categoryProviderMapping) {
		this.categoryProviderMapping = categoryProviderMapping;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	
	public String getPartnerType() {
		return partnerType;
	}

	public void setPartnerType(String partnerType) {
		this.partnerType = partnerType;
	}

	public Integer[] getFinancialInstrument() {
		return financialInstrument;
	}

	public void setFinancialInstrument(Integer[] financialInstrument) {
		this.financialInstrument = financialInstrument;
	}

	public String getWalletType() {
		return walletType;
	}

	public void setWalletType(String walletType) {
		this.walletType = walletType;
	}

	public Integer[] getOtherServices() {
		return otherServices;
	}

	public void setOtherServices(Integer[] otherServices) {
		this.otherServices = otherServices;
	}

	public String getBank() {
		return bank;
	}

	public void setBank(String bank) {
		this.bank = bank;
	}

	public String getFspfundTransferBank() {
		return fspfundTransferBank;
	}

	public void setFspfundTransferBank(String fspfundTransferBank) {
		this.fspfundTransferBank = fspfundTransferBank;
	}

	public String[] getFspproviders() {
		return fspproviders;
	}

	public void setFspproviders(String[] fspproviders) {
		this.fspproviders = fspproviders;
	}

	public Integer[] getFspfinancialInstrument() {
		return fspfinancialInstrument;
	}

	public void setFspfinancialInstrument(Integer[] fspfinancialInstrument) {
		this.fspfinancialInstrument = fspfinancialInstrument;
	}

	public Integer[] getFspotherServices() {
		return fspotherServices;
	}

	public void setFspotherServices(Integer[] fspotherServices) {
		this.fspotherServices = fspotherServices;
	}
	
	public String[] getRiFspproviders() {
		return riFspproviders;
	}

	public void setRiFspproviders(String[] riFspproviders) {
		this.riFspproviders = riFspproviders;
	}

	public Integer getRifspfinancialInstrument() {
		return rifspfinancialInstrument;
	}

	public void setRifspfinancialInstrument(Integer rifspfinancialInstrument) {
		this.rifspfinancialInstrument = rifspfinancialInstrument;
	}
	
	public String getFspBank() {
		return fspBank;
	}

	public void setFspBank(String fspBank) {
		this.fspBank = fspBank;
	}

	public String[] getProviders() {
		return providers;
	}

	public void setProviders(String[] providers) {
		this.providers = providers;
	}

	public Integer getFsp() {
		return fsp;
	}

	public void setFsp(Integer fsp) {
		this.fsp = fsp;
	}

	public Map<BankRelation, Map<String, String>> getBankBranchesMap() {
		return bankBranchesMap;
	}

	public void setBankBranchesMap(
			Map<BankRelation, Map<String, String>> bankBranchesMap) {
		this.bankBranchesMap = bankBranchesMap;
	}

	public Integer getSequence() {
		return sequence;
	}

	public void setSequence(Integer sequence) {
		this.sequence = sequence;
	}

	public Integer getPartnerCode() {
		return partnerCode;
	}

	public void setPartnerCode(Integer partnerCode) {
		this.partnerCode = partnerCode;
	}

	public String getNickName() {
		return nickName;
	}

	public void setNickName(String nickName) {
		this.nickName = nickName;
	}

	public PartnerData getParentPartner() {
		return parentPartner;
	}

	public void setParentPartner(PartnerData parentPartner) {
		this.parentPartner = parentPartner;
	}

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public AccountInfoData getHost() {
		return host;
	}

	public void setHost(AccountInfoData host) {
		this.host = host;
	}

	public boolean isFundTransferFSP() {
		return fundTransferFSP;
	}

	public void setFundTransferFSP(boolean fundTransferFSP) {
		this.fundTransferFSP = fundTransferFSP;
	}

	public boolean isProviderFSP() {
		return providerFSP;
	}

	public void setProviderFSP(boolean providerFSP) {
		this.providerFSP = providerFSP;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Integer getDirectBankCount() {
		return directBankCount;
	}
	public void setDirectBankCount(Integer directBankCount) {
		this.directBankCount = directBankCount;
	}
	public Integer getFspProviderBankCount() {
		return fspProviderBankCount;
	}
	public void setFspProviderBankCount(Integer fspProviderBankCount) {
		this.fspProviderBankCount = fspProviderBankCount;
	}
	public Integer getDirectBankInstCount() {
		return directBankInstCount;
	}
	public void setDirectBankInstCount(Integer directBankInstCount) {
		this.directBankInstCount = directBankInstCount;
	}
	public Integer getFspProvBankInstCount() {
		return fspProvBankInstCount;
	}
	public void setFspProvBankInstCount(Integer fspProvBankInstCount) {
		this.fspProvBankInstCount = fspProvBankInstCount;
	}

	public String getFspProviderfspotherServicesShowStatus() {
		return fspProviderfspotherServicesShowStatus;
	}
	public void setFspProviderfspotherServicesShowStatus(String fspProviderfspotherServicesShowStatus) {
		this.fspProviderfspotherServicesShowStatus = fspProviderfspotherServicesShowStatus;
	}
	public String getOtherServicesShowStatus() {
		return otherServicesShowStatus;
	}
	public void setOtherServicesShowStatus(String otherServicesShowStatus) {
		this.otherServicesShowStatus = otherServicesShowStatus;
	}
	@Override
	public boolean equals(Object obj) {
		if(obj==null){
			return false;
		}
		boolean check=false;
		if(obj instanceof PartnerData){
			PartnerData other = (PartnerData)obj;
			if(this.partnerCode!=null && other.getPartnerCode()!=null && this.partnerCode.equals(other.getPartnerCode())){
				check= true;
			}
			return check;
		}
		return super.equals(obj);
	}
	
	@Override
	public int hashCode() {
		if( this.partnerCode!=null){
			return this.partnerCode*7;	
		}else{
			return 0;
		}
		
	}

	
	@Override
	public int compareTo(PartnerData other) {
		if( other!=null){
			if(this.getSequence()==other.getSequence()){
				return 0;		
			}
			return this.getSequence()>other.getSequence()?1:-1;
		}
		return 0;	
	}
	public String getWalletstatus() {
		return walletstatus;
	}
	public void setWalletstatus(String walletstatus) {
		this.walletstatus = walletstatus;
	}
}
