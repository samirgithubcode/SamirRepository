/**
 * 
 */
package com.ng.sb.common.exception;

/**
 * @author himanshu
 *
 */
public class DecryptionException  extends Exception {
	private static final long serialVersionUID = 1L;
	
	public DecryptionException(String message){
		super(message);
	}
}