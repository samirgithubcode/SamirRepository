package com.ng.sb.common.dataobject;

import java.io.Serializable;

/**
 * @author amardeep
 *
 */
public class HostFeeData implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String templateCommType;
	private CommissionData commissionData;
	
	public String getTemplateCommType() {
		return templateCommType;
	}
	public void setTemplateCommType(String templateCommType) {
		this.templateCommType = templateCommType;
	}
	public CommissionData getCommissionData() {
		return commissionData;
	}
	public void setCommissionData(CommissionData commissionData) {
		this.commissionData = commissionData;
	}
}