/**
 * 
 */
package com.ng.bridge.service;

import com.ng.sb.common.service.IService;

/**
 * @author gaurav
 * Common Services for Bridge Component
 */
public interface IBridgeService extends IService {

}
