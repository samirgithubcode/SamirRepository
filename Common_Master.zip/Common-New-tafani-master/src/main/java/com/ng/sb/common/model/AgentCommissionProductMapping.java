package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
*
* @author Simran
* 
* The persistent class for the agent mapped to commission  database table.
*/
@Entity
@Table(name = "agentcommissionproductmapping")
@XmlRootElement
@NamedQueries({
	@NamedQuery(name="AgentCommissionProductMapping.findByInfo", query="SELECT c FROM AgentCommissionProductMapping c where c.agentCompanyId=:agentId And c.isActive=1 And endDate=Null" ), // And c.productCommissionId=:cid
	@NamedQuery(name="AgentCommissionProductMapping.findByProductMapping", query="SELECT c FROM AgentCommissionProductMapping c where c.productCommissionId=:productCommissionId AND c.endDate IS NULL OR c.endDate > :tDate"),
	@NamedQuery(name="AgentCommissionProductMapping.findApplicableCommProdMapping", query="SELECT acpm FROM AgentCommissionProductMapping acpm where acpm.isActive=1 AND (acpm.agentId=:agentUserId OR acpm.agentCompanyId=:agentId) AND acpm.startDate <= :tDate AND (acpm.endDate IS NULL OR acpm.endDate >= :tDate) ORDER BY acpm.agentId DESC" ),
	@NamedQuery(name="AgentCommissionProductMapping.findByAgentId", query="SELECT c FROM AgentCommissionProductMapping c where c.agentId=:agentId And c.isActive=1 And endDate=Null" ),
	@NamedQuery(name="AgentCommissionProductMapping.findByCompanyId", query="SELECT c FROM AgentCommissionProductMapping c where c.agentCompanyId=:agentCompanyId And c.isActive=1 And endDate=Null" ),
	@NamedQuery(name="AgentCommissionProductMapping.findApplicableCommProdMappingMIS", query="SELECT acpm FROM AgentCommissionProductMapping acpm where acpm.isActive=1 AND (acpm.agentCompanyId=:agentCompanyId OR acpm.agentId=:agentId) AND acpm.startDate <= :tDate AND (acpm.endDate IS NULL OR acpm.endDate >= :tDate) order by acpm.agentId desc" ),
	
	/*@NamedQuery(name="AgentCommissionProductMapping.findByIds", query="SELECT c FROM AgentCommissionProductMapping c where c.agentCompanyId=:agentCompanyId AND c.agentId=:agentId And c.isActive=1 And c.endDate=Null" ),*/
})
public class AgentCommissionProductMapping implements Serializable {
	private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Column(name = "agent_company_id")
    private String agentCompanyId;
    
    @Column(name = "agent_user_id")
    private String agentId;
    @JoinColumn(name = "commission_product_id", referencedColumnName = "id")
    @ManyToOne
    private CommissionProduct productCommissionId;
    @Column(name = "created_on")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createDate;
    @Column(name = "created_by") 
    private Integer createdBy;
    @Column(name = "start_date")
    @Temporal(TemporalType.DATE)
    private Date startDate;
    @Column(name = "end_date")
    @Temporal(TemporalType.DATE)
    private Date endDate;
    @Column(name = "updated_on")
    @Temporal(TemporalType.TIMESTAMP)
    private Date modifiedDate;
    @Column(name = "updated_by") 
    private Integer updatedBy;
    @Column(name = "isActive")
    private Integer isActive;
    public AgentCommissionProductMapping() {
 		//default
 	}
    public AgentCommissionProductMapping(Integer id) {
        this.id = id;
    }
    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
    	boolean check=true;
    	if(object!=null){
        if (!(object instanceof AgentCommissionProductMapping)) {
        	check= false;
        }
        AgentCommissionProductMapping other = (AgentCommissionProductMapping) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
    	}
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.AgentCommissionProductMapping[ id=" + id + " ]";
    }
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	
	public CommissionProduct getProductCommissionMappingId() {
		return productCommissionId;
	}
	public void setProductCommissionMappingId(CommissionProduct productCommissionId) {
		this.productCommissionId = productCommissionId;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public Integer getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}
	public Integer getIsActive() {
		return isActive;
	}
	public void setIsActive(Integer isActive) {
		this.isActive = isActive;
	}
	public String getAgentCompanyId() {
		return agentCompanyId;
	}
	public void setAgentCompanyId(String agentCompanyId) {
		this.agentCompanyId = agentCompanyId;
	}
	public CommissionProduct getProductCommissionId() {
		return productCommissionId;
	}
	public void setProductCommissionId(CommissionProduct productCommissionId) {
		this.productCommissionId = productCommissionId;
	}
	public String getAgentId() {
		return agentId;
	}
	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}
	
	
}
