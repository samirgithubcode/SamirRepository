package com.ng.sb.common.dataobject;

import java.util.List;

public class ShortOverlaysData  extends BaseObjectData {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private List<ShortOverlaysData> shortOverlaysDataList;
	private String product;
	private String masterVersion;
	private String externalNumber;
	public List<ShortOverlaysData> getShortOverlaysDataList() {
		return shortOverlaysDataList;
	}
	public void setShortOverlaysDataList(List<ShortOverlaysData> shortOverlaysDataList) {
		this.shortOverlaysDataList = shortOverlaysDataList;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public String getMasterVersion() {
		return masterVersion;
	}
	public void setMasterVersion(String masterVersion) {
		this.masterVersion = masterVersion;
	}
	public String getExternalNumber() {
		return externalNumber;
	}
	public void setExternalNumber(String externalNumber) {
		this.externalNumber = externalNumber;
	}
	

}
