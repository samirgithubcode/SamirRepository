package com.ng.transaction.service;

import org.springframework.stereotype.Component;

import com.ng.sb.common.dataobject.OverlayIssuance;
import com.ng.sb.common.dataobject.ResponseObject;
import com.ng.sb.common.dataobject.TransactionRequestData;
import com.ng.sb.common.model.CustomerDetails;
import com.ng.sb.common.service.IService;
import com.ng.transaction.data.SecureTransactionResponse;

@Component
public interface ISecureTransactionService extends IService
{
	public SecureTransactionResponse transferMoneyToWallet(TransactionRequestData transactionRequestData);

	public ResponseObject overlayIssuance(OverlayIssuance overlayIssuanceData) throws Exception;
	
	public ResponseObject addCustomerDetails(CustomerDetails customerDetails);
	
	public ResponseObject deActivateOverlay(OverlayIssuance overlayIssuanceData) throws Exception;
	
	public ResponseObject activateOverlay(OverlayIssuance overlayIssuanceData) throws Exception;
	
	public ResponseObject issuedList(OverlayIssuance overlayIssuanceData) throws Exception;
	
	public ResponseObject manageAccounts(OverlayIssuance overlayIssuanceData) throws Exception;
	
	public ResponseObject fetchCustomerDetails(OverlayIssuance overlayIssuanceData) throws Exception;
	
	public ResponseObject removeAllData(OverlayIssuance overlayIssuanceData) throws Exception;
}
