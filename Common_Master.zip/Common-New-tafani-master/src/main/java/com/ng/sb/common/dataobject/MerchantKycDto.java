package com.ng.sb.common.dataobject;

import java.util.Date;



public class MerchantKycDto {
	private String docType;
	private String docIdNumber;
	private String docIssuedBy;
	private String docStatus;
	private String comment;
	private String addedBy;
	private String modifiedOn;
	private Date modifiedBy;
	private String addedOn;
	public String getDocType() {
		return docType;
	}
	public void setDocType(String docType) {
		this.docType = docType;
	}
	public String getDocIdNumber() {
		return docIdNumber;
	}
	public void setDocIdNumber(String docIdNumber) {
		this.docIdNumber = docIdNumber;
	}
	public String getDocIssuedBy() {
		return docIssuedBy;
	}
	public void setDocIssuedBy(String docIssuedBy) {
		this.docIssuedBy = docIssuedBy;
	}
	public String getDocStatus() {
		return docStatus;
	}
	public void setDocStatus(String docStatus) {
		this.docStatus = docStatus;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getAddedOn() {
		return addedOn;
	}
	public void setAddedOn(String addedOn) {
		this.addedOn = addedOn;
	}
	public String getAddedBy() {
		return addedBy;
	}
	public void setAddedBy(String addedBy) {
		this.addedBy = addedBy;
	}
	public String getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(String modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	public Date getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Date modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	
}
