package com.ng.sb.common.dataobject;


public class InventoryRequest  implements ValidationBean  {
	private static final long serialVersionUID = 1399593624627585064L;
	private String mobileNumber;
	private String tokenId;
	private Integer productId;
	public String getMobileNumber() {
		return mobileNumber;
	}
	public String getTokenId() {
		return tokenId;
	}
	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}

}
