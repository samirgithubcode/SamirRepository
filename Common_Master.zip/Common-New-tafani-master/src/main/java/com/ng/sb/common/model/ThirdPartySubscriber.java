/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "ThirdPartySubscriber")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "ThirdPartySubscriber.findAll", query = "SELECT t FROM ThirdPartySubscriber t"),
    @NamedQuery(name = "ThirdPartySubscriber.findById", query = "SELECT t FROM ThirdPartySubscriber t WHERE t.id = :id"),
    @NamedQuery(name = "ThirdPartySubscriber.findByMobile", query = "SELECT t FROM ThirdPartySubscriber t WHERE t.mobile = :mobile"),
    @NamedQuery(name = "ThirdPartySubscriber.findByMobileAndWalletId", query = "SELECT t FROM ThirdPartySubscriber t WHERE t.mobile = :mobile and t.walletId=:walletId")
    
})
public class ThirdPartySubscriber implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Column(name = "agentId")
    private String agentId;
    @Basic(optional = false)
    @Column(name = "mobile")
    private String mobile;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tpsId")
    private Collection<ThirdPartySubsRecipient> thirdPartySubsRecipientCollection;
    @JoinColumn(name = "walletId", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Partner walletId;

    public ThirdPartySubscriber() {
    	//empty
    }

    public ThirdPartySubscriber(Integer id) {
        this.id = id;
    }

    public ThirdPartySubscriber(Integer id, String mobile) {
        this.id = id;
        this.mobile = mobile;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

   

    public String getAgentId() {
		return agentId;
	}

	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}

	public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    @XmlTransient
    public Collection<ThirdPartySubsRecipient> getThirdPartySubsRecipientCollection() {
        return thirdPartySubsRecipientCollection;
    }

    public void setThirdPartySubsRecipientCollection(Collection<ThirdPartySubsRecipient> thirdPartySubsRecipientCollection) {
        this.thirdPartySubsRecipientCollection = thirdPartySubsRecipientCollection;
    }

    public Partner getWalletId() {
        return walletId;
    }

    public void setWalletId(Partner walletId) {
        this.walletId = walletId;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.ThirdPartySubscriber[ id=" + id + " ]";
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof ThirdPartySubscriber)) {
            return false;
        }
        ThirdPartySubscriber other = (ThirdPartySubscriber) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

   
    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }
    
}
