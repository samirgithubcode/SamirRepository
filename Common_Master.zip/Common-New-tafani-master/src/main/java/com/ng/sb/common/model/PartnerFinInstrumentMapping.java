/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "PartnerFinInstrumentMapping")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "PartnerFinInstrumentMapping.findAll", query = "SELECT p FROM PartnerFinInstrumentMapping p"),
    @NamedQuery(name = "PartnerFinInstrumentMapping.findById", query = "SELECT p FROM PartnerFinInstrumentMapping p WHERE p.id = :id"),
    @NamedQuery(name = "PartnerFinInstrumentMapping.findByPartnerId", query = "SELECT p FROM PartnerFinInstrumentMapping p WHERE p.partnerId = :partnerId"),
    @NamedQuery(name = "PartnerFinInstrumentMapping.findByRelationshipType", query = "SELECT p FROM PartnerFinInstrumentMapping p WHERE p.relationshipType = :relationshipType"),
    @NamedQuery(name = "PartnerFinInstrumentMapping.findByInstrumentIdAndRelationShipType", query = "SELECT p FROM PartnerFinInstrumentMapping p WHERE p.instrumentId = :instrumentId and p.relationshipType =:relationshipType"),
    @NamedQuery(name = "PartnerFinInstrumentMapping.findByPartnerIdAndRelationShipType", query = "SELECT p FROM PartnerFinInstrumentMapping p WHERE p.partnerId.id = :partnerId and p.relationshipType =:relationshipType"),
})
public class PartnerFinInstrumentMapping implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
   
    @JoinColumn(name = "partnerId", referencedColumnName = "id", nullable = false)
    @ManyToOne(optional = false)
    private Partner partnerId;
    
    @Basic(optional = false)
    @Column(name = "relationshipType", nullable = false, length = 12)
    private String relationshipType;
    @JoinColumn(name = "instrumentId", referencedColumnName = "id", nullable = false)
    @ManyToOne(optional = false)
    private FinancialInstrument instrumentId;

    public PartnerFinInstrumentMapping() {
    	//empty
    	    }

    public PartnerFinInstrumentMapping(Integer id) {
        this.id = id;
    }

    public PartnerFinInstrumentMapping(Integer id, String relationshipType) {
        this.id = id;
        this.relationshipType = relationshipType;
    }

   
    public String getRelationshipType() {
        return relationshipType;
    }

    public void setRelationshipType(String relationshipType) {
        this.relationshipType = relationshipType;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Partner getPartnerId() {
        return partnerId;
    }

    public void setPartnerId(Partner partnerId) {
        this.partnerId = partnerId;
    }

    public FinancialInstrument getInstrumentId() {
        return instrumentId;
    }

    public void setInstrumentId(FinancialInstrument instrumentId) {
        this.instrumentId = instrumentId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof PartnerFinInstrumentMapping)) {
            return false;
        }
        PartnerFinInstrumentMapping other = (PartnerFinInstrumentMapping) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.PartnerFinInstrumentMapping[ id=" + id + " ]";
    }
    
}
