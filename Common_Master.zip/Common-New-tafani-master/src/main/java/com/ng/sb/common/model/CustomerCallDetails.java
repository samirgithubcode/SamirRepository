/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "customer_call_details")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CustomerCallDetails.findAll", query = "SELECT c FROM CustomerCallDetails c"),
    @NamedQuery(name = "CustomerCallDetails.findById", query = "SELECT c FROM CustomerCallDetails c WHERE c.id = :id"),
    @NamedQuery(name = "CustomerCallDetails.findByCustomerId", query = "SELECT c FROM CustomerCallDetails c WHERE c.customerId = :customerId"),
    @NamedQuery(name = "CustomerCallDetails.findByAccountType", query = "SELECT c FROM CustomerCallDetails c WHERE c.accountType = :accountType"),
    @NamedQuery(name = "CustomerCallDetails.findByHostId", query = "SELECT c FROM CustomerCallDetails c WHERE c.hostId = :hostId"),
    @NamedQuery(name = "CustomerCallDetails.findByMsisdnNo", query = "SELECT c FROM CustomerCallDetails c WHERE c.msisdnNo = :msisdnNo"),
    @NamedQuery(name = "CustomerCallDetails.findByCallDateTime", query = "SELECT c FROM CustomerCallDetails c WHERE c.callDateTime = :callDateTime"),
    @NamedQuery(name = "CustomerCallDetails.findByCallEndDateTime", query = "SELECT c FROM CustomerCallDetails c WHERE c.callEndDateTime = :callEndDateTime"),
    @NamedQuery(name = "CustomerCallDetails.findByCcAgentId", query = "SELECT c FROM CustomerCallDetails c WHERE c.ccAgentId = :ccAgentId"),
    @NamedQuery(name = "CustomerCallDetails.findByDescription", query = "SELECT c FROM CustomerCallDetails c WHERE c.description = :description"),
    @NamedQuery(name = "CustomerCallDetails.findByRemark", query = "SELECT c FROM CustomerCallDetails c WHERE c.remark = :remark"),
    @NamedQuery(name = "CustomerCallDetails.findByStatus", query = "SELECT c FROM CustomerCallDetails c WHERE c.status = :status")})
public class CustomerCallDetails implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
    @Basic(optional = false)
    @Column(name = "customer_id", nullable = false)
    private int customerId;
    @Basic(optional = false)
    @Column(name = "account_type", nullable = false)
    private int accountType;
    @Basic(optional = false)
    @Column(name = "host_id", nullable = false)
    private int hostId;
    @Basic(optional = false)
    @Column(name = "msisdn_no", nullable = false, length = 12)
    private String msisdnNo;
    @Basic(optional = false)
    @Column(name = "call_date_time", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date callDateTime;
    @Basic(optional = false)
    @Column(name = "call_end_date_time", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date callEndDateTime;
    @Basic(optional = false)
    @Column(name = "cc_agent_id", nullable = false)
    private int ccAgentId;
    @Basic(optional = false)
    @Column(name = "description", nullable = false, length = 500)
    private String description;
    @Column(name = "remark", length = 500)
    private String remark;
    @Basic(optional = false)
    @Column(name = "status", nullable = false)
    private int status;
    @JoinColumn(name = "faq_id", referencedColumnName = "id")
    @ManyToOne
    private FaqDetails faqId;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "callId")
    private Collection<CustomerCallVerificationInfo> customerCallVerificationInfoCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "customerCallId")
    private Collection<CustomerComplaintInfo> customerComplaintInfoCollection;

    public CustomerCallDetails() {
    	//default constructor
    }

    public CustomerCallDetails(Integer id) {
        this.id = id;
    }

    public CustomerCallDetails(Integer id, int customerId, int accountType, int hostId, String msisdnNo, Date callDateTime, Date callEndDateTime) {
        this.id = id;
        this.customerId = customerId;
        this.accountType = accountType;
        this.hostId = hostId;
        this.msisdnNo = msisdnNo;
        this.callDateTime = callDateTime;
        this.callEndDateTime = callEndDateTime;
       
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public int getAccountType() {
        return accountType;
    }

    public void setAccountType(int accountType) {
        this.accountType = accountType;
    }

    public int getHostId() {
        return hostId;
    }

    public void setHostId(int hostId) {
        this.hostId = hostId;
    }

    public String getMsisdnNo() {
        return msisdnNo;
    }

    public void setMsisdnNo(String msisdnNo) {
        this.msisdnNo = msisdnNo;
    }

    public Date getCallDateTime() {
        return callDateTime;
    }

    public void setCallDateTime(Date callDateTime) {
        this.callDateTime = callDateTime;
    }

    public Date getCallEndDateTime() {
        return callEndDateTime;
    }

    public void setCallEndDateTime(Date callEndDateTime) {
        this.callEndDateTime = callEndDateTime;
    }

    public int getCcAgentId() {
        return ccAgentId;
    }

    public void setCcAgentId(int ccAgentId) {
        this.ccAgentId = ccAgentId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public FaqDetails getFaqId() {
        return faqId;
    }

    public void setFaqId(FaqDetails faqId) {
        this.faqId = faqId;
    }

    @XmlTransient
    public Collection<CustomerCallVerificationInfo> getCustomerCallVerificationInfoCollection() {
        return customerCallVerificationInfoCollection;
    }

    public void setCustomerCallVerificationInfoCollection(Collection<CustomerCallVerificationInfo> customerCallVerificationInfoCollection) {
        this.customerCallVerificationInfoCollection = customerCallVerificationInfoCollection;
    }

    @XmlTransient
    public Collection<CustomerComplaintInfo> getCustomerComplaintInfoCollection() {
        return customerComplaintInfoCollection;
    }

    public void setCustomerComplaintInfoCollection(Collection<CustomerComplaintInfo> customerComplaintInfoCollection) {
        this.customerComplaintInfoCollection = customerComplaintInfoCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof CustomerCallDetails)) {
            return false;
        }
        CustomerCallDetails other = (CustomerCallDetails) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.CustomerCallDetails[ id=" + id + " ]";
    }
    
}
