/**
 * 
 */
package com.ng.sb.common.dao.impl;

import org.springframework.stereotype.Repository;

import com.ng.sb.common.dao.IMisDAO;
import com.ng.sb.common.util.SystemConstant;

/**
 * @author gaurav
 * Abstract DAO which will contain common MIS Implementation. 
 */
@Repository(value=SystemConstant.MIS_DAO)
public  class MisDAO  extends SuperParentDAO  implements IMisDAO {
	private static final long serialVersionUID = 1L;

}
