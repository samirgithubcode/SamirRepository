package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

/**
 * The persistent class for the UserWalletDetails database table.
 * 
 */
@Entity
@Table(name="User_Wallet_details")
@NamedQueries({
	@NamedQuery(name = "UserWalletDetails.findByUserId", query = "SELECT u FROM UserWalletDetails u WHERE u.userid = :userid"),
	@NamedQuery(name = "UserWalletDetails.findBySubsUserId", query = "SELECT u FROM UserWalletDetails u WHERE u.userid = :id"),
	@NamedQuery(name = "UserWalletDetails.findBySubsBankWallet", query = "SELECT u FROM UserWalletDetails u WHERE u.userid = :userid AND u.bankId=:bankId AND u.status=:status"),
	@NamedQuery(name = "UserWalletDetails.findBySubscriberWalletBank", query = "SELECT u FROM UserWalletDetails u WHERE u.userid = :userid AND u.bankId=:bankId "),
	@NamedQuery(name = "UserWalletDetails.findBySubsAndOTP", query = "SELECT u FROM UserWalletDetails u WHERE u.userid = :userid AND u.userOtp=:user_otp"),
	@NamedQuery(name = "UserWalletDetails.findByCustId", query = "SELECT u FROM UserWalletDetails u WHERE u.custId = :cust_Id"),
	@NamedQuery(name = "UserWalletDetails.findBySubsWallet", query = "SELECT u FROM UserWalletDetails u WHERE u.userid = :userid AND u.walletType=:walletType"),
	@NamedQuery(name = "UserWalletDetails.findByBankSubsWallet", query = "SELECT u FROM UserWalletDetails u WHERE u.userid = :userid AND u.walletType=:walletType AND u.bankId=:bankId"),
})
public class UserWalletDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false)
	private Integer id;
	
	@ManyToOne
	@JoinColumn(name="wallet_type_id", referencedColumnName="id")
	private WalletType walletType;
	
	@ManyToOne(optional = false,fetch=FetchType.LAZY)
	@JoinColumn(name="userid", referencedColumnName="id")
	private Subscriber userid;
	
	@Column(name="current_balance")
	private String currentBalance;
	
	@Column(name="transaction_pin")
	private String transactionPin;
	
	@Basic(optional = false)
    @Column(name = "default_pin_status", nullable = false)
    private boolean defaultPinStatus;
	
	@Column(name="last_txnId")
	private String lastTxnId;
	
	@Basic(optional = false)
    @Column(name = "status")
    private boolean status;
	
	
	
	@Basic(optional = false)
	@Column(name="daily_credit_limit")
	private Integer dailyCreditLimit;
	
	
	@Basic(optional = false)
	@Column(name="daily_debit_limit")
	private Integer dailyDebitLimit;
	
	@Basic(optional = false)
	@Column(name="daily_trx_count")
	private Integer dailyTrxCount;
	
	
	
	@Basic(optional = false)
	@Column(name="monthly_credit_limit")
	private Integer monthlyCreditLimit;
	
	@Basic(optional = false)
	@Column(name="monthly_debit_limit")
	private Integer monthlyDebitLimit;
	
	@Basic(optional = false)
	@Column(name="monthly_trx_count")
	private Integer monthlyTrxCount;
	
	
	@Basic(optional = false)
	@Column(name="yearly_credit_limit")
	private Integer yearlyCreditLimit;
	
	@Basic(optional = false)
	@Column(name="yearly_debit_limit")
	private Integer yearlyDebitLimit;
	
	
	@Basic(optional = false)
	@Column(name="yearly_trx_count")
	private Integer yearlyTrxCount;

	@Column(name="added_by")
	private Integer addedBy;
	
	@Column(name="modified_by")
	private Integer modifiedBy;
	
	@Column(name="cust_Id")
	private String custId;
	
	@Column(name = "access_channel")
	private Integer accessChannel;
	
	@Column(name = "createDate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createDate;
	
	@JoinColumn(name="bankId", referencedColumnName="id")
	@ManyToOne(fetch = FetchType.LAZY)
	@NotFound(
	        action = NotFoundAction.IGNORE)
	@Fetch(FetchMode.SELECT)
	private Banks bankId;
	
	@Column(name="user_otp")
	private Integer userOtp;
	
	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Integer getAccessChannel() {
		return accessChannel;
	}

	public void setAccessChannel(Integer accessChannel) {
		this.accessChannel = accessChannel;
	}

	public String getCustId() {
		return custId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}

	public Integer getUserOtp() {
		return userOtp;
	}

	public void setUserOtp(Integer userOtp) {
		this.userOtp = userOtp;
	}

	public Integer getAddedBy() {
		return addedBy;
	}

	public void setAddedBy(Integer addedBy) {
		this.addedBy = addedBy;
	}

	public Integer getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Banks getBankId() {
		return bankId;
	}

	public void setBankId(Banks bankId) {
		this.bankId = bankId;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public WalletType getWalletType() {
		return walletType;
	}

	public void setWalletType(WalletType walletType) {
		this.walletType = walletType;
	}

	public Subscriber getUserid() {
		return userid;
	}

	public void setUserid(Subscriber userid) {
		this.userid = userid;
	}

	public String getCurrentBalance() {
		return currentBalance;
	}

	public void setCurrentBalance(String currentBalance) {
		this.currentBalance = currentBalance;
	}

	public String getTransactionPin() {
		return transactionPin;
	}

	public void setTransactionPin(String transactionPin) {
		this.transactionPin = transactionPin;
	}

	public boolean isDefaultPinStatus() {
		return defaultPinStatus;
	}

	public void setDefaultPinStatus(boolean defaultPinStatus) {
		this.defaultPinStatus = defaultPinStatus;
	}

	public String getLastTxnId() {
		return lastTxnId;
	}

	public void setLastTxnId(String lastTxnId) {
		this.lastTxnId = lastTxnId;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public Integer getDailyCreditLimit() {
		return dailyCreditLimit;
	}

	public void setDailyCreditLimit(Integer dailyCreditLimit) {
		this.dailyCreditLimit = dailyCreditLimit;
	}

	public Integer getDailyDebitLimit() {
		return dailyDebitLimit;
	}

	public void setDailyDebitLimit(Integer dailyDebitLimit) {
		this.dailyDebitLimit = dailyDebitLimit;
	}
	
	public Integer getDailyTrxCount() {
		return dailyTrxCount;
	}

	public void setDailyTrxCount(Integer dailyTrxCount) {
		this.dailyTrxCount = dailyTrxCount;
	}

	public Integer getMonthlyCreditLimit() {
		return monthlyCreditLimit;
	}

	public void setMonthlyCreditLimit(Integer monthlyCreditLimit) {
		this.monthlyCreditLimit = monthlyCreditLimit;
	}
	
	public Integer getMonthlyDebitLimit() {
		return monthlyDebitLimit;
	}

	public void setMonthlyDebitLimit(Integer monthlyDebitLimit) {
		this.monthlyDebitLimit = monthlyDebitLimit;
	}

	public Integer getMonthlyTrxCount() {
		return monthlyTrxCount;
	}

	public void setMonthlyTrxCount(Integer monthlyTrxCount) {
		this.monthlyTrxCount = monthlyTrxCount;
	}

	public Integer getYearlyCreditLimit() {
		return yearlyCreditLimit;
	}

	public void setYearlyCreditLimit(Integer yearlyCreditLimit) {
		this.yearlyCreditLimit = yearlyCreditLimit;
	}

	public Integer getYearlyDebitLimit() {
		return yearlyDebitLimit;
	}

	public void setYearlyDebitLimit(Integer yearlyDebitLimit) {
		this.yearlyDebitLimit = yearlyDebitLimit;
	}
	public Integer getYearlyTrxCount() {
		return yearlyTrxCount;
	}

	public void setYearlyTrxCount(Integer yearlyTrxCount) {
		this.yearlyTrxCount = yearlyTrxCount;
	}

	@Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof UserWalletDetails)) {
            return false;
        }
        UserWalletDetails other = (UserWalletDetails) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.UserWalletDetails[ id=" + id + " ]";
    }
	
}
