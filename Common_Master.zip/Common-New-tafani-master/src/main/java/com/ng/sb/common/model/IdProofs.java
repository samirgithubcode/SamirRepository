/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Collection;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "IdProofs")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "IdProofs.findAll", query = "SELECT i FROM IdProofs i"),
    @NamedQuery(name = "IdProofs.findById", query = "SELECT i FROM IdProofs i WHERE i.id = :id"),
    @NamedQuery(name = "IdProofs.findByName", query = "SELECT i FROM IdProofs i WHERE i.name = :name"),
    @NamedQuery(name = "IdProofs.findCountByName", query = "SELECT n FROM IdProofs n WHERE n.name = :name"),
    @NamedQuery(name = "IdProofs.findByDesc", query = "SELECT i FROM IdProofs i WHERE i.description = :desc"),
    @NamedQuery(name = "IdProofs.findByHostId", query = "SELECT i FROM IdProofs i WHERE i.hostId = :hostId"),
    @NamedQuery(name = "IdProofs.checknamewithhost", query = "SELECT i FROM IdProofs i WHERE i.hostId = :hostId AND i.name=:name"),
    @NamedQuery(name = "IdProofs.findByHostIdAndIdFor", query = "SELECT i FROM IdProofs i WHERE i.hostId = :hostId AND (i.idFor=:idFor OR i.idFor='ALL')"),
    @NamedQuery(name = "IdProofs.findIdproofsForsubscribersAndHostId", query = "SELECT i FROM IdProofs i WHERE i.id NOT IN (:idProofIds) AND i.hostId=:hostId"),
    @NamedQuery(name = "IdProofs.findIdproofsByListOfApprovedIds", query = "SELECT i FROM IdProofs i WHERE i.id IN (:idProofIds)")
})
public class IdProofs implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
    @Basic(optional = false)
    @Column(name = "name", nullable = false, length = 100)
    private String name;
    @Basic(optional = false)
    @Column(name = "description", nullable = false, length = 100)
    private String description;
    @ManyToOne
	@JoinColumn(name = "hostId",nullable=false)
    private AccountInfo hostId;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idProofId")
    private Collection<SubscriberIdProofs> subscriberIdProofsCollection;
    @OneToMany(mappedBy = "docType")
    private Collection<CustomerCallVerificationInfo> customerCallVerificationInfoCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idProofId")
    private Collection<HostIdProofMapping> hostIdProofMappingCollection;
    @Column(name="idFor")
    private String idFor;
    
    @Column(name="idType")
    private String idType;
    @Column(name="isMandatory")
    private int isMandatory;
    
    @Column(name="weight")
    private String weight;

    @Column(name="validity")
    private int validity;
	public IdProofs() {
    	//default constructor
    }
    public IdProofs(Integer id) {
        this.id = id;
    }

    public IdProofs(Integer id, String name, String desc) {
        this.id = id;
        this.name = name;
        this.description = desc;
    }

    public String getWeight() {
		return weight;
	}

	public void setWeight(String weight) {
		this.weight = weight;
	}




    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesc() {
        return description;
    }

    public void setDesc(String description) {
        this.description = description;
    }

    @XmlTransient
    public Collection<SubscriberIdProofs> getSubscriberIdProofsCollection() {
        return subscriberIdProofsCollection;
    }

    public void setSubscriberIdProofsCollection(Collection<SubscriberIdProofs> subscriberIdProofsCollection) {
        this.subscriberIdProofsCollection = subscriberIdProofsCollection;
    }

    @XmlTransient
    public Collection<CustomerCallVerificationInfo> getCustomerCallVerificationInfoCollection() {
        return customerCallVerificationInfoCollection;
    }

    public void setCustomerCallVerificationInfoCollection(Collection<CustomerCallVerificationInfo> customerCallVerificationInfoCollection) {
        this.customerCallVerificationInfoCollection = customerCallVerificationInfoCollection;
    }

    @XmlTransient
    public Collection<HostIdProofMapping> getHostIdProofMappingCollection() {
        return hostIdProofMappingCollection;
    }

    public void setHostIdProofMappingCollection(Collection<HostIdProofMapping> hostIdProofMappingCollection) {
        this.hostIdProofMappingCollection = hostIdProofMappingCollection;
    }

	public AccountInfo getHostId() {
		return hostId;
	}

	public void setHostId(AccountInfo hostId) {
		this.hostId = hostId;
	}
	
	@Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof IdProofs)) {
            return false;
        }
        IdProofs other = (IdProofs) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.IdProofs[ id=" + id + " ]";
    }

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getIdType() {
		return idType;
	}

	public void setIdType(String idType) {
		this.idType = idType;
	}
	public int getValidity() {
		return validity;
	}
	public void setValidity(int validity) {
		this.validity = validity;
	}
	public int getIsMandatory() {
		return isMandatory;
	}
	public void setIsMandatory(int isMandatory) {
		this.isMandatory = isMandatory;
	}
	public String getIdFor() {
		return idFor;
	}
	public void setIdFor(String idFor) {
		this.idFor = idFor;
	}
    
}
