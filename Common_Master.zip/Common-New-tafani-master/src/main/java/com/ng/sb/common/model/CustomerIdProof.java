package com.ng.sb.common.model;

import java.io.Serializable;
import java.sql.Blob;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;


/**
 * @author abhishek
 *
 */
@Entity
@Table(name="CustomerIdProof")
@XmlRootElement
@NamedQueries({
	@NamedQuery(name="CustomerIdProof.findAll",query="SELECT c FROM CustomerIdProof c")
})
public class CustomerIdProof implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id	
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name="id")
	private Integer id;
	
	@ManyToOne
	@JoinColumn(name="hostId", referencedColumnName="id")
	private AccountInfo hostId;
	
	@ManyToOne
	@JoinColumn(name="subscriberId", referencedColumnName="id")
	private Subscriber subscriberId;
	
	@ManyToOne
	@JoinColumn(name="idProofId", referencedColumnName="id")
	private IdProofs idProofId;
	
	@Basic(optional = false)
	@Column(name="idNo")
	private Integer idNo;
	
	@Basic(optional = false)
	@Column(name="document")
	private transient Blob document;

	public CustomerIdProof(){
		//empty
	}
	
	public CustomerIdProof(Integer id){
		this.id = id;
	}
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public AccountInfo getHostId() {
		return hostId;
	}

	public void setHostId(AccountInfo hostId) {
		this.hostId = hostId;
	}

	public Subscriber getSubscriberId() {
		return subscriberId;
	}

	public void setSubscriberId(Subscriber subscriberId) {
		this.subscriberId = subscriberId;
	}

	public IdProofs getIdProofId() {
		return idProofId;
	}

	public void setIdProofId(IdProofs idProofId) {
		this.idProofId = idProofId;
	}

	public Integer getIdNo() {
		return idNo;
	}

	public void setIdNo(Integer idNo) {
		this.idNo = idNo;
	}

	public Blob getDocument() {
		return document;
	}

	public void setDocument(Blob document) {
		this.document = document;
	}
	
	@Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof Otp)) {
            return false;
        }
        CustomerIdProof other = (CustomerIdProof) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.CustomerIdProof[ id=" + id + " ]";
    }
}
