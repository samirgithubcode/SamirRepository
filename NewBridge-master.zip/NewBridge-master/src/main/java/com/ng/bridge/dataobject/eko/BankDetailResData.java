package com.ng.bridge.dataobject.eko;

public class BankDetailResData {
	private String name;

    private String ifscstatus;

    private String code;

    private String availablechannels;

    private String isverificationavailable;

    public String getName ()
    {
        return name;
    }

    public void setName (String name)
    {
        this.name = name;
    }

    public String getIfscstatus ()
    {
        return ifscstatus;
    }

    public void setIfscstatus (String ifscstatus)
    {
        this.ifscstatus = ifscstatus;
    }

    public String getCode ()
    {
        return code;
    }

    public void setCode (String code)
    {
        this.code = code;
    }

    public String getAvailablechannels ()
    {
        return availablechannels;
    }

    public void setAvailablechannels (String availablechannels)
    {
        this.availablechannels = availablechannels;
    }

	public String getIsverificationavailable() {
		return isverificationavailable;
	}

	public void setIsverificationavailable(String isverificationavailable) {
		this.isverificationavailable = isverificationavailable;
	}

    
    
    
}
