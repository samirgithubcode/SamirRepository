/**
 * 
 */
package com.ng.sb.common.dataobject;

/**
 * @author gaurav
 *
 */
public class CustomerData extends BaseObjectData{
	private static final long serialVersionUID = 1L;
	private Integer walletCode;
	private String customerFirstName;
	private String customerLastName;
	private String walletId;
	private String walletName;
	
	
	public Integer getWalletCode() {
		return walletCode;
	}
	public void setWalletCode(Integer walletCode) {
		this.walletCode = walletCode;
	}
	public String getCustomerFirstName() {
		return customerFirstName;
	}
	public void setCustomerFirstName(String customerFirstName) {
		this.customerFirstName = customerFirstName;
	}
	public String getCustomerLastName() {
		return customerLastName;
	}
	public void setCustomerLastName(String customerLastName) {
		this.customerLastName = customerLastName;
	}
	public String getWalletId() {
		return walletId;
	}
	public void setWalletId(String walletId) {
		this.walletId = walletId;
	}
	public String getWalletName() {
		return walletName;
	}
	public void setWalletName(String walletName) {
		this.walletName = walletName;
	}
	
}
