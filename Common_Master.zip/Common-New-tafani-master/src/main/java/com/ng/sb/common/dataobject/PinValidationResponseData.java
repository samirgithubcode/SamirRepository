package com.ng.sb.common.dataobject;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="PinValidationResponseData")
public class PinValidationResponseData extends PlatformResponseData{
	private static final long serialVersionUID = 1L;
	private Float totalAmount;
	private Float netAmount;
	private Float commission;
	private Float netCommission;
	private Float tax;
	private Float surcharge;
	private String transactionId;
	private List<PinData> pinDataList;
	
	
	public Float getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(Float totalAmount) {
		this.totalAmount = totalAmount;
	}
	public Float getNetAmount() {
		return netAmount;
	}
	public void setNetAmount(Float netAmount) {
		this.netAmount = netAmount;
	}
	public Float getCommission() {
		return commission;
	}
	public void setCommission(Float commission) {
		this.commission = commission;
	}
	public Float getNetCommission() {
		return netCommission;
	}
	public void setNetCommission(Float netCommission) {
		this.netCommission = netCommission;
	}
	public Float getTax() {
		return tax;
	}
	public void setTax(Float tax) {
		this.tax = tax;
	}
	public Float getSurcharge() {
		return surcharge;
	}
	public void setSurcharge(Float surcharge) {
		this.surcharge = surcharge;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public List<PinData> getPinDataList() {
		return pinDataList;
	}
	public void setPinDataList(List<PinData> pinDataList) {
		this.pinDataList = pinDataList;
	}
	
	
	
}
