/**
 * 
 */
package com.ng.transaction.conf;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;

/**
 * @author gopal
 *
 */
@Configuration 
public class DBConfig {

	@Autowired
	private DataSource dataSource;
	
	/*@Bean
	public SessionFactory getSessionFactory() {
		return new LocalSessionFactoryBuilder(dataSource)
		  
		 .addAnnotatedClasses(ProductTransactions.class)
		   .addAnnotatedClasses(PayCardApps.class)
		   .addAnnotatedClasses(CardDetails.class)
		   .addAnnotatedClasses(CardApps.class)
		   .addAnnotatedClasses(CardWallets.class)
		   .addAnnotatedClasses(PayCardAppPartner.class)
		   .addAnnotatedClasses(ProductOrders.class)
		  .addAnnotatedClasses(UserWalletDetails.class)
		  .addAnnotatedClasses(CommissionModel.class)
		  .addAnnotatedClasses(CommissionInfo.class)
		  .addAnnotatedClasses(CommissionProductMapping.class)
		  .addAnnotatedClasses(Packaging.class)
		  .addAnnotatedClasses(PackingGroup.class)
		  .addAnnotatedClasses(AccountSessionInfoSelfCare.class)
		.addAnnotatedClasses(CommissionTemplate.class)
		.addAnnotatedClasses(WalletType.class)
		.addAnnotatedClasses(TransactionCommition.class)
		.addAnnotatedClasses(Categories.class)
		.addAnnotatedClasses(OTACatProviderMapping.class)
		.addAnnotatedClasses(ShippingDetail.class)
		.addAnnotatedClasses(InventoryMgmt.class)
		.addAnnotatedClasses(ProductInventorySummary.class)
		.addAnnotatedClasses(CustomerCallVerificationInfo.class)
		.addAnnotatedClasses(AccountLoginInfo.class)
		.addAnnotatedClasses(CustomerIdProof.class)
		.addAnnotatedClasses(BoxDetails.class)
		.addAnnotatedClasses(MasterVersion.class)
		.addAnnotatedClasses(UserIndvMerchant.class)
		.addAnnotatedClasses(PartnerPreference.class)
		.addAnnotatedClasses(Partner.class)
		.addAnnotatedClasses(TransactionSecureService.class)
		.addAnnotatedClasses(HostSVWalletMapping.class)
		.addAnnotatedClasses(PinHolder.class)
		.addAnnotatedClasses(QueryTransactionInfo.class)
		.addAnnotatedClasses(InventoryOrderHistory.class)
		.addAnnotatedClasses(TicketQueryDetails.class)
		.addAnnotatedClasses(OrderDetailHistory.class)
		.addAnnotatedClasses(SimReplacementDetails.class)
		.addAnnotatedClasses(CustMerchPoolTransaction.class)
		.addAnnotatedClasses(PartnerBankMapping.class)
		.addAnnotatedClasses(HostSVWalletDetailHistory.class)
		.addAnnotatedClasses(UserAccounts.class)
		.addAnnotatedClasses(ComplaintCategoryTypes.class)
		.addAnnotatedClasses(CashInDetail.class)
		.addAnnotatedClasses(HostSVProviderPartnerMapping.class)
		.addAnnotatedClasses(AccountTransaction.class)
		.addAnnotatedClasses(SubscriberIdProofs.class)
		.addAnnotatedClasses(ThirdPartySubsRecipient.class)
		.addAnnotatedClasses(SysAccountType.class)
		.addAnnotatedClasses(MVWalletMapping.class)
		.addAnnotatedClasses(HostSVLongCodeHistory.class)
		.addAnnotatedClasses(PnbDemoCustTransaction.class)
		.addAnnotatedClasses(MerchantTillMapping.class)
		.addAnnotatedClasses(CommFinInstrumentMapping.class)
		.addAnnotatedClasses(AccountInfoMapping.class)
		.addAnnotatedClasses(OTAServiceConfigMapping.class)
		.addAnnotatedClasses(AccountInfo.class)
		.addAnnotatedClasses(UserBiller.class)
		.addAnnotatedClasses(ServiceConfig.class)
		.addAnnotatedClasses(HostSVFspServicesPartnerMapping.class)
		.addAnnotatedClasses(CommissionTemplate.class)
		.addAnnotatedClasses(CustomerWallet.class)
		.addAnnotatedClasses(MerchantAccountLoginInfoHistory.class)
		.addAnnotatedClasses(PortalUrls.class)
		.addAnnotatedClasses(SecurityQuestion.class)
		.addAnnotatedClasses(AccountSessionInfo.class)
		.addAnnotatedClasses(FaqDetails.class)
		.addAnnotatedClasses(RangeDetails.class)
		.addAnnotatedClasses(MerchantIpMapping.class)
		.addAnnotatedClasses(Inventory.class)
		.addAnnotatedClasses(ServiceParamMapping.class)
		.addAnnotatedClasses(SysCustomerCareMenu.class)
		.addAnnotatedClasses(Customer.class)
		.addAnnotatedClasses(HostSVServiceConfigMapping.class)
		.addAnnotatedClasses(OTAWalletHistoryComparison.class)
		.addAnnotatedClasses(InventoryOrder.class)
		.addAnnotatedClasses(SysAccountGroup.class)
		.addAnnotatedClasses(SysMisMenu.class)
		.addAnnotatedClasses(CustomerComplaintInfo.class)
		.addAnnotatedClasses(CategoryProviderMapping.class)
		.addAnnotatedClasses(FinancialInstrument.class)
		.addAnnotatedClasses(CountryCode.class)
		.addAnnotatedClasses(OrderDetail.class)
		.addAnnotatedClasses(OTAWalletMapping.class)
		.addAnnotatedClasses(HostSubVersion.class)
		.addAnnotatedClasses(TransactionLimits.class)
		.addAnnotatedClasses(PinTrnxInfo.class)
		.addAnnotatedClasses(PinManagement.class)
		.addAnnotatedClasses(SimTempBlockHistory.class)
		.addAnnotatedClasses(Products.class)
		.addAnnotatedClasses(ShippingDetailsHistory.class)
		.addAnnotatedClasses(HostSVWalletHistory.class)
		.addAnnotatedClasses(MappingType.class)
		.addAnnotatedClasses(Provider.class)
		.addAnnotatedClasses(State.class)
		.addAnnotatedClasses(CommFspServiceMapping.class)
		.addAnnotatedClasses(Country.class)
		.addAnnotatedClasses(Address.class)
		.addAnnotatedClasses(KYCLevel.class)
		.addAnnotatedClasses(BoxSize.class)
		.addAnnotatedClasses(Subscriber.class)
		.addAnnotatedClasses(OTASubscriber.class)
		.addAnnotatedClasses(OTAManagement.class)
		.addAnnotatedClasses(SelfcareLoginLogs.class)
		.addAnnotatedClasses(TransactionInfo.class)
		.addAnnotatedClasses(MerchantInfo.class)
		.addAnnotatedClasses(CustomerTransaction.class)
		.addAnnotatedClasses(Menu.class)
		.addAnnotatedClasses(SysCustomerCareSubMenu.class)
		.addAnnotatedClasses(Order.class)
		.addAnnotatedClasses(TransactionFundTransfer.class)
		.addAnnotatedClasses(KYCDescriptor.class)
		.addAnnotatedClasses(SysConfigRange.class)
		.addAnnotatedClasses(IdProofs.class)
		.addAnnotatedClasses(HostSVFinInstrumentPartnerMapping.class)
		.addAnnotatedClasses(FSPServices.class)
		.addAnnotatedClasses(CommProvPartMapping.class)
		.addAnnotatedClasses(CustMerchFinInstMapping.class)
		.addAnnotatedClasses(BankBranches.class)
		.addAnnotatedClasses(CustMerchTransaction.class)
		.addAnnotatedClasses(SysConfigRangeHistory.class)
		.addAnnotatedClasses(Banks.class)
		.addAnnotatedClasses(HostAccountInfo.class)
		.addAnnotatedClasses(ComplaintSubCategoryTypes.class)
		.addAnnotatedClasses(SimPermanentBlockHistory.class)
		.addAnnotatedClasses(CustomerCallDetails.class)
		.addAnnotatedClasses(MasterVersionCategory.class)
		.addAnnotatedClasses(HostIdProofMapping.class)
		.addAnnotatedClasses(PortalRegistration.class)
		.addAnnotatedClasses(PartnerFinInstrumentMapping.class)
		.addAnnotatedClasses(WalletTransaction.class)
		.addAnnotatedClasses(OTACustomer.class)
		.addAnnotatedClasses(PinTransaction.class)
		.addAnnotatedClasses(POCode.class)
		.addAnnotatedClasses(PartnerProviderMapping.class)
		.addAnnotatedClasses(MerchantDetail.class)
		.addAnnotatedClasses(ShippingInfo.class)
		.addAnnotatedClasses(ShippedProduct.class)
		.addAnnotatedClasses(TicketQueryAssignmentHistory.class)
		.addAnnotatedClasses(Account.class)
		.addAnnotatedClasses(Denomination.class)
		.addAnnotatedClasses(TicketQueryAssignmentInfo.class)
		.addAnnotatedClasses(SubscriberWallet.class)
		.addAnnotatedClasses(SysMisSubMenu.class)
		.addAnnotatedClasses(ThirdPartySubscriber.class)
		.addAnnotatedClasses(InventorySummary.class)
		.addAnnotatedClasses(MerchantAccountInfoHistory.class)
		.addAnnotatedClasses(ShippingDetails.class)
		.addAnnotatedClasses(PinTemplate.class)
		.addAnnotatedClasses(PartnerFspServiceMapping.class)
		.addAnnotatedClasses(Otp.class)

		   .buildSessionFactory();
	}
		   
	
	@Bean
	public HibernateTemplate hibernateTemplate() 
	{
		return new HibernateTemplate(getSessionFactory());
	}
	
	@Bean
	@Autowired
	public HibernateTransactionManager transactionManager(SessionFactory sessionFactory) 
	{
	  
	      HibernateTransactionManager txManager = new HibernateTransactionManager();
	      txManager.setSessionFactory(sessionFactory);
	 
	      return txManager;
	}*/
	
	@Bean 
	public LocalContainerEntityManagerFactoryBean entityManagerFactory() 
	{ 
		LocalContainerEntityManagerFactoryBean entityManagerFactory = new LocalContainerEntityManagerFactoryBean(); 
		entityManagerFactory.setDataSource(dataSource); 
		entityManagerFactory.setPackagesToScan("com.ng.transaction", "com.ng.sb"); 
		
		
		HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter(); 
		entityManagerFactory.setJpaVendorAdapter(vendorAdapter); 
		return entityManagerFactory; 
	} 
	
	@Bean 
	public JpaTransactionManager transactionManager() 
	{ 
		JpaTransactionManager transactionManager = new JpaTransactionManager(); 
		transactionManager.setEntityManagerFactory(entityManagerFactory().getObject()); 
		return transactionManager; 
	}
}