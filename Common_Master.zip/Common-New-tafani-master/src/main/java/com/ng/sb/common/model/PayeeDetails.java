/**
 * 
 */
package com.ng.sb.common.model;

import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Type;

import com.ng.sb.common.dataobject.ValidationBean;

/**
 * @author gopal
 *
 */
@Entity
@Table(name = "overlay_payee_details")
@NamedQueries({
    @NamedQuery(name = "PayeeDetails.findByCustId", query = "SELECT pd FROM PayeeDetails pd WHERE pd.customerId=:customerId "),
    @NamedQuery(name = "PayeeDetails.findByMsisdn", query = "SELECT pd FROM PayeeDetails pd WHERE pd.customerMsisdn=:customerMsisdn "),
    @NamedQuery(name = "PayeeDetails.findByAccountId", query = "SELECT pd FROM PayeeDetails pd WHERE pd.accountId=:accountId ")
})
public class PayeeDetails implements ValidationBean {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "id")
	private Integer id;
	
	@Column(name = "customerId")
	private String customerId;
	
	@Column(name = "msisdn")
	private Long customerMsisdn;
	
	@Column(name = "accountId")
	private String accountId;

	@Column(name = "nickName")
	private String payeeNickName;
	
	@Column(name = "accountName")
	private String accountName;
	
	@Column(name = "accountNumber")
	private Long accountNumber;
	
	@Column(name = "ifscCode")
	private String ifscCode;
	
	@Column(name = "mmid")
	private String accountMmid;
	
	@Column(name = "mobileNumber")
	private String payeeMobileNumber;
	
	@Column(name = "walletTypeId")
	private Integer walletTypeId;
	
	@Column(name = "walletNumber")
	private Long walletNumber;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Type(type="date")
	@Column(name = "addedOn")
	private Date addedOn;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Type(type="date")
	@Column(name = "modifiedOn")
	private Date modifiedOn;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public Long getCustomerMsisdn() {
		return customerMsisdn;
	}

	public void setCustomerMsisdn(Long customerMsisdn) {
		this.customerMsisdn = customerMsisdn;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getPayeeNickName() {
		return payeeNickName;
	}

	public void setPayeeNickName(String payeeNickName) {
		this.payeeNickName = payeeNickName;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public Long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getIfscCode() {
		return ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	public String getAccountMmid() {
		return accountMmid;
	}

	public void setAccountMmid(String accountMmid) {
		this.accountMmid = accountMmid;
	}

	public String getPayeeMobileNumber() {
		return payeeMobileNumber;
	}

	public void setPayeeMobileNumber(String payeeMobileNumber) {
		this.payeeMobileNumber = payeeMobileNumber;
	}

	public Integer getWalletTypeId() {
		return walletTypeId;
	}

	public void setWalletTypeId(Integer walletTypeId) {
		this.walletTypeId = walletTypeId;
	}

	public Long getWalletNumber() {
		return walletNumber;
	}

	public void setWalletNumber(Long walletNumber) {
		this.walletNumber = walletNumber;
	}

	public Date getAddedOn() {
		return addedOn;
	}

	public void setAddedOn(Date addedOn) {
		this.addedOn = addedOn;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	
	
}
