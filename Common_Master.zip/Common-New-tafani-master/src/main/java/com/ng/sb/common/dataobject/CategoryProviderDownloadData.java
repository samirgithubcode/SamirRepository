package com.ng.sb.common.dataobject;

import java.util.List;

public class CategoryProviderDownloadData extends BaseObjectData{
	private static final long serialVersionUID = 1L;
	
	private List<CategoryInfo> categoryInfos;
	private List<ProviderInfo> providerInfos;
	
	
	public List<CategoryInfo> getCategoryInfos() {
		return categoryInfos;
	}
	public void setCategoryInfos(List<CategoryInfo> categoryInfos) {
		this.categoryInfos = categoryInfos;
	}
	public List<ProviderInfo> getProviderInfos() {
		return providerInfos;
	}
	public void setProviderInfos(List<ProviderInfo> providerInfos) {
		this.providerInfos = providerInfos;
	}


	
	
	
	
}
