package com.ng.transaction.util;

public class Constants {
	public static final String BASE_URL = "https://sbipay.com /upi";
	public static final String CUSTOMER_REGISTRATION_ENDPOINT = "/api/registerPreAuthUser";
	public static final String PRE_AUTH_PAY_ENDPOINT = "/api/preAuthPayWeb";
	public static final String CHECK_VPA_ENDPOINT = "/api/checkVpaWeb";
	public static final String TRANSACTION_HISTORY_ENDPOINT = "/api/tranHistWeb";
	public static final String TRANSACTION_STATUS_ENDPOINT = "/api/tranStatusWeb";

	public static final Integer PSP_ID = 0;	// SBI to give
	public static final String PSP_REF_NO = "";	// SBI to give
	
	public static final String DEVICE_ID = "overlay";
	public static final String DEVICE_TYPE = "feature phone";
	public static final String APPLICATION_NAME = "overlay";
	public static final String PREFERRED_FLAG = "T";

	
	public static final String DUMMY_STRING = "NextGen"; // NA
	
}
