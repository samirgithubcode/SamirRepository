/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "sys_config_range")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "SysConfigRange.findAll", query = "SELECT s FROM SysConfigRange s"),
    @NamedQuery(name = "SysConfigRange.findById", query = "SELECT s FROM SysConfigRange s WHERE s.id = :id"),
    @NamedQuery(name = "SysConfigRange.findByMin", query = "SELECT s FROM SysConfigRange s WHERE s.min = :min"),
    @NamedQuery(name = "SysConfigRange.findByMax", query = "SELECT s FROM SysConfigRange s WHERE s.max = :max"),
    @NamedQuery(name = "SysConfigRange.findByValue", query = "SELECT s FROM SysConfigRange s WHERE s.value = :value"),
    @NamedQuery(name = "SysConfigRange.findByType", query = "SELECT s FROM SysConfigRange s WHERE s.type = :type"),
    @NamedQuery(name = "SysConfigRange.findByConfigId", query = "SELECT s FROM SysConfigRange s where s.sysCommConfigId=:configId")})
public class SysConfigRange implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
   
    @Column(name = "max", precision = 12)
    private Float max;
    @Column(name = "min", precision = 12)
    private Float min;
    @Column(name = "value", precision = 12)
    private Float value;
    @Column(name = "type", length = 5)
    private String type;
    @JoinColumn(name = "sysCommConfigId", referencedColumnName = "id")
    @ManyToOne
    private CommissionTemplate sysCommConfigId;

    public SysConfigRange() {
    	//default constructor
    }

    public SysConfigRange(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

   

    public Float getMax() {
        return max;
    }

    public void setMax(Float max) {
        this.max = max;
    }
    
    public Float getMin() {
        return min;
    }

    public void setMin(Float min) {
        this.min = min;
    }

    public Float getValue() {
        return value;
    }

    public void setValue(Float value) {
        this.value = value;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public CommissionTemplate getSysCommConfigId() {
        return sysCommConfigId;
    }

    public void setSysCommConfigId(CommissionTemplate sysCommConfigId) {
        this.sysCommConfigId = sysCommConfigId;
    }


    @Override
    public String toString() {
        return "com.ng.sb.common.model.SysConfigRange[ id=" + id + " ]";
    }
    
    
    @Override
    public boolean equals(Object object) {
        if (!(object instanceof SysConfigRange)) {
            return false;
        }
        SysConfigRange other = (SysConfigRange) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }
    
   

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }
    
}
