/**
 * 
 */
package com.ng.sb.common.exception;

public class InventoryDetailsException  extends RuntimeException {
	private static final long serialVersionUID = 1L;
	
	public InventoryDetailsException(String message){
		super(message);
	}
}