package com.ng.bridge.dataobject.eko;

public class GetCustomerRes {
	private String responseTypeId;

    private String message;

    private String responseStatusId;

    private String status;

    private GetCustomerResData data;

  
    public GetCustomerResData getData() {
		return data;
	}

	public void setData(GetCustomerResData data) {
		this.data = data;
	}

    public String getResponseStatusId ()
    {
        return responseStatusId;
    }

    public void setResponseStatusId (String responseStatusId)
    {
        this.responseStatusId = responseStatusId;
    }

    public String getMessage ()
    {
        return message;
    }

    public void setMessage (String message)
    {
        this.message = message;
    }
    public String getStatus ()
    {
        return status;
    }
    public String getResponseTypeId ()
    {
        return responseTypeId;
    }

    public void setResponseTypeId (String responseTypeId)
    {
        this.responseTypeId = responseTypeId;
    }
    public void setStatus (String status)
    {
        this.status = status;
    }

	

	

    
    
}
