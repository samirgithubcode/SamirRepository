package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "api_services")
@NamedQueries({
	@NamedQuery(name="ApiServices.findAll", query="SELECT a FROM ApiServices a Where a.status=1"),

    })
public class ApiServices implements Serializable {
    private static final long serialVersionUID = 1L;
   
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
    
    @Column(name = "serviceName")
    private String serviceName;
    
    @Column(name = "serviceURI")
    private String serviceURI;
    
    @Column(name = "serviceCategory")
    private String serviceCategory;
    
    @Column(name = "addedOn")
    @Temporal(TemporalType.DATE)
    private Date addedOn;
    
    @Column(name = "status" ,columnDefinition = "tinyint default true")
    private boolean status=true;
    
    @Column(name = "comments")
    private String comments;
    
    @Column(name = "subcategories")
    private String subcategories;
    
    /**
	 * @return the subcategories
	 */
	public String getSubcategories() {
		return subcategories;
	}

	/**
	 * @param subcategories the subcategories to set
	 */
	public void setSubcategories(String subcategories) {
		this.subcategories = subcategories;
	}

	ApiServices(){
    	//default
    }
    
    public ApiServices(Integer id) {
		this.id=id;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getServiceURI() {
		return serviceURI;
	}

	public void setServiceURI(String serviceURI) {
		this.serviceURI = serviceURI;
	}

	public String getServiceCategory() {
		return serviceCategory;
	}

	public void setServiceCategory(String serviceCategory) {
		this.serviceCategory = serviceCategory;
	}

	public Date getAddedOn() {
		return addedOn;
	}

	public void setAddedOn(Date addedOn) {
		this.addedOn = addedOn;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	

}
