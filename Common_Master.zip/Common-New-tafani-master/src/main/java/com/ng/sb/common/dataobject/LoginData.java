package com.ng.sb.common.dataobject;

import java.util.Date;
import java.util.List;
import java.util.Map;

public class LoginData  extends BaseObjectData{
	private static final long serialVersionUID = 1L;
	
	private List<MenuData> menuDatas;
	private Integer subAccountType;
	private String accountType;
	private Integer accountTypeWeightage;
	private String subAccountTypeName;
	private String username;
	private String userName;
	private Integer daystoexpire;
	private String password;
	private List<MenuDetails> menuDetails;
	private transient Map accountTypeMap;
	private int invalidCount;
	private String statusMessage;
	private String view;
	private int accountTypeId;
	private int accountId;
	private boolean sessionInfo;
	private Date currentDateTime;
	private int groupId;	
	private String groupCode;
	private String hostCode;
	private int groupWeight;
	private boolean firstTimeLogin;
	private Integer userLoginId;
	private String parentDetails;
	private Integer parentId;
	private Integer hostId;
	private String contactPersonName;
	private String typeCode;
	private String key;
	private String tokenId;
	private String subscriberMobNo;
	private String serialNumber;
	private String sessionId;
	private Integer loginType;
	private Integer merchantId;
	private String merchantUserId;
	private Integer userTypeId;
	
	private boolean loginStatus;
	private String merchantType;
	private boolean accountstatus;
	
	private String profileImageName;
	private String merchantName;
	private String userRole;
	public Integer getUserTypeId() {
		return userTypeId;
	}
	public void setUserTypeId(Integer userTypeId) {
		this.userTypeId = userTypeId;
	}
	public String getUserRole() {
		return userRole;
	}
	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}
	public String getMerchantName() {
		return merchantName;
	}
	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}
	public Integer getLoginType() {
		return loginType;
	}
	public void setLoginType(Integer loginType) {
		this.loginType = loginType;
	}
	
	public String getMerchantUserId() {
		return merchantUserId;
	}
	public void setMerchantUserId(String string) {
		this.merchantUserId = string;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public String getProfileImageName() {
		return profileImageName;
	}
	public void setProfileImageName(String profileImageName) {
		this.profileImageName = profileImageName;
	}
	public boolean isAccountstatus() {
		return accountstatus;
	}
	public void setAccountstatus(boolean accountstatus) {
		this.accountstatus = accountstatus;
	}
	
	
	
	public Integer getDaystoexpire() {
		return daystoexpire;
	}
	public void setDaystoexpire(Integer daystoexpire) {
		this.daystoexpire = daystoexpire;
	}
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getSubscriberMobNo() {
		return subscriberMobNo;
	}
	public void setSubscriberMobNo(String subscriberMobNo) {
		this.subscriberMobNo = subscriberMobNo;
	}
	public String getTokenId() {
		return tokenId;
	}
	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getTypeCode() {
		return typeCode;
	}
	public void setTypeCode(String typeCode) {
		this.typeCode = typeCode;
	}
	public String getHostCode() {
		return hostCode;
	}
	public void setHostCode(String hostCode) {
		this.hostCode = hostCode;
	}
	public String getContactPersonName() {
		return contactPersonName;
	}
	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}
	public Integer getParentId() {
		return parentId;
	}
	public void setParentId(Integer parentId) {
		this.parentId = parentId;
	}
	public Integer getHostId() {
		return hostId;
	}
	public void setHostId(Integer hostId) {
		this.hostId = hostId;
	}
	public String getParentDetails() {
		return parentDetails;
	}
	public void setParentDetails(String parentDetails) {
		this.parentDetails = parentDetails;
	}
	public Integer getUserLoginId() {
		return userLoginId;
	}
	public void setUserLoginId(Integer userLoginId) {
		this.userLoginId = userLoginId;
	}
	public boolean isFirstTimeLogin() {
		return firstTimeLogin;
	}
	public void setFirstTimeLogin(boolean firstTimeLogin) {
		this.firstTimeLogin = firstTimeLogin;
	}
	public Integer getAccountTypeWeightage() {
		return accountTypeWeightage;
	}
	public void setAccountTypeWeightage(Integer accountTypeWeightage) {
		this.accountTypeWeightage = accountTypeWeightage;
	}
	public int getGroupWeight() {
		return groupWeight;
	}
	public void setGroupWeight(int groupWeight) {
		this.groupWeight = groupWeight;
	}
	public List<MenuData> getMenuDatas() {
		return menuDatas;
	}
	public void setMenuDatas(List<MenuData> menuDatas) {
		this.menuDatas = menuDatas;
	}
	public Integer getSubAccountType() {
		return subAccountType;
	}
	public void setSubAccountType(Integer subAccountType) {
		this.subAccountType = subAccountType;
	}
	public Map getAccountTypeMap() {
		return accountTypeMap;
	}
	public void setAccountTypeMap(Map accountTypeMap) {
		this.accountTypeMap = accountTypeMap;
	}
	public List<MenuDetails> getMenuDetails() {
		return menuDetails;
	}
	public void setMenuDetails(List<MenuDetails> menuDetails) {
		this.menuDetails = menuDetails;
	}
	public String getSubAccountTypeName() {
		return subAccountTypeName;
	}
	public void setSubAccountTypeName(String subAccountTypeName) {
		this.subAccountTypeName = subAccountTypeName;
	}
	public int getGroupId() {
		return groupId;
	}
	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}
	public Date getCurrentDateTime() {
		return currentDateTime;
	}
	public void setCurrentDateTime(Date currentDateTime) {
		this.currentDateTime = currentDateTime;
	}
	public boolean isSessionInfo() {
		return sessionInfo;
	}
	public void setSessionInfo(boolean sessionInfo) {
		this.sessionInfo = sessionInfo;
	}
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public int getAccountTypeId() {
		return accountTypeId;
	}
	public void setAccountTypeId(int accountTypeId) {
		this.accountTypeId = accountTypeId;
	}
	
	
	
	public String getSessionId() {
		return sessionId;
	}
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
	public String getView() {
		return view;
	}
	public void setView(String view) {
		this.view = view;
	}
	public String getStatusMessage() {
		return statusMessage;
	}
	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}
	
	public int getInvalidCount() {
		return invalidCount;
	}
	public void setInvalidCount(int invalidCount) {
		this.invalidCount = invalidCount;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getGroupCode() {
		return groupCode;
	}
	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}
	public boolean isLoginStatus() {
		return loginStatus;
	}
	public void setLoginStatus(boolean loginStatus) {
		this.loginStatus = loginStatus;
	}
	@Override
	public String toString() {
		return "LoginData [menuDatas=" + menuDatas + ", subAccountType="
				+ subAccountType + ", accountType=" + accountType
				+ ", accountTypeWeightage=" + accountTypeWeightage
				+ ", subAccountTypeName=" + subAccountTypeName + ", username="
				+ username + ", userName=" + userName + ", password="
				+ password + ", menuDetails=" + menuDetails + ", invalidCount="
				+ invalidCount + ", statusMessage=" + statusMessage + ", view="
				+ view + ", accountTypeId=" + accountTypeId + ", accountId="
				+ accountId + ", sessionInfo=" + sessionInfo
				+ ", currentDateTime=" + currentDateTime + ", groupId="
				+ groupId + ", groupCode=" + groupCode + ", hostCode="
				+ hostCode + ", groupWeight=" + groupWeight
				+ ", firstTimeLogin=" + firstTimeLogin + ", userLoginId="
				+ userLoginId + ", parentDetails=" + parentDetails
				+ ", parentId=" + parentId + ", hostId=" + hostId
				+ ", contactPersonName=" + contactPersonName + ", typeCode="
				+ typeCode + ", key=" + key + ", tokenId=" + tokenId
				+ ", subscriberMobNo=" + subscriberMobNo + ", serialNumber="
				+ serialNumber + ", sessionId=" + sessionId + ", loginStatus="
				+ loginStatus + ", accountstatus=" + accountstatus
				+ ", daystoexpire=" + daystoexpire + "]";
	}
	public Integer getMerchantId() {
		return merchantId;
	}
	public void setMerchantId(Integer merchantId) {
		this.merchantId = merchantId;
	}
	public String getMerchantType() {
		return merchantType;
	}
	public void setMerchantType(String merchantType) {
		this.merchantType = merchantType;
	}
	
	
}