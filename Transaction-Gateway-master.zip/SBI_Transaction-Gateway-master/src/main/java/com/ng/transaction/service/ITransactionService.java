package com.ng.transaction.service;

import com.ng.sb.common.dataobject.BridgeDataObject;
import com.ng.sb.common.dataobject.CustomerAccountData;
import com.ng.sb.common.dataobject.TransactionData;
import com.ng.sb.common.exception.DecryptionException;
import com.ng.sb.common.exception.NoValidCustomerException;
import com.ng.sb.common.exception.ServiceMappingException;
import com.ng.sb.common.model.TransactionInfo;
import com.ng.sb.common.service.IService;

public interface ITransactionService extends IService{
	
	public TransactionInfo saveTransactionInfo(BridgeDataObject bridgeDataObject);
	public void requestFacade(TransactionData transactionData) throws DecryptionException,NoValidCustomerException,ServiceMappingException;
	public void requestFacadeWithoutEncryption(TransactionData transactionData) throws DecryptionException,NoValidCustomerException,ServiceMappingException;
	public CustomerAccountData getCustomerAccountInfo(TransactionData transactionData);
	
	public BridgeDataObject callService(BridgeDataObject bridgeDataObject) throws Exception;
	
}
