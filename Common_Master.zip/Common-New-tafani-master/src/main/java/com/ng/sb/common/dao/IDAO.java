/**
 * 
 */
package com.ng.sb.common.dao;

import java.util.List;

import com.ng.sb.common.model.AccountInfo;
import com.ng.sb.common.model.SysAccountGroup;


/**
 * @author gaurav
 *
 */
public interface IDAO 
{
	public AccountInfo getAccountInfoById(Integer id);
	public SysAccountGroup getSysAccountGroupById(int id);
	public List<AccountInfo> getAccountInfoByGroupId(Integer accountGroupId);

	public boolean persistObject(Object entity);

}
