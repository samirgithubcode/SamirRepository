package com.ng.sc.service;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Component;

import com.ng.sb.common.dataobject.LoginData;
import com.ng.sc.service.ISelfCareService;
/**
 * 
 * @author Satyendra
 *
 */

@Component
public interface IScSessionService extends ISelfCareService{
	public LoginData getSessionInfo(HttpSession session) throws Exception;

}
