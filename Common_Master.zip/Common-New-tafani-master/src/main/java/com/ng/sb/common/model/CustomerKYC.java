package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;
/**
*
* @author Simran
* 
* The persistent class for the customer KYC database table.
*/
@Entity
@Table(name = "customer_kyc")
@XmlRootElement
@NamedQueries({
	@NamedQuery(name = "CustomerKYC.findnameandweightage", query = "SELECT c FROM CustomerKYC c  ORDER BY c.order ")
})

public class CustomerKYC implements Serializable {
	    private static final long serialVersionUID = 1L;
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Basic(optional = false)
	    @Column(name = "id")
	    private Integer id;
	    @Column(name = "name")
	    private String name;
	    @Column(name = "weightage")
	    private Integer weightage;
	    @Column(name = "order")
	    private String order;
		@Column(name = "status")
	    private Integer status;
	    @Column(name = "start_date")
	    @Temporal(TemporalType.DATE)
	    private Date startDate;
	    @Column(name = "end_date")
	    @Temporal(TemporalType.DATE)
	    private Date endDate;
		@Column(name = "created_on")
	    @Temporal(TemporalType.TIMESTAMP)
	    private Date createDate;
	    @Column(name = "created_by") 
	    private Integer createdBy;
	    @Column(name = "updated_on")
	    @Temporal(TemporalType.TIMESTAMP)
	    private Date modifiedDate;
	    @Column(name = "updated_by") 
	    private Integer updatedBy;
	    
	    public CustomerKYC() {
	 		//default
	 	}
	    public CustomerKYC(Integer id) {
	        this.id = id;
	    }
	 
		public void setStartDate(Date startDate) {
			this.startDate = startDate;
		}
		public Date getEndDate() {
			return endDate;
		}
		public void setEndDate(Date endDate) {
			this.endDate = endDate;
		}
	
		public Integer getId() {
			return id;
		}

		public void setId(Integer id) {
			this.id = id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

	

		public Date getCreateDate() {
			return createDate;
		}

		public void setCreateDate(Date createDate) {
			this.createDate = createDate;
		}

		public Integer getCreatedBy() {
			return createdBy;
		}

		public void setCreatedBy(Integer createdBy) {
			this.createdBy = createdBy;
		}

		public Date getModifiedDate() {
			return modifiedDate;
		}

		public void setModifiedDate(Date modifiedDate) {
			this.modifiedDate = modifiedDate;
		}

		public Integer getUpdatedBy() {
			return updatedBy;
		}

		public void setUpdatedBy(Integer updatedBy) {
			this.updatedBy = updatedBy;
		}


		@Override
	    public int hashCode() {
	        int hash = 0;
	        hash += (id != null ? id.hashCode() : 0);
	        return hash;
	    }

	    @Override
	    public boolean equals(Object object) {
	    	boolean check=true;
	    	if(object!=null){
	        if (!(object instanceof CustomerKYC)) {
	        	check= false;
	        }
	        CustomerKYC other = (CustomerKYC) object;
	        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
	        	check= false;
	        }
	    	}
	        return check;
	    }

	    @Override
	    public String toString() {
	        return "com.ng.sb.common.model.CustomerKYC[ id=" + id + " ]";
	    }
	
		public Date getStartDate() {
			return startDate;
		}
		public Integer getWeightage() {
			return weightage;
		}
		public void setWeightage(Integer weightage) {
			this.weightage = weightage;
		}
		public String getOrder() {
			return order;
		}
		public void setOrder(String order) {
			this.order = order;
		}
		public Integer getStatus() {
			return status;
		}
		public void setStatus(Integer status) {
			this.status = status;
		}
		
}
