/**
 * 
 */
package com.ng.pnb.invoker.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author gopal
 *
 */
public class ISOUtils {

	private ISOUtils(){}
	
	public static String getFinalPaddedData(String dataToPadd, boolean isLeftPadding, int fieldLength, String paddingWith)
	{
		try{
			if(dataToPadd == null)
				dataToPadd = "";
			
		int paddingLengthRequired = fieldLength - dataToPadd.length();
		
			for(int i =0; i < paddingLengthRequired; i++)
			{
				if(isLeftPadding)
					dataToPadd = paddingWith+dataToPadd;
				else
					dataToPadd = dataToPadd+paddingWith;
			}
			
			return dataToPadd;
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	public static String dateToString(Date dateObject, String patterToParse) 
	{
		DateFormat df = new SimpleDateFormat(patterToParse);
		
		return df.format(dateObject);
	}
}
