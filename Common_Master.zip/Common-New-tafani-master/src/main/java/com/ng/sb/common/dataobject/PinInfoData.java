package com.ng.sb.common.dataobject;

public class PinInfoData extends BaseObjectData  {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long pinSerialNumber;
	private Integer denominationValue; 
	private String pinStatus;
	private Float pinCommission;
	private Float pinNetAmount;
	
	public Long getPinSerialNumber() {
		return pinSerialNumber;
	}
	public void setPinSerialNumber(Long pinSerialNumber) {
		this.pinSerialNumber = pinSerialNumber;
	}
	public Integer getDenominationValue() {
		return denominationValue;
	}
	public void setDenominationValue(Integer denominationValue) {
		this.denominationValue = denominationValue;
	}
	public String getPinStatus() {
		return pinStatus;
	}
	public void setPinStatus(String pinStatus) {
		this.pinStatus = pinStatus;
	}
	public Float getPinCommission() {
		return pinCommission;
	}
	public void setPinCommission(Float pinCommission) {
		this.pinCommission = pinCommission;
	}
	public Float getPinNetAmount() {
		return pinNetAmount;
	}
	public void setPinNetAmount(Float pinNetAmount) {
		this.pinNetAmount = pinNetAmount;
	}
	
}
