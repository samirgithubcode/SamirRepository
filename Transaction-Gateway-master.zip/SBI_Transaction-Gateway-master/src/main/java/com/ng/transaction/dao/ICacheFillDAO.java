package com.ng.transaction.dao;

import java.util.List;

import com.ng.sb.common.model.Categories;
import com.ng.sb.common.model.FSPServices;
import com.ng.sb.common.model.FinancialInstrument;
import com.ng.sb.common.model.HostSubVersion;
import com.ng.sb.common.model.MasterVersion;
import com.ng.sb.common.model.Partner;
import com.ng.sb.common.model.PartnerPreference;
import com.ng.sb.common.model.ServiceConfig;

public interface ICacheFillDAO {
	public List<HostSubVersion> getHostSubVersionList() throws Exception;
	public List<Categories> getCategoriesList() throws Exception;
	public List<FSPServices> getFSPServicesList() throws Exception;
	public List<Partner> getPartnerList() throws Exception;
	public List<FinancialInstrument> getFinancialInstrument() throws Exception;
	public List<MasterVersion> getMasterVersion() throws Exception;
	public PartnerPreference getPartnerPreferenceByHostVersion(Integer hostSubVersion) throws Exception;
	public List<ServiceConfig> getServiceConfigList() throws Exception;    // Gaurav
}
