package com.ng.sb.common.dataobject;

import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.stereotype.Service;
import org.springframework.web.context.annotation.ApplicationScope;
@ApplicationScope
@PropertySource("classpath:SystemProperties.properties")
@Service
@Qualifier(value = "platformLoginData")
public class PlatformLoginData extends BasePlatformLogin {

	@Value("${voucherUrl}")
	private String voucherUrl;
	
	@Value("${MERCHANT_ONBOARDING_ISSUANCE}")
	private String merchantIssuanceUrl;
	
	@Value("${RefundDays}")
	private String refundDays;

	@Value("${CLOUD_UPLOAD_KYC_IMAGE}")
	private String downloadKycUrl;
	
	@Value("${DOCUMENT_PATH}")
	private String documentUploadPath;

	@Value("${EKO_VERIFY_CUST_URL}")
	private String ekoVerifyCustUrl;

	@Value("${SUCCESS_MESSAGE}")
	private String successMessage;
	@Value("${SEIssuance_List_Url}")
	private String sEIssuanceListUrl;

	@Value("${SUCCESS_CODE}")
	private String successCode;
	
	

	@Value("${SUCCESS_DESCRIPTION}")
	private String successDescription;

	@Value("${PARTIAL_SUCCESS_MESSAGE}")
	private String partialSuccessMessage;

	@Value("${PARTIAL_SUCCESS_CODE}")
	private String partialSuccessCode;

	@Value("${PARTIAL_SUCCESS_DESCRIPTION}")
	private String partialSuccessDescription;

	@Value("${KEY_FAILURE_MESSAGE}")
	private String keyFailureMessage;

	@Value("${KEY_FAILURE_CODE}")
	private String keyFailureCode;

	@Value("${KEY_FAILURE_DESCRIPTION}")
	private String keyFailureDescription;

	@Value("${IP_FAILURE_MESSAGE}")
	private String ipFailureMessage;

	@Value("${IP_FAILURE_CODE}")
	private String ipFailureCode;

	@Value("${IP_FAILURE_DESCRIPTION}")
	private String ipFailureDescription;

	@Value("${EXPIRED_PIN_MESSAGE}")
	private String expiredPinMessage;

	@Value("${EXPIRED_PIN_CODE}")
	private String expiredPinCode;

	@Value("${EXPIRED_FAILURE_DESCRIPTION}")
	private String expiredPinDescription;

	@Value("${INTRANSIT_PIN_MESSAGE}")
	private String intransitPinMessage;

	@Value("${INTRANSIT_PIN_CODE}")
	private String intransitPinCode;

	@Value("${INTRANSIT_FAILURE_DESCRIPTION}")
	private String intransitPinDescription;

	@Value("${USED_PIN_MESSAGE}")
	private String usedPinMessage;

	@Value("${USED_PIN_CODE}")
	private String usedPinCode;

	@Value("${USED_FAILURE_DESCRIPTION}")
	private String usedPinDescription;

	@Value("${TOTAL_FAILURE_MESSAGE}")
	private String totalFailureMessage;

	@Value("${PIN_FAILURE_MESSAGE}")
	private String pinFailureMessage;

	@Value("${PIN_FAILURE_CODE}")
	private String pinFailureCode;
	
	@Value("${MAX_ROWS_MIS}")
	private String maxRowsMis;
	
	@Value("${PIN_FAILURE_DESCRIPTION}")
	private String pinFailureDescription;

	@Value("${PORTAL_FAILURE_MESSAGE}")
	private String portalFailureMessage;

	@Value("${PORTAL_FAILURE_CODE}")
	private String portalFailureCode;

	@Value("${PORTAL_FAILURE_DESCRIPTION}")
	private String portalFailureDescription;

	@Value("${MOBILE_NUMBER_LENGTH}")
	private Integer mobileNumberLength;

	@Value("${PNB_SOCKET_IP}")
	private String pnbSocketIP;

	@Value("${PNB_SOCKET_PORT}")
	private Integer pnbSocketPort;

	@Value("${EN_VAL_URL}")
	private String euroNetValURL;
	@Value("${INVENTORY_FILE_LOCATION}")
	private String inventoryUploadFileLocation;

	@Value("${EN_TXN_URL}")
	private String euroNetTxnURL;

	@Value("${EN_TXN_STATUS_URL}")
	private String euroNetTxnStatusURL;

	@Value("${EN_USER_NAME}")
	private String euroNetUserName;

	@Value("${EN_USER_PWD}")
	private String euroNetPassword;

	@Value("${EN_MERC_CODE}")
	private String euroNetMerchantCode;

	@Value("${EN_PAYM_PROV}")
	private String euroNetPaymentProvider;

	@Value("${EN_PAYM_MOD}")
	private String euroNetPaymentMode;

	@Value("${EN_CHAN_CODE}")
	private String euroNetChannelCode;

	@Value("${EN_STOR_CODE}")
	private String euroNetStoreCode;

	@Value("${EN_TERM_CODE}")
	private String euroNetTermCode;

	@Value("${EN_CUST_ID}")
	private String euroNetCustomerId;

	@Value("${EN_TC_FLAG}")
	private String euroNetTCFlag;

	@Value("${deploymentFor}")
	private String deploymentFor;

	@Value("${agent_a/c_type_id}")
	private String accountTypeid;

	@Value("${hostId}")
	private String hostId;
	
	@Value("${distributorId}")
	private String distributorId;

	@Value("${subdistributorId}")
	private String subdistributorId;

	@Value("${agentId}")
	private String agentId;

	@Value("${accountId}")
	private String accountId;

	@Value("${countryCode}")
	private String countryCode;

	@Value("${TAFANI_PROJECT_ID}")
	private String tafaniProjectId;

	@Value("${STORED_VALUE_APPLICATION1}")
	private String storedValueApplication1;

	@Value("${STORED_VALUE_APPLICATION2}")
	private String storedValueApplication2;

	@Value("${STORED_VALUE_APPLICATION3}")
	private String storedValueApplication3;

	@Value("${STORED_VALUE_APPLICATION4}")
	private String storedValueApplication4;

	@Value("${STORED_WALLET_APPLICATION1}")
	private String storedWalletApplication1;

	@Value("${STORED_WALLET_APPLICATION2}")
	private String storedWalletApplication2;

	@Value("${STORED_WALLET_APPLICATION3}")
	private String storedWalletApplication3;

	@Value("${STORED_WALLET_APPLICATION4}")
	private String storedWalletApplication4;

	@Value("${PAYCARD_APP_BUILD_VERSION}")
	private String payCardAppBuildVersion;

	
	@Value("${PAYCARD_ACKNOWLEDGEMENT_INTERVAL}")
	private Long payCardAckInterval;

	@Value("${OVERLAY_WELCOME_MESSAGE}")
	private String overlayWelcomeMessage;

	@Value("${walletToWalletUrl}")
	private String walletToWalletUrl;

	@Value("${transactionUrl}")
	private String transactionUrl;

	@Value("${changePasswordUrl}")
	private String changePasswordUrl;

	@Value("${forgetedPasswordUrl}")
	private String forgetedPasswordUrl;

	@Value("${selfCareloginUrl}")
	private String selfCareloginUrl;

	@Value("${HIT_URL}")
	private String hitUrl;
	@Value("${SMS_HIT_URL}")
	private String smsHitUrl;
	@Value("${OTA_HOST_HIT_URL}")
	private String otaHostUrl;
	@Value("${TOTAL_FAILURE_CODE}")
	private String totalFailureCode;

	@Value("${TOTAL_FAILURE_DESCRIPTION}")
	private String totalFailureDescription;
	@Value("${LOCAL_CACHE_ADDRESS}")
	private String localCacheAddress;
	@Value("${ESTEL_URL}")
	private String estelUrl;
	
	@Value("${OVERLAY_ISSUANCE_API}")
	private String overlayIssuanceApi;
	
	@Value("${LOG_FILE_PATH}")
	private String logFilePath;
	
	@Value("${walletListURL}")
	private String walletListURL;
	@Value("${TAFANI_SMS_PUSH_URL}")
	private String tafaniSMSPushUrl;
	@Value("${logoutUrl}")
	private String logoutUrl;
	@Value("${currencyCode}")
	private String currencyCode;
	@Value("${transactionIssueId}")
	private Integer transactionIssueId;
	@Value("#{'${SB_INVALID_ACCOUNTS}'.split(',')}")
	private List<Integer> sbInvalidAccounts;
	@Value("#{'${CC_INVALID_ACCOUNTS}'.split(',')}")
	private List<Integer> ccInvalidAccounts;
	
    @Value("${JMS_SERVER_ADDRESS}")
	private String jmsServerAddress;

	
    @Value("${authorizationCacheUrl}")
	private String authorizationCacheUrl;
    
    @Value("${COMMISSION_LIST_API}")
	private String commissionListingUrl;
    
    @Value("${UPLOAD_PROFILE_IMAGE}")
    private String imagePath;
    
    @Value("${QR_URL}")
    private String qrUrl;
    
    
    @Value("${DATE_FORMAT}")
    private String dateFormat;
    @Value("${DEFAULT_PACKAGE_NAME}")
    private String defaultPackageName; 
    
    @Value("${BULK_ISSUANCE_FILE_UPLOAD_LOCATION}")
    private String bulkFileUploadLocation;
    
    
    
    @Value("${MERCHANT_ONBOARDING}")
    private String merchantOnboard;
    
    @Value("${UPLOAD_KYC_IMAGE}")
    private String kycImagePath;
    @Value("${CORPORATE_ACCOUNT_ID}")
    private String corporateAccountId;
    @Value("${FRANCHISE_ACCOUNT_ID}")
    private String franchiseAccountId;
    @Value("${INDIVIDUAL_ACCOUNT_ID}")
    private String individualaccountId;
    @Value("${COMPANY_OWNED_STORE_ACCOUNT_ID}")
    private String companyAccountId;
    @Value("${COOPERATIVE_ACCOUNT_ID}")
    private String cooperativeAccountId;
    
    @Value("#{'${SEARCH_ISSUANCE_PRODUCTS_BY_TYPE}'.split(',')}") 
    private List<String> productType;
    
    
    @Value("${SEND_OTP_URL}")
    private String sendOtpURL;
    
    @Value("${WALLET_TO_WALLET_ALERT_TO_SENDER}")
    private String wtwSenderTemplate;
    @Value("${WALLET_TO_WALLET_ALERT_TO_RECEIVER}")
    private String wtwReceiverTemplate;
    @Value("${TAFANI_UNICODE_PUSH_URL}")
    private String tafaniUnicodePushUrl;
    
    @Value("#{'${MERCHANT_TRANSACTION_DETAIL_REPORT_HEADER}'.split(',')}") 
    private List<String> merchantTransactionDetailReportHeader;
    @Value("#{'${CARD_TRANSACTION_REPORT_HEADER}'.split(',')}") 
    private List<String> cardTransactionReportHeader;

    @Value("#{'${MERCHANT_TRANSACTION_REPORT_HEADER}'.split(',')}") 
    private List<String> merchantTransactionReportHeader;
    
    @Value("#{'${CARD_SUBSCRIPTION_REPORT_HEADER}'.split(',')}") 
    private List<String> cardSubscriptionReportHeader;


	public List<String> getMerchantTransactionDetailReportHeader() {
		return merchantTransactionDetailReportHeader;
	}

	public List<String> getCardTransactionReportHeader() {
		return cardTransactionReportHeader;
	}

	public List<String> getMerchantTransactionReportHeader() {
		return merchantTransactionReportHeader;
	}

	public List<String> getCardSubscriptionReportHeader() {
		return cardSubscriptionReportHeader;
	}

	public List<String> getProductType() {
		return productType;
	}

	public String getKycImagePath() {
		return kycImagePath;
	}

	public String getMerchantOnboard() {
		return merchantOnboard;
	}

	/**
     * 
     * @returnbulkFileUploadLocation
     */
    public String getBulkFileUploadLocation() {
		return bulkFileUploadLocation;
	}

	public void setBulkFileUploadLocation(String bulkFileUploadLocation) {
		this.bulkFileUploadLocation = bulkFileUploadLocation;
	}
    
    
	public String getDefaultPackageName() {
		return defaultPackageName;
	}

	/**
	 * @return the dateFormat
	 */
	public String getDateFormat() {
		return dateFormat;
	}

	/**
	 * @param dateFormat the dateFormat to set
	 */
	public void setDateFormat(String dateFormat) {
		this.dateFormat = dateFormat;
	}

	public String getQrUrl() {
		return qrUrl;
	}

	public void setQrUrl(String qrUrl) {
		this.qrUrl = qrUrl;
	}

	public String getImagePath() {
		return imagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

	/**
	 * @return the pukUrl
	 */
	public String getPukUrl() {
		return pukUrl;
	}

	public String getAuthorizationCacheUrl() {
		return authorizationCacheUrl;
	}

	public void setAuthorizationCacheUrl(String authorizationCacheUrl) {
		this.authorizationCacheUrl = authorizationCacheUrl;
	}

	/**
	 * @param pukUrl the pukUrl to set
	 */
	public void setPukUrl(String pukUrl) {
		this.pukUrl = pukUrl;
	}

	@Value("${QR_PATH}")
	private String  qrPath;
	
	@Value("${BANK_ID}")
	private Integer bankId;
	
	
	@Value("${pukUrl}")
	private String pukUrl;
	
	 @Value("${MIN_PACKAGE_SIZE}")
	    private int minimumPackageSize;
	    
	    
		/**
		 * @return the minimumPackageSize
		 */
		public int getMinimumPackageSize() {
			return minimumPackageSize;
		}

		/**
		 * @param minimumPackageSize the minimumPackageSize to set
		 */
		public void setMinimumPackageSize(int minimumPackageSize) {
			this.minimumPackageSize = minimumPackageSize;
		}

	public Integer getBankId() {
		return bankId;
	}

	public Integer getTransactionIssueId() {
		return transactionIssueId;
	}

	public void setTransactionIssueId(Integer transactionIssueId) {
		this.transactionIssueId = transactionIssueId;
	}

	public String getInventoryUploadFileLocation() {
		return inventoryUploadFileLocation;
	}
	
	public String getCurrencyCode() {
		return currencyCode;
	}


	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public String getLogoutUrl() {
		return logoutUrl;
	}

	public void setLogoutUrl(String logoutUrl) {
		this.logoutUrl = logoutUrl;
	}

	
	
	public String getLogFilePath() {
		return logFilePath;
	}
	
	public String getWalletListURL() {
		return walletListURL;
	}

	public void setWalletListURL(String walletListURL) {
		this.walletListURL = walletListURL;
	}

	public void setLogFilePath(String logFilePath) {
		this.logFilePath = logFilePath;
	}

	public String getEstelUrl() {
		return estelUrl;
	}

	public void setEstelUrl(String estelUrl) {
		this.estelUrl = estelUrl;
	}

	public String getLocalCacheAddress() {
		return localCacheAddress;
	}

	public void setLocalCacheAddress(String localCacheAddress) {
		this.localCacheAddress = localCacheAddress;
	}

	public String getHitUrl() {
		return hitUrl;
	}

	public void setHitUrl(String hitUrl) {
		this.hitUrl = hitUrl;
	}

	public String getSmsHitUrl() {
		return smsHitUrl;
	}

	public void setSmsHitUrl(String smsHitUrl) {
		this.smsHitUrl = smsHitUrl;
	}

	public String getOtaHostUrl() {
		return otaHostUrl;
	}

	public void setOtaHostUrl(String otaHostUrl) {
		this.otaHostUrl = otaHostUrl;
	}

	public String getWalletToWalletUrl() {
		return walletToWalletUrl;
	}

	public void setWalletToWalletUrl(String walletToWalletUrl) {
		this.walletToWalletUrl = walletToWalletUrl;
	}

	public String getTransactionUrl() {
		return transactionUrl;
	}

	public void setTransactionUrl(String transactionUrl) {
		this.transactionUrl = transactionUrl;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getHostId() {
		return hostId;
	}

	public void setHostId(String hostId) {
		this.hostId = hostId;
	}

	public String getDistributorId() {
		return distributorId;
	}

	public void setDistributorId(String distributorId) {
		this.distributorId = distributorId;
	}

	public String getSubdistributorId() {
		return subdistributorId;
	}

	public void setSubdistributorId(String subdistributorId) {
		this.subdistributorId = subdistributorId;
	}

	public String getAgentId() {
		return agentId;
	}

	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}

	public String getAccountTypeid() {
		return accountTypeid;
	}

	public void setAccountTypeid(String accountTypeid) {
		this.accountTypeid = accountTypeid;
	}

	public String getSuccessMessage() {
		return successMessage;
	}

	public void setSuccessMessage(String successMessage) {
		this.successMessage = successMessage;
	}

	public String getSuccessCode() {
		return successCode;
	}

	public void setSuccessCode(String successCode) {
		this.successCode = successCode;
	}

	public String getSuccessDescription() {
		return successDescription;
	}

	public void setSuccessDescription(String successDescription) {
		this.successDescription = successDescription;
	}

	public String getPartialSuccessMessage() {
		return partialSuccessMessage;
	}

	public void setPartialSuccessMessage(String partialSuccessMessage) {
		this.partialSuccessMessage = partialSuccessMessage;
	}

	public String getPartialSuccessCode() {
		return partialSuccessCode;
	}

	public void setPartialSuccessCode(String partialSuccessCode) {
		this.partialSuccessCode = partialSuccessCode;
	}

	public String getPartialSuccessDescription() {
		return partialSuccessDescription;
	}

	public void setPartialSuccessDescription(String partialSuccessDescription) {
		this.partialSuccessDescription = partialSuccessDescription;
	}

	public String getKeyFailureMessage() {
		return keyFailureMessage;
	}

	public void setKeyFailureMessage(String keyFailureMessage) {
		this.keyFailureMessage = keyFailureMessage;
	}

	public String getKeyFailureCode() {
		return keyFailureCode;
	}

	public void setKeyFailureCode(String keyFailureCode) {
		this.keyFailureCode = keyFailureCode;
	}

	public String getKeyFailureDescription() {
		return keyFailureDescription;
	}

	public void setKeyFailureDescription(String keyFailureDescription) {
		this.keyFailureDescription = keyFailureDescription;
	}

	public String getIpFailureMessage() {
		return ipFailureMessage;
	}

	public void setIpFailureMessage(String ipFailureMessage) {
		this.ipFailureMessage = ipFailureMessage;
	}

	public String getIpFailureCode() {
		return ipFailureCode;
	}

	public void setIpFailureCode(String ipFailureCode) {
		this.ipFailureCode = ipFailureCode;
	}

	public String getIpFailureDescription() {
		return ipFailureDescription;
	}

	public void setIpFailureDescription(String ipFailureDescription) {
		this.ipFailureDescription = ipFailureDescription;
	}

	public String getExpiredPinMessage() {
		return expiredPinMessage;
	}

	public void setExpiredPinMessage(String expiredPinMessage) {
		this.expiredPinMessage = expiredPinMessage;
	}

	public String getExpiredPinCode() {
		return expiredPinCode;
	}

	public void setExpiredPinCode(String expiredPinCode) {
		this.expiredPinCode = expiredPinCode;
	}

	public String getExpiredPinDescription() {
		return expiredPinDescription;
	}

	public void setExpiredPinDescription(String expiredPinDescription) {
		this.expiredPinDescription = expiredPinDescription;
	}

	public String getIntransitPinMessage() {
		return intransitPinMessage;
	}

	public void setIntransitPinMessage(String intransitPinMessage) {
		this.intransitPinMessage = intransitPinMessage;
	}

	public String getIntransitPinCode() {
		return intransitPinCode;
	}

	public void setIntransitPinCode(String intransitPinCode) {
		this.intransitPinCode = intransitPinCode;
	}

	public String getIntransitPinDescription() {
		return intransitPinDescription;
	}

	public void setIntransitPinDescription(String intransitPinDescription) {
		this.intransitPinDescription = intransitPinDescription;
	}

	public String getUsedPinMessage() {
		return usedPinMessage;
	}

	public void setUsedPinMessage(String usedPinMessage) {
		this.usedPinMessage = usedPinMessage;
	}

	public String getUsedPinCode() {
		return usedPinCode;
	}

	public void setUsedPinCode(String usedPinCode) {
		this.usedPinCode = usedPinCode;
	}

	public String getUsedPinDescription() {
		return usedPinDescription;
	}

	public void setUsedPinDescription(String usedPinDescription) {
		this.usedPinDescription = usedPinDescription;
	}

	public String getTotalFailureMessage() {
		return totalFailureMessage;
	}

	public void setTotalFailureMessage(String totalFailureMessage) {
		this.totalFailureMessage = totalFailureMessage;
	}

	public String getTotalFailureCode() {
		return totalFailureCode;
	}

	public void setTotalFailureCode(String totalFailureCode) {
		this.totalFailureCode = totalFailureCode;
	}

	public String getTotalFailureDescription() {
		return totalFailureDescription;
	}

	public void setTotalFailureDescription(String totalFailureDescription) {
		this.totalFailureDescription = totalFailureDescription;
	}

	public String getPinFailureMessage() {
		return pinFailureMessage;
	}

	public void setPinFailureMessage(String pinFailureMessage) {
		this.pinFailureMessage = pinFailureMessage;
	}

	public String getPinFailureCode() {
		return pinFailureCode;
	}

	public void setPinFailureCode(String pinFailureCode) {
		this.pinFailureCode = pinFailureCode;
	}

	public String getPinFailureDescription() {
		return pinFailureDescription;
	}

	public String getPortalFailureMessage() {
		return portalFailureMessage;
	}

	public void setPortalFailureMessage(String portalFailureMessage) {
		this.portalFailureMessage = portalFailureMessage;
	}

	public String getPortalFailureCode() {
		return portalFailureCode;
	}

	public void setPortalFailureCode(String portalFailureCode) {
		this.portalFailureCode = portalFailureCode;
	}

	public String getPortalFailureDescription() {
		return portalFailureDescription;
	}

	public void setPortalFailureDescription(String portalFailureDescription) {
		this.portalFailureDescription = portalFailureDescription;
	}

	public void setPinFailureDescription(String pinFailureDescription) {
		this.pinFailureDescription = pinFailureDescription;
	}

	public String getVoucherUrl() {
		return voucherUrl;
	}

	public void setVoucherUrl(String voucherUrl) {
		this.voucherUrl = voucherUrl;
	}

	public String getEkoVerifyCustUrl() {
		return ekoVerifyCustUrl;
	}

	public void setEkoVerifyCustUrl(String ekoVerifyCustUrl) {
		this.ekoVerifyCustUrl = ekoVerifyCustUrl;
	}

	public String getEuroNetValURL() {
		return euroNetValURL;
	}

	public void setEuroNetValURL(String euroNetValURL) {
		this.euroNetValURL = euroNetValURL;
	}

	public String getEuroNetTxnURL() {
		return euroNetTxnURL;
	}

	public void setEuroNetTxnURL(String euroNetTxnURL) {
		this.euroNetTxnURL = euroNetTxnURL;
	}

	public String getEuroNetTxnStatusURL() {
		return euroNetTxnStatusURL;
	}

	public void setEuroNetTxnStatusURL(String euroNetTxnStatusURL) {
		this.euroNetTxnStatusURL = euroNetTxnStatusURL;
	}

	public String getEuroNetUserName() {
		return euroNetUserName;
	}

	public void setEuroNetUserName(String euroNetUserName) {
		this.euroNetUserName = euroNetUserName;
	}

	public String getEuroNetPassword() {
		return euroNetPassword;
	}

	public void setEuroNetPassword(String euroNetPassword) {
		this.euroNetPassword = euroNetPassword;
	}

	public String getEuroNetMerchantCode() {
		return euroNetMerchantCode;
	}

	public void setEuroNetMerchantCode(String euroNetMerchantCode) {
		this.euroNetMerchantCode = euroNetMerchantCode;
	}

	public String getEuroNetPaymentProvider() {
		return euroNetPaymentProvider;
	}

	public void setEuroNetPaymentProvider(String euroNetPaymentProvider) {
		this.euroNetPaymentProvider = euroNetPaymentProvider;
	}

	public String getEuroNetPaymentMode() {
		return euroNetPaymentMode;
	}

	public void setEuroNetPaymentMode(String euroNetPaymentMode) {
		this.euroNetPaymentMode = euroNetPaymentMode;
	}

	public String getEuroNetChannelCode() {
		return euroNetChannelCode;
	}

	public void setEuroNetChannelCode(String euroNetChannelCode) {
		this.euroNetChannelCode = euroNetChannelCode;
	}

	public String getEuroNetStoreCode() {
		return euroNetStoreCode;
	}

	public void setEuroNetStoreCode(String euroNetStoreCode) {
		this.euroNetStoreCode = euroNetStoreCode;
	}

	public String getEuroNetTermCode() {
		return euroNetTermCode;
	}

	public void setEuroNetTermCode(String euroNetTermCode) {
		this.euroNetTermCode = euroNetTermCode;
	}

	public String getEuroNetCustomerId() {
		return euroNetCustomerId;
	}

	public void setEuroNetCustomerId(String euroNetCustomerId) {
		this.euroNetCustomerId = euroNetCustomerId;
	}

	public String getEuroNetTCFlag() {
		return euroNetTCFlag;
	}

	public void setEuroNetTCFlag(String euroNetTCFlag) {
		this.euroNetTCFlag = euroNetTCFlag;
	}

	public String getPnbSocketIP() {
		return pnbSocketIP;
	}

	public void setPnbSocketIP(String pnbSocketIP) {
		this.pnbSocketIP = pnbSocketIP;
	}

	public Integer getPnbSocketPort() {
		return pnbSocketPort;
	}

	public void setPnbSocketPort(Integer pnbSocketPort) {
		this.pnbSocketPort = pnbSocketPort;
	}

	@Bean
	public static PropertySourcesPlaceholderConfigurer placeholderConfigurer() {
		return new PropertySourcesPlaceholderConfigurer();
	}

	public String getDeploymentFor() {
		return deploymentFor;
	}

	public void setDeploymentFor(String deploymentFor) {
		this.deploymentFor = deploymentFor;
	}

	public String getStoredValueApplication1() {
		return storedValueApplication1;
	}

	public void setStoredValueApplication1(String storedValueApplication1) {
		this.storedValueApplication1 = storedValueApplication1;
	}

	public String getStoredValueApplication2() {
		return storedValueApplication2;
	}

	public void setStoredValueApplication2(String storedValueApplication2) {
		this.storedValueApplication2 = storedValueApplication2;
	}

	public String getStoredValueApplication3() {
		return storedValueApplication3;
	}

	public void setStoredValueApplication3(String storedValueApplication3) {
		this.storedValueApplication3 = storedValueApplication3;
	}

	public String getStoredValueApplication4() {
		return storedValueApplication4;
	}

	public void setStoredValueApplication4(String storedValueApplication4) {
		this.storedValueApplication4 = storedValueApplication4;
	}

	public String getStoredWalletApplication1() {
		return storedWalletApplication1;
	}

	public void setStoredWalletApplication1(String storedWalletApplication1) {
		this.storedWalletApplication1 = storedWalletApplication1;
	}

	public String getStoredWalletApplication2() {
		return storedWalletApplication2;
	}

	public void setStoredWalletApplication2(String storedWalletApplication2) {
		this.storedWalletApplication2 = storedWalletApplication2;
	}

	public String getStoredWalletApplication3() {
		return storedWalletApplication3;
	}

	public void setStoredWalletApplication3(String storedWalletApplication3) {
		this.storedWalletApplication3 = storedWalletApplication3;
	}

	public String getStoredWalletApplication4() {
		return storedWalletApplication4;
	}

	public void setStoredWalletApplication4(String storedWalletApplication4) {
		this.storedWalletApplication4 = storedWalletApplication4;
	}

	public String getPayCardAppBuildVersion() {
		return payCardAppBuildVersion;
	}



	public void setPayCardAppBuildVersion(String payCardAppBuildVersion) {
		this.payCardAppBuildVersion = payCardAppBuildVersion;
	}

	public String getTafaniProjectId() {
		return tafaniProjectId;
	}

	public void setTafaniProjectId(String tafaniProjectId) {
		this.tafaniProjectId = tafaniProjectId;
	}

	public Integer getMobileNumberLength() {
		return mobileNumberLength;
	}

	public void setMobileNumberLength(Integer mobileNumberLength) {
		this.mobileNumberLength = mobileNumberLength;
	}

	public Long getPayCardAckInterval() {
		return payCardAckInterval;
	}

	public void setPayCardAckInterval(Long payCardAckInterval) {
		this.payCardAckInterval = payCardAckInterval;
	}

	public String getOverlayWelcomeMessage() {
		return overlayWelcomeMessage;
	}

	public void setOverlayWelcomeMessage(String overlayWelcomeMessage) {
		this.overlayWelcomeMessage = overlayWelcomeMessage;
	}

	public String getChangePasswordUrl() {
		return changePasswordUrl;
	}

	public void setChangePasswordUrl(String changePasswordUrl) {
		this.changePasswordUrl = changePasswordUrl;
	}

	public String getForgetedPasswordUrl() {
		return forgetedPasswordUrl;
	}

	public void setForgetedPasswordUrl(String forgetedPasswordUrl) {
		this.forgetedPasswordUrl = forgetedPasswordUrl;
	}

	public String getSelfCareloginUrl() {
		return selfCareloginUrl;
	}

	public void setSelfCareloginUrl(String selfCareloginUrl) {
		this.selfCareloginUrl = selfCareloginUrl;
	}

	public String getOverlayIssuanceApi() {
		return overlayIssuanceApi;
	}

	public void setOverlayIssuanceApi(String overlayIssuanceApi) {
		this.overlayIssuanceApi = overlayIssuanceApi;
	}

	public String getTafaniSMSPushUrl() {
		return tafaniSMSPushUrl;
	}

	public void setTafaniSMSPushUrl(String tafaniSMSPushUrl) {
		this.tafaniSMSPushUrl = tafaniSMSPushUrl;
	}

	public String getDocumentUploadPath() {
		return documentUploadPath;
	}

	public void setDocumentUploadPath(String documentUploadPath) {
		this.documentUploadPath = documentUploadPath;
	}

	public void setInventoryUploadFileLocation(String inventoryUploadFileLocation) {
		this.inventoryUploadFileLocation = inventoryUploadFileLocation;
	}

	public String getRefundDays() {
		return refundDays;
	}

	public void setRefundDays(String refundDays) {
		this.refundDays = refundDays;
	}

	public String getsEIssuanceListUrl() {
		return sEIssuanceListUrl;
	}

	public void setsEIssuanceListUrl(String sEIssuanceListUrl) {
		this.sEIssuanceListUrl = sEIssuanceListUrl;
	}

	public List<Integer> getSbInvalidAccounts() {
		return sbInvalidAccounts;
	}

	public void setSbInvalidAccounts(List<Integer> sbInvalidAccounts) {
		this.sbInvalidAccounts = sbInvalidAccounts;
	}

	public List<Integer> getCcInvalidAccounts() {
		return ccInvalidAccounts;
	}

	public void setCcInvalidAccounts(List<Integer> ccInvalidAccounts) {
		this.ccInvalidAccounts = ccInvalidAccounts;
	}

	public String getQrPath() {
		return qrPath;
	}

	public String getJmsServerAddress() {
		return jmsServerAddress;
	}

	public void setJmsServerAddress(String jmsServerAddress) {
		this.jmsServerAddress = jmsServerAddress;
	}

	public String getCommissionListingUrl() {
		return commissionListingUrl;
	}

	public void setCommissionListingUrl(String commissionListingUrl) {
		this.commissionListingUrl = commissionListingUrl;
	}

	public void setQrPath(String qrPath) {
		this.qrPath = qrPath;
	}

	public void setBankId(Integer bankId) {
		this.bankId = bankId;
	}

	public String getMaxRowsMis() {
		return maxRowsMis;
	}

	public void setMaxRowsMis(String maxRowsMis) {
		this.maxRowsMis = maxRowsMis;
	}

	public String getDownloadKycUrl() {
		return downloadKycUrl;
	}

	public void setDownloadKycUrl(String downloadKycUrl) {
		this.downloadKycUrl = downloadKycUrl;
	}

	public String getMerchantIssuanceUrl() {
		return merchantIssuanceUrl;
	}

	public void setMerchantIssuanceUrl(String merchantIssuanceUrl) {
		this.merchantIssuanceUrl = merchantIssuanceUrl;
	}

	public String getCorporateAccountId() {
		return corporateAccountId;
	}

	public void setCorporateAccountId(String corporateAccountId) {
		this.corporateAccountId = corporateAccountId;
	}

	public String getFranchiseAccountId() {
		return franchiseAccountId;
	}

	public void setFranchiseAccountId(String franchiseAccountId) {
		this.franchiseAccountId = franchiseAccountId;
	}

	public String getIndividualaccountId() {
		return individualaccountId;
	}

	public void setIndividualaccountId(String individualaccountId) {
		this.individualaccountId = individualaccountId;
	}

	public String getCompanyAccountId() {
		return companyAccountId;
	}

	public void setCompanyAccountId(String companyAccountId) {
		this.companyAccountId = companyAccountId;
	}

	public String getCooperativeAccountId() {
		return cooperativeAccountId;
	}

	public void setCooperativeAccountId(String cooperativeAccountId) {
		this.cooperativeAccountId = cooperativeAccountId;
	}

	public void setDefaultPackageName(String defaultPackageName) {
		this.defaultPackageName = defaultPackageName;
	}

	public void setMerchantOnboard(String merchantOnboard) {
		this.merchantOnboard = merchantOnboard;
	}

	public void setKycImagePath(String kycImagePath) {
		this.kycImagePath = kycImagePath;
	}

	public void setProductType(List<String> productType) {
		this.productType = productType;
	}

	public String getSendOtpURL() {
		return sendOtpURL;
	}

	public void setSendOtpURL(String sendOtpURL) {
		this.sendOtpURL = sendOtpURL;
	}

	public String getWtwSenderTemplate() {
		return wtwSenderTemplate;
	}

	public void setWtwSenderTemplate(String wtwSenderTemplate) {
		this.wtwSenderTemplate = wtwSenderTemplate;
	}

	public String getWtwReceiverTemplate() {
		return wtwReceiverTemplate;
	}

	public void setWtwReceiverTemplate(String wtwReceiverTemplate) {
		this.wtwReceiverTemplate = wtwReceiverTemplate;
	}

	public String getTafaniUnicodePushUrl() {
		return tafaniUnicodePushUrl;
	}

	public void setTafaniUnicodePushUrl(String tafaniUnicodePushUrl) {
		this.tafaniUnicodePushUrl = tafaniUnicodePushUrl;
	}

}
