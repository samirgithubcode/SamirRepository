package com.ng.pnb.invoker.util;

public class AuthorizationDetails {

	private String primaryAccessCode = null;
	
    private String secondaryAccessCode = null;
    
    private String userId = null;    
    
    private String acceptTermsAndConditions = null;

	public String getPrimaryAccessCode() {
		return primaryAccessCode;
	}

	public void setPrimaryAccessCode(String primaryAccessCode) {
		this.primaryAccessCode = primaryAccessCode;
	}

	public String getSecondaryAccessCode() {
		return secondaryAccessCode;
	}

	public void setSecondaryAccessCode(String secondaryAccessCode) {
		this.secondaryAccessCode = secondaryAccessCode;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getAcceptTermsAndConditions() {
		return acceptTermsAndConditions;
	}

	public void setAcceptTermsAndConditions(String acceptTermsAndConditions) {
		this.acceptTermsAndConditions = acceptTermsAndConditions;
	}
    
}
