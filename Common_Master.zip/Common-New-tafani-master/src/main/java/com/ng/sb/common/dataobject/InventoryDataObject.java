package com.ng.sb.common.dataobject;

import java.util.List;

public class InventoryDataObject extends BaseObjectData {
	private static final long serialVersionUID = 1L;
	private String[] inventoryArray;
	private List<QueryDataObject> queryDataObjects;
	public String[] getInventoryArray() {
		return inventoryArray;
	}
	public void setInventoryArray(String[] inventoryArray) {
		this.inventoryArray = inventoryArray;
	}
	public List<QueryDataObject> getQueryDataObjects() {
		return queryDataObjects;
	}
	public void setQueryDataObjects(List<QueryDataObject> queryDataObjects) {
		this.queryDataObjects = queryDataObjects;
	}
	

}
