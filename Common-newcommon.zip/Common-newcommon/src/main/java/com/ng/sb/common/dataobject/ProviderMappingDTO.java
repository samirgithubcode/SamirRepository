package com.ng.sb.common.dataobject;

public class ProviderMappingDTO {
	private Integer providerId;
	private Integer mappingId;
	private String providerName;
	private String providerDescription;
	private Integer providerCode;
	private Integer catId;
	private String catName;
	private Integer thirdPartyBillerCode;
	private Boolean status;
	private Integer hsvId;
	public Integer getProviderId() {
		return providerId;
	}
	public void setProviderId(Integer providerId) {
		this.providerId = providerId;
	}
	
	public Integer getMappingId() {
		return mappingId;
	}
	public void setMappingId(Integer mappingId) {
		this.mappingId = mappingId;
	}
	public String getProviderName() {
		return providerName;
	}
	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}
	public String getProviderDescription() {
		return providerDescription;
	}
	public void setProviderDescription(String providerDescription) {
		this.providerDescription = providerDescription;
	}
	public Integer getProviderCode() {
		return providerCode;
	}
	public void setProviderCode(Integer providerCode) {
		this.providerCode = providerCode;
	}
	public Integer getCatId() {
		return catId;
	}
	public void setCatId(Integer catId) {
		this.catId = catId;
	}
	public Integer getThirdPartyBillerCode() {
		return thirdPartyBillerCode;
	}
	public void setThirdPartyBillerCode(Integer thirdPartyBillerCode) {
		this.thirdPartyBillerCode = thirdPartyBillerCode;
	}
	public Boolean getStatus() {
		return status;
	}
	public void setStatus(Boolean status) {
		this.status = status;
	}
	public String getCatName() {
		return catName;
	}
	public void setCatName(String catName) {
		this.catName = catName;
	}
	public Integer getHsvId() {
		return hsvId;
	}
	public void setHsvId(Integer hsvId) {
		this.hsvId = hsvId;
	}

}
