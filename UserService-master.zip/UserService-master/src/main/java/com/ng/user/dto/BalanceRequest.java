/**
 * 
 */
package com.ng.user.dto;

import com.ng.sb.common.dataobject.ValidationBean;

/**
 * @author gopal
 *
 */
public class BalanceRequest implements ValidationBean {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4203258071830126009L;

	private Integer agentId;

	public Integer getAgentId() {
		return agentId;
	}

	public void setAgentId(Integer agentId) {
		this.agentId = agentId;
	}
	
	
}
