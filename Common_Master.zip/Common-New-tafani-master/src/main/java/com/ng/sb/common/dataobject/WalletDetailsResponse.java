package com.ng.sb.common.dataobject;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "WalletListResponseData")

public class WalletDetailsResponse  implements ValidationBean {

	private static final long serialVersionUID = 1L;


private String errorList;
private String name;
private String walletbalance;
private String walletid;
private Integer refundAmount;


public String getErrorList() {
	return errorList;
}
public void setErrorList(String errorList) {
	this.errorList = errorList;
}

public String getWalletbalance() {
	return walletbalance;
}
public void setWalletbalance(String walletbalance) {
	this.walletbalance = walletbalance;
}
public Integer getRefundAmount() {
	return refundAmount;
}
public void setRefundAmount(Integer refundAmount) {
	this.refundAmount = refundAmount;
}

public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getWalletid() {
	return walletid;
}
public void setWalletid(String walletid) {
	this.walletid = walletid;
}
	
	
	
}
