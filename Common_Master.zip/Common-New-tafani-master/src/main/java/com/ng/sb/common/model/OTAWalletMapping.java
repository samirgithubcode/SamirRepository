/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "OTAWalletMapping")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "OTAWalletMapping.findAll", query = "SELECT o FROM OTAWalletMapping o"),
    @NamedQuery(name = "OTAWalletMapping.findById", query = "SELECT o FROM OTAWalletMapping o WHERE o.id = :id"),
    @NamedQuery(name = "OTAWalletMapping.findByotaMgmtId", query = "SELECT o FROM OTAWalletMapping o WHERE o.otaMgmtId = :otaMgmtId"),
    @NamedQuery(name = "OTAWalletMapping.findByWalletType", query = "SELECT o FROM OTAWalletMapping o WHERE o.walletType = :walletType")})
public class OTAWalletMapping implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Column(name = "walletType")
    private String walletType;
    @Basic(optional = false)
    @Column(name = "walletStatus")
    private String walletStatus;
    @Column(name="message")
    private String message;
    @JoinColumn(name = "walletId", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Partner walletId;
    @JoinColumn(name = "otaMgmtId", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private OTAManagement otaMgmtId;
    @Column(name="isCurrent")
    private Short isCurrent; 
	@ManyToOne
    @JoinColumn(name="otaWHCId")
    private OTAWalletHistoryComparison otaWHCId; 
    
	public OTAWalletMapping() {
		//default constructor
    }

    public OTAWalletMapping(Integer id) {
        this.id = id;
    }

    public OTAWalletMapping(Integer id, String walletStatus) {
        this.id = id;
        this.walletStatus = walletStatus;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getWalletType() {
        return walletType;
    }

    public void setWalletType(String walletType) {
        this.walletType = walletType;
    }

    public String getWalletStatus() {
        return walletStatus;
    }

    public void setWalletStatus(String walletStatus) {
        this.walletStatus = walletStatus;
    }

    public Partner getWalletId() {
        return walletId;
    }

    public void setWalletId(Partner walletId) {
        this.walletId = walletId;
    }
    
    public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public OTAManagement getOtaMgmtId() {
        return otaMgmtId;
    }

    public void setOtaMgmtId(OTAManagement otaMgmtId) {
        this.otaMgmtId = otaMgmtId;
    }
    
    public Short getIsCurrent() {
		return isCurrent;
	}

	public void setIsCurrent(Short isCurrent) {
		this.isCurrent = isCurrent;
	}
	
	public OTAWalletHistoryComparison getOtaWHCId() {
		return otaWHCId;
	}

	public void setOtaWHCId(OTAWalletHistoryComparison otaWHCId) {
		this.otaWHCId = otaWHCId;
	}
	
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof OTAWalletMapping)) {
            return false;
        }
        OTAWalletMapping other = (OTAWalletMapping) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.OTAWalletMapping[ id=" + id + " ]";
    }
    
}
