package com.ng.sb.common.dataobject;

import java.sql.Date;
import java.util.List;
import java.util.Map;


public class TransactionReportData extends BaseObjectData  {
	
	private static final long serialVersionUID = 1L;
	
	private Date toDate;
	private Date fromDate;
	private Date transactionDate;
	private String transactionId;
	private Integer portalNameValue;
	private String companyName;
	private String portalIp;
	private Integer numbeOfPin;
	private String totalAmount;
	private String grossCommission;
	private String netCommission;
	private String netAmount;
	private String status;
	private String portalTrxnStatus;
	private List<PinInfoData> pinInfoData;
	private Map<Integer,String> portalName;
	private String surcharge;
	private String tax;
	
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	
	public String getPortalTrxnStatus() {
		return portalTrxnStatus;
	}
	public void setPortalTrxnStatus(String portalTrxnStatus) {
		this.portalTrxnStatus = portalTrxnStatus;
	}
	
	public Date getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public Integer getPortalNameValue() {
		return portalNameValue;
	}
	public void setPortalNameValue(Integer portalNameValue) {
		this.portalNameValue = portalNameValue;
	}
	public Map<Integer, String> getPortalName() {
		return portalName;
	}
	public void setPortalName(Map<Integer, String> portalName) {
		this.portalName = portalName;
	}
	public String getPortalIp() {
		return portalIp;
	}
	public void setPortalIp(String portalIp) {
		this.portalIp = portalIp;
	}
	public Integer getNumbeOfPin() {
		return numbeOfPin;
	}
	public void setNumbeOfPin(Integer numbeOfPin) {
		this.numbeOfPin = numbeOfPin;
	}
	
	public String getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(String totalAmount) {
		this.totalAmount = totalAmount;
	}
	public String getGrossCommission() {
		return grossCommission;
	}
	public void setGrossCommission(String grossCommission) {
		this.grossCommission = grossCommission;
	}
	public String getNetCommission() {
		return netCommission;
	}
	public void setNetCommission(String netCommission) {
		this.netCommission = netCommission;
	}
	public String getNetAmount() {
		return netAmount;
	}
	public void setNetAmount(String netAmount) {
		this.netAmount = netAmount;
	}
	public String getSurcharge() {
		return surcharge;
	}
	public void setSurcharge(String surcharge) {
		this.surcharge = surcharge;
	}
	public String getTax() {
		return tax;
	}
	public void setTax(String tax) {
		this.tax = tax;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getToDate() {
		return toDate;
	}
	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}
	public Date getFromDate() {
		return fromDate;
	}
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}
	public List<PinInfoData> getPinInfoData() {
		return pinInfoData;
	}
	public void setPinInfoData(List<PinInfoData> pinInfoData) {
		this.pinInfoData = pinInfoData;
	}
}