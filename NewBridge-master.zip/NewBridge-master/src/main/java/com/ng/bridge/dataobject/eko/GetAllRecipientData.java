package com.ng.bridge.dataobject.eko;

public class GetAllRecipientData {
	 private GetAllRecipientList[] getAllRecipientList;
	
	

	public GetAllRecipientList[] getGetAllRecipientList() {
		return getAllRecipientList;
	}



	public void setGetAllRecipientList(GetAllRecipientList[] getAllRecipientList) {
		this.getAllRecipientList = getAllRecipientList;
	}



	@Override
    public String toString()
    {
        return "ClassPojo [getAllRecipientList = "+getAllRecipientList+"]";
    }
}
