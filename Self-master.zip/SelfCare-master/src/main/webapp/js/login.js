$( document ).ready(function() {
	$('#labsubaccount_type').hide(); 
   // $(".show_hide").show();
});
function selct(id){
	$('#message').html("");
	$("#"+id).addClass('valid');	
}

	function getAccountType() {
		var labaccounttype=$('#lab_account_type').val();
		if(labaccounttype=="Super Admin"){
			$('#labsubaccount_type').hide();
		}
		else{
			
			$.ajax({
					type: "post",
					url: '/securebanking/AdminUI/login/getSubAccountType',
					cache: false,
					data:'account_type=' + labaccounttype,
					success: function(response)
					{
						var obj1 = JSON.parse(response);
						var bcMap = obj1.accountTypeMap;
						var select = $('#lab_subaccount_type');
						select.find('option').remove();
						$.each(bcMap, function( key, value )
						{
							$('<option>').val(key).text(value).appendTo(select);
						});
						
					},
					error: function()
					{						
						
					}
			});
			
			
			
			$('#labsubaccount_type').show();
		}
		
		//alert(labaccounttype);
	}
	
	function usererrormessage(event)
	{
		
		
	var error=	$('.alert-danger').text();
	$('.alert-danger').hide();
	document.getElementById('hrefId').enable=true;
	
	}
	
	function removeMessage(){
		
		$('#message').html("");
		
	}
	
	
	
	function onlyNumeric(id,errorId,labelid){
		 $('#'+errorId).html('');
		 $('#'+labelid).show();
		var str=$('#'+id).val().trim();
		if(str.length!=0){
		for(var i=0;i<str.length;i++){
			 var asciiValue=str.charCodeAt(i);
			// alert(asciiValue)
			 if((asciiValue >= 97 && asciiValue <= 122)||(asciiValue >= 65 && asciiValue <= 90) ||(asciiValue >= 34 && asciiValue <= 38) || (asciiValue >= 40 && asciiValue <= 46) || asciiValue == 47 || asciiValue == 58 || asciiValue == 32 || asciiValue == 59  ||  asciiValue == 60 ||  asciiValue == 61 || asciiValue == 63 || asciiValue == 39 || asciiValue == 62 ||asciiValue == 64 ||asciiValue == 33 || ( asciiValue >= 91 && asciiValue <= 95 ) || asciiValue==96 || (asciiValue >=123 && asciiValue<=126) ){
				 
				 $('#'+id).val('');
				 $('#'+errorId).html('<font color="red">Only Numeric are allowed</font>');
				 $('#'+errorId).show();
				 $('#'+labelid).hide();
					event.preventDefault();
					return false;
			 }
		}
		 
		}
		
		
	}

	
	
	
	