/**
 * 
 */
package com.ng.sb.common.jms;

import java.io.Serializable;

/**
 * @author gopal
 *
 */
public class JmsMessage implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Integer txnId;
	
	private String distributionType;
	
	private String deductionSource;
	
    private String commissionCode;
    
    private String subscriptionCode;
	
	public Integer getTxnId() {
		return txnId;
	}

	public void setTxnId(Integer txnId) {
		this.txnId = txnId;
	}

	public String getDistributionType() {
		return distributionType;
	}

	public void setDistributionType(String distributionType) {
		this.distributionType = distributionType;
	}

	public String getDeductionSource() {
		return deductionSource;
	}

	public void setDeductionSource(String deductionSource) {
		this.deductionSource = deductionSource;
	}

	public String getCommissionCode() {
		return commissionCode;
	}

	public void setCommissionCode(String commissionCode) {
		this.commissionCode = commissionCode;
	}

	public String getSubscriptionCode() {
		return subscriptionCode;
	}

	public void setSubscriptionCode(String subscriptionCode) {
		this.subscriptionCode = subscriptionCode;
	}

}
