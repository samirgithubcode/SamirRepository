/**
 * 
 */
package com.ng.transaction.service;

import com.ng.sb.common.dataobject.BridgeDataObject;


/**
 * @author gaurav
 *
 */
public interface IMWalletAgentService extends IWalletService {
	public BridgeDataObject agentTopUpOnlineWalletToWallet(BridgeDataObject bridgeDataObject);
	public BridgeDataObject agentTopUpOnlineBankToWallet(BridgeDataObject bridgeDataObject);
	public BridgeDataObject agentTopUpOnlineCCToWallet(BridgeDataObject bridgeDataObject);
	public BridgeDataObject agentTopUpOnlineIMPSToWallet(BridgeDataObject bridgeDataObject);
	
	public BridgeDataObject agentTopUpAccountBankToBank(BridgeDataObject bridgeDataObject);
	public BridgeDataObject agentTopUpAccountBankToWallet(BridgeDataObject bridgeDataObject);
	public BridgeDataObject agentTopUpAccountBankToCC(BridgeDataObject bridgeDataObject);
	public BridgeDataObject agentTopUpAccountBankToIMPS(BridgeDataObject bridgeDataObject);
	
	public BridgeDataObject agentTopUpAccountIMPSToBank(BridgeDataObject bridgeDataObject);
	public BridgeDataObject agentTopUpAccountIMPSToWallet(BridgeDataObject bridgeDataObject);
	public BridgeDataObject agentTopUpAccountIMPSToIMPS(BridgeDataObject bridgeDataObject);
	public BridgeDataObject agentTopUpAccountIMPSToCC(BridgeDataObject bridgeDataObject);
	
	public BridgeDataObject agentTopUpAccountCCToBank(BridgeDataObject bridgeDataObject);
	public BridgeDataObject agentTopUpAccountCCToWallet(BridgeDataObject bridgeDataObject);
	public BridgeDataObject agentTopUpAccountCCToIMPS(BridgeDataObject bridgeDataObject);
	public BridgeDataObject agentTopUpAccountCCToCC(BridgeDataObject bridgeDataObject);
	
	public BridgeDataObject agentWalletCheckBalance(BridgeDataObject bridgeDataObject);
	
	
}
