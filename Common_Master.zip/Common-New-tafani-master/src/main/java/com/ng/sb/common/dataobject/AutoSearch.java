package com.ng.sb.common.dataobject;

public class AutoSearch extends BaseObjectData{

	/**
	 * Created by Deepika Kaushik
	 */
	private static final long serialVersionUID = 1L;
	
	
	private String searchCriteria;
	private String accountInfo;
	private String selectType;
	private String tagName;
	private String filter;
	public String getFilter() {
		return filter;
	}
	public void setFilter(String filter) {
		this.filter = filter;
	}

	public String getSearchCriteria() {
		return searchCriteria;
	}
	public void setSearchCriteria(String searchCriteria) {
		this.searchCriteria = searchCriteria;
	}
	public String getAccountInfo() {
		return accountInfo;
	}
	public void setAccountInfo(String accountInfo) {
		this.accountInfo = accountInfo;
	}
	public String getSelectType() {
		return selectType;
	}
	public void setSelectType(String selectType) {
		this.selectType = selectType;
	}
	public String getTagName() {
		return tagName;
	}
	public void setTagName(String tagName) {
		this.tagName = tagName;
	}
	
	
}