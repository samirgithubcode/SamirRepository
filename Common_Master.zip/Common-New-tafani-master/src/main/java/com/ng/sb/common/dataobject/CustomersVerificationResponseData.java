/**
 * 
 */
package com.ng.sb.common.dataobject;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author gaurav
 *
 */
@XmlRootElement(name = "CustomersVerificationResponseData")
public class CustomersVerificationResponseData extends PlatformResponseData {
	private static final long serialVersionUID = 1L;
	
	private List<CustomerVerificationResponseData> custVerificationList;
	private String responseMessage; 
	public String getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}

	public List<CustomerVerificationResponseData> getCustVerificationList() {
		return custVerificationList;
	}

	public void setCustVerificationList(List<CustomerVerificationResponseData> custVerificationList) {
		this.custVerificationList = custVerificationList;
	}

}
