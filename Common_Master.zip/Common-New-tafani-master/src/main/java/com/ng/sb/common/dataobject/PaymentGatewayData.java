package com.ng.sb.common.dataobject;

import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement(name="PaymentGatewayData")
public class PaymentGatewayData extends BaseObjectData{

	private static final long serialVersionUID = 1L;
	private String transactionData;
	private String portalId;
	private String vpin;
	private Object payload;
	private String message;
	private String transactionId;
	private Integer voucherValue;
	public String getToMobileNumber() {
		return toMobileNumber;
	}
	public void setToMobileNumber(String toMobileNumber) {
		this.toMobileNumber = toMobileNumber;
	}
	private String transactionTime;
	private String paymentMode;
	private Integer transactionAmount;
	private String refTransId;
	private String mobileNumber;
	private String mpin;
	private LoginData loginDetails;
	private String toMobileNumber;
	public LoginData getLoginDetails() {
		return loginDetails;
	}
	public void setLoginDetails(LoginData loginDetails) {
		this.loginDetails = loginDetails;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	private String radio;
	private String password;
	
	private WalletListResponseData[] txnResponse;
	
	public String getTransactionData() {
		return transactionData;
	}
	public void setTransactionData(String transactionData) {
		this.transactionData = transactionData;
	}
	public String getPortalId() {
		return portalId;
	}
	public void setPortalId(String portalId) {
		this.portalId = portalId;
	}
	public String getVpin() {
		return vpin;
	}
	public void setVpin(String vpin) {
		this.vpin = vpin;
	}
	public Object getPayload() {
		return payload;
	}
	public void setPayload(Object payload) {
		this.payload = payload;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public Integer getVoucherValue() {
		return voucherValue;
	}
	public void setVoucherValue(Integer voucherValue) {
		this.voucherValue = voucherValue;
	}
	public String getTransactionTime() {
		return transactionTime;
	}
	public void setTransactionTime(String transactionTime) {
		this.transactionTime = transactionTime;
	}
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	public Integer getTransactionAmount() {
		return transactionAmount;
	}
	public void setTransactionAmount(Integer transactionAmount) {
		this.transactionAmount = transactionAmount;
	}
	public String getRefTransId() {
		return refTransId;
	}
	public void setRefTransId(String refTransId) {
		this.refTransId = refTransId;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getMpin() {
		return mpin;
	}
	public void setMpin(String mpin) {
		this.mpin = mpin;
	}
	public WalletListResponseData[] getTxnResponse() {
		return txnResponse;
	}
	public void setTxnResponse(WalletListResponseData[] txnResponse) {
		this.txnResponse = txnResponse;
	}
	public String getRadio() {
		return radio;
	}
	public void setRadio(String radio) {
		this.radio = radio;
	}
}
