package com.ng.sb.common.dataobject;

import java.util.List;
import java.util.Map;

public class FileExportData extends BaseObjectData {
	private static final long serialVersionUID = 1L;
	private Integer pinId;
	private String description;
	private List<FileExportDetailsData> fileDetails;
	private Map<Integer,String> pinTemplate;
	public List<FileExportDetailsData> getFileDetails() {
		return fileDetails;
	}
	public void setFileDetails(List<FileExportDetailsData> fileDetails) {
		this.fileDetails = fileDetails;
	}
	
	public Map<Integer, String> getPinTemplate() {
		return pinTemplate;
	}
	public void setPinTemplate(Map<Integer, String> pinTemplate) {
		this.pinTemplate = pinTemplate;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Integer getPinId() {
		return pinId;
	}
	public void setPinId(Integer pinId) {
		this.pinId = pinId;
	}

}
