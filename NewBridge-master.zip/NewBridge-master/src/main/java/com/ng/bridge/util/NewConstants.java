package com.ng.bridge.util;

public class NewConstants {
	
	public static final String INR = "INR";
	public static final String DEBITSUCCESFULMSG=" has been debited succesfully with amount ";
	public static final String WALLETHAVINGID= " wallet having id ";
	public static final String FORTRANSACTION= " for transaction." ;
	public static final String EXCEPTIONOCCURED="Exception occurred : ";
	public static final String BASICHTTPBINDING="BasicHttpBinding_IService1";
	public static final String TEMPURI="http://tempuri.org/";
	public static final String ENDADDRESS="javax.xml.rpc.service.endpoint.address";
	public static final String LOCALHOST="http://localhost:4471/";
	public static final String XMLSCHEMA="http://www.w3.org/2001/XMLSchema";
	public static final String STRING ="string";
	public static final String WEBSERVICETRANSSOAP="WebServiceV3TransSoap";
	public static final String WALLET=" wallet.";
	public static final String INSUFFICIENTBALMSG="insufficient balance in your ";
	public static final String INVALID="invalid ";
	public static final String WALLETUSED=" wallet used.";
	public static final String BANKING="BANKING";
	public static final String REGISTERED="REGISTERED";
	public static final String TRANSACTIONID="TransactionId : ";
	public static final String WALLETS="WALLET";
	public static final String OTHER="OTHER";
	public static final String AIRTEL="AIRTEL";
	public static final String AIRCEL="AIRCEL";
	public static final String TATAPOWER="TATAPOWER";
	public static final String CHECKPARTNERSINSTRUMENTMSG=" Now check whether Its Partners provides the same Instrument require for this call ";
	public static final String STR_VALUE="strPassword";
	private NewConstants(){}
}
