/**
 * 
 */
package com.ng.sb.common.jms;

import javax.annotation.PostConstruct;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.stereotype.Component;

import com.ng.sb.common.dataobject.CommissionInfosResponse;
import com.ng.sb.common.util.TransactionUtils;

/**
 * @author gopal
 *
 */
@Component
public class MessageSender {
	private static final Logger LOGGER = LoggerFactory.getLogger(MessageSender.class);
	@Autowired
    JmsTemplate jmsTemplate;
 
    public boolean sendMessage(final JmsMessage messageObject) 
    {
    	boolean messageSendingStatus = false;
    	try
    	{
 
        jmsTemplate.send(new MessageCreator(){
                @Override
                public Message createMessage(Session session) throws JMSException{
                	return session.createObjectMessage(messageObject);
                	}
            });
        
        messageSendingStatus = true;
        
    	}catch(RuntimeException e)
    	{
    		LOGGER.info(""+e);
    	}
    	
    	return messageSendingStatus;
    }
    
}
