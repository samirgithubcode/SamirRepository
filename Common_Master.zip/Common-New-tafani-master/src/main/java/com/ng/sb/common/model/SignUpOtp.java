package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;


@Entity
@Table(name = "signupOtp")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "SignUpOtp.findAll", query = "SELECT o FROM SignUpOtp o"),
    @NamedQuery(name = "SignUpOtp.findByMobileNumberAndStatus", query = "SELECT o FROM SignUpOtp o WHERE o.mobileNumber = :mobileNumber AND o.status=1"),
})
public class SignUpOtp implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
   
    @Basic(optional = false)
    @Column(name = "mobileNumber")
    private String mobileNumber;
    @Basic(optional = false)
    @Column(name = "currentTime", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date currentTime;
    @Column(name = "otp", length = 10)
    private Integer otpp;
    @Basic(optional = false)
    @Column(name = "status")
    private Integer status;
    @Basic(optional = false)
    @Column(name = "email")
    private String email;
    @Basic(optional = false)
    @Column(name = "password")
    private String password;
    @Column(name="DateOfBirth")
    private String dob;

	public SignUpOtp() {
		//default constructor
    }

    public SignUpOtp(Integer id) {
        this.id = id;
    } 

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}



    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getCurrentTime() {
        return currentTime;
    }

    public void setCurrentTime(Date currentTime) {
        this.currentTime = currentTime;
    }


	
	
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof SignUpOtp)) {
            return false;
        }
        SignUpOtp other = (SignUpOtp) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.Otp[ id=" + id + " ]";
    }

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public Integer getOtpp() {
		return otpp;
	}

	public void setOtpp(Integer otpp) {
		this.otpp = otpp;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}
    
}
