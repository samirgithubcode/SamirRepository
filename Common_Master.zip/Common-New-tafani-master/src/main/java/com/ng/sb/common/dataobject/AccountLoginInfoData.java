package com.ng.sb.common.dataobject;

import java.util.Map;

public class AccountLoginInfoData extends BaseObjectData{
	
	private static final long serialVersionUID = 1L;
	private String loginName;
	private String userName;
	private String mobileNumber;
	private String hostName;
    private String distributerName;
    private String subdistributerName;
    private String agentName;
    private Integer accountId;
    private Map<String,Long> seMapForAgent;
  
    public Integer getAccountId() {
		return accountId;
	}
	public void setAccountId(Integer accountId) {
		this.accountId = accountId;
	}
    public Map<String, Long> getSeMapForAgent() 
    {
    	return seMapForAgent;
    }
    public void setSeMapForAgent(Map<String, Long> seMapForAgent) 	
    {
    	this.seMapForAgent = seMapForAgent;
    }
	public String getAgentName() {
		return agentName;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}

	public String getHostName() {
		return hostName;
	}

	public void setHostName(String hostName) {
		this.hostName = hostName;
	}

	public String getDistributerName() {
		return distributerName;
	}

	public void setDistributerName(String distributerName) {
		this.distributerName = distributerName;
	}

	public String getSubdistributerName() {
		return subdistributerName;
	}

	public void setSubdistributerName(String subdistributerName) {
		this.subdistributerName = subdistributerName;
	}

	
   
	public String getLoginName() {
		return loginName;
	}


	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	
    public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	
}
