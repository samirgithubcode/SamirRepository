package com.ng.bridge.dataobject.eko;

public class GetCustomerResLimit {
	private String remaining;

    private String name;

    private String used;

    public String getRemaining ()
    {
        return remaining;
    }

    public void setRemaining (String remaining)
    {
        this.remaining = remaining;
    }

    public String getName ()
    {
        return name;
    }

    public void setName (String name)
    {
        this.name = name;
    }

    public String getUsed ()
    {
        return used;
    }

    public void setUsed (String used)
    {
        this.used = used;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [remaining = "+remaining+", name = "+name+", used = "+used+"]";
    }
}
