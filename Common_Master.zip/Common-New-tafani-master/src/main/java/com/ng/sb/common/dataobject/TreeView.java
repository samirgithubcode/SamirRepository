package com.ng.sb.common.dataobject;

import java.util.List;

public class TreeView {
private static final long serialVersionUID = 1L;
private String text;
private List<Integer> tags;
private List<TreeView> nodes;
public String getText() {
	return text;
}
public void setText(String text) {
	this.text = text;
}
public List<TreeView> getNodes() {
	return nodes;
}
public void setNodes(List<TreeView> nodes) {
	this.nodes = nodes;
}
public List<Integer> getTags() {
	return tags;
}
public void setTags(List<Integer> tags) {
	this.tags = tags;
}



}
