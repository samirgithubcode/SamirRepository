/**
 * 
 */
package com.ng.user.dto;

import org.hibernate.validator.constraints.NotBlank;

import com.ng.sb.common.dataobject.ValidationBean;
import com.ng.sb.common.util.UserType;

/**
 * @author gopal
 *
 */
public class LoginRequset implements ValidationBean {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4819614103242294524L;

	@NotBlank(message="Channel Id cannot be blank")
	private String channelId;
	
	
	private int userTypeId = UserType.AGENT.getUserTypeId();
	
	@NotBlank(message="User Id cannot be blank")
	private String userId;
	
	@NotBlank(message="Password cannot be blank")
	private String passwd;
	
	private String deviceId;

	private String skuId;

	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public int getUserTypeId() {
		return userTypeId;
	}

	public void setUserTypeId(int userTypeId) {
		this.userTypeId = userTypeId;
	}
	
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getPasswd() {
		return passwd;
	}

	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getSkuId() {
		return skuId;
	}

	public void setSkuId(String skuId) {
		this.skuId = skuId;
	}
	
	
	
}
