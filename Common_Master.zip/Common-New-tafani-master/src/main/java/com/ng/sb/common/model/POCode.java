package com.ng.sb.common.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="poCode")
@NamedQueries({
	@NamedQuery(name="POCode.maxId",query="SELECT max(code) FROM POCode o"),
	@NamedQuery(name="POCode.findAll",query="SELECT o FROM POCode o"),
	@NamedQuery(name="POCode.updateAll",query=" UPDATE POCode p SET p.code=:poCode where p.id=1")
})
public class POCode {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false)
	private Integer id;
	@Column(name="poCode")
	private Integer code;
	@Column(name="version")
	private Integer version;
	
	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	
	public Integer getCode() {
		return code;
	}

	public void setCode(Integer code) {
		this.code = code;
	}

	@Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }
	
	@Override
	public String toString() {
		return "POCode [id=" + id + "]";
	}

	

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof POCode)) {
            return false;
        }
        POCode other = (POCode) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

}
