/**
 * 
 */
package com.ng.user.rest;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ng.sb.common.cache.MemCacheManager;
import com.ng.sb.common.cache.MemCacheUtils;
import com.ng.sb.common.dataobject.AuthCacheRequest;
import com.ng.sb.common.dataobject.RequestObject;
import com.ng.sb.common.dataobject.ResponseObject;
import com.ng.sb.common.dataobject.UserAccountData;
import com.ng.sb.common.util.ErrorCodes;
import com.ng.sb.common.util.ExceptionUtils;
import com.ng.sb.common.util.KeyEncryptionUtils;
import com.ng.sb.common.util.ProcessFiledError;
import com.ng.sb.common.util.SystemConstant;
import com.ng.sb.common.util.UserType;
import com.ng.user.dto.TxnHistoryRequest;
import com.ng.user.logger.UserServiceLogger;
import com.ng.user.service.IAccountService;
import com.ng.user.utils.CommonUtils;
import com.ng.user.utils.UserServiceConstants;

/**
 * @author gopal
 *
 */
@RestController
@RequestMapping("user/account/")
public class AccountController {

	@Autowired
    private MemCacheManager cacheManager;
	
	@Autowired	
	ProcessFiledError fieldError;
	
	@Autowired
	IAccountService accountService;
	
	@RequestMapping(value = "/txnHistory", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	public @ResponseBody ResponseObject getUserTransactionHistory(@RequestBody RequestObject requestObject, HttpServletRequest request) 
	{
		UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.INFO,  UserServiceConstants.LOGGING_REQUEST + UserServiceConstants.LOGGING_METHOD_NAME +Thread.currentThread().getStackTrace()[1].getMethodName()+ UserServiceConstants.LOGGING_TOKEN_STRING +requestObject.getTokenId()+ UserServiceConstants.LOGGING_REQUEST_FROM +request.getRemoteAddr() + UserServiceConstants.LOGGING_USER_ADDRESS + request.getHeader(SystemConstant.USER_IP_ADDRESS));
		
		System.out.println("request.getRequestURI() :" +request.getRequestURI());
		
		System.out.println("request.getRequestURL() :" +request.getRequestURL());
		
        ResponseObject responseObject = new ResponseObject();
		
		/* 
		 * Get Agent details from tokenId
		 * requestObject.getTokenId()
		 * 
		 */
        TxnHistoryRequest txnHistoryRequest = null;
		Object payload =  requestObject.getPayload();
		UserAccountData accountData = null;
		
			try
			{
				//Check token Validity
				accountData = cacheManager.getFromCache(requestObject.getTokenId(), UserAccountData.class, MemCacheUtils.AUTHTOKENCACHE);
				
				if(accountData.getUserType() == UserType.AGENT.getUserTypeId())
					responseObject = CommonUtils.validateRequest(accountData, requestObject, request, true);
				else
					responseObject = CommonUtils.validateRequest(accountData, requestObject, request, false);
				
				if(responseObject.getStatus() != null)
					return responseObject;
				
				txnHistoryRequest = KeyEncryptionUtils.jsonStringToObject(KeyEncryptionUtils.decryptUsingKey(accountData.getSecretKey(), payload), TxnHistoryRequest.class);
				
			    responseObject = CommonUtils.validateRequestData(txnHistoryRequest, requestObject, request);
				
			    if(txnHistoryRequest == null || responseObject.getStatus() != null)
					return responseObject;
			    
				txnHistoryRequest.setAgentId(accountData.getId());
				txnHistoryRequest.setUserTypeId(accountData.getUserType());
							  
							responseObject = accountService.getTxnHistory(txnHistoryRequest);
								
							if(responseObject != null && responseObject.getPayload() != null)
								{
									String encryptedString = KeyEncryptionUtils.encryptUsingKey(accountData.getSecretKey(), responseObject.getPayload());
									responseObject.setPayload(encryptedString);
								}
							
							UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.INFO,  UserServiceConstants.LOGGING_RESPONSE  + UserServiceConstants.LOGGING_METHOD_NAME +Thread.currentThread().getStackTrace()[1].getMethodName());
				 
			}catch(Exception e)
			{
				String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), null);
				
				UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME +Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE +e.getMessage()+UserServiceConstants.LOGGGING_CLASS_NAME +exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME +exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME +exceptionData[2]+ UserServiceConstants.LOGGING_LINE_NUMBER +exceptionData[3]);
				
			}	
			
		return responseObject;
	}

	@RequestMapping(value = "/resetPassword", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	public @ResponseBody ResponseObject resetPassword(@RequestBody RequestObject requstObject, HttpServletRequest request) 
	{
		return null;
	}
	
	@RequestMapping(value = "/updateAuthorizationCache", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	public @ResponseBody ResponseObject updateAuthorizationCache(@RequestBody AuthCacheRequest authCacheRequest, HttpServletRequest request) 
	{
		UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.INFO,  UserServiceConstants.LOGGING_REQUEST + UserServiceConstants.LOGGING_METHOD_NAME +Thread.currentThread().getStackTrace()[1].getMethodName()+ UserServiceConstants.LOGGING_TOKEN_STRING +authCacheRequest.getTokenId()+ UserServiceConstants.LOGGING_REQUEST_FROM +request.getRemoteAddr() + UserServiceConstants.LOGGING_USER_ADDRESS + request.getHeader(SystemConstant.USER_IP_ADDRESS));
		
		ResponseObject responseObject = new ResponseObject();
		
		try{
			if(authCacheRequest.getAccountTypeIds() == null || authCacheRequest.getActionUrl() == null || authCacheRequest.getActionType() == null)
			{
				responseObject.setStatus(ErrorCodes.REQUIRED_PARAMETERS_MISSING.getCode());
				responseObject.setMessage(ErrorCodes.REQUIRED_PARAMETERS_MISSING.getMessage());
				
				return responseObject ;
			}
			
			UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.INFO,  UserServiceConstants.LOGGING_REQUEST + UserServiceConstants.LOGGING_METHOD_NAME +Thread.currentThread().getStackTrace()[1].getMethodName()+ " [ACTION_URL] "+authCacheRequest.getActionUrl()+" [ACCOUNT_TYPE_ID] "+authCacheRequest.getAccountTypeIds()+" [ACTION_TYPE] "+authCacheRequest.getActionType() );
			
			switch(authCacheRequest.getActionType().toUpperCase())
			{
			case "ADD":
			case "UPDATE":
				cacheManager.addToCache(authCacheRequest.getActionUrl().toLowerCase(), authCacheRequest.getAccountTypeIds(), MemCacheUtils.AUTHORIZATIONCACHE);
				
				responseObject.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
				responseObject.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
				
				break;
				
			case "DELETE":
				cacheManager.removeFromCache(authCacheRequest.getActionUrl().toLowerCase(),  MemCacheUtils.AUTHORIZATIONCACHE);
				
				responseObject.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
				responseObject.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
				
				break;
				
				default:
					responseObject.setStatus(ErrorCodes.INVALID_REQUEST.getCode());
					responseObject.setMessage(ErrorCodes.INVALID_REQUEST.getMessage());
					break;	
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return responseObject;
	}
}
