package com.ng.sc.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Component;

import com.ng.sb.common.dataobject.LoginData;
import com.ng.sb.common.dataobject.LogoutData;
import com.ng.sb.common.dataobject.SubscriberData;
/**
 * 
 * @author 
 *
 */
@Component
public interface IScLoginService {

	
	/**
	 * @return
	 * @throws Exception
	 */
	public Map accountTypeMap(String accountType) ;
	public List accountGroup();
	public LoginData validateAccount(LoginData loginData) ;
	public LoginData setViewMessage(LoginData loginData,String view,String message);
	public LoginData getSessionInfo(HttpSession session);
	public LogoutData logout(LoginData loginData, HttpSession session);
	public Map getSecurityQuestion();
	public Integer validatePassExp(String username, Date date);
	public SubscriberData submitUserCreationData(SubscriberData subscriberData) ;
	public String generateEncryptedPassword(String userPassword);
	public List getAllRoleAccountList(Integer loginWeightage);
	public Map getCountryCodeMap();
	public Integer getOtpOnSignUp(String mobileNo);
	public void saveSignupDetails(SubscriberData subscriberData, Integer otp) ;
	public Integer getActiveOtp(String mobile);
	public void updateSignUpDetails(String mobile);
	public void updateTimeoutOtp(int otp);
}
