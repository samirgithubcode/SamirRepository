
//Function for check excel file or not using extension
function checkExcelFile(fieldId, errorid) {
	// ***************************** Code for check file extension
	// ****************************
	var ext = $('#' + fieldId).val().split('.').pop().toLowerCase();
	if ($.inArray(ext, [ 'xlsx' ]) == -1) {
		$('#' + errorid)
				.html(
						"<b><font color='red'>Kindly upload file having extension .xlsx !</font></b>");
		$('#' + fieldId).val('');
		return false;
	}
	// ***************************** Code for check file size
	// ****************************
	var fileSize = $('#' + fieldId)[0].files[0].size;
	var fileSizeKB = Math.round(parseInt(fileSize) / 1024);
	if (fileSizeKB > 5000) {
		$('#' + errorid)
				.html(
						"<b><font color='red'>Kindly upload file having size less than 5MB !</font></b>");
		$('#' + fieldId).val('');
		return false;
	}
	$('#' + errorid).html("");
}

//Function for inventor excel file upload submit
function validateUploadExcelFilePage(event){
	var poNo=$('#poNo').val();
	var uploadFilePath=$('#uploadFilePath').val();
	
	if(uploadFilePath.length <= 0)
	{
		$('#upload_ErrorId').html("<b><font color='red'>Kindly browse inventory excel file !</font></b>");
		completeCheck = false;
	}else{
		$('#upload_ErrorId').html("");
	}
	
	if(poNo.length <= 0)
	{
		$('#poNoErrorId').html("<b><font color='red'>Kindly select PO Number !</font></b>");
		completeCheck = false;
	}
	else{
		$('#poNoErrorId').html("");
	}
	if(!completeCheck){
		event.preventDefault();
		return false;
	}
	
}


function getpath(uploadFilePath)
{
//	alert($('#'+uploadFilePath).val());
}