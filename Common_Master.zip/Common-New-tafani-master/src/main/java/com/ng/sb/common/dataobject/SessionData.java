package com.ng.sb.common.dataobject;



public class SessionData  extends BaseObjectData{
	private static final long serialVersionUID = 1L;
	private int accountSessionCount;
	public int getAccountSessionCount() {
		return accountSessionCount;
	}
	public void setAccountSessionCount(int accountSessionCount) {
		this.accountSessionCount = accountSessionCount;
	}
	
	
}
