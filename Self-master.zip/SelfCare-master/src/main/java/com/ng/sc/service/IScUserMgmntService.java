package com.ng.sc.service;

import java.sql.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.ng.sb.common.dataobject.AddressInfo;
import com.ng.sb.common.dataobject.LoginData;
import com.ng.sb.common.dataobject.SubscriberData;
import com.ng.sb.common.dataobject.TransactionRequestData;
import com.ng.sb.common.dataobject.WalletRequest;
import com.ng.sb.common.model.Otp;

public interface IScUserMgmntService extends ISelfCareService {
	
	
	public Date convertStringToSqlDate(String dob)throws Exception;
	public void checkAndChangePassword(SubscriberData subscriberData,Integer subscriberId, HttpSession session) throws Exception;
	public Map<String,Integer> checkEmailDobAns(String emailorusername,String date,String answer)throws Exception;
	public SubscriberData setForgetedPassword(SubscriberData subscriberData)throws Exception;
	
	public SubscriberData forgetedPassword(SubscriberData subscriberData)throws Exception;
	public Map getCountryCodeMap();
	public int subscriberExists(String mobile, String dob, String emailId,String userPassword) throws Exception;
	public SubscriberData submitSubscriberPersonalInfo(SubscriberData subscriberData,Integer subscriberId) throws Exception;
	public SubscriberData submitUserProfileAddress(SubscriberData subscriberData, Integer userLoginId) throws Exception;
	public SubscriberData getOtpOnForgotPass(String mobileNo, String dateOfBirth) throws Exception;
	public void updateTimeoutOtp(Otp otp, String status) throws Exception;
	public List<AddressInfo> fetchAddress(String pinCode) throws Exception;
	public SubscriberData getProfilesById(Integer subscriberId) throws Exception;
	public SubscriberData getwalletdetails(SubscriberData subscriberData) throws Exception;
	public SubscriberData getproducttype(SubscriberData subscriberData) throws Exception;
	public Map<Integer, String> getsubquerylist(String productType) throws Exception;
	public TransactionRequestData transactionView(TransactionRequestData transactionRequestData, HttpSession session) throws Exception;
	public Map getWalletList(String loginId) throws Exception;
	public WalletRequest walletToWalletView(WalletRequest walletRequestData, HttpSession session, Integer confirmOtp) throws Exception;
	public Integer saveMyQuery(SubscriberData subscriberData, String mobileNo) throws Exception;
	public int checkfiled(String value, String tablename, String field) throws Exception;
	public void validateOtp(String mobileNo,String dateOfBirth, Integer otp) throws Exception;
	public SubscriberData getWalletDetailList(LoginData loginData, HttpSession session) throws Exception;
	public List<SubscriberData> queryStatus(HttpSession session, String mobileNo, TransactionRequestData transactionRequestData);
	public Integer saveTransactionIssue(String instrument, String id, String remarks, LoginData loginData, String subqueryid);
	public String getfindUrlList(Integer subqueryid);
	public SubscriberData getAllDetails(SubscriberData subscriberData);
	public Map<Integer, String> getproducttype(String subscriberMobNo);
	public String getqueryPUK(String productId, LoginData loginData);
	public SubscriberData getProductDetails(SubscriberData subscriberData);
	public boolean productsInfo(String productId, String mobileNumber, String comment);
	public SubscriberData getproductList(SubscriberData subscriberData);
	public List<SubscriberData> queryStatus(HttpSession session, String subscriberMobNo) throws Exception;
	public String getTypeOfDeployment();
	public void saveNewPinCode(SubscriberData subscriberData);
	public boolean validateOtpPassword(LoginData loginData, String confirmOtp,String userMobile);
	public boolean sendOtpforWallet(LoginData loginData, String userMobile);
	public boolean checkWallet(String userMobile, String walletId);
	public int subscriberAlreadySignedUp(String mobile) throws Exception;
	
	SubscriberData getSubscriberByMobileNumber(String mobileNumber)throws Exception;
	
	public void checkAndChangeWalletPin(SubscriberData subscriberData,Integer subscriberId, HttpSession session) throws Exception;
	public SubscriberData ChangeWalletPin(SubscriberData subscriberData, Integer subscriberid);
}
