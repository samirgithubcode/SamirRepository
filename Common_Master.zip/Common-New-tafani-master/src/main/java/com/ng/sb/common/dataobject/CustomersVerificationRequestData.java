/**
 * 
 */
package com.ng.sb.common.dataobject;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author gaurav
 *
 */
@XmlRootElement(name = "CustomersVerificationRequestData")
public class CustomersVerificationRequestData extends PlatformRequestData {
	private static final long serialVersionUID = 1L;
	private List<CustomerVerificationRequestData> custVerificationList;
	public List<CustomerVerificationRequestData> getCustVerificationList() {
		return custVerificationList;
	}
	public void setCustVerificationList(List<CustomerVerificationRequestData> custVerificationList) {
		this.custVerificationList = custVerificationList;
	}
	
}
