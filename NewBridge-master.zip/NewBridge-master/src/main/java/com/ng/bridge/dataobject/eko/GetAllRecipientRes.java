package com.ng.bridge.dataobject.eko;

public class GetAllRecipientRes {
	private String responseTypeId;

    private String message;

    private String responseStatusId;

    private String status;

    private GetAllRecipientData data;

    
 

    public String getResponseStatusId ()
    {
        return responseStatusId;
    }

    public void setResponseStatusId (String responseStatusId)
    {
        this.responseStatusId = responseStatusId;
    }
    public String getResponseTypeId ()
    {
        return responseTypeId;
    }

    public void setResponseTypeId (String responseTypeId)
    {
        this.responseTypeId = responseTypeId;
    }

    public String getStatus ()
    {
        return status;
    }

    public void setStatus (String status)
    {
        this.status = status;
    }
    public String getMessage ()
    {
        return message;
    }

    public void setMessage (String message)
    {
        this.message = message;
    }

   



	public GetAllRecipientData getData() {
		return data;
	}

	public void setData(GetAllRecipientData data) {
		this.data = data;
	}


}
