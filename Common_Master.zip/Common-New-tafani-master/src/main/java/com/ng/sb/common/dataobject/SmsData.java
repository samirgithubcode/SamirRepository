package com.ng.sb.common.dataobject;

public class SmsData extends BaseObjectData{

	private static final long serialVersionUID = 1L;
	
	String contactNo;
	String message;
	String extnCode;
	
	public String getExtnCode() {
		return extnCode;
	}
	public void setExtnCode(String extnCode) {
		this.extnCode = extnCode;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
}
