package com.ng.sb.common.dataobject;

/**
 * @author gaurav
 *
 */
public class IMPS extends BaseObjectData {
	private static final long serialVersionUID = 1L;
	private String mmid;
	private String mPin;
	private String accountId;
	private String ifsc;
	

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getIfsc() {
		return ifsc;
	}

	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}

	public String getMmid() {
		return mmid;
	}

	public void setMmid(String mmid) {
		this.mmid = mmid;
	}

	public String getmPin() {
		return mPin;
	}

	public void setmPin(String mPin) {
		this.mPin = mPin;
	}

}
