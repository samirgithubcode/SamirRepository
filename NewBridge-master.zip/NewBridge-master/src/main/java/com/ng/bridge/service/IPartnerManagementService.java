/**
 * 
 */
package com.ng.bridge.service;

import com.ng.sb.common.dataobject.BridgeDataObject;
import com.ng.sb.common.exception.BridgeObjectDataException;

/**
 * @author gaurav
 *
 */
@FunctionalInterface
public interface IPartnerManagementService {

	public BridgeDataObject partnerExecution(BridgeDataObject bridgeDataObject) throws BridgeObjectDataException;
}
