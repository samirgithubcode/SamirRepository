package com.ng.sb.common.dataobject;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class ServiceData implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int paymentServiceId;
	private String paymentServiceName;
	private String stkCode;
	private String controllerPath;
	private String className;
	private String methodName;
	private String serviceType;
	private boolean validationReq;
	private boolean status;
	private HostFeeData hostFeeDatas;
	private List<ServiceParamMappingData> serviceParamMappingDatas;
	private Map<Integer,ServiceProviderData> serviceProviderDatas;
	
	public int getPaymentServiceId() {
		return paymentServiceId;
	}
	public void setPaymentServiceId(int paymentServiceId) {
		this.paymentServiceId = paymentServiceId;
	}
	public String getPaymentServiceName() {
		return paymentServiceName;
	}
	public void setPaymentServiceName(String paymentServiceName) {
		this.paymentServiceName = paymentServiceName;
	}
	public String getStkCode() {
		return stkCode;
	}
	public void setStkCode(String stkCode) {
		this.stkCode = stkCode;
	}
	public String getControllerPath() {
		return controllerPath;
	}
	public void setControllerPath(String controllerPath) {
		this.controllerPath = controllerPath;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public String getMethodName() {
		return methodName;
	}
	public void setMethodName(String methodName) {
		this.methodName = methodName;
	}
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public boolean isValidationReq() {
		return validationReq;
	}
	public void setValidationReq(boolean validationReq) {
		this.validationReq = validationReq;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public HostFeeData getHostFeeDatas() {
		return hostFeeDatas;
	}
	public void setHostFeeDatas(HostFeeData hostFeeDatas) {
		this.hostFeeDatas = hostFeeDatas;
	}
	public List<ServiceParamMappingData> getServiceParamMappingDatas() {
		return serviceParamMappingDatas;
	}
	public void setServiceParamMappingDatas(
			List<ServiceParamMappingData> serviceParamMappingDatas) {
		this.serviceParamMappingDatas = serviceParamMappingDatas;
	}
	public Map<Integer, ServiceProviderData> getServiceProviderDatas() {
		return serviceProviderDatas;
	}
	public void setServiceProviderDatas(
			Map<Integer, ServiceProviderData> serviceProviderDatas) {
		this.serviceProviderDatas = serviceProviderDatas;
	}
}
