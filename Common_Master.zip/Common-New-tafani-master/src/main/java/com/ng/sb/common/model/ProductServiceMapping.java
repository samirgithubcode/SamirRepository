package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name="product_service_mapping")
@XmlRootElement
@NamedQueries({
	
	  @NamedQuery(name = "ProductServiceMapping.findAll", query = "SELECT p FROM ProductServiceMapping p"),
	  @NamedQuery(name = "ProductServiceMapping.findAllById", query = "SELECT p FROM ProductServiceMapping p where p.addedBy=:addedBy"),
	  @NamedQuery(name = "ProductServiceMapping.findAllByproductid", query = "SELECT p FROM ProductServiceMapping p where p.productId=:productId"),
	
	
})


public class ProductServiceMapping implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true,nullable=false)
	private int id;
	
	@ManyToOne
	@JoinColumn(name="product_id",referencedColumnName="id")
	private Products productId;
	
	@ManyToOne
	@JoinColumn(name="instrument_id",referencedColumnName="id")
	private FinancialInstruments instrumentId;
	
	@ManyToOne
	@JoinColumn(name="instrument_service_id", referencedColumnName="id")
	private FinancialServices instrumentserviceId;
	
	@Column(name="start_date")
	@Temporal(TemporalType.DATE)
	private Date startDate;

	@Column(name="modifiedBy",length=8)
    private int modifiedBy;

	@Column(name="addedBy",length=8)
	private int addedBy;
	@Column(name="end_date")
	@Temporal(TemporalType.DATE)
	private Date endDate;
	@Column(name="addedOn")
    @Temporal(TemporalType.DATE)
	private Date addedOn;
	
	
	
	@Column(name="modifiedOn")
    private Date modifiedOn;
	
	
	@Column(name="status",length=1)
	private boolean status;
	
	
	 public ProductServiceMapping() {
		//empty
	}

	@Override
	public int hashCode() {
		 int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProductServiceMapping other = (ProductServiceMapping) obj;
		boolean check=true;
		if (id != other.id)
			check= false;
		return check;
	}
	
	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Products getProductId() {
		return productId;
	}

	public void setProductId(Products productId) {
		this.productId = productId;
	}

	public FinancialInstruments getInstrumentId() {
		return instrumentId;
	}

	public void setInstrumentId(FinancialInstruments instrumentId) {
		this.instrumentId = instrumentId;
	}

	public FinancialServices getInstrumentserviceId() {
		return instrumentserviceId;
	}

	public void setInstrumentserviceId(FinancialServices instrumentserviceId) {
		this.instrumentserviceId = instrumentserviceId;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public int getAddedBy() {
		return addedBy;
	}

	public void setAddedBy(int addedBy) {
		this.addedBy = addedBy;
	}

	public Date getAddedOn() {
		return addedOn;
	}

	public void setAddedOn(Date addedOn) {
		this.addedOn = addedOn;
	}

	public int getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(int modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	
	
	
}
