package com.ng.sb.common.dataobject;

import java.util.List;

public class SwitchTransactionServiceData extends BaseObjectData{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	List<TransactionServiceData> transactionServiceData;
	Integer debitAmount;
	Integer creditAmount;
	Integer netAmount;
	public List<TransactionServiceData> getTransactionServiceData() {
		return transactionServiceData;
	}
	public void setTransactionServiceData(List<TransactionServiceData> transactionServiceData) {
		this.transactionServiceData = transactionServiceData;
	}
	
	public Integer getCreditAmount() {
		return creditAmount;
	}
	public void setCreditAmount(Integer creditAmount) {
		this.creditAmount = creditAmount;
	}
	
	public Integer getDebitAmount() {
		return debitAmount;
	}
	public void setDebitAmount(Integer debitAmount) {
		this.debitAmount = debitAmount;
	}
	
	public Integer getNetAmount() {
		return netAmount;
	}
	public void setNetAmount(Integer netAmount) {
		this.netAmount = netAmount;
	}
}
