/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author amardeep
 */
@Entity
@Table(name = "Provider")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Provider.findAll", query = "SELECT p FROM Provider p"),
    @NamedQuery(name = "Provider.findById", query = "SELECT p FROM Provider p WHERE p.id = :id"),
    @NamedQuery(name = "Provider.findByName", query = "SELECT p FROM Provider p WHERE p.name = :name"),
    @NamedQuery(name = "Provider.findByProviderCode", query = "SELECT p FROM Provider p WHERE p.providerCode = :providerCode"),
    @NamedQuery(name = "Provider.findByDesc", query = "SELECT p FROM Provider p WHERE p.description = :desc"),
    @NamedQuery(name = "Provider.findByDescription", query = "SELECT p FROM Provider p WHERE p.description = :description"),
    @NamedQuery(name = "Provider.findByCreateDate", query = "SELECT p FROM Provider p WHERE p.createDate = :createDate"),
    @NamedQuery(name = "Provider.findByEditDate", query = "SELECT p FROM Provider p WHERE p.editDate = :editDate"),
    @NamedQuery(name = "Provider.findMaxProviderCode", query = "SELECT MAX(a.providerCode) FROM Provider a"),
    @NamedQuery(name = "Provider.findByStatus", query = "SELECT p FROM Provider p WHERE p.status = :status"),
    @NamedQuery(name = "Provider.findCountByName", query = "SELECT n FROM Provider n WHERE n.name = :name"),
    @NamedQuery(name = "Provider.countbyproviderName", query = "SELECT count(*) FROM Provider p WHERE p.name =:name"),
    @NamedQuery(name = "Provider.countbyproviderNameandId", query = "SELECT count(*) FROM Provider p WHERE p.name =:name and p.id =:id"),
    @NamedQuery(name = "Provider.findAllProviderName", query = "SELECT a.name FROM Provider a where a.name LIKE :name"),
    })
public class Provider implements Serializable {
	private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "name")
    private String name;
    @Basic(optional = false)
    @Column(name = "providerCode")
    private int providerCode;
    @Column(name = "description")
    private String description;
    @Basic(optional = false)
    @Column(name = "createDate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createDate;
    @Column(name = "editDate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date editDate;
    @Basic(optional = false)
    @Column(name = "status")
    private boolean status;
    @Column(name = "contactDetail")
    private String contactDetail;
    @Column(name = "alterContactDetail")
    private String altContactDetail; 
    @ManyToOne
    @JoinColumn(name="countryCodeId", referencedColumnName="id")
    private CountryCode countryCodeId;
	@ManyToOne
    @JoinColumn(name="altCountryCodeId", referencedColumnName="id")
    private CountryCode altCountryCodeId;
    
    @Column(name = "email")
    private String emailId;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "providerId")
    private Collection<CategoryProviderMapping> categoryProviderMappingCollection;
    @OneToMany(mappedBy = "providerId")
    private Collection<HostSVProviderPartnerMapping> hostSVProviderPartnerMappingCollection;
    @OneToMany(mappedBy = "providerId")
    private Collection<CommProvPartMapping> commConfProvPartMappingCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "providerId")
    private Collection<MasterVersionCategory> masterVersionCategoryCollection;
    @OneToMany(mappedBy = "providerId")
    private Collection<PartnerProviderMapping> partnerProviderMappingCollection;
	

    public Provider() {
    	//default constructor
    }

    public Provider(Integer id) {
        this.id = id;
    }

    public Provider(Integer id, String name, int providerCode, Date createDate, boolean status) {
        this.id = id;
        this.name = name;
        this.providerCode = providerCode;
        this.createDate = createDate;
        this.status = status;
    }
    public CountryCode getCountryCodeId() {
		return countryCodeId;
	}

	public void setCountryCodeId(CountryCode countryCodeId) {
		this.countryCodeId = countryCodeId;
	}

	public CountryCode getAltCountryCodeId() {
		return altCountryCodeId;
	}

	public void setAltCountryCodeId(CountryCode altCountryCodeId) {
		this.altCountryCodeId = altCountryCodeId;
	}


    public String getContactDetail() {
		return contactDetail;
	}

	public void setContactDetail(String contactDetail) {
		this.contactDetail = contactDetail;
	}

	public String getAltContactDetail() {
		return altContactDetail;
	}

	public void setAltContactDetail(String altContactDetail) {
		this.altContactDetail = altContactDetail;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	



    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getProviderCode() {
        return providerCode;
    }

    public void setProviderCode(int providerCode) {
        this.providerCode = providerCode;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getEditDate() {
        return editDate;
    }

    public void setEditDate(Date editDate) {
        this.editDate = editDate;
    }

    public boolean getStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    @XmlTransient
    public Collection<CategoryProviderMapping> getCategoryProviderMappingCollection() {
        return categoryProviderMappingCollection;
    }

    public void setCategoryProviderMappingCollection(Collection<CategoryProviderMapping> categoryProviderMappingCollection) {
        this.categoryProviderMappingCollection = categoryProviderMappingCollection;
    }


    @XmlTransient
    public Collection<HostSVProviderPartnerMapping> getHostSVProviderPartnerMappingCollection() {
        return hostSVProviderPartnerMappingCollection;
    }

    public void setHostSVProviderPartnerMappingCollection(Collection<HostSVProviderPartnerMapping> hostSVProviderPartnerMappingCollection) {
        this.hostSVProviderPartnerMappingCollection = hostSVProviderPartnerMappingCollection;
    }

    @XmlTransient
    public Collection<CommProvPartMapping> getCommConfProvPartMappingCollection() {
        return commConfProvPartMappingCollection;
    }

    public void setCommConfProvPartMappingCollection(Collection<CommProvPartMapping> commConfProvPartMappingCollection) {
        this.commConfProvPartMappingCollection = commConfProvPartMappingCollection;
    }

    @XmlTransient
    public Collection<MasterVersionCategory> getMasterVersionCategoryCollection() {
        return masterVersionCategoryCollection;
    }

    public void setMasterVersionCategoryCollection(Collection<MasterVersionCategory> masterVersionCategoryCollection) {
        this.masterVersionCategoryCollection = masterVersionCategoryCollection;
    }

    @XmlTransient
    public Collection<PartnerProviderMapping> getPartnerProviderMappingCollection() {
        return partnerProviderMappingCollection;
    }

    public void setPartnerProviderMappingCollection(Collection<PartnerProviderMapping> partnerProviderMappingCollection) {
        this.partnerProviderMappingCollection = partnerProviderMappingCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
    	boolean check=false;
    	if(object!=null){
        if (!(object instanceof Provider)) {
        	check= false;
        }
        Provider other = (Provider) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
    	}
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.Provider[ id=" + id + " ]";
    }
}
