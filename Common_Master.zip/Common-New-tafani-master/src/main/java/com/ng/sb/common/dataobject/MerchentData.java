package com.ng.sb.common.dataobject;

import java.sql.Date;
import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;


/**
 * @author amardeep
 *
 */
public class MerchentData  extends BaseObjectData{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private List<String> merchantMobile;
	private String mobile;
	private String merchantCode;
	private String instrument;
	private Map<Integer, String> financialInstrument;
	private Integer mmid;
	private String bankAcc;
	private String ifsc;
	private String cardNo;
	private String cardHolderName;
	private Date exDate;
	private List<String> date;
	private List<String> yy;
	private String dates;
	private String yyyy;
	private String statusMsg;
	private Map<Integer, String> merchantWallet;
	private Integer walletId;
	private transient MultipartFile[] file;
	private String[] idNo;
	private Integer[] idProofCheck;
	
	public MultipartFile[] getFile() {
		return file;
	}
	public void setFile(MultipartFile[] file) {
		this.file = file;
	}

	public Integer[] getIdProofCheck() {
		return idProofCheck;
	}
	public void setIdProofCheck(Integer[] idProofCheck) {
		this.idProofCheck = idProofCheck;
	}
	public Integer getWalletId() {
		return walletId;
	}
	public void setWalletId(Integer walletId) {
		this.walletId = walletId;
	}
	public Map<Integer, String> getMerchantWallet() {
		return merchantWallet;
	}
	public void setMerchantWallet(Map<Integer, String> merchantWallet) {
		this.merchantWallet = merchantWallet;
	}
	public List<String> getMerchantMobile() {
		return merchantMobile;
	}
	public void setMerchantMobile(List<String> merchantMobile) {
		this.merchantMobile = merchantMobile;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getMerchantCode() {
		return merchantCode;
	}
	public void setMerchantCode(String merchantCode) {
		this.merchantCode = merchantCode;
	}
	public String getInstrument() {
		return instrument;
	}
	public void setInstrument(String instrument) {
		this.instrument = instrument;
	}
	public Map<Integer, String> getFinancialInstrument() {
		return financialInstrument;
	}
	public void setFinancialInstrument(Map<Integer, String> financialInstrument) {
		this.financialInstrument = financialInstrument;
	}
	public Integer getMmid() {
		return mmid;
	}
	public void setMmid(Integer mmid) {
		this.mmid = mmid;
	}
	public String getBankAcc() {
		return bankAcc;
	}
	public void setBankAcc(String bankAcc) {
		this.bankAcc = bankAcc;
	}
	public String getIfsc() {
		return ifsc;
	}
	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}
	public String getCardNo() {
		return cardNo;
	}
	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}
	public String getCardHolderName() {
		return cardHolderName;
	}
	public void setCardHolderName(String cardHolderName) {
		this.cardHolderName = cardHolderName;
	}
	public Date getExDate() {
		return exDate;
	}
	public void setExDate(Date exDate) {
		this.exDate = exDate;
	}
	public List<String> getDate() {
		return date;
	}
	public void setDate(List<String> date) {
		this.date = date;
	}
	public List<String> getYy() {
		return yy;
	}
	public void setYy(List<String> yy) {
		this.yy = yy;
	}
	public String getDates() {
		return dates;
	}
	public void setDates(String dates) {
		this.dates = dates;
	}
	public String getYyyy() {
		return yyyy;
	}
	public void setYyyy(String yyyy) {
		this.yyyy = yyyy;
	}
	public String getStatusMsg() {
		return statusMsg;
	}
	public void setStatusMsg(String statusMsg) {
		this.statusMsg = statusMsg;
	}
	public String[] getIdNo() {
		return idNo;
	}
	public void setIdNo(String[] idNo) {
		this.idNo = idNo;
	}
}
