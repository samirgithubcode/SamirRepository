/**
 * 
 */
package com.ng.sb.common.dataobject;

/**
 * @author gaurav
 * This class will hold Issuer Data - who issue the overlay product to customer.
 * OtherInfo is non-mandatory
 */
public class IssuerInfo extends BaseObjectData {

	private static final long serialVersionUID = 1L;
	private String mobileNumber;
	private OtherInfo otherInfo;
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public OtherInfo getOtherInfo() {
		return otherInfo;
	}
	public void setOtherInfo(OtherInfo otherInfo) {
		this.otherInfo = otherInfo;
	}
	
}
