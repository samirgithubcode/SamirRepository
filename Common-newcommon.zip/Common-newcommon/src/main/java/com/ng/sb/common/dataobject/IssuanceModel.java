package com.ng.sb.common.dataobject;



public class IssuanceModel {
	private NameObject name;
	private String lei;
	
	public IssuanceModel() {
		
	}
	
	public String getLei() {
		return lei;
	}
	public void setLei(String lei) {
		this.lei = lei;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("IssuanceModel [name=");
		builder.append(name);
		builder.append("],[lei=");
		builder.append(lei);
		builder.append("]");
		
		return builder.toString();
	}

	public NameObject getName() {
		return name;
	}

	public void setName(NameObject name) {
		this.name = name;
	}
	

}
