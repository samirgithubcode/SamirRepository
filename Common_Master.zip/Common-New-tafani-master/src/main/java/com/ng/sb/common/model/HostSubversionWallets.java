package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;
/**
*
* @author Simran
* 
* The persistent class for the HostSubversion wallets database table for OTA.
*/
@Entity
@Table(name = "hostsubversion_wallets")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "HostSubversionWallets.findByHsvId", query = "SELECT h FROM HostSubversionWallets h where h.hsvId = :hsvId"),
    @NamedQuery(name="HostSubversionWallets.findByHsvIdAndWalletId",query="SELECT h FROM HostSubversionWallets h where h.hsvId = :hsvId AND h.walletId=:walletId"),
    
})
public class HostSubversionWallets  implements Serializable {
	private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "walletName")
    private String walletName;
    @Column(name = "walletId")
    private Integer walletId;
    @Column(name = "partnerCode")
    private Integer partnerCode;
	@Column(name = "status")
    private String status;
    @Column(name = "hsvId")
    private Integer hsvId;
    @Column(name = "last_modified")
    @Temporal(TemporalType.TIMESTAMP)
    private Date modifiedDate;
    @Column(name = "createDate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createDate;
    @Column(name = "last_OTA_modified")
    @Temporal(TemporalType.TIMESTAMP)
    private Date otaModifiedDate;
    @Column(name = "modifiedBy")
    private Integer modifiedBy;
    @Column(name = "addedBy")
    private Integer addedBy;
    @Column(name = "scheduledDate") 
    @Temporal(TemporalType.DATE)
    private Date scheduledDate;
    public HostSubversionWallets() {
    	//default constructor
    }

    public HostSubversionWallets(Integer id) {
        this.id = id;
    }

    public HostSubversionWallets(Integer id, String walletName, Date createDate, Date modifiedDate, Date otaModifiedDate) {
        this.id = id;
        this.walletName = walletName;
        this.createDate = createDate;
        this.modifiedDate = modifiedDate;
        this.otaModifiedDate = otaModifiedDate;
    } 
    public Integer getId() {
		return id;
	}
    public Integer getPartnerCode() {
		return partnerCode;
	}

	public void setPartnerCode(Integer partnerCode) {
		this.partnerCode = partnerCode;
	}
	public void setId(Integer id) {
		this.id = id;
	}

	public String getWalletName() {
		return walletName;
	}

	public void setWalletName(String walletName) {
		this.walletName = walletName;
	}

	public Integer getWalletId() {
		return walletId;
	}

	public void setWalletId(Integer walletId) {
		this.walletId = walletId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	
	public Date getCreateDate() {
		return createDate;
	}

	

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public Integer getHsvId() {
		return hsvId;
	}

	public void setHsvId(Integer hsvId) {
		this.hsvId = hsvId;
	}

	public Date getOtaModifiedDate() {
		return otaModifiedDate;
	}

	public void setOtaModifiedDate(Date otaModifiedDate) {
		this.otaModifiedDate = otaModifiedDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}
	public Integer getAddedBy() {
		return addedBy;
	}

	public void setAddedBy(Integer addedBy) {
		this.addedBy = addedBy;
	}

	public Integer getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getScheduledDate() {
		return scheduledDate;
	}

	public void setScheduledDate(Date scheduledDate) {
		this.scheduledDate = scheduledDate;
	}

	@Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof HostSubversionWallets)) {
            return false;
        }
        boolean check=true;
        HostSubversionWallets other = (HostSubversionWallets) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.HostSubversionWallets[ id=" + id + " ]";
    }
}
