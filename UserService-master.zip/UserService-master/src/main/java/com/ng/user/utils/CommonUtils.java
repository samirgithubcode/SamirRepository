/**
 * 
 */
package com.ng.user.utils;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;
import java.util.UUID;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ng.sb.common.cache.MemCacheManager;
import com.ng.sb.common.cache.MemCacheUtils;
import com.ng.sb.common.dataobject.RequestObject;
import com.ng.sb.common.dataobject.ResponseObject;
import com.ng.sb.common.dataobject.UserAccountData;
import com.ng.sb.common.dataobject.ValidationBean;
import com.ng.sb.common.util.ErrorCodes;
import com.ng.sb.common.util.ExceptionUtils;
import com.ng.sb.common.util.KeyEncryptionUtils;
import com.ng.user.logger.UserServiceLogger;

/**
 * @author gopal
 *
 */
@Component
public class CommonUtils {

	private CommonUtils(){}
	
	@Autowired
	MemCacheManager cacheManager;
	
	public String getValidToken() throws Exception
	{

		try{
			
			String tokenString = UUID.randomUUID().toString();
			
			if(cacheManager.isKeyAvailable(tokenString, MemCacheUtils.AUTHTOKENCACHE))
				getValidToken();
			
			return tokenString;
			
		}catch(Exception e){
		
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), UserServiceConstants.PACKAGE_FOR_EXCEPTION);
			
			UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
		}
		
		return null;
	}
	
	public String getRandomNumber(int length) 
	{
		StringBuilder generatedToken = new StringBuilder();
	        try {
	            SecureRandom number = SecureRandom.getInstance("SHA1PRNG");
	            // Generate 20 integers 0..20
	            for (int i = 0; i < length; i++) {
	                generatedToken.append(number.nextInt(9));
	            }
	        } catch (NoSuchAlgorithmException e) {
	        	String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), UserServiceConstants.PACKAGE_FOR_EXCEPTION);
				
				UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
	        }

	        return generatedToken.toString();
	}
	
	public static ResponseObject validateRequestData(ValidationBean txnHistoryRequest, RequestObject requestObject, HttpServletRequest request) 
	{
		ResponseObject responseObject = new ResponseObject();
		
		  if(txnHistoryRequest == null)
		  {
			    responseObject.setStatus(ErrorCodes.REQUIRED_PARAMETERS_MISSING.getCode());
				responseObject.setMessage(ErrorCodes.REQUIRED_PARAMETERS_MISSING.getMessage());
				
				UserServiceLogger.log(CommonUtils.class.getSimpleName(), UserServiceLogger.ERROR,  UserServiceConstants.LOGGING_RESPONSE  + UserServiceConstants.LOGGING_METHOD_NAME +Thread.currentThread().getStackTrace()[1].getMethodName()+ UserServiceConstants.LOGGING_TOKEN_STRING +requestObject.getTokenId()+ UserServiceConstants.LOGGING_ACCESS_CHANNEL + requestObject.getChannelId() + UserServiceConstants.LOGGING_REQUEST_FROM +request.getRemoteAddr() + UserServiceConstants.LOGGING_ERROR_CODE +responseObject.getStatus()+UserServiceConstants.LOGGING_ERROR_MESSAGE +responseObject.getMessage());
				 
				return responseObject;
		  }
		  
			  Set<ConstraintViolation<ValidationBean>> validationError = KeyEncryptionUtils.validateBean(txnHistoryRequest);
			
					if(validationError != null && !validationError.isEmpty())
					{
						Iterator<ConstraintViolation<ValidationBean>>  itr =  validationError.iterator();
						 
						 responseObject.setStatus(ErrorCodes.REQUIRED_PARAMETERS_MISSING.getCode());
						 
						 StringBuilder builder = new StringBuilder();
						 
						 int counter = 1;
						 while(itr.hasNext())
						 {
							 builder.append(counter+". "+itr.next().getMessage()+" ");
							 
							 counter++;
						 }
						
						 responseObject.setMessage(builder.toString());
					
						 UserServiceLogger.log(CommonUtils.class.getSimpleName(), UserServiceLogger.ERROR,  UserServiceConstants.LOGGING_RESPONSE  + UserServiceConstants.LOGGING_METHOD_NAME +Thread.currentThread().getStackTrace()[1].getMethodName()+ UserServiceConstants.LOGGING_TOKEN_STRING +requestObject.getTokenId()+ UserServiceConstants.LOGGING_ACCESS_CHANNEL + requestObject.getChannelId() + UserServiceConstants.LOGGING_REQUEST_FROM +request.getRemoteAddr() + UserServiceConstants.LOGGING_ERROR +builder.toString());
						 
						 return responseObject;
					}
					
		return responseObject;
	}

	public static ResponseObject validateRequest(UserAccountData accountData, RequestObject requestObject, HttpServletRequest request, boolean validationRequired) 
	{
		ResponseObject responseObject = new ResponseObject();
		
		if(accountData == null)
		{
			responseObject.setStatus(ErrorCodes.AUTH_TOKEN_EXPIRED.getCode());
			responseObject.setMessage(ErrorCodes.AUTH_TOKEN_EXPIRED.getMessage());
			
			UserServiceLogger.log(CommonUtils.class.getSimpleName(), UserServiceLogger.ERROR,  UserServiceConstants.LOGGING_RESPONSE  + UserServiceConstants.LOGGING_METHOD_NAME +Thread.currentThread().getStackTrace()[1].getMethodName()+ UserServiceConstants.LOGGING_TOKEN_STRING +requestObject.getTokenId()+ UserServiceConstants.LOGGING_ACCESS_CHANNEL + requestObject.getChannelId() + UserServiceConstants.LOGGING_REQUEST_FROM +request.getRemoteAddr() + UserServiceConstants.LOGGING_ERROR_CODE +responseObject.getStatus()+UserServiceConstants.LOGGING_ERROR_MESSAGE +responseObject.getMessage());
			 
			return responseObject;
		}

		if(accountData.getChannelId() != requestObject.getChannelId())
		{
			responseObject.setStatus(ErrorCodes.INVALID_REQUEST.getCode());
			responseObject.setMessage(ErrorCodes.INVALID_REQUEST.getMessage());
			
			UserServiceLogger.log(CommonUtils.class.getSimpleName(), UserServiceLogger.ERROR,  UserServiceConstants.LOGGING_RESPONSE  + UserServiceConstants.LOGGING_METHOD_NAME +Thread.currentThread().getStackTrace()[1].getMethodName()+ UserServiceConstants.LOGGING_TOKEN_STRING +requestObject.getTokenId()+ UserServiceConstants.LOGGING_ACCESS_CHANNEL + requestObject.getChannelId() + UserServiceConstants.LOGGING_REQUEST_FROM +request.getRemoteAddr() + UserServiceConstants.LOGGING_ERROR_CODE +responseObject.getStatus()+UserServiceConstants.LOGGING_ERROR_MESSAGE +responseObject.getMessage());
			 
			return responseObject;
		}
		
		if(validationRequired && (request.getRequestURI() == null || accountData.getMappedServices() == null ||  !accountData.getMappedServices().contains(request.getRequestURI().toLowerCase())))
		{
			responseObject.setStatus(ErrorCodes.UNAUTHRIZED_ACCESS.getCode());
			responseObject.setMessage(ErrorCodes.UNAUTHRIZED_ACCESS.getMessage());
			
			UserServiceLogger.log(CommonUtils.class.getSimpleName(), UserServiceLogger.ERROR,  UserServiceConstants.LOGGING_RESPONSE  + UserServiceConstants.LOGGING_METHOD_NAME +Thread.currentThread().getStackTrace()[1].getMethodName()+ UserServiceConstants.LOGGING_TOKEN_STRING +requestObject.getTokenId()+ UserServiceConstants.LOGGING_ACCESS_CHANNEL + requestObject.getChannelId() + " [USER_ID] " + accountData.getId() + " [REQUEST_URI] " + request.getRequestURI()  + UserServiceConstants.LOGGING_REQUEST_FROM +request.getRemoteAddr() + UserServiceConstants.LOGGING_ERROR_CODE +responseObject.getStatus()+UserServiceConstants.LOGGING_ERROR_MESSAGE +responseObject.getMessage());
			 
			return responseObject;
		}
		
		return responseObject;
   }
	
	
	public static String getMySqlDateFormat(String dateString)
	{
		if(dateString == null)
			return null;
		
		try {
			String[] dateData = dateString.split("-");
			
			if(dateData == null || dateData.length < 3)
				return null;
			
			return dateData[2] +"-"+ dateData[1] +"-" +dateData[0];
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		return null;
	}
	
	public static String getDateTime(String format,Date date)
    {
        String dateNow;
        SimpleDateFormat formatter = new SimpleDateFormat(format);
        dateNow = formatter.format(date.getTime());
        return dateNow;
    }
}
