/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "hostAccountInfo")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "HostAccountInfo.findAll", query = "SELECT h FROM HostAccountInfo h"),
    @NamedQuery(name = "HostAccountInfo.findById", query = "SELECT h FROM HostAccountInfo h WHERE h.id = :id"),
    @NamedQuery(name = "HostAccountInfo.findBySmsgatewayName", query = "SELECT h FROM HostAccountInfo h WHERE h.smsgatewayName = :smsgatewayName"),
    @NamedQuery(name = "HostAccountInfo.findBySmsgatewayIp", query = "SELECT h FROM HostAccountInfo h WHERE h.smsgatewayIp = :smsgatewayIp"),
    @NamedQuery(name = "HostAccountInfo.findByPort", query = "SELECT h FROM HostAccountInfo h WHERE h.port = :port"),
    @NamedQuery(name = "HostAccountInfo.findByAlias", query = "SELECT h FROM HostAccountInfo h WHERE h.alias = :alias"),
    @NamedQuery(name = "HostAccountInfo.findByShortCode", query = "SELECT h FROM HostAccountInfo h WHERE h.shortCode = :shortCode"),
    @NamedQuery(name = "HostAccountInfo.findByHostId", query = "SELECT h FROM HostAccountInfo h WHERE h.hCode.accountCode = :hCode"),
    @NamedQuery(name = "HostAccountInfo.findByStatus", query = "SELECT h FROM HostAccountInfo h WHERE h.status = :status")})
public class HostAccountInfo implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
    @Column(name = "smsgateway_name", length = 200)
    private String smsgatewayName;
    @Basic(optional = false)
    @Column(name = "smsgateway_ip", nullable = false, length = 200)
    private String smsgatewayIp;
    @Column(name = "port", length = 10)
    private String port;
    @Column(name = "alias", length = 50)
    private String alias;
    @Column(name = "shortCode", nullable = false)
    private String shortCode;
    @Column(name = "status")
    private Boolean status;
    @JoinColumn(name = "hCode", referencedColumnName = "account_code")
    @ManyToOne
    private AccountInfo hCode;

    public HostAccountInfo() {
    	//default constructor
    }

    public HostAccountInfo(Integer id) {
        this.id = id;
    }

    public HostAccountInfo(Integer id, String smsgatewayIp, String shortCode) {
        this.id = id;
        this.smsgatewayIp = smsgatewayIp;
        this.shortCode = shortCode;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSmsgatewayName() {
        return smsgatewayName;
    }

    public void setSmsgatewayName(String smsgatewayName) {
        this.smsgatewayName = smsgatewayName;
    }

    public String getSmsgatewayIp() {
        return smsgatewayIp;
    }

    public void setSmsgatewayIp(String smsgatewayIp) {
        this.smsgatewayIp = smsgatewayIp;
    }

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    public String getShortCode() {
        return shortCode;
    }

    public void setShortCode(String shortCode) {
        this.shortCode = shortCode;
    }

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }

    public AccountInfo getHCode() {
        return hCode;
    }

    public void setHCode(AccountInfo hCode) {
        this.hCode = hCode;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof HostAccountInfo)) {
            return false;
        }
        boolean check=true;
        HostAccountInfo other = (HostAccountInfo) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.HostAccountInfo[ id=" + id + " ]";
    }
    
}
