package com.ng.sb.common.dataobject;
import java.util.Map;

import com.ng.sb.common.model.AccountInfo;

public class IDCreationData extends BaseObjectData {
	private static final long serialVersionUID = 1L;

	
	private String description;
	private Map<Integer, String> kycdescriptormap;
	private Integer descriptor;
	private java.util.List<IDCreationData> iddatalist; 
	private AccountInfo hostId;
    private String hiddenId;
    private String hiddencodeid;
    private String checkname;
    private String idtype;
	private String kycdescriptor;
	private String idProofWeight;
	
	public String getIdProofWeight() {
		return this.idProofWeight;
	}
	public void setIdProofWeight(String idProofWeight) {
		this.idProofWeight = idProofWeight;
	}
	public String getCheckname() {
		return checkname;
	}
	public void setCheckname(String checkname) {
		this.checkname = checkname;
	}
	public String getHiddencodeid() {
		return hiddencodeid;
	}
	public void setHiddencodeid(String hiddencodeid) {
		this.hiddencodeid = hiddencodeid;
	}
	public String getHiddenId() {
		return hiddenId;
	}
	public void setHiddenId(String hiddenId) {
		this.hiddenId = hiddenId;
	}
	public java.util.List<IDCreationData> getIddatalist() {
		return iddatalist;
	}
	public void setIddatalist(java.util.List<IDCreationData> iddatalist) {
		this.iddatalist = iddatalist;
	}
	
	public AccountInfo getHostId() {
		return hostId;
	}
	public void setHostId(AccountInfo hostId) {
		this.hostId = hostId;
	}
	
	public Integer getDescriptor() {
		return descriptor;
	}
	public void setDescriptor(Integer descriptor) {
		this.descriptor = descriptor;
	}
	public String getDescription() {
		return description;
	}
    public void setKycdescriptormap(Map<Integer, String> kycdescriptormap) {
		this.kycdescriptormap = kycdescriptormap;
	}
    public Map<Integer, String> getKycdescriptormap() {
		return kycdescriptormap;
	}

	public void setDescription(String description) {
		this.description = description;
	}

    
	public String getKycdescriptor() {
		return kycdescriptor;
	}

	public void setKycdescriptor(String kycdescriptor) {
		this.kycdescriptor = kycdescriptor;
	}
	public String getIdtype() {
		return idtype;
	}
	public void setIdtype(String idtype) {
		this.idtype = idtype;
	}



	
}
