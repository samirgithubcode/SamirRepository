package com.ng.sb.common.dataobject;

import java.math.BigDecimal;

public class InventoryResponse extends BaseObjectData{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private BigDecimal internalNo;
	private Long externalNo;
	private Integer masterVersionId;
	private Integer productId;
	private String productName;
	private String productType;
	public BigDecimal getInternalNo() {
		return internalNo;
	}
	public void setInternalNo(BigDecimal internalNo) {
		this.internalNo = internalNo;
	}
	public Long getExternalNo() {
		return externalNo;
	}
	public void setExternalNo(Long externalNo) {
		this.externalNo = externalNo;
	}
	public Integer getMasterVersionId() {
		return masterVersionId;
	}
	public void setMasterVersionId(Integer masterVersionId) {
		this.masterVersionId = masterVersionId;
	}
	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	
	

}
