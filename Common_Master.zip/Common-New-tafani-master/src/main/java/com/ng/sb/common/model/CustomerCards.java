/**
 * 
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author gopal
 *
 */
@Entity
@Table(name = "subscriber_cards_info")
@NamedQueries({
    @NamedQuery(name = "CustomerCards.findById", query = "SELECT s FROM CustomerCards s WHERE s.id = :id"),
    @NamedQuery(name = "CustomerCards.findByMsisdn", query = "SELECT s FROM CustomerCards s WHERE s.customerMsisdn = :customerMsisdn")
   })
public class CustomerCards implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;
   
    @Column(name = "customerId")
    private String customerId;
    
    @Column(name = "customerMsisdn")
    private String customerMsisdn;
    
    @Column(name = "cardType")
    private String cardType;
    
    @Column(name = "cardName")
    private String cardName;
    
    @Column(name = "cardNickName")
    private String cardNickName;
    
    @Column(name = "cardNumber")
    private BigDecimal cardNumber;
    
    @Column(name = "cardExpiry")
    private String cardExpiry;
    
    @Column(name = "cardStatus")
    private String cardStatus;
    
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "addedOn")
    private Date addedOn;
    
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "modifiedOn")
    private Date modifiedOn;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerMsisdn() {
		return customerMsisdn;
	}

	public void setCustomerMsisdn(String customerMsisdn) {
		this.customerMsisdn = customerMsisdn;
	}

	public String getCardType() {
		return cardType;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	public String getCardName() {
		return cardName;
	}

	public void setCardName(String cardName) {
		this.cardName = cardName;
	}

	public String getCardNickName() {
		return cardNickName;
	}

	public void setCardNickName(String cardNickName) {
		this.cardNickName = cardNickName;
	}

	public BigDecimal getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(BigDecimal cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getCardExpiry() {
		return cardExpiry;
	}

	public void setCardExpiry(String cardExpiry) {
		this.cardExpiry = cardExpiry;
	}

	public String getCardStatus() {
		return cardStatus;
	}

	public void setCardStatus(String cardStatus) {
		this.cardStatus = cardStatus;
	}

	public Date getAddedOn() {
		return addedOn;
	}

	public void setAddedOn(Date addedOn) {
		this.addedOn = addedOn;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

}
