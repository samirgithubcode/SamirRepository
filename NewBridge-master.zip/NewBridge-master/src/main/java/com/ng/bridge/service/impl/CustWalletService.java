package com.ng.bridge.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ng.bridge.dao.ICustWalletDAO;
import com.ng.bridge.service.ICustWalletService;
import com.ng.sb.common.dataobject.IConstants;
import com.ng.sb.common.dataobject.WalletRequestData;
import com.ng.sb.common.dataobject.WalletResponseData;
import com.ng.sb.common.dataobject.WalletResponseWrapperData;
import com.ng.sb.common.model.CustMerchFinInstMapping;
import com.ng.sb.common.model.Customer;
import com.ng.sb.common.model.Partner;

@Service
public class CustWalletService implements ICustWalletService {
	private static final Logger LOGGER = LoggerFactory.getLogger(CustWalletService.class);
	@Autowired
	ICustWalletDAO iCustWalletDAO;

@Override
	public Map<String,String> deductBalanceForTransaction(Integer walletType,String customerMobNumber,Integer amount) 
	{
		Partner partner=iCustWalletDAO.checkWalletStatus(walletType);
		CustMerchFinInstMapping customerCustMerchFinInstMapping=iCustWalletDAO.checkCustomerStatus(partner,customerMobNumber);
		Customer customerDetails=iCustWalletDAO.getCustomerDetails(customerMobNumber);
		Map<String,String> result= new HashMap<>();
		if(customerCustMerchFinInstMapping==null)
		{
			result.put(IConstants.FIRST_NAME, customerDetails.getFirstName());
			result.put(IConstants.LAST_NAME, customerDetails.getLastName());
			result.put(IConstants.STATUS,IConstants.FALSE);
			result.put(IConstants.MSG,IConstants.NO_WALLET);
			return result;
		}
		else if(customerCustMerchFinInstMapping.getBalance()<=amount)
		{
			result= new HashMap<>();
			result.put(IConstants.FIRST_NAME, customerDetails.getFirstName());
			result.put(IConstants.LAST_NAME, customerDetails.getLastName());
			result.put(IConstants.STATUS,IConstants.FALSE);
			result.put(IConstants.MSG,IConstants.NO_BALANCE);
			return result;
		}
		else if(customerCustMerchFinInstMapping.getBalance()>amount)
		{
			result= new HashMap<>();
			result.put(IConstants.FIRST_NAME, customerDetails.getFirstName());
			result.put(IConstants.LAST_NAME, customerDetails.getLastName());
			result.put(IConstants.STATUS,IConstants.TRUE);
			result.put(IConstants.MSG,IConstants.SUCCESS);
			Integer remainingAmount=customerCustMerchFinInstMapping.getBalance()-amount;
			result.put(IConstants.AVAILABLE_BALANCE,String.valueOf(remainingAmount));
			customerCustMerchFinInstMapping.setBalance(remainingAmount);
			iCustWalletDAO.updateCustMerchFinInstMappingInfo(customerCustMerchFinInstMapping);
			return result;
		}
		return result;
	}

@Override
public Map<String, String> getBalanceForTransaction(Integer walletType, String customerMobNumber) {
	Partner partner= null;
	CustMerchFinInstMapping customerCustMerchFinInstMapping=null;
	try{
	partner=iCustWalletDAO.checkWalletStatus(walletType);
	customerCustMerchFinInstMapping=iCustWalletDAO.checkCustomerStatus(partner,customerMobNumber);
	Customer customerDetails=iCustWalletDAO.getCustomerDetails(customerMobNumber);
	Map<String,String> result= new HashMap<>();
	result.put(IConstants.FIRST_NAME, customerDetails.getFirstName());
	result.put(IConstants.LAST_NAME, customerDetails.getLastName());
	if(partner==null)
	{
		result.put(IConstants.STATUS,IConstants.FALSE);
		result.put(IConstants.MSG,IConstants.NO_WALLET);
		return result;
	}
	else if(customerCustMerchFinInstMapping == null)
	{
		return getResult();
	}else
	{
		result.put(IConstants.STATUS,IConstants.TRUE);
		result.put(IConstants.MSG,IConstants.SUCCESS);
		result.put(IConstants.AVAILABLE_BALANCE,String.valueOf(customerCustMerchFinInstMapping.getBalance()));
		return result;
	}
	}catch(Exception ex)
	{
		LOGGER.info(" "+ex);
	}
	return null;
}

public Map<String,String> getResult(){
	Map<String,String> result= new HashMap<>();
	result.put(IConstants.STATUS,IConstants.FALSE);
	result.put(IConstants.MSG,IConstants.NO_WALLET);
	return result;
}
@Override
public Boolean transactionTimeOut(Integer timeInSeconds, String transactionId)  {

	return false;
}

@Override
public Boolean allTransactionTimeOut()  {
	return false;
}

@Override
public WalletResponseWrapperData validateWallet(WalletRequestData walletRequestData)  {
	return null;
}

@Override
public WalletResponseData validateWallet(String ip, WalletRequestData walletRequestData)  {

	return null;
}

@Override
public boolean reversal(String transactionId, String reason)  {

	return false;
}

@Override
public WalletResponseWrapperData refundAmount(String ip, WalletRequestData walletRequestData) {
	return null;
}

@Override
public WalletResponseWrapperData deductBalance(String ip, WalletRequestData walletRequestData) {
	return null;
}

@Override
public WalletResponseWrapperData cancelRequest(String ip, WalletRequestData walletRequestData) {

	return null;
}

@Override
public WalletResponseWrapperData checkBalance(String ipaddress, WalletRequestData walletRequestData)  {
	return null;
}
	
}
