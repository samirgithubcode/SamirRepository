/**
 * 
 */
package com.ng.pnb.bridge.invoker;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ng.base.invoker.IThirdPartyInvoker;
import com.ng.base.invoker.impl.ThirdPartyInvoker;
import com.ng.pnb.bridge.service.IAccountTransactionService;
import com.ng.pnb.invoker.util.AccountTransactionData;
import com.ng.sb.common.dataobject.BridgeDataObject;
import com.ng.sb.common.dataobject.BridgeDataResponse;
import com.ng.sb.common.dataobject.BridgeDataResponse.EListOrString;
import com.ng.sb.common.dataobject.BridgeDataResponse.Status;
import com.ng.sb.common.util.SystemConstant;

/**
 * @author gopal
 *
 */
@Service(value=SystemConstant.HDFC_TRANSIT_INVOKER)
public class HDFCTransitInvoker extends ThirdPartyInvoker implements IThirdPartyInvoker {
	private static final Logger LOGGER = LoggerFactory.getLogger(HDFCTransitInvoker.class);
	
	@Autowired
	IAccountTransactionService iAccountTransactionService;
	/* (non-Javadoc)
	 * @see com.ng.bridge.invoker.IThirdPartyInvoker#deductAmountThruBankDirect(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject deductAmountThruBankDirect(BridgeDataObject bridgeDataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ng.bridge.invoker.IThirdPartyInvoker#deductAmountThruCreditCardDirect(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject deductAmountThruCreditCardDirect(BridgeDataObject bridgeDataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ng.bridge.invoker.IThirdPartyInvoker#deductAmountThruIMPSDirect(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject deductAmountThruIMPSDirect(BridgeDataObject bridgeDataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ng.bridge.invoker.IThirdPartyInvoker#deductAmountThruWalletDirect(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject deductAmountThruWalletDirect(BridgeDataObject bridgeDataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ng.bridge.invoker.IThirdPartyInvoker#addAmountInBankDirect(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject addAmountInBankDirect(BridgeDataObject bridgeDataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ng.bridge.invoker.IThirdPartyInvoker#addAmountInCreditCardDirect(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject addAmountInCreditCardDirect(BridgeDataObject bridgeDataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ng.bridge.invoker.IThirdPartyInvoker#addAmountInIMPSDirect(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject addAmountInIMPSDirect(BridgeDataObject bridgeDataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ng.bridge.invoker.IThirdPartyInvoker#addAmountInWalletDirect(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject addAmountInWalletDirect(BridgeDataObject bridgeDataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ng.bridge.invoker.IThirdPartyInvoker#moneyTransferFSP(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject moneyTransferFSP(BridgeDataObject bridgeDataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ng.bridge.invoker.IThirdPartyInvoker#bankToBankFundTransferFSP(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject bankToBankFundTransferFSP(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In HDFCTransitInvoker - PNB - bankToBankFundTransferFSP method. ");
		try
		{
			AccountTransactionData accountTransactionData = iAccountTransactionService.performTransaction(bridgeDataObject);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		AccountTransactionData accountTransactionData = null;
		try
		{
			accountTransactionData = iAccountTransactionService.performTransaction(bridgeDataObject);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		BridgeDataResponse response = new BridgeDataResponse();
		response.setStatus(Status.SUCCESS);
		if(accountTransactionData.isSuccess()){
			response.setResponseMsg(accountTransactionData.getSuccessMessage());
		}else{
			response.setResponseMsg(accountTransactionData.getErrorMessage());
		}
		response.setMsidnToSendMsg(bridgeDataObject.getTransactionData().getMsisdn());
		bridgeDataObject.setBridgeResponse(response);
		return bridgeDataObject;
	}

	/* (non-Javadoc)
	 * @see com.ng.bridge.invoker.IThirdPartyInvoker#bankToWalletFundTransferFSP(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject bankToWalletFundTransferFSP(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In HDFCTransitInvoker - PNB - bankToWalletFundTransferFSP method. ");
		try
		{
			AccountTransactionData accountTransactionData = iAccountTransactionService.performTransaction(bridgeDataObject);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		AccountTransactionData accountTransactionData = null;
		try
		{
			accountTransactionData = iAccountTransactionService.performTransaction(bridgeDataObject);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		BridgeDataResponse response = new BridgeDataResponse();
		response.setStatus(Status.SUCCESS);
		if(accountTransactionData.isSuccess()){
			response.setResponseMsg(accountTransactionData.getSuccessMessage());
		}else{
			response.setResponseMsg(accountTransactionData.getErrorMessage());
		}
		response.setMsidnToSendMsg(bridgeDataObject.getTransactionData().getMsisdn());
		bridgeDataObject.setBridgeResponse(response);
		return bridgeDataObject;
	}

	/* (non-Javadoc)
	 * @see com.ng.bridge.invoker.IThirdPartyInvoker#bankToIMPSFundTransferFSP(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject bankToIMPSFundTransferFSP(BridgeDataObject bridgeDataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ng.bridge.invoker.IThirdPartyInvoker#bankToCreditCardFundTransferFSP(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject bankToCreditCardFundTransferFSP(BridgeDataObject bridgeDataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ng.bridge.invoker.IThirdPartyInvoker#walletToBankFundTransferFSP(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject walletToBankFundTransferFSP(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In HDFCTransitInvoker - HDFCTransit - walletToBankFundTransferFSP method. ");
		AccountTransactionData accountTransactionData = null;
		try
		{
			accountTransactionData = iAccountTransactionService.performTransaction(bridgeDataObject);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		BridgeDataResponse response = new BridgeDataResponse();
		response.setStatus(Status.SUCCESS);
		if(accountTransactionData.isSuccess()){
			response.setResponseMsg(accountTransactionData.getSuccessMessage());
		}else{
			response.setResponseMsg(accountTransactionData.getErrorMessage());
		}
		response.setMsidnToSendMsg(bridgeDataObject.getTransactionData().getMsisdn());
		bridgeDataObject.setBridgeResponse(response);
		return bridgeDataObject;
	}

	/* (non-Javadoc)
	 * @see com.ng.bridge.invoker.IThirdPartyInvoker#walletToWalletFundTransferFSP(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject walletToWalletFundTransferFSP(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In HDFCTransitInvoker - HDFCTransit - walletToWalletFundTransferFSP method. ");
		
		AccountTransactionData accountTransactionData = null;
		try
		{
			accountTransactionData = iAccountTransactionService.performTransaction(bridgeDataObject);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		BridgeDataResponse response = new BridgeDataResponse();
		response.setStatus(Status.SUCCESS);
		if(accountTransactionData.isSuccess()){
			response.setResponseMsg(accountTransactionData.getSuccessMessage());
		}else{
			response.setResponseMsg(accountTransactionData.getErrorMessage());
		}
		response.setMsidnToSendMsg(bridgeDataObject.getTransactionData().getMsisdn());
		bridgeDataObject.setBridgeResponse(response);
		return bridgeDataObject;
	}

	/* (non-Javadoc)
	 * @see com.ng.bridge.invoker.IThirdPartyInvoker#walletToIMPSFundTransferFSP(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject walletToIMPSFundTransferFSP(BridgeDataObject bridgeDataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ng.bridge.invoker.IThirdPartyInvoker#walletToCreditCardFundTransferFSP(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject walletToCreditCardFundTransferFSP(BridgeDataObject bridgeDataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ng.bridge.invoker.IThirdPartyInvoker#impsToBankFundTransferFSP(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject impsToBankFundTransferFSP(BridgeDataObject bridgeDataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ng.bridge.invoker.IThirdPartyInvoker#impsToWalletFundTransferFSP(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject impsToWalletFundTransferFSP(BridgeDataObject bridgeDataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ng.bridge.invoker.IThirdPartyInvoker#impsToIMPSFundTransferFSP(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject impsToIMPSFundTransferFSP(BridgeDataObject bridgeDataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ng.bridge.invoker.IThirdPartyInvoker#impsToCreditCardFundTransferFSP(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject impsToCreditCardFundTransferFSP(BridgeDataObject bridgeDataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ng.bridge.invoker.IThirdPartyInvoker#creditCardToBankFundTransferFSP(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject creditCardToBankFundTransferFSP(BridgeDataObject bridgeDataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ng.bridge.invoker.IThirdPartyInvoker#creditCardToWalletFundTransferFSP(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject creditCardToWalletFundTransferFSP(BridgeDataObject bridgeDataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ng.bridge.invoker.IThirdPartyInvoker#creditCardToIMPSFundTransferFSP(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject creditCardToIMPSFundTransferFSP(BridgeDataObject bridgeDataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ng.bridge.invoker.IThirdPartyInvoker#creditCardToCreditCardFundTransferFSP(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject creditCardToCreditCardFundTransferFSP(BridgeDataObject bridgeDataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ng.bridge.invoker.IThirdPartyInvoker#balanceEnquiryFSP(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject balanceEnquiryFSP(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In HDFCTransitInvoker - PNB - balanceEnquiryFSP method. ");
		AccountTransactionData accountTransactionData = null;
		try
		{
			accountTransactionData = iAccountTransactionService.performTransaction(bridgeDataObject);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		BridgeDataResponse response = new BridgeDataResponse();
		
		if(accountTransactionData.isSuccess())
		{
			response.setStatus(Status.SUCCESS);
			response.setResponseMsg(accountTransactionData.getSuccessMessage());
		}else{
			response.setStatus(Status.FAILED);
			response.setResponseMsg(accountTransactionData.getErrorMessage());
		}
		response.setMsidnToSendMsg(bridgeDataObject.getTransactionData().getMsisdn());
		bridgeDataObject.setBridgeResponse(response);
		return bridgeDataObject;
	}

	/* (non-Javadoc)
	 * @see com.ng.bridge.invoker.IThirdPartyInvoker#chequeBookRequestFSP(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject chequeBookRequestFSP(BridgeDataObject bridgeDataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ng.bridge.invoker.IThirdPartyInvoker#cancelChequeFSP(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject cancelChequeFSP(BridgeDataObject bridgeDataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ng.bridge.invoker.IThirdPartyInvoker#last5TransactionFSP(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject last5TransactionFSP(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In HDFCTransitInvoker - PNB - last5TransactionFSP method. ");
		AccountTransactionData accountTransactionData = null;
		try
		{
			accountTransactionData = iAccountTransactionService.performTransaction(bridgeDataObject);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		BridgeDataResponse response = new BridgeDataResponse();
		response.setStatus(Status.SUCCESS);
		String miniStatement = ""; 
		List<String> msgList = accountTransactionData.getMessageList();
		for(String msg:msgList){
			miniStatement += msg+" \n"; 
		}
		if(accountTransactionData.isSuccess()){
			response.setListOrString(EListOrString.L);
			response.setResponseMsg(miniStatement);
		}else{
			response.setListOrString(EListOrString.L);
			response.setResponseMsg(miniStatement);
		}
		response.setMsidnToSendMsg(bridgeDataObject.getTransactionData().getMsisdn());
		bridgeDataObject.setBridgeResponse(response);
		return bridgeDataObject;
	}

	/* (non-Javadoc)
	 * @see com.ng.bridge.invoker.IThirdPartyInvoker#billPaymentToBillerDirect(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject billPaymentToBillerDirect(BridgeDataObject bridgeDataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ng.bridge.invoker.IThirdPartyInvoker#billPaymentByWalletFSP(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject billPaymentByWalletFSP(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In HDFCTransitInvoker - HDFCTransit - walletBalanceEnquiryFSP method. ");
		
		AccountTransactionData accountTransactionData = null;
		try
		{
			accountTransactionData = iAccountTransactionService.performTransaction(bridgeDataObject);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		BridgeDataResponse response = new BridgeDataResponse();
		if(accountTransactionData.isSuccess()){
			response.setResponseMsg(accountTransactionData.getSuccessMessage());
		}else{
			response.setResponseMsg(accountTransactionData.getErrorMessage());
		}
		response.setStatus(Status.SUCCESS);
		response.setMsidnToSendMsg(bridgeDataObject.getTransactionData().getMsisdn());
		bridgeDataObject.setBridgeResponse(response);
		return bridgeDataObject;
	}

	/* (non-Javadoc)
	 * @see com.ng.bridge.invoker.IThirdPartyInvoker#billPaymentByBankFSP(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject billPaymentByBankFSP(BridgeDataObject bridgeDataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ng.bridge.invoker.IThirdPartyInvoker#billPaymentByIMPSFSP(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject billPaymentByIMPSFSP(BridgeDataObject bridgeDataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ng.bridge.invoker.IThirdPartyInvoker#billPaymentByCreditCardFSP(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject billPaymentByCreditCardFSP(BridgeDataObject bridgeDataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ng.bridge.invoker.IThirdPartyInvoker#topUpRechargeToBillerDirect(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject topUpRechargeToBillerDirect(BridgeDataObject bridgeDataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ng.bridge.invoker.IThirdPartyInvoker#topUpRechargeByWalletFSP(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject topUpRechargeByWalletFSP(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In HDFCTransitInvoker - HDFCTransit - walletBalanceEnquiryFSP method. ");
	
		AccountTransactionData accountTransactionData = null;
		try
		{
			accountTransactionData = iAccountTransactionService.performTransaction(bridgeDataObject);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		BridgeDataResponse response = new BridgeDataResponse();
		if(accountTransactionData.isSuccess()){
			response.setResponseMsg(accountTransactionData.getSuccessMessage());
		}else{
			response.setResponseMsg(accountTransactionData.getErrorMessage());
		}
		response.setStatus(Status.SUCCESS);
		response.setMsidnToSendMsg(bridgeDataObject.getTransactionData().getMsisdn());
		bridgeDataObject.setBridgeResponse(response);
		return bridgeDataObject;
	}

	/* (non-Javadoc)
	 * @see com.ng.bridge.invoker.IThirdPartyInvoker#topUpRechargeByBankFSP(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject topUpRechargeByBankFSP(BridgeDataObject bridgeDataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ng.bridge.invoker.IThirdPartyInvoker#topUpRechargeByIMPSFSP(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject topUpRechargeByIMPSFSP(BridgeDataObject bridgeDataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ng.bridge.invoker.IThirdPartyInvoker#topUpRechargeByCreditCardFSP(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject topUpRechargeByCreditCardFSP(BridgeDataObject bridgeDataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BridgeDataObject walletBalanceEnquiryFSP(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In HDFCTransitInvoker - HDFCTransit - walletBalanceEnquiryFSP method. ");
		
		AccountTransactionData accountTransactionData = null;
		try
		{
			accountTransactionData = iAccountTransactionService.performTransaction(bridgeDataObject);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		BridgeDataResponse response = new BridgeDataResponse();
		if(accountTransactionData.isSuccess())
		{
			response.setStatus(Status.SUCCESS);
			response.setResponseMsg(accountTransactionData.getSuccessMessage());
		}else{
			response.setStatus(Status.FAILED);
			response.setResponseMsg(accountTransactionData.getErrorMessage());
		}
		
		response.setMsidnToSendMsg(bridgeDataObject.getTransactionData().getMsisdn());
		bridgeDataObject.setBridgeResponse(response);
		return bridgeDataObject;
	}

	@Override
	public BridgeDataObject createPINFSP(BridgeDataObject bridgeDataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BridgeDataObject changePINFSP(BridgeDataObject bridgeDataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BridgeDataObject createWalletPINFSP(BridgeDataObject bridgeDataObject) 
	{
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In HDFCTransitInvoker - PNB - createWalletPINFSP method. ");
		
		AccountTransactionData accountTransactionData = null;
		try
		{
			accountTransactionData = iAccountTransactionService.performTransaction(bridgeDataObject);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		BridgeDataResponse response = new BridgeDataResponse();
		if(accountTransactionData.isSuccess())
		{
			response.setStatus(Status.SUCCESS);
			response.setResponseMsg(accountTransactionData.getSuccessMessage());
		}else{
			response.setStatus(Status.FAILED);
			response.setResponseMsg(accountTransactionData.getErrorMessage());
		}
		
		response.setMsidnToSendMsg(bridgeDataObject.getTransactionData().getMsisdn());
		bridgeDataObject.setBridgeResponse(response);
		return bridgeDataObject;
	}

	@Override
	public BridgeDataObject changeWalletPINFSP(BridgeDataObject bridgeDataObject) 
	{
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In HDFCTransitInvoker - PNB - createWalletPINFSP method. ");
		
		AccountTransactionData accountTransactionData = null;
		try
		{
			accountTransactionData = iAccountTransactionService.performTransaction(bridgeDataObject);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		BridgeDataResponse response = new BridgeDataResponse();
		if(accountTransactionData.isSuccess())
		{
			response.setStatus(Status.SUCCESS);
			response.setResponseMsg(accountTransactionData.getSuccessMessage());
		}else{
			response.setStatus(Status.FAILED);
			response.setResponseMsg(accountTransactionData.getErrorMessage());
		}
		
		response.setMsidnToSendMsg(bridgeDataObject.getTransactionData().getMsisdn());
		bridgeDataObject.setBridgeResponse(response);
		return bridgeDataObject;
	}

	@Override
	public BridgeDataObject addBankAccount(BridgeDataObject bridgeDataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BridgeDataObject chequeStatusFSP(BridgeDataObject bridgeDataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BridgeDataObject addMyPayee(BridgeDataObject bridgeDataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BridgeDataObject addMyMerchant(BridgeDataObject bridgeDataObject) {
		
		return null;
	}
	
	@Override
	public BridgeDataObject addMyBiller(BridgeDataObject bridgeDataObject) {
		
		return null;
	}
}