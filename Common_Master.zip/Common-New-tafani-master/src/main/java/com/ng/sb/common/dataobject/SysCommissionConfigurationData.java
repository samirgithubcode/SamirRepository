/**
 * 
 */
package com.ng.sb.common.dataobject;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author gaurav Data Transfer object to carry data for Commission Template.
 * 
 */
public class SysCommissionConfigurationData extends BaseObjectData {
	private static final long serialVersionUID = 1L;

	private List<SysConfigRangeData> sysConfigRangePartner = new ArrayList<>();
	private List<SysConfigRangeData> sysConfigRangeCustomer = new ArrayList<>();
	private List<SysConfigRangeData> sysConfigRangeCollection = new ArrayList<>();
	private List<SysConfigRangeData> sysConfigRangeHisCollection = new ArrayList<>();
	private List<AccountInfoData> accountInfoList;

	private String senderCommDesc;

	private Float senderCommFixedValue;

	private Float senderCommMax;

	private Float senderCommMin;

	private String senderCommType;

	private String recipientCommDesc;

	private Float recipientCommFixedValue;

	private Float recipientCommMax;

	private Float recipientCommMin;

	private String recipientCommType;
	private Integer showBack;
	private String hostname;
	private Date createdDate;

	private String description;

	private Date editDate;

	private Integer status;

	private Float surcharge;

	private Float tax;

	private String templateCommType;

	private int hostId;

	private int addedById;

	public List<SysConfigRangeData> getSysConfigRangeHisCollection() {
		return sysConfigRangeHisCollection;
	}

	public void setSysConfigRangeHisCollection(List<SysConfigRangeData> sysConfigRangeHisCollection) {
		this.sysConfigRangeHisCollection = sysConfigRangeHisCollection;
	}

	public enum TemplateCommissionType {
		NO, BOTH, CUST, PART, PORTAL
	}

	public enum CommissionDesc {
		NO, AMT, PERC
	}

	public enum CommissionType {
		FIXED, RANGE
	}

	public String getHostname() {
		return hostname;
	}

	public void setHostname(String hostname) {
		this.hostname = hostname;
	}

	public Integer getShowBack() {
		return showBack;
	}

	public void setShowBack(Integer showBack) {
		this.showBack = showBack;
	}

	public List<SysConfigRangeData> getSysConfigRangeCollection() {
		return sysConfigRangeCollection;
	}

	public void setSysConfigRangeCollection(List<SysConfigRangeData> sysConfigRangeCollection) {
		this.sysConfigRangeCollection = sysConfigRangeCollection;
	}

	public String getSenderCommDesc() {
		return senderCommDesc;
	}

	public void setSenderCommDesc(String senderCommDesc) {
		this.senderCommDesc = senderCommDesc;
	}

	public Float getSenderCommFixedValue() {
		return senderCommFixedValue;
	}

	public void setSenderCommFixedValue(Float senderCommFixedValue) {
		this.senderCommFixedValue = senderCommFixedValue;
	}

	public Float getSenderCommMax() {
		return senderCommMax;
	}

	public void setSenderCommMax(Float senderCommMax) {
		this.senderCommMax = senderCommMax;
	}

	public Float getSenderCommMin() {
		return senderCommMin;
	}

	public void setSenderCommMin(Float senderCommMin) {
		this.senderCommMin = senderCommMin;
	}

	public String getSenderCommType() {
		return senderCommType;
	}

	public void setSenderCommType(String senderCommType) {
		this.senderCommType = senderCommType;
	}

	public String getRecipientCommDesc() {
		return recipientCommDesc;
	}

	public void setRecipientCommDesc(String recipientCommDesc) {
		this.recipientCommDesc = recipientCommDesc;
	}

	public Float getRecipientCommFixedValue() {
		return recipientCommFixedValue;
	}

	public void setRecipientCommFixedValue(Float recipientCommFixedValue) {
		this.recipientCommFixedValue = recipientCommFixedValue;
	}

	public Float getRecipientCommMax() {
		return recipientCommMax;
	}

	public void setRecipientCommMax(Float recipientCommMax) {
		this.recipientCommMax = recipientCommMax;
	}

	public Float getRecipientCommMin() {
		return recipientCommMin;
	}

	public void setRecipientCommMin(Float recipientCommMin) {
		this.recipientCommMin = recipientCommMin;
	}

	public String getRecipientCommType() {
		return recipientCommType;
	}

	public void setRecipientCommType(String recipientCommType) {
		this.recipientCommType = recipientCommType;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getEditDate() {
		return editDate;
	}

	public void setEditDate(Date editDate) {
		this.editDate = editDate;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Float getSurcharge() {
		return surcharge;
	}

	public void setSurcharge(Float surcharge) {
		this.surcharge = surcharge;
	}

	public Float getTax() {
		return tax;
	}

	public void setTax(Float tax) {
		this.tax = tax;
	}

	public String getTemplateCommType() {
		return templateCommType;
	}

	public void setTemplateCommType(String templateCommType) {
		this.templateCommType = templateCommType;
	}

	public List<SysConfigRangeData> getSysConfigRangePartner() {
		return sysConfigRangePartner;
	}

	public void setSysConfigRangePartner(List<SysConfigRangeData> sysConfigRangePartner) {
		this.sysConfigRangePartner = sysConfigRangePartner;
	}

	public List<SysConfigRangeData> getSysConfigRangeCustomer() {
		return sysConfigRangeCustomer;
	}

	public void setSysConfigRangeCustomer(List<SysConfigRangeData> sysConfigRangeCustomer) {
		this.sysConfigRangeCustomer = sysConfigRangeCustomer;
	}

	public int getHostId() {
		return hostId;
	}

	public void setHostId(int hostId) {
		this.hostId = hostId;
	}

	public int getAddedById() {
		return addedById;
	}

	public void setAddedById(int addedById) {
		this.addedById = addedById;
	}

	public List<AccountInfoData> getAccountInfoList() {
		return accountInfoList;
	}

	public void setAccountInfoList(List<AccountInfoData> accountInfoList) {
		this.accountInfoList = accountInfoList;
	}

}
