package com.ng.sc.service;

import java.util.Map;

import com.ng.sb.common.service.IService;

public interface ISelfCareService  extends IService {
	public Map<Integer,String> getCountries() throws Exception;
	public Map<Integer,String> getState(Integer countryId) throws Exception;

}
