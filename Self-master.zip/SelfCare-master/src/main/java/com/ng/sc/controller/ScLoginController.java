package com.ng.sc.controller;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import com.ng.sb.common.controller.ASelfCareController;
import com.ng.sb.common.dataobject.LoginData;
import com.ng.sb.common.dataobject.LogoutData;
import com.ng.sb.common.dataobject.SubscriberData;
import com.ng.sb.common.util.SystemConstant;
import com.ng.sc.service.IScLoginService;
import com.ng.sc.service.IScSessionService;
import com.ng.sc.service.IScUserMgmntService;
import com.ng.sc.utils.ScSystemConstant;

/**
 * This class is used to login into the self care portal.
 */

/**
 * 
 * @author 
 *
 */
@Controller
@RequestMapping(value = "/login")
public class ScLoginController extends ASelfCareController {

	private static final Logger LOGGER = LoggerFactory.getLogger(ScLoginController.class);

	private ModelMap map = new ModelMap();

	@Autowired
	IScLoginService loginService;
	@Autowired
	ApplicationContext applicationContext;
	@Autowired
	private MessageSource messageSource;
	@Autowired
	IScSessionService managemetImpl;
	@Autowired
	IScUserMgmntService iUserMgmntService;

	@RequestMapping(value = "/getSubAccountType")
	 @ResponseBody public LoginData getBC(@ModelAttribute(value = "loginData") LoginData loginData, HttpSession session,
			HttpServletRequest request) {
		LOGGER.debug("*********get Sub Account Type starts executing*************");

		Map accountTypeMap = new HashMap();

		try {
			accountTypeMap = loginService.accountTypeMap(loginData.getAccountType());
			loginData.setAccountTypeMap(accountTypeMap);
		} catch (Exception e) {
			LOGGER.info("Exception in catch block occurred in getSubAccountType: " + e);
		}
		return loginData;
	}

	/**
	 * get login page
	 * 
	 */
	/**
	 * @param httpSession
	 * @return
	 */
	@RequestMapping(value = "/getLoginPage")
	public ModelAndView getLoginPage(HttpSession httpSession) {
		LOGGER.debug("getLoginPage");
		LoginData loginData = new LoginData();
		try {
			map.addAttribute(ScSystemConstant.LOGINDATA, loginData);
			map.addAttribute(SystemConstant.STATUS_MESSAGE, httpSession.getAttribute(SystemConstant.STATUS_MESSAGE));
			
			httpSession.setAttribute(SystemConstant.STATUS_MESSAGE, "");
			loginData.setView(ScSystemConstant.LOGIN_PAGE);
		} catch (Exception e) {
			LOGGER.debug("Error to get account Type List" + e);
			loginData.setView(SystemConstant.ERROR_PAGE);
		}

		return new ModelAndView(loginData.getView(), map);
	}

	@RequestMapping(value = "/getHomePage")
	public ModelAndView getHomePage(HttpSession httpSession) {
		LOGGER.debug("getHomePage");
		String view = "";
		try {
			view = ScSystemConstant.HOME_PAGE;
		} catch (Exception e) {
			LOGGER.debug("Error in getHomePage" + e);
			view = SystemConstant.ERROR_PAGE;
		}

		return new ModelAndView(view, map);
	}

	/**
	 * @param session
	 * @return
	 * 
	 * 
	 */
	@RequestMapping(value = "/getSignUpPage")
	public ModelAndView UserLoginCreationPage(HttpSession session) {
		SubscriberData subscriberData = new SubscriberData();
		String view = "";
		try {
			LOGGER.info("*******Execution start of method UserLoginCreationPage() in controller ScLoginController ");
				map.addAttribute(ScSystemConstant.SUBSCRIBERDATA, subscriberData);
				map.addAttribute(SystemConstant.STATUS_MESSAGE, "");
				map.addAttribute(SystemConstant.ERRORSTATUSMESSAGE, "");
				map.addAttribute(SystemConstant.MENU_ID, "185");
				map.addAttribute(SystemConstant.SUBMENU_ID, "186");
				view = "UserLoginCreation";
			
		} catch (Exception e) {
			LOGGER.info("EXCEPTION OCCUR ON Method userLoginCreationPage() in controller UserMgmntController :" + e);
			map.addAttribute(SystemConstant.STATUS_MESSAGE, getProperty(SystemConstant.NETWORK_ERROR_MESSAGE));
			view = ScSystemConstant.HOMEPAGE;
		}

		return new ModelAndView(view, map);
	}

	@RequestMapping(value = "/getSignUpPageOtp", method = RequestMethod.POST)
	public ModelAndView UserLoginCreationPageOtp(
			@ModelAttribute(value = "subscriberData") SubscriberData subscriberData, HttpSession session,
			HttpServletRequest request) {
		String view = "";
		try {
			LOGGER.info("**********Execution start of method UserLoginCreationPage() in controller ScLoginController ");
				Integer otp = loginService.getOtpOnSignUp(subscriberData.getMobile());
				loginService.updateSignUpDetails(subscriberData.getMobile());
				loginService.saveSignupDetails(subscriberData,otp);
				SubscriberData subscriberDto=iUserMgmntService.getSubscriberByMobileNumber(subscriberData.getMobile());
				subscriberData.setName(subscriberDto!=null?subscriberDto.getName():"");
				map.addAttribute(ScSystemConstant.SUBSCRIBERDATA, subscriberData);
				map.addAttribute(SystemConstant.ERRORSTATUSMESSAGE, "");
				map.addAttribute(SystemConstant.STATUS_MESSAGE, "");
				map.addAttribute(SystemConstant.MENU_ID, "185");
				map.addAttribute(SystemConstant.SUBMENU_ID, "186");
				view = ScSystemConstant.SIGN_UP_PAGE_OTP;
			
		} catch (Exception e) {
			LOGGER.info("EXCEPTION OCCURE ON Method userLoginCreationPage() in controller UserMgmntController :" + e);
			map.addAttribute(SystemConstant.STATUS_MESSAGE, getProperty(SystemConstant.NETWORK_ERROR_MESSAGE));
			view = ScSystemConstant.HOMEPAGE;
		}

		return new ModelAndView(view, map);
	}

	/**
	 * @param userLoginCreationData
	 * @param session
	 * @return
	 * 
	 */
	@RequestMapping(value = "/submitLoginCreationPage")
	public ModelAndView submitLoginCreationPage(
			@ModelAttribute(value = "subscriberData") SubscriberData subscriberData, HttpSession session,
			HttpServletRequest request) {
		String view = "";
		try {
			LOGGER.info("**********Execution start of method submitLoginCreationPage() in controller ScLoginController ");
			LoginData loginData = new LoginData();
			Integer otp=loginService.getActiveOtp(subscriberData.getMobile());
			if(subscriberData.getOtpOnSignUp().equals(otp)){
			SubscriberData subscriberData1 = loginService.submitUserCreationData(subscriberData);	
			map.addAttribute(ScSystemConstant.SUBSCRIBERDATA, subscriberData);
			map.addAttribute(SystemConstant.STATUS_MESSAGE, getProperty(subscriberData1.getMsg()));
			map.addAttribute(SystemConstant.ERRORSTATUSMESSAGE, subscriberData1.getErrorMsg());
			map.addAttribute(SystemConstant.MENU_ID, "104");
			map.addAttribute(SystemConstant.SUBMENU_ID, "107");
			map.addAttribute(ScSystemConstant.LOGINDATA, loginData);
			view = ScSystemConstant.LOGIN_PAGE;
			}else{
				
				view = ScSystemConstant.SIGN_UP_PAGE_OTP;
				map.addAttribute(SystemConstant.ERRORSTATUSMESSAGE, "Invalid OTP!");
			}
		} catch (Exception e) {
			LOGGER.info("EXCEPTION OCCURE ON Method submitLoginCreationPage() in controller ScLoginController :" + e);
			map.addAttribute(SystemConstant.STATUS_MESSAGE, SystemConstant.NETWORK_ERROR_MSG);
			view = "home";
		}

		return new ModelAndView(view, map);
	}

	/**
	 * @param loginData
	 * @param session
	 * @return Menu SysAccountGroup Accountsession
	 */
	@RequestMapping(value = "/validateAccount")
	public ModelAndView validateAccount(@ModelAttribute(value = "loginData") LoginData loginData, HttpSession session) {

		String view = "";
		LOGGER.debug("validateAccount");
		try {


			LoginData	loginDatainfo = loginService.validateAccount(loginData);
			
		
			session.setAttribute(ScSystemConstant.LOGINDATA, loginDatainfo);
			session.setAttribute("loginId", loginDatainfo.getSubscriberMobNo());
			session.setAttribute("key", loginDatainfo.getKey());
			session.setAttribute("tokenId", loginDatainfo.getTokenId());
		
			session.setAttribute("sessionId", loginDatainfo.getSessionId());
			session.setAttribute("accuntTypeId", loginDatainfo.getAccountTypeId());
  
				view = loginData.getView();
				map.addAttribute("passwordexpire", 0);
				map.addAttribute(ScSystemConstant.LOGINDATA, loginData);
				if(loginData.getView().equals(ScSystemConstant.LOGIN_PAGE))
				{
					map.addAttribute(SystemConstant.STATUS_MESSAGE,loginDatainfo.getMessage());
					return new ModelAndView(view, map);
					
				}else{
				return new ModelAndView("redirect:/AdminUI/UserMgmt/getIndexPage");
				}
		} catch (Exception e) {
			map.addAttribute(SystemConstant.STATUS_MESSAGE,
					messageSource.getMessage(SystemConstant.NETWORK_ERROR_MESSAGE, null, Locale.getDefault()) + e);
			LOGGER.debug("Error to get user info");
			loginData.setView(SystemConstant.LOGIN_TRANSFER_PAGE);
		}
		session.setAttribute(SystemConstant.STATUS_MESSAGE, "");
		return new ModelAndView(loginData.getView(), map);
	}

	/**
	 * @Post method for adminForm Gets the session Attribute as Input parameter
	 * 
	 * @return possible object is {@link ModelAndView }
	 * 
	 *         returning a jsp View Name and ModelMap contain StatusMessage
	 */
	@RequestMapping(value = "/logout")
	public ModelAndView logout(HttpSession session) {

		LOGGER.debug("logout Page");
		LoginData loginData = (LoginData) session.getAttribute(ScSystemConstant.LOGINDATA);
		LogoutData logoutData;
		try {
			if(loginData == null)
				loginData = new LoginData();
			
			logoutData = loginService.logout(loginData,session);
			session.removeAttribute("sessionId");
			loginData.setView("/selfcare/views/transferToLoginPage.jsp");
			if (logoutData != null) {
				session.setAttribute(SystemConstant.STATUS_MESSAGE, logoutData.getStatusMessage());
				map.addAttribute(SystemConstant.STATUS_MESSAGE, logoutData.getStatusMessage());
			}
		} catch (Exception e) {
			map.addAttribute(SystemConstant.STATUS_MESSAGE,
					messageSource.getMessage(SystemConstant.NETWORK_ERROR_MESSAGE, null, Locale.getDefault()));
			loginData.setView("/selfcare/views/transferToLoginPage.jsp");
			LOGGER.debug("Exception caught in logout() method of ScLoginController" + e);
		}
		return new ModelAndView(new RedirectView(loginData.getView()));
	}

	@RequestMapping(value = "/validatepasswordexpire")
	 @ResponseBody public boolean validatePassExp(HttpSession session, HttpServletRequest request,
			@RequestParam(value = "id") String id) {

		return true;
	}

	@RequestMapping(value = "getOtpOnSignUp", method = RequestMethod.POST)
	 @ResponseBody public String getOtpOnSignUp(@RequestParam(value = "mobileNo") String mobileNo, HttpSession session) {
		try {
			LOGGER.info("Execution start of getOtpOnSignUp() method in ScLoginController");
			
		} catch (Exception ex) {
			LOGGER.debug("Exception caught in getOtpOnSignUp() method of ScLoginController" + ex);
		}
		LOGGER.info("Execution end of getOtpOnSignUp() method in ScLoginController");
		return "Enter One Time Password(OTP) sent to your mobile number " + mobileNo + ".";
	}
	@RequestMapping(value = "resendOtp")
	public ModelAndView resendOtp(
			@ModelAttribute(value = "subscriberData") SubscriberData subscriberData, HttpSession session,
			HttpServletRequest request) {
		String view = "";
		String mobileNo=request.getParameter("mobile");
		String email=request.getParameter("emailId");
		String dob=request.getParameter("dob");
		String password=request.getParameter("userPassword");
		subscriberData.setEmailId(email);
		subscriberData.setDob(dob);
		subscriberData.setUserPassword(password);
		try {
			LOGGER.info("**********Execution start of method UserLoginCreationPage() in controller ScLoginController ");
				subscriberData.setMobile(mobileNo);
				Integer otp = loginService.getOtpOnSignUp(subscriberData.getMobile());
				loginService.updateSignUpDetails(subscriberData.getMobile());
				loginService.saveSignupDetails(subscriberData,otp);
				session.setAttribute("generatedotp", otp);
				map.addAttribute(ScSystemConstant.SUBSCRIBERDATA, subscriberData);
				map.addAttribute(SystemConstant.STATUS_MESSAGE, "");
				map.addAttribute(SystemConstant.ERRORSTATUSMESSAGE, "");
				map.addAttribute(SystemConstant.MENU_ID, "185");
				map.addAttribute(SystemConstant.SUBMENU_ID, "186");
				view = ScSystemConstant.SIGN_UP_PAGE_OTP;
			
		} catch (Exception e) {
			LOGGER.info("EXCEPTION OCCURE ON Method userLoginCreationPage() in controller UserMgmntController :" + e);
			map.addAttribute(SystemConstant.STATUS_MESSAGE, getProperty(SystemConstant.NETWORK_ERROR_MESSAGE));
			view = ScSystemConstant.HOMEPAGE;
		}

		return new ModelAndView(view, map);

	}
	
	@RequestMapping(value = "/checkfieled")
	 @ResponseBody public int checkfiled(@RequestParam(value = "val") String value,@RequestParam(value = "table") String tablename,@RequestParam(value = "field") String field) {
	
		int count =0;
		
		
		LOGGER.info("Execution start of checkfiled() mehtod in ASecureBnakingController");
		try
		{
	            count = iUserMgmntService.checkfiled(value,tablename,field);
		}
		catch(Exception ex)    
		{
			LOGGER.error("Exception occured in checkfiled() method in checkfiled--->"+ex);
		}
		LOGGER.info("Execution end of checkfiled() mehtod in checkfiled");
		return count;
		
		
	}
	
	@RequestMapping(value = "/subscriberExist")
	 @ResponseBody public int subscriberExist(@RequestParam(value = "mobile") String mobile) {
	
		int count =0;
		
		
		LOGGER.info("Execution start of checkfiled() mehtod in ASecureBnakingController");
		try
		{
	            count = iUserMgmntService.subscriberAlreadySignedUp(mobile);
		}
		catch(Exception ex)    
		{
			LOGGER.error("Exception occured in checkfiled() method in checkfiled--->"+ex);
		}
		LOGGER.info("Execution end of checkfiled() mehtod in checkfiled");
		return count;
		
		
	}
	
	}
