/**
 * 
 */
package com.ng.sb.common.dataobject;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author gaurav
 *
 */
@XmlRootElement(name = "CustomerVerificationRequestData")
public class CustomerVerificationRequestData extends PlatformRequestData{
	private static final long serialVersionUID = 1L;
	private Integer masterVersionCode;
	private String productCode;
	private String customerMSISDN;
	private Long externalNumber;
	
	public Long getExternalNumber() {
		return externalNumber;
	}
	public void setExternalNumber(Long externalNumber) {
		this.externalNumber = externalNumber;
	}
	public Integer getMasterVersionCode() {
		return masterVersionCode;
	}
	public void setMasterVersionCode(Integer masterVersionCode) {
		this.masterVersionCode = masterVersionCode;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getCustomerMSISDN() {
		return customerMSISDN;
	}
	public void setCustomerMSISDN(String customerMSISDN) {
		this.customerMSISDN = customerMSISDN;
	}

}
