package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the MerchantInfo database table.
 * 
 */
@Entity
@Table(name="merchant_category")
@NamedQueries
({
	 @NamedQuery(name="merchant_category.findAll", query = "SELECT a FROM MerchantCategory a"),


})
public class MerchantCategory implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "id", unique=true, nullable=false)
	private Integer id;

	@Column(name = "category_code", nullable=false, length=30)
	private String categoryCode;
	
	@Column(name = "category_name", nullable=false)
	private String categoryName;

	@Column(name = "status", nullable=false, length=30)
	private Integer status;

	
	
	
	
	public Integer getId() {
		return id;
	}

	public String getCategoryCode() {
		return categoryCode;
	}

	public void setCategoryCode(String categoryCode) {
		this.categoryCode = categoryCode;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}


}