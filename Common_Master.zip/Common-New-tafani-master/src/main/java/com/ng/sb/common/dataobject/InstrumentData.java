/**
 * 
 */
package com.ng.sb.common.dataobject;

import java.util.Set;

/**
 * @author gaurav
 *
 */
public class InstrumentData extends BaseObjectData {
	private static final long serialVersionUID = 1L;
	public enum Sequence {
		FIRST, SECOND
	}
	private Sequence sequence;
	private Set<PartnerData> partners;
	public InstrumentData() {
		//default constructor
	}

	public InstrumentData(String name) {
		super.setName(name);
	}

	
	public InstrumentData(String name,Sequence sequence) {
		super.setName(name);
		this.sequence=sequence;
	}

	public Sequence getSequence() {
		return sequence;
	}

	public void setSequence(Sequence sequence) {
		this.sequence = sequence;
	}

	

	public Set<PartnerData> getPartners() {
		return partners;
	}

	public void setPartners(Set<PartnerData> partners) {
		this.partners = partners;
	}
	
	@Override
	public boolean equals(Object obj) {
		boolean condition1=false;
		boolean condition2=false;
		
		if (obj == null) {
			return false;
		}
		boolean check=false;
		if ( obj instanceof InstrumentData) {
			InstrumentData other = (InstrumentData) obj;
			if(super.getName()!=null && !super.getName().isEmpty()){
				condition1=true;
			}
			if(other.getName()!=null && !other.getName().isEmpty()){
				condition2=true;
			}
			if (condition1 && condition2 && super.getName().equalsIgnoreCase(other.getName())) {
				check= true;
			}
			return check;
		}
		return super.equals(obj);
	}

	@Override
	public int hashCode() {
		if (super.getName()!=null && !super.getName().isEmpty()) {
			return super.getName().hashCode()*7;
		} else {
			return 0;
		}

	}

}
