/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "CashInDetail")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CashInDetail.findAll", query = "SELECT c FROM CashInDetail c"),
    @NamedQuery(name = "CashInDetail.findById", query = "SELECT c FROM CashInDetail c WHERE c.id = :id"),
    @NamedQuery(name = "CashInDetail.findByMobileNumber", query = "SELECT c FROM CashInDetail c WHERE c.mobileNumber = :mobileNumber"),
    @NamedQuery(name = "CashInDetail.findByPaymentMode", query = "SELECT c FROM CashInDetail c WHERE c.paymentMode = :paymentMode"),
    @NamedQuery(name = "CashInDetail.findByAmount", query = "SELECT c FROM CashInDetail c WHERE c.amount = :amount"),
    @NamedQuery(name = "CashInDetail.findByTopUpDate", query = "SELECT c FROM CashInDetail c WHERE c.topUpDate = :topUpDate")})
public class CashInDetail implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
    @Basic(optional = false)
    @Column(name = "mobileNumber", nullable = false, length = 10)
    private String mobileNumber;
    @Basic(optional = false)
    @Column(name = "paymentMode", nullable = false, length = 11)
    private String paymentMode;
    @Basic(optional = false)
    @Column(name = "amount", nullable = false)
    private float amount;
    @Basic(optional = false)
    @Column(name = "topUpDate", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date topUpDate;
    @JoinColumn(name = "cashInBy", referencedColumnName = "id", nullable = false)
    @ManyToOne(optional = false)
    private AccountInfo cashInBy;
    @JoinColumn(name = "cashInFor", referencedColumnName = "id", nullable = false)
    @ManyToOne(optional = false)
    private AccountInfo cashInFor;

    public CashInDetail() {
    	//default constructor
    }

    public CashInDetail(Integer id) {
        this.id = id;
    }

    public CashInDetail(Integer id, String mobileNumber, String paymentMode, float amount, Date topUpDate) {
        this.id = id;
        this.mobileNumber = mobileNumber;
        this.paymentMode = paymentMode;
        this.amount = amount;
        this.topUpDate = topUpDate;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getPaymentMode() {
        return paymentMode;
    }

    public void setPaymentMode(String paymentMode) {
        this.paymentMode = paymentMode;
    }

    public float getAmount() {
        return amount;
    }

    public void setAmount(float amount) {
        this.amount = amount;
    }

    public Date getTopUpDate() {
        return topUpDate;
    }

    public void setTopUpDate(Date topUpDate) {
        this.topUpDate = topUpDate;
    }

    public AccountInfo getCashInBy() {
        return cashInBy;
    }

    public void setCashInBy(AccountInfo cashInBy) {
        this.cashInBy = cashInBy;
    }

    public AccountInfo getCashInFor() {
        return cashInFor;
    }

    public void setCashInFor(AccountInfo cashInFor) {
        this.cashInFor = cashInFor;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof CashInDetail)) {
            return false;
        }
        CashInDetail other = (CashInDetail) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.CashInDetail[ id=" + id + " ]";
    }
    
}
