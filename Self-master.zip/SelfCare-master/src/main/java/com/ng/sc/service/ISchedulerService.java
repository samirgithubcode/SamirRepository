package com.ng.sc.service;

@FunctionalInterface  
public interface ISchedulerService {
	public void schedule(int timeout, int otp);

}
