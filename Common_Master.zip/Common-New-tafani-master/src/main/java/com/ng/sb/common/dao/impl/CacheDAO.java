package com.ng.sb.common.dao.impl;

import org.springframework.stereotype.Repository;

/**
 * @author amardeep
 *
 */
@Repository
public class CacheDAO extends SuperParentDAO {}
