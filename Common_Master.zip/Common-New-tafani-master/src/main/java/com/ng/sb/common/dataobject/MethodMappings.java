/**
 * 
 */
package com.ng.sb.common.dataobject;

import java.util.HashMap;
import java.util.Map;

/**
 * @author gaurav
 *
 */
public class MethodMappings extends BaseObjectData {
	private static final long serialVersionUID = 1L;
	private Map<String,String> methodMap = new HashMap<>();
	
	public MethodMappings(String fspMethodName,String firstCallMethodName,String secondCallMethodName,String riFspMethodName){
		methodMap.put(IConstants.METHOD_FSP, fspMethodName);
		methodMap.put(IConstants.METHOD_FIRST_CALL, firstCallMethodName);
		methodMap.put(IConstants.METHOD_SECOND_CALL, secondCallMethodName);
		methodMap.put(IConstants.METHOD_RI_FSP, riFspMethodName);
	}

	public Map<String, String> getMethodMap() {
		return methodMap;
	}

	public void setMethodMap(Map<String, String> methodMap) {
		this.methodMap = methodMap;
	}
	
}
