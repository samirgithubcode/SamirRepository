package com.ng.sb.common.dataobject;

public class IdProofVerificationData extends BaseObjectData{
	private static final long serialVersionUID = 1L;
	private String status;
	private String type;
	private String idNo;
	private String docName;
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getIdNo() {
		return idNo;
	}
	public void setIdNo(String idNo) {
		this.idNo = idNo;
	}
	public String getDocName() {
		return docName;
	}
	public void setDocName(String docName) {
		this.docName = docName;
	}

}
