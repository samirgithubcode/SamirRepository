/**
 * 
 */
package com.ng.bridge.service.impl;

import org.springframework.stereotype.Service;

import com.ng.bridge.service.IFundTransferMgtService;
import com.ng.sb.common.util.SystemConstant;

/**
 * @author gaurav
 *
 */
@Service(value=SystemConstant.BRIDGE_FUND_TRANSFER_MGT_SERVICE)
public class FundTransferMgtService extends FundMgtService implements IFundTransferMgtService {

}
