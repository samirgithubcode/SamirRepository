/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "query_transaction_info")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "QueryTransactionInfo.findAll", query = "SELECT q FROM QueryTransactionInfo q"),
    @NamedQuery(name = "QueryTransactionInfo.findById", query = "SELECT q FROM QueryTransactionInfo q WHERE q.id = :id"),
    @NamedQuery(name = "QueryTransactionInfo.findByTransactionId", query = "SELECT q FROM QueryTransactionInfo q WHERE q.transactionId = :transactionId"),
    @NamedQuery(name = "QueryTransactionInfo.findByTransactionDesc", query = "SELECT q FROM QueryTransactionInfo q WHERE q.transactionDesc = :transactionDesc"),
    @NamedQuery(name = "QueryTransactionInfo.findByTransStatus", query = "SELECT q FROM QueryTransactionInfo q WHERE q.transStatus = :transStatus"),
    @NamedQuery(name = "QueryTransactionInfo.findByAddByDate", query = "SELECT q FROM QueryTransactionInfo q WHERE q.addByDate = :addByDate"),
    @NamedQuery(name = "QueryTransactionInfo.findByEditByDate", query = "SELECT q FROM QueryTransactionInfo q WHERE q.editByDate = :editByDate")})
public class QueryTransactionInfo implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
    @Basic(optional = false)
    @Column(name = "transaction_id", nullable = false, length = 20)
    private String transactionId;
    @Basic(optional = false)
    @Column(name = "transaction_desc", nullable = false, length = 100)
    private String transactionDesc;
    @Basic(optional = false)
    @Column(name = "trans_status", nullable = false)
    private int transStatus;
    @Basic(optional = false)
    @Column(name = "add_by_date", nullable = false, length = 20)
    private String addByDate;
    @Column(name = "edit_by_date", length = 20)
    private String editByDate;
    @JoinColumn(name = "query_id", referencedColumnName = "id", nullable = false)
    @ManyToOne(optional = false)
    private TicketQueryDetails queryId;

    public QueryTransactionInfo() {
    	//default constructor
    }

    public QueryTransactionInfo(Integer id) {
        this.id = id;
    }

    public QueryTransactionInfo(Integer id, String transactionId, String transactionDesc, int transStatus, String addByDate) {
        this.id = id;
        this.transactionId = transactionId;
        this.transactionDesc = transactionDesc;
        this.transStatus = transStatus;
        this.addByDate = addByDate;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getTransactionDesc() {
        return transactionDesc;
    }

    public void setTransactionDesc(String transactionDesc) {
        this.transactionDesc = transactionDesc;
    }

    public int getTransStatus() {
        return transStatus;
    }

    public void setTransStatus(int transStatus) {
        this.transStatus = transStatus;
    }

    public String getAddByDate() {
        return addByDate;
    }

    public void setAddByDate(String addByDate) {
        this.addByDate = addByDate;
    }

    public String getEditByDate() {
        return editByDate;
    }

    public void setEditByDate(String editByDate) {
        this.editByDate = editByDate;
    }

    public TicketQueryDetails getQueryId() {
        return queryId;
    }

    public void setQueryId(TicketQueryDetails queryId) {
        this.queryId = queryId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof QueryTransactionInfo)) {
            return false;
        }
        QueryTransactionInfo other = (QueryTransactionInfo) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.QueryTransactionInfo[ id=" + id + " ]";
    }
    
}
