package com.ng.pnb.bridge.dao.impl;

import java.util.List;
import java.util.Map;

import com.ng.sb.common.dataobject.BankAccount;
import com.ng.sb.common.dataobject.Wallet;
import com.ng.sb.common.model.Account;
import com.ng.sb.common.model.AccountTransaction;
import com.ng.sb.common.model.CustomerWallets;
import com.ng.sb.common.model.Partner;

public interface IAccountTransactionDAO {

	public List<Account> validateBank(BankAccount bankAccount);
	public Account saveAccount(Account account);
	public List<Account> validateWallet(Wallet payeeWallet, Map<Integer, Partner> walletMap);
	public List<Partner> fetchAllWalets();
	public List<AccountTransaction> getMiniStatement(Account payerAccount);
	public AccountTransaction saveAccountTransaction(AccountTransaction account);
	public Account updateAccounts(Account account);
	
	public CustomerWallets getWallletDetails(Wallet walletDetails);
	
	public boolean saveEntity(Object entityObject);
	
	public boolean updateEntity(Object entityObject);
}
