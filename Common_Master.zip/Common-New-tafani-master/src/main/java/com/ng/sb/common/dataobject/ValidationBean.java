/**
 * 
 */
package com.ng.sb.common.dataobject;

import java.io.Serializable;

/**
 * @author gopal
 *
 */
public interface ValidationBean extends Serializable {

}
