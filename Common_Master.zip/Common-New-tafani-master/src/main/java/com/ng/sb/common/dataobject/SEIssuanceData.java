package com.ng.sb.common.dataobject;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

/**
 * @author abhishek
 *
 */
public class SEIssuanceData extends BaseObjectData{

	private static final long serialVersionUID = 1L;
	private String userType;
	private String company;
	private String product;
	private String hostName;
	private String externalNumber;
	private String status;
	private Integer productType;
	private String externalNo;
	private String masterVersion;
	private Integer subVersion;
	private String pinCode;
	private String address;
	private String locality;
	private String region;
	private String district;
	private String state;
	private String country;
	private Date dob;
	private String email;
	private String custMobileNo;
	private Integer agentName;
	private String agentMobileNo;
	private String agentUserType;
	private String firstName;
	private String lastName;
	private String[] idNo;
	private Integer[] idProofCheck;
	private Map<Integer,String> products;
	private Map<Integer,String> hostSubVersion;
	private List<String> wallets;
	private List<SEIssuanceData> seIssueList;
	private Map<Integer,String> agents;
	private Map<Integer,String> idproofs;
	private Map<Integer,String> businessIdProofs;
	private KYCDescriptorData descriptorData;
	private List<KYCDescriptorData> kycData;
	private String[] fileName;
	private Integer[] idProofId;
	private String[] userIdNo;
	private transient MultipartFile[] file;
	private String custId;
	private Integer mgmtId;
	private Integer pinAddressId;
	private Integer mvId;
	private Integer hSVId;
	private short kycGiven;
	
	private Integer createdBy;
	private Integer modifiedBy;
	private Date createdOn;
	private Date modifiedOn;
	private String comment;
	private Integer loginId;
	
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public Date getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public short getKycGiven() {
		return kycGiven;
	}
	public void setKycGiven(short kycGiven) {
		this.kycGiven = kycGiven;
	}
	public Integer gethSVId() {
		return hSVId;
	}
	public void sethSVId(Integer hSVId) {
		this.hSVId = hSVId;
	}
	public Integer getMvId() {
		return mvId;
	}
	public void setMvId(Integer mvId) {
		this.mvId = mvId;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public String getHostName() {
		return hostName;
	}
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}
	public String getExternalNumber() {
		return externalNumber;
	}
	public void setExternalNumber(String externalNumber) {
		this.externalNumber = externalNumber;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Integer getProductType() {
		return productType;
	}
	public void setProductType(Integer productType) {
		this.productType = productType;
	}
	public String getExternalNo() {
		return externalNo;
	}
	public void setExternalNo(String externalNo) {
		this.externalNo = externalNo;
	}
	public String getMasterVersion() {
		return masterVersion;
	}
	public void setMasterVersion(String masterVersion) {
		this.masterVersion = masterVersion;
	}
	public Integer getSubVersion() {
		return subVersion;
	}
	public void setSubVersion(Integer subVersion) {
		this.subVersion = subVersion;
	}
	public String getPinCode() {
		return pinCode;
	}
	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getLocality() {
		return locality;
	}
	public void setLocality(String locality) {
		this.locality = locality;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}

	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public Date getDob() {
		return dob;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public void setDob(java.sql.Date dob) {
		this.dob = dob;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCustMobileNo() {
		return custMobileNo;
	}
	public void setCustMobileNo(String custMobileNo) {
		this.custMobileNo = custMobileNo;
	}
	public Integer getAgentName() {
		return agentName;
	}
	public void setAgentName(Integer agentName) {
		this.agentName = agentName;
	}
	public String getAgentMobileNo() {
		return agentMobileNo;
	}
	public void setAgentMobileNo(String agentMobileNo) {
		this.agentMobileNo = agentMobileNo;
	}
	public String getAgentUserType() {
		return agentUserType;
	}
	public void setAgentUserType(String agentUserType) {
		this.agentUserType = agentUserType;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String[] getIdNo() {
		return idNo;
	}
	public void setIdNo(String[] idNo) {
		this.idNo = idNo;
	}
	public Integer[] getIdProofCheck() {
		return idProofCheck;
	}
	public void setIdProofCheck(Integer[] idProofCheck) {
		this.idProofCheck = idProofCheck;
	}
	public Map<Integer, String> getProducts() {
		return products;
	}
	public void setProducts(Map<Integer, String> products) {
		this.products = products;
	}
	public Map<Integer, String> getHostSubVersion() {
		return hostSubVersion;
	}
	public void setHostSubVersion(Map<Integer, String> hostSubVersion) {
		this.hostSubVersion = hostSubVersion;
	}
	public List<String> getWallets() {
		return wallets;
	}
	public void setWallets(List<String> wallets) {
		this.wallets = wallets;
	}
	public List<SEIssuanceData> getSeIssueList() {
		return seIssueList;
	}
	public void setSeIssueList(List<SEIssuanceData> seIssueList) {
		this.seIssueList = seIssueList;
	}
	public Map<Integer, String> getAgents() {
		return agents;
	}
	public void setAgents(Map<Integer, String> agents) {
		this.agents = agents;
	}
	public Map<Integer, String> getIdproofs() {
		return idproofs;
	}
	public void setIdproofs(Map<Integer, String> idproofs) {
		this.idproofs = idproofs;
	}
	public KYCDescriptorData getDescriptorData() {
		return descriptorData;
	}
	public void setDescriptorData(KYCDescriptorData descriptorData) {
		this.descriptorData = descriptorData;
	}
	public List<KYCDescriptorData> getKycData() {
		return kycData;
	}
	public void setKycData(List<KYCDescriptorData> kycData) {
		this.kycData = kycData;
	}
	public String[] getFileName() {
		return fileName;
	}
	public void setFileName(String[] fileName) {
		this.fileName = fileName;
	}
	public Integer[] getIdProofId() {
		return idProofId;
	}
	public void setIdProofId(Integer[] idProofId) {
		this.idProofId = idProofId;
	}
	public String[] getUserIdNo() {
		return userIdNo;
	}
	public void setUserIdNo(String[] userIdNo) {
		this.userIdNo = userIdNo;
	}
	public MultipartFile[] getFile() {
		return file;
	}
	public void setFile(MultipartFile[] file) {
		this.file = file;
	}
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	public Integer getMgmtId() {
		return mgmtId;
	}
	public void setMgmtId(Integer mgmtId) {
		this.mgmtId = mgmtId;
	}
	public void setPinAddressId(Integer pinAddressId) {
		this.pinAddressId = pinAddressId;
	}
	public Integer getPinAddressId(){
		return pinAddressId;
	}
		public Map<Integer, String> getBusinessIdProofs() {
		return businessIdProofs;
	}
	public void setBusinessIdProofs(Map<Integer, String> businessIdProofs) {
		this.businessIdProofs = businessIdProofs;
	}
	public Integer getLoginId() {
		return loginId;
	}
	public void setLoginId(Integer loginId) {
		this.loginId = loginId;
	}
}
