package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name = "product_service_mapping_History")
@XmlRootElement
@NamedQueries({

		@NamedQuery(name = "ProductServiceMappingHistory.findAll", query = "SELECT p FROM ProductServiceMappingHistory p"),
		@NamedQuery(name = "ProductServiceMappingHistory.findAllById", query = "SELECT p FROM ProductServiceMappingHistory p where p.addedBy=:addedBy"),

})
public class ProductServiceMappingHistory implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(unique = true, nullable = false)
	private int id;

	@ManyToOne
	@JoinColumn(name = "product_id", referencedColumnName = "id")
	private Products productId;

	@Column(name = "product_service_mapping_Id")
	private Integer productServiceMappingId;

	@Column(name = "addedOn")
	@Temporal(TemporalType.DATE)
	private Date addedOn;

	@ManyToOne
	@JoinColumn(name = "instrument_id", referencedColumnName = "id")
	private FinancialInstruments instrumentId;

	@ManyToOne
	@JoinColumn(name = "instrument_service_id", referencedColumnName = "id")
	private FinancialServices instrumentserviceId;

	@Column(name = "startdate")
	@Temporal(TemporalType.DATE)
	private Date startDate;
	@Column(name = "enddate")
	@Temporal(TemporalType.DATE)
	private Date endDate;

	@Column(name = "modifiedBy", length = 8)
	private int modifiedBy;

	@Column(name = "modifiedOn")
	private Date modifiedOn;

	@Column(name = "addedBy", length = 8)
	private int addedBy;

	@Column(name = "status", length = 1)
	private boolean status;

	public ProductServiceMappingHistory() {
		/*
		 * 
		 */
	}

	public ProductServiceMappingHistory(int id) {
		super();
		this.id = id;
	}

	public int getId() {
		return id;
	}

	@Override
	public int hashCode() {
		 int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Products getProductId() {
		return productId;
	}

	public void setProductId(Products productId) {
		this.productId = productId;
	}

	public Integer getProductServiceMappingId() {
		return productServiceMappingId;
	}

	public void setProductServiceMappingId(Integer productServiceMappingId) {
		this.productServiceMappingId = productServiceMappingId;
	}

	public Date getEndDate() {
		return endDate;
	}

	public FinancialInstruments getInstrumentId() {
		return instrumentId;
	}

	public FinancialServices getInstrumentserviceId() {
		return instrumentserviceId;
	}

	public void setInstrumentserviceId(FinancialServices instrumentserviceId) {
		this.instrumentserviceId = instrumentserviceId;
	}

	public void setInstrumentId(FinancialInstruments instrumentId) {
		this.instrumentId = instrumentId;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProductServiceMappingHistory other = (ProductServiceMappingHistory) obj;
		boolean check=true;
		if (id != other.id)
			check= false;
		return check;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

}
