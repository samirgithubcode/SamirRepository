package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * @author abhishek
 *
 */
@Entity
@Table(name="ShippingInfo")
@NamedQueries({
@NamedQuery(name="ShippingInfo.findAll", query="SELECT s FROM ShippingInfo s"),
@NamedQuery(name="ShippingInfo.findByShippingNumber", query="SELECT s FROM ShippingInfo s WHERE s.shippingNumber = :shippingNumber"),
@NamedQuery(name="ShippingInfo.getByShipBy", query="SELECT s FROM ShippingInfo s WHERE s.shipBy=:shipBy AND s.packageId IS NOT NULL"),
@NamedQuery(name="ShippingInfo.getByShipTo", query="SELECT s FROM ShippingInfo s WHERE s.shipTo=:shipTo AND s.packageId IS NOT NULL "),
@NamedQuery(name="ShippingInfo.findByOrderNumber", query="SELECT s FROM ShippingInfo s WHERE s.orderno=:ordernumber "),
@NamedQuery(name="ShippingInfo.getShippingInfoById", query="SELECT s FROM ShippingInfo s WHERE s.id=:id "),
})
public class ShippingInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false)
	private Integer id;

	@Column(name="creationDate",nullable=false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date creationDate;
	
	

	@Column(name="shippingDate")
	@Temporal(TemporalType.TIMESTAMP)
	private Date shippingDate;

	@Column(name="shippingNumber")
	private String shippingNumber;

	//bi-directional many-to-one association to ShippingDetail
	@OneToMany(mappedBy="shippingInfo")
	private List<ShippingDetail> shippingDetails;

	//bi-directional many-to-one association to AccountInfo
	@ManyToOne
	@JoinColumn(name="shipBy")
	private AccountInfo shipBy;

	//bi-directional many-to-one association to AccountInfo
	@ManyToOne
	@JoinColumn(name="shipTo")
	private AccountInfo shipTo;

	//bi-directional many-to-one association to AccountLoginInfo
	@ManyToOne
	@JoinColumn(name="addedBy")
	private AccountLoginInfo addedBy;
	/**
	 * Bi-Directional
	 */
	/*@OneToMany(mappedBy="shippingInfoId")
	private List<Packaging> packaging;
	
	public List<Packaging> getPackaging() {
		return packaging;
	}

	public void setPackaging(List<Packaging> packaging) {
		this.packaging = packaging;
	}
*/
	 @JoinColumn(name = "packageId", referencedColumnName = "id")
	 @OneToOne
	 private Packaging packageId;
	
	
	
	@Column(name="orderno")
	private String orderno;
	
	@Column(name="shippedItemCount")
	private Integer shippedItemCount;
	
	@Column(name= "shippingStatus")
	private String shippingStatus;
	
	
	public Packaging getPackageId() {
		return packageId;
	}

	public void setPackageId(Packaging packageId) {
		this.packageId = packageId;
	}

	/**
	 * @return the shippingStatus
	 */
	public String getShippingStatus() {
		return shippingStatus;
	}

	/**
	 * @param shippingStatus the shippingStatus to set
	 */
	public void setShippingStatus(String shippingStatus) {
		this.shippingStatus = shippingStatus;
	}

	/**
	 * @return the shippedItemCount
	 */
	public Integer getShippedItemCount() {
		return shippedItemCount;
	}

	/**
	 * @param shippedItemCount the shippedItemCount to set
	 */
	public void setShippedItemCount(Integer shippedItemCount) {
		this.shippedItemCount = shippedItemCount;
	}

	public String getOrderno() {
		return orderno;
	}

	public void setOrderno(String orderno) {
		this.orderno = orderno;
	}

	public ShippingInfo() {
		//empty
	}

	public ShippingInfo(Integer id) {
		this.id = id;
	}
	
	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Date getCreationDate() {
		return this.creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}
	public Date getShippingDate() {
		return shippingDate;
	}

	public void setShippingDate(Date shippingDate) {
		this.shippingDate = shippingDate;
	}

	public String getShippingNumber() {
		return this.shippingNumber;
	}

	public void setShippingNumber(String shippingNumber) {
		this.shippingNumber = shippingNumber;
	}

	public List<ShippingDetail> getShippingDetails() {
		return this.shippingDetails;
	}

	public void setShippingDetails(List<ShippingDetail> shippingDetails) {
		this.shippingDetails = shippingDetails;
	}

	public ShippingDetail addShippingDetail(ShippingDetail shippingDetail) {
		getShippingDetails().add(shippingDetail);
		shippingDetail.setShippingInfo(this);

		return shippingDetail;
	}

	public ShippingDetail removeShippingDetail(ShippingDetail shippingDetail) {
		getShippingDetails().remove(shippingDetail);
		shippingDetail.setShippingInfo(null);

		return shippingDetail;
	}

	public AccountInfo getShipBy() {
		return this.shipBy;
	}

	public void setShipBy(AccountInfo shipBy) {
		this.shipBy = shipBy;
	}

	public AccountInfo getShipTo() {
		return this.shipTo;
	}

	public void setShipTo(AccountInfo shipTo) {
		this.shipTo = shipTo;
	}

	public AccountLoginInfo getAddedBy() {
		return this.addedBy;
	}

	public void setAddedBy(AccountLoginInfo addedBy) {
		this.addedBy = addedBy;
	}
	
	@Override
	public String toString() {
		return "ShippingInfo [id=" + id + "]";
	}

}