/**
 * 
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

/**
 * @author gopal
 *
 */
@Entity
@Table(name = "product_transactions")
@NamedQueries({
	@NamedQuery(name = "ProductTransactions.findAllbywalletid&subid", query = "select p from  ProductTransactions p where p.walletid=:walletid AND p.customerId=:customerId"),
	@NamedQuery(name = "ProductTransactions.findByTxnId", query = "select p from  ProductTransactions p where p.id = :txnId"),
	@NamedQuery(name = "ProductTransactions.findByRefTxnId", query = "select p from  ProductTransactions p where p.refernceTransactionId=:refernceTransactionId AND p.agentId=:agentId and p.transactionTime=:transactionTime "),
	@NamedQuery(name = "ProductTransactions.getTransactionReport",query = "SELECT p FROM ProductTransactions p WHERE p.walletid=:walletid AND p.transactionTime >= :fromDate AND p.transactionTime <= :toDate AND p.transactionType IN :inclList"),
	@NamedQuery(name = "ProductTransactions.findByAll", query = "select p from  ProductTransactions p order by p.transactionOn desc "),
	@NamedQuery(name = "ProductTransactions.findByAllDate", query = "select p from  ProductTransactions p where Date(p.transactionOn)>=:startDate AND  Date(p.transactionOn)<=:endDate order by p.transactionOn desc "),
	@NamedQuery(name = "ProductTransactions.findByAllTxn", query = "select p from  ProductTransactions p where p.transactionType NOT IN (:txnTypes) order by p.transactionOn desc "),
	@NamedQuery(name = "ProductTransactions.findByAllTxnByDate", query = "select p from  ProductTransactions p where p.transactionType NOT IN (:txnTypes) and Date(p.transactionOn)>=:startDate AND  Date(p.transactionOn)<=:endDate order by p.transactionOn desc "),
	@NamedQuery(name = "ProductTransactions.findAllbyId", query = "select p from  ProductTransactions p where p.id=:id "),		
	@NamedQuery(name = "ProductTransactions.getCommissionableId", query="SELECT pt FROM ProductTransactions pt WHERE pt.transactionStatus = 200 AND (pt.agentId IS NOT NULL OR pt.portalId IS NOT NULL) AND pt.isCommissoinable = true and pt.isRefunded = false AND pt.transactionOn < :tDate AND pt.id >= :minId AND pt.id <= :maxId"),
	@NamedQuery(name = "ProductTransactions.maxEndTxnIdBeforeADay", query = "select max(pt.id) from  ProductTransactions pt WHERE transactionOn < :tDate"),
	@NamedQuery(name = "ProductTransactions.findAllbysubid", query="SELECT p FROM ProductTransactions p where p.customerId=:customerId order by p.transactionTime desc"),
	@NamedQuery(name = "ProductTransactions.findByCcRefTxnId", query = "select p from  ProductTransactions p where p.refernceTransactionId=:refernceTransactionId"),
	@NamedQuery(name = "ProductTransactions.findByDate", query="SELECT p FROM ProductTransactions p where p.transactionTime >= :fromDate AND p.transactionOn < :toDate AND p.customerId=:customerId order by p.transactionTime desc"),
	@NamedQuery(name = "ProductTransactions.findByAllAgents", query = "select p from  ProductTransactions p Where p.agentId!=null"),
	@NamedQuery(name = "ProductTransactions.findByAllTransactiondetails", query = "select p from  ProductTransactions p Where p.agentCompanyId IN (:ids)"),
	@NamedQuery(name = "ProductTransactions.findByAllTransactiondetailsByDate", query = "select p from  ProductTransactions p Where p.agentCompanyId IN (:ids) AND Date(p.transactionOn)>=:startDate AND  Date(p.transactionOn)<=:endDate"),
	@NamedQuery(name = "ProductTransactions.findByAllTxnType", query = "select p from  ProductTransactions p where p.transactionType IN (:txnTypes) and p.customerId=:custId order by p.transactionOn desc "),
	@NamedQuery(name = "ProductTransactions.findByAllTxnTypeByDate", query = "select p from  ProductTransactions p where p.transactionType IN (:txnTypes) and p.customerId=:custId and Date(p.transactionOn)>=:startDate AND  Date(p.transactionOn)<=:endDate order by p.transactionOn desc "),
	@NamedQuery(name = "ProductTransactions.findByAllTxnWithinDate", query = "select p from  ProductTransactions p where  Date(p.transactionOn)>=:startDate AND  Date(p.transactionOn)<=:endDate order by p.transactionOn desc "),
	@NamedQuery(name = "ProductTransactions.findByAllMerchants", query = "select p from  ProductTransactions p  WHERE p.fromUser IN (:fromUser) order by p.transactionOn desc"),
	@NamedQuery(name = "ProductTransactions.findByAllTxnByMerchantWithinDate", query = "select p from  ProductTransactions p where p.agentId=:agentId AND (p.fromUser=:fromUser OR p.toUser=:toUser) AND Date(p.transactionOn)>=:startDate AND  Date(p.transactionOn)<=:endDate order by p.transactionOn desc "),
	@NamedQuery(name = "ProductTransactions.findByAllTxnBySubscriberWithinDate", query = "select p from  ProductTransactions p where p.customerId=:customerId AND (p.fromUser=:fromUser OR p.toUser=:toUser) AND Date(p.transactionOn)>=:startDate AND  Date(p.transactionOn)<=:endDate order by p.transactionOn desc "),
	
	
	
	
})
public class ProductTransactions implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5163583684472511286L;

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	@ManyToOne
	@JoinColumn(name="order_id", referencedColumnName="orderid")
	private ProductOrders orderId;
	
	@Column(name = "ref_txn_id")
	private String refernceTransactionId;
	
	@Column(name = "refund_ref_txn_id")
	private Integer refundReferenceTransactionId;
	
	@ManyToOne
	@JoinColumn(name="product_id", referencedColumnName="id")
	private Products productId;
	
	/*@ManyToOne
	@JoinColumn(name="subscriber_id", referencedColumnName="id")*/
	@Column(name = "subscriber_id")
	private Integer customerId;
	
	@ManyToOne
	@JoinColumn(name="payCardId", referencedColumnName="id")
	//@Column(name="payCardId")
	private InventoryMgmt payCardId;
	
	@Column(name="payCardWalletId")
	private Integer payCardWalletId;
	
	@Column(name="payCardAppId")
	private Integer payCardAppId;
	
	@ManyToOne
	@JoinColumn(name="wallet_id", referencedColumnName="id")
	private UserWalletDetails walletid;
	
	@Column(name = "agent_id")
	private Integer agentId;
	
	@Column(name = "portal_id")
	private Integer portalId;
	
	@Column(name = "txn_time")
	private Date transactionTime;
	
	@Column(name = "from_user")
	private Integer fromUser;
	
	@Column(name = "to_user")
	private Integer toUser;
	
	@Column(name = "txn_type")
	private String transactionType;
	
	@Column(name = "transactionOn")
	private Date transactionOn;
	
	@Column(name = "commission_amount")
	private String commissionAmount;
	
	@Column(name = "txn_amount")
	private String transactionAmount;
	
	@Column(name = "net_txn_amount")
	private String netTransactionAmount;
	
	@Column(name = "opening_balance")
	private String openingBalance;
	
	@Column(name = "closing_balance")
	private String closingBalance;
	
	@Column(name = "settle_status")
	private Integer settlementStatus;
	
	@Column(name = "settle_on")
	private Date settledOn;
	
	@Column(name = "settle_id")
	private Integer settlementId;
	
	@Column(name = "txn_desc")
	private String transactionDescription;
	
	@Column(name = "txn_status")
	private Integer transactionStatus;
	
	
	@Column(name = "access_channel")
	private Integer accessChannel;
	
	@JoinColumn(name = "agent_company_id", referencedColumnName = "id")
    @ManyToOne(fetch=FetchType.LAZY)
    @Fetch(FetchMode.SELECT)
    private AccountInfo agentCompanyId;
	
	@Column(name = "isCommissoinable")
	private boolean isCommissoinable;
	
	@Column(name = "isRefunded")
	private boolean isRefunded = false;
	
	@Column(name = "device_id")
	private String deviceId;
	
	public ProductOrders getOrderId() {
		return orderId;
	}

	public void setOrderId(ProductOrders orderId) {
		this.orderId = orderId;
	}
	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getRefernceTransactionId() {
		return refernceTransactionId;
	}

	public void setRefernceTransactionId(String refernceTransactionId) {
		this.refernceTransactionId = refernceTransactionId;
	}

	public Integer getRefundReferenceTransactionId() {
		return refundReferenceTransactionId;
	}

	public void setRefundReferenceTransactionId(Integer refundReferenceTransactionId) {
		this.refundReferenceTransactionId = refundReferenceTransactionId;
	}

	public Products getProductId() {
		return productId;
	}

	public void setProductId(Products productId) {
		this.productId = productId;
	}

	public Integer getAgentId() {
		return agentId;
	}

	public void setAgentId(Integer agentId) {
		this.agentId = agentId;
	}

	public Integer getPortalId() {
		return portalId;
	}

	public void setPortalId(Integer portalId) {
		this.portalId = portalId;
	}

	public Date getTransactionTime() {
		return transactionTime;
	}

	public void setTransactionTime(Date transactionTime) {
		this.transactionTime = transactionTime;
	}

	public Integer getFromUser() {
		return fromUser;
	}

	public void setFromUser(Integer fromUser) {
		this.fromUser = fromUser;
	}

	public Integer getToUser() {
		return toUser;
	}

	public void setToUser(Integer toUser) {
		this.toUser = toUser;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public Date getTransactionOn() {
		return transactionOn;
	}

	public void setTransactionOn(Date transactionOn) {
		this.transactionOn = transactionOn;
	}

	public String getTransactionAmount() {
		return transactionAmount;
	}

	public void setTransactionAmount(String transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	public String getNetTransactionAmount() {
		return netTransactionAmount;
	}

	public void setNetTransactionAmount(String netTransactionAmount) {
		this.netTransactionAmount = netTransactionAmount;
	}

	public String getOpeningBalance() {
		return openingBalance;
	}

	public void setOpeningBalance(String openingBalance) {
		this.openingBalance = openingBalance;
	}

	public String getClosingBalance() {
		return closingBalance;
	}

	public void setClosingBalance(String closingBalance) {
		this.closingBalance = closingBalance;
	}

	public Integer getSettlementStatus() {
		return settlementStatus;
	}

	public void setSettlementStatus(Integer settlementStatus) {
		this.settlementStatus = settlementStatus;
	}

	public Date getSettledOn() {
		return settledOn;
	}

	public void setSettledOn(Date settledOn) {
		this.settledOn = settledOn;
	}

	public Integer getSettlementId() {
		return settlementId;
	}

	public void setSettlementId(Integer settlementId) {
		this.settlementId = settlementId;
	}

	public Integer getTransactionStatus() {
		return transactionStatus;
	}

	public void setTransactionStatus(Integer transactionStatus) {
		this.transactionStatus = transactionStatus;
	}

	public UserWalletDetails getWalletid() {
		return walletid;
	}

	public void setWalletid(UserWalletDetails walletid) {
		this.walletid = walletid;
	}

	public InventoryMgmt getPayCardId() {
		return payCardId;
	}

	public void setPayCardId(InventoryMgmt payCardId) {
		this.payCardId = payCardId;
	}

	public Integer getPayCardWalletId() {
		return payCardWalletId;
	}

	public void setPayCardWalletId(Integer payCardWalletId) {
		this.payCardWalletId = payCardWalletId;
	}

	public Integer getPayCardAppId() {
		return payCardAppId;
	}

	public void setPayCardAppId(Integer payCardAppId) {
		this.payCardAppId = payCardAppId;
	}
	
	@Override
	public boolean equals(Object object) {
		boolean checkStatus = true;
		if (object != null) {
			if (!(object instanceof ProductTransactions)) {
				checkStatus = false;
			}
			ProductTransactions other = (ProductTransactions) object;
			if ((this.id == null && other.id != null)
					|| (this.id != null && !this.id.equals(other.id))) {
				checkStatus = false;
			}
		}
		return checkStatus;
	}

	@Override
	public int hashCode() {
		int hash = 0;
		hash += (id != null ? id.hashCode() : 0);
		return hash;
	}

	public String getTransactionDescription() {
		return transactionDescription;
	}

	public void setTransactionDescription(String transactionDescription) {
		this.transactionDescription = transactionDescription;
	}

	public Integer getAccessChannel() {
		return accessChannel;
	}

	public void setAccessChannel(Integer accessChannel) {
		this.accessChannel = accessChannel;
	}

	public boolean isCommissoinable() {
		return isCommissoinable;
	}

	public void setCommissoinable(boolean isCommissoinable) {
		this.isCommissoinable = isCommissoinable;
	}

	public boolean isRefunded() {
		return isRefunded;
	}

	public void setRefunded(boolean isRefunded) {
		this.isRefunded = isRefunded;
	}

	public String getCommissionAmount() {
		return commissionAmount;
	}

	public void setCommissionAmount(String commissionAmount) {
		this.commissionAmount = commissionAmount;
	}

	public AccountInfo getAgentCompanyId() {
		return agentCompanyId;
	}

	public void setAgentCompanyId(AccountInfo agentCompanyId) {
		this.agentCompanyId = agentCompanyId;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
}
