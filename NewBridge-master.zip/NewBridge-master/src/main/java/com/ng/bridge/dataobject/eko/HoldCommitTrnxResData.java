package com.ng.bridge.dataobject.eko;

public class HoldCommitTrnxResData {
	private String amount;

    private String fee;

    private String timestamp;

    private String recipientId;

    private String state;

    private String serviceTax;

    private String clientRefId;

    private String customerId;

    private String transactionId;

    private String currency;
    
    private String lastUsedOkeKey;
    
  

    public String getFee ()
    {
        return fee;
    }

    public void setFee (String fee)
    {
        this.fee = fee;
    }
    public String getAmount ()
    {
        return amount;
    }

    public void setAmount (String amount)
    {
        this.amount = amount;
    }
    

    public String getRecipientId ()
    {
        return recipientId;
    }

    public void setRecipientId (String recipientId)
    {
        this.recipientId = recipientId;
    }
    public String getTimestamp ()
    {
        return timestamp;
    }

    public void setTimestamp (String timestamp)
    {
        this.timestamp = timestamp;
    }
    public String getState ()
    {
        return state;
    }

    public void setState (String state)
    {
        this.state = state;
    }

   
    public String getClientRefId ()
    {
        return clientRefId;
    }

    public void setClientRefId (String clientRefId)
    {
        this.clientRefId = clientRefId;
    }
    public String getServiceTax ()
    {
        return serviceTax;
    }

    public void setServiceTax (String serviceTax)
    {
        this.serviceTax = serviceTax;
    }

    public String getCustomerId ()
    {
        return customerId;
    }

    public void setCustomerId (String customerId)
    {
        this.customerId = customerId;
    }

	public String getLastUsedOkeKey() {
		return lastUsedOkeKey;
	}

	public void setLastUsedOkeKey(String lastUsedOkeKey) {
		this.lastUsedOkeKey = lastUsedOkeKey;
	}

    public String getCurrency ()
    {
        return currency;
    }

    public void setCurrency (String currency)
    {
        this.currency = currency;
    }
    public String getTransactionId ()
    {
        return transactionId;
    }

    public void setTransactionId (String transactionId)
    {
        this.transactionId = transactionId ;
    }


   
}
