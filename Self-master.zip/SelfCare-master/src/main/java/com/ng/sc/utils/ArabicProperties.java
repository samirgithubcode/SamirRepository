package com.ng.sc.utils;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.ApplicationScope;
@Component
@ApplicationScope
@PropertySource(value="classpath:message.properties")
public class ArabicProperties {
	@Value("${WTW_MONEY_TRANSFER}")
	private String wtwMoneyTransfer;
	
	@Value("${PRODUCTS}")
	private String products;
	
	@Value("${PROFILE}")
	private String profile;

	@Value("${MY_TRANSACTIONAS}")
	private String myTransactions;

	public String getWtwMoneyTransfer() {
		return wtwMoneyTransfer;
	}

	public String getProducts() {
		return products;
	}

	public String getProfile() {
		return profile;
	}

	public String getMyTransactions() {
		return myTransactions;
	}

	
	
	
}
