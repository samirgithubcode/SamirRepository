/**
 * Service1Locator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ng.bridge.dataobject.euronet.otherservice;

public class Service1Locator extends org.apache.axis.client.Service implements com.ng.bridge.dataobject.euronet.otherservice.Service1 {

	 private java.lang.String basicHttpBindingIService1Address = "https://invas01.euronetworldwide.com/Eurovas2Client/ART/Service1.svc";
	 private java.lang.String basicHttpBindingIService1WSDDServiceName = "BasicHttpBindingIService1";
	  private java.util.HashSet ports = null;

    public Service1Locator() {
    	//default constructor
    }


    public Service1Locator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public Service1Locator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for BasicHttpBinding_IService1
   

    public java.lang.String getBasicHttpBindingIService1Address() {
        return basicHttpBindingIService1Address;
    }

    // The WSDD service name defaults to the port name.
   

    public java.lang.String getBasicHttpBindingIService1WSDDServiceName() {
        return basicHttpBindingIService1WSDDServiceName;
    }

    public void setBasicHttpBindingIService1WSDDServiceName(java.lang.String name) {
        basicHttpBindingIService1WSDDServiceName = name;
    }

    public com.ng.bridge.dataobject.euronet.otherservice.IService1 getBasicHttpBindingIService1() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(basicHttpBindingIService1Address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getBasicHttpBindingIService1(endpoint);
    }

    public com.ng.bridge.dataobject.euronet.otherservice.IService1 getBasicHttpBindingIService1(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        com.ng.bridge.dataobject.euronet.otherservice.BasicHttpBindingIService1Stub stub = new com.ng.bridge.dataobject.euronet.otherservice.BasicHttpBindingIService1Stub(portAddress, this);
		stub.setPortName(getBasicHttpBindingIService1WSDDServiceName());
		return stub;
    }

    public void setBasicHttpBindingIService1EndpointAddress(java.lang.String address) {
        basicHttpBindingIService1Address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (com.ng.bridge.dataobject.euronet.otherservice.IService1.class.isAssignableFrom(serviceEndpointInterface)) {
                com.ng.bridge.dataobject.euronet.otherservice.BasicHttpBindingIService1Stub stub = new com.ng.bridge.dataobject.euronet.otherservice.BasicHttpBindingIService1Stub(new java.net.URL(basicHttpBindingIService1Address), this);
                stub.setPortName(getBasicHttpBindingIService1WSDDServiceName());
                return stub;
            }
        }
        catch (Exception t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("BasicHttpBindingIService1".equals(inputPortName)) {
            return getBasicHttpBindingIService1();
        }
        else  {
            java.rmi.Remote stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) stub).setPortName(portName);
            return stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://tempuri.org/", "Service1");
    }

  
    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://tempuri.org/", "BasicHttpBinding_IService1"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("BasicHttpBinding_IService1".equals(portName)) {
            setBasicHttpBindingIService1EndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }


}
