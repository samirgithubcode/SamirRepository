/**
 * 
 */
package com.ng.transaction.dao.impl;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.ng.sb.common.dao.impl.SuperParentDAO;
import com.ng.sb.common.dataobject.BridgeDataObject;
import com.ng.sb.common.dataobject.CustomerAccountData;
import com.ng.sb.common.dataobject.TransactionData;
import com.ng.sb.common.logger.DateTimeUtil;
import com.ng.sb.common.model.CategoryProviderMapping;
import com.ng.sb.common.model.CustomerCards;
import com.ng.sb.common.model.CustomerDetails;
import com.ng.sb.common.model.CustomerPreferredBiller;
import com.ng.sb.common.model.CustomerWallets;
import com.ng.sb.common.model.InventoryKeyMgmt;
import com.ng.sb.common.model.InventoryMgmt;
import com.ng.sb.common.model.OverlayMerchants;
import com.ng.sb.common.model.Partner;
import com.ng.sb.common.model.PayeeDetails;
import com.ng.sb.common.model.Subscriber;
import com.ng.sb.common.model.TransactionInfo;
import com.ng.sb.common.util.SystemConstant;
import com.ng.transaction.dao.ITransactionDAO;

/**
 * @author gaurav
 * Abstract DAO which will contain common Transaction Implementation. 
 */
@Repository(value=SystemConstant.TRANSACTION_DAO)
public class TransactionDAO extends SuperParentDAO  implements ITransactionDAO {
	private static Map<String,String> dKeyMap = new HashMap<String, String>();
	static{
		dKeyMap.put("B", "1");
		dKeyMap.put("C", "2");
		dKeyMap.put("D", "3");
		dKeyMap.put("E", "4");
		dKeyMap.put("F", "5");
	}
	private static final long serialVersionUID = 1L;
	@Override
	public TransactionInfo saveTransactionInfo(BridgeDataObject bridgeDataObject)
	{
		TypedQuery<TransactionInfo> query = null;
		TransactionInfo transactionInfo=null;
		try
		{
			 Query nativeQuery = entityManager.createNativeQuery("INSERT INTO secure_banking_schema.TransactionInfo (txnId, mvCode,hCode,hvCode,msisdn,serviceDefnitioon,shortCode,remoteIp,productCode,skuInternalNumber,requestMsg,responseMsg,responseStatus,date) " +
			            " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			 String xyz=DateTimeUtil.getDateAndTime("dd-MM-yyyy", new Date());
			 nativeQuery.setParameter(1,null);
			 nativeQuery.setParameter(2,null);
			 nativeQuery.setParameter(3, null);
			 nativeQuery.setParameter(4, null);
			 nativeQuery.setParameter(5,null);
			 nativeQuery.setParameter(6, null);
			 nativeQuery.setParameter(7, null);
			 nativeQuery.setParameter(8, null);
			 nativeQuery.setParameter(9, null);
			 nativeQuery.setParameter(10,null);
			 nativeQuery.setParameter(11,null);
			 nativeQuery.setParameter(12,null);
			 nativeQuery.setParameter(13,null);
			 nativeQuery.setParameter(14,xyz);
			 nativeQuery.executeUpdate(); 
			 query=entityManager.createNamedQuery("TransactionInfo.findByTxnId", TransactionInfo.class);
			 query.setParameter("txnId",bridgeDataObject.getTransactionData().getTransactionId());
			 transactionInfo=query.getSingleResult();
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return transactionInfo;
	}
	
	private String getKeyColumn(TransactionData transactionData){
		if(transactionData.getdKeyChar()!=null && !transactionData.getdKeyChar().isEmpty()){
			return "dKey" + dKeyMap.get(transactionData.getdKeyChar());
		}
		return "dKey";
	}
	
	
	private String getKeyColumn(TransactionData transactionData, List<InventoryKeyMgmt> keys)
	{
		String keyName = null;
		String finalKey = null;
		
		if(transactionData.getdKeyChar()!=null && !transactionData.getdKeyChar().isEmpty()){
			keyName = "D_Key" + dKeyMap.get(transactionData.getdKeyChar());
		}
		
		if(keyName != null)
		{
			for(InventoryKeyMgmt keyData : keys)
				if(keyData.getKeyName().equalsIgnoreCase(keyName))
				{
					finalKey = keyData.getKeyValue();
					break;
				}
		}
		
		return finalKey;
	}
	
	@Override
	public Object[] customerDetails(TransactionData transactionData)
	{
		
		Object[] object=null;
		String customerDetailsQuery="select internalNo,mvId,hsvId, "+ getKeyColumn(transactionData) + ",externalNo from InventoryMgmt im inner join Subscriber s  on im.id=s.invMgtId where im.customerMSISDN=:msisdn and s.status='ACTIVE'";
		try																											
		{
			Query nativeQuery = entityManager.createNativeQuery(customerDetailsQuery).setParameter("msisdn", transactionData.getMsisdn());
			object=(Object[])nativeQuery.getSingleResult();
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return object;
	}
	
	@Override
	public Object[] customerDetailsByInventory(TransactionData transactionData)
	{
		
		Object[] object=new Object[5];
		//String customerDetailsQuery="select internalNo,mvId,hsvId, "+ getKeyColumn(transactionData) + ",externalNo from InventoryMgmt im inner join Subscriber s  on im.id=s.invMgtId where im.customerMSISDN=:msisdn and s.status='ACTIVE'";
		try																											
		{
			TypedQuery<Subscriber> query = entityManager.createNamedQuery("Subscriber.findByMobileAndInventory",Subscriber.class);
			
			query.setParameter("msisdn", transactionData.getMsisdn());
			
			Subscriber resultData = query.getSingleResult();
			
			if(resultData != null)
			{
				Integer hsvId = resultData.getHsvId().getId();
				
				InventoryMgmt inventoryData = resultData.getInvMgtId();
				
				Long externalNo = inventoryData.getExternalNo();
				BigDecimal internalNo = inventoryData.getInternalNo();
				Integer mvId = inventoryData.getMvId().getId();
				
				BigInteger bigIntVar = new BigInteger(externalNo.toString() );
				
				String decryptionKey = getKeyColumn(transactionData, inventoryData.getInventoryKeys());
				
				object[0] = internalNo;
				object[1] = mvId;
				object[2] = hsvId;
				object[3] = decryptionKey;
				object[4] = bigIntVar;
			}
			/*Query nativeQuery = entityManager.createNativeQuery(customerDetailsQuery).setParameter("msisdn", transactionData.getMsisdn());
			object=(Object[])nativeQuery.getSingleResult();*/
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return object;
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public List<Object[]> serviceInfoDataList(String code,TransactionData transactionData) 
	{		
		List<Object[]> list=new ArrayList<>();
		try
		{
			String query="select sc.id ,sc.service_defination,spm.object_mapping,spm.sequence,spm.isNumeric from serviceConfig sc inner join serviceParamMapping spm on sc.id=spm.service_id where stk_code= :code and mvId= :mvId";
			Query nativeQuery = entityManager.createNativeQuery(query).setParameter("code", code).setParameter("mvId",transactionData.getSubsAccountDetails().getMvId());
			list=nativeQuery.getResultList();			
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return list;
	}

	@Override
	public Partner getPartnerByNickName(String nickName){
		try {
			TypedQuery<Partner> query=entityManager.createNamedQuery("Partner.findByNickName",Partner.class);
			query.setParameter("nickName", nickName);
			return query.getSingleResult();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public CustomerAccountData getCustomerDetails(String customerMsisdn) 
	{
		CustomerAccountData customerData = new CustomerAccountData();
		try {
		
			//Fetch Account Data
			TypedQuery<CustomerDetails> query = entityManager.createNamedQuery("CustomerDetails.findByCustMsisdn",CustomerDetails.class);
			
			query.setParameter("msisdn", customerMsisdn);
			
			List<CustomerDetails> accountData = query.getResultList();
			
			//Fetch Wallet Data
			TypedQuery<CustomerWallets> walletQuery = entityManager.createNamedQuery("CustomerWallets.findByMsisdn",CustomerWallets.class);
			
			walletQuery.setParameter("customerMsisdn", customerMsisdn);
			
			List<CustomerWallets> walletData = walletQuery.getResultList();
			
			//Fetch Payee Data
			TypedQuery<PayeeDetails> payeeQuery = entityManager.createNamedQuery("PayeeDetails.findByMsisdn",PayeeDetails.class);
			
			payeeQuery.setParameter("customerMsisdn", Long.parseLong(customerMsisdn));
			
			List<PayeeDetails> payeeData = payeeQuery.getResultList();
			
			//Fetch Cards Data
			TypedQuery<CustomerCards> cardsQuery = entityManager.createNamedQuery("CustomerCards.findByMsisdn",CustomerCards.class);
			
			cardsQuery.setParameter("customerMsisdn", customerMsisdn);
			
			List<CustomerCards> cardsData = cardsQuery.getResultList();
			
			
			//Fetch Merchants Data
			TypedQuery<OverlayMerchants> merchantQuery = entityManager.createNamedQuery("OverlayMerchants.findByMsisdn",OverlayMerchants.class);
			
			merchantQuery.setParameter("customerMsisdn", Long.parseLong(customerMsisdn));
			
			List<OverlayMerchants> merchantData = merchantQuery.getResultList();
			
			
			
			//Fetch Payee Data
			TypedQuery<CustomerPreferredBiller> billerQuery = entityManager.createNamedQuery("CustomerPreferredBiller.findByMsisdn",CustomerPreferredBiller.class);
			
			billerQuery.setParameter("customerMsisdn", Long.parseLong(customerMsisdn));
			
			List<CustomerPreferredBiller> billerList = billerQuery.getResultList();
			
			customerData.setAccountData(accountData);
			customerData.setWalletData(walletData);
			customerData.setPayeeData(payeeData);
			customerData.setCardsData(cardsData);
			customerData.setMerchantData(merchantData);
			customerData.setBillerData(billerList);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return customerData;
	}

	@Override
	public List<PayeeDetails> getPayeeList(String customerMsisdn) {
		List<PayeeDetails> payeeData = null;
		try {
			
			//Fetch Payee Data
			TypedQuery<PayeeDetails> payeeQuery = entityManager.createNamedQuery("PayeeDetails.findByMsisdn",PayeeDetails.class);
			
			payeeQuery.setParameter("customerMsisdn", Long.parseLong(customerMsisdn));
			
			payeeData = payeeQuery.getResultList();
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return payeeData;
	}

	@Override
	public List<OverlayMerchants> getMerchantList(String customerMsisdn) 
	{
		List<OverlayMerchants> merchantData = null;
		try {
			
			//Fetch Payee Data
			TypedQuery<OverlayMerchants> merchantQuery = entityManager.createNamedQuery("OverlayMerchants.findByMsisdn",OverlayMerchants.class);
			
			merchantQuery.setParameter("customerMsisdn", Long.parseLong(customerMsisdn));
			
			merchantData = merchantQuery.getResultList();
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return merchantData;
	}
	
	@Override
	public List<CustomerPreferredBiller> getBillerList(String customerMsisdn) 
	{
		List<CustomerPreferredBiller> billerList = null;
		try {
			
			//Fetch Payee Data
			TypedQuery<CustomerPreferredBiller> billerQuery = entityManager.createNamedQuery("CustomerPreferredBiller.findByMsisdn",CustomerPreferredBiller.class);
			
			billerQuery.setParameter("customerMsisdn", Long.parseLong(customerMsisdn));
			
			billerList = billerQuery.getResultList();
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return billerList;
	}

	@Override
	public List<Partner> getPartners(String partnerType) {
		List<Partner> partnerData = null;
		try {
			
			//Fetch Partner Data
			TypedQuery<Partner> partnerQuery = entityManager.createNamedQuery("Partner.findByType",Partner.class);
			
			partnerQuery.setParameter("type", partnerType);
			
			partnerData = partnerQuery.getResultList();
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return partnerData;
	}

	@Override
	public List<CategoryProviderMapping> getCategoryProviders() 
	{
		List<CategoryProviderMapping> categoriesData = null;
		try {
			
			TypedQuery<CategoryProviderMapping> partnerQuery = entityManager.createNamedQuery("CategoryProviderMapping.findAll",CategoryProviderMapping.class);
			
			categoriesData = partnerQuery.getResultList();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return categoriesData;
	}

	@Override
	public CategoryProviderMapping getCategoryProviderInfo(Integer providerCode) {
		
		CategoryProviderMapping catgProviderMapping = null;
		
		try {
			
			TypedQuery<CategoryProviderMapping> partnerQuery = entityManager.createNamedQuery("CategoryProviderMapping.findByProviderCode",CategoryProviderMapping.class);
			
			partnerQuery.setParameter("providerCode", providerCode);
			
			catgProviderMapping = partnerQuery.getSingleResult();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return catgProviderMapping;
	}

	@Override
	public List<CustomerWallets> getMyWallets(String customerMsisdn) 
	{
		if(customerMsisdn == null)
			return null;
		
		List<CustomerWallets> walletData = null;
				
		try{
			//Fetch Wallet Data
			TypedQuery<CustomerWallets> walletQuery = entityManager.createNamedQuery("CustomerWallets.findByMsisdn",CustomerWallets.class);
			
			walletQuery.setParameter("customerMsisdn", customerMsisdn);
			
			walletData = walletQuery.getResultList();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return walletData;
	}
	
	@Override
	public Subscriber updateCustomer(String msisdn) throws Exception {
		try{
			TypedQuery<Subscriber> query= entityManager.createNamedQuery("Subscriber.findByMsisdn", Subscriber.class);
			
			query.setParameter("msisdn", msisdn);
			
			Subscriber subscriber = query.getSingleResult();
			subscriber.setRegisteredToBank(true);
			subscriber.setRegisteredToBankTime(new Date());
			return entityManager.merge(subscriber);
		}
		catch(Exception e) {
			e.printStackTrace();
			return null;
		}
	}

}
