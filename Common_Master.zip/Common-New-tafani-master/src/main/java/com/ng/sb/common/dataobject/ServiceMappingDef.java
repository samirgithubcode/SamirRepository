package com.ng.sb.common.dataobject;

import com.ng.sb.common.dataobject.HostSubVersionData.ProviderRelation;
import com.ng.sb.common.dataobject.InstrumentData.Sequence;
import com.ng.sb.common.dataobject.PartnerData.BankRelation;

public class ServiceMappingDef extends BaseObjectData {

	private static final long serialVersionUID = 1L;
	public enum BankSide{
		NO_BANK,
		BOTH,
		PAYER_ONLY,
		PAYEE_ONLY
	}
	
	public enum Type{
		FUND_TRANSFER,
		FUND_TRANSFER_TO_BILLER,
		OTHER_SERVICE
	}
	private String fspService;
	private String regInstFSPService;
	private String firstInstrument;
	private String secondInstrument;
	private ProviderRelation fspProvider;
	private ProviderRelation directProvider;
	private ProviderRelation regInstrFspProvider;
	private BankSide bankIncluded;
	private BankRelation bankRelation;
	private Type type;
	
	public ServiceMappingDef(String fspService,String regInstFSPService,String firstInstrument,String secondInstrument,BankSide bankIncluded){
		this.type=Type.FUND_TRANSFER;
		this.fspService=fspService;
		this.regInstFSPService=regInstFSPService;
		this.firstInstrument=firstInstrument;
		this.secondInstrument=secondInstrument;
		this.bankIncluded=bankIncluded;
	}
	
	public ServiceMappingDef(ProviderRelation fspProvider,ProviderRelation regInstrFspProvider,String firstInstrument,ProviderRelation directProvider,BankSide bankIncluded){
		this.type=Type.FUND_TRANSFER_TO_BILLER;
		this.fspProvider=fspProvider;
		this.regInstrFspProvider=regInstrFspProvider;
		this.firstInstrument=firstInstrument;
		this.directProvider=directProvider;
		this.bankIncluded=bankIncluded;
	}
	
	public ServiceMappingDef(String fspService,BankSide bankIncluded,BankRelation bankRelation){
		this.type=Type.OTHER_SERVICE;
		this.fspService=fspService;
		this.bankIncluded=bankIncluded;
		this.bankRelation=bankRelation;
	}

	public FSPServiceInstrumentData getFSPServiceAndInstrument(){
		FSPServiceInstrumentData data = new FSPServiceInstrumentData();
		data.setType(this.type);
		if(this.type==Type.FUND_TRANSFER){
			data.setFspServicesData(new FSPServicesData(this.fspService));
			data.getInstrumentMap().put(Sequence.FIRST, new InstrumentData(firstInstrument));
			data.getInstrumentMap().put(Sequence.SECOND, new InstrumentData(secondInstrument));
			data.setBankIncluded(this.bankIncluded);
			data.setRegInstrFspServicesData(new FSPServicesData(this.regInstFSPService));
		}else if(this.type==Type.OTHER_SERVICE){
			data.setFspServicesData(new FSPServicesData(this.fspService));
			data.setBankIncluded(this.bankIncluded);
			data.setBankRelation(this.bankRelation);
		}else if(this.type==Type.FUND_TRANSFER_TO_BILLER){
			data.setFspProvider(this.fspProvider);
			data.setRegInstrFspProvider(this.regInstrFspProvider);
			data.getInstrumentProviderMap().put(Sequence.FIRST, new InstrumentProviderData(new InstrumentData(this.firstInstrument)));
			data.getInstrumentProviderMap().put(Sequence.SECOND, new InstrumentProviderData(this.directProvider));
			data.setBankIncluded(this.bankIncluded);
		}
		
		return data;
	}
	
}
