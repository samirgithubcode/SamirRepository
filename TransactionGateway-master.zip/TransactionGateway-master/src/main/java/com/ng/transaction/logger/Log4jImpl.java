/**
 * 
 */
package com.ng.transaction.logger;

import java.util.ResourceBundle;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.ng.transaction.util.TransactionConstants;

/**
 * @author gopal
 *
 */
public class Log4jImpl {

	ResourceBundle rb = ResourceBundle.getBundle("application");
			
	public static final int DEBUG=0;
    public static final int INFO=1;
    public static final int WARNING=2;
    public static final int ERROR=3;
    public static final int FATEL=4;
    public static final int CANVASM_TRACE_IN=5;
	
    protected static final Level[] debugLevels=new Level[]{Level.DEBUG, Level.INFO, Level.WARN, Level.ERROR, Level.FATAL};
    
	private org.apache.log4j.Logger logger = null;
	
	public Log4jImpl(Class arg0) {
		PropertyConfigurator.configure( rb.getString(TransactionConstants.LOG4J_FILE_PATH_KEY) +"/log4j.properties");
		logger = org.apache.log4j.Logger.getLogger(arg0);
	}
	
	public Logger getLogger() {
		return logger;
	}
	
	
}
