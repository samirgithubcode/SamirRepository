/**
 * 
 */
package com.ng.bridge.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ng.bridge.service.IAgentService;
import com.ng.bridge.service.IPartnerManagementService;
import com.ng.sb.common.dataobject.BridgeDataObject;
import com.ng.sb.common.exception.BridgeObjectDataException;
import com.ng.sb.common.util.SystemConstant;

/**
 * @author gaurav
 *
 */
@Service(value=SystemConstant.BRIDGE_AGENT_SERVICE)
public class AgentService extends WalletService implements IAgentService {

	private static final Logger LOGGER = LoggerFactory.getLogger(BankingService.class);
	@Autowired
	IPartnerManagementService ipartnerManagementService;
	
	/* (non-Javadoc)
	 * @see com.ng.transaction.service.IAgentWalletService#checkBalance(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject checkBalance(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge AgentWalletService -  checkBalance method. ");
		try {
			return ipartnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in checkBalance:"+ e);
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ng.transaction.service.IAgentWalletService#topOnline(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject topOnline(BridgeDataObject bridgeDataObject) {
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ng.transaction.service.IAgentWalletService#topUpAccount(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject topUpAccount(BridgeDataObject bridgeDataObject) {
		return null;
	}

}
