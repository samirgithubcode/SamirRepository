/**
 * 
 */
package com.ng.transaction.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import com.ng.sb.common.dataobject.AccountInfoData;
import com.ng.sb.common.dataobject.CategoryData;
import com.ng.sb.common.dataobject.FSPServicesData;
import com.ng.sb.common.dataobject.HostSVServiceConfigMapping;
import com.ng.sb.common.dataobject.HostSubVersionData;
import com.ng.sb.common.dataobject.HostSubVersionData.ProviderRelation;
import com.ng.sb.common.dataobject.InstrumentData;
import com.ng.sb.common.dataobject.MasterVersionData;
import com.ng.sb.common.dataobject.PartnerData;
import com.ng.sb.common.dataobject.PartnerData.BankRelation;
import com.ng.sb.common.dataobject.ProvidersData;
import com.ng.sb.common.dataobject.ServiceConfigData;
import com.ng.sb.common.dataobject.ServiceParamsMappingData;


/**
 * @author gaurav
 *
 */
public class FillDummyData {

	public Map<HostSubVersionData,HostSubVersionData> fillData(){
		
		Map<HostSubVersionData,HostSubVersionData> map=new HashMap<>();
		
		HostSubVersionData keyData=new HostSubVersionData();
		keyData.setCode(101);
		keyData.setFspServiceMap(getFspServiceMap());
		keyData.setHost(getHost().get(0));
		keyData.setId(1);
		keyData.setInstrumentMap(getInstrumentMap());
		keyData.setMasterVersionData(getMasterVersionData().get(0));
		keyData.setName("HostSubVersion101");
		keyData.setProviderMap(getProviderMap().get(0));
		//keyData.setServiceConfigMappings(getServiceMapping());
		map.put(keyData, keyData);
		//============second host sub version ===============
		keyData=new HostSubVersionData();
		keyData.setCode(102);
		keyData.setFspServiceMap(getFspServiceMap());
		keyData.setHost(getHost().get(0));
		keyData.setId(2);
		keyData.setInstrumentMap(getInstrumentMap());
		keyData.setMasterVersionData(getMasterVersionData().get(1));
		keyData.setName("HostSubVersion102");
		keyData.setProviderMap(getProviderMap().get(1));
		//keyData.setServiceConfigMappings(getServiceMapping());
		map.put(keyData, keyData);
		
		//============ third host sub version ===================
		keyData=new HostSubVersionData();
		keyData.setCode(103);
		keyData.setFspServiceMap(getFspServiceMap());
		keyData.setHost(getHost().get(1));
		keyData.setId(3);
		keyData.setInstrumentMap(getInstrumentMap());
		keyData.setMasterVersionData(getMasterVersionData().get(2));
		keyData.setName("HostSubVersion103");
		keyData.setProviderMap(getProviderMap().get(2));
		//keyData.setServiceConfigMappings(getServiceMapping());
		map.put(keyData, keyData);
		//=============== fourth host sub version ===============
		keyData=new HostSubVersionData();
		keyData.setCode(104);
		keyData.setFspServiceMap(getFspServiceMap());
		keyData.setHost(getHost().get(1));
		keyData.setId(4);
		keyData.setInstrumentMap(getInstrumentMap());
		keyData.setMasterVersionData(getMasterVersionData().get(3));
		keyData.setName("HostSubVersion104");
		keyData.setProviderMap(getProviderMap().get(3));
		//keyData.setServiceConfigMappings(getServiceMapping());
		map.put(keyData, keyData);
		
	
		return map;
	}
	public Map<FSPServicesData,FSPServicesData> getFspServiceMap(){
		Map<FSPServicesData,FSPServicesData> fspServiceMap=new HashMap<>();
		FSPServicesData keyData=new FSPServicesData();
		keyData.setName("B_T_B");
		keyData.setType("BANKING");
		keyData.setPartners(getPartner());
		fspServiceMap.put(keyData, keyData);
		
		keyData=new FSPServicesData();
		keyData.setName("B_T_CC");
		keyData.setType("BANKING");
		keyData.setPartners(getPartner());
		fspServiceMap.put(keyData, keyData);
		
		
		keyData=new FSPServicesData();
		keyData.setName("B_T_IMPS");
		keyData.setType("BANKING");
		keyData.setPartners(getPartner());
		fspServiceMap.put(keyData, keyData);
		
		keyData=new FSPServicesData();
		keyData.setName("B_T_W");
		keyData.setType("BANKING");
		keyData.setPartners(getPartner());
		fspServiceMap.put(keyData, keyData);
		
		keyData=new FSPServicesData();
		keyData.setName("IMPS_T_B");
		keyData.setType("BANKING");
		keyData.setPartners(getPartner());
		fspServiceMap.put(keyData, keyData);
		
		keyData=new FSPServicesData();
		keyData.setName("IMPS_T_CC");
		keyData.setType("BANKING");
		keyData.setPartners(getPartner());
		fspServiceMap.put(keyData, keyData);
		
		keyData=new FSPServicesData();
		keyData.setName("IMPS_T_IMPS");
		keyData.setType("BANKING");
		keyData.setPartners(getPartner());
		fspServiceMap.put(keyData, keyData);
		
		keyData=new FSPServicesData();
		keyData.setName("IMPS_T_W");
		keyData.setType("BANKING");
		keyData.setPartners(getPartner());
		fspServiceMap.put(keyData, keyData);
		
		
		keyData=new FSPServicesData();
		keyData.setName("CC_T_B");
		keyData.setType("BANKING");
		keyData.setPartners(getPartner());
		fspServiceMap.put(keyData, keyData);
		
		keyData=new FSPServicesData();
		keyData.setName("CC_T_CC");
		keyData.setType("BANKING");
		keyData.setPartners(getPartner());
		fspServiceMap.put(keyData, keyData);
		
		keyData=new FSPServicesData();
		keyData.setName("CC_T_IMPS");
		keyData.setType("BANKING");
		keyData.setPartners(getPartner());
		fspServiceMap.put(keyData, keyData);
		
		keyData=new FSPServicesData();
		keyData.setName("CC_T_W");
		keyData.setType("BANKING");
		keyData.setPartners(getPartner());
		fspServiceMap.put(keyData, keyData);
		
		keyData=new FSPServicesData();
		keyData.setName("W_T_B");
		keyData.setType("BANKING");
		keyData.setPartners(getPartner());
		fspServiceMap.put(keyData, keyData);
		
		keyData=new FSPServicesData();
		keyData.setName("W_T_CC");
		keyData.setType("BANKING");
		keyData.setPartners(getPartner());
		fspServiceMap.put(keyData, keyData);
		
		keyData=new FSPServicesData();
		keyData.setName("W_T_IMPS");
		keyData.setType("BANKING");
		keyData.setPartners(getPartner());
		fspServiceMap.put(keyData, keyData);
		
		keyData=new FSPServicesData();
		keyData.setName("W_T_W");
		keyData.setType("BANKING");
		keyData.setPartners(getPartner());
		fspServiceMap.put(keyData, keyData);
		
		keyData=new FSPServicesData();
		keyData.setName("CHANGE_PIN");
		keyData.setType("OTHER");
		keyData.setPartners(getPartner());
		fspServiceMap.put(keyData, keyData);
		
		keyData=new FSPServicesData();
		keyData.setName("CHEQUE_BOOK_REQUEST");
		keyData.setType("OTHER");
		keyData.setPartners(getPartner());
		fspServiceMap.put(keyData, keyData);
		
		keyData=new FSPServicesData();
		keyData.setName("RETRIEVE_MPIN");
		keyData.setType("OTHER");
		keyData.setPartners(getPartner());
		fspServiceMap.put(keyData, keyData);
		
		keyData=new FSPServicesData();
		keyData.setName("RETRIEVE_MMID");
		keyData.setType("OTHER");
		keyData.setPartners(getPartner());
		fspServiceMap.put(keyData, keyData);
		
		keyData=new FSPServicesData();
		keyData.setName("GENERATE_MPIN");
		keyData.setType("OTHER");
		keyData.setPartners(getPartner());
		fspServiceMap.put(keyData, keyData);
		
		keyData=new FSPServicesData();
		keyData.setName("CANCEL_CHEQUE");
		keyData.setType("OTHER");
		keyData.setPartners(getPartner());
		fspServiceMap.put(keyData, keyData);
		
		keyData=new FSPServicesData();
		keyData.setName("ADD_BANK_ACCOUNT");
		keyData.setType("OTHER");
		keyData.setPartners(getPartner());
		fspServiceMap.put(keyData, keyData);
		
		keyData=new FSPServicesData();
		keyData.setName("ADD_IMPS");
		keyData.setType("OTHER");
		keyData.setPartners(getPartner());
		fspServiceMap.put(keyData, keyData);
		
		keyData=new FSPServicesData();
		keyData.setName("MONEY_TRANSFER");
		keyData.setType("OTHER");
		keyData.setPartners(getPartner());
		fspServiceMap.put(keyData, keyData);
		
		
		return fspServiceMap;
	}
	public AccountInfoData getAccountInfoData(){
		AccountInfoData data=new AccountInfoData();
		data.setCompanyName("NextGen");
		data.setId(1);
		data.setName("Ram");
	
		return data;
	}
	public Map<InstrumentData,InstrumentData> getInstrumentMap(){
		Map<InstrumentData,InstrumentData> instrumentMap=new HashMap<>();
		InstrumentData data=new InstrumentData();
		data.setId(1);
		data.setName("BANK");
		data.setPartners(getPartner());
		instrumentMap.put(data, data);
		
		data=new InstrumentData();
		data.setId(2);
		data.setName("WALLET");
		data.setPartners(getPartner());
		instrumentMap.put(data, data);
		
		data=new InstrumentData();
		data.setId(3);
		data.setName("CREDITCARD");
		data.setPartners(getPartner());
		instrumentMap.put(data, data);
		
		data=new InstrumentData();
		data.setId(4);
		data.setName("IMPS");
		data.setPartners(getPartner());
		instrumentMap.put(data, data);
		
		return instrumentMap;
	}
	public List<MasterVersionData> getMasterVersionData(){
		List<MasterVersionData> list=new ArrayList<>();
		MasterVersionData data1=new MasterVersionData();
		data1.setCode(101);
		data1.setId(1);
		data1.setName("Version101");
		
		MasterVersionData data2=new MasterVersionData();
		data2.setCode(102);
		data2.setId(2);
		data2.setName("Version102");
		
		MasterVersionData data3=new MasterVersionData();
		data3.setCode(103);
		data3.setId(3);
		data3.setName("Version103");

		MasterVersionData data4=new MasterVersionData();
		data4.setCode(104);
		data4.setId(4);
		data4.setName("Version104");
		
		list.add(data1);
		list.add(data2);
		list.add(data3);
		list.add(data4);
		
		
		return list;
	}
	public List<Map<ProviderRelation,Map<ProvidersData,ProvidersData>>> getProviderMap(){
		List<Map<ProviderRelation,Map<ProvidersData,ProvidersData>>> list=new ArrayList<>();
		
		Map<ProviderRelation,Map<ProvidersData,ProvidersData>> providerMap1=new  HashMap<>();
		Map<ProvidersData,ProvidersData> value1=new HashMap<>();
		
		ProvidersData data1=new ProvidersData();
		data1.setCategory(getCategory().get(0));
		data1.setCode(101);
		data1.setId(101);
		data1.setName("AIRTEL");
		data1.setPartners(getPartner());
		
		ProvidersData data2=new ProvidersData();
		data2.setCategory(getCategory().get(2));
		data2.setCode(102);
		data2.setId(102);
		data2.setName("AIRCEL");
		data2.setPartners(getPartner());
		
		ProvidersData data3=new ProvidersData();
		data3.setCategory(getCategory().get(1));
		data3.setCode(103);
		data3.setId(103);
		data3.setName("TATAPOWER");
		data3.setPartners(getPartner());

		ProvidersData data4=new ProvidersData();
		data4.setCategory(getCategory().get(2));
		data4.setCode(104);
		data4.setId(105);
		data4.setName("BSNL");
		data4.setPartners(getPartner());
		
		value1.put(data1, data1);
		value1.put(data2, data2);
		value1.put(data3, data3);
		value1.put(data4, data4);
		
		Map<ProvidersData,ProvidersData> value2=new HashMap<>();
		
		ProvidersData data5=new ProvidersData();
		data5.setCategory(getCategory().get(2));
		data5.setCode(103);
		data5.setId(103);
		data5.setName("RELIANCE");
		data5.setPartners(getPartner());
		
		ProvidersData data6=new ProvidersData();
		data6.setCategory(getCategory().get(2));
		data6.setCode(104);
		data6.setId(104);
		data6.setName("AIRCEL");
		data6.setPartners(getPartner());
		
		ProvidersData data7=new ProvidersData();
		data7.setCategory(getCategory().get(2));
		data7.setCode(105);
		data7.setId(105);
		data7.setName("VODA");
		data7.setPartners(getPartner());

		ProvidersData data8=new ProvidersData();
		data8.setCategory(getCategory().get(2));
		data8.setCode(106);
		data8.setId(106);
		data8.setName("BSNL");
		data8.setPartners(getPartner());
		
		value2.put(data5, data5);
		value2.put(data6, data6);
		value2.put(data7, data7);
		value2.put(data8, data8);
		
		providerMap1.put(ProviderRelation.FSP_PROVIDER,value1);
		providerMap1.put(ProviderRelation.DIRECT_PROVIDER,value2);
		
		list.add(providerMap1);
		//============ FIRST HOST VERSION END==============================
		
		//=========== SEECOND HOST VERION =====================
		providerMap1=new  HashMap<>();
		value1=new HashMap<>();
		
		data1=new ProvidersData();
		data1.setCategory(getCategory().get(0));
		data1.setCode(101);
		data1.setId(101);
		data1.setName("AIRTEL");
		data1.setPartners(getPartner());
		
		data2=new ProvidersData();
		data2.setCategory(getCategory().get(2));
		data2.setCode(102);
		data2.setId(102);
		data2.setName("AIRCEL");
		data2.setPartners(getPartner());
		
		data3=new ProvidersData();
		data3.setCategory(getCategory().get(1));
		data3.setCode(103);
		data3.setId(103);
		data3.setName("TATAPOWER");
		data3.setPartners(getPartner());

		data4=new ProvidersData();
		data4.setCategory(getCategory().get(2));
		data4.setCode(104);
		data4.setId(105);
		data4.setName("BSNL");
		data4.setPartners(getPartner());
		
		value1.put(data1, data1);
		value1.put(data2, data2);
		value1.put(data3, data3);
		value1.put(data4, data4);
		
		value2=new HashMap<>();
		
		data5=new ProvidersData();
		data5.setCategory(getCategory().get(3));
		data5.setCode(103);
		data5.setId(103);
		data5.setName("IGPL");
		data5.setPartners(getPartner());
		
		data6=new ProvidersData();
		data6.setCategory(getCategory().get(1));
		data6.setCode(104);
		data6.setId(104);
		data6.setName("BSES");
		data6.setPartners(getPartner());
		
		data7=new ProvidersData();
		data7.setCategory(getCategory().get(2));
		data7.setCode(105);
		data7.setId(105);
		data7.setName("VODA");
		data7.setPartners(getPartner());

		data8=new ProvidersData();
		data8.setCategory(getCategory().get(2));
		data8.setCode(106);
		data8.setId(106);
		data8.setName("BSNL");
		data8.setPartners(getPartner());
		
		value2.put(data5, data5);
		value2.put(data6, data6);
		value2.put(data7, data7);
		value2.put(data8, data8);
		
		providerMap1.put(ProviderRelation.FSP_PROVIDER,value1);
		providerMap1.put(ProviderRelation.DIRECT_PROVIDER,value2);
		
		list.add(providerMap1);
		
		//===============SECOND VERSION ENDS =================
		//========== START THIRD VERSION =================
		providerMap1=new  HashMap<>();
		value1=new HashMap<>();
		
		data1=new ProvidersData();
		data1.setCategory(getCategory().get(0));
		data1.setCode(103);
		data1.setId(104);
		data1.setName("AIRTEL");
		data1.setPartners(getPartner());
		
		data2=new ProvidersData();
		data2.setCategory(getCategory().get(2));
		data2.setCode(104);
		data2.setId(104);
		data2.setName("AIRCEL");
		data2.setPartners(getPartner());
		
		data3=new ProvidersData();
		data3.setCategory(getCategory().get(2));
		data3.setCode(105);
		data3.setId(105);
		data3.setName("VODA");
		data3.setPartners(getPartner());

		data4=new ProvidersData();
		data4.setCategory(getCategory().get(2));
		data4.setCode(106);
		data4.setId(106);
		data4.setName("BSNL");
		data4.setPartners(getPartner());
		
		value1.put(data1, data1);
		value1.put(data2, data2);
		value1.put(data3, data3);
		value1.put(data4, data4);
		
		value2=new HashMap<>();
		
		data5=new ProvidersData();
		data5.setCategory(getCategory().get(2));
		data5.setCode(103);
		data5.setId(103);
		data5.setName("RELIANCE");
		data5.setPartners(getPartner());
		
		data6=new ProvidersData();
		data6.setCategory(getCategory().get(2));
		data6.setCode(104);
		data6.setId(104);
		data6.setName("AIRCEL");
		data6.setPartners(getPartner());
		
		data7=new ProvidersData();
		data7.setCategory(getCategory().get(2));
		data7.setCode(105);
		data7.setId(105);
		data7.setName("VODA");
		data7.setPartners(getPartner());

		data8=new ProvidersData();
		data8.setCategory(getCategory().get(2));
		data8.setCode(106);
		data8.setId(106);
		data8.setName("BSNL");
		data8.setPartners(getPartner());
		
		value2.put(data5, data5);
		value2.put(data6, data6);
		value2.put(data7, data7);
		value2.put(data8, data8);
		
		providerMap1.put(ProviderRelation.FSP_PROVIDER,value1);
		providerMap1.put(ProviderRelation.DIRECT_PROVIDER,value2);
		
		list.add(providerMap1);
		//=============== THIRD VERISON ENDS ============
		//========= FORTH VERSION STARTS ================
		
		providerMap1=new  HashMap<>();
		value1=new HashMap<>();
		
		data1=new ProvidersData();
		data1.setCategory(getCategory().get(0));
		data1.setCode(101);
		data1.setId(101);
		data1.setName("AIRTEL");
		data1.setPartners(getPartner());
		
		data2=new ProvidersData();
		data2.setCategory(getCategory().get(2));
		data2.setCode(102);
		data2.setId(102);
		data2.setName("AIRCEL");
		data2.setPartners(getPartner());
		
		data3=new ProvidersData();
		data3.setCategory(getCategory().get(1));
		data3.setCode(103);
		data3.setId(103);
		data3.setName("TATA");
		data3.setPartners(getPartner());

		data4=new ProvidersData();
		data4.setCategory(getCategory().get(2));
		data4.setCode(104);
		data4.setId(105);
		data4.setName("BSNL");
		data4.setPartners(getPartner());
		
		value1.put(data1, data1);
		value1.put(data2, data2);
		value1.put(data3, data3);
		value1.put(data4, data4);
		
		value2=new HashMap<>();
		
		data5=new ProvidersData();
		data5.setCategory(getCategory().get(2));
		data5.setCode(103);
		data5.setId(103);
		data5.setName("RELIANCE");
		data5.setPartners(getPartner());
		
		data6=new ProvidersData();
		data6.setCategory(getCategory().get(2));
		data6.setCode(104);
		data6.setId(104);
		data6.setName("AIRCEL");
		data6.setPartners(getPartner());
		
		data7=new ProvidersData();
		data7.setCategory(getCategory().get(2));
		data7.setCode(105);
		data7.setId(105);
		data7.setName("VODA");
		data7.setPartners(getPartner());

		data8=new ProvidersData();
		data8.setCategory(getCategory().get(2));
		data8.setCode(106);
		data8.setId(106);
		data8.setName("BSNL");
		data8.setPartners(getPartner());
		
		value2.put(data5, data5);
		value2.put(data6, data6);
		value2.put(data7, data7);
		value2.put(data8, data8);
		
		providerMap1.put(ProviderRelation.FSP_PROVIDER,value1);
		providerMap1.put(ProviderRelation.DIRECT_PROVIDER,value2);
		
		list.add(providerMap1);
		
		
		
		return list;
	}
	public List<HostSVServiceConfigMapping> getServiceMapping(){
		List<HostSVServiceConfigMapping> list=new ArrayList<>();
		HostSVServiceConfigMapping mapping1=new HostSVServiceConfigMapping();
		mapping1.setId(1);
		mapping1.setCode(1120);
		mapping1.setName("configMapping");
		list.add(mapping1);
		
		return list;
	}

	/*public HostSubVersionData getHostSubVersion(){
		HostSubVersionData version=new HostSubVersionData();
		version.setCode(101);
		version.setFspServiceMap(getFspServiceMap());
		version.setHost(getAccountInfoData());
		version.setId(10);
		version.setInstrumentMap(getInstrumentMap());
		version.setMasterVersionData(getMasterVersionData());
		version.setName("HostSubVersion10.01");
		version.setProviderMap(getProviderMap());
		version.setServiceConfigMappings(getServiceMapping());
		
		return version;
	}*/
	public ServiceConfigData getServiceConfig(){
		ServiceConfigData config=new ServiceConfigData();
		config.setCode(101);
		config.setId(1);
		config.setMvCode(101);
		config.setName("DTH");
		config.setParamMappings(getSerciceParamMappingList());
		config.setParentId(1);
		config.setRequiredInputParam(1);
		config.setServiceCode("12123");
		config.setServiceDefinition("service definition");
		config.setServiceDesc("service dessc");
		config.setServiceName("service name");
		config.setStatus(1);
		config.setValidationReq(1);
		return config;
	}
	public Set<PartnerData> getPartner(){
		Set<PartnerData> set=new TreeSet<>();
		PartnerData data=new PartnerData();
		data.setCode(101);
		data.setMode("Online");
		data.setName("BillDesk");
		data.setSequence(3);
		set.add(data);
		addBanks(data);
		
		data=new PartnerData();
		data.setCode(102);
		data.setMode("Online");
		data.setName("Citrus");
		data.setSequence(2);
		set.add(data);
		addBanks(data);
		
		data=new PartnerData();
		data.setCode(103);
		data.setMode("Online");
		data.setName("CCAvenue");
		data.setSequence(4);
		set.add(data);
		addBanks(data);
		
		data=new PartnerData();
		data.setCode(104);
		data.setMode("Online");
		data.setName("PayPal");
		data.setSequence(1);
		set.add(data);
		addBanks(data);
		
		return set;
	}
	
	private void addBanks(PartnerData data){
		Map<BankRelation,Map<String,String>> bankBranchesMap = new HashMap<>();
		Map<String,String> branchMap = new HashMap<>();
		branchMap.put("CITI", "CITI");
		branchMap.put("SBI1", "SBI1");
		branchMap.put("ICIC", "ICIC");
		branchMap.put("HDFC", "HDFC");
		bankBranchesMap.put(BankRelation.DIRECT_INSTRUMENT, branchMap);
		bankBranchesMap.put(BankRelation.FSP_PROVIDER, branchMap);
		bankBranchesMap.put(BankRelation.FSP_SERVICE, branchMap);
		data.setBankBranchesMap(bankBranchesMap);
	}
	
	public List<ProvidersData> getProviderData(){
		List<ProvidersData> list=new ArrayList<>();
		ProvidersData data1=new ProvidersData();
		data1.setCategory(getCategory().get(0));
		data1.setCode(120);
		data1.setId(123);
		data1.setName("Airtel");
		data1.setPartners(getPartner());
		return list;
	}
	
	public List<CategoryData> getCategory(){
		List<CategoryData> list=new ArrayList<>();
		CategoryData cat1=new CategoryData();
		cat1.setCode(101);
		cat1.setId(1);
		cat1.setName("DTH");
		
		CategoryData cat2=new CategoryData();
		cat2.setCode(102);
		cat2.setId(2);
		cat2.setName("ELECTRICITY");

		CategoryData cat3=new CategoryData();
		cat3.setCode(103);
		cat3.setId(3);
		cat3.setName("CELLULARPHONE");

		CategoryData cat4=new CategoryData();
		cat4.setCode(104);
		cat4.setId(4);
		cat4.setName("GAS");
		
		list.add(cat1);
		list.add(cat2);
		list.add(cat3);
		list.add(cat4);
		
		return list;
	}
	
	public List<ServiceParamsMappingData> getSerciceParamMappingList(){
		List<ServiceParamsMappingData> list=new ArrayList<>();
		ServiceParamsMappingData data= new ServiceParamsMappingData();
		data.setDesc("host service param mapping");
		data.setId(1);
		data.setIsnumericField(true);
		data.setName("host service mapping");
		data.setObjectMapping("mapping");
		data.setSequence(1);
		data.setServiceId(11);
		return list;
	}
	
		
	//============== fill service config map data ====================
	public  Map<ServiceConfigData,ServiceConfigData> fillServiceConfigMapData(){
		Map<ServiceConfigData,ServiceConfigData> map=new HashMap<>();
		ServiceConfigData key=getServiceConfig();
		ServiceConfigData value=getServiceConfig();
		map.put(key,value);
		return map;
	}
	
	public List<AccountInfoData> getHost(){
		List<AccountInfoData> list=new ArrayList<>();
		AccountInfoData data1=new AccountInfoData();
		data1.setCompanyName("ICICI");
		data1.setId(1);
		data1.setName("ICICI Admin");
		
		AccountInfoData data2=new AccountInfoData();
		data2.setCompanyName("Axis");
		data2.setId(1);
		data2.setName("ICICI Admin");
		
		list.add(data1);
		list.add(data2);
		return list;
	}
	
}
