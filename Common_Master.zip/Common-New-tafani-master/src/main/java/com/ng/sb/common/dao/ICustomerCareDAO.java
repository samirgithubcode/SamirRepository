package com.ng.sb.common.dao;

public interface ICustomerCareDAO extends IDAO{

}
