package com.ng.pnb.bridge.iso.impl;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.apache.commons.lang.StringUtils;
import org.jpos.iso.ISOException;
import org.jpos.iso.ISOMsg;
import org.jpos.iso.ISOUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.ng.pnb.bridge.iso.IISOMessageCreator;
import com.ng.pnb.invoker.util.ISOConstant;
import com.ng.pnb.invoker.util.ISOUtils;
import com.ng.pnb.invoker.util.PnbConstants;
import com.ng.sb.common.dataobject.BridgeDataObject;
import com.ng.sb.common.dataobject.ProvidersData;
import com.ng.sb.common.dataobject.BridgeDataObject.ServiceType;
import com.ng.sb.common.dataobject.HostSubVersionData.ProviderRelation;
import com.ng.sb.common.util.CommonUtils;
import com.ng.sb.common.util.KeyEncryptionUtils;
/**
 * @author gaurav
 *
 */
@Service(value="isoMessageCreator")
public class ISOMessageCreator extends ISODefiner implements IISOMessageCreator 
{
	private static final Logger LOGGER = LoggerFactory.getLogger(ISOMessageCreator.class);
	@Override
	public ISOMsg createBalEnquiryMessage(BridgeDataObject bridgeDataObject) throws ISOException 
	{
		ISOMsg isoMsg = null;
		
		boolean condition1=false;
		boolean condition2=false;
		LOGGER.info(PnbConstants.TRANSACTIONID +" : "+bridgeDataObject.getTransactionData().getTransactionId() + " In ISOMessageCreator -  createBalEnquiryMessage method. ");
		byte[] data = null;
		
		Calendar cd = new GregorianCalendar();
		String fyear =Integer.toString(cd.get(Calendar.YEAR));
		//String yr = fyear.substring(2, 4);
		String monthDate=Integer.toString(cd.get(Calendar.MONTH)+1)+""+cd.get(Calendar.DAY_OF_MONTH);
		String dateWoY=Integer.toString(cd.get(Calendar.MONTH)+1)+""+cd.get(Calendar.DAY_OF_MONTH)+""+cd.get(Calendar.HOUR)+""+cd.get(Calendar.MINUTE)+""+Calendar.SECOND;
		String dateWY=fyear+""+dateWoY;
		
		if(bridgeDataObject.getPayerBankAccount()!=null && bridgeDataObject.getPayerBankAccount().getAccountNumber()!=null){
			condition1=true;
		}
		if( !bridgeDataObject.getPayerBankAccount().getAccountNumber().isEmpty()
				&& bridgeDataObject.getPayerBankAccount().getbPin()!=null
				&& !bridgeDataObject.getPayerBankAccount().getbPin().isEmpty()){
			condition2=true;
		}
		if(condition1 && condition2){
			isoMsg = getISOMsg(bridgeDataObject.getTransactionData().getTransactionId(),true);
			isoMsg.set(2,"BNK0072520"); //ICCD#
			isoMsg.set(3, "310000"); //Processing Code
			isoMsg.set(4, "0000000000000000");
			//isoMsg.set(7, "0111155841");
			isoMsg.set(11, "000000000000"); // 12 Length Unique Number
			isoMsg.set(12, dateWY);
			isoMsg.set(17, "0111");
			isoMsg.set(24, "200");
			isoMsg.set(32, "9024");
			isoMsg.set(37, "701115061276"); // 8 Length Unique Number
			isoMsg.set(41, PnbConstants.ACN); // 8 Length Unique Number
			isoMsg.set(42, "000000000000000"); // External Number
			isoMsg.set(49, "356");
			
			
			isoMsg.set(102, bridgeDataObject.getPayerBankAccount().getIfscCode()+"00000000"+ISOUtils.getFinalPaddedData(bridgeDataObject.getPayerBankAccount().getAccountNumber(), true, 19, "0"));
			
			isoMsg.set(125, "K1405805~KO~~BALENQ"); // Mob#=ICCD#
			isoMsg.set(127, "FIGWAY:"); // Mob#=ICCD#

			
			//Mof Fin
			/*isoMsg.set(2, "888417677");
			isoMsg.set(3, "310000");
			isoMsg.set(4, "000000000000");
			isoMsg.set(7, "0402142528");
			isoMsg.set(8, "00000000");
			isoMsg.set(11, "123458");
			isoMsg.set(12, "000402");
			isoMsg.set(13, "0402");
			isoMsg.set(22, "810");
			isoMsg.set(25, "00");
			isoMsg.set(41, "TMODEFIN");
			isoMsg.set(42, "MODEFIN");
			isoMsg.set(49, "800");
			isoMsg.set(102, "0100101187450004");*/
		
			// print the DE list
			logISOMsg(isoMsg);
			// Get and print the output result
			//data = isoMsg.pack();
			//LOGGER.info(PnbConstants.TRANSACTIONID +" : "+bridgeDataObject.getTransactionData().getTransactionId() + PnbConstants.RESULTMSG + new String(data));
		}
		return isoMsg;
	}
	private  void logISOMsg(ISOMsg msg) {
		try {
			LOGGER.info(" In logISOMsg -   MTI : " + msg.getMTI());
			for (int i=1;i<=msg.getMaxField();i++) {
				if (msg.hasField(i)) {
					LOGGER.info("    Field-"+i+" : "+msg.getString(i));
				}
			}
		} catch (ISOException e) {
			LOGGER.info(""+e);
		} 
	}
	@Override
	public ISOMsg createMiniStatementMessage(BridgeDataObject bridgeDataObject)  throws ISOException 
	{
		ISOMsg isoMsg = null;
		
		boolean condition1=false;
		boolean condition2=false;
		
		LOGGER.info(PnbConstants.TRANSACTIONID +" : "+bridgeDataObject.getTransactionData().getTransactionId() + " In ISOMessageCreator -  createMiniStatementMessage method. ");
		byte[] data = null;
		if(bridgeDataObject.getPayerBankAccount()!=null && bridgeDataObject.getPayerBankAccount().getAccountNumber()!=null)
		{
			condition1=true;
		}
		
		if( !bridgeDataObject.getPayerBankAccount().getAccountNumber().isEmpty() && !StringUtils.isBlank(bridgeDataObject.getPayerBankAccount().getbPin()))
		{
			condition2=true;
		}
		
		if(condition1 && condition2)
		{
			isoMsg = getISOMsg(bridgeDataObject.getTransactionData().getTransactionId(),true);
			
			Calendar cd = new GregorianCalendar();
			String fyear =Integer.toString(cd.get(Calendar.YEAR));
			//String yr = fyear.substring(2, 4);
			String monthDate=Integer.toString(cd.get(Calendar.MONTH)+1)+""+cd.get(Calendar.DAY_OF_MONTH);
			String dateWoY=Integer.toString(cd.get(Calendar.MONTH)+1)+""+cd.get(Calendar.DAY_OF_MONTH)+""+cd.get(Calendar.HOUR)+""+cd.get(Calendar.MINUTE)+""+Calendar.SECOND;
			String dateWY=fyear+""+dateWoY;
			
			isoMsg.set(3, "380000"); //Processing Code
			isoMsg.set(4, "0000000000000000");
			isoMsg.set(11, "000000000000"); // 12 Length Unique Number
			isoMsg.set(12, dateWY);
			isoMsg.set(17, fyear+""+monthDate);
			isoMsg.set(24, "200");
			isoMsg.set(32, "504511");
			isoMsg.set(34, bridgeDataObject.getPayerBankAccount().getAccountNumber());  // 8 Length Unique Number
			
			isoMsg.set(41, "BANKAWAY"); // 8 Length Unique Number
			isoMsg.set(42, "BANKAWAY"); // External No
			isoMsg.set(43, "NG / sansad marg"); // Location
			
			isoMsg.set(49, "INR");
			isoMsg.set(102, bridgeDataObject.getPayerBankAccount().getIfscCode()+"00000000"+ISOUtils.getFinalPaddedData(bridgeDataObject.getPayerBankAccount().getAccountNumber(), true, 19, "0"));
			isoMsg.set(123, "BWY");
			// print the DE list
			logISOMsg(isoMsg);
			// Get and print the output result
			data = isoMsg.pack();
			LOGGER.info(PnbConstants.TRANSACTIONID +" : "+bridgeDataObject.getTransactionData().getTransactionId() + PnbConstants.RESULTMSG + new String(data));
		}
		return isoMsg;
	}
	
	@Override
	public ISOMsg createFundTransferMessage(BridgeDataObject bridgeDataObject)  throws ISOException 
	{
		ISOMsg isoMsg = null;
		
		LOGGER.info(PnbConstants.TRANSACTIONID +" : "+bridgeDataObject.getTransactionData().getTransactionId() + " In ISOMessageCreator -  createFundTransferMessage method. ");
		byte[] data=null;
		boolean condition1=false;
		boolean condition2=false;
		boolean condition3=false;
		if(!StringUtils.isBlank(bridgeDataObject.getPayerBankAccount().getAccountNumber())){
			condition1=true;
		}
		if(!StringUtils.isBlank(bridgeDataObject.getPayerBankAccount().getAccountNumber()) && !StringUtils.isBlank(bridgeDataObject.getPayerBankAccount().getbPin())
				){
			condition2=true;
		}
		if( !StringUtils.isBlank(bridgeDataObject.getPayeeBankAccount().getAccountNumber())
				&& bridgeDataObject.getAmount()!=null){
			condition3=true;
		}
		
		if(condition1 && condition2 && condition3 && bridgeDataObject.getAmount()>0){
			isoMsg = getISOMsg(bridgeDataObject.getTransactionData().getTransactionId(),true);
			isoMsg.set(2,"KVO4121440"); //ICCD#
			isoMsg.set(3, "400000"); //Processing Code
			isoMsg.set(4, ISOUtil.padleft(String.valueOf(bridgeDataObject.getAmount()), 16, '0'));
			Calendar cd = new GregorianCalendar();
			String fyear =  Integer.toString(cd.get(Calendar.YEAR));
			String yr = fyear.substring(2, 4);
			String monthDate=Integer.toString(cd.get(Calendar.MONTH)+1)+""+cd.get(Calendar.DAY_OF_MONTH);
			String dateWoY=Integer.toString(cd.get(Calendar.MONTH)+1)+""+cd.get(Calendar.DAY_OF_MONTH)+""+cd.get(Calendar.HOUR)+""+cd.get(Calendar.MINUTE)+""+Calendar.SECOND;
			String dateWY=fyear+""+dateWoY;
			isoMsg.set(11, "202083"); // 12 Length Unique Number
			isoMsg.set(12, dateWY);
			isoMsg.set(17, fyear+""+monthDate);
			isoMsg.set(24, "200");
			isoMsg.set(32, "9024");
			isoMsg.set(37, "701115061919");  // 8 Length Unique Number
			isoMsg.set(41,  PnbConstants.ACN); // 8 Length Unique Number
			isoMsg.set(43, "0"); // Location
			isoMsg.set(49, "356");
			isoMsg.set(59, "0");
			
			isoMsg.set(102, bridgeDataObject.getPayerBankAccount().getIfscCode()+"00000000"+ISOUtils.getFinalPaddedData(bridgeDataObject.getPayerBankAccount().getAccountNumber(), true, 19, "0"));
			isoMsg.set(103, bridgeDataObject.getPayeeBankAccount().getIfscCode()+"00000000"+ISOUtils.getFinalPaddedData(bridgeDataObject.getPayeeBankAccount().getAccountNumber(), true, 19, "0"));
			
			isoMsg.set(123, "UBP");
			isoMsg.set(126, "TCS/FIGWAY/:KO:7321002100003083");
			logISOMsg(isoMsg);
			data = isoMsg.pack();
			LOGGER.info(PnbConstants.TRANSACTIONID +" : "+bridgeDataObject.getTransactionData().getTransactionId() + PnbConstants.RESULTMSG + new String(data));
		}
		return isoMsg;
	}
	@Override
	public ISOMsg createFundDebitMessage(BridgeDataObject bridgeDataObject, String transactionDetails)
			throws ISOException {
		LOGGER.info(PnbConstants.TRANSACTIONID +" : "+bridgeDataObject.getTransactionData().getTransactionId() + " In ISOMessageCreator -  createFundDebitMessage method. ");
		
		ISOMsg isoMsg = null;
		
		byte[] data=null;
		boolean condition1=false;
		boolean condition2=false;
		
		if(!StringUtils.isBlank(bridgeDataObject.getPayerBankAccount().getAccountNumber())){
			condition1=true;
		}
		if(!StringUtils.isBlank(bridgeDataObject.getPayerBankAccount().getAccountNumber()) && !StringUtils.isBlank(bridgeDataObject.getPayerBankAccount().getbPin()))
		{
			condition2=true;
		}
		
		
		if(condition1 && condition2 && bridgeDataObject.getAmount() > 0)
		{
			isoMsg = getISOMsg(bridgeDataObject.getTransactionData().getTransactionId(),true);
			//isoMsg.set(2,"KVO4121440"); //ICCD#
			isoMsg.set(3, "480000"); //Processing Code
			isoMsg.set(4, ISOUtil.padleft(String.valueOf(bridgeDataObject.getAmount()), 16, '0'));
			Calendar cd = new GregorianCalendar();
			String fyear =  Integer.toString(cd.get(Calendar.YEAR));
			String yr = fyear.substring(2, 4);
			String monthDate=Integer.toString(cd.get(Calendar.MONTH)+1)+""+cd.get(Calendar.DAY_OF_MONTH);
			String dateWoY=Integer.toString(cd.get(Calendar.MONTH)+1)+""+cd.get(Calendar.DAY_OF_MONTH)+""+cd.get(Calendar.HOUR)+""+cd.get(Calendar.MINUTE)+""+Calendar.SECOND;
			String dateWY=fyear+""+dateWoY;
			isoMsg.set(11, "202083"); // 12 Length Unique Number
			isoMsg.set(12, dateWY);   
			isoMsg.set(17, fyear+""+monthDate);
			isoMsg.set(24, "200");
			isoMsg.set(32, "9024");
			
			isoMsg.set(34, bridgeDataObject.getPayerBankAccount().getAccountNumber());  // 8 Length Unique Number
			
			isoMsg.set(49, "INR");
			//isoMsg.set(59, "0");
			isoMsg.set(102, bridgeDataObject.getPayerBankAccount().getIfscCode()+"00000000"+ISOUtils.getFinalPaddedData(bridgeDataObject.getPayerBankAccount().getAccountNumber(), true, 19, "0"));
			//isoMsg.set(103, bridgeDataObject.getPayeeBankAccount().getAccountNumber()); // Account Number Cr
			isoMsg.set(123, "UBP");
			isoMsg.set(125, bridgeDataObject.getServiceType().toString() + "#" + transactionDetails);
			
			/*logISOMsg(isoMsg);
			data = isoMsg.pack();*/
			LOGGER.info(PnbConstants.TRANSACTIONID +" : "+bridgeDataObject.getTransactionData().getTransactionId() + PnbConstants.RESULTMSG );
		}
		return isoMsg;
	}
	
	
	@Override
	public ISOMsg createFundCreditMessage(BridgeDataObject bridgeDataObject, String transactionDetails)
			throws ISOException {
		LOGGER.info(PnbConstants.TRANSACTIONID +" : "+bridgeDataObject.getTransactionData().getTransactionId() + " In ISOMessageCreator -  createFundTransferMessage method. ");
		byte[] data=null;
		
		ISOMsg isoMsg = null;
		
		boolean condition1=false;
		boolean condition2=false;
		
		if(!StringUtils.isBlank(bridgeDataObject.getPayerBankAccount().getAccountNumber())){
			condition1=true;
		}
		if(!StringUtils.isBlank(bridgeDataObject.getPayerBankAccount().getAccountNumber()) && !StringUtils.isBlank(bridgeDataObject.getPayerBankAccount().getbPin())
				){
			condition2=true;
		}
		
		if(condition1 && condition2 && bridgeDataObject.getAmount() > 0)
		{
			isoMsg = getISOMsg(bridgeDataObject.getTransactionData().getTransactionId(),true);
			//isoMsg.set(2,"KVO4121440"); //ICCD#
			isoMsg.set(3, "490000"); //Processing Code
			isoMsg.set(4, ISOUtil.padleft(String.valueOf(bridgeDataObject.getAmount()), 16, '0'));
			Calendar cd = new GregorianCalendar();
			String fyear =  Integer.toString(cd.get(Calendar.YEAR));
			String yr = fyear.substring(2, 4);
			String monthDate=Integer.toString(cd.get(Calendar.MONTH)+1)+""+cd.get(Calendar.DAY_OF_MONTH);
			String dateWoY=Integer.toString(cd.get(Calendar.MONTH)+1)+""+cd.get(Calendar.DAY_OF_MONTH)+""+cd.get(Calendar.HOUR)+""+cd.get(Calendar.MINUTE)+""+Calendar.SECOND;
			String dateWY=fyear+""+dateWoY;
			isoMsg.set(11, "202083"); // 8 Length Unique Number
			isoMsg.set(12, dateWY);   
			isoMsg.set(17, fyear+""+monthDate);
			isoMsg.set(24, "200");
			isoMsg.set(32, "9024");
			
			isoMsg.set(34, bridgeDataObject.getPayerBankAccount().getAccountNumber());  // 8 Length Unique Number
			
			/*isoMsg.set(37, "701115061919");  // 8 Length Unique Number
			isoMsg.set(41,  PnbConstants.ACN); // 8 Length Unique Number
			isoMsg.set(43, "0"); // Location
*/			isoMsg.set(49, "INR");
			//isoMsg.set(59, "0");
			//isoMsg.set(102, bridgeDataObject.getPayerBankAccount().getAccountNumber()); // Account Number Dr
            isoMsg.set(103, bridgeDataObject.getPayerBankAccount().getIfscCode()+"00000000"+ISOUtils.getFinalPaddedData(bridgeDataObject.getPayerBankAccount().getAccountNumber(), true, 19, "0"));
			isoMsg.set(123, "UBP");
			isoMsg.set(125, bridgeDataObject.getServiceType().toString()+ "#" + transactionDetails);
			
			logISOMsg(isoMsg);
			data = isoMsg.pack();
			LOGGER.info(PnbConstants.TRANSACTIONID +" : "+bridgeDataObject.getTransactionData().getTransactionId() + PnbConstants.RESULTMSG + new String(data));
		}
		return isoMsg;
	}
	@Override
	public ISOMsg createWalletDebitMessage(BridgeDataObject bridgeDataObject, String transactionDetails)
			throws ISOException {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public ISOMsg createWalletCreditMessage(BridgeDataObject bridgeDataObject, String transactionDetails)
			throws ISOException {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public ISOMsg createChequeStatusMessage(BridgeDataObject bridgeDataObject) throws ISOException 
	{
		LOGGER.info(PnbConstants.TRANSACTIONID +" : "+bridgeDataObject.getTransactionData().getTransactionId() + " In ISOMessageCreator -  createChequeStatusMessage method. ");
		
		ISOMsg isoMsg = null;
		
		byte[] data=null;
		boolean condition1=false;
		boolean condition2=false;
		
		if(!StringUtils.isBlank(bridgeDataObject.getPayerBankAccount().getAccountNumber())){
			condition1=true;
		}
		if(!StringUtils.isBlank(bridgeDataObject.getPayerBankAccount().getAccountNumber()) && !StringUtils.isBlank(bridgeDataObject.getPayerBankAccount().getbPin()))
		{
			condition2=true;
		}
		
		
		if(condition1 && condition2 )
		{
			isoMsg = getISOMsg(bridgeDataObject.getTransactionData().getTransactionId(),true);
			//isoMsg.set(2,"KVO4121440"); //ICCD#
			if(bridgeDataObject.getServiceType() == ServiceType.BANKING_CHQ_STATUS)
				isoMsg.set(3, "940000"); //Processing Code
			else if(bridgeDataObject.getServiceType() == ServiceType.BANKING_STOP_CHEQUE)
				isoMsg.set(3, "950000"); //Processing Code
			
			isoMsg.set(4, "0000000000000000");
			Calendar cd = new GregorianCalendar();
			String fyear =  Integer.toString(cd.get(Calendar.YEAR));
			String yr = fyear.substring(2, 4);
			String monthDate=Integer.toString(cd.get(Calendar.MONTH)+1)+""+cd.get(Calendar.DAY_OF_MONTH);
			String dateWoY=Integer.toString(cd.get(Calendar.MONTH)+1)+""+cd.get(Calendar.DAY_OF_MONTH)+""+cd.get(Calendar.HOUR)+""+cd.get(Calendar.MINUTE)+""+Calendar.SECOND;
			String dateWY=fyear+""+dateWoY;
			isoMsg.set(11, "000000000000"); // 8 Length Unique Number
			isoMsg.set(12, dateWY);   
			isoMsg.set(17, fyear+""+monthDate);
			isoMsg.set(24, "200");
			isoMsg.set(32, "504511");
			
			isoMsg.set(34, ISOUtils.getFinalPaddedData(bridgeDataObject.getPayerBankAccount().getAccountNumber(), true, 13, "0"));
			isoMsg.set(41, "BANKAWAY");
			isoMsg.set(42, "BANKAWAY");
			
			isoMsg.set(49, "INR");
			
			if(bridgeDataObject.getServiceType() == ServiceType.BANKING_CHQ_STATUS)
				isoMsg.set(62, ISOUtils.getFinalPaddedData(bridgeDataObject.getCheque().getChequeNumber().toString(), true, 8, "0")+"005");
			else if(bridgeDataObject.getServiceType() == ServiceType.BANKING_STOP_CHEQUE)
				isoMsg.set(62, ISOUtils.getFinalPaddedData(bridgeDataObject.getCheque().getChequeNumber().toString(), true, 8, "0")+"001");
			
			//isoMsg.set(59, "0");
            isoMsg.set(102, bridgeDataObject.getPayerBankAccount().getIfscCode()+"00000000"+ISOUtils.getFinalPaddedData(bridgeDataObject.getPayerBankAccount().getAccountNumber(), true, 19, "0"));
			//isoMsg.set(103, bridgeDataObject.getPayeeBankAccount().getAccountNumber()); // Account Number Cr
			isoMsg.set(123, "BWY");
			isoMsg.set(125, bridgeDataObject.getServiceType().toString());
			
			/*logISOMsg(isoMsg);
			data = isoMsg.pack();*/
			LOGGER.info(PnbConstants.TRANSACTIONID +" : "+bridgeDataObject.getTransactionData().getTransactionId() + PnbConstants.RESULTMSG );
		}
		return isoMsg;
	}
	
	@Override
	public ISOMsg createStopChequeMessage(BridgeDataObject bridgeDataObject) throws ISOException 
	{
		LOGGER.info(PnbConstants.TRANSACTIONID +" : "+bridgeDataObject.getTransactionData().getTransactionId() + " In ISOMessageCreator -  createStopChequeMessage method. ");
		
		ISOMsg isoMsg = null;
		
		byte[] data=null;
		boolean condition1=false;
		boolean condition2=false;
		
		if(!StringUtils.isBlank(bridgeDataObject.getPayerBankAccount().getAccountNumber())){
			condition1=true;
		}
		if(!StringUtils.isBlank(bridgeDataObject.getPayerBankAccount().getAccountNumber()) && !StringUtils.isBlank(bridgeDataObject.getPayerBankAccount().getbPin()))
		{
			condition2=true;
		}
		
		
		if(condition1 && condition2 && bridgeDataObject.getAmount() > 0)
		{
			isoMsg = getISOMsg(bridgeDataObject.getTransactionData().getTransactionId(),true);
			//isoMsg.set(2,"KVO4121440"); //ICCD#
			isoMsg.set(3, "480000"); //Processing Code
			isoMsg.set(4, "0000000000000000");
			Calendar cd = new GregorianCalendar();
			String fyear =  Integer.toString(cd.get(Calendar.YEAR));
			String yr = fyear.substring(2, 4);
			String monthDate=Integer.toString(cd.get(Calendar.MONTH)+1)+""+cd.get(Calendar.DAY_OF_MONTH);
			String dateWoY=Integer.toString(cd.get(Calendar.MONTH)+1)+""+cd.get(Calendar.DAY_OF_MONTH)+""+cd.get(Calendar.HOUR)+""+cd.get(Calendar.MINUTE)+""+Calendar.SECOND;
			String dateWY=fyear+""+dateWoY;
			isoMsg.set(11, "000000000000"); // 8 Length Unique Number
			isoMsg.set(12, dateWY);   
			isoMsg.set(17, fyear+""+monthDate);
			isoMsg.set(24, "200");
			isoMsg.set(32, "9024");
			
			isoMsg.set(34, bridgeDataObject.getPayerBankAccount().getAccountNumber());  // 8 Length Unique Number
			
			isoMsg.set(49, "INR");
			//isoMsg.set(59, "0");
            isoMsg.set(102, ISOUtils.getFinalPaddedData(bridgeDataObject.getPayerBankAccount().getAccountNumber(), true, 16, "0") + bridgeDataObject.getPayerBankAccount().getIfscCode());
			//isoMsg.set(103, bridgeDataObject.getPayeeBankAccount().getAccountNumber()); // Account Number Cr
			isoMsg.set(123, "BWY");
			isoMsg.set(125, bridgeDataObject.getServiceType().toString());
			
			/*logISOMsg(isoMsg);
			data = isoMsg.pack();*/
			LOGGER.info(PnbConstants.TRANSACTIONID +" : "+bridgeDataObject.getTransactionData().getTransactionId() + PnbConstants.RESULTMSG );
		}
		return isoMsg;
	}
	
	@Override
	public ISOMsg createWalletBalanceEnquiryMessage(BridgeDataObject bridgeDataObject) throws ISOException 
	{
		LOGGER.info(PnbConstants.TRANSACTIONID +" : "+bridgeDataObject.getTransactionData().getTransactionId() + " In ISOMessageCreator -  createWalletBalanceEnquiryMessage method. ");
		
		ISOMsg isoMsg = null;
		
		byte[] data=null;
		boolean condition1=false;
		boolean condition2=false;
		
		if(!StringUtils.isBlank(bridgeDataObject.getPayerWallet().getAccountNumber())){
			condition1=true;
		}
		if(!StringUtils.isBlank(bridgeDataObject.getPayerWallet().getAccountNumber()))
		{
			condition2=true;
		}
		
		
		if(condition1 && condition2 )
		{
			isoMsg = getISOMsg(bridgeDataObject.getTransactionData().getTransactionId(),true);
			
			/*isoMsg.set(4, "0000000000000000");
			Calendar cd = new GregorianCalendar();
			String fyear =  Integer.toString(cd.get(Calendar.YEAR));
			String yr = fyear.substring(2, 4);
			String monthDate=Integer.toString(cd.get(Calendar.MONTH)+1)+""+cd.get(Calendar.DAY_OF_MONTH);
			String dateWoY=Integer.toString(cd.get(Calendar.MONTH)+1)+""+cd.get(Calendar.DAY_OF_MONTH)+""+cd.get(Calendar.HOUR)+""+cd.get(Calendar.MINUTE)+""+Calendar.SECOND;
			String dateWY=fyear+""+dateWoY;
			isoMsg.set(11, "000000000000"); // 8 Length Unique Number
			isoMsg.set(12, dateWY);   
			isoMsg.set(17, fyear+""+monthDate);
			isoMsg.set(24, "200");
			isoMsg.set(32, "504511");
			
			isoMsg.set(34, ISOUtils.getFinalPaddedData(bridgeDataObject.getPayerBankAccount().getAccountNumber(), true, 13, "0"));
			isoMsg.set(41, "BANKAWAY");
			isoMsg.set(42, "BANKAWAY");
			
			isoMsg.set(49, "INR");
			
			if(bridgeDataObject.getServiceType() == ServiceType.BANKING_CHQ_STATUS)
				isoMsg.set(62, ISOUtils.getFinalPaddedData(bridgeDataObject.getCheque().getChequeNumber().toString(), true, 8, "0")+"005");
			else if(bridgeDataObject.getServiceType() == ServiceType.BANKING_STOP_CHEQUE)
				isoMsg.set(62, ISOUtils.getFinalPaddedData(bridgeDataObject.getCheque().getChequeNumber().toString(), true, 8, "0")+"001");
			
			//isoMsg.set(59, "0");
            isoMsg.set(102, bridgeDataObject.getPayerBankAccount().getIfscCode()+"00000000"+ISOUtils.getFinalPaddedData(bridgeDataObject.getPayerBankAccount().getAccountNumber(), true, 19, "0"));
			//isoMsg.set(103, bridgeDataObject.getPayeeBankAccount().getAccountNumber()); // Account Number Cr
			isoMsg.set(123, "BWY");
			isoMsg.set(125, bridgeDataObject.getServiceType().toString());*/
			
			/*logISOMsg(isoMsg);
			data = isoMsg.pack();*/
			
			
			//Mof Fin
			isoMsg.set(2, "6273109999999999");
			isoMsg.set(3, ISOConstant.PROCESS_CODE_BALNACE_ENQUIRY);
			isoMsg.set(4, "000000000000");
			isoMsg.set(7, KeyEncryptionUtils.dateToString(new Date(), ISOConstant.DATE_TIME_FORMAT));
			isoMsg.set(11, CommonUtils.getRandomNumber(ISOConstant.SYSTEM_TRACE_AUDIT_NUMBER_LENGTH));
			isoMsg.set(12, KeyEncryptionUtils.dateToString(new Date(), ISOConstant.DATE_FORMAT));
			isoMsg.set(13, KeyEncryptionUtils.dateToString(new Date(), ISOConstant.DATE_FORMAT));
			isoMsg.set(41, "TMODEFIN");
			isoMsg.set(42, "Balance Enquiry");
			isoMsg.set(49, "356");
			isoMsg.set(60, "MODE");
			isoMsg.set(102, bridgeDataObject.getPayerWallet().getAccountNumber());
			
			LOGGER.info(PnbConstants.TRANSACTIONID +" : "+bridgeDataObject.getTransactionData().getTransactionId() + PnbConstants.RESULTMSG );
		}
		return isoMsg;
	}
	
	@Override
	public ISOMsg createWalletFundTransfer(BridgeDataObject bridgeDataObject) throws ISOException 
	{
		LOGGER.info(PnbConstants.TRANSACTIONID +" : "+bridgeDataObject.getTransactionData().getTransactionId() + " In ISOMessageCreator -  createWalletFundTransfer method. ");
		
		ISOMsg isoMsg = null;
		
		byte[] data=null;
		boolean condition1=false;
		boolean condition2=false;
		
		if(!StringUtils.isBlank(bridgeDataObject.getPayerWallet().getAccountNumber())){
			condition1=true;
		}
		
		if(!StringUtils.isBlank(bridgeDataObject.getPayerWallet().getAccountNumber()) && !StringUtils.isBlank(bridgeDataObject.getPayeeWallet().getMsisdn()))
		{
			condition2=true;
		}
		
		
		if(condition1 && condition2 )
		{
			isoMsg = getISOMsg(bridgeDataObject.getTransactionData().getTransactionId(),true);
			
			//Mof Fin
			isoMsg.set(2, "6273109999999999");
			isoMsg.set(3, "470000");
			isoMsg.set(4, "000000000"+bridgeDataObject.getAmount().toString());
			isoMsg.set(7, KeyEncryptionUtils.dateToString(new Date(), ISOConstant.DATE_TIME_FORMAT));
			isoMsg.set(8, "00000000");
			isoMsg.set(11, CommonUtils.getRandomNumber(ISOConstant.SYSTEM_TRACE_AUDIT_NUMBER_LENGTH));
			isoMsg.set(12, KeyEncryptionUtils.dateToString(new Date(), ISOConstant.DATE_FORMAT));
			isoMsg.set(13, KeyEncryptionUtils.dateToString(new Date(), ISOConstant.DATE_FORMAT));
			isoMsg.set(22, "810");
			isoMsg.set(25, "00");
			isoMsg.set(41, "TMODEFIN");
			isoMsg.set(42, "Tfr :"+bridgeDataObject.getPayeeWallet().getMsisdn());
			isoMsg.set(49, "800");
			isoMsg.set(102, bridgeDataObject.getPayerWallet().getAccountNumber());
			isoMsg.set(103, bridgeDataObject.getPayeeWallet().getMsisdn());
			isoMsg.set(125, bridgeDataObject.getPayeeWallet().getMsisdn());
			
			LOGGER.info(PnbConstants.TRANSACTIONID +" : "+bridgeDataObject.getTransactionData().getTransactionId() + PnbConstants.RESULTMSG );
		}
		return isoMsg;
	}
	@Override
	public ISOMsg createWalletBillPay(BridgeDataObject bridgeDataObject) throws ISOException 
	{
		LOGGER.info(PnbConstants.TRANSACTIONID +" : "+bridgeDataObject.getTransactionData().getTransactionId() + " In ISOMessageCreator -  createWalletBillPay method. ");
		
		ISOMsg isoMsg = null;
		
		byte[] data=null;
		boolean condition1=false;
		boolean condition2=false;
		
		ProvidersData fromCache = bridgeDataObject.getHostSubVersionData().getProviderMap().get(ProviderRelation.FSP_PROVIDER).get(new ProvidersData(bridgeDataObject.getProvider().getCode()));
		
		ProvidersData requestDetals = bridgeDataObject.getProvider();
		
		//String transactionDetails = "Utility Payment:"+fromCache.getCategory().getName()+"-"+fromCache.getName()+"-"+;
		
		
		if(!StringUtils.isBlank(bridgeDataObject.getPayerWallet().getAccountNumber())){
			condition1=true;
		}
		
		if(!StringUtils.isBlank(bridgeDataObject.getPayerWallet().getAccountNumber()) && bridgeDataObject.getProvider() != null)
		{
			condition2=true;
		}
		
		
		if(condition1 && condition2 )
		{
			isoMsg = getISOMsg(bridgeDataObject.getTransactionData().getTransactionId(),true);
			
			//Mof Fin
			isoMsg.set(2, "6273109999999999");
			isoMsg.set(3, "410000");
			isoMsg.set(4, "000000000"+bridgeDataObject.getAmount().toString());
			isoMsg.set(7, KeyEncryptionUtils.dateToString(new Date(), ISOConstant.DATE_TIME_FORMAT));
			isoMsg.set(8, "00000000");
			isoMsg.set(11, CommonUtils.getRandomNumber(ISOConstant.SYSTEM_TRACE_AUDIT_NUMBER_LENGTH));
			isoMsg.set(12, KeyEncryptionUtils.dateToString(new Date(), ISOConstant.DATE_FORMAT));
			isoMsg.set(13, KeyEncryptionUtils.dateToString(new Date(), ISOConstant.DATE_FORMAT));
			isoMsg.set(22, "810");
			isoMsg.set(25, "00");
			isoMsg.set(41, "TMODEFIN");
			isoMsg.set(42, "Bill Payment");
			isoMsg.set(48, fromCache.getName());  //Telecom Operator
			isoMsg.set(49, "356");
			isoMsg.set(60, "000"+requestDetals.getProviderCode());                 //Provider Code
			isoMsg.set(102, bridgeDataObject.getPayerWallet().getAccountNumber());
			isoMsg.set(103, requestDetals.getSubscriberId()); //Mobile Number
			
			LOGGER.info(PnbConstants.TRANSACTIONID +" : "+bridgeDataObject.getTransactionData().getTransactionId() + PnbConstants.RESULTMSG );
		}
		
		return isoMsg;
	}
	@Override
	public ISOMsg createWalletMiniStatementMessage(BridgeDataObject bridgeDataObject) throws ISOException 
	{
		LOGGER.info(PnbConstants.TRANSACTIONID +" : "+bridgeDataObject.getTransactionData().getTransactionId() + " In ISOMessageCreator -  createWalletMiniStatementMessage method. ");
		
		ISOMsg isoMsg = null;
		
		byte[] data=null;
		boolean condition1=false;
		boolean condition2=false;
		
		if(!StringUtils.isBlank(bridgeDataObject.getPayerWallet().getAccountNumber())){
			condition1=true;
		}
		
		
		
		if(condition1 )
		{
			isoMsg = getISOMsg(bridgeDataObject.getTransactionData().getTransactionId(),true);
			
			//Mof Fin
			isoMsg.set(2, "6273109999999999");
			isoMsg.set(3, ISOConstant.PROCESS_CODE_MINI_STATEMENT);
			isoMsg.set(4, "000000000000");
			isoMsg.set(7, KeyEncryptionUtils.dateToString(new Date(), ISOConstant.DATE_TIME_FORMAT));
			isoMsg.set(8, "00000000");
			isoMsg.set(11, CommonUtils.getRandomNumber(ISOConstant.SYSTEM_TRACE_AUDIT_NUMBER_LENGTH));
			isoMsg.set(12, KeyEncryptionUtils.dateToString(new Date(), ISOConstant.DATE_FORMAT));
			isoMsg.set(13, KeyEncryptionUtils.dateToString(new Date(), ISOConstant.DATE_FORMAT));
			isoMsg.set(22, "810");
			isoMsg.set(25, "00");
			isoMsg.set(41, "TMODEFIN");
			isoMsg.set(42, "MODEFIN");
			isoMsg.set(49, "800");
			isoMsg.set(102, bridgeDataObject.getPayerWallet().getAccountNumber());
			
			LOGGER.info(PnbConstants.TRANSACTIONID +" : "+bridgeDataObject.getTransactionData().getTransactionId() + PnbConstants.RESULTMSG );
		}
		return isoMsg;
	}

}
