package com.ng.sb.common.dataobject;

import java.util.List;

public class AccountTypesData  extends BaseObjectData{
	private static final long serialVersionUID = 1L;
	private List<String> accountTypeDatas;

	public List<String> getAccountTypeDatas() {
		return accountTypeDatas;
	}

	public void setAccountTypeDatas(List<String> accountTypeDatas) {
		this.accountTypeDatas = accountTypeDatas;
	}
}
