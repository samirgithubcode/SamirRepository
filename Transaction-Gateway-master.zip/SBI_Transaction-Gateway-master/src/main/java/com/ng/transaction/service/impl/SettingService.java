/**
 * 
 */
package com.ng.transaction.service.impl;

import org.springframework.stereotype.Service;

import com.ng.sb.common.dataobject.BridgeDataObject;
import com.ng.sb.common.util.SystemConstant;
import com.ng.transaction.service.ISettingService;

/**
 * @author gaurav
 *
 */
@Service(value=SystemConstant.SETTING_SERVICE)
public class SettingService extends FundTransferMgtService implements
		ISettingService {

	/* (non-Javadoc)
	 * @see com.ng.transaction.service.ISettingService#changePin(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject changePin(BridgeDataObject bridgeDataObject) {
		System.out.println("in SettingService service==>>>> SETTING_CHANGE_PIN");
		return invokeBridge(bridgeDataObject);
	}

	@Override
	public BridgeDataObject createPin(BridgeDataObject bridgeDataObject) {
		System.out.println("in SettingService service==>>>> SETTING_CREATE_PIN");
		return invokeBridge(bridgeDataObject);
	}
	
	
	@Override
	public BridgeDataObject changeWalletPin(BridgeDataObject bridgeDataObject) {
		System.out.println("in SettingService service==>>>> SETTING_CHANGE_WALLET_PIN");
		return invokeBridge(bridgeDataObject);
	}

	@Override
	public BridgeDataObject createWalletPin(BridgeDataObject bridgeDataObject) {
		System.out.println("in SettingService service==>>>> SETTING_CREATE_WALLET_PIN");
		return invokeBridge(bridgeDataObject);
	}
	
	/* (non-Javadoc)
	 * @see com.ng.transaction.service.ISettingService#saveMyBankAccount(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject saveMyBankAccount(BridgeDataObject bridgeDataObject) {
		System.out.println("in SettingService service==>>>> SETTINGS_BANK_ACC_ADD");
		return invokeBridge(bridgeDataObject);
	}

	/* (non-Javadoc)
	 * @see com.ng.transaction.service.ISettingService#editMyBankAccount(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject editMyBankAccount(BridgeDataObject bridgeDataObject) {
		System.out.println("in SettingService service==>>>> SETTINGS_BANK_ACC_EDIT");
		return invokeBridge(bridgeDataObject);
	}
	
	/* (non-Javadoc)
	 * @see com.ng.transaction.service.ISettingService#deleteMyBankAccount(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject deleteMyBankAccount(BridgeDataObject bridgeDataObject) {
		System.out.println("in SettingService service==>>>> SETTINGS_BANK_ACC_DELETE");
		return invokeBridge(bridgeDataObject);
	}
	
	/* (non-Javadoc)
	 * @see com.ng.transaction.service.ISettingService#saveMyCreditCard(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject saveMyCreditCard(BridgeDataObject bridgeDataObject) {
		System.out.println("in SettingService service==>>>> SETTINGS_CC_ADD");
		return invokeBridge(bridgeDataObject);
	}
	
	/* (non-Javadoc)
	 * @see com.ng.transaction.service.ISettingService#editMyCreditCard(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject editMyCreditCard(BridgeDataObject bridgeDataObject) {
		System.out.println("in SettingService service==>>>> SETTINGS_CC_DELETE");
		return invokeBridge(bridgeDataObject);
	}
	
	/* (non-Javadoc)
	 * @see com.ng.transaction.service.ISettingService#deleteMyCreditCard(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject deleteMyCreditCard(BridgeDataObject bridgeDataObject) {
		System.out.println("in SettingService service==>>>> SETTINGS_CC_DELETE");
		return invokeBridge(bridgeDataObject);
	}
	

	/* (non-Javadoc)
	 * @see com.ng.transaction.service.ISettingService#saveMyIMPS(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject saveMyIMPS(BridgeDataObject bridgeDataObject) {
		// TODO Auto-generated method stub
		return invokeBridge(bridgeDataObject);
	}

	/* (non-Javadoc)
	 * @see com.ng.transaction.service.ISettingService#saveMyIndividual(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject saveMyIndividual(BridgeDataObject bridgeDataObject) {
		System.out.println("in SettingService service==>>>> SETTINGS_MY_PAYEE_ADD");
		return invokeBridge(bridgeDataObject);
	}

	/* (non-Javadoc)
	 * @see com.ng.transaction.service.ISettingService#editMyIndividual(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject editMyIndividual(BridgeDataObject bridgeDataObject) {
		System.out.println("in SettingService service==>>>> SETTINGS_MY_PAYEE_EDIT");
		return invokeBridge(bridgeDataObject);
	}
	/* (non-Javadoc)
	 * @see com.ng.transaction.service.ISettingService#deleteMyIndividual(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject deleteMyIndividual(BridgeDataObject bridgeDataObject) {
		System.out.println("in SettingService service==>>>> SETTINGS_MY_PAYEE_DELETE");
		return invokeBridge(bridgeDataObject);
	}
	
	/* (non-Javadoc)
	 * @see com.ng.transaction.service.ISettingService#saveMyForex(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject saveMyForex(BridgeDataObject bridgeDataObject) {
		System.out.println("in SettingService service==>>>> SETTINGS_FOREX_BENEFICIARY_ADD");
		return invokeBridge(bridgeDataObject);
	}

	/* (non-Javadoc)
	 * @see com.ng.transaction.service.ISettingService#editMyForex(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject editMyForex(BridgeDataObject bridgeDataObject) {
		System.out.println("in SettingService service==>>>> SETTINGS_FOREX_BENEFICIARY_EDIT");
		return invokeBridge(bridgeDataObject);
	}
	/* (non-Javadoc)
	 * @see com.ng.transaction.service.ISettingService#deleteMyForex(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject deleteMyForex(BridgeDataObject bridgeDataObject) {
		System.out.println("in SettingService service==>>>> SETTINGS_FOREX_BENEFICIARY_DELETE");
		return invokeBridge(bridgeDataObject);
	}
	
	/* (non-Javadoc)
	 * @see com.ng.transaction.service.ISettingService#saveMyMerchant(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject saveMyMerchant(BridgeDataObject bridgeDataObject) {
		System.out.println("in SettingService service==>>>> SETTINGS_MY_MERCHANT_ADD");
		return invokeBridge(bridgeDataObject);
	}

	/* (non-Javadoc)
	 * @see com.ng.transaction.service.ISettingService#editMyMerchant(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject editMyMerchant(BridgeDataObject bridgeDataObject) {
		System.out.println("in SettingService service==>>>> SETTINGS_MY_MERCHANT_EDIT");
		return invokeBridge(bridgeDataObject);
	}
	
	/* (non-Javadoc)
	 * @see com.ng.transaction.service.ISettingService#deleteMyMerchant(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject deleteMyMerchant(BridgeDataObject bridgeDataObject) {
		System.out.println("in SettingService service==>>>> SETTINGS_MY_MERCHANT_DELETE");
		return invokeBridge(bridgeDataObject);
	}
	
	/* (non-Javadoc)
	 * @see com.ng.transaction.service.ISettingService#saveMyBiller(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject saveMyBiller(BridgeDataObject bridgeDataObject) {
		System.out.println("in SettingService service==>>>> SETTINGS_MY_BILLER_ADD");
		return invokeBridge(bridgeDataObject);
	}
	
	/* (non-Javadoc)
	 * @see com.ng.transaction.service.ISettingService#editMyBiller(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject editMyBiller(BridgeDataObject bridgeDataObject) {
		System.out.println("in SettingService service==>>>> SETTINGS_MY_BILLER_EDIT");
		return invokeBridge(bridgeDataObject);
	}
	
	/* (non-Javadoc)
	 * @see com.ng.transaction.service.ISettingService#deleteMyBiller(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject deleteMyBiller(BridgeDataObject bridgeDataObject) {
		System.out.println("in SettingService service==>>>> SETTINGS_MY_BILLER_DELETE");
		return invokeBridge(bridgeDataObject);
	}

	/* (non-Javadoc)
	 * @see com.ng.transaction.service.ISettingService#last5Transactions(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject last5Transactions(BridgeDataObject bridgeDataObject) {
		System.out.println("in SettingService service==>>>> SETTINGS_LAST_5_TRANS");
		return invokeBridge(bridgeDataObject);
	}

	/* (non-Javadoc)
	 * @see com.ng.transaction.service.ISettingService#autoTopUp(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject autoTopUp(BridgeDataObject bridgeDataObject) {
		// TODO Auto-generated method stub
		return invokeBridge(bridgeDataObject);
	}

	/* (non-Javadoc)
	 * @see com.ng.transaction.service.ISettingService#recoverMySettings(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject recoverMySettings(BridgeDataObject bridgeDataObject) {
		System.out.println("in SettingService service==>>>> SETTINGS_RECOVER_SETTING");
		return invokeBridge(bridgeDataObject);
	}
	
	/* (non-Javadoc)
	 * @see com.ng.transaction.service.ISettingService#recoverMySettings(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject configOTP(BridgeDataObject bridgeDataObject) {
		System.out.println("in SettingService service==>>>> SETTINGS_OTP_CONF");
		return invokeBridge(bridgeDataObject);
	}

	
}
