/**
 * 
 */
package com.ng.base.invoker.impl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.google.gson.Gson;
import com.ng.base.invoker.util.BaseConstant;
import com.ng.sb.common.dataobject.BridgeDataObject;
import com.ng.sb.common.dataobject.PlatformLoginData;

/**
 * @author gopal
 *
 */
public class ThirdPartyInvoker  {

	public enum HTTPRequest{
		GET,
		PUT,
		POST
	}
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ThirdPartyInvoker.class);
	@Autowired
	PlatformLoginData platformLoginData;
	
	protected String getCatName(BridgeDataObject bridgeDataObject){
		boolean condition1=false;
		boolean condition2=false;
		
		if(bridgeDataObject == null )
		{
			return null;
		}
		
		if( bridgeDataObject.getProvider()!=null && bridgeDataObject.getProvider().getCategory()!=null)
		{
			condition1=true;
		}
		if(bridgeDataObject.getProvider().getCategory().getName()!=null && !bridgeDataObject.getProvider().getCategory().getName().isEmpty())
		{
			condition2=true;
		}
		
			if(condition1 && condition2)
			{
				return bridgeDataObject.getProvider().getCategory().getName().toLowerCase();
			}else
				return null;	
	}
	
	protected <T>T callRestAPI(String transactionId,String partnerName,String urlValue,Object reqObject,Class<T> respType){
		try {
			URL url = new URL(urlValue);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty(BaseConstant.CONTENTTYPE, "application/json");
			
		     
		     Gson gson = new Gson();
		     String jsonString=gson.toJson(reqObject);
		     
		     LOGGER.info(BaseConstant.TRANSACTIONID +" : "+ transactionId + " Request JSON String ## " + jsonString + " for Partner ## " +partnerName);
		     
		     OutputStream os = conn.getOutputStream();
		     os.write(jsonString.getBytes());
			 os.flush();
		     
			 BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));

			String output;
			StringBuilder sb=new StringBuilder();
			while ((output = br.readLine()) != null) {
				sb.append(output);
			}
			conn.disconnect();
			LOGGER.info(BaseConstant.TRANSACTIONID +" : "+ transactionId + " Output from  Partner ##  " + partnerName + " is  ###  " + sb.toString());
			JAXBContext jaxbContext = JAXBContext.newInstance(respType);
            Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
            StringReader reader = new StringReader(sb.toString());
            return (T)unmarshaller.unmarshal(reader);
			
		} catch (Exception e) {
			LOGGER.info(""+e);
		}
		return null;
	}
	
	protected <L,T>T callRestAPI(String transactionId,String partnerName,String urlValue,Object reqObject,Class<L> requestType,Class<T> respType){
		try {
			URL url = new URL(urlValue);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty(BaseConstant.CONTENTTYPE, "application/xml");
			
		     
			
			JAXBContext jaxbContext = JAXBContext.newInstance(requestType);
			Marshaller jaxbMarshaller = jaxbContext.createMarshaller();


			 java.io.StringWriter sw = new StringWriter();

			 jaxbMarshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
			 jaxbMarshaller.marshal(reqObject, sw);
			 String reqXMLString = sw.toString();
			 
		     LOGGER.info(BaseConstant.TRANSACTIONID +" : "+ transactionId + " Request xml String for Partner ## " +partnerName + " is ## " + reqXMLString);
		     
		     OutputStream os = conn.getOutputStream();
		     os.write(reqXMLString.getBytes());
			 os.flush();
		     
			 BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));

			String output;
			StringBuilder sb=new StringBuilder();
			while ((output = br.readLine()) != null) {
				sb.append(output);
			}
			conn.disconnect();
			LOGGER.info(BaseConstant.TRANSACTIONID +" : "+ transactionId + " Output from Partner ## " + partnerName + " is ###  " + sb.toString());
			JAXBContext jaxbContext1 = JAXBContext.newInstance(respType);
            Unmarshaller unmarshaller = jaxbContext1.createUnmarshaller();
            StringReader reader = new StringReader(sb.toString());
            return (T)unmarshaller.unmarshal(reader);
			
		} catch (Exception e) {
			LOGGER.info(""+e);
		}
		return null;
	}
	protected <T>T callGetRestAPI(String url,Map<String,String> headerMap,Class<T> respType) throws IOException{
		HttpClient client = HttpClientBuilder.create().build();
		HttpGet request = new HttpGet(url);
		 HttpResponse response = client.execute(request);
		BufferedReader rd =null;
		try (InputStreamReader isr=new InputStreamReader(response.getEntity().getContent())){
			Iterator<Entry<String, String>> it = headerMap.entrySet().iterator();
		    while (it.hasNext()) {
		        Map.Entry<String,String> pair = it.next();
				request.addHeader(pair.getKey(), pair.getValue());
		    }
		    rd = new BufferedReader(isr);
			StringBuilder result = new StringBuilder();
			String line;
			while ((line = rd.readLine()) != null) {
				result.append(line);
			}
			Gson gson=new Gson();
			return (T)gson.fromJson(result.toString(), respType);
			
		} catch (Exception e) {
			LOGGER.info("Exception : "+e);
			}
		finally
		{
			 
			 if(rd!=null)
			 {
				 rd.close();
			 }
		}
		return null;
	}
	
	protected <T>T callPutRestAPI(String urlValue){
		try {
			
			
			URL url = new URL(urlValue);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod("PUT");
			conn.setRequestProperty(BaseConstant.CONTENTTYPE, "application/x-www-form-urlencoded");
			conn.setRequestProperty("name", "Testing");
			conn.setRequestProperty("initiator_id", "9910028267");
			conn.setRequestProperty("developer_key", "becbbce45f79c6f5109f848acd540567");
			BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			String output;
			StringBuilder sb=new StringBuilder();
			while ((output = br.readLine()) != null) {
				sb.append(output);
			}
			conn.disconnect();
		
		} catch (Exception e) {
			LOGGER.info("Exception : "+e);
		}
		return null;
	}
}