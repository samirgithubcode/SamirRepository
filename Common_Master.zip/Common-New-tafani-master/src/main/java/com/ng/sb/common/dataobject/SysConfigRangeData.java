package com.ng.sb.common.dataobject;


/**
 * @author gaurav
 *
 * Data Transfer Object to hold list of ranges for particular commission template.
 */
public class SysConfigRangeData extends BaseObjectData{
	private static final long serialVersionUID = 1L;

	private float max;

	private float min;

	private String type;

	private float value;

	public float getMax() {
		return max;
	}

	public void setMax(float max) {
		this.max = max;
	}

	public float getMin() {
		return min;
	}

	public void setMin(float min) {
		this.min = min;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public float getValue() {
		return value;
	}

	public void setValue(float value) {
		this.value = value;
	}

}
