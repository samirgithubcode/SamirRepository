/**
 * 
 */
package com.ng.sb.common.model;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.ng.sb.common.dataobject.ValidationBean;

/**
 * @author gopal
 *
 */
@Entity
@Table(name = "overlay_merchant_details")
@NamedQueries({
    @NamedQuery(name = "OverlayMerchants.findById", query = "SELECT s FROM OverlayMerchants s WHERE s.id = :id"),
    @NamedQuery(name = "OverlayMerchants.findByMsisdn", query = "SELECT s FROM OverlayMerchants s WHERE s.customerMsisdn = :customerMsisdn"),
    @NamedQuery(name = "OverlayMerchants.findByAccountId", query = "SELECT s FROM OverlayMerchants s WHERE s.accountId = :accountId")
   })
public class OverlayMerchants implements ValidationBean {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "id")
	private Integer id;
	
	@Column(name = "customerId")
	private String customerId;
	
	@Column(name = "customerMsisdn")
	private Long customerMsisdn;
	
	@Column(name = "accountId")
	private String accountId;

	@Column(name = "bharatQrCode")
	private String bharatQrCode;

	@Column(name = "nickName")
	private String merchantNickName;
	
	@Column(name = "merchantId")
	private BigDecimal merchantId;
	
	@Column(name = "accountNumber")
	private Long accountNumber;
	
	@Column(name = "ifscCode")
	private String ifscCode;
	
	@Column(name = "mmid")
	private String accountMmid;
	
	@Column(name = "merchantMsisdn")
	private String merchantMsisdn;
	
	@Column(name = "walletTypeId")
	private Integer walletTypeId;
	
	@Column(name = "walletId")
	private Long walletNumber;
	
	@Column(name = "status")
	private String merchantStatus;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "addedOn")
	private Date addedOn;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "modifiedOn")
	private Date modifiedOn;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public Long getCustomerMsisdn() {
		return customerMsisdn;
	}

	public void setCustomerMsisdn(Long customerMsisdn) {
		this.customerMsisdn = customerMsisdn;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getMerchantNickName() {
		return merchantNickName;
	}

	public void setMerchantNickName(String merchantNickName) {
		this.merchantNickName = merchantNickName;
	}

	public BigDecimal getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(BigDecimal merchantId) {
		this.merchantId = merchantId;
	}

	public Long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getIfscCode() {
		return ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	public String getAccountMmid() {
		return accountMmid;
	}

	public void setAccountMmid(String accountMmid) {
		this.accountMmid = accountMmid;
	}

	public String getMerchantMsisdn() {
		return merchantMsisdn;
	}

	public void setMerchantMsisdn(String merchantMsisdn) {
		this.merchantMsisdn = merchantMsisdn;
	}

	public Integer getWalletTypeId() {
		return walletTypeId;
	}

	public void setWalletTypeId(Integer walletTypeId) {
		this.walletTypeId = walletTypeId;
	}

	public Long getWalletNumber() {
		return walletNumber;
	}

	public void setWalletNumber(Long walletNumber) {
		this.walletNumber = walletNumber;
	}

	public String getMerchantStatus() {
		return merchantStatus;
	}

	public void setMerchantStatus(String merchantStatus) {
		this.merchantStatus = merchantStatus;
	}

	public Date getAddedOn() {
		return addedOn;
	}

	public void setAddedOn(Date addedOn) {
		this.addedOn = addedOn;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public String getBharatQrCode() {
		return bharatQrCode;
	}

	public void setBharatQrCode(String bharatQrCode) {
		this.bharatQrCode = bharatQrCode;
	}

	
}
