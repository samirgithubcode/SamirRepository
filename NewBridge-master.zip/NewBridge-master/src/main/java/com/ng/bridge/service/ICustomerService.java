/**
 * 
 */
package com.ng.bridge.service;

import com.ng.bridge.exception.GenericException;
import com.ng.sb.common.dataobject.BridgeDataObject;
import com.ng.sb.common.model.ThirdPartySubsRecipient;
import com.ng.sb.common.model.ThirdPartySubscriber;

/**
 * @author ram
 * This service deals with the customer data
 *
 */

public interface ICustomerService {
	public ThirdPartySubscriber checkMobileNumber(BridgeDataObject bridgeDataObject) throws GenericException;
	public ThirdPartySubsRecipient checkRecipient(BridgeDataObject bridgeDataObject,int tpsId);
	
}
