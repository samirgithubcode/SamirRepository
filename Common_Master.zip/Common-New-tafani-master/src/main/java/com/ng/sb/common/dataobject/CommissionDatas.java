/**
 * 
 */
package com.ng.sb.common.dataobject;

import java.util.Date;
import java.util.List;

/**
 * @author gaurav Data Transfer object to carry data for Commission Template.
 * 
 */
public class CommissionDatas extends BaseObjectData {
	private static final long serialVersionUID = 1L;
	private Integer commissionId;
	private Integer subscriptionId;
	private String customerCommissionType;
	private String commissionName;
	private Integer productTypeHidden;
	private String commissionHidden;
	private Integer commissionIdHidden;
	private String productsId;
	private String deduction;
	private List<SysConfigRangeData> sysConfigRangeCustomer;
	private List<CommissionDatas> listcomdata;
	private List<List<String>> commissionTemplateList;
	private List<List<String>> commissionTypeList;
	private List<List<String>> deductionList;
	private List<List<String>> subscriptionTemplateList;
	public enum TemplateCommissionType {
		NO, BOTH, CUST, PART, PORTAL
	}

	public enum CommissionDesc {
		NO, AMT, PERC
	}

	public enum CommissionType {
		FIXED, RANGE
	}

	private String senderCommDesc;
	private Integer senderCommFixedValue;
	private Integer senderCommMax;
	private Integer senderCommMin;
	private String senderCommType;
	private Date createdDate;
	private Double hostCommission=0.0;
	private Double distCommission=0.0;
	private Double subDistCommission=0.0;
	private Double agentCommission=0.0;
	private Double bankCommission=0.0;
	private Double totalCommission=0.0;
	private Double hostSubscription=0.0;
	private Double distSubscription=0.0;
	private Double subDistSubscription=0.0;
	private Double agentSubscription=0.0;
	private Double bankSubscription=0.0;
	private Double totalSubscription=0.0;
	private String subscription;
	private String templateCommType;
	private String description;
	private Date editDate;
	private Integer status;
	private Date startDate;
	private Date endDate;
	private Integer userLoginId;
	private Integer parentId;
	private String commissionTypeHidden;

	public String getCommissionHidden() {
		return commissionHidden;
	}

	public String getProductsId() {
		return productsId;
	}

	public void setProductsId(String productsId) {
		this.productsId = productsId;
	}

	public Double getHostCommission() {
		return hostCommission;
	}

	public void setHostCommission(Double hostCommission) {
		this.hostCommission = hostCommission;
	}

	public Double getDistCommission() {
		return distCommission;
	}

	public void setDistCommission(Double distCommission) {
		this.distCommission = distCommission;
	}

	public Double getSubDistCommission() {
		return subDistCommission;
	}

	public void setSubDistCommission(Double subDistCommission) {
		this.subDistCommission = subDistCommission;
	}

	public Double getAgentCommission() {
		return agentCommission;
	}

	public void setAgentCommission(Double agentCommission) {
		this.agentCommission = agentCommission;
	}

	public Double getTotalCommission() {
		return totalCommission;
	}

	public void setTotalCommission(Double totalCommission) {
		this.totalCommission = totalCommission;
	}

	public String getTemplateCommType() {
		return templateCommType;
	}

	public void setTemplateCommType(String templateCommType) {
		this.templateCommType = templateCommType;
	}

	public void setCommissionHidden(String commissionHidden) {
		this.commissionHidden = commissionHidden;
	}

	public String getCommissionTypeHidden() {
		return commissionTypeHidden;
	}

	public void setCommissionTypeHidden(String commissionTypeHidden) {
		this.commissionTypeHidden = commissionTypeHidden;
	}

	public Integer getProductTypeHidden() {
		return productTypeHidden;
	}

	public void setProductTypeHidden(Integer integer) {
		this.productTypeHidden = integer;
	}

	public String getCommissionName() {
		return commissionName;
	}

	public void setCommissionName(String commissionName) {
		this.commissionName = commissionName;
	}

	public String getCustomerCommissionType() {
		return customerCommissionType;
	}

	public void setCustomerCommissionType(String customerCommissionType) {
		this.customerCommissionType = customerCommissionType;
	}

	public Integer getCommissionId() {
		return commissionId;
	}

	public void setCommissionId(Integer commissionId) {
		this.commissionId = commissionId;
	}

	public void setSysConfigRangeCustomer(List<SysConfigRangeData> sysConfigRangeCustomer) {
		this.sysConfigRangeCustomer = sysConfigRangeCustomer;
	}

	public List<CommissionDatas> getListcomdata() {
		return listcomdata;
	}

	public void setListcomdata(List<CommissionDatas> listcomdata) {
		this.listcomdata = listcomdata;
	}

	public String getSenderCommDesc() {
		return senderCommDesc;
	}

	public void setSenderCommDesc(String senderCommDesc) {
		this.senderCommDesc = senderCommDesc;
	}

	public Integer getSenderCommFixedValue() {
		return senderCommFixedValue;
	}

	public void setSenderCommFixedValue(Integer senderCommFixedValue) {
		this.senderCommFixedValue = senderCommFixedValue;
	}

	public Integer getSenderCommMax() {
		return senderCommMax;
	}

	public void setSenderCommMax(Integer senderCommMax) {
		this.senderCommMax = senderCommMax;
	}

	public Integer getSenderCommMin() {
		return senderCommMin;
	}

	public void setSenderCommMin(Integer senderCommMin) {
		this.senderCommMin = senderCommMin;
	}

	public String getSenderCommType() {
		return senderCommType;
	}

	public void setSenderCommType(String senderCommType) {
		this.senderCommType = senderCommType;
	}

	public Date getStartDate() {
		return startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public Integer getParentId() {
		return parentId;
	}

	public Integer getUserLoginId() {
		return userLoginId;
	}

	public void setUserLoginId(Integer userLoginId) {
		this.userLoginId = userLoginId;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getEditDate() {
		return editDate;
	}

	public void setEditDate(Date editDate) {
		this.editDate = editDate;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public List<SysConfigRangeData> getSysConfigRangeCustomer() {
		return sysConfigRangeCustomer;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;

	}

	public void setParentId(Integer parentId) {
		this.parentId = parentId;

	}

	public Integer getCommissionIdHidden() {
		return commissionIdHidden;
	}

	public void setCommissionIdHidden(Integer commissionIdHidden) {
		this.commissionIdHidden = commissionIdHidden;
	}

	public List<List<String>> getCommissionTemplateList() {
		return commissionTemplateList;
	}

	public void setCommissionTemplateList(List<List<String>> commissionTemplateList) {
		this.commissionTemplateList = commissionTemplateList;
	}

	public List<List<String>> getCommissionTypeList() {
		return commissionTypeList;
	}

	public void setCommissionTypeList(List<List<String>> commissionTypeList) {
		this.commissionTypeList = commissionTypeList;
	}

	public Double getBankCommission() {
		return bankCommission;
	}

	public void setBankCommission(Double bankCommission) {
		this.bankCommission = bankCommission;
	}

	public String getDeduction() {
		return deduction;
	}

	public void setDeduction(String deduction) {
		this.deduction = deduction;
	}

	public List<List<String>> getDeductionList() {
		return deductionList;
	}

	public void setDeductionList(List<List<String>> deductionList) {
		this.deductionList = deductionList;
	}

	public Double getHostSubscription() {
		return hostSubscription;
	}

	public void setHostSubscription(Double hostSubscription) {
		this.hostSubscription = hostSubscription;
	}

	public Double getDistSubscription() {
		return distSubscription;
	}

	public void setDistSubscription(Double distSubscription) {
		this.distSubscription = distSubscription;
	}

	public Double getSubDistSubscription() {
		return subDistSubscription;
	}

	public void setSubDistSubscription(Double subDistSubscription) {
		this.subDistSubscription = subDistSubscription;
	}

	public Double getAgentSubscription() {
		return agentSubscription;
	}

	public void setAgentSubscription(Double agentSubscription) {
		this.agentSubscription = agentSubscription;
	}

	public Double getBankSubscription() {
		return bankSubscription;
	}

	public void setBankSubscription(Double bankSubscription) {
		this.bankSubscription = bankSubscription;
	}

	public Double getTotalSubscription() {
		return totalSubscription;
	}

	public void setTotalSubscription(Double totalSubscription) {
		this.totalSubscription = totalSubscription;
	}

	public String getSubscription() {
		return subscription;
	}

	public void setSubscription(String subscription) {
		this.subscription = subscription;
	}

	public Integer getSubscriptionId() {
		return subscriptionId;
	}

	public void setSubscriptionId(Integer subscriptionId) {
		this.subscriptionId = subscriptionId;
	}

	public List<List<String>> getSubscriptionTemplateList() {
		return subscriptionTemplateList;
	}

	public void setSubscriptionTemplateList(List<List<String>> subscriptionTemplateList) {
		this.subscriptionTemplateList = subscriptionTemplateList;
	}



}
