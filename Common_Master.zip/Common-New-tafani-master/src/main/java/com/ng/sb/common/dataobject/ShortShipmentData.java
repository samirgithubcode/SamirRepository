package com.ng.sb.common.dataobject;

import java.util.List;
import java.util.Map;

/**
 * @author abhishek
 *
 */
public class ShortShipmentData extends BaseObjectData {

	private static final long serialVersionUID = 1L;
	private String mainSeriesFrom;
	private String mainSeriesTo;
	private String boxNo;
	private String product;
	private String masterVersion;
	private String po;
	private Integer orderNo;
	private Map<Integer,String> masterVersionData;
	private Map<Integer,String> productData;
	private Map<Integer,String> orderData;
	private Map<Integer,String> statusData;
	private String status;
	private Integer products;
	private Integer masterVersions;
	private List<ShortShipmentData> data;
	public String getMainSeriesFrom() {
		return mainSeriesFrom;
	}
	public void setMainSeriesFrom(String mainSeriesFrom) {
		this.mainSeriesFrom = mainSeriesFrom;
	}
	
	public String getBoxNo() {
		return boxNo;
	}
	public void setBoxNo(String boxNo) {
		this.boxNo = boxNo;
	}
	public String getMainSeriesTo() {
		return mainSeriesTo;
	}
	public void setMainSeriesTo(String mainSeriesTo) {
		this.mainSeriesTo = mainSeriesTo;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public String getMasterVersion() {
		return masterVersion;
	}
	public void setMasterVersion(String masterVersion) {
		this.masterVersion = masterVersion;
	}
	public String getPo() {
		return po;
	}
	public void setPo(String po) {
		this.po = po;
	}
	public Integer getOrderNo() {
		return orderNo;
	}
	public void setOrderNo(Integer orderNo) {
		this.orderNo = orderNo;
	}
	public Map<Integer, String> getMasterVersionData() {
		return masterVersionData;
	}
	public void setMasterVersionData(Map<Integer, String> masterVersionData) {
		this.masterVersionData = masterVersionData;
	}
	public Map<Integer, String> getProductData() {
		return productData;
	}
	public void setProductData(Map<Integer, String> productData) {
		this.productData = productData;
	}
	public Map<Integer, String> getOrderData() {
		return orderData;
	}
	public void setOrderData(Map<Integer, String> orderData) {
		this.orderData = orderData;
	}
	public Map<Integer, String> getStatusData() {
		return statusData;
	}
	public void setStatusData(Map<Integer, String> statusData) {
		this.statusData = statusData;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Integer getProducts() {
		return products;
	}
	public void setProducts(Integer products) {
		this.products = products;
	}
	public Integer getMasterVersions() {
		return masterVersions;
	}
	public void setMasterVersions(Integer masterVersions) {
		this.masterVersions = masterVersions;
	}
	public List<ShortShipmentData> getData() {
		return data;
	}
	public void setData(List<ShortShipmentData> data) {
		this.data = data;
	}
}
