package com.ng.sb.common.dataobject;

import java.sql.Date;
import java.util.List;

import com.ng.sb.common.model.PayCardAppPartner;
import com.ng.sb.common.model.PayCardApps;

public class AppPartnerData extends BaseObjectData{
   private static final long serialVersionUID=1L;
   private String partnerName;
   private String partnerDescription;
   private Date startDate;
   private Date endDate;
   private String status;
   private PayCardApps paycardAppId;
   private String appName;
   private List<PayCardAppPartner> partnerDetailList;
   public PayCardApps getPaycardAppId() {
	return paycardAppId;
}
public void setPaycardAppId(PayCardApps paycardAppId) {
	this.paycardAppId = paycardAppId;
}
public String getAppName() {
	return appName;
}
public void setAppName(String appName) {
	this.appName = appName;
}

   public String getPartnerName() {
	return partnerName;
}
public void setPartnerName(String partnerName) {
	this.partnerName = partnerName;
}
public String getPartnerDescription() {
	return partnerDescription;
}
public void setPartnerDescription(String partnerDescription) {
	this.partnerDescription = partnerDescription;
}
public Date getStartDate() {
	return startDate;
}
public void setStartDate(Date startDate) {
	this.startDate = startDate;
}
public Date getEndDate() {
	return endDate;
}
public void setEndDate(Date endDate) {
	this.endDate = endDate;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public List<PayCardAppPartner> getPartnerDetailList() {
	return partnerDetailList;
}
public void setPartnerDetailList(List<PayCardAppPartner> partnerDetailList) {
	this.partnerDetailList = partnerDetailList;
}

}
