package com.ng.sb.common.dataobject;
import java.util.Map;

public class PackagingData extends BaseObjectData {

	private static final long serialVersionUID = 1L;

	private String packagingName;
	private String packagingParentName;
	private String productFrom;
	private String productTo;
	private String overLay;
	private String product;
	private String masterVersion;
	private String productType;
	private String cardType;
	private String quantity;
	private String productsreader;
	private int levelNumber;
	
	public String getProductsreader() {
		return productsreader;
	}
	public void setProductsreader(String productsreader) {
		this.productsreader = productsreader;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	private String products;
	private String groupType;
	private Map<Integer,String> mvData;
	private Map<Integer,String> cardData;
	private Map<Integer,String> groupData;
	public String getOverLay() {
		return overLay;
	}
	public void setOverLay(String overLay) {
		this.overLay = overLay;
	}
	public String getProductFrom() {
		return productFrom;
	}
	public void setProductFrom(String productFrom) {
		this.productFrom = productFrom;
	}
	public String getProductTo() {
		return productTo;
	}
	public void setProductTo(String productTo) {
		this.productTo = productTo;
	}
	public String getPackagingParentName() {
		return packagingParentName;
	}
	public void setPackagingParentName(String packagingParentName) {
		this.packagingParentName = packagingParentName;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	
	
	public Map<Integer, String> getMvData() {
		return mvData;
	}
	public void setMvData(Map<Integer, String> mvData) {
		this.mvData = mvData;
	}
	public Map<Integer, String> getCardData() {
		return cardData;
	}
	public void setCardData(Map<Integer, String> cardData) {
		this.cardData = cardData;
	}
	public Map<Integer, String> getGroupData() {
		return groupData;
	}
	public void setGroupData(Map<Integer, String> groupData) {
		this.groupData = groupData;
	}
	public String getPackagingName() {
		return packagingName;
	}
	public void setPackagingName(String packagingName) {
		this.packagingName = packagingName;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public String getMasterVersion() {
		return masterVersion;
	}
	public void setMasterVersion(String masterVersion) {
		this.masterVersion = masterVersion;
	}
	public String getProducts() {
		return products;
	}
	public void setProducts(String products) {
		this.products = products;
	}
	public String getCardType() {
		return cardType;
	}
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}
	public String getGroupType() {
		return groupType;
	}
	public void setGroupType(String groupType) {
		this.groupType = groupType;
	}
	/**
	 * @return the levelNumber
	 */
	public int getLevelNumber() {
		return levelNumber;
	}
	/**
	 * @param levelNumber the levelNumber to set
	 */
	public void setLevelNumber(int levelNumber) {
		this.levelNumber = levelNumber;
	}
}