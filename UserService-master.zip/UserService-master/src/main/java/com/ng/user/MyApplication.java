/**
 * 
 */
package com.ng.user;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

/**
 * @author gopal
 *
 */
@ComponentScan({ "com.ng.user" ,"com.ng.sb"})
@SpringBootApplication
public class MyApplication {

public static void main(String[] args) {
	System.setProperty("spring.devtools.restart.enabled", "false");
SpringApplication.run(MyApplication.class, args);

}

}