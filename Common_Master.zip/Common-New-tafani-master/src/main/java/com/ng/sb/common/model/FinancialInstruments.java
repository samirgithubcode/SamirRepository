package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name = "financial_instrument")
@XmlRootElement
@NamedQueries({

		@NamedQuery(name = "FinancialInstruments.findAll", query = "SELECT p FROM FinancialInstruments p"),
		@NamedQuery(name = "FinancialInstruments.findById", query = "SELECT p FROM FinancialInstruments p where p.id=:id"),
		 @NamedQuery(name = "FinancialInstruments.findByName", query = "SELECT f FROM FinancialInstruments f WHERE f.name = :name"),
		    @NamedQuery(name = "FinancialInstruments.findByNameandId", query = "SELECT b FROM FinancialInstruments b WHERE b.name = :name  AND b.id=:id"),

})
public class FinancialInstruments implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name = "end_date")
	@Temporal(TemporalType.DATE)
	private Date endDate;

	@Column(name = "addedBy", length = 8)
	private int addedBy;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(unique = true, nullable = false)
	private Integer id;
	@Column(name = "modifiedOn")
	private Date modifiedOn;
	@Column(name = "name", length = 20)
	private String name;

	@Basic(optional = false)
	@Column(name = "start_date")
	@Temporal(TemporalType.DATE)
	private Date startDate;

	@Column(name = "modifiedBy", length = 8)
	private int modifiedBy;

	@Column(name = "status", length = 1)
	private boolean status;
	@Column(name = "addedOn")
	private Date addedOn;

	public FinancialInstruments() {
		// empty

	}

	public FinancialInstruments(Integer id) {
		super();
		this.id = id;
	}

	@Override
	public int hashCode() {
		 int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FinancialInstruments other = (FinancialInstruments) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	public Date getEndDate() {
		return endDate;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public int getAddedBy() {
		return addedBy;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public void setAddedBy(int addedBy) {
		this.addedBy = addedBy;
	}

	public int getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(int modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getAddedOn() {
		return addedOn;
	}

	public void setAddedOn(Date addedOn) {
		this.addedOn = addedOn;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

}
