/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "sim_temp_block_history")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "SimTempBlockHistory.findAll", query = "SELECT s FROM SimTempBlockHistory s"),
    @NamedQuery(name = "SimTempBlockHistory.findById", query = "SELECT s FROM SimTempBlockHistory s WHERE s.id = :id"),
    @NamedQuery(name = "SimTempBlockHistory.findByTransactiondetailsid", query = "SELECT s FROM SimTempBlockHistory s WHERE s.transactiondetailsid = :transactiondetailsid"),
    @NamedQuery(name = "SimTempBlockHistory.findByInvalidPinCount", query = "SELECT s FROM SimTempBlockHistory s WHERE s.invalidPinCount = :invalidPinCount"),
    @NamedQuery(name = "SimTempBlockHistory.findByLockDate", query = "SELECT s FROM SimTempBlockHistory s WHERE s.lockDate = :lockDate")})
public class SimTempBlockHistory implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
    @Basic(optional = false)
    @Column(name = "Transaction_details_id", nullable = false)
    private int transactiondetailsid;
    @Basic(optional = false)
    @Column(name = "invalid_pin_count", nullable = false)
    private int invalidPinCount;
    @Basic(optional = false)
    @Column(name = "lock_date", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date lockDate;
    @JoinColumn(name = "user_id", referencedColumnName = "id", nullable = false)
    @ManyToOne(optional = false)
    private Subscriber userId;

    public SimTempBlockHistory() {
    	//default constructor
    }

    public SimTempBlockHistory(Integer id) {
        this.id = id;
    }

    public SimTempBlockHistory(Integer id, int transactiondetailsid, int invalidPinCount, Date lockDate) {
        this.id = id;
        this.transactiondetailsid = transactiondetailsid;
        this.invalidPinCount = invalidPinCount;
        this.lockDate = lockDate;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public int getTransactiondetailsid() {
        return transactiondetailsid;
    }

    public void setTransactiondetailsid(int transactiondetailsid) {
        this.transactiondetailsid = transactiondetailsid;
    }

    public int getInvalidPinCount() {
        return invalidPinCount;
    }

    public void setInvalidPinCount(int invalidPinCount) {
        this.invalidPinCount = invalidPinCount;
    }

    public Date getLockDate() {
        return lockDate;
    }

    public void setLockDate(Date lockDate) {
        this.lockDate = lockDate;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }
    
    public Subscriber getUserId() {
        return userId;
    }

    public void setUserId(Subscriber userId) {
        this.userId = userId;
    }

    

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof SimTempBlockHistory)) {
            return false;
        }
        SimTempBlockHistory other = (SimTempBlockHistory) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.SimTempBlockHistory[ id=" + id + " ]";
    }
    
}
