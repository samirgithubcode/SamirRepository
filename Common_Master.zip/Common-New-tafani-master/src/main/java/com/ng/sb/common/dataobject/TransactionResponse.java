package com.ng.sb.common.dataobject;


public class TransactionResponse implements ValidationBean
{
	private static final long serialVersionUID = 1L;
	private String txnId;
	private String txnInstrument;
	private String appName;
	private int status;
	private String msg;
	private double txnAmount;
	private String txnTime;
	private String txnType;
	private int txnStatus;
	private String accessChannel;
	private String agentName;
	private String agentMsisdn;
	private String subscriberName;
	private String subscriberNumber;
	private String transactionNature;
	private Integer closingBalance;
	//private Integer productId;
	private String productType;
	
	private Double commAmount;
	 
	 public Double getCommAmount() {
		return commAmount;
	}
	public void setCommAmount(Double commAmount) {
		this.commAmount = commAmount;
	}
	public Double getNetTxnAmount() {
		return netTxnAmount;
	}
	public void setNetTxnAmount(Double netTxnAmount) {
		this.netTxnAmount = netTxnAmount;
	}
	private Double netTxnAmount;
	 
	 private String productId;
	
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	
	public String getTxnId() {
		return txnId;
	}
	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}
	public String getTxnInstrument() {
		return txnInstrument;
	}
	public void setTxnInstrument(String txnInstrument) {
		this.txnInstrument = txnInstrument;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public double getTxnAmount() {
		return txnAmount;
	}
	public void setTxnAmount(double txnAmount) {
		this.txnAmount = txnAmount;
	}
	public String getTxnTime() {
		return txnTime;
	}
	public void setTxnTime(String txnTime) {
		this.txnTime = txnTime;
	}
	public String getTxnType() {
		return txnType;
	}
	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}
	public int getTxnStatus() {
		return txnStatus;
	}
	public void setTxnStatus(int txnStatus) {
		this.txnStatus = txnStatus;
	}
	public String getAccessChannel() {
		return accessChannel;
	}
	public void setAccessChannel(String accessChannel) {
		this.accessChannel = accessChannel;
	}
	public String getAgentName() {
		return agentName;
	}
	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}
	public String getAgentMsisdn() {
		return agentMsisdn;
	}
	public void setAgentMsisdn(String agentMsisdn) {
		this.agentMsisdn = agentMsisdn;
	}
	public String getSubscriberName() {
		return subscriberName;
	}
	public void setSubscriberName(String subscriberName) {
		this.subscriberName = subscriberName;
	}
	public String getSubscriberNumber() {
		return subscriberNumber;
	}
	public void setSubscriberNumber(String subscriberNumber) {
		this.subscriberNumber = subscriberNumber;
	}
	public String getTransactionNature() {
		return transactionNature;
	}
	public void setTransactionNature(String transactionNature) {
		this.transactionNature = transactionNature;
	}
	public Integer getClosingBalance() {
		return closingBalance;
	}
	public void setClosingBalance(Integer closingBalance) {
		this.closingBalance = closingBalance;
	}
	
	
	
}
