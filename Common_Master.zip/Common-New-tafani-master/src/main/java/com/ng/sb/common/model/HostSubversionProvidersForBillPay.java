package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;
/**
*
* @author Simran
* 
* The persistent class for the HostSubversion providers for bill payment database table for OTA.
*/
@Entity
@Table(name = "hostsubversion_providers_billpay")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "HostSubversionProvidersForBillPay.findByHsvId", query = "SELECT h FROM HostSubversionProvidersForBillPay h where h.hsvId = :hsvId"),
    @NamedQuery(name="HostSubversionProvidersForBillPay.findByHsvIdandcatproviderId",query="SELECT h FROM HostSubversionProvidersForBillPay h where h.hsvId = :hsvId AND h.catId=:catId AND h.providerId=:providerId"),

})
public class HostSubversionProvidersForBillPay  implements Serializable {
	private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "hsvId")
    private Integer hsvId;
    @Column(name = "catId")
    private String catId;
    @Column(name = "categoryName")
    private String categoryName;
    @Column(name = "providerId")
    private String providerId;
    @Column(name = "providerName")
    private String providerName;
    @Column(name = "providerCode")
    private String providerCode;
    @Column(name = "status")
    private String status;
	@Column(name = "createDate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createDate;
    @Column(name = "last_modified")
    @Temporal(TemporalType.TIMESTAMP)
    private Date modifiedDate;
    @Column(name = "last_OTA_modified")
    @Temporal(TemporalType.TIMESTAMP)
    private Date otaModifiedDate;
    @Column(name = "addedBy")
    private Integer addedBy;
    @Column(name = "modifiedBy")
    private Integer modifiedBy;
    @Column(name = "scheduledDate")
    @Temporal(TemporalType.DATE)
    private Date scheduledDate;
    public HostSubversionProvidersForBillPay() {
    	//default constructor
    }

    public HostSubversionProvidersForBillPay(Integer id) {
        this.id = id;
    }

    public HostSubversionProvidersForBillPay(Integer id, String providerName, Date createDate, Date modifiedDate, Date otaModifiedDate) {
        this.id = id;
        this.providerName = providerName;
        this.createDate = createDate;
        this.modifiedDate = modifiedDate;
        this.otaModifiedDate = otaModifiedDate;
    }
    public String getProviderName() {
		return providerName;
	}

	public String getCategoryName() {
		return categoryName;
	}
   	public String getStatus() {
		return status;
	}

	public String getProviderCode() {
		return providerCode;
	}

	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public void setCatId(String catId) {
		this.catId = catId;
	}

	public void setProviderId(String providerId) {
		this.providerId = providerId;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getHsvId() {
		return hsvId;
	}
	public void setHsvId(Integer hsvId) {
		this.hsvId = hsvId;
	}
	
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public Date getOtaModifiedDate() {
		return otaModifiedDate;
	}
	public void setOtaModifiedDate(Date otaModifiedDate) {
		this.otaModifiedDate = otaModifiedDate;
	}
	
	public Integer getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Integer getAddedBy() {
		return addedBy;
	}
	public void setAddedBy(Integer addedBy) {
		this.addedBy = addedBy;
	}
	public Date getScheduledDate() {
		return scheduledDate;
	}

	public void setScheduledDate(Date scheduledDate) {
		this.scheduledDate = scheduledDate;
	}

	public String getCatId() {
		return catId;
	}

	public String getProviderId() {
		return providerId;
	}

	@Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof HostSubversionProvidersForBillPay)) {
            return false;
        }
        boolean check=true;
        HostSubversionProvidersForBillPay other = (HostSubversionProvidersForBillPay) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.HostSubversionProvidersForBillPay[ id=" + id + " ]";
    }
}
