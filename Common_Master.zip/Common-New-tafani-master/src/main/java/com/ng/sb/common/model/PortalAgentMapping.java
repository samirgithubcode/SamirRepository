package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name = "portalagentmapping")
@NamedQueries({
	@NamedQuery(name="PortalAgentMapping.findAll", query="SELECT p FROM PortalAgentMapping p "),
	

})
public class PortalAgentMapping implements Serializable{
	
	    private static final long serialVersionUID = 1L;
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Basic(optional = false)
	    @Column(name = "id")
	    private Integer id;
	    
	    @JoinColumn(name = "agentId", referencedColumnName = "id")
	    @ManyToOne
	    private AccountLoginInfo agentId;
	    
	    @JoinColumn(name = "portalId", referencedColumnName = "id")
	    private PortalRegistration portalId;
	    
		@JoinColumn(name = "addedBy", referencedColumnName = "id")
	    private AccountLoginInfo addedBy;
	    
	    @JoinColumn(name = "modifiedby", referencedColumnName = "id")
	    private AccountLoginInfo modifiedBy;
	    
	    
	    @Column(name = "addedOn")
	    @Temporal(TemporalType.DATE)
	    private Date addedOn;
	    
	    @Column(name = "modifiedOn")
	    @Temporal(TemporalType.DATE)
	    private Date modifiedOn;
	    
	    @Column(name = "status")
	    private Integer status;
	    
	    public PortalAgentMapping() {
	    	//empty
	    }

	    public PortalAgentMapping(Integer id) {
	        this.id = id;
	    }
	    public AccountLoginInfo getAgentId() {
			return agentId;
		}

		public void setAgentId(AccountLoginInfo agentId) {
			this.agentId = agentId;
		}

		public PortalRegistration getPortalId() {
			return portalId;
		}

		public void setPortalId(PortalRegistration portalId) {
			this.portalId = portalId;
		}

		public AccountLoginInfo getAddedBy() {
			return addedBy;
		}

		public void setAddedBy(AccountLoginInfo addedBy) {
			this.addedBy = addedBy;
		}

		public AccountLoginInfo getModifiedBy() {
			return modifiedBy;
		}

		public void setModifiedById(AccountLoginInfo modifiedBy) {
			this.modifiedBy = modifiedBy;
		}

		public Date getAddedOn() {
			return addedOn;
		}

		public void setAddedOn(Date addedOn) {
			this.addedOn = addedOn;
		}

		public Date getModifiedOn() {
			return modifiedOn;
		}

		public void setModifiedOn(Date modifiedOn) {
			this.modifiedOn = modifiedOn;
		}

		public Integer getStatus() {
			return status;
		}

		public void setStatus(Integer status) {
			this.status = status;
		}



		public Integer getId() {
			return id;
		}

		public void setId(Integer id) {
			this.id = id;
		}

		

		@Override
	    public int hashCode() {
	        int hash = 0;
	        hash += (id != null ? id.hashCode() : 0);
	        return hash;
	    }

	    @Override
	    public boolean equals(Object object) {
	    	boolean check=true;
	    	if(object!=null){
	        if (!(object instanceof PortalAgentMapping)) {
	        	check= false;
	        }
	        PortalAgentMapping other = (PortalAgentMapping) object;
	        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
	        	check= false;
	        }
	    	}
	        return check;
	    }

	    @Override
	    public String toString() {
	        return "com.mine.model.PortalAgentMapping[ id=" + id + " ]";
	    }
	}


