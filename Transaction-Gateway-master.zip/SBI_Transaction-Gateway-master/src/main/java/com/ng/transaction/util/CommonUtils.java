/**
 * 
 */
package com.ng.transaction.util;

import java.util.Date;
import java.util.Iterator;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ng.sb.common.dataobject.BankAccount;
import com.ng.sb.common.dataobject.BridgeDataObject;
import com.ng.sb.common.dataobject.BridgeDataResponse;
import com.ng.sb.common.dataobject.CategoryData;
import com.ng.sb.common.dataobject.Cheque;
import com.ng.sb.common.dataobject.ProvidersData;
import com.ng.sb.common.dataobject.RequestObject;
import com.ng.sb.common.dataobject.ResponseObject;
import com.ng.sb.common.dataobject.Settings;
import com.ng.sb.common.dataobject.TransactionData;
import com.ng.sb.common.dataobject.UserAccountData;
import com.ng.sb.common.dataobject.ValidationBean;
import com.ng.sb.common.dataobject.Wallet;
import com.ng.sb.common.logger.DateTimeUtil;
import com.ng.sb.common.model.CustomerPreferredBiller;
import com.ng.sb.common.model.OverlayMerchants;
import com.ng.sb.common.model.PayeeDetails;
import com.ng.sb.common.util.EncryptionUtils;
import com.ng.sb.common.util.ErrorCodes;
import com.ng.sb.common.util.KeyEncryptionUtils;
import com.ng.sb.common.util.TransactionIdGenerator;
import com.ng.transaction.data.BankingRequest;
import com.ng.transaction.data.WalletRequest;

/**
 * @author gaurav
 *
 */
public class CommonUtils {

	private static final Logger LOGGER = LoggerFactory.getLogger(CommonUtils.class);
	
	public static ResponseObject validateRequestData(ValidationBean txnHistoryRequest, RequestObject requestObject, HttpServletRequest request) 
	{
		ResponseObject responseObject = new ResponseObject();
		
		  if(txnHistoryRequest == null)
		  {
			    responseObject.setStatus(ErrorCodes.REQUIRED_PARAMETERS_MISSING.getCode());
				responseObject.setMessage(ErrorCodes.REQUIRED_PARAMETERS_MISSING.getMessage());
				
				LOGGER.error("[RESPONSE]  [METHOD_NAME] " +Thread.currentThread().getStackTrace()[1].getMethodName()+ " [TOKEN_STRING] " +requestObject.getTokenId()+ " [ACCESS_CHANNEL] " + requestObject.getChannelId() + " [REQUEST_FROM] " +request.getRemoteAddr() + " [ERROR_CODE] " +responseObject.getStatus()+" [ERROR_MESSAGE] " +responseObject.getMessage());
				 
				return responseObject;
		  }
		  
			  Set<ConstraintViolation<ValidationBean>> validationError = KeyEncryptionUtils.validateBean(txnHistoryRequest);
			
					if(validationError != null && !validationError.isEmpty())
					{
						Iterator<ConstraintViolation<ValidationBean>>  itr =  validationError.iterator();
						 
						 responseObject.setStatus(ErrorCodes.REQUIRED_PARAMETERS_MISSING.getCode());
						 
						 StringBuilder builder = new StringBuilder();
						 
						 int counter = 1;
						 while(itr.hasNext())
						 {
							 builder.append(counter+". "+itr.next().getMessage()+" ");
							 
							 counter++;
						 }
						
						 responseObject.setMessage(builder.toString());
					
						 LOGGER.error("[RESPONSE]  [METHOD_NAME] " +Thread.currentThread().getStackTrace()[1].getMethodName()+ " [TOKEN_STRING] " +requestObject.getTokenId()+ " [ACCESS_CHANNEL] " + requestObject.getChannelId() + " [REQUEST_FROM] " +request.getRemoteAddr() + " [ERROR] " +builder.toString());
						 
						 return responseObject;
					}
					
		return responseObject;
	}

	public static ResponseObject validateRequest(UserAccountData accountData, RequestObject requestObject, HttpServletRequest request) 
	{
		ResponseObject responseObject = new ResponseObject();
		
		if(accountData == null)
		{
			responseObject.setStatus(ErrorCodes.AUTH_TOKEN_EXPIRED.getCode());
			responseObject.setMessage(ErrorCodes.AUTH_TOKEN_EXPIRED.getMessage());
			
			LOGGER.error("[RESPONSE]  [METHOD_NAME] " +Thread.currentThread().getStackTrace()[1].getMethodName()+ " [TOKEN_STRING] " +requestObject.getTokenId()+ " [ACCESS_CHANNEL] " + requestObject.getChannelId() + " [REQUEST_FROM] " +request.getRemoteAddr() + " [ERROR_CODE] " +responseObject.getStatus()+" [ERROR_MESSAGE] " +responseObject.getMessage());
			 
			return responseObject;
		}

		if(accountData.getChannelId() != requestObject.getChannelId())
		{
			responseObject.setStatus(ErrorCodes.INVALID_REQUEST.getCode());
			responseObject.setMessage(ErrorCodes.INVALID_REQUEST.getMessage());
			
			LOGGER.error("[RESPONSE]  [METHOD_NAME] " +Thread.currentThread().getStackTrace()[1].getMethodName()+ " [TOKEN_STRING] " +requestObject.getTokenId()+ " [ACCESS_CHANNEL] " + requestObject.getChannelId() + " [REQUEST_FROM] " +request.getRemoteAddr() + " [ERROR_CODE] " +responseObject.getStatus()+" [ERROR_MESSAGE] " +responseObject.getMessage());
			 
			return responseObject;
		}
		
		return responseObject;
   }
	
	public static ResponseObject setStatusCode(BridgeDataResponse bridgeResponse, ResponseObject responseObject) 
	{
		switch (bridgeResponse.getStatus()) 
		{
		case SUCCESS:
			responseObject.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
			responseObject.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
			break;
		
		case FAILED:
			responseObject.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseObject.setMessage(bridgeResponse.getResponseMsg());
			break;
			
			default:
				responseObject.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
				responseObject.setMessage(ErrorCodes.REQUEST_FAILED.getMessage());
				break;
		}
		
		return responseObject;
	}

	public static BridgeDataObject setPayeeDetails(BridgeDataObject bridgeDataObject, PayeeDetails payee) 
	{
			//case SETTINGS_MY_PAYEE_ADD:
		BankAccount payerBank = new BankAccount();
		Wallet payerWallet = new Wallet();	
		
		switch(bridgeDataObject.getServiceType()) 
		{
		
		case SETTINGS_MY_PAYEE_ADD:
			payerBank.setAccountName(payee.getAccountName());
			payerBank.setAccountId(EncryptionUtils.stringToHex(com.ng.sb.common.util.CommonUtils.getRandomNumber(2)));
			payerBank.setName(payee.getPayeeNickName());
			payerBank.setAccountNumber(payee.getAccountNumber().toString());
			payerBank.setIfscCode(payee.getIfscCode());
			payerBank.setMmid(payee.getAccountMmid());
			payerWallet.setMerchantId(payee.getPayeeMobileNumber());
			payerWallet.setWalletCode(payee.getWalletTypeId());
			payerWallet.setMsisdn(payee.getWalletNumber().toString());
			break;
			
		case SETTINGS_MY_PAYEE_EDIT:
		
			    payerBank.setAccountName(payee.getAccountName());
				payerBank.setAccountId(payee.getAccountId());
				payerBank.setName(payee.getPayeeNickName());
				payerBank.setAccountNumber(payee.getAccountNumber().toString());
				payerBank.setIfscCode(payee.getIfscCode());
				payerBank.setMmid(payee.getAccountMmid());
				payerWallet.setMerchantId(payee.getPayeeMobileNumber());
				payerWallet.setWalletCode(payee.getWalletTypeId());
				payerWallet.setMsisdn(payee.getWalletNumber().toString());
				break;
				
		case SETTINGS_MY_PAYEE_DELETE:
				
				payerBank.setAccountId(payee.getAccountId());
				break;
		}
		
		bridgeDataObject.setPayerBankAccount(payerBank);
		bridgeDataObject.setPayerWallet(payerWallet);
		
		return bridgeDataObject;
	}
	
	public static BridgeDataObject setMerchantDetails(BridgeDataObject bridgeDataObject, OverlayMerchants overlayMerchant) 
	{
		
		BankAccount payerBank = new BankAccount();
		Wallet payerWallet = new Wallet();	
		switch(bridgeDataObject.getServiceType()) 
		{
		
		case SETTINGS_MY_MERCHANT_ADD:
			
			payerBank.setAccountId(EncryptionUtils.stringToHex(com.ng.sb.common.util.CommonUtils.getRandomNumber(2)));
			payerBank.setAccountNickName(overlayMerchant.getMerchantNickName());
			payerBank.setAccountNumber(overlayMerchant.getAccountNumber().toString());
			payerBank.setIfscCode(overlayMerchant.getIfscCode());
			payerBank.setMmid(overlayMerchant.getAccountMmid());
			payerBank.setBharatQrCode(overlayMerchant.getBharatQrCode());
			payerWallet.setMerchantId(overlayMerchant.getMerchantMsisdn());
			payerWallet.setWalletCode(overlayMerchant.getWalletTypeId());
			payerWallet.setMsisdn(overlayMerchant.getWalletNumber().toString());
			
			break;
			
		case SETTINGS_MY_MERCHANT_EDIT:
			
				payerBank.setAccountId(overlayMerchant.getAccountId());
				payerBank.setAccountNickName(overlayMerchant.getMerchantNickName());
				payerBank.setAccountNumber(overlayMerchant.getAccountNumber().toString());
				payerBank.setIfscCode(overlayMerchant.getIfscCode());
				payerBank.setMmid(overlayMerchant.getAccountMmid());
				payerBank.setBharatQrCode(overlayMerchant.getBharatQrCode());
				payerWallet.setMerchantId(overlayMerchant.getMerchantMsisdn());
				payerWallet.setWalletCode(overlayMerchant.getWalletTypeId());
				payerWallet.setMsisdn(overlayMerchant.getWalletNumber().toString());
				
				break;
		case SETTINGS_MY_MERCHANT_DELETE:
				payerBank.setAccountId(overlayMerchant.getAccountId());
				break;	
		}
				bridgeDataObject.setPayerBankAccount(payerBank);
				bridgeDataObject.setPayerWallet(payerWallet);
		
		return bridgeDataObject;
	}
	
	public static BridgeDataObject setBillerDetails(BridgeDataObject bridgeDataObject, CustomerPreferredBiller custPrefBiller) 
	{
		Settings settings = new Settings();
		
		ProvidersData providerData = new ProvidersData();
		CategoryData catgData = new CategoryData();
		
	
		switch(bridgeDataObject.getServiceType()) 
		{
		
		case SETTINGS_MY_BILLER_ADD:
			
			catgData.setCode(custPrefBiller.getBillerCategoryId());
			providerData.setCategory(catgData);
			
			providerData.setProviderCode(custPrefBiller.getBillerId());
			providerData.setName(custPrefBiller.getSubsAccountNickName());
			providerData.setSubscriberId(custPrefBiller.getSubscriberAccountId().toString());
			providerData.setAccountId(EncryptionUtils.stringToHex(com.ng.sb.common.util.CommonUtils.getRandomNumber(2)));
			
			break;
			
		case SETTINGS_MY_BILLER_EDIT:
			
			catgData.setCode(custPrefBiller.getBillerCategoryId());
			providerData.setCategory(catgData);
			
			providerData.setProviderCode(custPrefBiller.getBillerId());
			providerData.setName(custPrefBiller.getSubsAccountNickName());
			providerData.setSubscriberId(custPrefBiller.getSubscriberAccountId().toString());
			providerData.setAccountId(custPrefBiller.getAccountId());
			
			break;
		case SETTINGS_MY_BILLER_DELETE:
				
			providerData.setAccountId(custPrefBiller.getAccountId());
			break;	
		}
		
		settings.setMyBiller(providerData);
		
		bridgeDataObject.setSettings(settings);
				
		
		return bridgeDataObject;
	}
	
	public static BridgeDataObject setBankDetails(BridgeDataObject bridgeData, BankingRequest bankingRequest) 
	{
		BankAccount payerBank = null;
		BankAccount payeeBank = null;
		ProvidersData provider = null; 
		
		switch (bridgeData.getServiceType()) 
		{
			case BANKING_CHECK_BAL:
			case BANKING_CHQ_BOOK_REQUEST:
			case BANKING_CHQ_STATUS:
			case BANKING_STOP_CHEQUE:
			case BANKING_LAST_5_TRANS:
			
				payerBank = new BankAccount();
				
				payerBank.setIfscCode(bankingRequest.getPayerBankAccount().getIfscCode());
				payerBank.setbPin(bankingRequest.getPayerBankAccount().getbPin());
				payerBank.setAccountNumber(bankingRequest.getPayerBankAccount().getAccountNumber());
				payerBank.setsPin(bankingRequest.getPayerBankAccount().getSettingPin());
				
				if(bankingRequest.getPayerBankAccount().getChequeNumber() > 0)
				{
					Cheque cheque = new Cheque();
					cheque.setChequeNumber(bankingRequest.getPayerBankAccount().getChequeNumber());
					
					bridgeData.setCheque(cheque);
				}
				
				break;
			
			case SETTINGS_CREATE_PIN_TRANSACTION:
				
				payerBank = new BankAccount();
				
				payerBank.setIfscCode(bankingRequest.getPayerBankAccount().getIfscCode());
				payerBank.setbPin(EncryptionUtils.hexToString(bankingRequest.getPayerBankAccount().getbPin()));
				payerBank.setAccountNumber(bankingRequest.getPayerBankAccount().getAccountNumber());
				payerBank.setsPin(bankingRequest.getPayerBankAccount().getSettingPin());
				
				break;
				
			case SETTINGS_CHANGE_PIN_TRANSACTION:
				payerBank = new BankAccount();
				
				payerBank.setIfscCode(bankingRequest.getPayerBankAccount().getIfscCode());
				payerBank.setsPin(bankingRequest.getPayerBankAccount().getSettingPin());
				payerBank.setOldBankingPin(EncryptionUtils.hexToString(bankingRequest.getPayerBankAccount().getOldPin()));
				payerBank.setNewBankingPin(EncryptionUtils.hexToString(bankingRequest.getPayerBankAccount().getNewPin()));
				payerBank.setAccountNumber(bankingRequest.getPayerBankAccount().getAccountNumber());
				
				break;
			case BANKING_FT_B_TO_WALLET:
				
				payerBank = new BankAccount();
				
				payerBank.setIfscCode(bankingRequest.getPayerBankAccount().getIfscCode());
				payerBank.setbPin(bankingRequest.getPayerBankAccount().getbPin());
				payerBank.setAccountNumber(bankingRequest.getPayerBankAccount().getAccountNumber());
				
				Wallet payeeWallet = new Wallet();
				
				payeeWallet.setWalletCode(bankingRequest.getPayeeWallet().getWalletCode());
				payeeWallet.setMsisdn(bankingRequest.getPayeeWallet().getMsisdn());
				
				bridgeData.setAmount(bankingRequest.getTxnAmount());
				
				bridgeData.setPayeeWallet(payeeWallet);
				break;
				
			case BANKING_FT_B_TO_B:
				
				payerBank = new BankAccount();
				
				payerBank.setIfscCode(bankingRequest.getPayerBankAccount().getIfscCode());
				payerBank.setbPin(bankingRequest.getPayerBankAccount().getbPin());
				payerBank.setAccountNumber(bankingRequest.getPayerBankAccount().getAccountNumber());
				
				payeeBank = new BankAccount();
				
				payeeBank.setIfscCode(bankingRequest.getPayeeBankAccount().getIfscCode());
				payeeBank.setAccountNumber(bankingRequest.getPayeeBankAccount().getAccountNumber());
				
				bridgeData.setAmount(bankingRequest.getTxnAmount());
				break;
				
			case TOP_UP_RECH_BY_B:
			case BILL_PAY_BY_B:
				
				payerBank = new BankAccount();
				
				payerBank.setIfscCode(bankingRequest.getPayerBankAccount().getIfscCode());
				payerBank.setbPin(EncryptionUtils.hexToString(bankingRequest.getPayerBankAccount().getbPin()));
				payerBank.setAccountNumber(bankingRequest.getPayerBankAccount().getAccountNumber());
				
				provider = new ProvidersData();
				
				provider.setCode(bankingRequest.getProvider().getProviderCode());
				provider.setSubscriberId(bankingRequest.getProvider().getSubscriberId());
				
				bridgeData.setAmount(bankingRequest.getTxnAmount());
				break;
				
			default:
				break;
		}
		
		bridgeData.setPayerBankAccount(payerBank);
		bridgeData.setPayeeBankAccount(payeeBank);
		bridgeData.setProvider(provider);
		return bridgeData;
	}

	public static BridgeDataObject setWalletDetails(BridgeDataObject bridgeData, WalletRequest walletRequest) 
	{
		Wallet payerWallet = null;
		Wallet payeeWallet = null;
		
		ProvidersData provider = null;
		
		switch (bridgeData.getServiceType()) 
		{
			case MWALLET_CUST_CHK_BAL:
			
				payerWallet = new Wallet();
				
				payerWallet.setMsisdn(walletRequest.getPayerWallet().getMsisdn());
				payerWallet.setWalletCode(walletRequest.getPayerWallet().getWalletCode());
				payerWallet.setWalletPin(walletRequest.getPayerWallet().getWalletPin());
				
				break;
				
			case MWALLET_CUST_TOP_UP_ONLINE_B_T_W:
				
				payeeWallet = new Wallet();
				
				payeeWallet.setWalletCode(walletRequest.getPayeeWallet().getWalletCode());
				
				BankAccount payerBank = new BankAccount();
				
				payerBank.setAccountNumber(walletRequest.getPayerBankAccount().getAccountNumber());
				payerBank.setIfscCode(walletRequest.getPayerBankAccount().getIfscCode());
				payerBank.setbPin(walletRequest.getPayerBankAccount().getbPin());
				
				bridgeData.setPayerBankAccount(payerBank);
				bridgeData.setAmount(walletRequest.getAmount());
				break;
				
			case OTH_PAY_INDI_WALLET_TO_B:
				
				payerWallet = new Wallet();
				
				payerWallet.setWalletCode(walletRequest.getPayerWallet().getWalletCode());
				payerWallet.setWalletPin(walletRequest.getPayerWallet().getWalletPin());
				
				BankAccount payeeBank = new BankAccount();
				
				payeeBank.setAccountNumber(walletRequest.getPayeeBankAccount().getAccountNumber());
				payeeBank.setIfscCode(walletRequest.getPayeeBankAccount().getIfscCode());
				
				bridgeData.setPayeeBankAccount(payeeBank);
				bridgeData.setAmount(walletRequest.getAmount());
				
				break;
			
			case OTH_PAY_INDI_WALLET_TO_WALLET:
				
				payerWallet = new Wallet();
				
				payerWallet.setWalletCode(walletRequest.getPayerWallet().getWalletCode());
				payerWallet.setWalletPin(walletRequest.getPayerWallet().getWalletPin());
				
				payeeWallet = new Wallet();
				
				payeeWallet.setWalletCode(walletRequest.getPayeeWallet().getWalletCode());
				payeeWallet.setMsisdn(walletRequest.getPayeeWallet().getMsisdn());
				
				
				bridgeData.setAmount(walletRequest.getAmount());
				
				break;
				
			case SETTINGS_CREATE_PIN_WALLET:
				
				payerWallet = new Wallet();
				
				payerWallet.setMsisdn(walletRequest.getPayerWallet().getMsisdn());
				payerWallet.setWalletCode(walletRequest.getPayerWallet().getWalletCode());
				payerWallet.setWalletPin(walletRequest.getPayerWallet().getWalletPin());
				payerWallet.setsPin(walletRequest.getPayerWallet().getsPin());
				
				break;
				
			case SETTINGS_CHANGE_PIN_WALLET:
	
				payerWallet = new Wallet();
				
				payerWallet.setMsisdn(walletRequest.getPayerWallet().getMsisdn());
				payerWallet.setWalletCode(walletRequest.getPayerWallet().getWalletCode());
				payerWallet.setWalletPin(walletRequest.getPayerWallet().getWalletPin());
				payerWallet.setsPin(walletRequest.getPayerWallet().getsPin());
				payerWallet.setOldWalletPin(walletRequest.getPayerWallet().getOldWalletPin());
				
				break;
	
			case TOP_UP_RECH_BY_WALLET:
			case BILL_PAY_BY_WALLET:
				
				payerWallet = new Wallet();
				
				payerWallet.setWalletCode(walletRequest.getPayerWallet().getWalletCode());
				payerWallet.setWalletPin(walletRequest.getPayerWallet().getWalletPin());
				
				provider = new ProvidersData();
				
				provider.setCode(walletRequest.getProvider().getProviderCode());
				provider.setSubscriberId(walletRequest.getProvider().getSubscriberId());
				
				bridgeData.setAmount(walletRequest.getAmount());
				break;
				
			default:
				break;
		}
		
		bridgeData.setPayerWallet(payerWallet);
		bridgeData.setPayeeWallet(payeeWallet);
		bridgeData.setProvider(provider);
		
		return bridgeData;
	}
	
	public static TransactionData getTransactionData(UserAccountData accountData) 
	{
		TransactionData transactionData = new TransactionData();
		String dateTime=DateTimeUtil.getDateAndTime("dd-MM-yyyy", new Date());
		String transactionId=new TransactionIdGenerator().genTransId();
		String clientRefId=new TransactionIdGenerator().getClientRefId();
		transactionData.setClientReferenceId(clientRefId);
		
		transactionData.setDateTime(dateTime);
		transactionData.setGatewaystatus(true);
		transactionData.setUserIp(null);
		transactionData.setTransactionId(transactionId);
	
		
		transactionData.setMsisdn(accountData.getMobileNo());
		
		return transactionData;
	}
}
