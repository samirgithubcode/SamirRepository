package com.ng.sc.dao.impl;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.ng.sb.common.model.Order;
import com.ng.sb.common.model.Subscriber;

@Repository
public class EntityUtils<T> extends SelfCareDAO {
	/**
	 * 
	 */
	private static final long serialVersionUID = -2928317703266650519L;
	private static final Logger LOGGER = LoggerFactory.getLogger(EntityUtils.class);
	@PersistenceContext
	protected transient EntityManager entityManager;
	/**
	 * 
	 * @param id
	 * @param namedQuery
	 * @param Klass
	 * @return
	 */
	public T getEntityById(Integer id, String namedQuery, Class<T> Klass) {
		T entity = null;
		TypedQuery<T> query = null;
		try {
			LOGGER.info("*********Start Method getEntityById() in EntityUtils ");
			query = entityManager.createNamedQuery(namedQuery, Klass);
			query.setParameter("id", id);
			entity = query.getSingleResult();
		} catch (Exception exp) {
			LOGGER.debug("Exception Occure In method getEntityById() Execution in EntityUtils  "
					+ exp.getLocalizedMessage());
			LOGGER.info(" " + exp);
		}
		return entity;
	}

	
	
	@Transactional
	public T getEntityByParamId(String param,Integer id, String namedQuery, Class<T> Klass) {
		T entity = null;
		TypedQuery<T> query = null;
		try {
			LOGGER.info("*********Start Method getEntityById() in EntityUtils ");
			query = entityManager.createNamedQuery(namedQuery, Klass);
			query.setParameter(param, new Subscriber(id));
			entity = query.getSingleResult();
		} catch (Exception exp) {
			LOGGER.debug("Exception Occure In method getEntityById() Execution in EntityUtils  "
					+ exp.getLocalizedMessage());
			LOGGER.info(" " + exp);
		}
		return entity;
	}
	/**
	 * 
	 * @param id
	 * @param namedQuery
	 * @param Klass
	 * @return
	 */
	public List<T> getEntitiesById(Integer id, String namedQuery, Class<T> Klass) {
		List<T> entities = null;
		TypedQuery<T> query = null;
		try {
			LOGGER.info("*********Start Method getEntityById() in EntityUtils ");
			query = entityManager.createNamedQuery(namedQuery, Klass);
			query.setParameter("id", id);
			entities = query.getResultList();
		} catch (Exception exp) {
			exp.printStackTrace();
			LOGGER.debug("Exception Occure In method getEntityById() Execution in EntityUtils  "
					+ exp.getLocalizedMessage());
			LOGGER.info(" " + exp);
		}
		return entities;
	}

	/**
	 * 
	 * @param t
	 * @return
	 */
	@Transactional
	public T saveEntity(T t) {
		try {
			LOGGER.info("**********Start Method saveEntity() in EntityUtils");
			entityManager.persist(t);
		} catch (Exception ex) {
			LOGGER.info("***Exception Ocure in Method saveEntity() in EntityUtils :" + ex.getLocalizedMessage());
			LOGGER.info("Exception in  saveEntity() in DAO " + ex);
			throw ex;
		}
		return t;
	}
	/**
	 * 
	 * @param subscriberId
	 * @param namedQuery
	 * @param Klass
	 * @return
	 */
	public List<T> getEntityBySubscriberId(Integer subscriberId, String namedQuery, Class<T> Klass) {
		List<T> entities = null;
		TypedQuery<T> query = null;
		try {
			LOGGER.info("**********Start Method getEntityBySubscriberId() in EntityUtils");
			query = entityManager.createNamedQuery(namedQuery, Klass);
			query.setParameter("subscriberId", new Subscriber(subscriberId));
			entities = query.getResultList();
		} catch (Exception ex) {
			LOGGER.info("***Exception Ocure in Method getEntityBySubscriberId() in EntityUtils :" + ex.getLocalizedMessage());
			LOGGER.info("Exception in  getEntityBySubscriberId() in EntityUtils " + ex);
			throw ex;
		}
		return entities;
	}
	/**
	 * 
	 * @param id
	 * @param namedQuery
	 * @param Klass
	 * @return
	 */
	public List<T> getEntityByOrderId(Integer id, String namedQuery, Class<T> Klass) {
		List<T> entity = null;
		TypedQuery<T> query = null;
		try {
			LOGGER.info("*********Start Method getEntityByOrderId() in EntityUtils ");
			query = entityManager.createNamedQuery(namedQuery, Klass);
			query.setParameter("order", new Order(id));
			entity = query.getResultList();
		} catch (Exception exp) {
			exp.printStackTrace();
			LOGGER.debug("Exception Occure In method getEntityByOrderId() Execution in EntityUtils  "
					+ exp.getLocalizedMessage());
			LOGGER.info(" " + exp);
		}
		return entity;
	}
	
	/**
	 * 
	 * @param entityList
	 * @throws Exception
	 * save batch entities
	 */
	@Transactional
	public void saveBatchEntity(List<T> entityList) throws Exception{
		try {
			LOGGER.info("**********Start Method saveBatchEntity() in EntityUtils");
			for (T entity : entityList) {
				entityManager.persist(entity);
			}
		} 
		catch (Exception ex) {
			LOGGER.info("***Exception Ocure in Method saveBatchEntity() in EntityUtils :" + ex.getLocalizedMessage());
			LOGGER.info("Exception in  saveBatchEntity() in DAO " + ex);
			throw ex;
		}
	
	}
	
	/**
	 * 
	 * @param ids
	 * @param namedQuery
	 * @param Klass
	 * @return
	 * where ids in 
	 */
	public List<T> getEntitiesInIds(List<Integer> ids, String namedQuery, Class<T> Klass) {
		List<T> entity = null;
		TypedQuery<T> query = null;
		try {
			LOGGER.info("*********Start Method getEntitiesInIds() in EntityUtils ");
			query = entityManager.createNamedQuery(namedQuery, Klass);
			query.setParameter("id", ids);
			entity = query.getResultList();
		} catch (Exception exp) {
			exp.printStackTrace();
			LOGGER.debug("Exception Occure In method getEntitiesInIds() Execution in EntityUtils  "
					+ exp.getLocalizedMessage());
			LOGGER.info(" " + exp);
		}
		return entity;
	}
	
	/**
	 * 
	 * @param ids
	 * @param namedQuery
	 * @param Klass
	 * @return
	 * get All data from a table.
	 */
	public List<T> getAllEntities(String namedQuery, Class<T> Klass) {
		List<T> entity = null;
		TypedQuery<T> query = null;
		try {
			LOGGER.info("*********Start Method getAllEntities() in EntityUtils ");
			query = entityManager.createNamedQuery(namedQuery, Klass);
			entity = query.getResultList();
		} catch (Exception exp) {
			exp.printStackTrace();
			LOGGER.debug("Exception Occure In method getAllEntities() Execution in EntityUtils  "
					+ exp.getLocalizedMessage());
			LOGGER.info(" " + exp);
		}
		return entity;
	}
	
	/**
	 * 
	 * @param t
	 * @return
	 */
	
	@Transactional
	public T updateEntity(T t) {
		try {
			LOGGER.info("**********Start Method updateEntity() in EntityUtils");
			entityManager.merge(t);
		} catch (Exception ex) {
			LOGGER.info("***Exception Ocure in Method updateEntity() in EntityUtils :" + ex.getLocalizedMessage());
			LOGGER.info("Exception in  updateEntity() in DAO " + ex);
			throw ex;
		}
		return t;
	}
	
	/**
	 * 
	 * @param t
	 * @return
	 */
	@Transactional
	public Boolean updateBatchEntities(List<T> entityList) {
		Boolean updateStaus = false;
		try {
			LOGGER.info("**********Start Method updateBatchEntities() in EntityUtils");
			for (T entity : entityList) {
				entityManager.merge(entity);
			}
			updateStaus=true;
			
		} catch (Exception ex) {
			LOGGER.info("***Exception Ocure in Method updateBatchEntities() in EntityUtils :" + ex.getLocalizedMessage());
			LOGGER.info("Exception in  updateBatchEntities() in DAO " + ex);
			throw ex;
		}
		return updateStaus;
	}
	
	/**
	 * 
	 * @param entityList
	 * @return entities List 
	 * @throws Exception
	 */
	@Transactional
	public List<T> saveBatchEntities(List<T> entityList) throws Exception{
		try {
			LOGGER.info("**********Start Method saveBatchEntities() in EntityUtils");
			for (T entity : entityList) {
				entityManager.persist(entity);
			}
		}
		catch (Exception ex) {
			LOGGER.info("***Exception Ocure in Method saveBatchEntities() in EntityUtils :" + ex.getLocalizedMessage());
			ex.printStackTrace();
			LOGGER.info("Exception in  saveBatchEntities() in DAO " + ex);
			throw ex;
		}
		return entityList;
	}
	public List<T> getAllEntitiesWithinStartDateAndEndDate(String namedQuery, Class<T> Klass,Date startDate,Date endDate) {
		List<T> entity = null;
		TypedQuery<T> query = null;
		try {
			LOGGER.info("*********Start Method getAllEntitiesWithinStartDateAndEndDate() in EntityUtils ");
			query = entityManager.createNamedQuery(namedQuery, Klass);
			query.setParameter("startDate", startDate);
			query.setParameter("endDate", endDate);
			entity = query.getResultList();
		} catch (Exception exp) {
			exp.printStackTrace();
			LOGGER.debug("Exception Occure In method getAllEntitiesWithinStartDateAndEndDate() Execution in EntityUtils  "
					+ exp.getLocalizedMessage());
			LOGGER.info(" " + exp);
		}
		return entity;
	}
	
}
