/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "ticket_query_assignment_info")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "TicketQueryAssignmentInfo.findAll", query = "SELECT t FROM TicketQueryAssignmentInfo t"),
    @NamedQuery(name = "TicketQueryAssignmentInfo.findById", query = "SELECT t FROM TicketQueryAssignmentInfo t WHERE t.id = :id"),
    @NamedQuery(name = "TicketQueryAssignmentInfo.findByTicketId", query = "SELECT t FROM TicketQueryAssignmentInfo t WHERE t.ticketId = :ticketId"),
    @NamedQuery(name = "TicketQueryAssignmentInfo.findByQueryId", query = "SELECT t FROM TicketQueryAssignmentInfo t WHERE t.queryId = :queryId"),
    @NamedQuery(name = "TicketQueryAssignmentInfo.findByUserId", query = "SELECT t FROM TicketQueryAssignmentInfo t WHERE t.userId = :userId"),
    @NamedQuery(name = "TicketQueryAssignmentInfo.findByHostId", query = "SELECT t FROM TicketQueryAssignmentInfo t WHERE t.hostId = :hostId"),
    @NamedQuery(name = "TicketQueryAssignmentInfo.findByTechnicalPersonId", query = "SELECT t FROM TicketQueryAssignmentInfo t WHERE t.technicalPersonId = :technicalPersonId"),
    @NamedQuery(name = "TicketQueryAssignmentInfo.findByAccountTypeId", query = "SELECT t FROM TicketQueryAssignmentInfo t WHERE t.accountTypeId = :accountTypeId"),
    @NamedQuery(name = "TicketQueryAssignmentInfo.findByServicePartnerId", query = "SELECT t FROM TicketQueryAssignmentInfo t WHERE t.servicePartnerId = :servicePartnerId"),
    @NamedQuery(name = "TicketQueryAssignmentInfo.findByServiceProviderId", query = "SELECT t FROM TicketQueryAssignmentInfo t WHERE t.serviceProviderId = :serviceProviderId"),
    @NamedQuery(name = "TicketQueryAssignmentInfo.findBySolutionDetail", query = "SELECT t FROM TicketQueryAssignmentInfo t WHERE t.solutionDetail = :solutionDetail"),
    @NamedQuery(name = "TicketQueryAssignmentInfo.findByQueryStatus", query = "SELECT t FROM TicketQueryAssignmentInfo t WHERE t.queryStatus = :queryStatus"),
    @NamedQuery(name = "TicketQueryAssignmentInfo.findByQueryAssignDate", query = "SELECT t FROM TicketQueryAssignmentInfo t WHERE t.queryAssignDate = :queryAssignDate"),
    @NamedQuery(name = "TicketQueryAssignmentInfo.findByQueryCloseDate", query = "SELECT t FROM TicketQueryAssignmentInfo t WHERE t.queryCloseDate = :queryCloseDate"),
    @NamedQuery(name = "TicketQueryAssignmentInfo.findByAddDate", query = "SELECT t FROM TicketQueryAssignmentInfo t WHERE t.addDate = :addDate"),
    @NamedQuery(name = "TicketQueryAssignmentInfo.findByEditDate", query = "SELECT t FROM TicketQueryAssignmentInfo t WHERE t.editDate = :editDate"),
    @NamedQuery(name = "TicketQueryAssignmentInfo.findByAddByRoleId", query = "SELECT t FROM TicketQueryAssignmentInfo t WHERE t.addByRoleId = :addByRoleId"),
    @NamedQuery(name = "TicketQueryAssignmentInfo.findByEditByRoleId", query = "SELECT t FROM TicketQueryAssignmentInfo t WHERE t.editByRoleId = :editByRoleId")})
public class TicketQueryAssignmentInfo implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
    @Basic(optional = false)
    @Column(name = "ticket_id", nullable = false, length = 20)
    private String ticketId;
    @Basic(optional = false)
    @Column(name = "query_id", nullable = false)
    private int queryId;
    @Basic(optional = false)
    @Column(name = "user_id", nullable = false)
    private int userId;
    @Basic(optional = false)
    @Column(name = "host_id", nullable = false)
    private int hostId;
    @Basic(optional = false)
    @Column(name = "technical_person_id", nullable = false)
    private int technicalPersonId;
    @Basic(optional = false)
    @Column(name = "account_type_id", nullable = false)
    private int accountTypeId;
    @Column(name = "service_partner_id")
    private Integer servicePartnerId;
    @Column(name = "service_provider_id")
    private Integer serviceProviderId;
    @Column(name = "solution_detail", length = 200)
    private String solutionDetail;
    @Basic(optional = false)
    @Column(name = "query_status", nullable = false, length = 20)
    private String queryStatus;
    @Basic(optional = false)
    @Column(name = "query_assign_date", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date queryAssignDate;
    
    @Basic(optional = false)
    @Column(name = "add_date", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date addDate;
    @Column(name = "query_close_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date queryCloseDate;
    
    @Column(name = "edit_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date editDate;
   
    @Column(name = "edit_by_role_id")
    private Integer editByRoleId;
    
    @Basic(optional = false)
    @Column(name = "add_by_role_id", nullable = false)
    private int addByRoleId;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "queryAssignInfoId")
    private Collection<TicketQueryAssignmentHistory> ticketQueryAssignmentHistoryCollection;

    public TicketQueryAssignmentInfo() {
    	//default constructor
    }

    public TicketQueryAssignmentInfo(Integer id) {
        this.id = id;
    }

    public TicketQueryAssignmentInfo(Integer id, String ticketId, int queryId, int userId, int hostId, int technicalPersonId, int accountTypeId) {
        this.id = id;
        this.ticketId = ticketId;
        this.queryId = queryId;
        this.userId = userId;
        this.hostId = hostId;
        this.technicalPersonId = technicalPersonId;
        this.accountTypeId = accountTypeId;
       
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTicketId() {
        return ticketId;
    }

    public void setTicketId(String ticketId) {
        this.ticketId = ticketId;
    }

    public int getQueryId() {
        return queryId;
    }

    public void setQueryId(int queryId) {
        this.queryId = queryId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getHostId() {
        return hostId;
    }

    public void setHostId(int hostId) {
        this.hostId = hostId;
    }

    public int getTechnicalPersonId() {
        return technicalPersonId;
    }

    public void setTechnicalPersonId(int technicalPersonId) {
        this.technicalPersonId = technicalPersonId;
    }

    public int getAccountTypeId() {
        return accountTypeId;
    }

    public void setAccountTypeId(int accountTypeId) {
        this.accountTypeId = accountTypeId;
    }

    public Integer getServicePartnerId() {
        return servicePartnerId;
    }

    public void setServicePartnerId(Integer servicePartnerId) {
        this.servicePartnerId = servicePartnerId;
    }

    public Integer getServiceProviderId() {
        return serviceProviderId;
    }

    public void setServiceProviderId(Integer serviceProviderId) {
        this.serviceProviderId = serviceProviderId;
    }

    

    public String getQueryStatus() {
        return queryStatus;
    }

    public void setQueryStatus(String queryStatus) {
        this.queryStatus = queryStatus;
    }

    public String getSolutionDetail() {
        return solutionDetail;
    }

    public void setSolutionDetail(String solutionDetail) {
        this.solutionDetail = solutionDetail;
    }
    
    public Date getQueryAssignDate() {
        return queryAssignDate;
    }

    public void setQueryAssignDate(Date queryAssignDate) {
        this.queryAssignDate = queryAssignDate;
    }

   

    public Date getAddDate() {
        return addDate;
    }

    public void setAddDate(Date addDate) {
        this.addDate = addDate;
    }

    public Date getQueryCloseDate() {
        return queryCloseDate;
    }

    public void setQueryCloseDate(Date queryCloseDate) {
        this.queryCloseDate = queryCloseDate;
    }
    public Date getEditDate() {
        return editDate;
    }

    public void setEditDate(Date editDate) {
        this.editDate = editDate;
    }

   

    public Integer getEditByRoleId() {
        return editByRoleId;
    }

    public void setEditByRoleId(Integer editByRoleId) {
        this.editByRoleId = editByRoleId;
    }

    public int getAddByRoleId() {
        return addByRoleId;
    }

    public void setAddByRoleId(int addByRoleId) {
        this.addByRoleId = addByRoleId;
    }
    
    @XmlTransient
    public Collection<TicketQueryAssignmentHistory> getTicketQueryAssignmentHistoryCollection() {
        return ticketQueryAssignmentHistoryCollection;
    }

    public void setTicketQueryAssignmentHistoryCollection(Collection<TicketQueryAssignmentHistory> ticketQueryAssignmentHistoryCollection) {
        this.ticketQueryAssignmentHistoryCollection = ticketQueryAssignmentHistoryCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof TicketQueryAssignmentInfo)) {
            return false;
        }
        TicketQueryAssignmentInfo other = (TicketQueryAssignmentInfo) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.TicketQueryAssignmentInfo[ id=" + id + " ]";
    }
    
}
