package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.*;



/**
 * @author abhishek
 *
 */
@Entity
@Table(name="OTACustomer")
@NamedQuery(name="OTACustomer.findAll", query="SELECT o FROM OTACustomer o")
public class OTACustomer implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false)
	private Integer id;

	@Column(name="msgType")
	private String msgType;

	@Column(name="status")
	private String status;

	@Column(name="message")
	private String message;
	
	@ManyToOne
	@JoinColumn(name="subscriberId")
	private Subscriber subscriberId;

	//bi-directional many-to-one association to OTAManagement
	@ManyToOne
	@JoinColumn(name="otaMgmtId")
	private OTAManagement otaMgmtId;

	//bi-directional many-to-one association to OTAWalletMapping
	@ManyToOne
	@JoinColumn(name="otaWalletMappingId")
	private OTAWalletMapping otaWalletMappingId;

	//bi-directional many-to-one association to HostSVLongCodeHistory
	@ManyToOne
	@JoinColumn(name="hsvLCHistoryId")
	private HostSVLongCodeHistory hsvLCHistoryId;

	//bi-directional many-to-one association to HostSVWalletHistory
	@ManyToOne
	@JoinColumn(name="hsvWHistoryId")
	private HostSVWalletHistory hsvWHistoryId;

	public OTACustomer() {
		//empty
	}
	
	public OTACustomer(Integer id) {
		this.id = id;
	}
	
	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getMsgType() {
		return this.msgType;
	}

	public void setMsgType(String msgType) {
		this.msgType = msgType;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Subscriber getSubscriberId() {
		return this.subscriberId;
	}

	public void setSubscriberId(Subscriber subscriberId) {
		this.subscriberId = subscriberId;
	}

	public OTAManagement getOtaMgmtId() {
		return this.otaMgmtId;
	}

	public void setOtaMgmtId(OTAManagement otaMgmtId) {
		this.otaMgmtId = otaMgmtId;
	}

	public OTAWalletMapping getOtaWalletMappingId() {
		return this.otaWalletMappingId;
	}

	public void setOtaWalletMappingId(OTAWalletMapping otaWalletMappingId) {
		this.otaWalletMappingId = otaWalletMappingId;
	}

	public HostSVLongCodeHistory getHsvLCHistoryId() {
		return this.hsvLCHistoryId;
	}

	public void setHsvLCHistoryId(HostSVLongCodeHistory hsvLCHistoryId) {
		this.hsvLCHistoryId = hsvLCHistoryId;
	}

	public HostSVWalletHistory getHsvWHistoryId() {
		return this.hsvWHistoryId;
	}

	public void setHsvWHistoryId(HostSVWalletHistory hsvWHistoryId) {
		this.hsvWHistoryId = hsvWHistoryId;
	}
	
	@Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

	
	
	

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof OTACustomer)) {
            return false;
        }
        OTACustomer other = (OTACustomer) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }
    
    @Override
	public String toString() {
		return "OTACustomer [id=" + id + "]";
	}
}