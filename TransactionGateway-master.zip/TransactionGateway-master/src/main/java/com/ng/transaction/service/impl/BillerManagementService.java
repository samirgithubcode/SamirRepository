/**
 * 
 */
package com.ng.transaction.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.ng.sb.common.dataobject.BridgeDataObject;
import com.ng.sb.common.util.SystemConstant;
import com.ng.transaction.service.IBillerManagementService;

/**
 * @author gaurav
 *
 */
@Service(value=SystemConstant.BILLER_MGT_SERVICE)
public class BillerManagementService extends FundTransferMgtService implements IBillerManagementService {

	private static final Logger LOGGER = LoggerFactory.getLogger(BillerManagementService.class);
	@Override
	public BridgeDataObject fundTransferToBillerByBank(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction BillerManagementService -  fundTransferToBillerByBank method. ");
		return invokeBridge(bridgeDataObject);
	}

	@Override
	public BridgeDataObject fundTransferToBillerByCC(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction BillerManagementService -  fundTransferToBillerByCC method. ");
		return invokeBridge(bridgeDataObject);
	}

	@Override
	public BridgeDataObject fundTransferToBillerByIMPS(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction BillerManagementService -  fundTransferToBillerByIMPS method. ");
		return invokeBridge(bridgeDataObject);
	}

	@Override
	public BridgeDataObject fundTransferToBillerByWallet(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction BillerManagementService -  fundTransferToBillerByWallet method. ");
		return invokeBridge(bridgeDataObject);
	}

	@Override
	public BridgeDataObject fundTransferToBillerByRI(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction BillerManagementService -  fundTransferToBillerByRI method. ");
		return invokeBridge(bridgeDataObject);
	}

	@Override
	public BridgeDataObject topUpRechargeByWallet(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction BillerManagementService -  topUpDTHRechargeByWallet method. ");
		return invokeBridge(bridgeDataObject);
	}
	
	@Override
	public BridgeDataObject topUpRechargeByCC(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction BillerManagementService -  topUpRechargeByCC method. ");
		return invokeBridge(bridgeDataObject);
	}
	
	@Override
	public BridgeDataObject topUpRechargeByIMPS(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction BillerManagementService -  topUpRechargeByIMPS method. ");
		return invokeBridge(bridgeDataObject);
	}
	
	@Override
	public BridgeDataObject topUpRechargeByBank(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction BillerManagementService -  topUpRechargeByBank method. ");
		return invokeBridge(bridgeDataObject);
	}

	


}
