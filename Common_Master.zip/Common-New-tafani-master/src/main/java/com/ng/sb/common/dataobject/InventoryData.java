package com.ng.sb.common.dataobject;

import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;



/**
 * @author amardeep
 *
 */
public class InventoryData  extends BaseObjectData
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	//***********************Pojo For CustomerInventory Form********************
	private String simVersionNum;
	private String simFormat;
	private String startRange;
	private String numOfSim;
	private String numOfSimWithRfid;
	private String hidSimSerialNumber;
	private String simInternalSerialNum;
	private String simExternalSerialNum;
	private String rfidExternalSerialNum;
	private String rfidReaderExternalSerialNum;
	private String checkResult;
	private Integer simPukCode;
	private Integer pukCounter;
	private String disabledFieldName;
	private Integer hidAccuntTypeId;	
	private String resultMessage;
	private String view;
	private String simInventory;
	private String singleRecord;
	private String bulkUpload;
	private String singleRecord12;
	private String bulkUpload23;
	private String simWithRFIDInventory;
	private String rfidVersionNumber;
	private String rfidStartRange;
	private String hidRFIDSerialNum;
	private String numOfRFID;
	private String rfidReaderVersionNumber;
	private String rfidReaderStartRange;
	private String labelDescription;
	private String numOfRFIDReader;
	private String rfidReaderTagType;
	private String hidRFIDReaderSerialNum;
	private String rfidBigReaderVer;
	private String rfidSmallReaderVer;
	private String labelLoginAs;
	private String labelhost;
	private String labelDistributor;
	private String labelSubDistributor;
	private String labelRetailer;
	private String labelBC;
	private String labelVersionNum;
	private String labelTotalUnits;
	private String labelSoldUnits;
	private String labelStatusType;
	private String labelSimType;
	private String hidReaderSerialNum;
	private String numofSIMWithReader;
	private transient Map simVersionMap;
	private transient Map simFormatMap;
	private transient Map simRFIDMap;
	private transient Map rfidReaderMap;
	private transient MultipartFile labelUpload;
	private String hidStkmenuid;
	private String readerExternalSerialNum;
	private transient MultipartFile uploadBulkData;
	private String sellingDate;
	private String currentStatus;
	private String status;
	private String acountType;
	private String sellerName;
	private String hostName;
	private Integer soldCount;
	private Integer accountGroupId;
	private String company;
	private String labelEncryptionkey;
	private String simOrientation;
	private List<String> simOrientationss;
	private String imageLocation;
	
	private Integer inventoryStatus;
	//*********************** Methods ********************
	
	
	public Integer getInventoryStatus() {
		return inventoryStatus;
	}
	public void setInventoryStatus(Integer inventoryStatus) {
		this.inventoryStatus = inventoryStatus;
	}
	public String getImageLocation() {
		return imageLocation;
	}
	public void setImageLocation(String imageLocation) {
		this.imageLocation = imageLocation;
	}
	public List<String> getSimOrientationss() {
		return simOrientationss;
	}
	public void setSimOrientationss(List<String> simOrientationss) {
		this.simOrientationss = simOrientationss;
	}
	public String getSimOrientation() {
		return simOrientation;
	}
	public void setSimOrientation(String simOrientation) {
		this.simOrientation = simOrientation;
	}
	public String getLabelEncryptionkey() {
		return labelEncryptionkey;
	}
	public void setLabelEncryptionkey(String labelEncryptionkey) {
		this.labelEncryptionkey = labelEncryptionkey;
	}
	public Integer getUserId() {
		return id;
	}
	public void setUserId(Integer id) {
		this.id = id;
	}
	public Integer getAccountGroupId() {
		return accountGroupId;
	}
	public void setAccountGroupId(Integer accountGroupId) {
		this.accountGroupId = accountGroupId;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public Integer getSoldCount() {
		return soldCount;
	}
	public void setSoldCount(Integer soldCount) {
		this.soldCount = soldCount;
	}
	public String getHostName() {
		return hostName;
	}
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}
	public String getSellerName() {
		return sellerName;
	}
	public void setSellerName(String sellerName) {
		this.sellerName = sellerName;
	}
	public String getAcountType() {
		return acountType;
	}
	public void setAcountType(String acountType) {
		this.acountType = acountType;
	}
	public String getSellingDate() {
		return sellingDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getCurrentStatus() {
		return currentStatus;
	}
	public void setCurrentStatus(String currentStatus) {
		this.currentStatus = currentStatus;
	}
	public void setSellingDate(String sellingDate) {
		this.sellingDate = sellingDate;
	}
	public String getLabelSimType() {
		return labelSimType;
	}
	public void setLabelSimType(String labelSimType) {
		this.labelSimType = labelSimType;
	}
	public String getLabelHost() {
		return labelhost;
	}
	public void setLabelHost(String labelHost) {
		this.labelhost = labelHost;
	}
	public String getLabelTotalUnits() {
		return labelTotalUnits;
	}
	public void setLabelTotalUnits(String labelTotalUnits) {
		this.labelTotalUnits = labelTotalUnits;
	}
	public String getLabelSoldUnits() {
		return labelSoldUnits;
	}
	public void setLabelSoldUnits(String labelSoldUnits) {
		this.labelSoldUnits = labelSoldUnits;
	}
	public String getLabelStatusType() {
		return labelStatusType;
	}
	public void setLabelStatusType(String labelStatusType) {
		this.labelStatusType = labelStatusType;
	}
	public String getLabelVersionNum() {
		return labelVersionNum;
	}
	public void setLabelVersionNum(String labelVersionNum) {
		this.labelVersionNum = labelVersionNum;
	}
	public String getLabelDistributor() {
		return labelDistributor;
	}
	public void setLabelDistributor(String labelDistributor) {
		this.labelDistributor = labelDistributor;
	}
	public String getLabelSubDistributor() {
		return labelSubDistributor;
	}
	public void setLabelSubDistributor(String labelSubDistributor) {
		this.labelSubDistributor = labelSubDistributor;
	}
	public String getLabelRetailer() {
		return labelRetailer;
	}
	public void setLabelRetailer(String labelRetailer) {
		this.labelRetailer = labelRetailer;
	}
	public String getLabelBC() {
		return labelBC;
	}
	public void setLabelBC(String labelBC) {
		this.labelBC = labelBC;
	}
	public String getLabelLoginAs() {
		return labelLoginAs;
	}
	public void setLabelLoginAs(String labelLoginAs) {
		this.labelLoginAs = labelLoginAs;
	}
	public String getRfidReaderExternalSerialNum() {
		return rfidReaderExternalSerialNum;
	}
	public void setRfidReaderExternalSerialNum(String rfidReaderExternalSerialNum) {
		this.rfidReaderExternalSerialNum = rfidReaderExternalSerialNum;
	}
	public String getBulkUpload() {
		return bulkUpload;
	}
	public void setBulkUpload(String bulkUpload) {
		this.bulkUpload = bulkUpload;
	}
	public String getSingleRecord() {
		return singleRecord;
	}
	public void setSingleRecord(String singleRecord) {
		this.singleRecord = singleRecord;
	}
	public String getLabelDescription() {
		return labelDescription;
	}
	public void setLabelDescription(String labelDescription) {
		this.labelDescription = labelDescription;
	}
	public String getRfidExternalSerialNum() {
		return rfidExternalSerialNum;
	}
	public void setRfidExternalSerialNum(String rfidExternalSerialNum) {
		this.rfidExternalSerialNum = rfidExternalSerialNum;
	}
	public String getCheckResult() {
		return checkResult;
	}
	public void setCheckResult(String checkResult) {
		this.checkResult = checkResult;
	}
	public Integer getHidAccuntTypeId() {
		return hidAccuntTypeId;
	}
	public void setHidAccuntTypeId(Integer hidAccuntTypeId) {
		this.hidAccuntTypeId = hidAccuntTypeId;
	}
	public String getDisabledFieldName() {
		return disabledFieldName;
	}
	public void setDisabledFieldName(String disabledFieldName) {
		this.disabledFieldName = disabledFieldName;
	}
	public MultipartFile getLabelUpload() {
		return labelUpload;
	}
	public void setLabelUpload(MultipartFile labelUpload) {
		this.labelUpload = labelUpload;
	}
	
	public String getHidStkmenuid() {
		return hidStkmenuid;
	}
	public void setHidStkmenuid(String hidStkmenuid) {
		this.hidStkmenuid = hidStkmenuid;
	}
	
	public String getSimVersionNum() {
		return simVersionNum;
	}
	public void setSimVersionNum(String simVersionNum) {
		this.simVersionNum = simVersionNum;
	}
	public String getSimFormat() {
		return simFormat;
	}
	public void setSimFormat(String simFormat) {
		this.simFormat = simFormat;
	}
	public String getStartRange() {
		return startRange;
	}
	public void setStartRange(String startRange) {
		this.startRange = startRange;
	}
	public String getNumOfSim() {
		return numOfSim;
	}
	public void setNumOfSim(String numOfSim) {
		this.numOfSim = numOfSim;
	}
	public String getNumOfSimWithRfid() {
		return numOfSimWithRfid;
	}
	public void setNumOfSimWithRfid(String numOfSimWithRfid) {
		this.numOfSimWithRfid = numOfSimWithRfid;
	}
	public String getHidSimSerialNumber() {
		return hidSimSerialNumber;
	}
	public void setHidSimSerialNumber(String hidSimSerialNumber) {
		this.hidSimSerialNumber = hidSimSerialNumber;
	}
	public String getSimInternalSerialNum() {
		return simInternalSerialNum;
	}
	public void setSimInternalSerialNum(String simInternalSerialNum) {
		this.simInternalSerialNum = simInternalSerialNum;
	}
	public String getSimExternalSerialNum() {
		return simExternalSerialNum;
	}
	public void setSimExternalSerialNum(String simExternalSerialNum) {
		this.simExternalSerialNum = simExternalSerialNum;
	}
	public Integer getSimPukCode() {
		return simPukCode;
	}
	public void setSimPukCode(Integer simPukCode) {
		this.simPukCode = simPukCode;
	}
	public Integer getPukCounter() {
		return pukCounter;
	}
	public void setPukCounter(Integer pukCounter) {
		this.pukCounter = pukCounter;
	}
	public String getResultMessage() {
		return resultMessage;
	}
	public void setResultMessage(String resultMessage) {
		this.resultMessage = resultMessage;
	}
	public String getView() {
		return view;
	}
	public void setView(String view) {
		this.view = view;
	}
	public String getSimInventory() {
		return simInventory;
	}
	public void setSimInventory(String simInventory) {
		this.simInventory = simInventory;
	}
	public String getSingleRecord12() {
		return singleRecord12;
	}
	public void setSingleRecord12(String singleRecord) {
		this.singleRecord12 = singleRecord;
	}
	public String getBulkUpload23() {
		return bulkUpload23;
	}
	public void setBulkUpload23(String bulkUpload) {
		this.bulkUpload23 = bulkUpload;
	}
	public String getSimWithRFIDInventory() {
		return simWithRFIDInventory;
	}
	public void setSimWithRFIDInventory(String simWithRFIDInventory) {
		this.simWithRFIDInventory = simWithRFIDInventory;
	}
	public String getRfidVersionNumber() {
		return rfidVersionNumber;
	}
	public void setRfidVersionNumber(String rfidVersionNumber) {
		this.rfidVersionNumber = rfidVersionNumber;
	}
	public String getRfidStartRange() {
		return rfidStartRange;
	}
	public void setRfidStartRange(String rfidStartRange) {
		this.rfidStartRange = rfidStartRange;
	}
	public String getHidRFIDSerialNum() {
		return hidRFIDSerialNum;
	}
	public void setHidRFIDSerialNum(String hidRFIDSerialNum) {
		this.hidRFIDSerialNum = hidRFIDSerialNum;
	}
	public String getNumOfRFID() {
		return numOfRFID;
	}
	public void setNumOfRFID(String numOfRFID) {
		this.numOfRFID = numOfRFID;
	}
	public String getRfidReaderVersionNumber() {
		return rfidReaderVersionNumber;
	}
	public void setRfidReaderVersionNumber(String rfidReaderVersionNumber) {
		this.rfidReaderVersionNumber = rfidReaderVersionNumber;
	}
	public String getRfidReaderStartRange() {
		return rfidReaderStartRange;
	}
	public void setRfidReaderStartRange(String rfidReaderStartRange) {
		this.rfidReaderStartRange = rfidReaderStartRange;
	}
	public String getNumOfRFIDReader() {
		return numOfRFIDReader;
	}
	public void setNumOfRFIDReader(String numOfRFIDReader) {
		this.numOfRFIDReader = numOfRFIDReader;
	}
	public String getRfidReaderTagType() {
		return rfidReaderTagType;
	}
	public void setRfidReaderTagType(String rfidReaderTagType) {
		this.rfidReaderTagType = rfidReaderTagType;
	}
	public String getHidRFIDReaderSerialNum() {
		return hidRFIDReaderSerialNum;
	}
	public void setHidRFIDReaderSerialNum(String hidRFIDReaderSerialNum) {
		this.hidRFIDReaderSerialNum = hidRFIDReaderSerialNum;
	}
	public String getRfidBigReaderVer() {
		return rfidBigReaderVer;
	}
	public void setRfidBigReaderVer(String rfidBigReaderVer) {
		this.rfidBigReaderVer = rfidBigReaderVer;
	}
	public String getRfidSmallReaderVer() {
		return rfidSmallReaderVer;
	}
	public void setRfidSmallReaderVer(String rfidSmallReaderVer) {
		this.rfidSmallReaderVer = rfidSmallReaderVer;
	}
	public String getHidReaderSerialNum() {
		return hidReaderSerialNum;
	}
	public void setHidReaderSerialNum(String hidReaderSerialNum) {
		this.hidReaderSerialNum = hidReaderSerialNum;
	}
	public String getNumofSIMWithReader() {
		return numofSIMWithReader;
	}
	public void setNumofSIMWithReader(String numofSIMWithReader) {
		this.numofSIMWithReader = numofSIMWithReader;
	}
	public Map getSimVersionMap() {
		return simVersionMap;
	}
	public void setSimVersionMap(Map simVersionMap) {
		this.simVersionMap = simVersionMap;
	}
	public Map getSimFormatMap() {
		return simFormatMap;
	}
	public void setSimFormatMap(Map simFormatMap) {
		this.simFormatMap = simFormatMap;
	}
	public Map getSimRFIDMap() {
		return simRFIDMap;
	}
	public void setSimRFIDMap(Map simRFIDMap) {
		this.simRFIDMap = simRFIDMap;
	}
	public Map getRfidReaderMap() {
		return rfidReaderMap;
	}
	public void setRfidReaderMap(Map rfidReaderMap) {
		this.rfidReaderMap = rfidReaderMap;
	}
	public String getReaderExternalSerialNum() {
		return readerExternalSerialNum;
	}
	public void setReaderExternalSerialNum(String readerExternalSerialNum) {
		this.readerExternalSerialNum = readerExternalSerialNum;
	}
	public MultipartFile getUploadBulkData() {
		return uploadBulkData;
	}
	public void setUploadBulkData(MultipartFile uploadBulkData) {
		this.uploadBulkData = uploadBulkData;
	}
	
	
}
