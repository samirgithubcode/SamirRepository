/**
 * 
 */
package com.ng.bridge.service.impl;

import java.lang.reflect.InvocationTargetException;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.ng.bridge.service.IPartnerManagementService;
import com.ng.bridge.util.NewConstants;
import com.ng.sb.common.dataobject.BridgeDataObject;
import com.ng.sb.common.dataobject.BridgeDataResponse.Status;
import com.ng.sb.common.dataobject.IConstants;
import com.ng.sb.common.dataobject.InstrumentData.Sequence;
import com.ng.sb.common.dataobject.PartnerData;
import com.ng.sb.common.dataobject.SelectedPartnerData;
import com.ng.sb.common.exception.BridgeObjectDataException;
import com.ng.sb.common.util.SystemConstant;

/**
 * @author gaurav
 *
 */
@Service("partnerManagementService")
public class PartnerManagementService implements IPartnerManagementService {

	private static final Logger LOGGER = LoggerFactory.getLogger(PartnerManagementService.class);
	@Override
	public BridgeDataObject partnerExecution(BridgeDataObject bridgeDataObject) throws BridgeObjectDataException {
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge PartnerManagementService -  partnerExecution method. ",NewConstants.TRANSACTIONID);
			BridgeDataObject response=new BridgeDataObject() ;
			Map<Integer,SelectedPartnerData> partnerObject = PartnerRetrievalService.getInstance().getPartners(bridgeDataObject);
			
			boolean itrationRequired = true;
			
				for(int i=1;i<=partnerObject.size() && itrationRequired ;i++){
					SelectedPartnerData partnerData = partnerObject.get(i);
					switch (partnerData.getCallingSeqType()) {
					case SystemConstant.SEQ_RI_FSP:
						response = getRegInstrumentFSPServiceCall(bridgeDataObject,partnerData);
						if(response!=null){
							break;
						}
						break;
					case SystemConstant.SEQ_FSP:
						response = getFSPServiceCall(bridgeDataObject,partnerData);
						if(getResult(response)){
							itrationRequired = false;
							LOGGER.info("Got Success from Direct FSP Services. So no need to call other Buckets." +bridgeDataObject.getTransactionData().getTransactionId());
							break; // No Other Bucket will get called.
						}
						break;
					case SystemConstant.SEQ_TWO_CALLS:
						response = getDirectInstrumentCall(bridgeDataObject,partnerData);
						if(getResult(response)){
							LOGGER.info(" Got Success from Direct Instruments/Providers Combination. So no need to call other Buckets. "+ bridgeDataObject.getTransactionData().getTransactionId() );
							break; // No Other Bucket will get called.
						}
						break;
					default:
						break;
					}
				}
			return response;
	}
	public boolean getResult(BridgeDataObject response){
		boolean condition =false;
		if(response.getBridgeResponse()!=null && (response.getBridgeResponse().getStatus()==Status.SUCCESS || response.getBridgeResponse().getStatus()==Status.PENDING)){
			condition=true;
		}
		return condition;
		
	}
	private BridgeDataObject getRegInstrumentFSPServiceCall(BridgeDataObject bridgeDataObject,SelectedPartnerData partnerData){
		boolean condition=false;
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge PartnerManagementService -  getRegInstrumentFSPServiceCall method. ",NewConstants.TRANSACTIONID);
		if(partnerData!=null && partnerData.getRegInstFspPartnerSequence()!=null && partnerData.getRegInstFspPartnerSequence().getPartnerMap()!=null){
			condition=true;
		}
		
		if( condition && !partnerData.getRegInstFspPartnerSequence().getPartnerMap().isEmpty()){
			Map<Integer, PartnerData> partnerMap = partnerData.getRegInstFspPartnerSequence().getPartnerMap();
			for(int i=1;i<=partnerMap.size();i++){
				PartnerData partnerDataCall = partnerMap.get(i);
				bridgeDataObject.setCallablePartner(partnerDataCall);
				BridgeDataObject response=null;
				try {
					response = ServiceInvoker.getInstance().invoke(partnerDataCall.getMappingName(), bridgeDataObject,IConstants.METHOD_RI_FSP);
				} catch (IllegalArgumentException  e) {
					LOGGER.info(""+e);
				}
				if(response!=null){
					return response;
				}
			}
		}
		return null;
	}
	
	private BridgeDataObject getFSPServiceCall(BridgeDataObject bridgeDataObject,SelectedPartnerData partnerData){
		boolean condition1=false;
		if(bridgeDataObject!=null && partnerData!=null && partnerData.getFspPartnerSequence()!=null && partnerData.getFspPartnerSequence().getPartnerMap()!=null){
			condition1=true;
		}
		if(bridgeDataObject!=null && bridgeDataObject.getTransactionData().getTransactionId()!=null){
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge PartnerManagementService -  getFSPServiceCall method. ",NewConstants.TRANSACTIONID);
		}
		if(condition1 && !partnerData.getFspPartnerSequence().getPartnerMap().isEmpty()){
			Map<Integer, PartnerData> partnerMap = partnerData.getFspPartnerSequence().getPartnerMap();
			executePartner(bridgeDataObject, partnerMap,IConstants.METHOD_FSP);
		}
		return bridgeDataObject;
	}
	
	private boolean executePartner(BridgeDataObject bridgeDataObject,Map<Integer, PartnerData> partnerMap,String methodCallType){
		for(int i=1;i<=partnerMap.size();i++){
			PartnerData partnerDataCall = partnerMap.get(i);
			bridgeDataObject.setCallablePartner(partnerDataCall);
			BridgeDataObject response=null;
			try {
				LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " Going to call Partner ## " + partnerDataCall.getMappingName(),NewConstants.TRANSACTIONID);
				response = ServiceInvoker.getInstance().invoke(partnerDataCall.getMappingName(), bridgeDataObject,methodCallType);
			} catch (IllegalArgumentException e) {
				LOGGER.info(""+e);
			}
			if(response!=null && response.getBridgeResponse()!=null && (response.getBridgeResponse().getStatus()==Status.SUCCESS || response.getBridgeResponse().getStatus()==Status.PENDING)){
				return true;
			}else if(response!=null && response.getBridgeResponse()!=null && (response.getBridgeResponse().getStatus()==Status.FAILED)){
				return false;
			}else if(response==null){// Means Didn't get the Implementation
				return true;
			}
		}
		return false;
	}
	
	private boolean getFirstInstrumentCall(BridgeDataObject bridgeDataObject,Map<Integer, PartnerData> partnersMap,String methodCallType){
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge PartnerManagementService -  getFirstInstrumentCall method. ",NewConstants.TRANSACTIONID);
		if( partnersMap!=null){
			return executePartner(bridgeDataObject, partnersMap,methodCallType);
		}
		return false;
	}
	
	private boolean getSecondInstrumentCall(BridgeDataObject bridgeDataObject,Map<Integer, PartnerData> partnersMap,String methodCallType){
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge PartnerManagementService -  getSecondInstrumentCall method. ",NewConstants.TRANSACTIONID);
		if( partnersMap!=null){
			return executePartner(bridgeDataObject, partnersMap,methodCallType);
		}
		return false;
	}
	
	private BridgeDataObject getDirectInstrumentCall(BridgeDataObject bridgeDataObject,SelectedPartnerData partnerData){
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge PartnerManagementService -  getDirectInstrumentCall method. ",NewConstants.TRANSACTIONID);
		boolean condition1=false;
		boolean condition2=false;
		boolean condition3=false;
		boolean condition4=false;
		if(partnerData!=null && partnerData.getDirectPartnerMap()!=null){
			condition1=true;
		}
		if( partnerData!=null && partnerData.getDirectPartnerMap().get(Sequence.FIRST)!=null 	&& partnerData.getDirectPartnerMap().get(Sequence.FIRST).getPartnerMap()!=null && !partnerData.getDirectPartnerMap().get(Sequence.FIRST).getPartnerMap().isEmpty()){
			condition2=true;
		}
		if(partnerData!=null && partnerData.getDirectPartnerMap().get(Sequence.SECOND)!=null 	&& partnerData.getDirectPartnerMap().get(Sequence.SECOND).getPartnerMap()!=null && !partnerData.getDirectPartnerMap().get(Sequence.SECOND).getPartnerMap().isEmpty()){
			condition3=true;
		}
		if(partnerData!=null && getFirstInstrumentCall(bridgeDataObject, partnerData.getDirectPartnerMap().get(Sequence.FIRST).getPartnerMap(),IConstants.METHOD_FIRST_CALL)){
			condition4=true;
		}
		if(condition1 && condition2 && condition3 && condition4){
				getSecondInstrumentCall(bridgeDataObject, partnerData.getDirectPartnerMap().get(Sequence.SECOND).getPartnerMap(),IConstants.METHOD_SECOND_CALL);
		
		}
		return bridgeDataObject;
	}

}
