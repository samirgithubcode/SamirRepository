/**
 * 
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * @author gopal
 *
 */
@Entity
@Table(name = "internal_accounts_master")
@NamedQueries({
    @NamedQuery(name = "InternalAccountMaster.findByAccountType", query = "SELECT cd FROM InternalAccountMaster cd WHERE cd.accountType=:accountType "),
    @NamedQuery(name = "InternalAccountMaster.findByAccountTypeNumber", query = "SELECT iam FROM InternalAccountMaster iam WHERE iam.accountStatus='ACTIVE' AND iam.accountType=:accountType AND iam.accountNumber=:accountNumber"),
    @NamedQuery(name = "InternalAccountMaster.findByAccountNumber", query = "SELECT cd FROM InternalAccountMaster cd WHERE cd.accountNumber=:accountNumber AND cd.accountType=:tradingWallet"),
    @NamedQuery(name = "InternalAccountMaster.findByAccountNumbernType", query = "SELECT cd FROM InternalAccountMaster cd WHERE cd.accountNumber=:accountNumber and cd.accountType=:accountType"),
    @NamedQuery(name = "InternalAccountMaster.findAll", query = "SELECT cd FROM InternalAccountMaster cd ORDER BY cd.updatedOn DESC "),
    @NamedQuery(name = "InternalAccountMaster.findAllByDate", query = "SELECT cd FROM InternalAccountMaster cd where cd.startDate>=:startDate AND cd.startDate<=:endDate ORDER BY cd.updatedOn DESC "),
})
public class InternalAccountMaster implements Serializable {
    
	private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    
    @Column(name="ACCOUNT_TYPE")
	private String accountType;
    
    @Column(name="ACCOUNT_NUMBER")
   	private Long accountNumber;
    
    @Column(name="STATUS")
   	private String accountStatus;
    
    @Column(name="START_DATE")
   	private Date startDate;
    
    @Column(name="END_DATE")
   	private Date endDate;
    
    @Column(name = "UPDATED_TS")
	private Date updatedOn;
    
    @Column(name = "ACCOUNT_BALANCE")
	private Double accountBalance;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public Long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountStatus() {
		return accountStatus;
	}

	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	public Double getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(Double accountBalance) {
		this.accountBalance = accountBalance;
	}
	
}