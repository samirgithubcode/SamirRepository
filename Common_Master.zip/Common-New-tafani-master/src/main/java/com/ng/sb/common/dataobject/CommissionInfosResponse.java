package com.ng.sb.common.dataobject;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;


public class CommissionInfosResponse implements ValidationBean{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5164736180283870698L;

	@JsonProperty(value = "txntype")
	private String txnType;
	
	@JsonIgnore
	private String commCode;
	
	@JsonIgnore
	private String commId;
	
	@JsonIgnore
	private String subsCode;
	
	@JsonIgnore
	private String hostCommission;
	
	@JsonIgnore
	private String distributorCommission;
	
	@JsonIgnore
	private String subDistributorCommission;
	
	@JsonIgnore
	private String agentCommission;
	
	@JsonIgnore
	private String bankCommission;
	
	@JsonProperty(value = "commission")
	private String totalCommission;
	
	@JsonProperty(value = "source")
	private String commissionDeductedFrom;
	
	@JsonProperty(value = "commissiontype")
	private String commissionType;
	
	public String getTxnType() {
		return txnType;
	}
	
	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}
	
	public String getCommCode() {
		return commCode;
	}
	
	public void setCommCode(String commCode) {
		this.commCode = commCode;
	}
	
	public String getCommId() {
		return commId;
	}

	public void setCommId(String commId) {
		this.commId = commId;
	}

	public String getSubsCode() {
		return subsCode;
	}

	public void setSubsCode(String subsCode) {
		this.subsCode = subsCode;
	}

	public String getHostCommission() {
		return hostCommission;
	}
	
	public void setHostCommission(String hostCommission) {
		this.hostCommission = hostCommission;
	}
	
	public String getDistributorCommission() {
		return distributorCommission;
	}
	
	public void setDistributorCommission(String distributorCommission) {
		this.distributorCommission = distributorCommission;
	}
	
	public String getSubDistributorCommission() {
		return subDistributorCommission;
	}
	
	public void setSubDistributorCommission(String subDistributorCommission) {
		this.subDistributorCommission = subDistributorCommission;
	}
	
	public String getAgentCommission() {
		return agentCommission;
	}
	
	public void setAgentCommission(String agentCommission) {
		this.agentCommission = agentCommission;
	}
	
	public String getBankCommission() {
		return bankCommission;
	}
	
	public void setBankCommission(String bankCommission) {
		this.bankCommission = bankCommission;
	}
	
	public String getTotalCommission() {
		return totalCommission;
	}
	
	public void setTotalCommission(String totalCommission) {
		this.totalCommission = totalCommission;
	}
	
	public String getCommissionDeductedFrom() {
		return commissionDeductedFrom;
	}
	
	public void setCommissionDeductedFrom(String commissionDeductedFrom) {
		this.commissionDeductedFrom = commissionDeductedFrom;
	}

	public String getCommissionType() {
		return commissionType;
	}

	public void setCommissionType(String commissionType) {
		this.commissionType = commissionType;
	}

	@Override
	public String toString() {
		return "CommissionInfosResponse [txnType=" + txnType + ", commCode="
				+ commCode + ", subsCode=" + subsCode + ", hostCommission="
				+ hostCommission + ", distributorCommission="
				+ distributorCommission + ", subDistributorCommission="
				+ subDistributorCommission + ", agentCommission="
				+ agentCommission + ", bankCommission=" + bankCommission
				+ ", totalCommission=" + totalCommission
				+ ", commissionDeductedFrom=" + commissionDeductedFrom
				+ ", commissionType=" + commissionType + "]";
	}

}
