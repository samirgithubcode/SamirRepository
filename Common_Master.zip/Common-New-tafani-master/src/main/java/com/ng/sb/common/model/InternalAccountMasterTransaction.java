/**
 * 
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

/**
 * @author gopal
 *
 */
@Entity
@Table(name = "internal_accounts_master_transaction")
@NamedQueries({
    @NamedQuery(name = "InternalAccountMasterTransaction.findByAccountType", query = "SELECT cd FROM InternalAccountMasterTransaction cd WHERE cd.accountType=:accountType "),
    @NamedQuery(name = "InternalAccountMasterTransaction.findByAccountNumber", query = "SELECT cd FROM InternalAccountMasterTransaction cd WHERE cd.accountNumber=:accountNumber "),
    @NamedQuery(name = "InternalAccountMasterTransaction.findAll", query = "SELECT cd FROM InternalAccountMasterTransaction cd ORDER BY cd.entryDate DESC"),
    @NamedQuery(name = "InternalAccountMasterTransaction.findAllByDate", query = "SELECT cd FROM InternalAccountMasterTransaction cd where  cd.entryDate>=:startDate AND cd.entryDate<=:endDate ORDER BY cd.entryDate DESC"),
    @NamedQuery(name = "InternalAccountMasterTransaction.findUserTxnByDate", query = "SELECT cd FROM InternalAccountMasterTransaction cd where  DATE(cd.entryDate)>=:startDate AND DATE(cd.entryDate)<=:endDate AND cd.companyId=:companyId ORDER BY cd.entryDate DESC")  
    
})
public class InternalAccountMasterTransaction implements Serializable {
    
	private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    
    @Column(name="ACCOUNT_TYPE")
	private String accountType;
    
    @Column(name="ACCOUNT_NUMBER")
   	private Long accountNumber;
    
    @Column(name = "OPENING_BALANCE")
	private Double openingBalance;
    
    @Column(name = "AMOUNT")
	private Double amount;
    
    @Column(name = "CLOSING_BALANCE")
	private Double closingBalance;
    
    @Column(name="TXN_NATURE")
   	private String txnNature;
    
    @Column(name="ENTRY_DATE")
   	private Date entryDate;
    
    @JoinColumn(name = "TXN_ID", referencedColumnName = "id")
    @ManyToOne(fetch=FetchType.LAZY)
    @Fetch(FetchMode.SELECT)
    private ProductTransactions txnId;
    
    @Column(name="TXN_TYPE")
   	private String txnType;
    
    @Column(name = "SUBSCRIBER_ID")
    private Integer subscriberId;
    
    @Column(name = "COMPANY_ID")
    private Integer companyId;
    
    @Column(name="COMPANY_USER")
   	private String companyUser;
    @Column(name="COMMENT")
   	private String comment;
    
    @Column(name="POSTED_ON")
   	private Date postedOn;
    @Column(name="POSTING_STATUS")
   	private String postingStatus;
    @Column(name="REF_TXN_ID")
   	private String refTxnID;
    @Column(name="REQUEST")
   	private String request;
    
    @Column(name="RESPONSE")
   	private String response;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public Long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public Double getOpeningBalance() {
		return openingBalance;
	}

	public void setOpeningBalance(Double openingBalance) {
		this.openingBalance = openingBalance;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public Double getClosingBalance() {
		return closingBalance;
	}

	public void setClosingBalance(Double closingBalance) {
		this.closingBalance = closingBalance;
	}

	public String getTxnNature() {
		return txnNature;
	}

	public void setTxnNature(String txnNature) {
		this.txnNature = txnNature;
	}

	public Date getEntryDate() {
		return entryDate;
	}

	public void setEntryDate(Date entryDate) {
		this.entryDate = entryDate;
	}

	public ProductTransactions getTxnId() {
		return txnId;
	}

	public void setTxnId(ProductTransactions txnId) {
		this.txnId = txnId;
	}

	public String getTxnType() {
		return txnType;
	}

	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}

	public Integer getSubscriberId() {
		return subscriberId;
	}

	public void setSubscriberId(Integer subscriberId) {
		this.subscriberId = subscriberId;
	}

	public Integer getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}

	public String getCompanyUser() {
		return companyUser;
	}

	public void setCompanyUser(String companyUser) {
		this.companyUser = companyUser;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public Date getPostedOn() {
		return postedOn;
	}

	public void setPostedOn(Date postedOn) {
		this.postedOn = postedOn;
	}

	public String getPostingStatus() {
		return postingStatus;
	}

	public void setPostingStatus(String postingStatus) {
		this.postingStatus = postingStatus;
	}

	public String getRefTxnID() {
		return refTxnID;
	}

	public void setRefTxnID(String refTxnID) {
		this.refTxnID = refTxnID;
	}

	public String getRequest() {
		return request;
	}

	public void setRequest(String request) {
		this.request = request;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}
    
}