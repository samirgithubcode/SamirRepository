package com.ng.sb.common.dataobject;
import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author
 *
 */
@JsonIgnoreProperties
public class PgStringRequestObject  implements ValidationBean{
	private static final long serialVersionUID = 1399593624627585064L;
	private String refTrxnId;
	private String trxamount;
	private String trxDate;
	
	/**
	 * @return the refTrxnId
	 */
	public String getRefTrxnId() {
		return refTrxnId;
	}
	/**
	 * @param refTrxnId the refTrxnId to set
	 */
	public void setRefTrxnId(String refTrxnId) {
		this.refTrxnId = refTrxnId;
	}
	public String getTrxamount() {
		return trxamount;
	}
	public void setTrxamount(String trxamount) {
		this.trxamount = trxamount;
	}
	public String getTrxDate() {
		return trxDate;
	}
	public void setTrxDate(String trxDate) {
		this.trxDate = trxDate;
	}
	public String getTrxDesc() {
		return trxDesc;
	}
	public void setTrxDesc(String trxDesc) {
		this.trxDesc = trxDesc;
	}
	public String getImgsrc() {
		return imgsrc;
	}
	public void setImgsrc(String imgsrc) {
		this.imgsrc = imgsrc;
	}
	private String trxDesc;
	private String imgsrc;
	
		
			
	
}
