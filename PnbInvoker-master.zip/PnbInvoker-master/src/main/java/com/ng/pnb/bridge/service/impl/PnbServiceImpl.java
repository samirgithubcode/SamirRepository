/**
 * 
 */
package com.ng.pnb.bridge.service.impl;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Map;

import javax.transaction.Transactional;

import org.jpos.iso.ISOException;
import org.jpos.iso.ISOMsg;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ng.pnb.bridge.dao.impl.IPNBDao;
import com.ng.pnb.bridge.invoker.PNBUtility;
import com.ng.pnb.bridge.iso.IISOMessageCreator;
import com.ng.pnb.bridge.iso.IISOMessageParser;
import com.ng.pnb.bridge.service.ITransactionService;
import com.ng.pnb.bridge.service.ISocketService;
import com.ng.pnb.invoker.util.PnbConstants;
import com.ng.sb.common.dataobject.BankAccount;
import com.ng.sb.common.dataobject.BridgeDataObject;
import com.ng.sb.common.dataobject.BridgeDataObject.ServiceType;
import com.ng.sb.common.dataobject.BridgeDataResponse;
import com.ng.sb.common.dataobject.BridgeDataResponse.Status;
import com.ng.sb.common.dataobject.HostSubVersionData.ProviderRelation;
import com.ng.sb.common.dataobject.ProvidersData;
import com.ng.sb.common.dataobject.ResponseObject;
import com.ng.sb.common.exception.BankingException;
import com.ng.sb.common.model.CustomerDetails;
import com.ng.sb.common.model.CustomerPreferredBiller;
import com.ng.sb.common.model.CustomerWallets;
import com.ng.sb.common.model.InternalAccountMaster;
import com.ng.sb.common.model.OverlayMerchants;
import com.ng.sb.common.model.PayeeDetails;
import com.ng.sb.common.model.PoolAccount;
import com.ng.sb.common.model.Subscriber;
import com.ng.sb.common.util.EncryptionUtils;
import com.ng.sb.common.util.ErrorCodes;
import com.ng.sb.common.util.SystemConstant;

/**
 * @author gopal
 *
 */
@Service("pnbService")
public class PnbServiceImpl implements ITransactionService {
	
	@Autowired
	IPNBDao pnbDao;

	@Autowired
	IISOMessageCreator isoMessageCreator;
	
	@Autowired
	ISocketService socketService;
	
	@Autowired
	IISOMessageParser isoMessageParser;
	
	@Autowired
	PNBUtility pnbUtility;
	
	@Override
	public BridgeDataResponse processRequest(BridgeDataObject bridgeDataObject) 
	{
		BridgeDataResponse response = null;
		
		//Processing Fund Transfer Bank To Bank
		    if(bridgeDataObject.getServiceType() == ServiceType.SETTINGS_CREATE_PIN_TRANSACTION)
			{
		    	response = processBankTransactionPinCreation(bridgeDataObject);
				
			}else if(bridgeDataObject.getServiceType() == ServiceType.SETTINGS_CHANGE_PIN_TRANSACTION)
			{
				response = processBankTransactionPinChange(bridgeDataObject);
				
			}else if(bridgeDataObject.getServiceType() == ServiceType.BANKING_FT_B_TO_B || bridgeDataObject.getServiceType()==ServiceType.MWALLET_AG_TOP_UP_ACCOUNT_B_T_B || bridgeDataObject.getServiceType()==ServiceType.OTH_PAY_RET_B_TO_B || bridgeDataObject.getServiceType()==ServiceType.OTH_PAY_INDI_B_TO_B)
			{
				response = processFundTransferBankToBank(bridgeDataObject);
		      
			}else if(bridgeDataObject.getServiceType() == ServiceType.BANKING_FT_B_TO_WALLET || bridgeDataObject.getServiceType() == ServiceType.MWALLET_AG_TOP_UP_ONLINE_B_T_W || bridgeDataObject.getServiceType()==ServiceType.MWALLET_AG_TOP_UP_ACCOUNT_B_T_W||  bridgeDataObject.getServiceType()==ServiceType.MWALLET_CUST_TOP_UP_ONLINE_B_T_W|| bridgeDataObject.getServiceType()==ServiceType.OTH_PAY_RET_B_TO_WALLET ||  bridgeDataObject.getServiceType()==ServiceType.OTH_PAY_INDI_B_TO_WALLET)
			{
				response = processFundTransferBankToWallet(bridgeDataObject);
				
			}else if(bridgeDataObject.getServiceType()==ServiceType.OTH_PAY_RET_WALLET_TO_B ||  bridgeDataObject.getServiceType()==ServiceType.OTH_PAY_INDI_WALLET_TO_B)
			{
				response = processFundTransferWalletToBank(bridgeDataObject);
				
			}else if(bridgeDataObject.getServiceType() == ServiceType.BILL_PAY_BY_B || bridgeDataObject.getServiceType() == ServiceType.TOP_UP_RECH_BY_B)
			{
				response = processUtilityPaymentsFromBank(bridgeDataObject);
				
			}else if(bridgeDataObject.getServiceType() == ServiceType.BILL_PAY_BY_WALLET || bridgeDataObject.getServiceType() == ServiceType.TOP_UP_RECH_BY_WALLET)
			{
				response = processUtilityPaymentsFromWallet(bridgeDataObject);
				
			}else if(bridgeDataObject.getServiceType()==ServiceType.MWALLET_AG_TOP_UP_ONLINE_W_T_W || bridgeDataObject.getServiceType()==ServiceType.MWALLET_CUST_CASH_OUT_WALLET || bridgeDataObject.getServiceType()==ServiceType.OTH_PAY_RET_WALLET_TO_WALLET || bridgeDataObject.getServiceType()==ServiceType.OTH_PAY_INDI_WALLET_TO_WALLET)
			{
				response = processPaymentWalletToWallet(bridgeDataObject);
				
			}else if(bridgeDataObject.getServiceType()==ServiceType.BANKING_LAST_5_TRANS)
			{
				response = processBankingTxnHistory(bridgeDataObject);
				
			}else if(bridgeDataObject.getServiceType()==ServiceType.MWALLET_AG_CHK_BAL || bridgeDataObject.getServiceType()==ServiceType.MWALLET_CUST_CHK_BAL)
			{
				response = processWalletBalanceCheck(bridgeDataObject);
				
			}else if(bridgeDataObject.getServiceType()==ServiceType.BANKING_CHECK_BAL)
			{
				response = processBankBalanceCheck(bridgeDataObject);
				
			}else if(bridgeDataObject.getServiceType()==ServiceType.BANKING_FT_UPI_TO_UPI)
			{
				// TODO: UPI TO UPI FT
				
//				response = processBankBalanceCheck(bridgeDataObject);
				
			}else if(bridgeDataObject.getServiceType()==ServiceType.BANKING_CHQ_BOOK_REQUEST || bridgeDataObject.getServiceType()==ServiceType.BANKING_CHQ_STATUS || bridgeDataObject.getServiceType()==ServiceType.BANKING_STOP_CHEQUE)
			{
				response = processChequeStatus(bridgeDataObject);
				
			}else if(bridgeDataObject.getServiceType() == ServiceType.SETTINGS_MY_PAYEE_ADD || bridgeDataObject.getServiceType()==ServiceType.SETTINGS_MY_PAYEE_EDIT || bridgeDataObject.getServiceType()==ServiceType.SETTINGS_MY_PAYEE_DELETE)
			{
				response = processPayeeManagement(bridgeDataObject);
				
			}else if(bridgeDataObject.getServiceType() == ServiceType.SETTINGS_MY_MERCHANT_ADD || bridgeDataObject.getServiceType()==ServiceType.SETTINGS_MY_MERCHANT_EDIT || bridgeDataObject.getServiceType()==ServiceType.SETTINGS_MY_MERCHANT_DELETE)
			{
				response = processMerchantManagement(bridgeDataObject);
				
			}
			else if(bridgeDataObject.getServiceType() == ServiceType.SETTINGS_MY_BILLER_ADD || bridgeDataObject.getServiceType()==ServiceType.SETTINGS_MY_BILLER_EDIT || bridgeDataObject.getServiceType()==ServiceType.SETTINGS_MY_BILLER_DELETE)
			{
				response = processBillerManagement(bridgeDataObject);
			}
		
		    if(response != null)
		    	response.setMsidnToSendMsg(bridgeDataObject.getTransactionData().getMsisdn());
		    
		    bridgeDataObject.setBridgeResponse(response);
		
		return null;
	}

	private BridgeDataResponse processPaymentWalletToWallet(BridgeDataObject bridgeDataObject) 
	{
		BridgeDataResponse response = new BridgeDataResponse();
		
		try{
			
			boolean verifiedCustomer = verifyCustomerByWalletPin(bridgeDataObject);
			
			if(verifiedCustomer)
			{
				
				ISOMsg responseMsg = socketService.writeOnSocket(bridgeDataObject.getTransactionData().getTransactionId(), isoMessageCreator.createWalletFundTransfer(bridgeDataObject));
				
				if(responseMsg != null)
				{
					Map<Integer,String> isoMap = isoMessageParser.parseMessage(bridgeDataObject.getTransactionData().getTransactionId(), responseMsg);
					
					if(isoMap != null && !isoMap.isEmpty() && Integer.parseInt(isoMap.get(39)) == 0)
					{
						pnbUtility.createWalletFundTransferFSPResponse(bridgeDataObject, isoMap);
					
						response = bridgeDataObject.getBridgeResponse();
						
						return response;
						
					}else{
						pnbUtility.createErrorResponse(bridgeDataObject);
						response = bridgeDataObject.getBridgeResponse();
						response.setStatus(Status.FAILED);
						
						return response;
					}
				}else{
					pnbUtility.createErrorResponse(bridgeDataObject);
					
					response = bridgeDataObject.getBridgeResponse();
					response.setStatus(Status.FAILED);
					
					return response;
				}
			}else{
					
					pnbUtility.createErrorResponse(bridgeDataObject, "Invalid Wallet Pin.");
					
					response = bridgeDataObject.getBridgeResponse();
					response.setStatus(Status.FAILED);
					
					return response;
				}
		}catch(IOException | ISOException | BankingException e)
		{
			if(e instanceof BankingException)
				pnbUtility.createErrorResponse(bridgeDataObject, e.getMessage());
			else
				pnbUtility.createErrorResponse(bridgeDataObject);
			
			response = bridgeDataObject.getBridgeResponse();
			response.setStatus(Status.FAILED);
			
			return response;
		}
	}

	@Transactional
	private BridgeDataResponse processPayeeManagement(BridgeDataObject bridgeDataObject) 
	{
		BridgeDataResponse response = new BridgeDataResponse();
		try
		{
			Subscriber customerDetails = pnbDao.getSubscriberDetails(bridgeDataObject.getTransactionData().getMsisdn());
			
			if(customerDetails == null)
			{
				pnbUtility.createErrorResponse(bridgeDataObject, PnbConstants.INVALID_CUSTOMER);
				
				response = bridgeDataObject.getBridgeResponse();
				response.setStatus(Status.SUCCESS);
				
				return response;
			}
			
			/**
			 *  Some process to verify Setting PIN
			 */
			
			if(bridgeDataObject.getServiceType() == ServiceType.SETTINGS_MY_PAYEE_ADD)
			{
				PayeeDetails payee = new PayeeDetails();
				
				payee.setCustomerId(customerDetails.getCustId());
				payee.setCustomerMsisdn(Long.parseLong(customerDetails.getMsisdn()));
				payee.setAccountId(EncryptionUtils.hexToString(bridgeDataObject.getPayerBankAccount().getAccountId()));
				payee.setPayeeNickName(bridgeDataObject.getPayerBankAccount().getName());
				payee.setAccountName(bridgeDataObject.getPayerBankAccount().getAccountName());
				payee.setAccountNumber(Long.parseLong(bridgeDataObject.getPayerBankAccount().getAccountNumber()));
				payee.setIfscCode(bridgeDataObject.getPayerBankAccount().getIfscCode());
				payee.setAccountMmid(bridgeDataObject.getPayerBankAccount().getMmid());
				payee.setPayeeMobileNumber(bridgeDataObject.getPayerWallet().getMerchantId());
				payee.setWalletTypeId(bridgeDataObject.getPayerWallet().getWalletCode());
				payee.setWalletNumber(Long.parseLong(bridgeDataObject.getPayerWallet().getMsisdn()));
				payee.setAddedOn(new Date());
				
				pnbDao.saveEntity(payee);
				
				pnbUtility.createErrorResponse(bridgeDataObject, PnbConstants.PAYEE_ADDED_SUCCESSFUL);
				
				response = bridgeDataObject.getBridgeResponse();
				response.setStatus(Status.SUCCESS);
				
			}else if(bridgeDataObject.getServiceType() == ServiceType.SETTINGS_MY_PAYEE_EDIT)
			{
				
				PayeeDetails payee = pnbDao.getPayeeByAccountId(EncryptionUtils.hexToString(bridgeDataObject.getPayerBankAccount().getAccountId()));
				
				if(payee != null)
				{
					payee.setCustomerId(customerDetails.getCustId());
					payee.setCustomerMsisdn(Long.parseLong(customerDetails.getMsisdn()));
					payee.setPayeeNickName(bridgeDataObject.getPayerBankAccount().getName());
					payee.setAccountName(bridgeDataObject.getPayerBankAccount().getAccountName());
					payee.setAccountNumber(Long.parseLong(bridgeDataObject.getPayerBankAccount().getAccountNumber()));
					payee.setIfscCode(bridgeDataObject.getPayerBankAccount().getIfscCode());
					payee.setAccountMmid(bridgeDataObject.getPayerBankAccount().getMmid());
					payee.setPayeeMobileNumber(bridgeDataObject.getPayerWallet().getMerchantId());
					payee.setWalletTypeId(bridgeDataObject.getPayerWallet().getWalletCode());
					payee.setWalletNumber(Long.parseLong(bridgeDataObject.getPayerWallet().getMsisdn()));
					payee.setModifiedOn(new Date());
					
					pnbDao.updateEntity(payee);
					
					pnbUtility.createErrorResponse(bridgeDataObject, PnbConstants.PAYEE_ADDED_SUCCESSFUL);
					
					response = bridgeDataObject.getBridgeResponse();
					response.setStatus(Status.SUCCESS);
					
				}else{
					
					pnbUtility.createErrorResponse(bridgeDataObject, PnbConstants.INVALID_PAYEE);
					
					response = bridgeDataObject.getBridgeResponse();
					response.setStatus(Status.SUCCESS);
				}
			}else if(bridgeDataObject.getServiceType() == ServiceType.SETTINGS_MY_PAYEE_DELETE)
			{
				PayeeDetails payee = pnbDao.getPayeeByAccountId(EncryptionUtils.hexToString(bridgeDataObject.getPayerBankAccount().getAccountId()));
						
						if(payee != null)
						{
							boolean status = pnbDao.deleteEntity(payee);
							
							if(status)
							{
							pnbUtility.createErrorResponse(bridgeDataObject, "Payee deleted successfully.");
							}else{
								pnbUtility.createErrorResponse(bridgeDataObject, "Request failed to delete Payee.");
							}
							
							response = bridgeDataObject.getBridgeResponse();
							response.setStatus(Status.SUCCESS);
						
						}else{
							pnbUtility.createErrorResponse(bridgeDataObject, PnbConstants.INVALID_PAYEE);
							
							response = bridgeDataObject.getBridgeResponse();
							response.setStatus(Status.SUCCESS);
						}
			}
		}catch(Exception e)
		{
			pnbUtility.createErrorResponse(bridgeDataObject);
			
			response = bridgeDataObject.getBridgeResponse();
			response.setStatus(Status.FAILED);
			
			return response;
		}
		
		return response;
	}

	@Transactional
	private BridgeDataResponse processMerchantManagement(BridgeDataObject bridgeDataObject) 
	{
		BridgeDataResponse response = new BridgeDataResponse();
		try
		{
			Subscriber customerDetails = pnbDao.getSubscriberDetails(bridgeDataObject.getTransactionData().getMsisdn());
			
			if(customerDetails == null)
			{
				pnbUtility.createErrorResponse(bridgeDataObject, PnbConstants.INVALID_CUSTOMER);
				
				response = bridgeDataObject.getBridgeResponse();
				response.setStatus(Status.SUCCESS);
				
				return response;
			}
			
			/**
			 *  Some process to verify Setting PIN
			 */
			
			if(bridgeDataObject.getServiceType() == ServiceType.SETTINGS_MY_MERCHANT_ADD)
			{
				OverlayMerchants merchant = new OverlayMerchants();
				
				merchant.setCustomerId(customerDetails.getCustId());
				merchant.setCustomerMsisdn(Long.parseLong(customerDetails.getMsisdn()));
				merchant.setAccountId(EncryptionUtils.hexToString(bridgeDataObject.getPayerBankAccount().getAccountId()));
				merchant.setMerchantNickName(bridgeDataObject.getPayerBankAccount().getAccountNickName());
				merchant.setBharatQrCode(bridgeDataObject.getPayerBankAccount().getBharatQrCode());
				merchant.setMerchantId(new BigDecimal(bridgeDataObject.getPayerWallet().getMerchantId()));
				merchant.setAccountNumber(Long.parseLong(bridgeDataObject.getPayerBankAccount().getAccountNumber()));
				merchant.setIfscCode(bridgeDataObject.getPayerBankAccount().getIfscCode());
				merchant.setAccountMmid(bridgeDataObject.getPayerBankAccount().getMmid());
				merchant.setMerchantMsisdn(bridgeDataObject.getPayerWallet().getMsisdn());
				merchant.setWalletTypeId(bridgeDataObject.getPayerWallet().getWalletCode());
				merchant.setWalletNumber(Long.parseLong(bridgeDataObject.getPayerWallet().getMsisdn()));
				merchant.setAddedOn(new Date());
				
				pnbDao.saveEntity(merchant);
				
				pnbUtility.createErrorResponse(bridgeDataObject, PnbConstants.MERCHANT_ADDED_SUCCESSFUL);
				
				response = bridgeDataObject.getBridgeResponse();
				response.setStatus(Status.SUCCESS);
				
			}else if(bridgeDataObject.getServiceType() == ServiceType.SETTINGS_MY_MERCHANT_EDIT)
			{
				OverlayMerchants merchant = pnbDao.getMerchantByAccountId(EncryptionUtils.hexToString(bridgeDataObject.getPayerBankAccount().getAccountId()));
				
				if(merchant != null)
				{
					merchant.setCustomerId(customerDetails.getCustId());
					merchant.setCustomerMsisdn(Long.parseLong(customerDetails.getMsisdn()));
					merchant.setMerchantNickName(bridgeDataObject.getPayerBankAccount().getAccountNickName());
					merchant.setMerchantId(new BigDecimal(bridgeDataObject.getPayerWallet().getMerchantId()));
					merchant.setBharatQrCode(bridgeDataObject.getPayerBankAccount().getBharatQrCode());
					merchant.setAccountNumber(Long.parseLong(bridgeDataObject.getPayerBankAccount().getAccountNumber()));
					merchant.setIfscCode(bridgeDataObject.getPayerBankAccount().getIfscCode());
					merchant.setAccountMmid(bridgeDataObject.getPayerBankAccount().getMmid());
					merchant.setMerchantMsisdn(bridgeDataObject.getPayerWallet().getMsisdn());
					merchant.setWalletTypeId(bridgeDataObject.getPayerWallet().getWalletCode());
					merchant.setWalletNumber(Long.parseLong(bridgeDataObject.getPayerWallet().getMsisdn()));
					merchant.setModifiedOn(new Date());
					
					pnbDao.updateEntity(merchant);
					
					pnbUtility.createErrorResponse(bridgeDataObject, PnbConstants.MERCHANT_ADDED_SUCCESSFUL);
					
					response = bridgeDataObject.getBridgeResponse();
					response.setStatus(Status.SUCCESS);
				}else{
					pnbUtility.createErrorResponse(bridgeDataObject, PnbConstants.INVALID_MERCHANT);
					
					response = bridgeDataObject.getBridgeResponse();
					response.setStatus(Status.SUCCESS);
				}
			}else if(bridgeDataObject.getServiceType() == ServiceType.SETTINGS_MY_MERCHANT_DELETE)
			{
				OverlayMerchants merchant = pnbDao.getMerchantByAccountId(EncryptionUtils.hexToString(bridgeDataObject.getPayerBankAccount().getAccountId()));
				
				if(merchant != null)
				{
					boolean status = pnbDao.deleteEntity(merchant);
					
					if(status)
					{
					pnbUtility.createErrorResponse(bridgeDataObject, "Merchant deleted successfully.");
					}else{
						pnbUtility.createErrorResponse(bridgeDataObject, "Request failed to delete Merchant.");
					}
					
					response = bridgeDataObject.getBridgeResponse();
					response.setStatus(Status.SUCCESS);
				
				}else{
					pnbUtility.createErrorResponse(bridgeDataObject, PnbConstants.INVALID_MERCHANT);
					
					response = bridgeDataObject.getBridgeResponse();
					response.setStatus(Status.SUCCESS);
				}
			}
			
		}catch(Exception e)
		{
			pnbUtility.createErrorResponse(bridgeDataObject);
			
			response = bridgeDataObject.getBridgeResponse();
			response.setStatus(Status.FAILED);
			
			return response;
		}
		
		return response;
	}
	
	@Transactional
	private BridgeDataResponse processBillerManagement(BridgeDataObject bridgeDataObject) 
	{
		BridgeDataResponse response = new BridgeDataResponse();
		try
		{
			Subscriber customerDetails = pnbDao.getSubscriberDetails(bridgeDataObject.getTransactionData().getMsisdn());
			
			if(customerDetails == null)
			{
				pnbUtility.createErrorResponse(bridgeDataObject, PnbConstants.INVALID_CUSTOMER);
				
				response = bridgeDataObject.getBridgeResponse();
				response.setStatus(Status.SUCCESS);
				
				return response;
			}
			
			/**
			 *  Some process to verify Setting PIN
			 */
			
			if(bridgeDataObject.getServiceType() == ServiceType.SETTINGS_MY_BILLER_ADD)
			{
				
				CustomerPreferredBiller biller = new CustomerPreferredBiller();
				
				biller.setAccountId(EncryptionUtils.hexToString(bridgeDataObject.getSettings().getMyBiller().getAccountId()));
				biller.setAddedOn(new Date());
				biller.setBillerCategoryId(bridgeDataObject.getSettings().getMyBiller().getCategory().getCode());
				biller.setBillerId(bridgeDataObject.getSettings().getMyBiller().getProviderCode());
				biller.setCustomerId(customerDetails.getCustId());
				biller.setCustomerMsisdn(Long.parseLong(customerDetails.getMsisdn()));
				biller.setStatus("1");
				biller.setSubsAccountNickName(bridgeDataObject.getSettings().getMyBiller().getName());
				biller.setSubscriberAccountId(Long.parseLong(bridgeDataObject.getSettings().getMyBiller().getSubscriberId()));
				
				pnbDao.saveEntity(biller);
				
				pnbUtility.createErrorResponse(bridgeDataObject, PnbConstants.BILLER_ADDED_SUCCESSFUL);
				
				response = bridgeDataObject.getBridgeResponse();
				response.setStatus(Status.SUCCESS);
				
			}else if(bridgeDataObject.getServiceType() == ServiceType.SETTINGS_MY_BILLER_EDIT)
			{
				CustomerPreferredBiller biller = pnbDao.getCustomerBillerByAccountId(EncryptionUtils.hexToString(bridgeDataObject.getSettings().getMyBiller().getAccountId()), customerDetails.getCustId());
				
				if(biller != null)
				{
					biller.setModifiedOn(new Date());
					biller.setBillerCategoryId(bridgeDataObject.getSettings().getMyBiller().getCategory().getCode());
					biller.setBillerId(bridgeDataObject.getSettings().getMyBiller().getProviderCode());
					biller.setCustomerId(customerDetails.getCustId());
					biller.setCustomerMsisdn(Long.parseLong(customerDetails.getMsisdn()));
					biller.setStatus("1");
					biller.setSubsAccountNickName(bridgeDataObject.getSettings().getMyBiller().getName());
					biller.setSubscriberAccountId(Long.parseLong(bridgeDataObject.getSettings().getMyBiller().getSubscriberId()));
					
					pnbDao.updateEntity(biller);
					
					pnbUtility.createErrorResponse(bridgeDataObject, PnbConstants.BILLER_EDITED_SUCCESSFUL);
					
					response = bridgeDataObject.getBridgeResponse();
					response.setStatus(Status.SUCCESS);
				}else{
					pnbUtility.createErrorResponse(bridgeDataObject, PnbConstants.INVALID_BILLER);
					
					response = bridgeDataObject.getBridgeResponse();
					response.setStatus(Status.SUCCESS);
				}
			}else if(bridgeDataObject.getServiceType() == ServiceType.SETTINGS_MY_BILLER_DELETE)
			{
				CustomerPreferredBiller biller = pnbDao.getCustomerBillerByAccountId(EncryptionUtils.hexToString(bridgeDataObject.getSettings().getMyBiller().getAccountId()), customerDetails.getCustId());
				
				if(biller != null)
				{
					boolean status = pnbDao.deleteEntity(biller);
					
					if(status)
					{
					pnbUtility.createErrorResponse(bridgeDataObject, PnbConstants.BILLER_DELETED_SUCCESSFUL);
					}else{
						pnbUtility.createErrorResponse(bridgeDataObject, "Request failed to delete Biller.");
					}
					
					response = bridgeDataObject.getBridgeResponse();
					response.setStatus(Status.SUCCESS);
				
				}else{
					pnbUtility.createErrorResponse(bridgeDataObject, PnbConstants.INVALID_BILLER);
					
					response = bridgeDataObject.getBridgeResponse();
					response.setStatus(Status.SUCCESS);
				}
			}
			
		}catch(Exception e)
		{
			pnbUtility.createErrorResponse(bridgeDataObject);
			
			response = bridgeDataObject.getBridgeResponse();
			response.setStatus(Status.FAILED);
			
			return response;
		}
		
		return response;
	}
	
	@Transactional
	private BridgeDataResponse processChequeStatus(BridgeDataObject bridgeDataObject) 
	{
		BridgeDataResponse response = new BridgeDataResponse();
		
		try{
		    //converting Hex to String
			bridgeDataObject.getPayerBankAccount().setbPin(EncryptionUtils.hexToString(bridgeDataObject.getPayerBankAccount().getbPin()));
			
			boolean verifiedCustomer = verifyCustomerByBPin(bridgeDataObject);
			
			if(verifiedCustomer)
			{
				if(bridgeDataObject.getServiceType()==ServiceType.BANKING_CHQ_BOOK_REQUEST)
				{
					pnbUtility.createErrorResponse(bridgeDataObject, "Cheque Book Request Received.");
					
					response = bridgeDataObject.getBridgeResponse();
					response.setStatus(Status.SUCCESS);
					
					return response;
					
				}else{
				
					ISOMsg responseMsg = socketService.writeOnSocket(bridgeDataObject.getTransactionData().getTransactionId(), isoMessageCreator.createChequeStatusMessage(bridgeDataObject));
					
					if(responseMsg != null)
					{
						Map<Integer,String> isoMap = isoMessageParser.parseMessage(bridgeDataObject.getTransactionData().getTransactionId(), responseMsg);
						
						if(isoMap != null && !isoMap.isEmpty() && isoMap.get(39).equals("000"))
						{
							pnbUtility.createChequeStatusFSPResponse(bridgeDataObject, isoMap);
						
							response = bridgeDataObject.getBridgeResponse();
							
							response.setStatus(Status.SUCCESS);
							return response;
							
						}else{
							pnbUtility.createErrorResponse(bridgeDataObject, Integer.parseInt(isoMap.get(39)) );
							response = bridgeDataObject.getBridgeResponse();
							response.setStatus(Status.FAILED);
							
							return response;
						}
					}else{
						pnbUtility.createErrorResponse(bridgeDataObject);
						
						response = bridgeDataObject.getBridgeResponse();
						response.setStatus(Status.FAILED);
						
						return response;
					}
				}
			}else{
				
				pnbUtility.createErrorResponse(bridgeDataObject, "Invalid Banking Pin.");
				
				response = bridgeDataObject.getBridgeResponse();
				response.setStatus(Status.FAILED);
				
				return response;
			}
			
		}catch(BankingException | IOException | ISOException e)
		{
			if(e instanceof BankingException)
				pnbUtility.createErrorResponse(bridgeDataObject, e.getMessage());
			else
				pnbUtility.createErrorResponse(bridgeDataObject);
			
			response = bridgeDataObject.getBridgeResponse();
			response.setStatus(Status.FAILED);
			
			return response;
		}
	}

	@Transactional
	private BridgeDataResponse processBankTransactionPinCreation(BridgeDataObject bridgeDataObject) 
	{
		BridgeDataResponse response = new BridgeDataResponse();
		try
		{
			CustomerDetails customerDetails = pnbDao.getCustomerDetailsByAccount(bridgeDataObject.getPayerBankAccount().getAccountNumber(), bridgeDataObject.getPayerBankAccount().getIfscCode());
			
			if(customerDetails == null)
			{
				pnbUtility.createErrorResponse(bridgeDataObject, PnbConstants.INVALID_CUSTOMER_DETAILS);
				
				response = bridgeDataObject.getBridgeResponse();
				response.setStatus(Status.FAILED);
				
				return response;
			}
			
			/**
			 *  Some process to verify Setting PIN
			 */
			
			customerDetails.setTransactionPin(EncryptionUtils.sha256Hash(bridgeDataObject.getPayerBankAccount().getbPin()));
			
			pnbDao.updateEntity(customerDetails);
			
			pnbUtility.createErrorResponse(bridgeDataObject, PnbConstants.BANKING_PIN_SUCCESSFUL);
			
			response = bridgeDataObject.getBridgeResponse();
			response.setStatus(Status.SUCCESS);
			
			return response;
			
		}catch(Exception e)
		{
			pnbUtility.createErrorResponse(bridgeDataObject);
			
			response = bridgeDataObject.getBridgeResponse();
			response.setStatus(Status.FAILED);
			
			return response;
		}
		
	}

	
	@Transactional
	private BridgeDataResponse processBankTransactionPinChange(BridgeDataObject bridgeDataObject) 
	{
		BridgeDataResponse response = new BridgeDataResponse();
		try
		{
			CustomerDetails customerDetails = pnbDao.getCustomerDetailsByAccount(bridgeDataObject.getPayerBankAccount().getAccountNumber(), bridgeDataObject.getPayerBankAccount().getIfscCode());
			
			if(customerDetails == null)
			{
				pnbUtility.createErrorResponse(bridgeDataObject, PnbConstants.INVALID_CUSTOMER_DETAILS);
				
				response = bridgeDataObject.getBridgeResponse();
				response.setStatus(Status.FAILED);
				
				return response;
			}
			
			/**
			 *  Some process to verify Setting PIN
			 */
			
			if(customerDetails.getTransactionPin() != null && customerDetails.getTransactionPin().equals(EncryptionUtils.sha256Hash(bridgeDataObject.getPayerBankAccount().getOldBankingPin())))
			{
				customerDetails.setTransactionPin(EncryptionUtils.sha256Hash(bridgeDataObject.getPayerBankAccount().getNewBankingPin()));
			
			}else
			{
				pnbUtility.createErrorResponse(bridgeDataObject, PnbConstants.INVALID_OLD_BANKING_PIN);
				
				response = bridgeDataObject.getBridgeResponse();
				response.setStatus(Status.FAILED);
				
				return response;
			}
			
			pnbDao.updateEntity(customerDetails);
			
			pnbUtility.createErrorResponse(bridgeDataObject, PnbConstants.BANKING_PIN_CHANGE_SUCCESSFUL);
			
			response = bridgeDataObject.getBridgeResponse();
			response.setStatus(Status.SUCCESS);
			
			return response;
			
		}catch(Exception e)
		{
			pnbUtility.createErrorResponse(bridgeDataObject);
			
			response = bridgeDataObject.getBridgeResponse();
			response.setStatus(Status.FAILED);
			
			return response;
		}
		
	}
	private BridgeDataResponse processBankBalanceCheck(BridgeDataObject bridgeDataObject) 
	{
		BridgeDataResponse response = new BridgeDataResponse();
		
		try{
		    //converting Hex to String
			bridgeDataObject.getPayerBankAccount().setbPin(EncryptionUtils.hexToString(bridgeDataObject.getPayerBankAccount().getbPin()));
			
			boolean verifiedCustomer = verifyCustomerByBPin(bridgeDataObject);
			
			if(verifiedCustomer)
			{
				ISOMsg responseMsg = socketService.writeOnSocket(bridgeDataObject.getTransactionData().getTransactionId(), isoMessageCreator.createBalEnquiryMessage(bridgeDataObject));
				
				if(responseMsg != null)
				{
					Map<Integer,String> isoMap = isoMessageParser.parseMessage(bridgeDataObject.getTransactionData().getTransactionId(), responseMsg);
					
					if(isoMap != null && !isoMap.isEmpty() && isoMap.get(39).equals("000"))
					{
						pnbUtility.createBalanceEnquiryFSPResponse(bridgeDataObject, isoMap);
					
						response = bridgeDataObject.getBridgeResponse();
						response.setStatus(Status.SUCCESS);
						
						return response;
						
					}else{
						pnbUtility.createErrorResponse(bridgeDataObject);
						response = bridgeDataObject.getBridgeResponse();
						response.setStatus(Status.FAILED);
						
						return response;
					}
				}else{
					pnbUtility.createErrorResponse(bridgeDataObject);
					
					response = bridgeDataObject.getBridgeResponse();
					response.setStatus(Status.FAILED);
					
					return response;
				}
			}else{
				
				pnbUtility.createErrorResponse(bridgeDataObject, "Invalid Banking Pin.");
				
				response = bridgeDataObject.getBridgeResponse();
				response.setStatus(Status.FAILED);
				
				return response;
			}
			
		}catch(BankingException | IOException | ISOException e)
		{
			if(e instanceof BankingException)
				pnbUtility.createErrorResponse(bridgeDataObject, e.getMessage());
			else
				pnbUtility.createErrorResponse(bridgeDataObject);
			
			response = bridgeDataObject.getBridgeResponse();
			response.setStatus(Status.FAILED);
			
			return response;
		}
	}

	private BridgeDataResponse processWalletBalanceCheck(BridgeDataObject bridgeDataObject) 
	{
		BridgeDataResponse response = new BridgeDataResponse();
		
		try{
			
			boolean verifiedCustomer = verifyCustomerByWalletPin(bridgeDataObject);
			
			if(verifiedCustomer)
			{
				
				ISOMsg responseMsg = socketService.writeOnSocket(bridgeDataObject.getTransactionData().getTransactionId(), isoMessageCreator.createWalletBalanceEnquiryMessage(bridgeDataObject));
				//ISOMsg responseMsg = socketService.writeOnSocket(bridgeDataObject.getTransactionData().getTransactionId(), isoMessageCreator.createWalletMiniStatementMessage(bridgeDataObject));
				
				if(responseMsg != null)
				{
					Map<Integer,String> isoMap = isoMessageParser.parseMessage(bridgeDataObject.getTransactionData().getTransactionId(), responseMsg);
					
					if(isoMap != null && !isoMap.isEmpty() && Integer.parseInt(isoMap.get(39)) == 0)
					{
						pnbUtility.createBalanceEnquiryFSPResponse(bridgeDataObject, isoMap);
					
						response = bridgeDataObject.getBridgeResponse();
						
						return response;
						
					}else{
						pnbUtility.createErrorResponse(bridgeDataObject);
						response = bridgeDataObject.getBridgeResponse();
						response.setStatus(Status.FAILED);
						
						return response;
					}
				}else{
					pnbUtility.createErrorResponse(bridgeDataObject);
					
					response = bridgeDataObject.getBridgeResponse();
					response.setStatus(Status.FAILED);
					
					return response;
				}
			}else{
					
					pnbUtility.createErrorResponse(bridgeDataObject, "Invalid Wallet Pin.");
					
					response = bridgeDataObject.getBridgeResponse();
					response.setStatus(Status.FAILED);
					
					return response;
				}
		}catch(IOException | ISOException | BankingException e)
		{
			if(e instanceof BankingException)
				pnbUtility.createErrorResponse(bridgeDataObject, e.getMessage());
			else
				pnbUtility.createErrorResponse(bridgeDataObject);
			
			response = bridgeDataObject.getBridgeResponse();
			response.setStatus(Status.FAILED);
			
			return response;
		}
	}

	private BridgeDataResponse processBankingTxnHistory(BridgeDataObject bridgeDataObject) 
	{
		BridgeDataResponse response = new BridgeDataResponse();
		try{
			
			bridgeDataObject.getPayerBankAccount().setbPin(EncryptionUtils.hexToString(bridgeDataObject.getPayerBankAccount().getbPin()));
			
			boolean verifiedCustomer = verifyCustomerByBPin(bridgeDataObject);
			
			if(verifiedCustomer)
			{
			
				ISOMsg responseMsg = socketService.writeOnSocket(bridgeDataObject.getTransactionData().getTransactionId(), isoMessageCreator.createMiniStatementMessage(bridgeDataObject));
				
				if(responseMsg != null)
				{
					Map<Integer,String> isoMap = isoMessageParser.parseMessage(bridgeDataObject.getTransactionData().getTransactionId(), responseMsg);
					
					if(isoMap != null && !isoMap.isEmpty() && isoMap.get(39).equals("000"))
					{
						pnbUtility.createMiniStatementFSPResponse(bridgeDataObject, isoMap);
					
						response = bridgeDataObject.getBridgeResponse();
						
						return response;
						
					}else{
						pnbUtility.createErrorResponse(bridgeDataObject);
						response = bridgeDataObject.getBridgeResponse();
						response.setStatus(Status.FAILED);
						
						return response;
					}
				}else{
					pnbUtility.createErrorResponse(bridgeDataObject);
					
					response = bridgeDataObject.getBridgeResponse();
					response.setStatus(Status.FAILED);
					
					return response;
				}
			}else{
				
				pnbUtility.createErrorResponse(bridgeDataObject, "Invalid Banking Pin.");
				
				response = bridgeDataObject.getBridgeResponse();
				response.setStatus(Status.FAILED);
				
				return response;
			}
		}catch(IOException | ISOException | BankingException e)
		{
			if(e instanceof BankingException)
				pnbUtility.createErrorResponse(bridgeDataObject, e.getMessage());
			else
				pnbUtility.createErrorResponse(bridgeDataObject);
			
			response = bridgeDataObject.getBridgeResponse();
			response.setStatus(Status.FAILED);
			
			return response;
		}
	}

	private BridgeDataResponse processUtilityPaymentsFromBank(BridgeDataObject bridgeDataObject) 
	{
		BridgeDataResponse response = new BridgeDataResponse();
		try{
			ProvidersData fromCache = bridgeDataObject.getHostSubVersionData().getProviderMap().get(ProviderRelation.FSP_PROVIDER).get(new ProvidersData(bridgeDataObject.getProvider().getCode()));
			
			ProvidersData requestDetals = bridgeDataObject.getProvider();
			
			String transactionDetails = "Utility Payment:"+fromCache.getCategory().getName()+"-"+fromCache.getName()+"-"+requestDetals.getSubscriberId();
			
			boolean verifiedCustomer = verifyCustomerByBPin(bridgeDataObject);
			
			if(verifiedCustomer)
			{
				ISOMsg responseMsg = socketService.writeOnSocket(bridgeDataObject.getTransactionData().getTransactionId(), isoMessageCreator.createFundDebitMessage(bridgeDataObject,transactionDetails));
				
				if(responseMsg != null)
				{
					Map<Integer,String> isoMap = isoMessageParser.parseMessage(bridgeDataObject.getTransactionData().getTransactionId(), responseMsg);
					
					if(isoMap != null && !isoMap.isEmpty() && isoMap.get(39).equals("000"))
					{
						String currentBalance = pnbUtility.getCurrentBalanceFromDebitCreditResponse(isoMap.get(48));
						
						CustomerDetails customerDetails = pnbDao.getCustomerDetailsByAccount(bridgeDataObject.getPayerBankAccount().getAccountNumber(), bridgeDataObject.getPayerBankAccount().getIfscCode());
					
						response = managePoolAndExternalCall(bridgeDataObject.getServiceType(),customerDetails , bridgeDataObject, true,  currentBalance, transactionDetails);
						
						return response;
						
					}else{
						pnbUtility.createBankToBankFSPResponse(bridgeDataObject, isoMap);
						response = bridgeDataObject.getBridgeResponse();
						response.setStatus(Status.FAILED);
						
						return response;
					}
				}else{
					pnbUtility.createErrorResponse(bridgeDataObject);
					
					response = bridgeDataObject.getBridgeResponse();
					response.setStatus(Status.FAILED);
					
					return response;
				}
			}else{
				
				pnbUtility.createErrorResponse(bridgeDataObject, "Invalid Banking Pin.");
				
				response = bridgeDataObject.getBridgeResponse();
				response.setStatus(Status.FAILED);
				
				return response;
			}
		}catch(BankingException | IOException | ISOException e)
		{
			if(e instanceof BankingException)
				pnbUtility.createErrorResponse(bridgeDataObject, e.getMessage());
			else
				pnbUtility.createErrorResponse(bridgeDataObject);
			
			response = bridgeDataObject.getBridgeResponse();
			response.setStatus(Status.FAILED);
			
			return response;
		}
	}

	private BridgeDataResponse processUtilityPaymentsFromWallet(BridgeDataObject bridgeDataObject) 
	{
		BridgeDataResponse response = new BridgeDataResponse();
		try{
			ProvidersData fromCache = bridgeDataObject.getHostSubVersionData().getProviderMap().get(ProviderRelation.FSP_PROVIDER).get(new ProvidersData(bridgeDataObject.getProvider().getCode()));
			
			ProvidersData requestDetals = bridgeDataObject.getProvider();
			
			String transactionDetails = "Utility Payment:"+fromCache.getCategory().getName()+"-"+fromCache.getName()+"-"+requestDetals.getSubscriberId();
			
			boolean verifiedCustomer = verifyCustomerByWalletPin(bridgeDataObject);
			
			if(verifiedCustomer)
			{
				ISOMsg responseMsg = socketService.writeOnSocket(bridgeDataObject.getTransactionData().getTransactionId(), isoMessageCreator.createWalletBillPay(bridgeDataObject));
				
				if(responseMsg != null)
				{
					Map<Integer,String> isoMap = isoMessageParser.parseMessage(bridgeDataObject.getTransactionData().getTransactionId(), responseMsg);
					
					if(isoMap != null && !isoMap.isEmpty() && Integer.parseInt(isoMap.get(39)) == 0)
					{
						//String currentBalance = pnbUtility.getCurrentBalanceFromDebitCreditResponse(isoMap.get(48));
						/*sfa
						CustomerDetails customerDetails = pnbDao.getCustomerDetailsByAccount(bridgeDataObject.getPayerBankAccount().getAccountNumber(), bridgeDataObject.getPayerBankAccount().getIfscCode());
					
						response = managePoolAndExternalCall(bridgeDataObject.getServiceType(),customerDetails , bridgeDataObject, true,  currentBalance, transactionDetails);
						
						return response;*/
						
						pnbUtility.createWalletBillPaymentFSPResponse(bridgeDataObject, isoMap, fromCache.getName());
						
						response = bridgeDataObject.getBridgeResponse();
						
						return response;
						
					}else{
						pnbUtility.createBankToBankFSPResponse(bridgeDataObject, isoMap);
						response = bridgeDataObject.getBridgeResponse();
						response.setStatus(Status.FAILED);
						
						return response;
					}
				}else{
					pnbUtility.createErrorResponse(bridgeDataObject);
					
					response = bridgeDataObject.getBridgeResponse();
					response.setStatus(Status.FAILED);
					
					return response;
				}
			}else{
				
				pnbUtility.createErrorResponse(bridgeDataObject, "Invalid Wallet Pin.");
				
				response = bridgeDataObject.getBridgeResponse();
				response.setStatus(Status.FAILED);
				
				return response;
			}
		}catch(BankingException | IOException | ISOException e)
		{
			if(e instanceof BankingException)
				pnbUtility.createErrorResponse(bridgeDataObject, e.getMessage());
			else
				pnbUtility.createErrorResponse(bridgeDataObject);
			
			response = bridgeDataObject.getBridgeResponse();
			response.setStatus(Status.FAILED);
			
			return response;
		}
	}
	
	private BridgeDataResponse processFundTransferWalletToBank(BridgeDataObject bridgeDataObject) 
	{
		BridgeDataResponse response = new BridgeDataResponse();
		try{
			String transactionDetails = "";
			ISOMsg responseMsg = socketService.writeOnSocket(bridgeDataObject.getTransactionData().getTransactionId(), isoMessageCreator.createWalletDebitMessage(bridgeDataObject,transactionDetails));
			
			if(responseMsg != null)
			{
				Map<Integer,String> isoMap = isoMessageParser.parseMessage(bridgeDataObject.getTransactionData().getTransactionId(), responseMsg);
				
				if(isoMap != null && !isoMap.isEmpty() && isoMap.get(39).equals("000"))
				{
					String currentBalance = pnbUtility.getCurrentBalanceFromDebitCreditResponse(isoMap.get(48));
					
					CustomerDetails customerDetails = pnbDao.getCustomerDetailsByAccount(bridgeDataObject.getPayerBankAccount().getAccountNumber(), bridgeDataObject.getPayerBankAccount().getIfscCode());
				
					response = managePoolAndExternalCall(bridgeDataObject.getServiceType(),customerDetails , bridgeDataObject, true, currentBalance, transactionDetails );
					
					return response;
					
				}else{
					pnbUtility.createBankToBankFSPResponse(bridgeDataObject, isoMap);
					response = bridgeDataObject.getBridgeResponse();
					response.setStatus(Status.FAILED);
					
					return response;
				}
			}else{
				pnbUtility.createErrorResponse(bridgeDataObject);
				
				response = bridgeDataObject.getBridgeResponse();
				response.setStatus(Status.FAILED);
				
				return response;
			}
			
		}catch(IOException | ISOException e)
		{
			if(e instanceof BankingException)
				pnbUtility.createErrorResponse(bridgeDataObject, e.getMessage());
			else
				pnbUtility.createErrorResponse(bridgeDataObject);
			
			response = bridgeDataObject.getBridgeResponse();
			response.setStatus(Status.FAILED);
			
			return response;
		}
		
	}

	/**
	 *  Wallet API required to complete the implementation
	 * @param bridgeDataObject
	 * @return
	 */
	private BridgeDataResponse processFundTransferBankToWallet(BridgeDataObject bridgeDataObject) 
	{
		BridgeDataResponse response = new BridgeDataResponse();
		try{
			String transactionDetails = "BTW:"+bridgeDataObject.getPayeeWallet().getWalletCode()+"-"+bridgeDataObject.getMsisdn();
			
			bridgeDataObject.getPayerBankAccount().setbPin(EncryptionUtils.hexToString(bridgeDataObject.getPayerBankAccount().getbPin()));
			
			boolean verifiedCustomer = verifyCustomerByBPin(bridgeDataObject);
			
			if(verifiedCustomer)
			{
				ISOMsg responseMsg = socketService.writeOnSocket(bridgeDataObject.getTransactionData().getTransactionId(), isoMessageCreator.createFundDebitMessage(bridgeDataObject, transactionDetails));
				
				if(responseMsg != null)
				{
					Map<Integer,String> isoMap = isoMessageParser.parseMessage(bridgeDataObject.getTransactionData().getTransactionId(), responseMsg);
					
					if(isoMap != null && !isoMap.isEmpty() && Integer.parseInt(isoMap.get(39)) == 0)
					{
						String currentBalance = pnbUtility.getCurrentBalanceFromDebitCreditResponse(isoMap.get(48));
						
						CustomerDetails customerDetails = pnbDao.getCustomerDetailsByAccount(bridgeDataObject.getPayerBankAccount().getAccountNumber(), bridgeDataObject.getPayerBankAccount().getIfscCode());
					
						response = managePoolAndExternalCall(bridgeDataObject.getServiceType(),customerDetails , bridgeDataObject, true, currentBalance, transactionDetails );
						
						return response;
						//Credit Amount to Pool A/c
					}else{
						pnbUtility.createBankToBankFSPResponse(bridgeDataObject, isoMap);
						response = bridgeDataObject.getBridgeResponse();
						response.setStatus(Status.SUCCESS);
						
						return response;
					}
				}else{
					pnbUtility.createErrorResponse(bridgeDataObject);
					
					response = bridgeDataObject.getBridgeResponse();
					response.setStatus(Status.SUCCESS);
					
					return response;
				}
			
			}else{
				pnbUtility.createErrorResponse(bridgeDataObject, "Invalid Banking Pin.");
				response = bridgeDataObject.getBridgeResponse();
				response.setStatus(Status.SUCCESS);
				
				return response;
			}
		}catch(BankingException | IOException | ISOException e)
		{
			e.printStackTrace();
			
			if(e instanceof BankingException)
				pnbUtility.createErrorResponse(bridgeDataObject, e.getMessage());
			else
				pnbUtility.createErrorResponse(bridgeDataObject);
			
			response = bridgeDataObject.getBridgeResponse();
			response.setStatus(Status.FAILED);
			
			return response;
		}
	
	}

	private BridgeDataResponse processFundTransferBankToBank(BridgeDataObject bridgeDataObject) 
	{

		BridgeDataResponse response = new BridgeDataResponse();
		
		boolean isOnUsTransaction = false;
		
		bridgeDataObject.getPayerBankAccount().setbPin(EncryptionUtils.hexToString(bridgeDataObject.getPayerBankAccount().getbPin()));
		
		String payeeIFSC = bridgeDataObject.getPayeeBankAccount().getIfscCode();
		
		String payerIFSC = bridgeDataObject.getPayerBankAccount().getIfscCode();
		
		if(payerIFSC == null || payerIFSC.isEmpty() || payerIFSC.length() != 11)
		{
			response.setStatus(Status.SUCCESS);
			response.setResponseMsg("INVALID PAYER IFSC CODE.");
			
			return response;
		}
		
		if(payeeIFSC == null || payeeIFSC.isEmpty() || payeeIFSC.length() != 11)
		{
			response.setStatus(Status.SUCCESS);
			response.setResponseMsg("INVALID PAYEE IFSC CODE.");
			
			return response;
		}
			
		
		if(payerIFSC.substring(0, 4).equalsIgnoreCase(payeeIFSC.substring(0, 4)))
			isOnUsTransaction = true;
		
		if(isOnUsTransaction)
		{
			//Hit fund transafer API
			try{
				
				boolean verifiedCustomer = verifyCustomerByBPin(bridgeDataObject);
				boolean proceedFurther = false;
				
				if(verifiedCustomer)
				{
					ResponseObject kycCompatibility = txnKYCCompatible(bridgeDataObject.getPayerBankAccount(), SystemConstant.TRANSACTION_NATURE_DEBIT);
					
					if(kycCompatibility != null && kycCompatibility.getStatus().intValue() == ErrorCodes.REQUEST_SUCCESSFUL.getCode().intValue())
					{
						kycCompatibility = txnKYCCompatible(bridgeDataObject.getPayeeBankAccount(), SystemConstant.TRANSACTION_NATURE_CREDIT);
						
						if(kycCompatibility != null && kycCompatibility.getStatus().intValue() == ErrorCodes.REQUEST_SUCCESSFUL.getCode().intValue())
							proceedFurther = true;
					}
						
					if(proceedFurther)
					{
						ISOMsg responseMsg = socketService.writeOnSocket(bridgeDataObject.getTransactionData().getTransactionId(), isoMessageCreator.createFundTransferMessage(bridgeDataObject));
						
						if(responseMsg != null)
						{
							Map<Integer,String> isoMap = isoMessageParser.parseMessage(bridgeDataObject.getTransactionData().getTransactionId(), responseMsg);
							
							if(isoMap != null && !isoMap.isEmpty() && isoMap.get(39).equals("000"))
							{
								String currentBalance = pnbUtility.getCurrentBalanceFromDebitCreditResponse(isoMap.get(48));
								
								String payerAccount = pnbUtility.getMaskedAccountNumber(bridgeDataObject.getPayerBankAccount().getAccountNumber());
								
								String payeeAccount = pnbUtility.getMaskedAccountNumber(bridgeDataObject.getPayeeBankAccount().getAccountNumber());
								
									response.setResponseMsg(PnbConstants.AC + payerAccount + "  has been debited successfully with ETB "+ bridgeDataObject.getAmount()+" for Fund transfer to "+ PnbConstants.AC_NO + payeeAccount+".Current balance is ETB "+currentBalance+".");
									response.setStatus(Status.SUCCESS);
								
								return response;
							}else{
								pnbUtility.createBankToBankFSPResponse(bridgeDataObject, isoMap);
								response = bridgeDataObject.getBridgeResponse();
								response.setStatus(Status.FAILED);
								
								return response;
							}
						}
					}else{
						pnbUtility.createErrorResponse(bridgeDataObject, kycCompatibility.getMessage());
					}
				}else{
					pnbUtility.createErrorResponse(bridgeDataObject, "Invalid Banking Pin.");
				}
				
			}catch(BankingException | IOException | ISOException e)
			{
				e.printStackTrace();
				
				if(e instanceof BankingException)
					pnbUtility.createErrorResponse(bridgeDataObject, e.getMessage());
				else
				pnbUtility.createErrorResponse(bridgeDataObject);
			}
			
			 return bridgeDataObject.getBridgeResponse();
			
		}else{
			//First Hit Debit call on payer A/c
			//Update Pool A/c
			//Hit NPCI call 
			//Update Pool A/c
			
			try{
				
				boolean verifiedCustomer = verifyCustomerByBPin(bridgeDataObject);
				
				if(verifiedCustomer)
				{
					
				String transactionDetails = bridgeDataObject.getPayeeBankAccount().getAccountNumber()+"-"+bridgeDataObject.getPayeeBankAccount().getIfscCode();
				
				ISOMsg responseMsg = socketService.writeOnSocket(bridgeDataObject.getTransactionData().getTransactionId(), isoMessageCreator.createFundDebitMessage(bridgeDataObject, transactionDetails));
				
				if(responseMsg != null)
				{
					Map<Integer,String> isoMap = isoMessageParser.parseMessage(bridgeDataObject.getTransactionData().getTransactionId(), responseMsg);
					
					if(isoMap != null && !isoMap.isEmpty() && isoMap.get(39).equals("000"))
					{
						String currentBalance = pnbUtility.getCurrentBalanceFromDebitCreditResponse(isoMap.get(48));
						
						CustomerDetails customerDetails = pnbDao.getCustomerDetailsByAccount(bridgeDataObject.getPayerBankAccount().getAccountNumber(), bridgeDataObject.getPayerBankAccount().getIfscCode());
						
						response = managePoolAndExternalCall(bridgeDataObject.getServiceType(),customerDetails , bridgeDataObject, isOnUsTransaction, currentBalance, transactionDetails );
						
						return response;
					}else{
						pnbUtility.createBankToBankFSPResponse(bridgeDataObject, isoMap);
						response = bridgeDataObject.getBridgeResponse();
						response.setStatus(Status.FAILED);
						
						return response;
					}
				}else{
					pnbUtility.createErrorResponse(bridgeDataObject);
					
					response = bridgeDataObject.getBridgeResponse();
					response.setStatus(Status.FAILED);
					
					return response;
				}
				}else{
					pnbUtility.createErrorResponse(bridgeDataObject, "Invalid Banking Pin.");
					response = bridgeDataObject.getBridgeResponse();
					response.setStatus(Status.SUCCESS);
				}
			}catch(BankingException | IOException | ISOException e)
			{
				e.printStackTrace();
				
				if(e instanceof BankingException)
					pnbUtility.createErrorResponse(bridgeDataObject, e.getMessage());
				else
					pnbUtility.createErrorResponse(bridgeDataObject);
				
				response = bridgeDataObject.getBridgeResponse();
				response.setStatus(Status.SUCCESS);
				
				return response;
			}
		}
		
		return response;
	}

	private boolean verifyCustomerByBPin(BridgeDataObject bridgeDataObject) throws BankingException
	{
			CustomerDetails customerDetails = pnbDao.getCustomerDetailsByAccount(bridgeDataObject.getPayerBankAccount().getAccountNumber(), bridgeDataObject.getPayerBankAccount().getIfscCode());
			
			if(customerDetails == null)
				throw new BankingException("Invalid Account Number and IFSC code.");
			
			if(customerDetails.getTransactionPin() == null)
				throw new BankingException("Banking Pin not set for given account.");
			
			if(bridgeDataObject.getPayerBankAccount().getbPin() == null)
				throw new BankingException("Invalid Banking Pin.");
			
			return (customerDetails.getTransactionPin().equalsIgnoreCase(EncryptionUtils.sha256Hash(bridgeDataObject.getPayerBankAccount().getbPin())));
	}

	private boolean verifyCustomerByWalletPin(BridgeDataObject bridgeDataObject) throws BankingException
	{
		boolean customerStatus = false;
		
			CustomerWallets walletDetails = pnbDao.getSubscriberWallet(bridgeDataObject.getPayerWallet().getMsisdn(), bridgeDataObject.getPayerWallet().getWalletCode());
			
			if(walletDetails == null)
				throw new BankingException("Invalid Wallet Details.");
			
			if(walletDetails.getWalletPin() == null)
				throw new BankingException("Pin not set for given wallet.");
			
			if(walletDetails.getWalletStatus() == null || !walletDetails.getWalletStatus().equalsIgnoreCase(SystemConstant.ACTIVE))
				throw new BankingException("Your wallet is not Active, please contact customer care.");
			
			if(bridgeDataObject.getPayerWallet().getWalletPin() == null)
				throw new BankingException("Invalid Wallet Pin.");
			
			customerStatus = (walletDetails.getWalletPin().equalsIgnoreCase(EncryptionUtils.sha256Hash(bridgeDataObject.getPayerWallet().getWalletPin().toString())));
			
			if(customerStatus)
				bridgeDataObject.getPayerWallet().setAccountNumber(walletDetails.getWalletNumber());
			
			return customerStatus;
	}
	
	private synchronized BridgeDataResponse managePoolAndExternalCall(ServiceType serviceType, CustomerDetails customerDetails, BridgeDataObject bridgeDataObject, boolean isOnUsTransaction, String updatedBalance, String transactionDetails) 
	{
		BridgeDataResponse response = new BridgeDataResponse();
		
		try{
			
			InternalAccountMaster accountMaster = pnbDao.getAccountMaster(PnbConstants.LIEN_ACCOUNT_TYPE);
			
			PoolAccount poolAccount = new PoolAccount();
			
			if(bridgeDataObject.getPayerBankAccount() != null)
			{
				poolAccount.setInstrument(SystemConstant.BANK);
				poolAccount.setAccountNumber(Long.parseLong(bridgeDataObject.getPayerBankAccount().getAccountNumber()));
				
			}else if(bridgeDataObject.getPayerWallet() != null)
			{
				poolAccount.setInstrument(SystemConstant.WALLETS);
				poolAccount.setAccountNumber(Long.parseLong(bridgeDataObject.getPayerWallet().getMsisdn()));
			}
			
			if(bridgeDataObject.getPayerBankAccount() != null)
			{
				poolAccount.setTransactionDescription(bridgeDataObject.getServiceType().toString() + ":" + bridgeDataObject.getPayerBankAccount().getAccountNumber()+"-"+bridgeDataObject.getPayerBankAccount().getIfscCode());
			}else if(bridgeDataObject.getPayeeWallet() != null)
			{
				poolAccount.setTransactionDescription(bridgeDataObject.getServiceType().toString() + ":" + bridgeDataObject.getPayeeWallet().getMsisdn()+"-"+bridgeDataObject.getPayeeWallet().getWalletCode());
			}
			
			poolAccount.setOpeningBalance(accountMaster.getAccountBalance());
			
			poolAccount.setCustomerId(customerDetails.getCustomerId());
			poolAccount.setTransactionAmount((double)bridgeDataObject.getAmount());
			poolAccount.setTransactionId(bridgeDataObject.getTransactionData().getTransactionId());
			poolAccount.setTransactionNature(SystemConstant.TRANSACTION_NATURE_CREDIT);
			poolAccount.setTransactionStatus(SystemConstant.SUCCESS);
			poolAccount.setTransactionStatusDescription(SystemConstant.SUCCESS);
			poolAccount.setTransactionType(bridgeDataObject.getServiceType().toString());
			poolAccount.setTrasactionOn(new Date());
			
			poolAccount.setClosingBalance(accountMaster.getAccountBalance() + (double)bridgeDataObject.getAmount());
			
			boolean saveStatus = pnbDao.saveEntity(poolAccount);
			
			accountMaster.setAccountBalance(accountMaster.getAccountBalance() + (double)bridgeDataObject.getAmount());
			accountMaster.setUpdatedOn(new Date());
			
			pnbDao.updateEntity(accountMaster);
			
			ResponseObject externalCallResponse = null;
			
			String responseMessage = null;
			
			if(saveStatus)
			{
				
				switch(serviceType)
				{
				
				case BANKING_FT_B_TO_B:
					externalCallResponse = new ResponseObject(); //call NPCI Api
					
					externalCallResponse.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode().intValue());
					externalCallResponse.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
					
					String payerAccount = pnbUtility.getMaskedAccountNumber(bridgeDataObject.getPayerBankAccount().getAccountNumber());
					
					String payeeAccount = pnbUtility.getMaskedAccountNumber(bridgeDataObject.getPayeeBankAccount().getAccountNumber());
					
					if(externalCallResponse.getStatus().intValue() == ErrorCodes.REQUEST_SUCCESSFUL.getCode().intValue())
						responseMessage = PnbConstants.AC + payerAccount + "  has been debited successfully with ETB "+ bridgeDataObject.getAmount()+" for Fund transfer to "+ PnbConstants.AC_NO + payeeAccount+".Current balance is ETB "+updatedBalance+".";
					else
						responseMessage = "Fund transfer from your  A/C  "+payerAccount+"  to  A/C  "+payeeAccount+"  is Failed. Please try after some times.";
					
					break;
					
				case BANKING_FT_B_TO_WALLET:
					//externalCallResponse = null; //call Wallet Credit API
					
					externalCallResponse = new ResponseObject();
					
					externalCallResponse.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
					externalCallResponse.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
					
					String payerAccountNumber = pnbUtility.getMaskedAccountNumber(bridgeDataObject.getPayerBankAccount().getAccountNumber());
					
					if(externalCallResponse.getStatus().intValue() == ErrorCodes.REQUEST_SUCCESSFUL.getCode().intValue())
						responseMessage = PnbConstants.AC + payerAccountNumber + "  has been debited successfully with ETB "+ bridgeDataObject.getAmount()+" for Fund transfer to "+ bridgeDataObject.getPayeeWallet().getMsisdn() +" wallet.Current balance is ETB "+updatedBalance+".";
					else
						responseMessage = "Fund transfer from your  A/C  "+payerAccountNumber+"  to  wallet  "+bridgeDataObject.getPayeeWallet().getMsisdn()+"  is Failed. Please try after some times.";
					
					break;
					
				case BILL_PAY_BY_B:
					//externalCallResponse = null; //call BillDesk API
					externalCallResponse = new ResponseObject();
					
					externalCallResponse.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
					externalCallResponse.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
					
					payerAccount = pnbUtility.getMaskedAccountNumber(bridgeDataObject.getPayerBankAccount().getAccountNumber());
					
					if(externalCallResponse.getStatus().intValue() == ErrorCodes.REQUEST_SUCCESSFUL.getCode().intValue())
						responseMessage = PnbConstants.AC + payerAccount + "  has been debited successfully with ETB "+ bridgeDataObject.getAmount()+" for Bill Pay to "+ bridgeDataObject.getProvider().getSubscriberId()  +".Current balance is ETB "+updatedBalance+".";
					else
						responseMessage = "Bill Pay to "+ bridgeDataObject.getProvider().getSubscriberId()  +" is Failed. Please try after some times.";
					
					break;
					
				case BILL_PAY_BY_WALLET:
					//externalCallResponse = null; //call BillDesk Api
					externalCallResponse = new ResponseObject();
					
					externalCallResponse.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
					externalCallResponse.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
					
					break;
					
				case TOP_UP_RECH_BY_B:
					//externalCallResponse = null; //call BillDesk API
					
					externalCallResponse = new ResponseObject();
					
					externalCallResponse.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
					externalCallResponse.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
					
					payerAccount = pnbUtility.getMaskedAccountNumber(bridgeDataObject.getPayerBankAccount().getAccountNumber());
					
					if(externalCallResponse.getStatus().intValue() == ErrorCodes.REQUEST_SUCCESSFUL.getCode().intValue())
						responseMessage = PnbConstants.AC + payerAccount + "  has been debited successfully with ETB "+ bridgeDataObject.getAmount()+" for TopUp to "+ bridgeDataObject.getProvider().getSubscriberId()  +".Current balance is ETB "+updatedBalance+".";
					else
						responseMessage = "TopUp to "+ bridgeDataObject.getProvider().getSubscriberId()  +" is Failed. Please try after some times.";
					
					break;
					
				case TOP_UP_RECH_BY_WALLET:
					//externalCallResponse = null; //call BillDesk API
					
					externalCallResponse = new ResponseObject();
					
					externalCallResponse.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
					externalCallResponse.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
					
					
					break;
					
				case OTH_PAY_RET_B_TO_WALLET:
				
					//externalCallResponse = null; //call Wallet Credit Api
					
					externalCallResponse = new ResponseObject();
					
					externalCallResponse.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
					externalCallResponse.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
					
					payerAccount = pnbUtility.getMaskedAccountNumber(bridgeDataObject.getPayerBankAccount().getAccountNumber());
					
					if(externalCallResponse.getStatus().intValue() == ErrorCodes.REQUEST_SUCCESSFUL.getCode().intValue())
						responseMessage = PnbConstants.AC + payerAccount + "  has been debited successfully with ETB "+ bridgeDataObject.getAmount()+" for TopUp to "+ bridgeDataObject.getProvider().getSubscriberId()  +".Current balance is ETB "+updatedBalance+".";
					else
						responseMessage = "TopUp to "+ bridgeDataObject.getProvider().getSubscriberId()  +" is Failed. Please try after some times.";
					
					
					break;
				case MWALLET_AG_TOP_UP_ACCOUNT_B_T_W:
				case MWALLET_CUST_TOP_UP_ONLINE_B_T_W:
					//externalCallResponse = null; //call Wallet Credit Api
					
					externalCallResponse = new ResponseObject();
					
					externalCallResponse.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
					externalCallResponse.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
					
					payerAccount = pnbUtility.getMaskedAccountNumber(bridgeDataObject.getPayerBankAccount().getAccountNumber());
					
					if(externalCallResponse.getStatus().intValue() == ErrorCodes.REQUEST_SUCCESSFUL.getCode().intValue())
						responseMessage = "Your wallet recharged successfully with ETB "+ bridgeDataObject.getAmount();
					else
						responseMessage = "Your wallet recharge is Failed. Please try after some times.";
					
					
					break;
							
				
				case OTH_PAY_RET_WALLET_TO_B:
					//externalCallResponse = null; //call NPCI API
					
					externalCallResponse = new ResponseObject();
					
					externalCallResponse.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
					externalCallResponse.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
					
					break;
					
				case OTH_PAY_INDI_B_TO_WALLET:
					//externalCallResponse = null; //call Wallet Credit API
					
					externalCallResponse = new ResponseObject();
					
					externalCallResponse.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
					externalCallResponse.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
					
					break;
					
				case OTH_PAY_INDI_WALLET_TO_B:
					//externalCallResponse = null; //call NPCI Api
					
					externalCallResponse = new ResponseObject();
					
					externalCallResponse.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
					externalCallResponse.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
					
					break;
					
				}
				
				
				if(externalCallResponse.getStatus().intValue() == ErrorCodes.REQUEST_SUCCESSFUL.getCode().intValue())
				{
					PoolAccount updatePoolAccount = new PoolAccount();
					
					BeanUtils.copyProperties(poolAccount, updatePoolAccount);
					
					updatePoolAccount.setTransactionStatus(SystemConstant.SUCCESS);
					updatePoolAccount.setTransactionStatusDescription(SystemConstant.SUCCESS);
					
					updatePoolAccount.setOpeningBalance(poolAccount.getClosingBalance());
					updatePoolAccount.setClosingBalance(poolAccount.getClosingBalance() - (double)bridgeDataObject.getAmount());
					
					updatePoolAccount.setTransactionNature(SystemConstant.TRANSACTION_NATURE_DEBIT);
					updatePoolAccount.setTrasactionOn(new Date());
					updatePoolAccount.setId(null);

					pnbDao.saveEntity(poolAccount);
					
					accountMaster.setAccountBalance(accountMaster.getAccountBalance() - (double)bridgeDataObject.getAmount());
					accountMaster.setUpdatedOn(new Date());
					
					pnbDao.updateEntity(accountMaster);
					
					response.setStatus(Status.SUCCESS);
					response.setResponseMsg(responseMessage);
					
					return response;
					
				}else 
				{
				
					ISOMsg creditResponseMsg = socketService.writeOnSocket(bridgeDataObject.getTransactionData().getTransactionId(), isoMessageCreator.createFundCreditMessage(bridgeDataObject, transactionDetails));
					
					if(creditResponseMsg != null && creditResponseMsg.hasField(39) && creditResponseMsg.getString(39).equals("000"))
					{
						poolAccount.setTransactionStatus(SystemConstant.REFUNDED);
						poolAccount.setTransactionStatusDescription(externalCallResponse.getMessage());
						
						poolAccount.setOpeningBalance(poolAccount.getClosingBalance());
						poolAccount.setClosingBalance(poolAccount.getClosingBalance() - (double)bridgeDataObject.getAmount());
						
						poolAccount.setTransactionNature(SystemConstant.TRANSACTION_NATURE_DEBIT);
						poolAccount.setTrasactionOn(new Date());
						poolAccount.setId(null);

						boolean updateStatus = pnbDao.saveEntity(poolAccount);
						
						accountMaster.setAccountBalance(accountMaster.getAccountBalance() - (double)bridgeDataObject.getAmount());
						accountMaster.setUpdatedOn(new Date());
						
						pnbDao.updateEntity(accountMaster);
					}
					
					response.setStatus(Status.SUCCESS);
					response.setResponseMsg(responseMessage);
					
					return response;
				}
			}else{
			
				ISOMsg creditResponseMsg = socketService.writeOnSocket(bridgeDataObject.getTransactionData().getTransactionId(), isoMessageCreator.createFundCreditMessage(bridgeDataObject, transactionDetails));
				
				response.setStatus(Status.FAILED);
				response.setResponseMsg("Fund transfer from your  A/C  "+bridgeDataObject.getPayerBankAccount().getAccountNumber()+"  to  A/C  "+bridgeDataObject.getPayeeBankAccount().getAccountNumber()+"  is Failed.");
				
				return response;
			}
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return response;
	}

	
	public ResponseObject txnKYCCompatible(BankAccount accountDetails, String txnNature)
	{
		ResponseObject responseObject = new ResponseObject();
		
		//Fetch Subscriber details based on accountDetails
		CustomerDetails customerAccountData = pnbDao.getCustomerDetailsByAccount(accountDetails.getAccountNumber(), accountDetails.getIfscCode());
		
		//Fetch subscriber & his KYC data based on customerId
		Subscriber subscriber = pnbDao.getSubscriberByCustId(customerAccountData.getCustomerId()) ;
		
		
		switch(txnNature)
		{
		case SystemConstant.TRANSACTION_NATURE_CREDIT:
			
			//Validate subscriber KYC against CREDIT limit
			
			break;
			
		case SystemConstant.TRANSACTION_NATURE_DEBIT:
			
			//Validate subscriber KYC against DEBIT limit
			break;
			
		}
		
		responseObject.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
		
		return responseObject;
	}
	
	public ResponseObject updateKycLimit(BankAccount accountDetails, String txnNature)
	{
		ResponseObject responseObject = new ResponseObject();
		
		//Fetch Subscriber details based on accountDetails
		CustomerDetails customerAccountData = pnbDao.getCustomerDetailsByAccount(accountDetails.getAccountNumber(), accountDetails.getIfscCode());
		
		//Fetch subscriber & his KYC data based on customerId
		Subscriber subscriber = pnbDao.getSubscriberByCustId(customerAccountData.getCustomerId()) ;
		
		
		switch(txnNature)
		{
		case SystemConstant.TRANSACTION_NATURE_CREDIT:
			
			//Validate subscriber KYC against CREDIT limit
			
			break;
			
		case SystemConstant.TRANSACTION_NATURE_DEBIT:
			
			//Validate subscriber KYC against DEBIT limit
			break;
			
		}
		
		responseObject.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
		
		//pnbDao.updateEntity(subscriber.kycLimit)
		
		return responseObject;
	}
}
