/**
 * 
 */
package com.ng.pnb.bridge.service;

import java.io.IOException;

import org.jpos.iso.ISOMsg;

/**
 * @author gopal
 *
 */

public interface ISocketService {

	public ISOMsg writeOnSocket(String txnId,ISOMsg request) throws IOException;
	
	//public ISOMsg writeOnSocket(String txnId,String message) throws IOException;
	
	public ISOMsg submitNGetResponse(ISOMsg request) throws IOException;
}
