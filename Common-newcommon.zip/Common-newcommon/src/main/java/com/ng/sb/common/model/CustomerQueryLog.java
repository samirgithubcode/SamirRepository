package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
@Entity
@Table(name = "querylog")
@XmlRootElement

@NamedQueries({
	@NamedQuery(name="CustomerQueryLog.findAll", query="SELECT c FROM CustomerQueryLog c"),
	@NamedQuery(name="CustomerQueryLog.findbyid", query="SELECT c FROM CustomerQueryLog c where c.id=:id"),
	@NamedQuery(name="CustomerQueryLog.findbystatus", query="SELECT count(*) FROM CustomerQueryLog c where c.status=:status  and c.priorityid =:priorityid"),
	@NamedQuery(name="CustomerQueryLog.findbyticket", query="SELECT c FROM CustomerQueryLog c where c.refticketno=:refticketno"),
	@NamedQuery(name="CustomerQueryLog.findAllbymobilenumber", query="SELECT c FROM CustomerQueryLog c where c.mobilenocaller=:mobilenocaller and c.createdon != null"),
	@NamedQuery(name="CustomerQueryLog.findAllbyprority", query="SELECT c FROM CustomerQueryLog c where c.priorityid=:priorityid AND c.status=:status"),
	@NamedQuery(name="CustomerQueryLog.findAllbystatus", query="SELECT c FROM CustomerQueryLog c where  c.status=:status  AND  c.priorityid is NOT NULL"),
	@NamedQuery(name="CustomerQueryLog.findAllbyticketnumber", query="SELECT c FROM CustomerQueryLog c where c.refticketno=:refticketno or c.id=:refticketno"),
	@NamedQuery(name="CustomerQueryLog.findBymobilenumberService", query="SELECT c FROM CustomerQueryLog c where c.mobilenoservice=:mobilenoservice order by c.createdon desc"),
	@NamedQuery(name="CustomerQueryLog.findBymobilenumberServiceAndStatus", query="SELECT c FROM CustomerQueryLog c where c.mobilenoservice=:mobilenoservice AND c.status=:status order by c.createdon desc"),
	@NamedQuery(name="CustomerQueryLog.findBymobilenumberServiceAndDate", query="SELECT c FROM CustomerQueryLog c where c.mobilenoservice=:mobilenoservice AND DATE(c.createdon)>=:startDate AND DATE(c.createdon)<=:endDate order by c.createdon desc"),
	@NamedQuery(name="CustomerQueryLog.findBymobilenumberServiceAndDateAndStatus", query="SELECT c FROM CustomerQueryLog c where c.mobilenoservice=:mobilenoservice AND c.status=:status AND c.createdon>=:startDate AND c.createdon<=:endDate order by c.createdon desc"),
	@NamedQuery(name="CustomerQueryLog.findbystatusByLevel", query="SELECT count(*) FROM CustomerQueryLog c where  c.priorityid =:priorityid and c.level=:level and c.status in ('Pending','InProgress') "),
	@NamedQuery(name="CustomerQueryLog.findAllbystatusByLevel", query="SELECT c FROM CustomerQueryLog c where c.level=:level AND  c.priorityid is NOT NULL And c.status in ('Pending','InProgress')"),
	@NamedQuery(name="CustomerQueryLog.findAllbyprorityByLevel", query="SELECT c FROM CustomerQueryLog c where c.priorityid=:priorityid And c.level=:level And c.status in ('Pending','InProgress')"),
		/*
		 * @NamedQuery(name="CustomerQueryLog.findAllForSelfCare",
		 * query="SELECT c FROM CustomerQueryLog c where  c.isSelfcare='1' And c.status in ('Pending','InProgress') And (c.level is Null or c.level='L1') order by c.id desc"
		 * ),
		 */
	@NamedQuery(name="CustomerQueryLog.findAllbySubscriberId", query="SELECT c FROM CustomerQueryLog c where c.subscriberId=:subscriberId and c.createdon != null"),
	@NamedQuery(name="CustomerQueryLog.findLimitmobilenumberService", query="SELECT c FROM CustomerQueryLog c where c.mobilenoservice=:mobilenoservice order by c.createdon desc"),
	@NamedQuery(name="CustomerQueryLog.findAllForSelfCare", query="SELECT c FROM CustomerQueryLog c where  c.isSelfcare='1' And c.status in ('Pending','InProgress') And (c.level is Null or c.level='L1') order by c.id desc"),
})
public class CustomerQueryLog implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "id")
	private Integer id;
	
	@Column(name="level")
	private String level;
	
	@Basic(optional = true)
	@Column(name = "ref_ticket_no")
	private String refticketno;
	
	@Basic(optional = true)
	@Column(name = "Mobile_number_caller")
	private String mobilenocaller;
	
	@Basic(optional = true)
	@Column(name = "Mobile_number_services")
	private String mobilenoservice;
	
	@Basic(optional = true)
	@JoinColumn(name = "priorityId", referencedColumnName = "id")
	@ManyToOne
	private Customerpriority priorityid;

	@Basic(optional = true)
	@JoinColumn(name = "subscriber_id", referencedColumnName = "id")
	@ManyToOne(fetch = FetchType.LAZY)
	@Fetch(FetchMode.SELECT)
	private  Subscriber subscriberId;
	
	@Basic(optional = true)
	@JoinColumn(name = "subquery_id", referencedColumnName = "id")
	@ManyToOne
	private CustomerSubQuery subqueryId;
	
	@Basic(optional = true)
	@JoinColumn(name = "productid", referencedColumnName = "id")
	@ManyToOne
	private Products productid;
	
	@Basic(optional = true)
	@Column(name = "intial_customer_query")
	private String initialcustomerquery;
	
	@Basic(optional = true)
	@Column(name = "final_description")
	private String finaldescription;
	
	@Basic(optional = true)
	@Column(name = "assigned_to")
	private String assignedto;
	
	@Basic(optional = true)
	@JoinColumn(name = "created_by", referencedColumnName = "id")
	@ManyToOne
	
	private AccountLoginInfo accountLoginInfoId;
	

	@Basic(optional = true)
	@Column(name = "created_on", columnDefinition="DATETIME")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdon;
	
	@Basic(optional = true)
	@Column(name = "isSelfcare")
	private String isSelfcare;
	
	
	@Basic(optional = true)
	@JoinColumn(name = "modified_by", referencedColumnName = "id",nullable=true)
	@ManyToOne
	private AccountLoginInfo modifiedby;
	
	@Basic(optional = true)
	@Column(name = "modified_on", columnDefinition="DATETIME")
	@Temporal(TemporalType.TIMESTAMP)
	private Date modifiedon;
	
	@Basic(optional = true)
	@Column(name = "status")
	private String status ;
	
	@Basic(optional = true)
	@Column(name = "transaction_id")
	private String transactionid ;
	public CustomerQueryLog() {
		//constructor
	}
	public CustomerQueryLog(Integer id) {
		super();
		this.id = id;
	}
	public CustomerQueryLog(Integer id, String transactionid) {
		super();
		this.id = id;
		this.transactionid = transactionid;
	}
	
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}

	public String getRefticketno() {
		return refticketno;
	}

	public void setRefticketno(String refticketno) {
		this.refticketno = refticketno;
	}

	public String getMobilenocaller() {
		return mobilenocaller;
	}

	public void setMobilenocaller(String mobilenocaller) {
		this.mobilenocaller = mobilenocaller;
	}

	public String getMobilenoservice() {
		return mobilenoservice;
	}

	public void setMobilenoservice(String mobilenoservice) {
		this.mobilenoservice = mobilenoservice;
	}


	public Subscriber getSubscriberId() {
		return subscriberId;
	}

	public void setSubscriberId(Subscriber subscriberId) {
		this.subscriberId = subscriberId;
	}

	public CustomerSubQuery getSubqueryId() {
		return subqueryId;
	}

	public void setSubqueryId(CustomerSubQuery subqueryId) {
		this.subqueryId = subqueryId;
	}

	public String getInitialcustomerquery() {
		return initialcustomerquery;
	}

	public void setInitialcustomerquery(String initialcustomerquery) {
		this.initialcustomerquery = initialcustomerquery;
	}

	public String getFinaldescription() {
		return finaldescription;
	}

	public void setFinaldescription(String finaldescription) {
		this.finaldescription = finaldescription;
	}

	public String getAssignedto() {
		return assignedto;
	}

	public void setAssignedto(String assignedto) {
		this.assignedto = assignedto;
	}

	public AccountLoginInfo getAccountLoginInfoId() {
		return accountLoginInfoId;
	}

	public void setAccountLoginInfoId(AccountLoginInfo accountLoginInfo) {
		this.accountLoginInfoId = accountLoginInfo;
	}

	public Date getCreatedon() {
		return createdon;
	}


	public void setCreatedon(Date createdon) {
		this.createdon = createdon;
	}

	public AccountLoginInfo getModifiedby() {
		return modifiedby;
	}

	public void setModifiedby(AccountLoginInfo modifiedby) {
		this.modifiedby = modifiedby;
	}

	public Date getModifiedon() {
		return modifiedon;
	}

	public void setModifiedon(Date modifiedon) {
		this.modifiedon = modifiedon;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getTransactionid() {
		return transactionid;
	}

	public void setTransactionid(String transactionid) {
		this.transactionid = transactionid;
	}
	public Products getProductid() {
		return productid;
	}

	public void setProductid(Products productid) {
		this.productid = productid;
	}

	public Customerpriority getPriorityid() {
		return priorityid;
	}

	public void setPriorityid(Customerpriority priorityid) {
		this.priorityid = priorityid;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CustomerQueryLog other = (CustomerQueryLog) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "CustomerQueryLog [id=" + id + "]";
	}
	
	@Override
	public int hashCode() {
		 int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}
	public String getIsSelfcare() {
		return isSelfcare;
	}
	public void setIsSelfcare(String isSelfcare) {
		this.isSelfcare = isSelfcare;
	}
	
	
	
}
