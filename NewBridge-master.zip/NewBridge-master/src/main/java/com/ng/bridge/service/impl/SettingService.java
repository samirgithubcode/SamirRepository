/**
 * 
 */
package com.ng.bridge.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ng.bridge.service.IPartnerManagementService;
import com.ng.bridge.service.ISettingService;
import com.ng.bridge.util.NewConstants;
import com.ng.sb.common.dataobject.BridgeDataObject;
import com.ng.sb.common.exception.BridgeObjectDataException;
import com.ng.sb.common.util.SystemConstant;

/**
 * @author gaurav
 *
 */
@Service(value=SystemConstant.BRIDGE_SETTING_SERVICE)
public class SettingService extends FundTransferMgtService implements ISettingService {

	private static final Logger LOGGER = LoggerFactory.getLogger(SettingService.class);
	
	@Autowired
	IPartnerManagementService partnerManagementService;
	
	/* (non-Javadoc)
	 * @see com.ng.transaction.service.ISettingService#changePin(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject changePin(BridgeDataObject bridgeDataObject) {
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge SettingService -  changePin method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in changePin:"+ e);
		}
		return null;
	}

	@Override
	public BridgeDataObject createPin(BridgeDataObject bridgeDataObject) 
	{
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge SettingService -  createPin method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in createPin:"+ e);
		}
		return null;
	}
	
	@Override
	public BridgeDataObject changeWalletPin(BridgeDataObject bridgeDataObject) 
	{
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge SettingService -  changePin method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in changeWalletPin:"+ e);
		}
		return null;
	}

	@Override
	public BridgeDataObject createWalletPin(BridgeDataObject bridgeDataObject) {
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge SettingService -  changePin method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in createWalletPin:"+ e);
		}
		return null;
	}
	
	/* (non-Javadoc)
	 * @see com.ng.transaction.service.ISettingService#saveMyBankAccount(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject saveMyBankAccount(BridgeDataObject bridgeDataObject) {
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge SettingService -  saveMyBankAccount method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in saveMyBankAccount:"+ e);
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ng.transaction.service.ISettingService#saveMyCreditCard(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject saveMyCreditCard(BridgeDataObject bridgeDataObject) 
	{
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge SettingService -  saveMyCreditCard method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in saveMyCreditCard:"+ e);
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ng.transaction.service.ISettingService#saveMyIMPS(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject saveMyIMPS(BridgeDataObject bridgeDataObject) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ng.transaction.service.ISettingService#saveMyIndividual(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject saveMyIndividual(BridgeDataObject bridgeDataObject) 
	{
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge SettingService -  saveMyIndividual method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in saveMyIndividual:"+ e);
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ng.transaction.service.ISettingService#saveMyMerchant(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject saveMyMerchant(BridgeDataObject bridgeDataObject) 
	{
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge SettingService -  saveMyMerchant method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in saveMyMerchant:"+ e);
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ng.transaction.service.ISettingService#saveMyBiller(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject saveMyBiller(BridgeDataObject bridgeDataObject) 
	{
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge SettingService -  saveMyBiller method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in saveMyBiller:"+ e);
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ng.transaction.service.ISettingService#last5Transactions(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject last5Transactions(BridgeDataObject bridgeDataObject) 
	{
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge SettingService -  last5Transactions method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in last5Transactions:"+ e);
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ng.transaction.service.ISettingService#autoTopUp(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject autoTopUp(BridgeDataObject bridgeDataObject) 
	{
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge SettingService -  autoTopUp method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in autoTopUp:"+ e);
		}
		return null;
	}

	@Override
	public BridgeDataObject editMyIndividual(BridgeDataObject bridgeDataObject) {
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge SettingService -  editMyIndividual method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in editMyIndividual:"+ e);
		}
		return null;
	}

	@Override
	public BridgeDataObject editMyMerchant(BridgeDataObject bridgeDataObject) {
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge SettingService -  editMyMerchant method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in editMyMerchant:"+ e);
		}
		return null;
	}

	@Override
	public BridgeDataObject editMyBiller(BridgeDataObject bridgeDataObject) {
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge SettingService -  editMyBiller method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in editMyMerchant:"+ e);
		}
		return null;
	}
	
	@Override
	public BridgeDataObject deleteMyIndividual(BridgeDataObject bridgeDataObject) {
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge SettingService -  deleteMyIndividual method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in deleteMyIndividual:"+ e);
		}
		return null;
	}

	@Override
	public BridgeDataObject deleteMyMerchant(BridgeDataObject bridgeDataObject) {
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge SettingService -  deleteMyMerchant method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in deleteMyMerchant:"+ e);
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ng.transaction.service.ISettingService#deleteMyBiller(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject deleteMyBiller(BridgeDataObject bridgeDataObject) 
	{
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge SettingService -  deleteMyBiller method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in saveMyBiller:"+ e);
		}
		return null;
	}
}
