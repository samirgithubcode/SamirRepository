/**
 * 
 */
package com.ng.bridge.invoker;

import com.ng.sb.common.dataobject.BridgeDataObject;

/**
 * @author gaurav
 * Service Caller 
 */
@FunctionalInterface
public interface IServiceInvoker {
	public BridgeDataObject invoke(String partnerServiceName,BridgeDataObject bridgeDataObject,String methodCallType);
	
}
