/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "userAccounts")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "UserAccounts.findAll", query = "SELECT u FROM UserAccounts u"),
    @NamedQuery(name = "UserAccounts.findById", query = "SELECT u FROM UserAccounts u WHERE u.id = :id"),
    @NamedQuery(name = "UserAccounts.findByMsisdn", query = "SELECT u FROM UserAccounts u WHERE u.msisdn = :msisdn"),
    @NamedQuery(name = "UserAccounts.findByIfscCode", query = "SELECT u FROM UserAccounts u WHERE u.ifscCode = :ifscCode"),
    @NamedQuery(name = "UserAccounts.findByBankAccNumber", query = "SELECT u FROM UserAccounts u WHERE u.bankAccNumber = :bankAccNumber"),
    @NamedQuery(name = "UserAccounts.findByCcNumber", query = "SELECT u FROM UserAccounts u WHERE u.ccNumber = :ccNumber"),
    @NamedQuery(name = "UserAccounts.findByCCName", query = "SELECT u FROM UserAccounts u WHERE u.cCName = :cCName"),
    @NamedQuery(name = "UserAccounts.findByCCExpDate", query = "SELECT u FROM UserAccounts u WHERE u.cCExpDate = :cCExpDate"),
    @NamedQuery(name = "UserAccounts.findByNickName", query = "SELECT u FROM UserAccounts u WHERE u.nickName = :nickName"),
    @NamedQuery(name = "UserAccounts.findByMmid", query = "SELECT u FROM UserAccounts u WHERE u.mmid = :mmid"),
    @NamedQuery(name = "UserAccounts.findByType", query = "SELECT u FROM UserAccounts u WHERE u.type = :type")})
public class UserAccounts implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
    
    @Column(name = "ifscCode", length = 15)
    private String ifscCode;
    @Column(name = "bankAccNumber", length = 25)
    private String bankAccNumber;
    @Column(name = "ccNumber")
    private Integer ccNumber;
    @Basic(optional = false)
    @Column(name = "msisdn", nullable = false, length = 25)
    private String msisdn;
    @Column(name = "CCName", length = 50)
    private String cCName;
    @Column(name = "CCExpDate")
    private Integer cCExpDate;
    @Column(name = "nickName", length = 25)
    private String nickName;
    @Column(name = "mmid")
    private Integer mmid;
    @Column(name = "type", length = 7)
    private String type;
    @JoinColumn(name = "userId", referencedColumnName = "id", nullable = false)
    @ManyToOne(optional = false)
    private Subscriber userId;

    public UserAccounts() {
    	//default constructor
    }

    public UserAccounts(Integer id) {
        this.id = id;
    }

    public UserAccounts(Integer id, String msisdn) {
        this.id = id;
        this.msisdn = msisdn;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMsisdn() {
        return msisdn;
    }

    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }

    public String getIfscCode() {
        return ifscCode;
    }

    public void setIfscCode(String ifscCode) {
        this.ifscCode = ifscCode;
    }

    public String getBankAccNumber() {
        return bankAccNumber;
    }

    public void setBankAccNumber(String bankAccNumber) {
        this.bankAccNumber = bankAccNumber;
    }

    public Integer getCcNumber() {
        return ccNumber;
    }

    public void setCcNumber(Integer ccNumber) {
        this.ccNumber = ccNumber;
    }

    public String getCCName() {
        return cCName;
    }

    public void setCCName(String cCName) {
        this.cCName = cCName;
    }

    public Integer getCCExpDate() {
        return cCExpDate;
    }

    public void setCCExpDate(Integer cCExpDate) {
        this.cCExpDate = cCExpDate;
    }

    public Subscriber getUserId() {
        return userId;
    }

    public void setUserId(Subscriber userId) {
        this.userId = userId;
    }
    
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
    
    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public Integer getMmid() {
        return mmid;
    }

    public void setMmid(Integer mmid) {
        this.mmid = mmid;
    }

    

   

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof UserAccounts)) {
            return false;
        }
        UserAccounts other = (UserAccounts) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.UserAccounts[ id=" + id + " ]";
    }
    
}
