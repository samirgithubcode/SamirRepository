package com.ng.bridge.dataobject.eko;

public class TransactionEnquiryRes {

	private String responseTypeId;

    private String message;

    private String responseStatusId;

    private String status;

    private TransactionEnquiryResData data;

    public TransactionEnquiryResData getData() {
		return data;
	}

	public void setData(TransactionEnquiryResData data) {
		this.data = data;
	}

    public String getMessage ()
    {
        return message;
    }

    public void setMessage (String message)
    {
        this.message = message;
    }

    
    public String getResponseTypeId ()
    {
        return responseTypeId;
    }

    public void setResponseTypeId (String responseTypeId)
    {
        this.responseTypeId = responseTypeId;
    }
    public String getStatus ()
    {
        return status;
    }
    public String getResponseStatusId ()
    {
        return responseStatusId;
    }

    public void setResponseStatusId (String responseStatusId)
    {
        this.responseStatusId = responseStatusId;
    }
    public void setStatus (String status)
    {
        this.status = status;
    }

	

  


}
