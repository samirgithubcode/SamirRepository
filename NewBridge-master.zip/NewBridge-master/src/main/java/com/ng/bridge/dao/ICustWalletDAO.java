package com.ng.bridge.dao;

import com.ng.bridge.exception.GenericException;
import com.ng.sb.common.model.CustMerchFinInstMapping;
import com.ng.sb.common.model.CustMerchPoolTransaction;
import com.ng.sb.common.model.CustMerchTransaction;
import com.ng.sb.common.model.Customer;
import com.ng.sb.common.model.MerchantInfo;
import com.ng.sb.common.model.MerchantIpMapping;
import com.ng.sb.common.model.Partner;


public interface ICustWalletDAO  {
	public MerchantIpMapping checkIp(String ip) throws GenericException;
	public MerchantInfo checkKey(String key) throws GenericException;
	public Partner checkWalletStatus(Integer walletCode) throws GenericException;
	public CustMerchFinInstMapping checkCustomerStatus(Partner wId,String mobileNumber) throws GenericException;
	public CustMerchFinInstMapping getMerchantdetails(MerchantInfo merchantInfo,Partner partner) throws GenericException;
	public CustMerchFinInstMapping updateCustMerchFinInstMappingInfo(CustMerchFinInstMapping custMerchFinInstMapping) throws GenericException;
	public CustMerchPoolTransaction updateCustMerchPoolTransaction(CustMerchPoolTransaction custMerchTransaction) throws GenericException;
	public CustMerchPoolTransaction getTransactionInfo(String transactionId) throws GenericException;
	public CustMerchTransaction getCustMerchTransactionRefund(String previousTransactionId) throws GenericException;
	public CustMerchTransaction saveCustMerchTransaction(CustMerchTransaction custMerchTransaction) throws GenericException;
	public CustMerchTransaction getTransactionInfoByOurId(String transactionId,String status) throws GenericException;
	public CustMerchFinInstMapping checkCustomerStatusForRefund(String mobileNumber) throws GenericException;
	public void saveCustMerchTransactionData(CustMerchTransaction custMerchTransaction)throws GenericException;
	public Customer getCustomerDetails(String mobileNumber) throws GenericException;
}
