package com.ng.sb.common.dataobject;

import java.util.Map;

public class PlatformChain {
	private Map<Integer,String> hostMap;
	private Map<Integer,String> vendorMap;
	private Map<Integer,String> distributorMap;
	private Map<Integer,String> subDistributorMap;
	private Map<Integer,String> retailerMap;
	private Map<Integer,String> bcMap;
	
	private Integer vendorId;
	private Integer hostId;
	private Integer distributorId;
	private Integer subDistributorId;
	private Integer retailerId;
	
	public void setVendorMap(Map<Integer, String> vendorMap) {
		this.vendorMap = vendorMap;
	}
	public Map<Integer, String> getVendorMap() {
		return vendorMap;
	}
	public Integer getHostId() {
		return hostId;
	}
	
	public void setVendorId(Integer vendorId) {
		this.vendorId = vendorId;
	}
	public Integer getVendorId() {
		return vendorId;
	}
	public void setHostId(Integer hostId) {
		this.hostId = hostId;
	}
	public Integer getDistributorId() {
		return distributorId;
	}
	public void setDistributorId(Integer distributorId) {
		this.distributorId = distributorId;
	}
	public Integer getSubDistributorId() {
		return subDistributorId;
	}
	public void setSubDistributorId(Integer subDistributorId) {
		this.subDistributorId = subDistributorId;
	}
	public Integer getRetailerId() {
		return retailerId;
	}
	public void setRetailerId(Integer retailerId) {
		this.retailerId = retailerId;
	}
	public Map<Integer, String> getHostMap() {
		return hostMap;
	}
	public void setHostMap(Map<Integer, String> hostMap) {
		this.hostMap = hostMap;
	}
	public Map<Integer, String> getDistributorMap() {
		return distributorMap;
	}
	public void setDistributorMap(Map<Integer, String> distributorMap) {
		this.distributorMap = distributorMap;
	}
	public Map<Integer, String> getSubDistributorMap() {
		return subDistributorMap;
	}
	public void setSubDistributorMap(Map<Integer, String> subDistributorMap) {
		this.subDistributorMap = subDistributorMap;
	}
	public Map<Integer, String> getRetailerMap() {
		return retailerMap;
	}
	public void setRetailerMap(Map<Integer, String> retailerMap) {
		this.retailerMap = retailerMap;
	}
	public Map<Integer, String> getBcMap() {
		return bcMap;
	}
	public void setBcMap(Map<Integer, String> bcMap) {
		this.bcMap = bcMap;
	}
}
