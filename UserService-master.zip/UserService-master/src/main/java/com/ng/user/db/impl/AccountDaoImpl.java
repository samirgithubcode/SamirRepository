/**
 * 
 */
package com.ng.user.db.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.ng.sb.common.model.AccountLoginInfo;
import com.ng.sb.common.model.AgentApiMapping;
import com.ng.sb.common.model.InternalAccountMaster;
import com.ng.sb.common.util.ExceptionUtils;
import com.ng.sb.common.util.KeyEncryptionUtils;
import com.ng.sb.common.util.TransactionUtils;
import com.ng.sb.common.util.UserType;
import com.ng.user.db.IAccountDao;
import com.ng.user.dto.TxnHistoryRequest;
import com.ng.user.dto.TxnHistoryResponse;
import com.ng.user.logger.UserServiceLogger;
import com.ng.user.utils.CommonUtils;
import com.ng.user.utils.UserServiceConstants;

/**
 * @author gopal
 *
 */
@Transactional
@Repository(value="accountDao")
public class AccountDaoImpl extends BaseDaoImpl implements IAccountDao 
{

	@Override
	public List<TxnHistoryResponse> getTxnHistory(TxnHistoryRequest txnHistoryRequest) 
	{
		List<TxnHistoryResponse> results = new ArrayList<>();
		
	 try{
		 
		 StringBuilder query = null;
		 
		 if(txnHistoryRequest.getUserTypeId() == UserType.AGENT.getUserTypeId())
		 		 query = getAgentQuery(txnHistoryRequest);
		 
		 else if(txnHistoryRequest.getUserTypeId() == UserType.SUBSCRIBER.getUserTypeId())
		         query = getSubscriberQuery(txnHistoryRequest);
				 
		 if(query == null)
			 return results;
			 	 
				 
				 List<Object[]> resultData = createQuery(query.toString());
				 
				 if(resultData != null && !resultData.isEmpty())
				 {
					for(Object[] data : resultData)
					 {
						 
						 TxnHistoryResponse txnHistory = new TxnHistoryResponse();
						 
						 txnHistory.setTxnAmount((data[4] != null)? Double.parseDouble((String)data[4]) : new Double("0.0"));
						 txnHistory.setAppName((data[3] == null)?(String)data[11]:(String)data[3]);
						 txnHistory.setTxnId((String)data[8]);
						 txnHistory.setTxnInstrument((String)data[2]);
						 txnHistory.setTxnRefundRefId((Integer)data[9]);
						 txnHistory.setTxnStatus((Integer)data[7]);
						 txnHistory.setTxnTime((Date)data[5]);
						 txnHistory.setTxnType((String)data[6]);
						
						 
						 txnHistory.setAccessChannel((String)data[10]);
						 
						 txnHistory = getTxnSource(txnHistoryRequest, txnHistory, data);
						 
						 results.add(txnHistory);
					}
				 }
		
	 }catch(Exception e)
	 {
		 String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), UserServiceConstants.PACKAGE_FOR_EXCEPTION);
			
		UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
	 }
		return results;
	}

	private TxnHistoryResponse getTxnSource(TxnHistoryRequest txnHistoryRequest, TxnHistoryResponse txnHistory, Object[] data) 
	{
		if(txnHistoryRequest.getUserTypeId() == UserType.AGENT.getUserTypeId())
		 {
			 txnHistory.setCustomerMsisdn((String)data[1]);
			 //System.out.println(data[0].getClass().getSimpleName());
			 txnHistory.setCustomerName((data[0] == null)?"": new String((byte[])data[0]));
			 
			 txnHistory.setCommAmount((data[12] != null)? Double.parseDouble((String)data[12]) : new Double("0.0"));
			 txnHistory.setNetTxnAmount((data[13] != null)? Double.parseDouble((String)data[13]) : new Double("0.0"));
			 
			 if((boolean)data[14])
				 txnHistory.setTxnStatus(300);
			 
		 }else
		 {
			 
			 txnHistory.setSubscriberName((data[12] == null)?"":new String((byte[])data[12]));
			 txnHistory.setSubscriberNumber((data[13] == null)?"":(String)data[13]);
			 
			 txnHistory.setAgentMsisdn((String)data[1]);
			 txnHistory.setAgentName((String)data[0]);
			 txnHistory.setTransactionNature((data[14] == null)?"":(String)data[14]);
			 txnHistory.setClosingBalance((data[15] != null)?Double.parseDouble((String)data[15]): new Double("0.0"));
			 
			 if(txnHistory.getTxnType() != null && txnHistory.getTxnType().equalsIgnoreCase(TransactionUtils.WALLETTOWALLETTRANSFER.getTransactionTypeName()) && txnHistory.getTransactionNature().equalsIgnoreCase("CR"))
			 {
				 txnHistory.setSubscriberName((data[16] == null)?"":new String((byte[])data[16]));
				 txnHistory.setSubscriberNumber((data[17] == null)?"":(String)data[17]);
			 }
			 
			 txnHistory.setCommAmount((data[18] != null)? Double.parseDouble((String)data[18]) : new Double("0.0"));
			 txnHistory.setNetTxnAmount((data[19] != null)? Double.parseDouble((String)data[19]) : new Double("0.0"));
			 
			 txnHistory.setProductId(((Integer)data[20]).toString());
			 txnHistory.setProductType((String)data[21]);
		 }
		 
		return txnHistory;
	}

	private StringBuilder getAgentQuery(TxnHistoryRequest txnHistoryRequest) 
	{
		StringBuilder query = new StringBuilder();
		
		query.append("Select aes_decrypt(s.name,s.msisdn), s.msisdn, p.productName, pca.paycard_app_name, t.txn_amount, t.transactionOn "
		 		+ ",t.txn_type, t.txn_status,t.ref_txn_id, t.refund_ref_txn_id,case t.access_channel WHEN 1 THEN 'WebSite' WHEN 2 THEN 'MobileClient' WHEN 3 THEN 'PosClient' ELSE 'PosClient' END AS 'access_channel' ,wt.wallet_type_name,t.commission_amount,t.net_txn_amount,t.isRefunded from product_transactions t LEFT JOIN Subscriber s ON "
		 		+ "t.subscriber_id = s.id LEFT JOIN  Products p ON t.product_id=p.id LEFT JOIN paycard_app pca ON t.payCardAppId=pca.id LEFT JOIN wallet_type wt ON t.payCardWalletId = wt.id ");
		 
		 query.append(" where t.txn_type !='Refund' and t.agent_id = "+txnHistoryRequest.getAgentId());
		 
		 return configureQueryParameters(txnHistoryRequest, query);
	}

	private StringBuilder getSubscriberQuery(TxnHistoryRequest txnHistoryRequest) 
	{
		StringBuilder query = new StringBuilder();
		
		/*query.append("Select al.company_name, al.mobileNumber, p.productName, pca.paycard_app_name, t.txn_amount, t.transactionOn "
		 		+ ",t.txn_type, t.txn_status,t.id, t.refund_ref_txn_id,case t.access_channel WHEN 1 THEN 'WebSite' WHEN 2 THEN 'MobileClient' WHEN 3 THEN 'PosClient' ELSE 'PosClient' END AS 'access_channel',wt.wallet_type_name,aes_decrypt(s.name,s.msisdn),s.msisdn,(case when(t.from_user=t.subscriber_id) then 'DR' when(t.to_user=t.subscriber_id) then 'CR' else 'N/A' end),t.closing_balance,(case when(t.txn_type='WalletToWallet') then aes_decrypt(s2.name,s2.msisdn) end),(case when(t.txn_type='WalletToWallet') then s2.msisdn end) from product_transactions t LEFT JOIN accountinfo al ON "
		 		+ "t.agent_company_id = al.Id and al.account_group_id=6 LEFT JOIN Subscriber s ON t.to_user=s.Id LEFT JOIN Subscriber s2 on t.from_user=s2.Id LEFT JOIN  Products p ON t.product_id=p.id LEFT JOIN paycard_app pca ON t.payCardAppId=pca.id LEFT JOIN wallet_type wt ON t.payCardWalletId = wt.id ");*/
		query.append("Select al.company_name, al.mobileNumber, p.productName, pca.paycard_app_name, t.txn_amount, t.transactionOn "
		 		+ ",t.txn_type, t.txn_status,t.ref_txn_id, t.refund_ref_txn_id,case t.access_channel WHEN 1 THEN 'WebSite' WHEN 2 THEN 'MobileClient' WHEN 3 THEN 'PosClient' ELSE 'PosClient' END AS 'access_channel',wt.wallet_type_name,aes_decrypt(s.name,s.msisdn),s.msisdn,(case when(t.from_user=t.subscriber_id) then 'DR' when(t.to_user=t.subscriber_id) then 'CR' else 'N/A' end),t.closing_balance,(case when(t.txn_type='WalletToWallet') then aes_decrypt(s2.name,s2.msisdn) end),(case when(t.txn_type='WalletToWallet') then s2.msisdn end),t.commission_amount,t.net_txn_amount,p.id as 'ProductId',p.type from product_transactions t LEFT JOIN accountinfo al ON "
		 		+ "t.agent_company_id = al.Id and al.account_group_id=6 LEFT JOIN Subscriber s ON t.to_user=s.Id LEFT JOIN Subscriber s2 on t.from_user=s2.Id LEFT JOIN  Products p ON t.product_id=p.id LEFT JOIN paycard_app pca ON t.payCardAppId=pca.id LEFT JOIN wallet_type wt ON t.payCardWalletId = wt.id ");
		
		 query.append(" where t.subscriber_id = "+txnHistoryRequest.getAgentId());
		 
		 return configureQueryParameters(txnHistoryRequest, query);
	}

	private StringBuilder configureQueryParameters(TxnHistoryRequest txnHistoryRequest, StringBuilder query) 
	{
		if(txnHistoryRequest.getStartDate() != null && !txnHistoryRequest.getStartDate().isEmpty() && txnHistoryRequest.getEndDate() != null && !txnHistoryRequest.getEndDate().isEmpty())
		 {
			 query.append(" and date(t.transactionOn) between '"+CommonUtils.getMySqlDateFormat(txnHistoryRequest.getStartDate())+"' and '"+CommonUtils.getMySqlDateFormat(txnHistoryRequest.getEndDate())+"' ");
		 }
		 
		 if(txnHistoryRequest.getSubscriberMsisdn() != null && !txnHistoryRequest.getSubscriberMsisdn().isEmpty())
		 {
			 query.append(" and s.msisdn='"+txnHistoryRequest.getSubscriberMsisdn()+"' ");
		 }
		 
		 if(txnHistoryRequest.getTxnStatus() != null && txnHistoryRequest.getTxnStatus() != 0)
		 {
			 if(txnHistoryRequest.getTxnStatus().intValue() == 500)
				 query.append(" and t.txn_status != 200 ");
			 else
				 query.append(" and t.txn_status="+txnHistoryRequest.getTxnStatus()+" ");
		 }
		 
		 if(txnHistoryRequest.getTxnType() != null && !txnHistoryRequest.getTxnType().isEmpty())
		 {
			 query.append(" and t.txn_type='"+txnHistoryRequest.getTxnType()+"' ");
		 }
		 
		 query.append(" order by t.transactionOn desc limit "+txnHistoryRequest.getTxnCount());
		 
		return query;
	}

	@Override
	public InternalAccountMaster getInternalAccountMaster(String accountNumber, String accountType) 
	{
		InternalAccountMaster accountMaster = null;
		try{
			
			accountMaster = findObjectByNamedQuery("InternalAccountMaster.findByAccountNumbernType", createMapForQueryParams(
							new String[] { "accountNumber", "accountType" },
							new Object[] { Long.parseLong(accountNumber), accountType }), InternalAccountMaster.class);
			
			
		}catch(Exception e)
		{
			UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, "[getInternalAccountMaster] [ACCOUNT_NUMBER] "+accountNumber+ " [ERROR_MESSAGE] " +e);
			
		}
		
		return accountMaster;
	}

	@Override
	public List<AgentApiMapping> getServiceMappings(AccountLoginInfo accountLoginInfo) 
	{
		List<AgentApiMapping> apiMapping = null;
		try{
			
			apiMapping = findByNamedQuery("AgentApiMapping.findServicesByAgent", 
							new String[] { "agentId" },
							new Object[] { accountLoginInfo });
			
			
			if(apiMapping == null || (apiMapping != null && apiMapping.isEmpty()))
			{
				apiMapping = findByNamedQuery("AgentApiMapping.findServicesByAgentCompany", 
						new String[] { "agentCompanyId" },
						new Object[] { accountLoginInfo.getAccountId() });
			}
			
		}catch(Exception e)
		{
			UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, "[getServiceMappings] [MOBILE_NUMBER] "+accountLoginInfo.getMobileNumber()+ " [ERROR_MESSAGE] " +e);
			
		}
		
		return apiMapping;
	}

}
