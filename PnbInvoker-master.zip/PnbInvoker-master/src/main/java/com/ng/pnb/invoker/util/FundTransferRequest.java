package com.ng.pnb.invoker.util;

public class FundTransferRequest {

	private FundTransferData data;
	
	private FTHeader header;

	public FundTransferData getData() {
		return data;
	}

	public void setData(FundTransferData data) {
		this.data = data;
	}

	public FTHeader getHeader() {
		return header;
	}

	public void setHeader(FTHeader header) {
		this.header = header;
	}
	
	
}

class FTHeader{
	
	private AuthorizationDetails authorizationDetails;

	public AuthorizationDetails getAuthorizationDetails() {
		return authorizationDetails;
	}

	public void setAuthorizationDetails(AuthorizationDetails authorizationDetails) {
		this.authorizationDetails = authorizationDetails;
	}
	
	
	
}
