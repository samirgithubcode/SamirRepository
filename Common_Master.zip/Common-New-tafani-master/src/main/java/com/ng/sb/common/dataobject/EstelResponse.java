package com.ng.sb.common.dataobject;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement(name="estel")
public class EstelResponse {
	private EstelHeader header;
	private EstelResponseObject response;
	@XmlElement(name="header")
	public EstelHeader getHeader() {
		return header;
	}
	public void setHeader(EstelHeader header) {
		this.header = header;
	}
	@XmlElement(name="response")
	public EstelResponseObject getResponse() {
		return response;
	}
	public void setResponse(EstelResponseObject response) {
		this.response = response;
	}
	

}
