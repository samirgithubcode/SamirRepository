/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author amardeep
 */
@Entity
@Table(name = "MerchantAccountLoginInfoHistory")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "MerchantAccountLoginInfoHistory.findAll", query = "SELECT m FROM MerchantAccountLoginInfoHistory m"),
    @NamedQuery(name = "MerchantAccountLoginInfoHistory.findById", query = "SELECT m FROM MerchantAccountLoginInfoHistory m WHERE m.id = :id"),
    @NamedQuery(name = "MerchantAccountLoginInfoHistory.findByContactPersonName", query = "SELECT m FROM MerchantAccountLoginInfoHistory m WHERE m.contactPersonName = :contactPersonName"),
    @NamedQuery(name = "MerchantAccountLoginInfoHistory.findByMobileNumber", query = "SELECT m FROM MerchantAccountLoginInfoHistory m WHERE m.mobileNumber = :mobileNumber"),
    @NamedQuery(name = "MerchantAccountLoginInfoHistory.findByDateOfBirth", query = "SELECT m FROM MerchantAccountLoginInfoHistory m WHERE m.dateOfBirth = :dateOfBirth"),
    @NamedQuery(name = "MerchantAccountLoginInfoHistory.findBySecurityQuestion", query = "SELECT m FROM MerchantAccountLoginInfoHistory m WHERE m.securityQuestion = :securityQuestion"),
    @NamedQuery(name = "MerchantAccountLoginInfoHistory.findBySecurityAnswer", query = "SELECT m FROM MerchantAccountLoginInfoHistory m WHERE m.securityAnswer = :securityAnswer"),
    @NamedQuery(name = "MerchantAccountLoginInfoHistory.findByEmailId", query = "SELECT m FROM MerchantAccountLoginInfoHistory m WHERE m.emailId = :emailId"),
    @NamedQuery(name = "MerchantAccountLoginInfoHistory.findByLoginName", query = "SELECT m FROM MerchantAccountLoginInfoHistory m WHERE m.loginName = :loginName"),
    @NamedQuery(name = "MerchantAccountLoginInfoHistory.findByUserPassword", query = "SELECT m FROM MerchantAccountLoginInfoHistory m WHERE m.userPassword = :userPassword"),
    @NamedQuery(name = "MerchantAccountLoginInfoHistory.findByInvalidLoginCount", query = "SELECT m FROM MerchantAccountLoginInfoHistory m WHERE m.invalidLoginCount = :invalidLoginCount"),
    @NamedQuery(name = "MerchantAccountLoginInfoHistory.findByStatus", query = "SELECT m FROM MerchantAccountLoginInfoHistory m WHERE m.status = :status"),
    @NamedQuery(name = "MerchantAccountLoginInfoHistory.findByFirstTimeLogin", query = "SELECT m FROM MerchantAccountLoginInfoHistory m WHERE m.firstTimeLogin = :firstTimeLogin")})
public class MerchantAccountLoginInfoHistory implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "contactPersonName")
    private String contactPersonName;
    @Basic(optional = false)
    @Column(name = "mobileNumber")
    private String mobileNumber;
    @Column(name = "dateOfBirth")
    @Temporal(TemporalType.DATE)
    private Date dateOfBirth;
    @Column(name = "securityQuestion")
    private String securityQuestion;
    @Column(name = "securityAnswer")
    private String securityAnswer;
    @Basic(optional = false)
    @Column(name = "emailId")
    private String emailId;
    @Basic(optional = false)
    @Column(name = "login_name")
    private String loginName;
    @Basic(optional = false)
    @Column(name = "user_password")
    private String userPassword;
    @Basic(optional = false)
    @Column(name = "invalid_login_count")
    private int invalidLoginCount;
    @Basic(optional = false)
    @Column(name = "status")
    private boolean status;
    @Column(name = "first_time_login")
    private Boolean firstTimeLogin;
    @JoinColumn(name = "rtId", referencedColumnName = "id")
    @ManyToOne
    private AccountInfo rtId;
    @JoinColumn(name = "bcId", referencedColumnName = "id")
    @ManyToOne
    private AccountInfo bcId;
    @JoinColumn(name = "sdId", referencedColumnName = "id")
    @ManyToOne
    private AccountInfo sdId;
    @JoinColumn(name = "dId", referencedColumnName = "id")
    @ManyToOne
    private AccountInfo dId;
    @JoinColumn(name = "hId", referencedColumnName = "id")
    @ManyToOne
    private AccountInfo hId;
    @JoinColumn(name = "accountTypeId", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private SysAccountType accountTypeId;
    @JoinColumn(name = "account_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private AccountInfo accountId;

    public MerchantAccountLoginInfoHistory() {
    	//default constructor
    }

    public MerchantAccountLoginInfoHistory(Integer id) {
        this.id = id;
    }

    public MerchantAccountLoginInfoHistory(Integer id, String contactPersonName, String mobileNumber, String emailId, String loginName, String userPassword, int invalidLoginCount) {
        this.id = id;
        this.contactPersonName = contactPersonName;
        this.mobileNumber = mobileNumber;
        this.emailId = emailId;
        this.loginName = loginName;
        this.userPassword = userPassword;
        this.invalidLoginCount = invalidLoginCount;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getContactPersonName() {
        return contactPersonName;
    }

    public void setContactPersonName(String contactPersonName) {
        this.contactPersonName = contactPersonName;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getSecurityQuestion() {
        return securityQuestion;
    }

    public void setSecurityQuestion(String securityQuestion) {
        this.securityQuestion = securityQuestion;
    }

    public String getSecurityAnswer() {
        return securityAnswer;
    }

    public void setSecurityAnswer(String securityAnswer) {
        this.securityAnswer = securityAnswer;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }

    public int getInvalidLoginCount() {
        return invalidLoginCount;
    }

    public void setInvalidLoginCount(int invalidLoginCount) {
        this.invalidLoginCount = invalidLoginCount;
    }

    public boolean getStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public Boolean getFirstTimeLogin() {
        return firstTimeLogin;
    }

    public void setFirstTimeLogin(Boolean firstTimeLogin) {
        this.firstTimeLogin = firstTimeLogin;
    }

    public AccountInfo getRtId() {
        return rtId;
    }

    public void setRtId(AccountInfo rtId) {
        this.rtId = rtId;
    }

    public AccountInfo getBcId() {
        return bcId;
    }

    public void setBcId(AccountInfo bcId) {
        this.bcId = bcId;
    }

    public AccountInfo getSdId() {
        return sdId;
    }

    public void setSdId(AccountInfo sdId) {
        this.sdId = sdId;
    }

    public AccountInfo getDId() {
        return dId;
    }

    public void setDId(AccountInfo dId) {
        this.dId = dId;
    }

    public AccountInfo getHId() {
        return hId;
    }

    public void setHId(AccountInfo hId) {
        this.hId = hId;
    }

    public SysAccountType getAccountTypeId() {
        return accountTypeId;
    }

    public void setAccountTypeId(SysAccountType accountTypeId) {
        this.accountTypeId = accountTypeId;
    }

    public AccountInfo getAccountId() {
        return accountId;
    }

    public void setAccountId(AccountInfo accountId) {
        this.accountId = accountId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof MerchantAccountLoginInfoHistory)) {
            return false;
        }
        MerchantAccountLoginInfoHistory other = (MerchantAccountLoginInfoHistory) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.MerchantAccountLoginInfoHistory[ id=" + id + " ]";
    }
    
}
