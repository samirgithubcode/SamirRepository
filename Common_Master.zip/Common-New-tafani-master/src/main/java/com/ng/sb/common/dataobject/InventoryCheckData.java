package com.ng.sb.common.dataobject;

import java.util.List;
import java.util.Map;

/**
 * @author abhishek
 *
 */
public class InventoryCheckData extends BaseObjectData { 
	private static final long serialVersionUID = 1L; 
	private Map<Integer,String> productList;
	private Map<Integer,String> masterVersionList;
	private Map<Integer,String> orderList;
	private Integer product;
	private Integer masterVersion;
	private String mainSeriesFrom;
	private String mainSeriesTo;
	private String boxNo;
	private String boxFrom;
	private String boxTo;
	private Integer boxSize;
	private Integer availableUnits;
	private String productName;
	private String productDescription;
	private String masterVersions;
	private String po;
	private List<InventoryCheckData> data;
	private Integer loginId;
	private Integer orderNo;
	
	public Integer getProduct() {
		return product;
	}

	public void setProduct(Integer product) {
		this.product = product;
	}

	public Integer getMasterVersion() {
		return masterVersion;
	}

	public void setMasterVersion(Integer masterVersion) {
		this.masterVersion = masterVersion;
	}

	public Map<Integer, String> getMasterVersionList() {
		return masterVersionList;
	}
	
	public void setMasterVersionList(Map<Integer, String> masterVersionList) {
		this.masterVersionList = masterVersionList;
	}
	
	public Map<Integer, String> getOrderList() {
		return orderList;
	}

	public void setOrderList(Map<Integer, String> orderList) {
		this.orderList = orderList;
	}

	public Map<Integer, String> getProductList() {
		return productList;
	}
	
	public void setProductList(Map<Integer, String> productList) {
		this.productList = productList;
	}

	public String getMainSeriesFrom() {
		return mainSeriesFrom;
	}

	public void setMainSeriesFrom(String mainSeriesFrom) {
		this.mainSeriesFrom = mainSeriesFrom;
	}

	public String getMainSeriesTo() {
		return mainSeriesTo;
	}

	public void setMainSeriesTo(String mainSeriesTo) {
		this.mainSeriesTo = mainSeriesTo;
	}

	public String getBoxNo() {
		return boxNo;
	}

	public void setBoxNo(String boxNo) {
		this.boxNo = boxNo;
	}

	public String getBoxFrom() {
		return boxFrom;
	}

	public void setBoxFrom(String boxFrom) {
		this.boxFrom = boxFrom;
	}

	public String getBoxTo() {
		return boxTo;
	}

	public void setBoxTo(String boxTo) {
		this.boxTo = boxTo;
	}

	public Integer getBoxSize() {
		return boxSize;
	}

	public void setBoxSize(Integer boxSize) {
		this.boxSize = boxSize;
	}

	public Integer getAvailableUnits() {
		return availableUnits;
	}

	public void setAvailableUnits(Integer availableUnits) {
		this.availableUnits = availableUnits;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public String getMasterVersions() {
		return masterVersions;
	}

	public void setMasterVersions(String masterVersions) {
		this.masterVersions = masterVersions;
	}

	public String getPo() {
		return po;
	}

	public void setPo(String po) {
		this.po = po;
	}
	
	public List<InventoryCheckData> getData() {
		return data;
	}

	public void setData(List<InventoryCheckData> data) {
		this.data = data;
	}

	public Integer getLoginId() {
		return loginId;
	}

	public void setLoginId(Integer loginId) {
		this.loginId = loginId;
	}

	public Integer getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(Integer orderNo) {
		this.orderNo = orderNo;
	}
}
