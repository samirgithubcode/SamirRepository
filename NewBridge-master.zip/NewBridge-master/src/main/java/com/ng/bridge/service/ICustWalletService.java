package com.ng.bridge.service;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.ng.bridge.exception.GenericException;
import com.ng.sb.common.dataobject.WalletRequestData;
import com.ng.sb.common.dataobject.WalletResponseData;
import com.ng.sb.common.dataobject.WalletResponseWrapperData;
@Component
public interface ICustWalletService {
		public Boolean transactionTimeOut(Integer timeInSeconds,String transactionId) throws GenericException;
		public Boolean allTransactionTimeOut() throws GenericException; 
		public WalletResponseWrapperData validateWallet(WalletRequestData walletRequestData) throws GenericException;
		public WalletResponseData validateWallet(String ip,WalletRequestData walletRequestData) throws GenericException;
		public boolean reversal(String transactionId,String reason) throws GenericException;
		public WalletResponseWrapperData refundAmount(String ip, WalletRequestData walletRequestData) throws GenericException;
		public WalletResponseWrapperData deductBalance(String ip,WalletRequestData walletRequestData) throws GenericException;
		public WalletResponseWrapperData cancelRequest(String ip,WalletRequestData walletRequestData) throws GenericException;
		public WalletResponseWrapperData checkBalance(String ipaddress, WalletRequestData walletRequestData) throws GenericException;
		public Map<String,String> deductBalanceForTransaction(Integer walletType,String customerMobNumber,Integer amount) throws GenericException;
		public Map<String,String> getBalanceForTransaction(Integer walletType,String customerMobNumber) throws GenericException;
}
