/**
 * 
 */
package com.ng.transaction.dao;

/**
 * @author gaurav
 *
 */
public interface IChequeDAO extends IOtherBankingDAO {

}
