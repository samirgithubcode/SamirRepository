/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "ticket_query_assignment_history")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "TicketQueryAssignmentHistory.findAll", query = "SELECT t FROM TicketQueryAssignmentHistory t"),
    @NamedQuery(name = "TicketQueryAssignmentHistory.findById", query = "SELECT t FROM TicketQueryAssignmentHistory t WHERE t.id = :id"),
    @NamedQuery(name = "TicketQueryAssignmentHistory.findByTechnicalPesonId", query = "SELECT t FROM TicketQueryAssignmentHistory t WHERE t.technicalPesonId = :technicalPesonId"),
    @NamedQuery(name = "TicketQueryAssignmentHistory.findByAccountTypeId", query = "SELECT t FROM TicketQueryAssignmentHistory t WHERE t.accountTypeId = :accountTypeId"),
    @NamedQuery(name = "TicketQueryAssignmentHistory.findByNewTechnicalPesonId", query = "SELECT t FROM TicketQueryAssignmentHistory t WHERE t.newTechnicalPesonId = :newTechnicalPesonId"),
    @NamedQuery(name = "TicketQueryAssignmentHistory.findByNewAccountTypeId", query = "SELECT t FROM TicketQueryAssignmentHistory t WHERE t.newAccountTypeId = :newAccountTypeId"),
    @NamedQuery(name = "TicketQueryAssignmentHistory.findBySolutionDetail", query = "SELECT t FROM TicketQueryAssignmentHistory t WHERE t.solutionDetail = :solutionDetail"),
    @NamedQuery(name = "TicketQueryAssignmentHistory.findByQueryStatus", query = "SELECT t FROM TicketQueryAssignmentHistory t WHERE t.queryStatus = :queryStatus"),
    @NamedQuery(name = "TicketQueryAssignmentHistory.findByQueryAssignDate", query = "SELECT t FROM TicketQueryAssignmentHistory t WHERE t.queryAssignDate = :queryAssignDate"),
    @NamedQuery(name = "TicketQueryAssignmentHistory.findByQueryCloseDate", query = "SELECT t FROM TicketQueryAssignmentHistory t WHERE t.queryCloseDate = :queryCloseDate"),
    @NamedQuery(name = "TicketQueryAssignmentHistory.findByQueryReassignReopenDate", query = "SELECT t FROM TicketQueryAssignmentHistory t WHERE t.queryReassignReopenDate = :queryReassignReopenDate"),
    @NamedQuery(name = "TicketQueryAssignmentHistory.findByQueryReassignReopenReason", query = "SELECT t FROM TicketQueryAssignmentHistory t WHERE t.queryReassignReopenReason = :queryReassignReopenReason"),
    @NamedQuery(name = "TicketQueryAssignmentHistory.findByAddDate", query = "SELECT t FROM TicketQueryAssignmentHistory t WHERE t.addDate = :addDate"),
    @NamedQuery(name = "TicketQueryAssignmentHistory.findByAddByRoleId", query = "SELECT t FROM TicketQueryAssignmentHistory t WHERE t.addByRoleId = :addByRoleId")})
public class TicketQueryAssignmentHistory implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
    @Basic(optional = false)
    @Column(name = "technical_peson_id", nullable = false)
    private int technicalPesonId;
    @Basic(optional = false)
    @Column(name = "account_type_id", nullable = false)
    private int accountTypeId;
    @Basic(optional = false)
    @Column(name = "solution_detail", nullable = false, length = 200)
    private String solutionDetail;
    @Basic(optional = false)
    @Column(name = "new_technical_peson_id", nullable = false)
    private int newTechnicalPesonId;
    @Basic(optional = false)
    @Column(name = "new_account_type_id", nullable = false)
    private int newAccountTypeId;
   
    
    @Basic(optional = false)
    @Column(name = "query_assign_date", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date queryAssignDate;
    @Basic(optional = false)
    @Column(name = "query_close_date", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date queryCloseDate;
    @Basic(optional = false)
    @Column(name = "query_reassign_reopen_date", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date queryReassignReopenDate;
    @Basic(optional = false)
    @Column(name = "query_reassign_reopen_reason", nullable = false, length = 200)
    private String queryReassignReopenReason;
    @Basic(optional = false)
    @Column(name = "add_date", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date addDate;
    @Basic(optional = false)
    @Column(name = "query_status", nullable = false, length = 20)
    private String queryStatus;
    @Basic(optional = false)
    @Column(name = "add_by_role_id", nullable = false)
    private int addByRoleId;
    @JoinColumn(name = "query_assign_info_id", referencedColumnName = "id", nullable = false)
    @ManyToOne(optional = false)
    private TicketQueryAssignmentInfo queryAssignInfoId;
    @JoinColumn(name = "query_id", referencedColumnName = "id", nullable = false)
    @ManyToOne(optional = false)
    private TicketQueryDetails queryId;
    @JoinColumn(name = "ticket_id", referencedColumnName = "ticket_id", nullable = false)
    @ManyToOne(optional = false)
    private CustomerComplaintInfo ticketId;

    public TicketQueryAssignmentHistory() {
    	//default constructor
    }

    public TicketQueryAssignmentHistory(Integer id) {
        this.id = id;
    }

    public TicketQueryAssignmentHistory(Integer id, int technicalPesonId, int accountTypeId, int newTechnicalPesonId, int newAccountTypeId, String solutionDetail, String queryStatus) {
        this.id = id;
        this.technicalPesonId = technicalPesonId;
        this.accountTypeId = accountTypeId;
        this.newTechnicalPesonId = newTechnicalPesonId;
        this.newAccountTypeId = newAccountTypeId;
        this.solutionDetail = solutionDetail;
        this.queryStatus = queryStatus;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public int getTechnicalPesonId() {
        return technicalPesonId;
    }

    public void setTechnicalPesonId(int technicalPesonId) {
        this.technicalPesonId = technicalPesonId;
    }

    public int getAccountTypeId() {
        return accountTypeId;
    }

    public void setAccountTypeId(int accountTypeId) {
        this.accountTypeId = accountTypeId;
    }

    public int getNewTechnicalPesonId() {
        return newTechnicalPesonId;
    }

    public void setNewTechnicalPesonId(int newTechnicalPesonId) {
        this.newTechnicalPesonId = newTechnicalPesonId;
    }

    public int getNewAccountTypeId() {
        return newAccountTypeId;
    }

    public void setNewAccountTypeId(int newAccountTypeId) {
        this.newAccountTypeId = newAccountTypeId;
    }

    public String getSolutionDetail() {
        return solutionDetail;
    }

    public void setSolutionDetail(String solutionDetail) {
        this.solutionDetail = solutionDetail;
    }

    public String getQueryStatus() {
        return queryStatus;
    }

    public void setQueryStatus(String queryStatus) {
        this.queryStatus = queryStatus;
    }

    public Date getQueryAssignDate() {
        return queryAssignDate;
    }

    public void setQueryAssignDate(Date queryAssignDate) {
        this.queryAssignDate = queryAssignDate;
    }

    public Date getQueryCloseDate() {
        return queryCloseDate;
    }

    public void setQueryCloseDate(Date queryCloseDate) {
        this.queryCloseDate = queryCloseDate;
    }

    public Date getQueryReassignReopenDate() {
        return queryReassignReopenDate;
    }

    public void setQueryReassignReopenDate(Date queryReassignReopenDate) {
        this.queryReassignReopenDate = queryReassignReopenDate;
    }

    public String getQueryReassignReopenReason() {
        return queryReassignReopenReason;
    }

    public void setQueryReassignReopenReason(String queryReassignReopenReason) {
        this.queryReassignReopenReason = queryReassignReopenReason;
    }

    public Date getAddDate() {
        return addDate;
    }

    public void setAddDate(Date addDate) {
        this.addDate = addDate;
    }

    public int getAddByRoleId() {
        return addByRoleId;
    }

    public void setAddByRoleId(int addByRoleId) {
        this.addByRoleId = addByRoleId;
    }

    public TicketQueryAssignmentInfo getQueryAssignInfoId() {
        return queryAssignInfoId;
    }

    public void setQueryAssignInfoId(TicketQueryAssignmentInfo queryAssignInfoId) {
        this.queryAssignInfoId = queryAssignInfoId;
    }

    public TicketQueryDetails getQueryId() {
        return queryId;
    }

    public void setQueryId(TicketQueryDetails queryId) {
        this.queryId = queryId;
    }

    public CustomerComplaintInfo getTicketId() {
        return ticketId;
    }

    public void setTicketId(CustomerComplaintInfo ticketId) {
        this.ticketId = ticketId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof TicketQueryAssignmentHistory)) {
            return false;
        }
        TicketQueryAssignmentHistory other = (TicketQueryAssignmentHistory) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.TicketQueryAssignmentHistory[ id=" + id + " ]";
    }
    
}
