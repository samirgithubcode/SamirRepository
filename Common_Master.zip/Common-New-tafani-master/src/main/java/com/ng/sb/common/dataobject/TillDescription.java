package com.ng.sb.common.dataobject;

public class TillDescription {
 private String tillName;
 private String tillDesc;
 private String tillId;
 
 public String getTillName() {
  return tillName;
 }
 public void setTillName(String tillName) {
  this.tillName = tillName;
 }
 public String getTillDesc() {
  return tillDesc;
 }
 public void setTillDesc(String tillDesc) {
  this.tillDesc = tillDesc;
 }
 public String getTillId() {
  return tillId;
 }
public void setTillId(String tillId) {
	this.tillId = tillId;
}
}