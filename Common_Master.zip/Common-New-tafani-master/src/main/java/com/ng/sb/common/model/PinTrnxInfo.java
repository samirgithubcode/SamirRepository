/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "PinTrnxInfo")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "PinTrnxInfo.findAll", query = "SELECT p FROM PinTrnxInfo p"),
    @NamedQuery(name = "PinTrnxInfo.findById", query = "SELECT p FROM PinTrnxInfo p WHERE p.id = :id"),
    @NamedQuery(name = "PinTrnxInfo.findByTrnxId", query = "SELECT p FROM PinTrnxInfo p WHERE p.trnxId = :trnxId"),
    @NamedQuery(name = "PinTrnxInfo.findByCommission", query = "SELECT p FROM PinTrnxInfo p WHERE p.grossCommission = :commission"),
    @NamedQuery(name = "PinTrnxInfo.findByNetCommission", query = "SELECT p FROM PinTrnxInfo p WHERE p.netCommission = :netCommission"),
    @NamedQuery(name = "PinTrnxInfo.findByNetAmount", query = "SELECT p FROM PinTrnxInfo p WHERE p.netAmount = :netAmount"),
    @NamedQuery(name = "PinTrnxInfo.findByStatus", query = "SELECT p FROM PinTrnxInfo p WHERE p.status = :status"),
    @NamedQuery(name = "PinTrnxInfo.findByPinSerialNumber", query="SELECT p FROM PinTrnxInfo p WHERE p.pinSerialNumber = :pinSerialNumber"),
    @NamedQuery(name = "PinTrnxInfo.findByTransactionId", query = "SELECT p FROM PinTrnxInfo p WHERE p.pinTrnxId = :pinTrnxId"),
    })
public class PinTrnxInfo implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "trnxId")
    private String trnxId;
    @Basic(optional = false)
    @Column(name = "pinSerialNumber")
    private Long pinSerialNumber;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "grossCommission")
    private Float grossCommission;
    @Column(name = "netCommission")
    private Float netCommission;
    @Column(name = "netAmount")
    private Float netAmount;
    @Column(name = "status")
    private String status;
    @JoinColumn(name = "pinTrnxId", referencedColumnName = "id")
    @ManyToOne(cascade = CascadeType.ALL,optional = false)
    private PinTransaction pinTrnxId;
    @JoinColumn(name = "denominationId", referencedColumnName = "id")
    @ManyToOne
    private Denomination denominationId;

    public PinTrnxInfo() {
    	//empty
    }

    public PinTrnxInfo(Integer id) {
        this.id = id;
    }

    public PinTrnxInfo(Integer id, String trnxId, Long pinSerialNumber) {
        this.id = id;
        this.trnxId = trnxId;
        this.pinSerialNumber = pinSerialNumber;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTrnxId() {
        return trnxId;
    }

    public void setTrnxId(String trnxId) {
        this.trnxId = trnxId;
    }

    public Long getPinSerialNumber() {
		return pinSerialNumber;
	}

	public void setPinSerialNumber(Long pinSerialNumber) {
		this.pinSerialNumber = pinSerialNumber;
	}

    public Float getGrossCommission() {
        return grossCommission;
    }

    public void setGrossCommission(Float grossCommission) {
        this.grossCommission = grossCommission;
    }

    public Float getNetCommission() {
		return netCommission;
	}

	public void setNetCommission(Float netCommission) {
		this.netCommission = netCommission;
	}

	public Float getNetAmount() {
        return netAmount;
    }

    public void setNetAmount(Float netAmount) {
        this.netAmount = netAmount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public PinTransaction getPinTrnxId() {
        return pinTrnxId;
    }

    public void setPinTrnxId(PinTransaction pinTrnxId) {
        this.pinTrnxId = pinTrnxId;
    }

    public Denomination getDenominationId() {
        return denominationId;
    }

    public void setDenominationId(Denomination denominationId) {
        this.denominationId = denominationId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof PinTrnxInfo)) {
            return false;
        }
        PinTrnxInfo other = (PinTrnxInfo) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.PinTrnxInfo[ id=" + id + " ]";
    }
    
}
