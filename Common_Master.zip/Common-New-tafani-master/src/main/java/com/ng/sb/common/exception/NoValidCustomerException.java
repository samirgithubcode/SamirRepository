package com.ng.sb.common.exception;

public class NoValidCustomerException  extends Exception {
	private static final long serialVersionUID = 1L;
	
	public NoValidCustomerException(String message){
		super(message);
	}
}