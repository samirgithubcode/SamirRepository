package com.ng.sb.common.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * @author abhishek
 *
 */
@Entity
@Table(name="MappingType")
@NamedQuery(name="MappingType.findAll", query="SELECT m FROM MappingType m")
public class MappingType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Basic(optional = false)
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true)
	private Integer id;
	
	@Basic(optional = false)
	@Column(name="description",length=75)
	private String description;
	
	@Basic(optional = false)
	@Column(name="mapping_name", length=30)
	private String mappingName;

	public MappingType() {
		//default constructor
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getMappingName() {
		return this.mappingName;
	}

	public void setMappingName(String mappingName) {
		this.mappingName = mappingName;
	}

}