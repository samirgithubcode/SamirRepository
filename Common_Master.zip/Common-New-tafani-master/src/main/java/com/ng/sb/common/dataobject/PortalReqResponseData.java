package com.ng.sb.common.dataobject;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="PortalReqResponseData")
public class PortalReqResponseData extends BaseObjectData {
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
private String message;

public String getMessage() {
	return message;
}

public void setMessage(String message) {
	this.message = message;
}
}
