package com.ng.bridge.dataobject.eko;

public class AddRecipientResData {
	 private String recipientidtype;

	    private String recipientid;

	    private String recipientmobile;

	    public String getRecipientidtype ()
	    {
	        return recipientidtype;
	    }

	    public void setRecipientidtype (String recipientidtype)
	    {
	        this.recipientidtype = recipientidtype;
	    }

	    public String getRecipientid ()
	    {
	        return recipientid;
	    }

	    public void setRecipientid (String recipientid)
	    {
	        this.recipientid = recipientid;
	    }

	    public String getRecipientmobile ()
	    {
	        return recipientmobile;
	    }

	    public void setRecipientmobile (String recipientmobile)
	    {
	        this.recipientmobile = recipientmobile;
	    }

	    @Override
	    public String toString()
	    {
	        return "ClassPojo [recipientidtype = "+recipientidtype+", recipientid = "+recipientid+", recipientmobile = "+recipientmobile+"]";
	    }
}
