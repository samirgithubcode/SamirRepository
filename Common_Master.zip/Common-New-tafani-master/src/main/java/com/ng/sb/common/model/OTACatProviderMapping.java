/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "OTACatProviderMapping")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "OTACatProviderMapping.findAll", query = "SELECT o FROM OTACatProviderMapping o"),
    @NamedQuery(name = "OTACatProviderMapping.findById", query = "SELECT o FROM OTACatProviderMapping o WHERE o.id = :id"),
    @NamedQuery(name = "OTACatProviderMapping.findByCategoryName", query = "SELECT o FROM OTACatProviderMapping o WHERE o.categoryName = :categoryName"),
    @NamedQuery(name = "OTACatProviderMapping.findByCategoryAndOtaMgmt", query = "SELECT o FROM OTACatProviderMapping o WHERE o.categoryId = :categoryId AND o.otaMgmtId = :otaMgmtId And o.providerId IS NULL"),
    @NamedQuery(name = "OTACatProviderMapping.findByProviderName", query = "SELECT o FROM OTACatProviderMapping o WHERE o.providerName = :providerName")})
public class OTACatProviderMapping implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Column(name = "categoryName")
    private String categoryName;
    @Column(name = "providerName")
    private String providerName;
    @JoinColumn(name = "providerId", referencedColumnName = "id")
    @ManyToOne
    private Provider providerId;
    @JoinColumn(name = "categoryId", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Categories categoryId;
    @JoinColumn(name = "otaMgmtId", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private OTAManagement otaMgmtId;

    public OTACatProviderMapping() {
    	//empty
    }

    public OTACatProviderMapping(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getProviderName() {
        return providerName;
    }

    public void setProviderName(String providerName) {
        this.providerName = providerName;
    }

    public Provider getProviderId() {
        return providerId;
    }

    public void setProviderId(Provider providerId) {
        this.providerId = providerId;
    }

    public Categories getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Categories categoryId) {
        this.categoryId = categoryId;
    }

    public OTAManagement getOtaMgmtId() {
        return otaMgmtId;
    }

    public void setOtaMgmtId(OTAManagement otaMgmtId) {
        this.otaMgmtId = otaMgmtId;
    }

   

    @Override
    public boolean equals(Object object) {
    	boolean check=true;
    	if(object!=null){
        if (!(object instanceof OTACatProviderMapping)) {
        	check= false;
        }
        
        
        OTACatProviderMapping other = (OTACatProviderMapping) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
    	}
        return check;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }
    @Override
    public String toString() {
        return "com.ng.sb.common.model.OTACatProviderMapping[ id=" + id + " ]";
    }
    
}
