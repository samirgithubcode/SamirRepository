package com.ng.sb.common.dataobject;

import java.util.Date;

public class FileExportDetailsData extends BaseObjectData {

	private static final long serialVersionUID = 1L;
	private Integer denominator;
	private Integer quantity;
	private Date expiryDate;
	public Integer getDenominator() {
		return denominator;
	}
	public void setDenominator(Integer denominator) {
		this.denominator = denominator;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public Date getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

}
