package com.ng.sb.common.dataobject;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.ng.sb.common.model.Categories;
import com.ng.sb.common.model.ServiceConfig;

public class MasterVersionData extends BaseObjectData {

	private static final long serialVersionUID = 1L;

	private int mVersionCode;
	private String mVersionName;
	private String mVersionDecsription;
	private Date createdOn;
	private String createdBy;
	private Map<Map<Integer,String>,Map<String,String>> categoryProviderMap;
	private List<String> categoryProviderList;
	private Integer mvId;
	private String []  providers;
	private String  smscode;
	private String walletType;
	private Integer[] walletcheckBoxName;
	private List<PartnerData> noofwallets;
	private String[] walletpriority;
	private Map<String,Integer> mapnoofwallet;
	private List<PartnerData> walletdata;
	private List<ServiceConfig> services;
	private List<String> serviceArray;
	private Set<Categories> categoryId;
	private Set<Integer> allocatedServiceIds;
	private Integer status;
	
	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Set<Integer> getAllocatedServiceIds() {
		return allocatedServiceIds;
	}

	public void setAllocatedServiceIds(Set<Integer> allocatedServiceIds) {
		this.allocatedServiceIds = allocatedServiceIds;
	}

	public Set<Categories> getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(Set<Categories> categoryId) {
		this.categoryId = categoryId;
	}

	public List<String> getServiceArray() {
		return serviceArray;
	}

	public void setServiceArray(List<String> serviceArray) {
		this.serviceArray = serviceArray;
	}

	public List<ServiceConfig> getServices() {
		return services;
	}

	public void setServices(List<ServiceConfig> services) {
		this.services = services;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}


	public String[] getWalletpriority() {
		return walletpriority;
	}

	public void setWalletpriority(String[] walletpriority) {
		this.walletpriority = walletpriority;
	}


	public Map<String, Integer> getMapnoofwallet() {
		return mapnoofwallet;
	}

	public void setMapnoofwallet(Map<String, Integer> mapnoofwallet) {
		this.mapnoofwallet = mapnoofwallet;
	}

	public List<PartnerData> getNoofwallets() {
		return noofwallets;
	}

	public void setNoofwallets(List<PartnerData> noofwallets) {
		this.noofwallets = noofwallets;
	}

	public Integer[] getWalletcheckBoxName() {
		return walletcheckBoxName;
	}

	public void setWalletcheckBoxName(Integer[] walletcheckBoxName) {
		this.walletcheckBoxName = walletcheckBoxName;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}


	public String getWalletType() {
		return walletType;
	}

	public void setWalletType(String walletType) {
		this.walletType = walletType;
	}

	public List<PartnerData> getWalletdata() {
		return walletdata;
	}

	public void setWalletdata(List<PartnerData> walletdata) {
		this.walletdata = walletdata;
	}

	public String getSmscode() {
		return smscode;
	}

	public void setSmscode(String smscode) {
		this.smscode = smscode;
	}

	public String[] getProviders() {
		return providers;
	}

	public void setProviders(String[] providers) {
		this.providers = providers;
	}

	public Integer getMvId() {
		return mvId;
	}

	public void setMvId(Integer mvId) {
		this.mvId = mvId;
	}

	public List<String> getCategoryProviderList() {
		return categoryProviderList;
	}

	public void setCategoryProviderList(List<String> categoryProviderList) {
		this.categoryProviderList = categoryProviderList;
	}


	public Map<Map<Integer, String>, Map<String, String>> getCategoryProviderMap() {
		return categoryProviderMap;
	}

	public void setCategoryProviderMap(Map<Map<Integer, String>, Map<String, String>> categoryProviderMap) {
		this.categoryProviderMap = categoryProviderMap;
	}

	/**
	 * @return the mVersionCode
	 */
	public int getmVersionCode() {
		return mVersionCode;
	}

	/**
	 * @param mVersionCode
	 *	the mVersionCode to set
	 */
	public void setmVersionCode(int mVersionCode) {
		this.mVersionCode = mVersionCode;
	}

	/**
	 * @return the mVersionName
	 */
	public String getmVersionName() {
		return mVersionName;
	}

	/**
	 * @param mVersionName
	 * the mVersionName to set
	 */
	public void setmVersionName(String mVersionName) {
		this.mVersionName = mVersionName;
	}

	/**
	 * @return the mVersionDecsription
	 */
	public String getmVersionDecsription() {
		return mVersionDecsription;
	}

	/**
	 * @param mVersionDecsription
	 * the mVersionDecsription to set
	 */
	public void setmVersionDecsription(String mVersionDecsription) {
		this.mVersionDecsription = mVersionDecsription;
	}

}