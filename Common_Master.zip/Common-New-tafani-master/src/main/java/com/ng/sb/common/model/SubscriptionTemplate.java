package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;
	/**
	*
	* @author Simran
	* 
	* The persistent class for the subscription template database table.
	*/
	@Entity
	@Table(name = "subscriptiontemplate")
	@XmlRootElement
	@NamedQueries({
		@NamedQuery(name="SubscriptionTemplate.findByEndDate", query="SELECT c FROM SubscriptionTemplate c where c.isActive=:isActive AND c.endDate=NULL"),
		@NamedQuery(name="SubscriptionTemplate.findById", query="SELECT c FROM SubscriptionTemplate c where c.id=:id"),
		@NamedQuery(name="SubscriptionTemplate.findByCommCodeInDuration", query="SELECT st FROM SubscriptionTemplate st where st.isActive=1 AND st.subscriptionCode=:subs AND st.startDate <= :tDate AND (st.endDate IS NULL OR st.endDate >= :tDate)"),
		@NamedQuery(name="SubscriptionTemplate.findBySubscriptionCode", query="SELECT c FROM SubscriptionTemplate c where c.isActive=1 AND c.subscriptionCode=:subscriptionCode"),
	})

	public class SubscriptionTemplate implements Serializable {
	    private static final long serialVersionUID = 1L;
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Basic(optional = false)
	    @Column(name = "id")
	    private Integer id;
	    @Column(name = "name")
	    private String name;
	    @Column(name = "subscription_code")
	    private String subscriptionCode;
		@Column(name = "host_subscription")
	    private Double hostSubscription=0.0;
	    @Column(name = "distributor_subscription")
	    private Double distributorSubscription=0.0;
	    @Column(name = "sub_distributor_subscription")
	    private Double subDistributorSubscription=0.0;
	    @Column(name = "agent_subscription")
	    private Double agentSubscription=0.0;
	    @Column(name = "total_Subscription")
	    private Double totalSubscription=0.0;
	    @Column(name = "bank_subscription")
	    private Double bankSubscription=0.0;
	    @Column(name = "start_date")
	    @Temporal(TemporalType.DATE)
	    private Date startDate;
	    @Column(name = "end_date")
	    @Temporal(TemporalType.DATE)
	    private Date endDate;
		@Column(name = "created_on")
	    @Temporal(TemporalType.TIMESTAMP)
	    private Date createDate;
	    @Column(name = "created_by") 
	    private Integer createdBy;
	    @Column(name = "updated_on")
	    @Temporal(TemporalType.TIMESTAMP)
	    private Date modifiedDate;
	    @Column(name = "updated_by") 
	    private Integer updatedBy;
	    @Column(name = "isActive")
	    private Integer isActive;
	    @Column(name="subscription_type")
	    private String subscription;
	    public SubscriptionTemplate() {
	 		//default
	 	}
	    public SubscriptionTemplate(Integer id) {
	        this.id = id;
	    }
	 

		public void setStartDate(Date startDate) {
			this.startDate = startDate;
		}
		public Date getEndDate() {
			return endDate;
		}
		public void setEndDate(Date endDate) {
			this.endDate = endDate;
		}
	

		public Integer getId() {
			return id;
		}

		public void setId(Integer id) {
			this.id = id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

	

		public Date getCreateDate() {
			return createDate;
		}

		public void setCreateDate(Date createDate) {
			this.createDate = createDate;
		}

		public Integer getCreatedBy() {
			return createdBy;
		}

		public void setCreatedBy(Integer createdBy) {
			this.createdBy = createdBy;
		}

		public Date getModifiedDate() {
			return modifiedDate;
		}

		public void setModifiedDate(Date modifiedDate) {
			this.modifiedDate = modifiedDate;
		}

		public Integer getUpdatedBy() {
			return updatedBy;
		}

		public void setUpdatedBy(Integer updatedBy) {
			this.updatedBy = updatedBy;
		}

		public Integer getIsActive() {
			return isActive;
		}

		public void setIsActive(Integer isActive) {
			this.isActive = isActive;
		}

		@Override
	    public int hashCode() {
	        int hash = 0;
	        hash += (id != null ? id.hashCode() : 0);
	        return hash;
	    }

	    @Override
	    public boolean equals(Object object) {
	    	boolean check=true;
	    	if(object!=null){
	        if (!(object instanceof SubscriptionTemplate)) {
	        	check= false;
	        }
	        SubscriptionTemplate other = (SubscriptionTemplate) object;
	        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
	        	check= false;
	        }
	    	}
	        return check;
	    }

	    @Override
	    public String toString() {
	        return "com.ng.sb.common.model.SubscriptionTemplate[ id=" + id + " ]";
	    }
		public String getSubscriptionCode() {
			return subscriptionCode;
		}
		public void setSubscriptionCode(String subscriptionCode) {
			this.subscriptionCode = subscriptionCode;
		}
		public Double getHostSubscription() {
			return hostSubscription;
		}
		public void setHostSubscription(Double hostSubscription) {
			this.hostSubscription = hostSubscription;
		}
		public Double getDistributorSubscription() {
			return distributorSubscription;
		}
		public void setDistributorSubscription(Double distributorSubscription) {
			this.distributorSubscription = distributorSubscription;
		}
		public Double getSubDistributorSubscription() {
			return subDistributorSubscription;
		}
		public void setSubDistributorSubscription(Double subDistributorSubscription) {
			this.subDistributorSubscription = subDistributorSubscription;
		}
		public Double getAgentSubscription() {
			return agentSubscription;
		}
		public void setAgentSubscription(Double agentSubscription) {
			this.agentSubscription = agentSubscription;
		}
		public Double getTotalSubscription() {
			return totalSubscription;
		}
		public void setTotalSubscription(Double totalSubscription) {
			this.totalSubscription = totalSubscription;
		}
		public Double getBankSubscription() {
			return bankSubscription;
		}
		public void setBankSubscriptionPercentage(Double bankSubscription) {
			this.bankSubscription = bankSubscription;
		}
		public String getSubscription() {
			return subscription;
		}
		public void setSubscription(String subscription) {
			this.subscription = subscription;
		}
		public Date getStartDate() {
			return startDate;
		}
		
}
