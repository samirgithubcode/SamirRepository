package com.ng.transaction.data;

public class SecureServiceResponse extends BaseObject {

	private static final long serialVersionUID = 1L;
	private Integer responseCode;
	private String responseString;
	public Integer getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(Integer responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseString() {
		return responseString;
	}
	public void setResponseString(String responseString) {
		this.responseString = responseString;
	}

	

}
