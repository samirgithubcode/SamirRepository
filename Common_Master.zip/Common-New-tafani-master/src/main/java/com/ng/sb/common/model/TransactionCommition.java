/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "TransactionCommition")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "TransactionCommition.findAll", query = "SELECT t FROM TransactionCommition t"),
    @NamedQuery(name = "TransactionCommition.findById", query = "SELECT t FROM TransactionCommition t WHERE t.id = :id"),
    @NamedQuery(name = "TransactionCommition.findByMsisdn", query = "SELECT t FROM TransactionCommition t WHERE t.msisdn = :msisdn"),
    @NamedQuery(name = "TransactionCommition.findByTxnId", query = "SELECT t FROM TransactionCommition t WHERE t.txnId = :txnId"),
    @NamedQuery(name = "TransactionCommition.findByAmountRecFrmSubsc", query = "SELECT t FROM TransactionCommition t WHERE t.amountRecFrmSubsc = :amountRecFrmSubsc"),
    @NamedQuery(name = "TransactionCommition.findBySubsCommitionDR", query = "SELECT t FROM TransactionCommition t WHERE t.subsCommitionDR = :subsCommitionDR"),
    @NamedQuery(name = "TransactionCommition.findByPartnerCommitionDR", query = "SELECT t FROM TransactionCommition t WHERE t.partnerCommitionDR = :partnerCommitionDR"),
    @NamedQuery(name = "TransactionCommition.findByTotalCommitionBe4Tex", query = "SELECT t FROM TransactionCommition t WHERE t.totalCommitionBe4Tex = :totalCommitionBe4Tex"),
    @NamedQuery(name = "TransactionCommition.findByTax", query = "SELECT t FROM TransactionCommition t WHERE t.tax = :tax"),
    @NamedQuery(name = "TransactionCommition.findBySurcharge", query = "SELECT t FROM TransactionCommition t WHERE t.surcharge = :surcharge"),
    @NamedQuery(name = "TransactionCommition.findByTotalCommitionAfterTex", query = "SELECT t FROM TransactionCommition t WHERE t.totalCommitionAfterTex = :totalCommitionAfterTex"),
    @NamedQuery(name = "TransactionCommition.findByPartnerAmountCR", query = "SELECT t FROM TransactionCommition t WHERE t.partnerAmountCR = :partnerAmountCR"),
    @NamedQuery(name = "TransactionCommition.findByPlatformProviderCommition", query = "SELECT t FROM TransactionCommition t WHERE t.platformProviderCommition = :platformProviderCommition"),
    @NamedQuery(name = "TransactionCommition.findByHostCommition", query = "SELECT t FROM TransactionCommition t WHERE t.hostCommition = :hostCommition"),
    @NamedQuery(name = "TransactionCommition.findByDCommition", query = "SELECT t FROM TransactionCommition t WHERE t.dCommition = :dCommition"),
    @NamedQuery(name = "TransactionCommition.findBySdCommition", query = "SELECT t FROM TransactionCommition t WHERE t.sdCommition = :sdCommition"),
    @NamedQuery(name = "TransactionCommition.findByRtCommition", query = "SELECT t FROM TransactionCommition t WHERE t.rtCommition = :rtCommition"),
    @NamedQuery(name = "TransactionCommition.findByBcCommition", query = "SELECT t FROM TransactionCommition t WHERE t.bcCommition = :bcCommition")})
public class TransactionCommition implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
   
    
    @Column(name = "msisdn", length = 25)
    private String msisdn;
    
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "amountRecFrmSubsc", precision = 12)
    private Float amountRecFrmSubsc;
    @Column(name = "subsCommitionDR", precision = 12)
    private Float subsCommitionDR;
    @Column(name = "txnId", length = 25)
    private String txnId;
    @Column(name = "partnerCommitionDR", precision = 12)
    private Float partnerCommitionDR;
    @Column(name = "totalCommitionBe4Tex", precision = 12)
    private Float totalCommitionBe4Tex;
    @Column(name = "tax", precision = 12)
    private Float tax;
    @Column(name = "surcharge", precision = 12)
    private Float surcharge;
    @Column(name = "totalCommitionAfterTex", precision = 12)
    private Float totalCommitionAfterTex;
    @Column(name = "partnerAmountCR", precision = 12)
    private Float partnerAmountCR;
    @Column(name = "platformProviderCommition", precision = 12)
    private Float platformProviderCommition;
    @Column(name = "hostCommition", precision = 12)
    private Float hostCommition;
    @Column(name = "dCommition", precision = 12)
    private Float dCommition;
    @Column(name = "sdCommition", precision = 12)
    private Float sdCommition;
    @Column(name = "rtCommition", precision = 12)
    private Float rtCommition;
    @Column(name = "bcCommition")
    private Integer bcCommition;
    @JoinColumn(name = "userId", referencedColumnName = "id")
    @ManyToOne
    private Subscriber userId;

    public TransactionCommition() {
    	//default constructor
    }

    public TransactionCommition(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    

   
    
    public String getMsisdn() {
        return msisdn;
    }

    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }

    public Float getAmountRecFrmSubsc() {
        return amountRecFrmSubsc;
    }

    public void setAmountRecFrmSubsc(Float amountRecFrmSubsc) {
        this.amountRecFrmSubsc = amountRecFrmSubsc;
    }

    public Float getSubsCommitionDR() {
        return subsCommitionDR;
    }

    public void setSubsCommitionDR(Float subsCommitionDR) {
        this.subsCommitionDR = subsCommitionDR;
    }

    public String getTxnId() {
        return txnId;
    }

    public void setTxnId(String txnId) {
        this.txnId = txnId;
    }
    
    public Float getPartnerCommitionDR() {
        return partnerCommitionDR;
    }

    public void setPartnerCommitionDR(Float partnerCommitionDR) {
        this.partnerCommitionDR = partnerCommitionDR;
    }

    public Float getTotalCommitionBe4Tex() {
        return totalCommitionBe4Tex;
    }

    public void setTotalCommitionBe4Tex(Float totalCommitionBe4Tex) {
        this.totalCommitionBe4Tex = totalCommitionBe4Tex;
    }

    public Float getTax() {
        return tax;
    }

    public void setTax(Float tax) {
        this.tax = tax;
    }

    public Float getSurcharge() {
        return surcharge;
    }

    public void setSurcharge(Float surcharge) {
        this.surcharge = surcharge;
    }

    public Float getTotalCommitionAfterTex() {
        return totalCommitionAfterTex;
    }

    public void setTotalCommitionAfterTex(Float totalCommitionAfterTex) {
        this.totalCommitionAfterTex = totalCommitionAfterTex;
    }

    public Float getPartnerAmountCR() {
        return partnerAmountCR;
    }

    public void setPartnerAmountCR(Float partnerAmountCR) {
        this.partnerAmountCR = partnerAmountCR;
    }

    public Float getPlatformProviderCommition() {
        return platformProviderCommition;
    }

    public void setPlatformProviderCommition(Float platformProviderCommition) {
        this.platformProviderCommition = platformProviderCommition;
    }

    public Float getHostCommition() {
        return hostCommition;
    }

    public void setHostCommition(Float hostCommition) {
        this.hostCommition = hostCommition;
    }

    public Float getDCommition() {
        return dCommition;
    }

    public void setDCommition(Float dCommition) {
        this.dCommition = dCommition;
    }

    public Float getSdCommition() {
        return sdCommition;
    }

    public void setSdCommition(Float sdCommition) {
        this.sdCommition = sdCommition;
    }

    public Float getRtCommition() {
        return rtCommition;
    }

    public void setRtCommition(Float rtCommition) {
        this.rtCommition = rtCommition;
    }

    public Integer getBcCommition() {
        return bcCommition;
    }

    public void setBcCommition(Integer bcCommition) {
        this.bcCommition = bcCommition;
    }

    public Subscriber getUserId() {
        return userId;
    }

    public void setUserId(Subscriber userId) {
        this.userId = userId;
    }

   

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof TransactionCommition)) {
            return false;
        }
        TransactionCommition other = (TransactionCommition) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.TransactionCommition[ id=" + id + " ]";
    }
    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }
    
}
