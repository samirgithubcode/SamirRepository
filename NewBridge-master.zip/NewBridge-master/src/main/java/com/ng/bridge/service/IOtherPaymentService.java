/**
 * 
 */
package com.ng.bridge.service;

import com.ng.sb.common.dataobject.BridgeDataObject;

/**
 * @author gaurav
 *
 */
public interface IOtherPaymentService extends IFundTransferMgtService {
	public BridgeDataObject fundTransferToIndividual(BridgeDataObject bridgeDataObject);
	public BridgeDataObject fundTransferToMerchant(BridgeDataObject bridgeDataObject);
	public BridgeDataObject fundTransferWalletToWallet(BridgeDataObject bridgeDataObject);
	public BridgeDataObject fundTransferBankToWallet(BridgeDataObject bridgeDataObject);
	public BridgeDataObject fundTransferWalletToBank(BridgeDataObject bridgeDataObject);
}
