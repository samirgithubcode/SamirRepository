/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "selfcare_login_logs")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "SelfcareLoginLogs.findAll", query = "SELECT s FROM SelfcareLoginLogs s"),
    @NamedQuery(name = "SelfcareLoginLogs.findById", query = "SELECT s FROM SelfcareLoginLogs s WHERE s.id = :id"),
    @NamedQuery(name = "SelfcareLoginLogs.findBySubscriberId", query = "SELECT s FROM SelfcareLoginLogs s WHERE s.subscriberId = :subscriberId"),
    @NamedQuery(name = "SelfcareLoginLogs.findByMsisdn", query = "SELECT s FROM SelfcareLoginLogs s WHERE s.msisdn = :msisdn"),
    @NamedQuery(name = "SelfcareLoginLogs.findByReqDateTime", query = "SELECT s FROM SelfcareLoginLogs s WHERE s.reqDateTime = :reqDateTime"),
    @NamedQuery(name = "SelfcareLoginLogs.findByAttemptResult", query = "SELECT s FROM SelfcareLoginLogs s WHERE s.attemptResult = :attemptResult"),
    @NamedQuery(name = "SelfcareLoginLogs.findByInvalidLoginCount", query = "SELECT s FROM SelfcareLoginLogs s WHERE s.invalidLoginCount = :invalidLoginCount"),
    @NamedQuery(name = "SelfcareLoginLogs.findByRemarks", query = "SELECT s FROM SelfcareLoginLogs s WHERE s.remarks = :remarks")})
public class SelfcareLoginLogs implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
    @Basic(optional = false)
    @Column(name = "subscriber_id", nullable = false)
    private int subscriberId;
    @Basic(optional = false)
    @Column(name = "msisdn", nullable = false)
    private int msisdn;
    @Basic(optional = false)
    @Column(name = "req_date_time", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date reqDateTime;
    @Basic(optional = false)
    @Column(name = "attempt_result", nullable = false)
    private int attemptResult;
    @Basic(optional = false)
    @Column(name = "invalid_login_count", nullable = false)
    private int invalidLoginCount;
    @Column(name = "remarks", length = 100)
    private String remarks;

    public SelfcareLoginLogs() {
    	//default constructor
    }

    public SelfcareLoginLogs(Integer id) {
        this.id = id;
    }

    public SelfcareLoginLogs(Integer id, int subscriberId, int msisdn, Date reqDateTime, int attemptResult, int invalidLoginCount) {
        this.id = id;
        this.subscriberId = subscriberId;
        this.msisdn = msisdn;
        this.reqDateTime = reqDateTime;
        this.attemptResult = attemptResult;
        this.invalidLoginCount = invalidLoginCount;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public int getSubscriberId() {
        return subscriberId;
    }

    public void setSubscriberId(int subscriberId) {
        this.subscriberId = subscriberId;
    }

    public int getMsisdn() {
        return msisdn;
    }

    public void setMsisdn(int msisdn) {
        this.msisdn = msisdn;
    }

    public Date getReqDateTime() {
        return reqDateTime;
    }

    public void setReqDateTime(Date reqDateTime) {
        this.reqDateTime = reqDateTime;
    }

    public int getAttemptResult() {
        return attemptResult;
    }

    public void setAttemptResult(int attemptResult) {
        this.attemptResult = attemptResult;
    }

    public int getInvalidLoginCount() {
        return invalidLoginCount;
    }

    public void setInvalidLoginCount(int invalidLoginCount) {
        this.invalidLoginCount = invalidLoginCount;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof SelfcareLoginLogs)) {
            return false;
        }
        SelfcareLoginLogs other = (SelfcareLoginLogs) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.SelfcareLoginLogs[ id=" + id + " ]";
    }
    
}
