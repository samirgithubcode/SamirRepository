package com.ng.bridge.dataobject.eko;

public class RefundResendOTPResData {

	private String tid;

    private String otp;

    public String getTid ()
    {
        return tid;
    }

    public void setTid (String tid)
    {
        this.tid = tid;
    }

    public String getOtp ()
    {
        return otp;
    }

    public void setOtp (String otp)
    {
        this.otp = otp;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [tid = "+tid+", otp = "+otp+"]";
    }
}
