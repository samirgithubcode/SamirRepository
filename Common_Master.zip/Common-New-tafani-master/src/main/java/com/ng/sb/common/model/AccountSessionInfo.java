/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "account_session_info")
@XmlRootElement
@NamedQueries({
	@NamedQuery(name = "AccountSessionInfo.findBySessionID", query = "SELECT a FROM AccountSessionInfo a WHERE a.randSessionKey = :randSessionKey"),
	@NamedQuery(name = "AccountSessionInfo.findByAccountId", query = "SELECT a FROM AccountSessionInfo a WHERE a.accountId = :accountId ORDER BY a.id"),
	@NamedQuery(name = "AccountSessionInfo.findByAccountIdAndSessionKey", query = "SELECT a FROM AccountSessionInfo a WHERE a.accountId = :accountId and a.randSessionKey= :randSessionKey"),
	@NamedQuery(name = "AccountSessionInfo.countFindByAccountId", query = "SELECT COUNT(a) FROM AccountSessionInfo a WHERE a.accountId = :accountId"),
	
})

public class AccountSessionInfo implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
   
    
    
    @Column(name = "outtime")
    @Temporal(TemporalType.TIMESTAMP)
    private Date outtime;
    @Basic(optional = false)
    @Column(name = "intime", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date intime;
    @Basic(optional = false)
    @Column(name = "rand_session_key", nullable = false, length = 100)
    private String randSessionKey;
   
    @JoinColumn(name = "account_id", referencedColumnName = "id", nullable = false)
    @ManyToOne(optional = false)
    private AccountInfo accountId;
    @Column(name = "ip_address", length = 100)
    private String ipAddress;
    public AccountSessionInfo() {
    	//default constructor
    }

    public AccountSessionInfo(Integer id) {
        this.id = id;
    }

    public AccountSessionInfo(Integer id, Date intime, String randSessionKey) {
        this.id = id;
        this.intime = intime;
        this.randSessionKey = randSessionKey;
    }

   

    public Date getIntime() {
        return intime;
    }

    public void setIntime(Date intime) {
        this.intime = intime;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
    
    public Date getOuttime() {
        return outtime;
    }

    public void setOuttime(Date outtime) {
        this.outtime = outtime;
    }

    
    
    public AccountInfo getAccountId() {
        return accountId;
    }

    public void setAccountId(AccountInfo accountId) {
        this.accountId = accountId;
    }

    public String getRandSessionKey() {
        return randSessionKey;
    }

    public void setRandSessionKey(String randSessionKey) {
        this.randSessionKey = randSessionKey;
    }
    
    public String getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }


    @Override
    public String toString() {
        return "com.ng.sb.common.model.AccountSessionInfo[ id=" + id + " ]";
    }
    

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof AccountSessionInfo)) {
            return false;
        }
        boolean check=true;
        AccountSessionInfo other = (AccountSessionInfo) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }
    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }


    
    

    
    
}
