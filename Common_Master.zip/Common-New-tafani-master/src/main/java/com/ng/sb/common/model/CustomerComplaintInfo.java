/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "customer_complaint_info", uniqueConstraints = {
    @UniqueConstraint(columnNames = {"ticket_id"})})
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CustomerComplaintInfo.findAll", query = "SELECT c FROM CustomerComplaintInfo c"),
    @NamedQuery(name = "CustomerComplaintInfo.findById", query = "SELECT c FROM CustomerComplaintInfo c WHERE c.id = :id"),
    @NamedQuery(name = "CustomerComplaintInfo.findByTicketId", query = "SELECT c FROM CustomerComplaintInfo c WHERE c.ticketId = :ticketId"),
    @NamedQuery(name = "CustomerComplaintInfo.findByJobStatus", query = "SELECT c FROM CustomerComplaintInfo c WHERE c.jobStatus = :jobStatus"),
    @NamedQuery(name = "CustomerComplaintInfo.findByJobCloseRemark", query = "SELECT c FROM CustomerComplaintInfo c WHERE c.jobCloseRemark = :jobCloseRemark"),
    @NamedQuery(name = "CustomerComplaintInfo.findByNumberOfQuery", query = "SELECT c FROM CustomerComplaintInfo c WHERE c.numberOfQuery = :numberOfQuery"),
    @NamedQuery(name = "CustomerComplaintInfo.findByJobOpenDate", query = "SELECT c FROM CustomerComplaintInfo c WHERE c.jobOpenDate = :jobOpenDate"),
    @NamedQuery(name = "CustomerComplaintInfo.findByJobCloseDate", query = "SELECT c FROM CustomerComplaintInfo c WHERE c.jobCloseDate = :jobCloseDate")})
public class CustomerComplaintInfo implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
   
    @Basic(optional = false)
    @Column(name = "job_status", nullable = false)
    private int jobStatus;
    
    @Basic(optional = false)
    @Column(name = "ticket_id", nullable = false, length = 20)
    private String ticketId;
    @Column(name = "job_close_remark", length = 200)
    private String jobCloseRemark;
    @Basic(optional = false)
    @Column(name = "number_of_query", nullable = false)
    private int numberOfQuery;
    @Basic(optional = false)
    @Column(name = "job_open_date", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date jobOpenDate;
    @Column(name = "job_close_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date jobCloseDate;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "ticketId")
    private Collection<TicketQueryAssignmentHistory> ticketQueryAssignmentHistoryCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "ticketId")
    private Collection<TicketQueryDetails> ticketQueryDetailsCollection;
    @JoinColumn(name = "customer_call_id", referencedColumnName = "id", nullable = false)
    @ManyToOne(optional = false)
    private CustomerCallDetails customerCallId;

    public CustomerComplaintInfo() {
    	//default constructor
    }

    public CustomerComplaintInfo(Integer id) {
        this.id = id;
    }

    public CustomerComplaintInfo(Integer id, String ticketId, int jobStatus, int numberOfQuery, Date jobOpenDate) {
        this.id = id;
        this.ticketId = ticketId;
        this.jobStatus = jobStatus;
        this.numberOfQuery = numberOfQuery;
        this.jobOpenDate = jobOpenDate;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTicketId() {
        return ticketId;
    }

    public void setTicketId(String ticketId) {
        this.ticketId = ticketId;
    }

    public int getJobStatus() {
        return jobStatus;
    }

    public void setJobStatus(int jobStatus) {
        this.jobStatus = jobStatus;
    }

    public String getJobCloseRemark() {
        return jobCloseRemark;
    }

    public void setJobCloseRemark(String jobCloseRemark) {
        this.jobCloseRemark = jobCloseRemark;
    }

    public int getNumberOfQuery() {
        return numberOfQuery;
    }

    public void setNumberOfQuery(int numberOfQuery) {
        this.numberOfQuery = numberOfQuery;
    }

    public Date getJobOpenDate() {
        return jobOpenDate;
    }

    public void setJobOpenDate(Date jobOpenDate) {
        this.jobOpenDate = jobOpenDate;
    }

    public Date getJobCloseDate() {
        return jobCloseDate;
    }

    public void setJobCloseDate(Date jobCloseDate) {
        this.jobCloseDate = jobCloseDate;
    }

    @XmlTransient
    public Collection<TicketQueryAssignmentHistory> getTicketQueryAssignmentHistoryCollection() {
        return ticketQueryAssignmentHistoryCollection;
    }

    public void setTicketQueryAssignmentHistoryCollection(Collection<TicketQueryAssignmentHistory> ticketQueryAssignmentHistoryCollection) {
        this.ticketQueryAssignmentHistoryCollection = ticketQueryAssignmentHistoryCollection;
    }

    @XmlTransient
    public Collection<TicketQueryDetails> getTicketQueryDetailsCollection() {
        return ticketQueryDetailsCollection;
    }

    public void setTicketQueryDetailsCollection(Collection<TicketQueryDetails> ticketQueryDetailsCollection) {
        this.ticketQueryDetailsCollection = ticketQueryDetailsCollection;
    }

    public CustomerCallDetails getCustomerCallId() {
        return customerCallId;
    }

    public void setCustomerCallId(CustomerCallDetails customerCallId) {
        this.customerCallId = customerCallId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof CustomerComplaintInfo)) {
            return false;
        }
        CustomerComplaintInfo other = (CustomerComplaintInfo) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.CustomerComplaintInfo[ id=" + id + " ]";
    }
    
}
