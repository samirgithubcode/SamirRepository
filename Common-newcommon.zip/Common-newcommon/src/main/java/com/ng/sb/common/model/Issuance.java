package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Table(name="issuance")
@NamedQueries({
	@NamedQuery(name="Issuance.findFirstByOrderByIdDesc", query="SELECT i FROM Issuance i ORDER BY id desc"),
	@NamedQuery(name="Issuance.FirstByAccountNumber", query="SELECT i FROM Issuance i where i.accountNumber= :accountNumber"),
	

})
@Entity
public class Issuance implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="id")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	@Column(name="overlay_number")
	private Long overlayNumber;
	@Size(min = 3, max =12)
	@Column(name="account_number")
	private String accountNumber;
	@Column(name="cif_number")
	private String cifNumber;
	@Column(name="name")
	private String name;
	@Column(name="mobile")
	private String mobile;
	@Column(name="address")
	private String address;
	@Column(name="verification_doc")
	private String verificationDoc;
	@Column(name="other_doc")
	private String otherDoc;
	@Column(name="bank_name")
	private String bankName;
	@Column(name="created_at")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdAt = new Date();
	
	@Column(name="profileImage")
	private String profileImage;
	
	
	
	
	public String getProfileImage() {
		return profileImage;
	}
	public void setProfileImage(String profileImage) {
		this.profileImage = profileImage;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getOverlayNumber() {
		return overlayNumber;
	}
	public void setOverlayNumber(Long overlayNumber) {
		this.overlayNumber = overlayNumber;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getCifNumber() {
		return cifNumber;
	}
	public void setCifNumber(String cifNumber) {
		this.cifNumber = cifNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getVerificationDoc() {
		return verificationDoc;
	}
	public void setVerificationDoc(String verificationDoc) {
		this.verificationDoc = verificationDoc;
	}
	public String getOtherDoc() {
		return otherDoc;
	}
	public void setOtherDoc(String otherDoc) {
		this.otherDoc = otherDoc;
	}
	public Date getCreatedAt() {
		return createdAt;
	}
	
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	@PreUpdate
	public void setCreatedAt() {  
	    this.createdAt= new Date(); 
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Issuance [id=");
		builder.append(id);
		builder.append(", overlayNumber=");
		builder.append(overlayNumber);
		builder.append(", accountNumber=");
		builder.append(accountNumber);
		builder.append(", cifNumber=");
		builder.append(cifNumber);
		builder.append(", name=");
		builder.append(name);
		builder.append(", mobile=");
		builder.append(mobile);
		builder.append(", address=");
		builder.append(address);
		builder.append(", verificationDoc=");
		builder.append(verificationDoc);
		builder.append(", otherDoc=");
		builder.append(otherDoc);
		builder.append(", bankName=");
		builder.append(bankName);
		builder.append(", createdAt=");
		builder.append(createdAt);
		builder.append(", profileImage=");
		builder.append(profileImage);
		builder.append("]");
		return builder.toString();
	}
	
	
	
	
}
