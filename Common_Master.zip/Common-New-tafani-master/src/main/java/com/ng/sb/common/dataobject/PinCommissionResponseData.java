package com.ng.sb.common.dataobject;

public class PinCommissionResponseData extends BaseObjectData {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Double grossAmount;
	private String commissionType;
	private String commissionValueType;
	private Float grossCommissionAmount;
	private Float netCommissionAmount;
	private Float tax;
	private Float surCharge;
	private Float taxAndSurcharge;
	private Double netAmount;
	private Float minCommissionAmount;
	private Float maxCommissionAmount;

	public Float getNetCommissionAmount() {
		return netCommissionAmount;
	}
	public void setNetCommissionAmount(Float netCommissionAmount) {
		this.netCommissionAmount = netCommissionAmount;
	}
	public Double getGrossAmount() {
		return grossAmount;
	}
	public void setGrossAmount(Double grossAmount) {
		this.grossAmount = grossAmount;
	}
	public String getCommissionType() {
		return commissionType;
	}
	public void setCommissionType(String commissionType) {
		this.commissionType = commissionType;
	}
	public String getCommissionValueType() {
		return commissionValueType;
	}
	public void setCommissionValueType(String commissionValueType) {
		this.commissionValueType = commissionValueType;
	}
	public Float getGrossCommissionAmount() {
		return grossCommissionAmount;
	}
	public void setGrossCommissionAmount(Float grossCommissionAmount) {
		this.grossCommissionAmount = grossCommissionAmount;
	}
	public Float getTax() {
		return tax;
	}
	public void setTax(Float tax) {
		this.tax = tax;
	}
	public Float getSurCharge() {
		return surCharge;
	}
	public void setSurCharge(Float surCharge) {
		this.surCharge = surCharge;
	}
	public Float getTaxAndSurcharge() {
		return taxAndSurcharge;
	}
	public void setTaxAndSurcharge(Float taxAndSurcharge) {
		this.taxAndSurcharge = taxAndSurcharge;
	}
	public Double getNetAmount() {
		return netAmount;
	}
	public void setNetAmount(Double netAmount) {
		this.netAmount = netAmount;
	}
	public Float getMinCommissionAmount() {
		return minCommissionAmount;
	}
	public void setMinCommissionAmount(Float minCommissionAmount) {
		this.minCommissionAmount = minCommissionAmount;
	}
	public Float getMaxCommissionAmount() {
		return maxCommissionAmount;
	}
	public void setMaxCommissionAmount(Float maxCommissionAmount) {
		this.maxCommissionAmount = maxCommissionAmount;
	}
}
