/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name = "BoxDetails")
@XmlRootElement
@NamedQueries({
	@NamedQuery(name = "BoxDetails.findAll", query = "SELECT b FROM BoxDetails b"),
	@NamedQuery(name = "BoxDetails.findallbyhid&product&namemaster", query = "SELECT b FROM BoxDetails b WHERE b.hId=:hid AND  b.masterVersion=:mv AND b.productVersion=:pv"),
	@NamedQuery(name = "BoxDetails.findallbypid&product&namemaster", query = "SELECT b FROM BoxDetails b WHERE b.pId=:pid AND  b.masterVersion=:mv AND b.productVersion=:pv"),
	@NamedQuery(name = "BoxDetails.findById", query = "SELECT b FROM BoxDetails b WHERE b.id = :id"),
	@NamedQuery(name = "BoxDetails.findByOrderId", query = "SELECT b FROM BoxDetails b WHERE b.po = :po"),
	@NamedQuery(name = "BoxDetails.findByOrderIdAndStatus", query = "SELECT b FROM BoxDetails b WHERE b.po = :po AND b.status = :status"),
	@NamedQuery(name = "BoxDetails.findByOrderIdMvidAndStatus", query = "SELECT b FROM BoxDetails b WHERE b.po = :po AND b.masterVersion = :masterVersion AND b.status = :status"),
		//	@NamedQuery(name = "BoxDetails.findByIdAndStatus", query = "SELECT b FROM BoxDetails b WHERE b.rdId = :rdId and b.allotStatus = :allotStatus"),
		//	@NamedQuery(name = "BoxDetails.findByIdAndStatus", query = "SELECT b FROM BoxDetails b WHERE b.rdId = :rdId and b.allotStatus = :allotStatus"),
	@NamedQuery(name = "BoxDetails.findByOrderIdProductIdAndMvid", query = "SELECT b FROM BoxDetails b WHERE b.po = :po AND b.productVersion = :productVersion AND b.masterVersion = :masterVersion"),
	@NamedQuery(name = "BoxDetails.findByOrderIdProductIdAndMvidAndStatus", query = "SELECT b FROM BoxDetails b WHERE b.po = :po AND b.productVersion = :productVersion AND b.masterVersion = :masterVersion AND b.status = :status"),
	@NamedQuery(name = "BoxDetails.findByOrderIdAndProductId", query = "SELECT b FROM BoxDetails b WHERE b.po = :po AND b.productVersion = :productVersion"),
	@NamedQuery(name = "BoxDetails.findByOrderIdAndMvId", query = "SELECT b FROM BoxDetails b WHERE b.po = :po AND b.masterVersion = :masterVersion"),
	@NamedQuery(name = "BoxDetails.findByOrderIdProductIdAndStatus", query = "SELECT b FROM BoxDetails b WHERE b.po = :po AND b.productVersion = :productVersion AND b.allotStatus = :allotStatus"),
	@NamedQuery(name = "BoxDetails.findByOrderHidAndStatus", query = "SELECT b FROM BoxDetails b, Products p WHERE b.productVersion=p.id AND b.hId = :hId AND b.allotStatus = :allotStatus GROUP BY b.productVersion, b.masterVersion "),
	@NamedQuery(name = "BoxDetails.findByOrderPidAndStatus", query = "SELECT b FROM BoxDetails b, Products p WHERE b.productVersion=p.id AND b.pId = :pId AND b.allotStatus = :allotStatus GROUP BY b.productVersion, b.masterVersion  "),
	@NamedQuery(name = "BoxDetails.findByOrderDidAndStatus", query = "SELECT b FROM BoxDetails b, Products p WHERE b.productVersion=p.id AND b.dId = :hId AND b.allotStatus = :allotStatus GROUP BY b.productVersion, b.masterVersion "),
	@NamedQuery(name = "BoxDetails.findByOrderSidAndStatus", query = "SELECT b FROM BoxDetails b, Products p WHERE b.productVersion=p.id AND b.sdId = :hId AND b.allotStatus = :allotStatus GROUP BY b.productVersion, b.masterVersion "),
	@NamedQuery(name = "BoxDetails.findByOrderAgidAndStatus", query = "SELECT b FROM BoxDetails b, Products p WHERE b.productVersion=p.id AND b.agId = :hId AND b.allotStatus = :allotStatus GROUP BY b.productVersion, b.masterVersion "),
	@NamedQuery(name = "BoxDetails.findNoOfBoxes", query = "SELECT b FROM BoxDetails b WHERE b.hId = :hId AND b.allotStatus = :allotStatus  AND b.productVersion= :id"),
	@NamedQuery(name = "BoxDetails.findNoOfBoxesP", query = "SELECT b FROM BoxDetails b WHERE b.pId = :hId AND b.allotStatus = :allotStatus AND b.productVersion= :id"),
	@NamedQuery(name = "BoxDetails.findNoOfBoxesD", query = "SELECT b FROM BoxDetails b WHERE b.dId = :hId AND b.allotStatus = :allotStatus AND b.productVersion= :id"),
	@NamedQuery(name = "BoxDetails.findNoOfBoxesS", query = "SELECT b FROM BoxDetails b WHERE b.sdId = :hId AND b.allotStatus = :allotStatus AND b.productVersion= :id"),
	@NamedQuery(name = "BoxDetails.findNoOfBoxesR", query = "SELECT b FROM BoxDetails b WHERE b.agId = :hId AND b.allotStatus = :allotStatus AND b.productVersion= :id"),
	
	@NamedQuery(name = "BoxDetails.findAvailableQty", query = "SELECT b FROM BoxDetails b, Products p WHERE b.hId = :hId AND b.allotStatus = :allotStatus ORDER BY b.productVersion"),
	
	@NamedQuery(name = "BoxDetails.findAllBoxDetails", query = "SELECT b FROM BoxDetails b WHERE b.hId = :hId AND b.allotStatus = :allotStatus  AND b.productVersion= :id AND b.masterVersion= :mvId"),
	@NamedQuery(name = "BoxDetails.findAllBoxDetailsP", query = "SELECT b FROM BoxDetails b WHERE b.pId = :hId AND b.allotStatus = :allotStatus AND b.productVersion= :id AND b.masterVersion= :mvId"),
	@NamedQuery(name = "BoxDetails.findAllBoxDetailsD", query = "SELECT b FROM BoxDetails b WHERE b.dId = :hId AND b.allotStatus = :allotStatus AND b.productVersion= :id AND b.masterVersion= :mvId"),
	@NamedQuery(name = "BoxDetails.findAllBoxDetailsS", query = "SELECT b FROM BoxDetails b WHERE b.sdId = :hId AND b.allotStatus = :allotStatus AND b.productVersion= :id AND b.masterVersion= :mvId"),
	@NamedQuery(name = "BoxDetails.findAllBoxDetailsR", query = "SELECT b FROM BoxDetails b WHERE b.agId = :hId AND b.allotStatus = :allotStatus AND b.productVersion= :id AND b.masterVersion= :mvId"),
	
	
	@NamedQuery(name = "BoxDetails.findallinventorydetails", query="SELECT x FROM BoxDetails x WHERE x.hId = :hId and allotStatus = :allotStatus ORDER BY x.productVersion"),
    @NamedQuery(name = "BoxDetails.findallinventorydetails1", query="SELECT i FROM BoxDetails i WHERE i.dId = :dId and allotStatus = :allotStatus1 ORDER BY i.productVersion"),
    @NamedQuery(name = "BoxDetails.findallinventorydetails2", query="SELECT i FROM BoxDetails i WHERE i.sdId = :sdId and allotStatus = :allotStatus2 ORDER BY i.productVersion"),
    @NamedQuery(name = "BoxDetails.findallinventorydetails3", query="SELECT i FROM BoxDetails i WHERE i.agId = :agId and allotStatus = :allotStatus3 ORDER BY i.productVersion"),
    @NamedQuery(name = "BoxDetails.findallinventorydetails01", query="SELECT x FROM BoxDetails x WHERE x.hId = :hId and allotStatus = :allotStatus ORDER BY x.productVersion"),
    @NamedQuery(name = "BoxDetails.findallinventorydetails11", query="SELECT i FROM BoxDetails i WHERE i.dId = :dId and allotStatus = :allotStatus1 ORDER BY i.productVersion"),
    @NamedQuery(name = "BoxDetails.findallinventorydetails21", query="SELECT i FROM BoxDetails i WHERE i.sdId = :sdId and allotStatus = :allotStatus2 ORDER BY i.productVersion"),
    @NamedQuery(name = "BoxDetails.findallinventorydetails31", query="SELECT i FROM BoxDetails i WHERE i.agId = :agId and allotStatus = :allotStatus3 ORDER BY i.productVersion"),
	@NamedQuery(name = "BoxDetails.findallinventorydetailsbyhid", query="SELECT x FROM BoxDetails x WHERE x.hId = :hId and allotStatus = :allotStatus ORDER BY x.productVersion"),
    @NamedQuery(name = "BoxDetails.findallinventorydetailsbydid", query="SELECT i FROM BoxDetails i WHERE i.dId = :dId and allotStatus = :allotStatus1 ORDER BY i.productVersion"),
    @NamedQuery(name = "BoxDetails.findallinventorydetailsbysd", query="SELECT i FROM BoxDetails i WHERE i.sdId = :sdId and allotStatus = :allotStatus2 ORDER BY i.productVersion"),
    @NamedQuery(name = "BoxDetails.findallinventorydetailsbyre", query="SELECT i FROM BoxDetails i WHERE i.agId = :agId and allotStatus = :allotStatus3 ORDER BY i.productVersion"),
    @NamedQuery(name = "BoxDetails.findallinventorydetailsbyhid&allot", query="SELECT x FROM BoxDetails x WHERE x.hId = :hId and allotStatus = :allotStatus ORDER BY x.productVersion"),
    @NamedQuery(name = "BoxDetails.findallinventorydetailsbydid&allot", query="SELECT i FROM BoxDetails i WHERE i.dId = :dId and allotStatus = :allotStatus1 ORDER BY i.productVersion"),
    @NamedQuery(name = "BoxDetails.findallinventorydetailsbysdid&allot", query="SELECT i FROM BoxDetails i WHERE i.sdId = :sdId and allotStatus = :allotStatus2 ORDER BY i.productVersion"),
    @NamedQuery(name = "BoxDetails.findallinventorydetailsbyagid&allot", query="SELECT i FROM BoxDetails i WHERE i.agId = :agId and allotStatus = :allotStatus3 ORDER BY i.productVersion"),
    @NamedQuery(name = "BoxDetails.findseinstockbyid", query = "SELECT b FROM BoxDetails b where b.po=:order "),
    @NamedQuery(name = "BoxDetails.findBetweenBoxSeries", query = "SELECT b FROM BoxDetails b WHERE b.boxSeSrNoFrom = :boxFrom AND b.boxSeSrNoTo = :boxTo"),
    @NamedQuery(name =	"BoxDetails.countbyProductOrderMasterVersion",query="SELECT count(*) FROM BoxDetails b WHERE b.productVersion =:productId AND b.masterVersion=:mvId AND b.po=:poId"),
    @NamedQuery(name ="BoxDetails.findByversionProductOrder",query="SELECT b FROM BoxDetails b WHERE b.productVersion =:productId AND b.masterVersion=:mvId AND b.po=:poId AND b.pId=:pId AND b.hId IS NULL AND b.dId IS NULL AND b.sdId IS NULL AND b.agId IS NULL"),
    @NamedQuery(name ="BoxDetails.findbyBoxseries",query="SELECT b FROM BoxDetails b WHERE b.boxSeSrNoFrom =:boxSeSrNoFrom AND b.boxSeSrNoTo =:boxSeSrNoTo"),
    @NamedQuery(name ="BoxDetails.findByProductIdAndMvidAndhid",query="SELECT b.boxSizeId FROM BoxDetails b Where b.productVersion =:productVersionName AND b.masterVersion =:masterVersionName AND b.hId =:aid AND b.allotStatus =:groupCode"),
    @NamedQuery(name ="BoxDetails.findByProductIdAndMvidAndpid",query="SELECT b.boxSizeId FROM BoxDetails b Where b.productVersion =:productVersionName AND b.masterVersion =:masterVersionName AND b.pId =:aid AND b.allotStatus =:groupCode"),
    @NamedQuery(name ="BoxDetails.findByProductIdAndMvidAnddid",query="SELECT b.boxSizeId FROM BoxDetails b Where b.productVersion =:productVersionName AND b.masterVersion =:masterVersionName AND b.dId =:aid AND b.allotStatus =:groupCode"),
    @NamedQuery(name ="BoxDetails.findByProductIdAndMvidAndsdid",query="SELECT b.boxSizeId FROM BoxDetails b Where b.productVersion =:productVersionName AND b.masterVersion =:masterVersionName AND b.sdId =:aid AND b.allotStatus =:groupCode"),
    @NamedQuery(name ="BoxDetails.findByProductIdAndMvidAndagid",query="SELECT b.boxSizeId FROM BoxDetails b Where b.productVersion =:productVersionName AND b.masterVersion =:masterVersionName AND b.agId =:aid AND b.allotStatus =:groupCode"),
    @NamedQuery(name ="BoxDetails.findBoxDetailsByPoNo",query="SELECT b FROM BoxDetails b Where b.po.poNumber =:poNo"),
})
public class BoxDetails implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id	  	
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "boxSeriesFrom")
    private String boxSeSrNoFrom;
    @Basic(optional = false)
    @Column(name = "boxSeriesTo")
    private String boxSeSrNoTo;
    @Basic(optional = false)
    @Column(name = "boxNumber")
    private String boxNumber;
    @Column(name = "verification")
    private Boolean verification;
    @JoinColumn(name = "boxSizeId", referencedColumnName = "id")	
    @ManyToOne(optional = false)
    private BoxSize boxSizeId;
    @Basic(optional = false)
    @Column(name = "availableSEQty")
    private Integer availableSEQty;
    @Column(name = "allotStatus")
    private String allotStatus;
    @Basic(optional = false)
    @Column(name = "addDate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date addDate;
    @Basic(optional = false)
    @Column(name = "transactionId")
    private String transactionId;
    @Column(name = "editDate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date editDate;
    @Column(name="totalBoxes")
    private Integer totalBoxes;
    @JoinColumn(name = "addById", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private AccountLoginInfo addById;
    @JoinColumn(name = "editById", referencedColumnName = "id")
    @ManyToOne
    private AccountLoginInfo editById;
    @JoinColumn(name = "cardDetailsId", referencedColumnName = "id")
    @ManyToOne
    private CardDetails cardDetailsId;
    @JoinColumn(name="pId", referencedColumnName="id")
    @ManyToOne
    private AccountInfo pId;
    @JoinColumn(name = "hId", referencedColumnName = "id")
    @ManyToOne
    private AccountInfo hId;
    @JoinColumn(name = "agId", referencedColumnName = "id")
    @ManyToOne
    private AccountInfo agId;
    @JoinColumn(name = "po", referencedColumnName = "id")
    @ManyToOne
    private Order po;
    @JoinColumn(name="productVersion", referencedColumnName = "id")
    @ManyToOne
    private Products productVersion;
    @JoinColumn(name="masterVersion", referencedColumnName = "id")
    @ManyToOne
    private MasterVersion masterVersion;
  
    @JoinColumn(name = "dId", referencedColumnName = "id")
    @ManyToOne
    private AccountInfo dId;
    @JoinColumn(name = "sdId", referencedColumnName = "id")
    @ManyToOne
    private AccountInfo sdId;
    
    @Column(name = "status")
    private String status;
    @Column(name = "boxNumberCount")
    private Integer boxNumberCount;
    public BoxDetails() {
    	//empty
    }
public BoxDetails(Integer id) {
    this.id = id;
}
    public CardDetails getCardDetailsId() {
		return cardDetailsId;
	}


	public void setCardDetailsId(CardDetails cardDetailsId) {
		this.cardDetailsId = cardDetailsId;
	}

	
    
   

    
    public Integer getBoxNumberCount() {
		return boxNumberCount;
	}

	public void setBoxNumberCount(Integer boxNumberCount) {
		this.boxNumberCount = boxNumberCount;
	}

	

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getBoxSeSrNoFrom() {
		return boxSeSrNoFrom;
	}

	public void setBoxSeSrNoFrom(String boxSeSrNoFrom) {
		this.boxSeSrNoFrom = boxSeSrNoFrom;
	}

	public Boolean getVerification() {
		return verification;
	}

	public void setVerification(Boolean verification) {
		this.verification = verification;
	}

	public String getBoxSeSrNoTo() {
		return boxSeSrNoTo;
	}

	public void setBoxSeSrNoTo(String boxSeSrNoTo) {
		this.boxSeSrNoTo = boxSeSrNoTo;
	}
	
	public String getAllotStatus() {
		return allotStatus;
	}

	public void setAllotStatus(String allotStatus) {
		this.allotStatus = allotStatus;
	}

	public String getBoxNumber() {
		return boxNumber;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public void setBoxNumber(String boxNumber) {
		this.boxNumber = boxNumber;
	}

	public BoxSize getBoxSizeId() {
		return boxSizeId;
	}

	public void setBoxSizeId(BoxSize boxSizeId) {
		this.boxSizeId = boxSizeId;
	}

	public Integer getAvailableSEQty() {
		return availableSEQty;
	}

	public void setAvailableSEQty(Integer availableSEQty) {
		this.availableSEQty = availableSEQty;
	}

	public Date getAddDate() {
		return addDate;
	}

	public void setAddDate(Date addDate) {
		this.addDate = addDate;
	}

	public Date getEditDate() {
		return editDate;
	}

	public void setEditDate(Date editDate) {
		this.editDate = editDate;
	}

	public AccountLoginInfo getAddById() {
		return addById;
	}

	public void setAddById(AccountLoginInfo addById) {
		this.addById = addById;
	}

	public AccountLoginInfo getEditById() {
		return editById;
	}

	public void setEditById(AccountLoginInfo editById) {
		this.editById = editById;
	}

	

	public AccountInfo getdId() {
		return dId;
	}

	public void setdId(AccountInfo dId) {
		this.dId = dId;
	}


	public AccountInfo gethId() {
		return hId;
	}

	public void sethId(AccountInfo hId) {
		this.hId = hId;
	}
	
	public AccountInfo getSdId() {
		return sdId;
	}

	public void setSdId(AccountInfo sdId) {
		this.sdId = sdId;
	}

	public AccountInfo getAgId() {
		return agId;
	}

	public void setAgId(AccountInfo agId) {
		this.agId = agId;
	}

	public Integer getTotalBoxes() {
		return totalBoxes;
	}

	public void setTotalBoxes(Integer totalBoxes) {
		this.totalBoxes = totalBoxes;
	}

	public AccountInfo getpId() {
		return pId;
	}

	public void setpId(AccountInfo pId) {
		this.pId = pId;
	}

	public Order getPo() {
		return po;
	}

	public void setPo(Order po) {
		this.po = po;
	}

	public Products getProductVersion() {
		return productVersion;
	}

	public void setProductVersion(Products productVersion) {
		this.productVersion = productVersion;
	}

	public MasterVersion getMasterVersion() {
		return masterVersion;
	}

	public void setMasterVersion(MasterVersion masterVersion) {
		this.masterVersion = masterVersion;
	}

	public String getStatus() {
		return status;
	}

	@Override
	public int hashCode() {
		int hash = 0;
		hash += (id != null ? id.hashCode() : 0);
		return hash;
	}
	
	public void setStatus(String status) {
		this.status = status;
	}

	


	@Override
	public boolean equals(Object object) {
		boolean checkStatus=true;
		if(object!=null){
		if (!(object instanceof BoxDetails)) {
			 checkStatus= false;
		}
		BoxDetails other = (BoxDetails) object;
		if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
			 checkStatus= false;
		}
		}
		return  checkStatus;
	}

	@Override
	public String toString() {
		return "com.ng.sb.common.model.BoxDetails[ id=" + id + " ]";
	}

}
