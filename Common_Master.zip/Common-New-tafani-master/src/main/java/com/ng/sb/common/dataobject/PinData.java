package com.ng.sb.common.dataobject;

public class PinData extends PlatformResponseData {
	private static final long serialVersionUID = 1L;
	private String serialNumber;
	private String pinNumber;
	private Float grossAmount;
	private Float netAmount;
	private Float grossCommission;
	private Float netCommission;
	
	private String status;
	
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getPinNumber() {
		return pinNumber;
	}
	public void setPinNumber(String pinNumber) {
		this.pinNumber = pinNumber;
	}
	public Float getNetAmount() {
		return netAmount;
	}
	public void setNetAmount(Float netAmount) {
		this.netAmount = netAmount;
	}
	public Float getGrossCommission() {
		return grossCommission;
	}
	public void setGrossCommission(Float grossCommission) {
		this.grossCommission = grossCommission;
	}
	public Float getNetCommission() {
		return netCommission;
	}
	public void setNetCommission(Float netCommission) {
		this.netCommission = netCommission;
	}
	public Float getGrossAmount() {
		return grossAmount;
	}
	public void setGrossAmount(Float grossAmount) {
		this.grossAmount = grossAmount;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
	
}
