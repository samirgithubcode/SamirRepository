/**
 * 
 */
package com.ng.transaction.dao;


/**
 * @author gaurav
 *
 */
public interface ISettingsDAO extends ITransactionDAO {

}
