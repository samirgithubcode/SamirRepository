package com.ng.sb.common.dataobject;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@JsonIgnoreProperties(ignoreUnknown = true)
public class AccountList {
	private Integer id;
	private String vendorId;
	private String companyName;
	private String hostcompanyName;
	private String discompanyName;
	private String subcompanyName;
	private String agentcompanyName;

	private Integer accountCode;
	private String accountType;
	private String address;
	private String hostName;
	private String distributorName;
	private String subDistributorName;
	private String retailerName;
	private String mobileNo;
	private String altMobileNo;
	private String emailId;
	private String accountStatus;
	public String getHostcompanyName() {
		return hostcompanyName;
	}
	public void setHostcompanyName(String hostcompanyName) {
		this.hostcompanyName = hostcompanyName;
	}
	public String getDiscompanyName() {
		return discompanyName;
	}
	public void setDiscompanyName(String discompanyName) {
		this.discompanyName = discompanyName;
	}
	public String getSubcompanyName() {
		return subcompanyName;
	}
	public void setSubcompanyName(String subcompanyName) {
		this.subcompanyName = subcompanyName;
	}
	public String getAgentcompanyName() {
		return agentcompanyName;
	}
	public void setAgentcompanyName(String agentcompanyName) {
		this.agentcompanyName = agentcompanyName;
	}
	
	
	public String getAccountStatus() {
		return accountStatus;
	}
	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getAltMobileNo() {
		return altMobileNo;
	}
	public void setAltMobileNo(String altMobileNo) {
		this.altMobileNo = altMobileNo;
	}
	
	
	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}
	public String getVendorId() {
		return vendorId;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public Integer getAccountCode() {
		return accountCode;
	}
	public void setAccountCode(Integer accountCode) {
		this.accountCode = accountCode;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getHostName() {
		return hostName;
	}
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}
	public String getDistributorName() {
		return distributorName;
	}
	public void setDistributorName(String distributorName) {
		this.distributorName = distributorName;
	}
	public String getSubDistributorName() {
		return subDistributorName;
	}
	public void setSubDistributorName(String subDistributorName) {
		this.subDistributorName = subDistributorName;
	}
	public String getRetailerName() {
		return retailerName;
	}
	public void setRetailerName(String retailerName) {
		this.retailerName = retailerName;
	}
}
