package com.ng.sb.common.dataobject;

import java.math.BigInteger;
import java.util.List;
import java.util.Map;


public class MisReportData extends BaseObjectData {

	private static final long serialVersionUID = 1L;
	
	private int sno;
	private String txnType;
	private String ip;
	private String clientStoreId;
	private String clientCounterNo;
	private String clientOperatorId;
	private String clientTxnId;
	private String txnId;
	private Double txnAmount;
	private String custPhnNo;
	private String custName;
	private String clientBusinessDate;
	private String userType;
	private String parentName;
	private String storeName;
	private String walletName;
	private Map<Integer, String> distMap;
	private String initiator;
	private String status;
	private Float trxAmount;
	private String agentCode;
	private Integer hostCode;
	private String disttCode;
	private Integer subDistCode;
	private Float agentCommission;
	private Float hostCommission;
	private Float disttCommission;
	private Map<Integer, String> hostMap;
	private Map<Integer, String> subDistMap;
	private Float subDistCommission;
	private String city;
	private Map<Integer, String> agentMap;
	private String agentName;
	private String openingBalance;
	private String closingBalance;
	private String distName;
	private String region;
	private String accountNo;
	private String accntType;
	private String txnDate;
	private Double amount;
	private String txnNature;
	private String particulars;
	private BigInteger count;
	private String commissionAmount;
	private String transactionDescription;
	private Integer subDistributor;
	private Integer distributor;
	private Integer host;
	private List<MisReportData> transactionsList;
	private MisReportData mis;
	private String subDistName;
	private String hostName;
	private List<String> header;
	private String roleName;
	private Double debitAmount;
	private Double creditAmount;
	private String startDate;
	private String endDate;
	private Float bankCommission;
	private String deviceId;
	private String distributorId;
	private String agentId;
	
	private String commissionPostingStatus;
	private String commissionPostingId;
	private String commissionPostingTime;
	private String cardExternalNumber;
	private String bankName;
	private Integer custId;
	
	
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	
	public BigInteger getCount() {
		return count;
	}
	public void setCount(BigInteger row) {
		this.count = row;
	}
	
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getDistName() {
		return distName;
	}
	public void setDistName(String distName) {
		this.distName = distName;
	}
	public String getSubDistName() {
		return subDistName;
	}
	public void setSubDistName(String subDistName) {
		this.subDistName = subDistName;
	}
	
	
	
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getAgentName() {
		return agentName;
	}
	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}
	
	public String getOpeningBalance() {
		return openingBalance;
	}
	public void setOpeningBalance(String openingBalance) {
		this.openingBalance = openingBalance;
	}
	public String getClosingBalance() {
		return closingBalance;
	}
	public void setClosingBalance(String closingBalance) {
		this.closingBalance = closingBalance;
	}
	public Float getAgentCommission() {
		return agentCommission;
	}
	public void setAgentCommission(Float agentCommission) {
		this.agentCommission = agentCommission;
	}
	public Float getHostCommission() {
		return hostCommission;
	}
	public void setHostCommission(Float hostCommission) {
		this.hostCommission = hostCommission;
	}
	public Float getDisttCommission() {
		return disttCommission;
	}
	public void setDisttCommission(Float disttCommission) {
		this.disttCommission = disttCommission;
	}
	public Float getSubDistCommission() {
		return subDistCommission;
	}
	public void setSubDistCommission(Float subDistCommission) {
		this.subDistCommission = subDistCommission;
	}
	
	
	public String getAgentCode() {
		return agentCode;
	}
	public void setAgentCode(String agentCode) {
		this.agentCode = agentCode;
	}
	public Integer getHostCode() {
		return hostCode;
	}
	public void setHostCode(Integer hostCode) {
		this.hostCode = hostCode;
	}
	public String getDisttCode() {
		return disttCode;
	}
	public void setDisttCode(String disttCode) {
		this.disttCode = disttCode;
	}
	public Integer getSubDistCode() {
		return subDistCode;
	}
	public void setSubDistCode(Integer subDistCode) {
		this.subDistCode = subDistCode;
	}
	public Float getTrxAmount() {
		return trxAmount;
	}
	public void setTrxAmount(Float trxAmount) {
		this.trxAmount = trxAmount;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getInitiator() {
		return initiator;
	}
	public void setInitiator(String initiator) {
		this.initiator = initiator;
	}
	public String getWalletName() {
		return walletName;
	}
	public void setWalletName(String walletName) {
		this.walletName = walletName;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	public String getParentName() {
		return parentName;
	}
	public void setParentName(String parentName) {
		this.parentName = parentName;
	}
	public String getStoreName() {
		return storeName;
	}
	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}
	public int getSno() {
		return sno;
	}
	public void setSno(int sno) {
		this.sno = sno;
	}
	public String getTxnType() {
		return txnType;
	}
	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public String getClientStoreId() {
		return clientStoreId;
	}
	public void setClientStoreId(String clientStoreId) {
		this.clientStoreId = clientStoreId;
	}
	public String getClientCounterNo() {
		return clientCounterNo;
	}
	public void setClientCounterNo(String clientCounterNo) {
		this.clientCounterNo = clientCounterNo;
	}
	public String getClientOperatorId() {
		return clientOperatorId;
	}
	public void setClientOperatorId(String clientOperatorId) {
		this.clientOperatorId = clientOperatorId;
	}
	public String getClientTxnId() {
		return clientTxnId;
	}
	public void setClientTxnId(String clientTxnId) {
		this.clientTxnId = clientTxnId;
	}
	public String getTxnId() {
		return txnId;
	}
	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}
	public Double getTxnAmount() {
		return txnAmount;
	}
	public void setTxnAmount(Double txnAmount) {
		this.txnAmount = txnAmount;
	}
	public String getCustPhnNo() {
		return custPhnNo;
	}
	public void setCustPhnNo(String custPhnNo) {
		this.custPhnNo = custPhnNo;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getClientBusinessDate() {
		return clientBusinessDate;
	}
	public void setClientBusinessDate(String clientBusinessDate) {
		this.clientBusinessDate = clientBusinessDate;
	}
	public Map<Integer, String> getDistMap() {
		return distMap;
	}
	public void setDistMap(Map<Integer, String> distMap) {
		this.distMap = distMap;
	}
	public Map<Integer, String> getHostMap() {
		return hostMap;
	}
	public void setHostMap(Map<Integer, String> hostMap) {
		this.hostMap = hostMap;
	}
	public Map<Integer, String> getSubDistMap() {
		return subDistMap;
	}
	public void setSubDistMap(Map<Integer, String> subDistMap) {
		this.subDistMap = subDistMap;
	}
	public Map<Integer, String> getAgentMap() {
		return agentMap;
	}
	public void setAgentMap(Map<Integer, String> agentMap) {
		this.agentMap = agentMap;
	}
	public List<MisReportData> getTransactionsList() {
		return transactionsList;
	}
	public void setTransactionsList(List<MisReportData> transactionsList) {
		this.transactionsList = transactionsList;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getAccntType() {
		return accntType;
	}
	public void setAccntType(String accntType) {
		this.accntType = accntType;
	}
	public String getTxnDate() {
		return txnDate;
	}
	public void setTxnDate(String txnDate) {
		this.txnDate = txnDate;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public String getTxnNature() {
		return txnNature;
	}
	public void setTxnNature(String txnNature) {
		this.txnNature = txnNature;
	}
	public String getParticulars() {
		return particulars;
	}
	public void setParticulars(String particulars) {
		this.particulars = particulars;
	}
	public Integer getSubDistributor() {
		return subDistributor;
	}
	public void setSubDistributor(Integer subDistributor) {
		this.subDistributor = subDistributor;
	}
	public Integer getDistributor() {
		return distributor;
	}
	public void setDistributor(Integer distributor) {
		this.distributor = distributor;
	}
	public Integer getHost() {
		return host;
	}
	public void setHost(Integer host) {
		this.host = host;
	}
	public String getHostName() {
		return hostName;
	}
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}
	public List<String> getHeader() {
		return header;
	}
	public void setHeader(List<String> header) {
		this.header = header;
	}
	public MisReportData getMis() {
		return mis;
	}
	public void setMis(MisReportData mis) {
		this.mis = mis;
	}
	public String getCommissionAmount() {
		return commissionAmount;
	}
	public void setCommissionAmount(String commissionAmount) {
		this.commissionAmount = commissionAmount;
	}
	
	public String getTransactionDescription() {
		return transactionDescription;
	}
	public void setTransactionDescription(String transactionDescription) {
		this.transactionDescription = transactionDescription;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	public Double getDebitAmount() {
		return debitAmount;
	}
	public void setDebitAmount(Double debitAmount) {
		this.debitAmount = debitAmount;
	}
	public Double getCreditAmount() {
		return creditAmount;
	}
	public void setCreditAmount(Double creditAmount) {
		this.creditAmount = creditAmount;
	}
	public Float getBankCommission() {
		return bankCommission;
	}
	public void setBankCommission(Float bankCommission) {
		this.bankCommission = bankCommission;
	}
	public String getDeviceId() {
		return deviceId;
	}
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	public String getDistributorId() {
		return distributorId;
	}
	public void setDistributorId(String distributorId) {
		this.distributorId = distributorId;
	}
	public String getAgentId() {
		return agentId;
	}
	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}
	public String getCommissionPostingStatus() {
		return commissionPostingStatus;
	}
	public void setCommissionPostingStatus(String commissionPostingStatus) {
		this.commissionPostingStatus = commissionPostingStatus;
	}
	public String getCommissionPostingId() {
		return commissionPostingId;
	}
	public void setCommissionPostingId(String commissionPostingId) {
		this.commissionPostingId = commissionPostingId;
	}
	public String getCommissionPostingTime() {
		return commissionPostingTime;
	}
	public void setCommissionPostingTime(String commissionPostingTime) {
		this.commissionPostingTime = commissionPostingTime;
	}
	public String getCardExternalNumber() {
		return cardExternalNumber;
	}
	public void setCardExternalNumber(String cardExternalNumber) {
		this.cardExternalNumber = cardExternalNumber;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public Integer getCustId() {
		return custId;
	}
	public void setCustId(Integer custId) {
		this.custId = custId;
	}

}
