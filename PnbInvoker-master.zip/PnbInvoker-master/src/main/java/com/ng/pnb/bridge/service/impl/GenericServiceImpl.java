/**
 * 
 */
package com.ng.pnb.bridge.service.impl;

import java.util.Date;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ng.pnb.bridge.dao.impl.IPNBDao;
import com.ng.pnb.bridge.invoker.PNBUtility;
import com.ng.pnb.bridge.service.ITransactionService;
import com.ng.pnb.invoker.util.ApiHandler;
import com.ng.pnb.invoker.util.PnbConstants;
import com.ng.sb.common.dataobject.BridgeDataObject;
import com.ng.sb.common.dataobject.BridgeDataObject.ServiceType;
import com.ng.sb.common.dataobject.BridgeDataResponse;
import com.ng.sb.common.dataobject.BridgeDataResponse.Status;
import com.ng.sb.common.dataobject.PlatformLoginData;
import com.ng.sb.common.exception.BankingException;
import com.ng.sb.common.model.CustomerDetails;
import com.ng.sb.common.model.PayeeDetails;
import com.ng.sb.common.model.Subscriber;
import com.ng.sb.common.util.EncryptionUtils;

/**
 * @author gopal
 *
 */
@Service("oromiaService")
public class GenericServiceImpl implements ITransactionService {

	@Autowired
	IPNBDao pnbDao;

	@Autowired
	PNBUtility pnbUtility;
	
	@Autowired
	ApiHandler apiHandler;
	
	@Autowired
	PlatformLoginData platformLoginData;
	
	@Override
	public BridgeDataResponse processRequest(BridgeDataObject bridgeDataObject) 
	{
    	System.out.println("--------------------------------------processRequest PNB invoker generic---------------------------------------");
		BridgeDataResponse response = null;
		
		//Processing Fund Transfer Bank To Bank
		    if(bridgeDataObject.getServiceType() == ServiceType.SETTINGS_CREATE_PIN_TRANSACTION)
			{
		    	System.out.println("create pin api called---------------------------------------");
		    	response = processBankTransactionPinCreation(bridgeDataObject);
				
			}else if(bridgeDataObject.getServiceType() == ServiceType.SETTINGS_CHANGE_PIN_TRANSACTION)
			{
				response = processBankTransactionPinChange(bridgeDataObject);
				
			}else if(bridgeDataObject.getServiceType() == ServiceType.BANKING_FT_B_TO_B || bridgeDataObject.getServiceType()==ServiceType.MWALLET_AG_TOP_UP_ACCOUNT_B_T_B || bridgeDataObject.getServiceType()==ServiceType.OTH_PAY_RET_B_TO_B || bridgeDataObject.getServiceType()==ServiceType.OTH_PAY_INDI_B_TO_B)
			{
				response = processFundTransferBankToBank(bridgeDataObject);
		      
			}else if(bridgeDataObject.getServiceType() == ServiceType.BANKING_FT_B_TO_WALLET || bridgeDataObject.getServiceType() == ServiceType.MWALLET_AG_TOP_UP_ONLINE_B_T_W || bridgeDataObject.getServiceType()==ServiceType.MWALLET_AG_TOP_UP_ACCOUNT_B_T_W||  bridgeDataObject.getServiceType()==ServiceType.MWALLET_CUST_TOP_UP_ONLINE_B_T_W|| bridgeDataObject.getServiceType()==ServiceType.OTH_PAY_RET_B_TO_WALLET ||  bridgeDataObject.getServiceType()==ServiceType.OTH_PAY_INDI_B_TO_WALLET)
			{
				response = serviceNotAvailable(bridgeDataObject);
				
			}else if(bridgeDataObject.getServiceType()==ServiceType.OTH_PAY_RET_WALLET_TO_B ||  bridgeDataObject.getServiceType()==ServiceType.OTH_PAY_INDI_WALLET_TO_B)
			{
				response = serviceNotAvailable(bridgeDataObject);
				
			}else if(bridgeDataObject.getServiceType() == ServiceType.BILL_PAY_BY_B || bridgeDataObject.getServiceType() == ServiceType.TOP_UP_RECH_BY_B)
			{
				response = serviceNotAvailable(bridgeDataObject);
				
			}else if(bridgeDataObject.getServiceType()==ServiceType.MWALLET_AG_TOP_UP_ONLINE_W_T_W || bridgeDataObject.getServiceType()==ServiceType.MWALLET_CUST_CASH_OUT_WALLET || bridgeDataObject.getServiceType()==ServiceType.OTH_PAY_RET_WALLET_TO_WALLET || bridgeDataObject.getServiceType()==ServiceType.OTH_PAY_INDI_WALLET_TO_WALLET)
			{
				response = serviceNotAvailable(bridgeDataObject);
				
			}else if(bridgeDataObject.getServiceType()==ServiceType.BANKING_LAST_5_TRANS)
			{
				response = processBankingTxnHistory(bridgeDataObject);
				
			}else if(bridgeDataObject.getServiceType()==ServiceType.MWALLET_AG_CHK_BAL || bridgeDataObject.getServiceType()==ServiceType.MWALLET_CUST_CHK_BAL)
			{
				response = serviceNotAvailable(bridgeDataObject);
				
			}else if(bridgeDataObject.getServiceType()==ServiceType.BANKING_CHECK_BAL)
			{
				response = processBankBalanceCheck(bridgeDataObject);
				
			}else if(bridgeDataObject.getServiceType()==ServiceType.BANKING_FT_UPI_TO_UPI)
			{
				// TODO: write service for upi to upi ft
	//			response = processBankBalanceCheck(bridgeDataObject);
				
			}else if(bridgeDataObject.getServiceType()==ServiceType.BANKING_CHQ_STATUS || bridgeDataObject.getServiceType()==ServiceType.BANKING_STOP_CHEQUE)
			{
				response = serviceNotAvailable(bridgeDataObject);
				
			}else if(bridgeDataObject.getServiceType() == ServiceType.SETTINGS_MY_PAYEE_ADD || bridgeDataObject.getServiceType()==ServiceType.SETTINGS_MY_PAYEE_EDIT || bridgeDataObject.getServiceType()==ServiceType.SETTINGS_MY_PAYEE_DELETE)
			{
				response = processPayeeManagement(bridgeDataObject);
				
			}else if(bridgeDataObject.getServiceType() == ServiceType.SETTINGS_MY_MERCHANT_ADD || bridgeDataObject.getServiceType()==ServiceType.SETTINGS_MY_MERCHANT_EDIT || bridgeDataObject.getServiceType()==ServiceType.SETTINGS_MY_MERCHANT_DELETE)
			{
				response = processPayeeManagement(bridgeDataObject);
				
			}
		
		    if(response != null)
		    	response.setMsidnToSendMsg(bridgeDataObject.getTransactionData().getMsisdn());
		    
		    bridgeDataObject.setBridgeResponse(response);
		
		return null;
	}

	@Transactional
	private BridgeDataResponse processPayeeManagement(BridgeDataObject bridgeDataObject) 
	{
		BridgeDataResponse response = new BridgeDataResponse();
		try
		{
			Subscriber customerDetails = pnbDao.getSubscriberDetails(bridgeDataObject.getTransactionData().getMsisdn());
			
			if(customerDetails == null)
			{
				pnbUtility.createErrorResponse(bridgeDataObject, PnbConstants.INVALID_CUSTOMER);
				
				response = bridgeDataObject.getBridgeResponse();
				response.setStatus(Status.SUCCESS);
				
				return response;
			}
			
			/**
			 *  Some process to verify Setting PIN
			 */
			
			if(bridgeDataObject.getServiceType() == ServiceType.SETTINGS_MY_PAYEE_ADD)
			{
				PayeeDetails payee = new PayeeDetails();
				
				payee.setCustomerId(customerDetails.getCustId());
				payee.setCustomerMsisdn(Long.parseLong(customerDetails.getMsisdn()));
				payee.setAccountId(EncryptionUtils.hexToString(bridgeDataObject.getPayerBankAccount().getAccountId()));
				payee.setPayeeNickName(bridgeDataObject.getPayerBankAccount().getAccountNickName());
				payee.setAccountName(bridgeDataObject.getPayerBankAccount().getAccountNickName());
				payee.setAccountNumber(Long.parseLong(bridgeDataObject.getPayerBankAccount().getAccountNumber()));
				payee.setIfscCode(bridgeDataObject.getPayerBankAccount().getIfscCode());
				payee.setAccountMmid(bridgeDataObject.getPayerBankAccount().getMmid());
				payee.setPayeeMobileNumber(bridgeDataObject.getPayerWallet().getMsisdn());
				payee.setWalletTypeId(bridgeDataObject.getPayerWallet().getWalletCode());
				
				payee.setWalletNumber((bridgeDataObject.getPayerWallet().getMsisdn() == null || bridgeDataObject.getPayerWallet().getMsisdn().isEmpty())?null:Long.parseLong(bridgeDataObject.getPayerWallet().getMsisdn()));
				payee.setAddedOn(new Date());
				
				pnbDao.saveEntity(payee);
				
				pnbUtility.createErrorResponse(bridgeDataObject, PnbConstants.PAYEE_ADDED_SUCCESSFUL);
				
				response = bridgeDataObject.getBridgeResponse();
				response.setStatus(Status.SUCCESS);
				
			}
			
			
			
		}catch(Exception e)
		{
			pnbUtility.createErrorResponse(bridgeDataObject);
			
			response = bridgeDataObject.getBridgeResponse();
			response.setStatus(Status.FAILED);
			
			return response;
		}
		
		return response;
	}

	@Transactional
	private BridgeDataResponse processBankTransactionPinCreation(BridgeDataObject bridgeDataObject) 
	{
		BridgeDataResponse response = new BridgeDataResponse();
		try
		{
			CustomerDetails customerDetails = pnbDao.getCustomerDetailsByAccount(bridgeDataObject.getPayerBankAccount().getAccountNumber(), bridgeDataObject.getPayerBankAccount().getIfscCode());
			
			if(customerDetails == null)
			{
				pnbUtility.createErrorResponse(bridgeDataObject, PnbConstants.INVALID_CUSTOMER_DETAILS);
				
				response = bridgeDataObject.getBridgeResponse();
				response.setStatus(Status.FAILED);
				
				return response;
			}
			
			/**
			 *  Some process to verify Setting PIN
			 */
			
			customerDetails.setTransactionPin(EncryptionUtils.sha256Hash(bridgeDataObject.getPayerBankAccount().getbPin()));
			
			pnbDao.updateEntity(customerDetails);
			
			pnbUtility.createErrorResponse(bridgeDataObject, PnbConstants.BANKING_PIN_SUCCESSFUL);
			
			response = bridgeDataObject.getBridgeResponse();
			response.setStatus(Status.SUCCESS);
			
			return response;
			
		}catch(Exception e)
		{
			pnbUtility.createErrorResponse(bridgeDataObject);
			
			response = bridgeDataObject.getBridgeResponse();
			response.setStatus(Status.FAILED);
			
			return response;
		}
		
	}

	
	@Transactional
	private BridgeDataResponse processBankTransactionPinChange(BridgeDataObject bridgeDataObject) 
	{
		BridgeDataResponse response = new BridgeDataResponse();
		try
		{
			CustomerDetails customerDetails = pnbDao.getCustomerDetailsByAccount(bridgeDataObject.getPayerBankAccount().getAccountNumber(), bridgeDataObject.getPayerBankAccount().getIfscCode());
			
			if(customerDetails == null)
			{
				pnbUtility.createErrorResponse(bridgeDataObject, PnbConstants.INVALID_CUSTOMER_DETAILS);
				
				response = bridgeDataObject.getBridgeResponse();
				response.setStatus(Status.FAILED);
				
				return response;
			}
			
			/**
			 *  Some process to verify Setting PIN
			 */
			
			if(customerDetails.getTransactionPin() != null && customerDetails.getTransactionPin().equals(EncryptionUtils.sha256Hash(bridgeDataObject.getPayerBankAccount().getOldBankingPin())))
			{
				customerDetails.setTransactionPin(EncryptionUtils.sha256Hash(bridgeDataObject.getPayerBankAccount().getNewBankingPin()));
			
			}else
			{
				pnbUtility.createErrorResponse(bridgeDataObject, PnbConstants.INVALID_OLD_BANKING_PIN);
				
				response = bridgeDataObject.getBridgeResponse();
				response.setStatus(Status.SUCCESS);
				
				return response;
			}
			
			pnbDao.updateEntity(customerDetails);
			
			pnbUtility.createErrorResponse(bridgeDataObject, PnbConstants.BANKING_PIN_CHANGE_SUCCESSFUL);
			
			response = bridgeDataObject.getBridgeResponse();
			response.setStatus(Status.SUCCESS);
			
			return response;
			
		}catch(Exception e)
		{
			pnbUtility.createErrorResponse(bridgeDataObject);
			
			response = bridgeDataObject.getBridgeResponse();
			response.setStatus(Status.FAILED);
			
			return response;
		}
		
	}
	
	private BridgeDataResponse processBankBalanceCheck(BridgeDataObject bridgeDataObject) 
	{
		BridgeDataResponse response = new BridgeDataResponse();
		
		try{
		    //converting Hex to String
			bridgeDataObject.getPayerBankAccount().setbPin(EncryptionUtils.hexToString(bridgeDataObject.getPayerBankAccount().getbPin()));
			
			boolean verifiedCustomer = verifyCustomerByBPin(bridgeDataObject);
			
			if(verifiedCustomer)
			{
				//if(platformLoginData.getBankingIntegrationProtocol().equalsIgnoreCase(PnbConstants.API_BANKING))
					response = apiHandler.processBankBalanceCheck(bridgeDataObject);
				
			}else{
				
				pnbUtility.createErrorResponse(bridgeDataObject, "Invalid Banking Pin.");
				
				response = bridgeDataObject.getBridgeResponse();
				response.setStatus(Status.FAILED);
				
			}
			
		}catch(BankingException e)
		{
			if(e instanceof BankingException)
				pnbUtility.createErrorResponse(bridgeDataObject, e.getMessage());
			else
				pnbUtility.createErrorResponse(bridgeDataObject);
			
			response = bridgeDataObject.getBridgeResponse();
			response.setStatus(Status.FAILED);
			
		}
		
		return response;
	}

	private BridgeDataResponse processBankingTxnHistory(BridgeDataObject bridgeDataObject) 
	{
		BridgeDataResponse response = new BridgeDataResponse();
		try{
			
			//converting Hex to String
			bridgeDataObject.getPayerBankAccount().setbPin(EncryptionUtils.hexToString(bridgeDataObject.getPayerBankAccount().getbPin()));
			
			boolean verifiedCustomer = verifyCustomerByBPin(bridgeDataObject);
			
			if(verifiedCustomer)
				response = apiHandler.processBankingTxnHistory(bridgeDataObject);
			else{
				
				pnbUtility.createErrorResponse(bridgeDataObject, "Invalid Banking Pin.");
				
				response = bridgeDataObject.getBridgeResponse();
				response.setStatus(Status.FAILED);
			
			}
			
		}catch(BankingException e)
		{
				pnbUtility.createErrorResponse(bridgeDataObject, e.getMessage());
			
			response = bridgeDataObject.getBridgeResponse();
			response.setStatus(Status.FAILED);
		}
		
		return response;
	}

	
	/**
	 *  Wallet API required to complete the implementation
	 * @param bridgeDataObject
	 * @return
	 */
	private BridgeDataResponse serviceNotAvailable(BridgeDataObject bridgeDataObject) 
	{
		BridgeDataResponse response = new BridgeDataResponse();
		
		response.setStatus(Status.SUCCESS);
		response.setResponseMsg(PnbConstants.REQUESTED_SERVICE_NOT_AVAILABLE);
		
		return response;
	}

	private BridgeDataResponse processFundTransferBankToBank(BridgeDataObject bridgeDataObject) 
	{

		BridgeDataResponse response = new BridgeDataResponse();
		
		boolean isOnUsTransaction = false;
		
		bridgeDataObject.getPayerBankAccount().setbPin(EncryptionUtils.hexToString(bridgeDataObject.getPayerBankAccount().getbPin()));
		
		String payeeIFSC = bridgeDataObject.getPayeeBankAccount().getIfscCode();
		
		String payerIFSC = bridgeDataObject.getPayerBankAccount().getIfscCode();
		
		if(payerIFSC == null || payerIFSC.isEmpty() || payerIFSC.length() != 11)
		{
			response.setStatus(Status.FAILED);
			response.setResponseMsg("INVALID PAYER IFSC CODE.");
			
			return response;
		}
		
		if(payeeIFSC == null || payeeIFSC.isEmpty() || payeeIFSC.length() != 11)
		{
			response.setStatus(Status.FAILED);
			response.setResponseMsg("INVALID PAYEE IFSC CODE.");
			
			return response;
		}
			
		
		if(payerIFSC.substring(0, 4).equalsIgnoreCase(payeeIFSC.substring(0, 4)))
			isOnUsTransaction = true;
		
		if(isOnUsTransaction)
		{
			//Hit fund transafer API
			try{
				
				boolean verifiedCustomer = verifyCustomerByBPin(bridgeDataObject);
				
				if(verifiedCustomer)
				{
					response = apiHandler.processFundTransferBankToBank(bridgeDataObject);
					
				}else{
					pnbUtility.createErrorResponse(bridgeDataObject, "Invalid Banking Pin.");
				}
				
			}catch(BankingException e)
			{
				e.printStackTrace();
				
				pnbUtility.createErrorResponse(bridgeDataObject);
			}
			
			 return bridgeDataObject.getBridgeResponse();
			
		}else{
			
			response = serviceNotAvailable(bridgeDataObject);
		}
		
		return response;
	}

	private boolean verifyCustomerByBPin(BridgeDataObject bridgeDataObject) throws BankingException
	{
			CustomerDetails customerDetails = pnbDao.getCustomerDetailsByAccount(bridgeDataObject.getPayerBankAccount().getAccountNumber(), bridgeDataObject.getPayerBankAccount().getIfscCode());
			
			if(customerDetails == null)
				throw new BankingException("Invalid Account Number and IFSC code.");
			
			/*if(customerDetails.getTransactionPin() == null)
				throw new BankingException("Banking Pin not set for given account.");
			
			if(bridgeDataObject.getPayerBankAccount().getbPin() == null)
				throw new BankingException("Invalid Banking Pin.");*/
			
			bridgeDataObject.getPayerBankAccount().setUserId(customerDetails.getUserId());
			
			//return (customerDetails.getTransactionPin().equalsIgnoreCase(EncryptionUtils.sha256Hash(bridgeDataObject.getPayerBankAccount().getbPin())));
		return true;
	}

}
