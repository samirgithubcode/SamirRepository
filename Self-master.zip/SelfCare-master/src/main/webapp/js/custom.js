$("#menu-toggle").click(function(e) {
	"use strict";
	e.preventDefault();
	$("#wrapper").toggleClass("toggled");
	$(this).toggleClass("menu-active");
});
$(document).ready(function() {
	"use strict";
    $('#example').DataTable();
} );
