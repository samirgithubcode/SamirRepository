/**
 * 
 */
package com.ng.user.dto;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.ng.sb.common.util.CustomJsonDateTimeSerializer;

/**
 * @author gopal
 *
 */
@JsonInclude(Include.NON_NULL)
public class TxnHistoryResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4417781119448484490L;

	private String txnId;
	
	private String customerName;
	
	private String customerMsisdn;
	
	private String txnInstrument;
	
	private String appName;
	
	private String walletName;
	
	private Double txnAmount;
	
	@JsonSerialize(using = CustomJsonDateTimeSerializer.class)
	private Date txnTime;
	
	private String txnType;
	
	private Integer txnStatus;
	
	private Integer txnRefundRefId;

	private String accessChannel;
	
	private String agentName;
	
	private String agentMsisdn;
	
	private String subscriberName;
	
	private String subscriberNumber;
	
	private String transactionNature;
	
	private Double closingBalance;
	
	private Double commAmount;
	
	private Double netTxnAmount;
	
	private String productType;
	
	private String productId;
	
	public String getTxnId() {
		return txnId;
	}

	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerMsisdn() {
		return customerMsisdn;
	}

	public void setCustomerMsisdn(String customerMsisdn) {
		this.customerMsisdn = customerMsisdn;
	}

	public String getTxnInstrument() {
		return txnInstrument;
	}

	public void setTxnInstrument(String txnInstrument) {
		this.txnInstrument = txnInstrument;
	}

	public Double getTxnAmount() {
		return txnAmount;
	}

	public void setTxnAmount(Double txnAmount) {
		this.txnAmount = txnAmount;
	}

	public Date getTxnTime() {
		return txnTime;
	}

	public void setTxnTime(Date txnTime) {
		this.txnTime = txnTime;
	}

	public String getTxnType() {
		return txnType;
	}

	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}

	public Integer getTxnStatus() {
		return txnStatus;
	}

	public void setTxnStatus(Integer txnStatus) {
		this.txnStatus = txnStatus;
	}

	public Integer getTxnRefundRefId() {
		return txnRefundRefId;
	}

	public void setTxnRefundRefId(Integer txnRefundRefId) {
		this.txnRefundRefId = txnRefundRefId;
	}

	public String getAccessChannel() {
		return accessChannel;
	}

	public void setAccessChannel(String accessChannel) {
		this.accessChannel = accessChannel;
	}

	public String getAgentName() {
		return agentName;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}

	public String getAgentMsisdn() {
		return agentMsisdn;
	}

	public void setAgentMsisdn(String agentMsisdn) {
		this.agentMsisdn = agentMsisdn;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getWalletName() {
		return walletName;
	}

	public void setWalletName(String walletName) {
		this.walletName = walletName;
	}

	public String getSubscriberName() {
		return subscriberName;
	}

	public void setSubscriberName(String subscriberName) {
		this.subscriberName = subscriberName;
	}

	public String getSubscriberNumber() {
		return subscriberNumber;
	}

	public void setSubscriberNumber(String subscriberNumber) {
		this.subscriberNumber = subscriberNumber;
	}

	public String getTransactionNature() {
		return transactionNature;
	}

	public void setTransactionNature(String transactionNature) {
		this.transactionNature = transactionNature;
	}

	public Double getClosingBalance() {
		return closingBalance;
	}

	public void setClosingBalance(Double closingBalance) {
		this.closingBalance = closingBalance;
	}

	public Double getCommAmount() {
		return commAmount;
	}

	public void setCommAmount(Double commAmount) {
		this.commAmount = commAmount;
	}

	public Double getNetTxnAmount() {
		return netTxnAmount;
	}

	public void setNetTxnAmount(Double netTxnAmount) {
		this.netTxnAmount = netTxnAmount;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}
	
}
