package com.ng.pnb.invoker.util;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

import org.jpos.iso.BaseChannel;
import org.jpos.iso.ISOException;
import org.jpos.iso.ISOMsg;
import org.jpos.iso.ISOPackager;
import org.jpos.iso.ISOUtil;
import org.jpos.iso.channel.NACChannel;
import org.jpos.iso.packager.GenericPackager;
import org.jpos.util.Logger;
import org.jpos.util.SimpleLogListener;

public class ModeFinDemoClass {

	public static Socket sock = null;
	public static InputStream sockInput = null;
	public static OutputStream sockOutput = null;
	public static BaseChannel baseChannel = null;

	/**R
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		try {
			ModeFinDemoClass services = new ModeFinDemoClass();
			ISOMsg isoMsg = new ISOMsg();

			String hostName = "efedha.com";
			//String hostName = "10.117.4.17";
			//String hostName = "10.117.4.109";
			int port =1009;
			/*int port=1234;*/
			//int port  = 12345;
			Logger logger = new Logger();

			logger.addListener(new SimpleLogListener(System.out));

			ISOPackager packager;
			packager = new GenericPackager(
					"D:/backup/Rasika Backups/JposServerSimulation/bin/com/mode/test/Basic.xml");
			//((ISOPackager) packager).setLogger(logger, "debug");
			baseChannel = new NACChannel(hostName, port, packager, null);
			try {
				baseChannel.connect();
			} catch (Exception e) {
				e.printStackTrace();
			}

			//isoMsg = services.prepareLoanBalanceRequest();
			
			logISOMsg(isoMsg);
			try {
				baseChannel.send(isoMsg);
				ISOMsg isoResponse = null;
				isoResponse = baseChannel.receive();
				logISOMsg(isoResponse);			

			} catch (Exception e) {

				e.printStackTrace();

			}

		} catch (ISOException e) {
			e.printStackTrace();
		} finally {
			try {
				baseChannel.disconnect();
			} catch (Exception e) {

				e.printStackTrace();
			}
		}
	}

	public static void logISOMsg(ISOMsg msg) {
		System.out.println("----ISO MESSAGE-----");
		try {
			System.out.println("  MTI : " + msg.getMTI());
			for (int i = 1; i <= msg.getMaxField(); i++) {
				if (msg.hasField(i)) {
					System.out
							.println("    DE-" + i + " : " + msg.getString(i));
				}
			}
		} catch (ISOException e) {
			e.printStackTrace();
		} finally {
			System.out.println("--------------------");
		}

	}

}
