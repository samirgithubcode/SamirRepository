package com.ng.sb.common.dataobject;

public class KYCLevelData extends BaseObjectData {

	private static final long serialVersionUID = 1L;
    private Integer weight;
    private java.util.List<KYCLevelData> idlevellist; 
	public java.util.List<KYCLevelData> getIdlevellist() {
		return idlevellist;
	}
	public void setIdlevellist(java.util.List<KYCLevelData> idlevellist) {
		this.idlevellist = idlevellist;
	}
	public Integer getWeight() {
		return weight;
	}
	public void setWeight(Integer weight) {
		this.weight = weight;
	}
	

}
