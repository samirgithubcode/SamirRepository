package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

/**
*
* @author Simran
* 
* The persistent class for the customer KYC verification database table.
*/
@Entity
@Table(name = "kyc_verification")
@XmlRootElement
@NamedQueries({
	@NamedQuery(name = "kyc_verification.findById", query = "SELECT c FROM KycVerificationDetails c  where c.id=:id"),
	/*@NamedQuery(name = "CustomerKYC.findnameandweightage", query = "SELECT c FROM CustomerKYC c  ORDER BY c.order ")*/
})
public class KycVerificationDetails implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Column(name = "request_type")
    private String requestType;
    @OneToOne
	@JoinColumn(name = "query_id", referencedColumnName = "id")
    @NotFound(action = NotFoundAction.IGNORE) 
    private CustomerQueryLog queryId;
	@Column(name = "created_on")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createDate;
    @Column(name = "created_by") 
    private Integer createdBy;    
    public KycVerificationDetails() {
 		//default
 	}
    public KycVerificationDetails(Integer id) {
        this.id = id;
    }
 
	


	@Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
    	boolean check=true;
    	if(object!=null){
        if (!(object instanceof KycVerificationDetails)) {
        	check= false;
        }
        KycVerificationDetails other = (KycVerificationDetails) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
    	}
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.KycVerificationDetails[ id=" + id + " ]";
    }
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getRequestType() {
		return requestType;
	}
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	public CustomerQueryLog getQueryId() {
		return queryId;
	}
	public void setQueryId(CustomerQueryLog queryId) {
		this.queryId = queryId;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	
	
}