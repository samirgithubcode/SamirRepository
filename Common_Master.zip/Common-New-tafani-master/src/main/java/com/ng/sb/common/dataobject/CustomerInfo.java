/**
 * 
 */
package com.ng.sb.common.dataobject;

/**
 * @author gaurav
 * This class will hold customer's information like mobile# and Other Info which is non-mandatory
 */
public class CustomerInfo extends BaseObjectData {
	private static final long serialVersionUID = 1L;
	private String mobileNumber;
	private String oldMobileNumber;
	private OtherInfo otherInfo;
	
	
	public OtherInfo getOtherInfo() {
		return otherInfo;
	}
	public void setOtherInfo(OtherInfo otherInfo) {
		this.otherInfo = otherInfo;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	/**
	 * @return the oldMobileNumber
	 */
	public String getOldMobileNumber() {
		return oldMobileNumber;
	}
	/**
	 * @param oldMobileNumber the oldMobileNumber to set
	 */
	public void setOldMobileNumber(String oldMobileNumber) {
		this.oldMobileNumber = oldMobileNumber;
	}
	
}
