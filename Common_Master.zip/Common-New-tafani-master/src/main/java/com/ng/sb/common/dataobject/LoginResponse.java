package com.ng.sb.common.dataobject;

import java.io.Serializable;

public class LoginResponse implements Serializable {
private static final long serialVersionUID = -746456166864235090L;
	
	private int status;
	private int userTypeId;
	private String message;
	private String tokenId;
	private String userId;
	private String userName;
	
	private String key;
	private boolean firstLogin;
	private int accountTypeId;
	private String lastPasswordDate;
	private Integer accountId;
	private String accountTypeCode;
	
	private Integer parentId;
	
	public String getAccountTypeCode() {
		return accountTypeCode;
	}
	public void setAccountTypeCode(String accountTypeCode) {
		this.accountTypeCode = accountTypeCode;
	}
    public Integer getParentId() {
		return parentId;
	}
	public void setParentId(Integer parentId) {
		this.parentId = parentId;
	}
	public Integer getAccountId() {
		return accountId;
	}
	public void setAccountId(Integer accountId) {
		this.accountId = accountId;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public String getGroupCode() {
		return groupCode;
	}
	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}
	public String getGroupWeight() {
		return groupWeight;
	}
	public void setGroupWeight(String groupWeight) {
		this.groupWeight = groupWeight;
	}
	public String getContactPersonName() {
		return contactPersonName;
	}
	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}
	private String groupId;
	
	private String groupCode;
	private String groupWeight;
	private String contactPersonName;
	
	
	
    
	
	

	public String getLastPasswordDate() {
		return lastPasswordDate;
	}
	public void setLastPasswordDate(String lastPasswordDate) {
		this.lastPasswordDate = lastPasswordDate;
	}
	public boolean isFirstLogin() {
		return firstLogin;
	}
	public void setFirstLogin(boolean firstLogin) {
		this.firstLogin = firstLogin;
	}
	public int getAccountTypeId() {
		return accountTypeId;
	}
	public void setAccountTypeId(int accountTypeId) {
		this.accountTypeId = accountTypeId;
	}
	
public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public int getUserTypeId() {
		return userTypeId;
	}
	public void setUserTypeId(int userTypeId) {
		this.userTypeId = userTypeId;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getTokenId() {
		return tokenId;
	}
	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}

	}
