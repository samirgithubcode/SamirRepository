package com.ng.sb.common.dataobject;

public class PortalUrlListData extends BaseObjectData {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String urlList;
	public String getUrlList() {
		return urlList;
	}
	public void setUrlList(String urlList) {
		this.urlList = urlList;
	}
	

}
