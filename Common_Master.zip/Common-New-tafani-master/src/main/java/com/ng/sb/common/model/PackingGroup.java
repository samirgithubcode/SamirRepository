package com.ng.sb.common.model;
import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name = "packinggroup")
@XmlRootElement
@NamedQueries({
	@NamedQuery(name = "PackingGroup.findAll", query = "SELECT p FROM PackingGroup p"),
	@NamedQuery(name = "PackingGroup.findById", query = "SELECT p FROM PackingGroup p WHERE p.id=:id"),
	@NamedQuery(name = "PackingGroup.findByName", query = "SELECT p FROM PackingGroup p WHERE p.groupName=:groupName"),
	@NamedQuery(name = "PackingGroup.productType", query = "SELECT p FROM PackingGroup p WHERE p.productType=:productType"),
	@NamedQuery(name = "PackingGroup.productTypeAndLevelNumber", query = "SELECT p FROM PackingGroup p WHERE p.productType=:productType AND p.levelNumber=:levelNumber"),
	
	@NamedQuery(name = "PackingGroup.findparentId", query = "SELECT p FROM PackingGroup p WHERE p.parentId=:parentId  or p.id=:id"),
	@NamedQuery(name = "PackingGroup.findMaxLevelByType", query = "SELECT MAX(p.levelNumber)  FROM PackingGroup p WHERE p.productType=:productType AND p.status=true"),
	@NamedQuery(name = "PackingGroup.getPackageGroupDetails", query = "SELECT packageGroup FROM PackingGroup packageGroup WHERE packageGroup.productType=:productType AND packageGroup.levelNumber='0' AND packageGroup.quantity=:count AND packageGroup.totalCount=:total_count "),
})
public class PackingGroup implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
    @Id	  	
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @JoinColumn(name="parentId", referencedColumnName="id")
    @ManyToOne
    private PackingGroup parentId;
    @Column(name = "count")
    private Integer quantity;
    @Column(name = "total_count")
    private Integer totalCount;
    @Column(name = "name")
    private String groupName;
    @Column(name = "productType")
    private String productType;
    @Column(name = "start_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date startDate;
    @Column(name = "end_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date endDate;
    @Column(name = "status")
    private Boolean status;
    @Column(name="levelNumber")
    private Integer levelNumber;
    public Integer getLevelNumber() {
		return levelNumber;
	}
	public void setLevelNumber(Integer levelNumber) {
		this.levelNumber = levelNumber;
	}
	public PackingGroup()
	{
	//default	
	}
	public PackingGroup(Integer id)
	{
		this.id=id;
	}
    
	public Boolean isStatus() {
		return status;
	}
	public void setStatus(Boolean status) {
		this.status = status;
	}
	public Integer getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(Integer totalCount) {
		this.totalCount = totalCount;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public PackingGroup getParentId() {
		return parentId;
	}
	public void setParentId(PackingGroup parentId) {
		this.parentId = parentId;
	}
	public Integer getQuantity() {
		return quantity;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PackingGroup other = (PackingGroup) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	@Override
	public int hashCode() {
		 int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

}
