/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "HostSVWalletMapping")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "HostSVWalletMapping.findAll", query = "SELECT h FROM HostSVWalletMapping h"),
    @NamedQuery(name = "HostSVWalletMapping.findById", query = "SELECT h FROM HostSVWalletMapping h WHERE h.id = :id"),
    @NamedQuery(name = "HostSVWalletMapping.findByHostSVId", query = "SELECT h FROM HostSVWalletMapping h WHERE h.hsvId.id = :hsvId")
    
})
public class HostSVWalletMapping implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
    @JoinColumn(name = "hostId", referencedColumnName = "id")
    @ManyToOne
    private AccountInfo hostId;
    @JoinColumn(name = "hsvId", referencedColumnName = "id")
    @ManyToOne
    private HostSubVersion hsvId;
    @JoinColumn(name = "walletId", referencedColumnName = "id")
    @ManyToOne
    private Partner walletId;
    
    @Column(name = "walletType")
    private String walletType;

    public String getWalletType() {
		return walletType;
	}

	public void setWalletType(String walletType) {
		this.walletType = walletType;
	}

	public HostSVWalletMapping() {
		//default constructor
    }

    public HostSVWalletMapping(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public AccountInfo getHostId() {
        return hostId;
    }

    public void setHostId(AccountInfo hostId) {
        this.hostId = hostId;
    }

    public HostSubVersion getHsvId() {
        return hsvId;
    }

    public void setHsvId(HostSubVersion hsvId) {
        this.hsvId = hsvId;
    }

    public Partner getWalletId() {
        return walletId;
    }

    public void setWalletId(Partner walletId) {
        this.walletId = walletId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof HostSVWalletMapping)) {
            return false;
        }
        HostSVWalletMapping other = (HostSVWalletMapping) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.HostSVWalletMapping[ id=" + id + " ]";
    }
    
}
