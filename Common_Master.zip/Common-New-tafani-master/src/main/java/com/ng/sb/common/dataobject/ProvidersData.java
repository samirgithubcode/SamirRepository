package com.ng.sb.common.dataobject;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

/**
 * @author gaurav
 *
 */
public class ProvidersData extends BaseObjectData {

	private static final long serialVersionUID = 1L;
	private CategoryData category;
	private String offerCode;
	private String subscriberId;
	private String mappingId;
	private Integer providerCode;
	private Integer showData;
	private Map<PartnerData,PartnerData> partnerMap=new HashMap<>();
	private Set<PartnerData> partners=new TreeSet<>();
	protected Integer code;
	
	public ProvidersData() {
//empty
	}

	public ProvidersData(Integer code,Integer catCode) {
		this.code=code;
		if(this.category==null){
			this.category=new CategoryData();
		}
		this.category.setCode(catCode);
	}
	
	public Integer getShowData() {
		return showData;
	}

	public void setShowData(Integer showData) {
		this.showData = showData;
	}
	
	public ProvidersData(Integer code) {
		this.code=code;
		}
	
	
	public Map<PartnerData, PartnerData> getPartnerMap() {
		return partnerMap;
	}

	public void setPartnerMap(Map<PartnerData, PartnerData> partnerMap) {
		this.partnerMap = partnerMap;
	}


	

	public Integer getProviderCode() {
		return providerCode;
	}

	public void setProviderCode(Integer providerCode) {
		this.providerCode = providerCode;
	}

	public Set<PartnerData> getPartners() {
		return partners;
	}

	public void setPartners(Set<PartnerData> partners) {
		this.partners = partners;
	}

	public CategoryData getCategory() {
		return category;
	}

	public void setCategory(CategoryData category) {
		this.category = category;
	}

	public String getOfferCode() {
		return offerCode;
	}

	public void setOfferCode(String offerCode) {
		this.offerCode = offerCode;
	}
	
	public String getSubscriberId() {
		return subscriberId;
	}

	public void setSubscriberId(String subscriberId) {
		this.subscriberId = subscriberId;
	}

	
	
	public String getMappingId() {
		return mappingId;
	}

	public void setMappingId(String mappingId) {
		this.mappingId = mappingId;
	}

	@Override
	public boolean equals(Object obj) {
		if(obj==null){
			return false;
		}
		if(obj instanceof ProvidersData){
			ProvidersData other = (ProvidersData)obj;
		 if(this.getCode().equals(other.getCode())){
				return true;
			}
			
		}
		return false;
	}
	
	@Override
	public int hashCode() {
		if( this.getCode()!=null){
			return this.getCode();	
		}else{
			return 0;
		}
		
	}
	
	public Integer getCode() {
		return code;
	}
	public void setCode(Integer code) {
		this.code = code;
	}
}
