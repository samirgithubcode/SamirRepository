package com.ng.bridge.dao.imp;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.ng.bridge.dao.ICustWalletDAO;
import com.ng.bridge.util.NewConstants;
import com.ng.sb.common.model.CustMerchFinInstMapping;
import com.ng.sb.common.model.CustMerchPoolTransaction;
import com.ng.sb.common.model.CustMerchTransaction;
import com.ng.sb.common.model.Customer;
import com.ng.sb.common.model.MerchantInfo;
import com.ng.sb.common.model.MerchantIpMapping;
import com.ng.sb.common.model.Partner;
@Repository
public class CustWalletDAO  implements ICustWalletDAO{

	private static final long serialVersionUID = 1L;
	@PersistenceContext
	protected EntityManager entityManager;
	private static final Logger LOGGER = LoggerFactory.getLogger(CustWalletDAO.class);
	
	@Override
	public MerchantIpMapping checkIp(String ip)  {
		LOGGER.debug("****************** checkIp() starts executing ***************");
		try{
			TypedQuery<MerchantIpMapping> query=entityManager.createNamedQuery("MerchantIpMapping.findByMerchantIp",MerchantIpMapping.class);
			query.setParameter("ip",ip);
			List<MerchantIpMapping> list=query.getResultList();
			if(list.isEmpty()){
				return list.get(0); 
			}
			else{
				return null;
			}
		}
		catch(Exception e){
			LOGGER.info(NewConstants.EXCEPTIONOCCURED+" : "+e);
			throw e;
		}
	}

	@Override
	public MerchantInfo checkKey(String key) {
		LOGGER.debug("****************** checkKey() starts executing ***************");
		List<MerchantInfo> list=null;
		try{
			TypedQuery<MerchantInfo> query=entityManager.createNamedQuery("MerchantInfo.findBykey",MerchantInfo.class);
			query.setParameter("key",key);
			list=query.getResultList();
			if(list.isEmpty()){
				return list.get(0); 
			}
			else
			{
				return null;
			}
		}
		catch(Exception e){
			LOGGER.info(NewConstants.EXCEPTIONOCCURED+" : "+e.getLocalizedMessage());
			throw e;
		}
	}

	@Override
	public Partner checkWalletStatus(Integer walletCode)  {
		LOGGER.debug("****************** checkWalletStatus() starts executing ***************");
		List<Partner> list=null;
		try{
			TypedQuery<Partner> query=entityManager.createNamedQuery("Partner.findByPartnerCode",Partner.class);
			query.setParameter("partnerCode",walletCode);
			list=query.getResultList();
			if(list.isEmpty()){
				return list.get(0);
			}
			else{
				return null;
			}
		}
		catch(Exception e){
			LOGGER.info(NewConstants.EXCEPTIONOCCURED+" : "+e.getLocalizedMessage());
			throw e;
		}
	}

	@Override
	public CustMerchFinInstMapping checkCustomerStatus(Partner wId, String mobileNumber) {
		LOGGER.debug("****************** checkCustomerStatus() starts executing ***************");
		List<CustMerchFinInstMapping> list=null;
		try{
			TypedQuery<CustMerchFinInstMapping> query=entityManager.createNamedQuery("CustMerchFinInstMapping.findByWalletIdAndWId",CustMerchFinInstMapping.class);
			query.setParameter("wId",wId);
			query.setParameter("walletId",mobileNumber);
			list=query.getResultList();
			if(list.isEmpty()){
				return list.get(0);
			}
			else{
				return null;
			}
		}
		catch(Exception e){
			LOGGER.info(NewConstants.EXCEPTIONOCCURED+" : "+e.getLocalizedMessage());
			throw e;
		}
	}

	@Override
	public CustMerchFinInstMapping getMerchantdetails(MerchantInfo merchantInfo,Partner partner)  {
		LOGGER.debug("****************** getMerchantdetails() starts executing ***************");
		List<CustMerchFinInstMapping> list=null;
		try{
			TypedQuery<CustMerchFinInstMapping> query=entityManager.createNamedQuery("CustMerchFinInstMapping.findByMerchantIdandPartner",CustMerchFinInstMapping.class);
			query.setParameter("merchantId",merchantInfo);
			query.setParameter("wId",partner);
			list=query.getResultList();
			if(list.isEmpty()){
				return list.get(0);
			}
			else{
				return null;
			}
		}
		catch(Exception e){
			LOGGER.info(NewConstants.EXCEPTIONOCCURED+" : "+e.getLocalizedMessage());
			throw e;
		}
	}

	@Override
	@Transactional
	public CustMerchFinInstMapping updateCustMerchFinInstMappingInfo(CustMerchFinInstMapping custMerchFinInstMapping)  {
		LOGGER.debug("*********** updateMerchantInfo() starts executing  *************");
		try
		{
			entityManager.merge(custMerchFinInstMapping);
		}
		catch(Exception ex)
		{
			LOGGER.info("Exception occurred in updatePortalData() method in PortalDAO --->"+ex);
		}
		return custMerchFinInstMapping;
	}

	@Override
	@Transactional
	public CustMerchPoolTransaction updateCustMerchPoolTransaction(CustMerchPoolTransaction custMerchTransaction)  {
		CustMerchPoolTransaction cust=new CustMerchPoolTransaction();
		LOGGER.debug("*********** updateCustMerchTransaction() starts executing  *************");
		try
		{
			cust=entityManager.merge(custMerchTransaction);
		}
		catch(Exception ex)
		{
			LOGGER.info("Exception occurred in updateCustMerchTransaction() method in PortalDAO --->"+ex);
		}
		return cust;
	}

	@Override
	public CustMerchPoolTransaction getTransactionInfo(String transactionId)  {
		LOGGER.debug("****************** getTransactionInfo() starts executing ***************");
		List<CustMerchPoolTransaction> list=null;
		try{
			TypedQuery<CustMerchPoolTransaction> query=entityManager.createNamedQuery("CustMerchPoolTransaction.findByPreviousTransactionId",CustMerchPoolTransaction.class);
			query.setParameter("clientTransactionId",transactionId);
			list=query.getResultList();
			if(list.isEmpty()){
				return list.get(0);
			}
			else{
				return null;
			}
	}
		catch(Exception ex)
		{
			LOGGER.info(NewConstants.EXCEPTIONOCCURED+" : "+ex);
			return null;
		}
		
 }

	@Override
	public CustMerchTransaction getCustMerchTransactionRefund(String previousTransactionId) {
		LOGGER.debug("****************** getTransactionInfo() starts executing ***************");
		List<CustMerchTransaction> list=null;
		try{
			TypedQuery<CustMerchTransaction> query=entityManager.createNamedQuery("CustMerchTransaction.findByPreviousTransactionIdAndStatus",CustMerchTransaction.class);
			query.setParameter("clientTransactionId",previousTransactionId);
			query.setParameter("status","SUCCESS");
			query.setParameter("transactionType","DEDUCT BALANCE");
			list=query.getResultList();
			if(list.isEmpty()){
				return list.get(0);
			}
			else{
				return null;
			}
	}
		catch(Exception ex)
		{
			LOGGER.info(NewConstants.EXCEPTIONOCCURED+" : "+ex);
			return null;
		}
	}
	
	@Override
	@Transactional
	public CustMerchTransaction saveCustMerchTransaction(CustMerchTransaction custMerchTransaction) {
		LOGGER.debug("*********** saveCustMerchTransaction() starts executing  *************");
		try
		{
			entityManager.merge(custMerchTransaction);
		}
		catch(Exception ex)
		{
			LOGGER.info("Exception occurred in saveCustMerchTransaction() method in PortalDAO --->"+ex);
		}
		return custMerchTransaction;
	}

	@Override
	public CustMerchTransaction getTransactionInfoByOurId(String transactionId,String status)  {
		LOGGER.debug("****************** getTransactionInfoByOurId() starts executing ***************");
		List<CustMerchTransaction> list=null;
		try{
			TypedQuery<CustMerchTransaction> query=entityManager.createNamedQuery("CustMerchTransaction.findByTransactionIdOurId",CustMerchTransaction.class);
			query.setParameter("transactionId",transactionId);
			query.setParameter("status",status);
			list=query.getResultList();
			if(list.isEmpty()){
				return list.get(0);
			}
			else{
				return null;
			}
	}
		catch(Exception ex)
		{
			LOGGER.info(NewConstants.EXCEPTIONOCCURED+" : "+ex);
			return null;
		}
	}

	@Override
	public CustMerchFinInstMapping checkCustomerStatusForRefund(String mobileNumber) {
		LOGGER.debug("****************** checkCustomerStatus() starts executing ***************");
		List<CustMerchFinInstMapping> list=null;
		try{
			TypedQuery<CustMerchFinInstMapping> query=entityManager.createNamedQuery("CustMerchFinInstMapping.findByMobileNumber",CustMerchFinInstMapping.class);
			query.setParameter("walletId",mobileNumber);
			list=query.getResultList();
			if(list.isEmpty()){
				return list.get(0);
			}
			else{
				return null;
			}
		}
		catch(Exception e){
			LOGGER.info(NewConstants.EXCEPTIONOCCURED+" : "+e);
			throw e;
		}
	}

	@Override
	public void saveCustMerchTransactionData(CustMerchTransaction custMerchTransaction)  {
		try{
			entityManager.persist(custMerchTransaction);
		}catch(Exception ex)
		{
			LOGGER.debug("****************** Exception in  saveCustMerchTransactionData***************"+ex);
		}
	}

	@Override
	public Customer getCustomerDetails(String mobileNumber)  {
		LOGGER.debug("****************** getCustomerDetails() starts executing ***************");
		List<Customer> list=null;
		try{
			TypedQuery<Customer> query=entityManager.createNamedQuery("Customer.findByContactNumber",Customer.class);
			query.setParameter("contactNumber",mobileNumber);
			list=query.getResultList();
			if(list.isEmpty()){
				return list.get(0); 
			}
			else
			{
				return null;
			}
		}
		catch(Exception e){
			LOGGER.info(NewConstants.EXCEPTIONOCCURED+" : "+e);
			throw e;
		}
	}
}