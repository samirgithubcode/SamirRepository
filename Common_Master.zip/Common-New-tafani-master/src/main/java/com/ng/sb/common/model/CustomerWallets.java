/**
 * 
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author gopal
 *
 */
@Entity
@Table(name = "subscriber_wallet_info")
@NamedQueries({
    @NamedQuery(name = "CustomerWallets.findById", query = "SELECT s FROM CustomerWallets s WHERE s.id = :id"),
    @NamedQuery(name = "CustomerWallets.findByMsisdn", query = "SELECT s FROM CustomerWallets s WHERE s.customerMsisdn = :customerMsisdn"),
    @NamedQuery(name = "CustomerWallets.findByMsisdnnWalletId", query = "SELECT s FROM CustomerWallets s WHERE s.customerMsisdn = :customerMsisdn and s.walletId =:walletId")
   })
public class CustomerWallets implements Serializable {

	private static final long serialVersionUID = 1L;
	
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;
   
    @Column(name = "customerId")
    private String customerId;
    
    @Column(name = "customerMsisdn")
    private String customerMsisdn;
    
    @Column(name = "walletNumber")
    private String walletNumber;
    
    @Column(name = "walletName")
    private String walletName;
    
    @Column(name = "walletPin")
    private String walletPin;
    
    @Column(name = "walletId")
    private Integer walletId;
    
    @Column(name = "currentBalance")
    private Double currentBalance;
    
    @Column(name = "status")
    private String walletStatus;
    
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "createdOn")
    private Date createdOn;
    
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "modifiedOn")
    private Date modifiedOn;

    
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerMsisdn() {
		return customerMsisdn;
	}

	public void setCustomerMsisdn(String customerMsisdn) {
		this.customerMsisdn = customerMsisdn;
	}

	public String getWalletNumber() {
		return walletNumber;
	}

	public void setWalletNumber(String walletNumber) {
		this.walletNumber = walletNumber;
	}

	public String getWalletName() {
		return walletName;
	}

	public void setWalletName(String walletName) {
		this.walletName = walletName;
	}

	public Integer getWalletId() {
		return walletId;
	}

	public void setWalletId(Integer walletId) {
		this.walletId = walletId;
	}

	public Double getCurrentBalance() {
		return currentBalance;
	}

	public void setCurrentBalance(Double currentBalance) {
		this.currentBalance = currentBalance;
	}

	public String getWalletStatus() {
		return walletStatus;
	}

	public void setWalletStatus(String walletStatus) {
		this.walletStatus = walletStatus;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public String getWalletPin() {
		return walletPin;
	}

	public void setWalletPin(String walletPin) {
		this.walletPin = walletPin;
	}
    
    
}
