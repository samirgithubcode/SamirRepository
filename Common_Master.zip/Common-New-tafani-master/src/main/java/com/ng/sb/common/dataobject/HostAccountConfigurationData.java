package com.ng.sb.common.dataobject;

import java.util.Date;

import org.springframework.web.multipart.MultipartFile;


public class HostAccountConfigurationData  extends BaseObjectData{
	
		
	private static final long serialVersionUID = 1L;

	private String  sTKMenu; 
	
	private Date uploadDate; 
		
	private transient MultipartFile uploadFile1;
		
	private transient MultipartFile uploadFile2;
		
	private String approvedStatus;
	
	private String applicationVersion;
	
	public HostAccountConfigurationData(){
		//default constructor
	}

	public String getApplicationVersion() {
		return applicationVersion;
	}
	
	public void setApprlicationVersion(String applicationVersion) {
		this.applicationVersion = applicationVersion;
	}
	
	public String getSTKMenu() {
		
		return sTKMenu;
	}
	public void setSTKMenu(String sTKMenu) {
		this.sTKMenu = sTKMenu;
	}
	public Date getUploadDate() {
		return uploadDate;
	}
	public void setUploadDate(Date uploadDate) {
		this.uploadDate = uploadDate;
	}
	
	
	
	public MultipartFile getUploadFile1() {
		return uploadFile1;
	}

	public void setUploadFile1(MultipartFile uploadFile1) {
		this.uploadFile1 = uploadFile1;
	}

	public MultipartFile getUploadFile2() {
		return uploadFile2;
	}

	public void setUploadFile2(MultipartFile uploadFile2) {
		this.uploadFile2 = uploadFile2;
	}

	public String getApprovedStatus() {
		return approvedStatus;
	}
	public void setApprovedStatus(String approvedStatus) {
		this.approvedStatus = approvedStatus;
	}
	

	@Override
	public String toString() {
		return "HostAccountConfigurationData [STKMenu=" + sTKMenu + ", uploadDate=" + uploadDate + ", uploadFile1="
				+ uploadFile1 + ", uploadFile2=" + uploadFile2 + ", approvedStatus=" + approvedStatus
				+ ", applicationVersion=" + applicationVersion + "]";
	}
	
	
	
    
	
}
