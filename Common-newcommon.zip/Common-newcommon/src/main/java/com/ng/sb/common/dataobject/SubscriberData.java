package com.ng.sb.common.dataobject;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;

import com.ng.sb.common.model.Products;
public class SubscriberData extends BaseObjectData {
	/**
	 * 
	 */
	  @InitBinder
	    public void initBinder(WebDataBinder binder) {
	        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	        dateFormat.setLenient(false);
	        binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, false));
	    }
	private static final long serialVersionUID = 1L;
	private String issuedTo;
	private String deploymentType;
	private String mobilenumber;
	private String email;
	private String confirmpassword;
	private String productType;
	private String comment;
	private String addDate;
	private String addedBy;
//	private String name;
	private String hierarchy;
	
	private String mobile;
	private String dateOfBirth;
	private Map<Integer,String> mobileMap;
	private String userName;
	private String secretQuestion;
	private String roleType;
	private String emailId;
	private Integer mvId;
	private Map<Integer,String> mvMap;
	private Integer hsvId;
	private Map<Integer,String> hsvMap;
	private Map<Integer,String> productMap;
	private Integer instock;
	private Integer serialNumber;
	private Map<Integer,BigDecimal> serialNumberMap;
	private String dob;
	private Integer accountId;
	private Integer availableInventory;
	private Integer userLoginId;
	private String lastName;
	private String address;
	private String address1;
	private String city;
	private String state;
	private String country;
	private Integer pinCode;
	private String gender;
	private String newPassword;
	private String cnfPassword;
	private String currentPassword;
	private String errorMsg;
	private String otpOnForgotPass;
	private List<SubscriberData> subscriberslist;
	private List<SubscriberData> customerData;
	private String currencyCode;
	private String checkBox;
	private String status;
	private Integer pendingDocs;
	private String district;
	
	private String currentWalletPin;
	private String newWalletPin;
	private String cnfWalletPin;
	
	private String profileImage;
	private int requestStatus;
	
	public Integer getPendingDocs() {
		return pendingDocs;
	}

	public void setPendingDocs(Integer pendingDocs) {
		this.pendingDocs = pendingDocs;
	}

	public String getHierarchy() {
		return hierarchy;
	}

	public void setHierarchy(String hierarchy) {
		this.hierarchy = hierarchy;
	}

//	public String getName() {
//		return name;
//	}
//
//	public void setName(String name) {
//		this.name = name;
//	}

	/**
	 * @return the comment
	 */
	public String getComment() {
		return comment;
	}

	/**
	 * @param comment the comment to set
	 */
	public void setComment(String comment) {
		this.comment = comment;
	}
	

	public String getAddDate() {
		return addDate;
	}

	public void setAddDate(String addDate) {
		this.addDate = addDate;
	}

	public String getAddedBy() {
		return addedBy;
	}

	public void setAddedBy(String addedBy) {
		this.addedBy = addedBy;
	}

	/**
	 * @return the productType
	 */
	public String getProductType() {
		return productType;
	}

	/**
	 * @param productType the productType to set
	 */
	public void setProductType(String productType) {
		this.productType = productType;
	}

	/**
	 * @return the confirmpassword
	 */
	public String getConfirmpassword() {
		return confirmpassword;
	}

	/**
	 * @param confirmpassword the confirmpassword to set
	 */
	public void setConfirmpassword(String confirmpassword) {
		this.confirmpassword = confirmpassword;
	}

	/**
	 * @return the mobilenumber
	 */
	public String getMobilenumber() {
		return mobilenumber;
	}

	/**
	 * @param mobilenumber the mobilenumber to set
	 */
	public void setMobilenumber(String mobilenumber) {
		this.mobilenumber = mobilenumber;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the checkBox
	 */
	public String getCheckBox() {
		return checkBox;
	}

	/**
	 * @param checkBox the checkBox to set
	 */
	public void setCheckBox(String checkBox) {
		this.checkBox = checkBox;
	}

	/**
	 * @return the currencyCode
	 */
	public String getCurrencyCode() {
		return currencyCode;
	}

	/**
	 * @param currencyCode the currencyCode to set
	 */
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public final String getStartDate() {
		return startDate;
	}

	public final void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	private List<SubscriberData> walletList;
	private String startDate;
	public  Double getWalletBalance() {
		return walletBalance;
	}

	public  void setWalletBalance(Double walletBalance) {
		this.walletBalance = walletBalance;
	}

	private Double walletBalance;
	public List<SubscriberData> getSubscriberslist() {
		return subscriberslist;
	}

	public final List<SubscriberData> getWalletList() {
		return walletList;
	}

	public final void setWalletList(List<SubscriberData> walletList) {
		this.walletList = walletList;
	}

	public void setSubscriberslist(List<SubscriberData> subscriberslist) {
		this.subscriberslist = subscriberslist;
	}

	public Integer getWallettypeid() {
		return wallettypeid;
	}

	public void setWallettypeid(Integer wallettypeid) {
		this.wallettypeid = wallettypeid;
	}

	private String region;
	private String locality;
	private String[] checkedLinks;
	private Integer wallettypeid;
	public String[] getCheckedLinks() {
		return checkedLinks;
	}

	public void setCheckedLinks(String[] checkedLinks) {
		this.checkedLinks = checkedLinks;
	}

	public String getQueryStatus() {
		return queryStatus;
	}

	public void setQueryStatus(String queryStatus) {
		this.queryStatus = queryStatus;
	}

	private Integer pinaddressId;
	private Integer otpOnSignUp;
	private String userPassword;
	private Integer subscriberid;
	

	private String querytype;
	private String queryStatus;
	private Integer subqueryid;
	private List<Products> productMapNew;
	private String wallet;
	private Map<String,String> productTypeMap;
	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	private String subquerydescription;
	private String subquerycomment;
	private int userTypeId;
	private String currentPasswd;
	private String newPasswd;
	private String msg;
	private String accountTypeId;
	private String userMobile;
	private String createdDate;
	private String subscribers;
	private List<SubscriberData> productList;
	
	public String getUserMobile() {
		return userMobile;
	}

	public void setUserMobile(String userMobile) {
		this.userMobile = userMobile;
	}
	public String getAccountTypeId() {
		return accountTypeId;
	}

	public void setAccountTypeId(String accountTypeId) {
		this.accountTypeId = accountTypeId;
	}

	private WalletListResponseData[] txnResponse;
	
	public WalletListResponseData[] getTxnResponse() {
		return txnResponse;
	}

	public void setTxnResponse(WalletListResponseData[] txnResponse) {
		this.txnResponse = txnResponse;
	}

	public String getDeploymentType() {
		return deploymentType;
	}

	public void setDeploymentType(String deploymentType) {
		this.deploymentType = deploymentType;
	}

	
	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	public String getSecretQuestion() {
		return secretQuestion;
	}

	public void setSecretQuestion(String secretQuestion) {
		this.secretQuestion = secretQuestion;
	}
	public Integer getOtpOnSignUp() {
		return otpOnSignUp;
	}

	public void setOtpOnSignUp(Integer otpOnSignUp) {
		this.otpOnSignUp = otpOnSignUp;
	}

	public Integer getPinaddressId() {
		return pinaddressId;
	}

	public void setPinaddressId(Integer pinaddressId) {
		this.pinaddressId = pinaddressId;
	}

	public String getLocality() {
		return locality;
	}

	public void setLocality(String locality) {
		this.locality = locality;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getOtpOnForgotPass() {
		return otpOnForgotPass;
	}

	public void setOtpOnForgotPass(String otpOnForgotPass) {
		this.otpOnForgotPass = otpOnForgotPass;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}
	
	public String getCurrentPassword() {
		return currentPassword;
	}

	public void setCurrentPassword(String currentPassword) {
		this.currentPassword = currentPassword;
	}

	public String getNewPassword() {
		return newPassword;
	}

	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}

	public String getCnfPassword() {
		return cnfPassword;
	}

	public void setCnfPassword(String cnfPassword) {
		this.cnfPassword = cnfPassword;
	}
	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public Integer getPinCode() {
		return pinCode;
	}
	public void setPinCode(Integer pinCode) {
		this.pinCode = pinCode;
	}
	
	public Integer getUserLoginId() {
		return userLoginId;
	}
	public void setUserLoginId(Integer userLoginId) {
		this.userLoginId = userLoginId;
	}
	public Integer getAvailableInventory() {
		return availableInventory;
	}
	public void setAvailableInventory(Integer availableInventory) {
		this.availableInventory = availableInventory;
	}
	public Integer getAccountId() {
		return accountId;
	}
	public void setAccountId(Integer accountId) {
		this.accountId = accountId;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getIssuedTo() {
		return issuedTo;
	}
	public void setIssuedTo(String issuedTo) {
		this.issuedTo = issuedTo;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public Map<Integer, String> getMobileMap() {
		return mobileMap;
	}
	public void setMobileMap(Map<Integer, String> mobileMap) {
		this.mobileMap = mobileMap;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String name) {
		this.userName = name;
	}
	public String getRoleType() {
		return roleType;
	}
	public void setRoleType(String roleType) {
		this.roleType = roleType;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public Integer getMvId() {
		return mvId;
	}
	public void setMvId(Integer mvId) {
		this.mvId = mvId;
	}
	public Map<Integer, String> getMvMap() {
		return mvMap;
	}
	public void setMvMap(Map<Integer, String> mvMap) {
		this.mvMap = mvMap;
	}
	public Integer getHsvId() {
		return hsvId;
	}
	public void setHsvId(Integer hsvId) {
		this.hsvId = hsvId;
	}
	public Map<Integer, String> getHsvMap() {
		return hsvMap;
	}
	public void setHsvMap(Map<Integer, String> hsvMap) {
		this.hsvMap = hsvMap;
	}
	public Map<Integer, String> getProductMap() {
		return productMap;
	}
	public void setProductMap(Map<Integer, String> productMap) {
		this.productMap = productMap;
	}
	public Integer getInstock() {
		return instock;
	}
	public void setInstock(Integer instock) {
		this.instock = instock;
	}
	public Integer getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(Integer serialNumber) {
		this.serialNumber = serialNumber;
	}
	public Map<Integer, BigDecimal> getSerialNumberMap() {
		return serialNumberMap;
	}
	public void setSerialNumberMap(Map<Integer,BigDecimal> serialNumberMap) {
		this.serialNumberMap = serialNumberMap;
	}

	public Integer getSubscriberid() {
		return subscriberid;
	}

	public void setSubscriberid(Integer subscriberid) {
		this.subscriberid = subscriberid;
	}

	public String getWallet() {
		return wallet;
	}

	public void setWallet(String wallet) {
		this.wallet = wallet;
	}

	public String getQuerytype() {
		return querytype;
	}

	public void setQuerytype(String querytype) {
		this.querytype = querytype;
	}

	public Integer getSubqueryid() {
		return subqueryid;
	}

	public void setSubqueryid(Integer subqueryid) {
		this.subqueryid = subqueryid;
	}

	public List<Products> getProductMapNew() {
		return productMapNew;
	}

	public void setProductMapNew(List<Products> list) {
		this.productMapNew = list;
	}

	public String getSubquerydescription() {
		return subquerydescription;
	}

	public void setSubquerydescription(String subquerydescription) {
		this.subquerydescription = subquerydescription;
	}

	public String getSubquerycomment() {
		return subquerycomment;
	}

	public void setSubquerycomment(String subquerycomment) {
		this.subquerycomment = subquerycomment;
	}

	public int getUserTypeId() {
		return userTypeId;
	}

	public void setUserTypeId(int userTypeId) {
		this.userTypeId = userTypeId;
	}

	public String getCurrentPasswd() {
		return currentPasswd;
	}

	public void setCurrentPasswd(String currentPasswd) {
		this.currentPasswd = currentPasswd;
	}

	public String getNewPasswd() {
		return newPasswd;
	}

	public void setNewPasswd(String newPasswd) {
		this.newPasswd = newPasswd;
	}

	public String getSubscribers() {
		return subscribers;
	}

	public void setSubscribers(String subscribers) {
		this.subscribers = subscribers;
	}

	public List<SubscriberData> getCustomerData() {
		return customerData;
	}

	public void setCustomerData(List<SubscriberData> customerData) {
		this.customerData = customerData;
	}

	/**
	 * @return the productList
	 */
	public List<SubscriberData> getProductList() {
		return productList;
	}

	/**
	 * @return the productTypeMap
	 */
	public Map<String, String> getProductTypeMap() {
		return productTypeMap;
	}

	/**
	 * @param productTypeMap the productTypeMap to set
	 */
	public void setProductTypeMap(Map<String, String> productTypeMap) {
		this.productTypeMap = productTypeMap;
	}

	/**
	 * @param productList the productList to set
	 */
	public void setProductList(List<SubscriberData> productList) {
		this.productList = productList;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getProfileImage() {
		return profileImage;
	}

	public void setProfileImage(String profileImage) {
		this.profileImage = profileImage;
	}

	public String getCurrentWalletPin() {
		return currentWalletPin;
	}

	public void setCurrentWalletPin(String currentWalletPin) {
		this.currentWalletPin = currentWalletPin;
	}

	public String getNewWalletPin() {
		return newWalletPin;
	}

	public void setNewWalletPin(String newWalletPin) {
		this.newWalletPin = newWalletPin;
	}

	public String getCnfWalletPin() {
		return cnfWalletPin;
	}

	public void setCnfWalletPin(String cnfWalletPin) {
		this.cnfWalletPin = cnfWalletPin;
	}

	public int getRequestStatus() {
		return requestStatus;
	}

	public void setRequestStatus(int requestStatus) {
		this.requestStatus = requestStatus;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("SubscriberData [issuedTo=");
		builder.append(issuedTo);
		builder.append(", deploymentType=");
		builder.append(deploymentType);
		builder.append(", mobilenumber=");
		builder.append(mobilenumber);
		builder.append(", email=");
		builder.append(email);
		builder.append(", confirmpassword=");
		builder.append(confirmpassword);
		builder.append(", productType=");
		builder.append(productType);
		builder.append(", comment=");
		builder.append(comment);
		builder.append(", addDate=");
		builder.append(addDate);
		builder.append(", addedBy=");
		builder.append(addedBy);
		builder.append(", hierarchy=");
		builder.append(hierarchy);
		builder.append(", mobile=");
		builder.append(mobile);
		builder.append(", dateOfBirth=");
		builder.append(dateOfBirth);
		builder.append(", mobileMap=");
		builder.append(mobileMap);
		builder.append(", userName=");
		builder.append(userName);
		builder.append(", secretQuestion=");
		builder.append(secretQuestion);
		builder.append(", roleType=");
		builder.append(roleType);
		builder.append(", emailId=");
		builder.append(emailId);
		builder.append(", mvId=");
		builder.append(mvId);
		builder.append(", mvMap=");
		builder.append(mvMap);
		builder.append(", hsvId=");
		builder.append(hsvId);
		builder.append(", hsvMap=");
		builder.append(hsvMap);
		builder.append(", productMap=");
		builder.append(productMap);
		builder.append(", instock=");
		builder.append(instock);
		builder.append(", serialNumber=");
		builder.append(serialNumber);
		builder.append(", serialNumberMap=");
		builder.append(serialNumberMap);
		builder.append(", dob=");
		builder.append(dob);
		builder.append(", accountId=");
		builder.append(accountId);
		builder.append(", availableInventory=");
		builder.append(availableInventory);
		builder.append(", userLoginId=");
		builder.append(userLoginId);
		builder.append(", lastName=");
		builder.append(lastName);
		builder.append(", address=");
		builder.append(address);
		builder.append(", address1=");
		builder.append(address1);
		builder.append(", city=");
		builder.append(city);
		builder.append(", state=");
		builder.append(state);
		builder.append(", country=");
		builder.append(country);
		builder.append(", pinCode=");
		builder.append(pinCode);
		builder.append(", gender=");
		builder.append(gender);
		builder.append(", newPassword=");
		builder.append(newPassword);
		builder.append(", cnfPassword=");
		builder.append(cnfPassword);
		builder.append(", currentPassword=");
		builder.append(currentPassword);
		builder.append(", errorMsg=");
		builder.append(errorMsg);
		builder.append(", otpOnForgotPass=");
		builder.append(otpOnForgotPass);
		builder.append(", subscriberslist=");
		builder.append(subscriberslist);
		builder.append(", customerData=");
		builder.append(customerData);
		builder.append(", currencyCode=");
		builder.append(currencyCode);
		builder.append(", checkBox=");
		builder.append(checkBox);
		builder.append(", status=");
		builder.append(status);
		builder.append(", pendingDocs=");
		builder.append(pendingDocs);
		builder.append(", district=");
		builder.append(district);
		builder.append(", currentWalletPin=");
		builder.append(currentWalletPin);
		builder.append(", newWalletPin=");
		builder.append(newWalletPin);
		builder.append(", cnfWalletPin=");
		builder.append(cnfWalletPin);
		builder.append(", profileImage=");
		builder.append(profileImage);
		builder.append(", requestStatus=");
		builder.append(requestStatus);
		builder.append(", walletList=");
		builder.append(walletList);
		builder.append(", startDate=");
		builder.append(startDate);
		builder.append(", walletBalance=");
		builder.append(walletBalance);
		builder.append(", region=");
		builder.append(region);
		builder.append(", locality=");
		builder.append(locality);
		builder.append(", checkedLinks=");
		builder.append(Arrays.toString(checkedLinks));
		builder.append(", wallettypeid=");
		builder.append(wallettypeid);
		builder.append(", pinaddressId=");
		builder.append(pinaddressId);
		builder.append(", otpOnSignUp=");
		builder.append(otpOnSignUp);
		builder.append(", userPassword=");
		builder.append(userPassword);
		builder.append(", subscriberid=");
		builder.append(subscriberid);
		builder.append(", querytype=");
		builder.append(querytype);
		builder.append(", queryStatus=");
		builder.append(queryStatus);
		builder.append(", subqueryid=");
		builder.append(subqueryid);
		builder.append(", productMapNew=");
		builder.append(productMapNew);
		builder.append(", wallet=");
		builder.append(wallet);
		builder.append(", productTypeMap=");
		builder.append(productTypeMap);
		builder.append(", subquerydescription=");
		builder.append(subquerydescription);
		builder.append(", subquerycomment=");
		builder.append(subquerycomment);
		builder.append(", userTypeId=");
		builder.append(userTypeId);
		builder.append(", currentPasswd=");
		builder.append(currentPasswd);
		builder.append(", newPasswd=");
		builder.append(newPasswd);
		builder.append(", msg=");
		builder.append(msg);
		builder.append(", accountTypeId=");
		builder.append(accountTypeId);
		builder.append(", userMobile=");
		builder.append(userMobile);
		builder.append(", createdDate=");
		builder.append(createdDate);
		builder.append(", subscribers=");
		builder.append(subscribers);
		builder.append(", productList=");
		builder.append(productList);
		builder.append(", txnResponse=");
		builder.append(Arrays.toString(txnResponse));
		builder.append("]");
		return builder.toString();
	}
	
	



	
}
