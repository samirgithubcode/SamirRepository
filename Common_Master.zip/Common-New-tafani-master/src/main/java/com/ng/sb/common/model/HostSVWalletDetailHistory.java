package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.*;


/**
 * @author abhishek
 *
 */
@Entity
@Table(name="HostSVWalletDetailHistory")
@NamedQueries({
@NamedQuery(name="HostSVWalletDetailHistory.findByhsvWHID", query="SELECT h FROM HostSVWalletDetailHistory h WHERE h.hsvWHID = :hsvWHID"),
@NamedQuery(name="HostSVWalletDetailHistory.findAll", query="SELECT h FROM HostSVWalletDetailHistory h")})
public class HostSVWalletDetailHistory implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;

	//bi-directional many-to-one association to HostSVWalletHistory
	@ManyToOne
	@JoinColumn(name="hsvWHID")
	private HostSVWalletHistory hsvWHID;

	//bi-directional many-to-one association to Partner
	@ManyToOne
	@JoinColumn(name="walletId")
	private Partner walletId;

	public HostSVWalletDetailHistory() {
		//empty
	}

	public HostSVWalletDetailHistory(Integer id) {
		this.id = id;
	}
	
	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public HostSVWalletHistory getHsvWHID() {
		return this.hsvWHID;
	}

	public void setHsvWHID(HostSVWalletHistory hsvWHID) {
		this.hsvWHID = hsvWHID;
	}

	public Partner getWalletId() {
		return this.walletId;
	}

	public void setWalletId(Partner walletId) {
		this.walletId = walletId;
	}
	
	@Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof HostSVWalletDetailHistory)) {
            return false;
        }
        HostSVWalletDetailHistory other = (HostSVWalletDetailHistory) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.HostSVWalletDetailHistory[ id=" + id + " ]";
    }

}