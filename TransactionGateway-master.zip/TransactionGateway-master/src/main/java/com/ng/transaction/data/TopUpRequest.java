/**
 * 
 */
package com.ng.transaction.data;

import com.ng.sb.common.dataobject.ValidationBean;

/**
 * @author gopal
 *
 */
public class TopUpRequest implements ValidationBean {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6730979416498482079L;

	private int amount;
	
	private BankingData payerBankAccount;
	
	private ProviderDetails provider;

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public BankingData getPayerBankAccount() {
		return payerBankAccount;
	}

	public void setPayerBankAccount(BankingData payerBankAccount) {
		this.payerBankAccount = payerBankAccount;
	}

	public ProviderDetails getProvider() {
		return provider;
	}

	public void setProvider(ProviderDetails provider) {
		this.provider = provider;
	}
	
	
}
