/**
 * 
 */
package com.ng.user.dto;

/**
 * @author gopal
 *
 */
public class LogoutRequest {

    private Integer channelId;
	
	private String  tokenId;

	public Integer getChannelId() {
		return channelId;
	}

	public void setChannelId(Integer channelId) {
		this.channelId = channelId;
	}

	public String getTokenId() {
		return tokenId;
	}

	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}
	
	
}
