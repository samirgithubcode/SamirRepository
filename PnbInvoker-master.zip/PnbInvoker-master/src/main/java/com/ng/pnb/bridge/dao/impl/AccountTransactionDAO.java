package com.ng.pnb.bridge.dao.impl;

import java.util.List;
import java.util.Map;

import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.ng.sb.common.dao.impl.SuperParentDAO;
import com.ng.sb.common.dataobject.BankAccount;
import com.ng.sb.common.dataobject.Wallet;
import com.ng.sb.common.model.Account;
import com.ng.sb.common.model.AccountTransaction;
import com.ng.sb.common.model.CustomerWallets;
import com.ng.sb.common.model.Partner;
import com.ng.sb.common.util.SystemConstant;
@Repository
public class AccountTransactionDAO extends SuperParentDAO implements IAccountTransactionDAO{

	private static final long serialVersionUID = 1L;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(AccountTransactionDAO.class);
	@Override
	public List<Account> validateBank(BankAccount bankAccount) {
		TypedQuery<Account> query = null;
		List<Account> accountList = null;
		try{
			query = entityManager.createNamedQuery("Account.findByAccountNumberAndIFSC",Account.class);
			query.setParameter("accNumber",bankAccount.getAccountNumber());
			query.setParameter("ifsc",bankAccount.getIfscCode());
			accountList = query.getResultList();
		}catch(Exception ex){
			LOGGER.debug("Exception caught in validateBank() method of AccountTransactionDAO"+ex);
		}
		return accountList;
	}
	@Override
	@Transactional
	public Account saveAccount(Account account)  {
		try{
			entityManager.persist(account);
		}catch(Exception ex){
			LOGGER.info("Exception caught in saveAccount() method of AccountTransactionDAO"+ex);
		}
		return account;
	}
	@Override
	@Transactional
	public List<Account> validateWallet(Wallet wallet,Map<Integer,Partner> walletMap) {
		TypedQuery<Account> query = null;
		List<Account> accountList = null;
		try{
			LOGGER.info("Execution start of validateWallet() method in AccountTransactionDAO");
				query = entityManager.createNamedQuery("Account.findBymobileNumberAndWalletId",Account.class);
				query.setParameter("mobileNumber", wallet.getMsisdn());
				query.setParameter("walletId", walletMap.get(wallet.getWalletCode()));
				accountList = query.getResultList();
		}catch(Exception ex){
			LOGGER.debug("Exception caught in validateWallet() method of AccountTransactionDAO"+ex);
		}
		LOGGER.info("Execution end of validateWallet() method in AccountTransactionDAO");
		return accountList;
	}
	@Override
	@Transactional
	public List<Partner> fetchAllWalets()  {
		TypedQuery<Partner> query = null;
		List<Partner> partnerList = null;
		try{
			LOGGER.info("Execution start of fetchAllWallets() method in AccountTransactionDAO");
			query = entityManager.createNamedQuery("Partner.findAllInternalWallets",Partner.class);
			query.setParameter("walletType", SystemConstant.INTERNAL);
			partnerList = query.getResultList();
		}catch(Exception ex){
			LOGGER.debug("Exception caught in fetchAllWallets() method of AccountTransactionDAO"+ex);
		}
		LOGGER.info("Execution end of fetchAllWallets() method in AccountTransactionDAO");
		return partnerList;
	}

	@Override
	@Transactional
	public List<AccountTransaction> getMiniStatement(Account payerAccount) {
		List<AccountTransaction> accountTransactionList = null;
		TypedQuery<AccountTransaction> query = null;
		try{
			query = entityManager.createNamedQuery("AccountTransaction.findByPayerAccIdOrPayeeAccId",AccountTransaction.class);
			query.setParameter("payerAccId",payerAccount);
			query.setParameter("payeeAccId",payerAccount);
			accountTransactionList = query.getResultList();
		}catch(Exception ex){
			LOGGER.debug("Exception caught in getMiniStatement() method in AccountTransactionDAO"+ex);
		}
		LOGGER.info("Execution end of fetchAllWallets() method in AccountTransactionDAO");
		return accountTransactionList;
	}

	@Override
	@Transactional
	public AccountTransaction saveAccountTransaction(AccountTransaction account){
		LOGGER.debug("*********** updateAccountTransaction() starts executing in AccountTransactionDAO *************");
		try
		{
			entityManager.persist(account);
		}
		catch(Exception ex)
		{
			LOGGER.info("Exception occurred in updateAccountTransaction() method in AccountTransactionDAO --->"+ex);
		}
		return account;
		}
	@Override
	@Transactional
	public Account updateAccounts(Account account)  {
		
		LOGGER.debug("*********** updateAccounts() starts executing in AccountTransactionDAO *************");
		try
		{
		account = entityManager.merge(account);
		}catch(Exception ex)
		{
			LOGGER.info("Exception occurred in updateAccounts() method in AccountTransactionDAO --->"+ex);
		}
		return account;
	}
	@Override
	public CustomerWallets getWallletDetails(Wallet walletDetails) 
	{
			TypedQuery<CustomerWallets> query = null;
			CustomerWallets resultData = null;
			try{
				query = entityManager.createNamedQuery("CustomerWallets.findByMsisdnnWalletId", CustomerWallets.class);
				query.setParameter("customerMsisdn", walletDetails.getMsisdn());
				query.setParameter("walletId", walletDetails.getWalletCode());
				resultData = query.getSingleResult();
			}catch(Exception ex){
				LOGGER.debug("Exception caught in getWallletDetails() method of AccountTransactionDAO"+ex);
			}
		return resultData;	
	}
	
	@Override
	@Transactional
	public boolean saveEntity(Object entityObject) 
	{
		try
		{
			entityManager.persist(entityObject);
			return true;
		}catch(Exception ex)
		{
			ex.printStackTrace();
			LOGGER.info("Exception caught in saveEntity() method of AccountTransactionDAO"+ex);
		}
		
		return false;
	}
	
	@Override
	@Transactional
	public boolean updateEntity(Object entityObject) 
	{
		try
		{
			entityManager.merge(entityObject);
			
			return true;
		}catch(Exception ex)
		{
			LOGGER.info("Exception caught in updateEntity() method of AccountTransactionDAO"+ex);
		}
		
		return false;
	}
	
	
	
}


