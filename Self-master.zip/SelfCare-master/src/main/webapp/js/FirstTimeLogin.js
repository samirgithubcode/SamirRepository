function validateUserByDOB(dobId,useNameId){
	 
	//alert("dob :"+dobId +" userName :"+useNameId);
	var userNameId=$("#"+useNameId).val().trim();
	var dobId=$("#"+dobId).val();
	var checkAvailaity=true;
	if(userNameId.length<=0){
		
		$("#lab_userNameorEmailErrorId").html("<b><font color='red'> Please Enter User Name !</font></b>")
		checkAvailaity=false;
	}
	if(dobId.length<=0){
		
		$("#lab_dobErrorId").html("<b><font color='red'> Please Select DOB !</font></b>")
		checkAvailaity=false;
	}
	if(checkAvailaity){
		
		
		$.ajax({
			 url: '/securebanking/AdminUI/UserMgmt/validateByLoginNameDob',
			  type: 'GET',
			  data: {
		            'userName': userNameId,
		             'dob' : dobId
		            
	                  },
			  success: function(response) {
				 
				var firstTimeLoginDataResponse=response;
				//alert("firstTimeLoginDataResponse :"+firstTimeLoginDataResponse.validUserStatus);
				if(firstTimeLoginDataResponse.validUserStatus==true){
					$("#question").show();
				}
				else{
					$("#lab_userNameorEmailErrorId").html("<b><font color='red'> Invalid User Name or DOB !</font></b>");
					
				}
				
			  },
			  error: function(e) {
				  //alert("error: "+e);
				  console.log(e.message);
			  }
			});
		
		
		
		
	}
	  
	
	
}