/**
 * 
 */
package com.ng.user.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ng.sb.common.dataobject.ValidationBean;

/**
 * @author gopal
 *
 */
public class ChangePasswordRequest implements ValidationBean {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@JsonProperty("UserTypeId")
	private int userTypeId ;
	
	private String userId;
	
	private String currentPasswd;
	
	private String newPasswd;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getCurrentPasswd() {
		return currentPasswd;
	}

	public void setCurrentPasswd(String currentPasswd) {
		this.currentPasswd = currentPasswd;
	}

	public String getNewPasswd() {
		return newPasswd;
	}

	public void setNewPasswd(String newPasswd) {
		this.newPasswd = newPasswd;
	}

	public int getUserTypeId() {
		return userTypeId;
	}

	public void setUserTypeId(int userTypeId) {
		this.userTypeId = userTypeId;
	}
	
}
