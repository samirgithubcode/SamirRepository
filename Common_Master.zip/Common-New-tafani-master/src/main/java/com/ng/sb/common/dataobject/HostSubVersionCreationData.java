package com.ng.sb.common.dataobject;

import java.util.List;
import java.util.Map;

import com.ng.sb.common.model.AccountInfo;

public class HostSubVersionCreationData extends BaseObjectData {
	
	
private static final long serialVersionUID = 1L;
	
     private Integer hsvId;
    private AccountInfo hostId;
	private String subVersionName;
	
	private String walletDate;
	private String walletstatus;
	private String providersDate;
	private String serviceDate;
	private String servicestatus;
	private String mainMenu;
	private String mainservicecheckBox;
	private transient Map walletMap;
	private Integer categoryId;
	private String categoryName;
	private Integer providerId;
	private String providerName;
	private String providerStatus;
	private Integer[] walletcheckBox;
	private String[] providercheckBox;
	private Integer[] servicescheckBox;
	private Integer serviceConfigId;
	private String serviceConfigName;
	
	
	private String smsCode;
    private List<MasterVersionData> masterVersionData;
	private Integer masterVersionId;
    private String hostSubVersionName;
    private List<ServiceConfigData> stkMenuServiceList;
    private List<PartnerData> partnerDatas;
    private List<HostSubVersionCreationData> partnerDatas2;
    private List<PartnerData> editPartnerDatas;
    private List<String> walletType;
    private Integer[] walletcheckBoxName;
	private Integer[] otherServices;
	private Integer[] fspotherServices;
	private Integer[] financialInstrument;
	private Integer[] bank;
	private Integer[] fspfundTransferBank;
	private Integer[] fspBank;
	private Integer[] providers;
	private Integer[] fspproviders;
	private Integer[] riFspproviders;
	private Integer[] fspfinancialInstrument;
	private boolean fsp;
	private boolean rifspfinancialInstrument;
	private Integer[] fspDirectIds;
	private boolean fundTransferFSP;
	private boolean providerFSP;
	private Map<CategoryData,List<ProvidersData>> categoryProviderMapping;
    private Map<PartnerData,List<String>> walletWalletTypeMapping;
    private Map<FinancialInstrumentData,List<PartnerData>> nonFspfinancialInstrumentPartnerMapping;
	private Map<FSPServicesData, List<PartnerData>> nonFspOtherServices;
	private String[] financialInstrumentPartnerMapping;
	private String[] fspProviderfspotherServices;
    private Map<Integer,String> partnerSequenceMapping;
	private String[] financialInstrumentPartnerMappingSequence;
	private String[] fspProviderfspotherServicesSequence;
	private String[] directOtherServices;
	private String[] directOtherServicesSequence;
	private String[] providersPath;
    private String[] directProviders;
    private String[] directProvidersSequence;
    private String[] fspprovidersPath;
    private String[] fspProviderfspproviders;
    private String[] fspProviderfspprovidersSequence;
    private String[] financialInstrumentCommissionMappingSequence;
    private String[]  otherServicesCommissionMapping;
    private String[] directProvidersSequenceCommission;
    private Integer walletId;
	private String[] fspFundTransferCommissionMappingSequence;
	private List<Integer> serviceConfigIds;
    //
	CategoriesMappingData categoriesProviderPartnerDirectMappingData;
	
	CategoriesMappingData categoriesProviderPartnerFSPMappingData;
	
	private List<PartnerData> partnerDatasForAllWallets;
	private String[] fspProvidersSequenceCommission;
	
	
	private String[] financialInstrumentPartnerMappingCommission;

	public String[] getFspProvidersSequenceCommission() {
		return fspProvidersSequenceCommission;
	}

	public void setFspProvidersSequenceCommission(String[] fspProvidersSequenceCommission) {
		this.fspProvidersSequenceCommission = fspProvidersSequenceCommission;
	}
	
	public String[] getFspFundTransferCommissionMappingSequence() {
		return fspFundTransferCommissionMappingSequence;
	}

	public void setFspFundTransferCommissionMappingSequence(String[] fspFundTransferCommissionMappingSequence) {
		this.fspFundTransferCommissionMappingSequence = fspFundTransferCommissionMappingSequence;
	}

	public Integer[] getFspDirectIds() {
		return fspDirectIds;
	}

	public void setFspDirectIds(Integer[] fspDirectIds) {
		this.fspDirectIds = fspDirectIds;
	}
	    
    public String[] getDirectProvidersSequenceCommission() {
		return directProvidersSequenceCommission;
	}

	public void setDirectProvidersSequenceCommission(String[] directProvidersSequenceCommission) {
		this.directProvidersSequenceCommission = directProvidersSequenceCommission;
	}

	public String[] getOtherServicesCommissionMapping() {
		return otherServicesCommissionMapping;
	}

	public void setOtherServicesCommissionMapping(String[] otherServicesCommissionMapping) {
		this.otherServicesCommissionMapping = otherServicesCommissionMapping;
	}

	public String[] getFinancialInstrumentCommissionMappingSequence() {
		return financialInstrumentCommissionMappingSequence;
	}

	public void setFinancialInstrumentCommissionMappingSequence(String[] financialInstrumentCommissionMappingSequence) {
		this.financialInstrumentCommissionMappingSequence = financialInstrumentCommissionMappingSequence;
	}

	public List<PartnerData> getPartnerDatasForAllWallets() {
		return partnerDatasForAllWallets;
	}

	public void setPartnerDatasForAllWallets(List<PartnerData> partnerDatasForAllWallets) {
		this.partnerDatasForAllWallets = partnerDatasForAllWallets;
	}

	public String[] getFinancialInstrumentPartnerMappingCommission() {
		return financialInstrumentPartnerMappingCommission;
	}

	public void setFinancialInstrumentPartnerMappingCommission(String[] financialInstrumentPartnerMappingCommission) {
		this.financialInstrumentPartnerMappingCommission = financialInstrumentPartnerMappingCommission;
	}

	public List<PartnerData> getEditPartnerDatas() {
		return editPartnerDatas;
	}

	public void setEditPartnerDatas(List<PartnerData> editPartnerDatas) {
		this.editPartnerDatas = editPartnerDatas;
	}

	public Integer getHsvId() {
		return hsvId;
	}

	public void setHsvId(Integer hsvId) {
		this.hsvId = hsvId;
	}

	public List<Integer> getServiceConfigIds() {
		return serviceConfigIds;
	}

	public void setServiceConfigIds(List<Integer> serviceConfigIds) {
		this.serviceConfigIds = serviceConfigIds;
	}

	public String[] getFspprovidersPath() {
		return fspprovidersPath;
	}

	public void setFspprovidersPath(String[] fspprovidersPath) {
		this.fspprovidersPath = fspprovidersPath;
	}

	public String[] getFspProviderfspproviders() {
		return fspProviderfspproviders;
	}

	public void setFspProviderfspproviders(String[] fspProviderfspproviders) {
		this.fspProviderfspproviders = fspProviderfspproviders;
	}

	public String[] getFspProviderfspprovidersSequence() {
		return fspProviderfspprovidersSequence;
	}

	public void setFspProviderfspprovidersSequence(
			String[] fspProviderfspprovidersSequence) {
		this.fspProviderfspprovidersSequence = fspProviderfspprovidersSequence;
	}

	public CategoriesMappingData getCategoriesProviderPartnerDirectMappingData() {
		return categoriesProviderPartnerDirectMappingData;
	}

	public void setCategoriesProviderPartnerDirectMappingData(
			CategoriesMappingData categoriesProviderPartnerDirectMappingData) {
		this.categoriesProviderPartnerDirectMappingData = categoriesProviderPartnerDirectMappingData;
	}

	public CategoriesMappingData getCategoriesProviderPartnerFSPMappingData() {
		return categoriesProviderPartnerFSPMappingData;
	}

	public void setCategoriesProviderPartnerFSPMappingData(
			CategoriesMappingData categoriesProviderPartnerFSPMappingData) {
		this.categoriesProviderPartnerFSPMappingData = categoriesProviderPartnerFSPMappingData;
	}

	public String[] getProvidersPath() {
		return providersPath;
	}

	public void setProvidersPath(String[] providersPath) {
		this.providersPath = providersPath;
	}

	public String[] getDirectProvidersSequence() {
		return directProvidersSequence;
	}

	public void setDirectProvidersSequence(String[] directProvidersSequence) {
		this.directProvidersSequence = directProvidersSequence;
	}

	public String[] getDirectProviders() {
		return directProviders;
	}

	public void setDirectProviders(String[] directProviders) {
		this.directProviders = directProviders;
	}

	public String[] getDirectOtherServicesSequence() {
		return directOtherServicesSequence;
	}

	public void setDirectOtherServicesSequence(String[] directOtherServicesSequence) {
		this.directOtherServicesSequence = directOtherServicesSequence;
	}

	public String[] getDirectOtherServices() {
		return directOtherServices;
	}

	public void setDirectOtherServices(String[] directOtherServices) {
		this.directOtherServices = directOtherServices;
	}

	public String[] getFspProviderfspotherServicesSequence() {
		return fspProviderfspotherServicesSequence;
	}

	public void setFspProviderfspotherServicesSequence(
			String[] fspProviderfspotherServicesSequence) {
		this.fspProviderfspotherServicesSequence = fspProviderfspotherServicesSequence;
	}

	public String[] getFspProviderfspotherServices() {
		return fspProviderfspotherServices;
	}

	public void setFspProviderfspotherServices(
			String[] fspProviderfspotherServices) {
		this.fspProviderfspotherServices = fspProviderfspotherServices;
	}

	public String[] getFinancialInstrumentPartnerMappingSequence() {
		return financialInstrumentPartnerMappingSequence;
	}

	public void setFinancialInstrumentPartnerMappingSequence(
			String[] financialInstrumentPartnerMappingSequence) {
		this.financialInstrumentPartnerMappingSequence = financialInstrumentPartnerMappingSequence;
	}

	public Map<Integer, String> getPartnerSequenceMapping() {
		return partnerSequenceMapping;
	}

	public void setPartnerSequenceMapping(
			Map<Integer, String> partnerSequenceMapping) {
		this.partnerSequenceMapping = partnerSequenceMapping;
	}

	public String getSmsCode() {
		return smsCode;
	}

	public void setSmsCode(String smsCode) {
		this.smsCode = smsCode;
	}

	public String[] getFinancialInstrumentPartnerMapping() {
		return financialInstrumentPartnerMapping;
	}
	
	public void setFinancialInstrumentPartnerMapping(
			String[] financialInstrumentPartnerMapping) {
		this.financialInstrumentPartnerMapping = financialInstrumentPartnerMapping;
	}
	
	public Map<PartnerData, List<String>> getWalletWalletTypeMapping() {
		return walletWalletTypeMapping;
	}
	public void setWalletWalletTypeMapping(
			Map<PartnerData, List<String>> walletWalletTypeMapping) {
		this.walletWalletTypeMapping = walletWalletTypeMapping;
	}
	public Map<FinancialInstrumentData, List<PartnerData>> getNonFspfinancialInstrumentPartnerMapping() {
		return nonFspfinancialInstrumentPartnerMapping;
	}
	public void setNonFspfinancialInstrumentPartnerMapping(
			Map<FinancialInstrumentData, List<PartnerData>> nonFspfinancialInstrumentPartnerMapping) {
		this.nonFspfinancialInstrumentPartnerMapping = nonFspfinancialInstrumentPartnerMapping;
	}
	public Map<FSPServicesData, List<PartnerData>> getNonFspOtherServices() {
		return nonFspOtherServices;
	}
	public void setNonFspOtherServices(
			Map<FSPServicesData, List<PartnerData>> nonFspOtherServices) {
		this.nonFspOtherServices = nonFspOtherServices;
	}
	
	public List<String> getWalletType() {
		return walletType;
	}
	public void setWalletType(List<String> walletType) {
		this.walletType = walletType;
	}
	public boolean isFsp() {
		return fsp;
	}
	public void setFsp(boolean fsp) {
		this.fsp = fsp;
	}
	public AccountInfo getHostId() {
		return hostId;
	}
	public void setHostId(AccountInfo hostId) {
		this.hostId = hostId;
	}
	public Integer[] getWalletcheckBoxName() {
		return walletcheckBoxName;
	}
	public void setWalletcheckBoxName(Integer[] walletcheckBoxName) {
		this.walletcheckBoxName = walletcheckBoxName;
	}
	public List<PartnerData> getPartnerDatas() {
		return partnerDatas;
	}
	public void setPartnerDatas(List<PartnerData> partnerDatas) {
		this.partnerDatas = partnerDatas;
	}
	public String getSubVersionName() {
		return subVersionName;
	}
	public void setSubVersionName(String subVersionName) {
		this.subVersionName = subVersionName;
	}
	public List<MasterVersionData> getMasterVersionData() {
		return masterVersionData;
	}
	public void setMasterVersionData(List<MasterVersionData> masterVersionData) {
		this.masterVersionData = masterVersionData;
	}
	public Integer getMasterVersionId() {
		return masterVersionId;
	}
	public void setMasterVersionId(Integer masterVersionId) {
		this.masterVersionId = masterVersionId;
	}
	public String getHostSubVersionName() {
		return hostSubVersionName;
	}
	public void setHostSubVersionName(String hostSubVersionName) {
		this.hostSubVersionName = hostSubVersionName;
	}
	public List<ServiceConfigData> getStkMenuServiceList() {
		return stkMenuServiceList;
	}
	public void setStkMenuServiceList(List<ServiceConfigData> stkMenuServiceList) {
		this.stkMenuServiceList = stkMenuServiceList;
	}
	
	
	
	
	//partner data on hsv 
	
	public Integer[] getOtherServices() {
		return otherServices;
	}
	public void setOtherServices(Integer[] otherServices) {
		this.otherServices = otherServices;
	}
	public Integer[] getFspotherServices() {
		return fspotherServices;
	}
	public void setFspotherServices(Integer[] fspotherServices) {
		this.fspotherServices = fspotherServices;
	}
	public Integer[] getFinancialInstrument() {
		return financialInstrument;
	}
	public void setFinancialInstrument(Integer[] financialInstrument) {
		this.financialInstrument = financialInstrument;
	}
	public Integer[] getBank() {
		return bank;
	}
	public void setBank(Integer[] bank) {
		this.bank = bank;
	}
	public Integer[] getFspfundTransferBank() {
		return fspfundTransferBank;
	}
	public void setFspfundTransferBank(Integer[] fspfundTransferBank) {
		this.fspfundTransferBank = fspfundTransferBank;
	}
	public Integer[] getFspBank() {
		return fspBank;
	}
	public void setFspBank(Integer[] fspBank) {
		this.fspBank = fspBank;
	}
	public Integer[] getProviders() {
		return providers;
	}
	public void setProviders(Integer[] providers) {
		this.providers = providers;
	}
	public Integer[] getFspproviders() {
		return fspproviders;
	}
	public void setFspproviders(Integer[] fspproviders) {
		this.fspproviders = fspproviders;
	}
	public Integer[] getRiFspproviders() {
		return riFspproviders;
	}
	public void setRiFspproviders(Integer[] riFspproviders) {
		this.riFspproviders = riFspproviders;
	}
	public Integer[] getFspfinancialInstrument() {
		return fspfinancialInstrument;
	}
	public void setFspfinancialInstrument(Integer[] fspfinancialInstrument) {
		this.fspfinancialInstrument = fspfinancialInstrument;
	}
	
	
	
	public boolean isRifspfinancialInstrument() {
		return rifspfinancialInstrument;
	}
	public void setRifspfinancialInstrument(boolean rifspfinancialInstrument) {
		this.rifspfinancialInstrument = rifspfinancialInstrument;
	}
	public boolean isFundTransferFSP() {
		return fundTransferFSP;
	}
	
	public void setFundTransferFSP(boolean fundTransferFSP) {
		this.fundTransferFSP = fundTransferFSP;
	}
	public boolean isProviderFSP() {
		return providerFSP;
	}
	public void setProviderFSP(boolean providerFSP) {
		this.providerFSP = providerFSP;
	}
	public Map<CategoryData, List<ProvidersData>> getCategoryProviderMapping() {
		return categoryProviderMapping;
	}
	public void setCategoryProviderMapping(
			Map<CategoryData, List<ProvidersData>> categoryProviderMapping) {
		this.categoryProviderMapping = categoryProviderMapping;
	}

	

	public String getWalletstatus() {
		return walletstatus;
	}

	public void setWalletstatus(String walletstatus) {
		this.walletstatus = walletstatus;
	}


	public Map getWalletMap() {
		return walletMap;
	}

	public void setWalletMap(Map walletMap) {
		this.walletMap = walletMap;
	}

	public String getWalletDate() {
		return walletDate;
	}

	public void setWalletDate(String walletDate) {
		this.walletDate = walletDate;
	}

	public List<HostSubVersionCreationData> getPartnerDatas2() {
		return partnerDatas2;
	}

	public void setPartnerDatas2(List<HostSubVersionCreationData> partnerDatas2) {
		this.partnerDatas2 = partnerDatas2;
	}

	public Integer getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(Integer categoryId) {
		this.categoryId = categoryId;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public Integer getProviderId() {
		return providerId;
	}

	public void setProviderId(Integer providerId) {
		this.providerId = providerId;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getProviderStatus() {
		return providerStatus;
	}

	public void setProviderStatus(String providerStatus) {
		this.providerStatus = providerStatus;
	}

	public String getProvidersDate() {
		return providersDate;
	}

	public void setProvidersDate(String providersDate) {
		this.providersDate = providersDate;
	}

	public Integer[] getWalletcheckBox() {
		return walletcheckBox;
	}

	public void setWalletcheckBox(Integer[] walletcheckBox) {
		this.walletcheckBox = walletcheckBox;
	}

	public void setWalletId(Integer walletId) {
		this.walletId = 	walletId;
	}
	public Integer getWalletId() {
		return walletId;
	}

	public String[] getProvidercheckBox() {
		return providercheckBox;
	}

	public void setProvidercheckBox(String[] providercheckBox) {
		this.providercheckBox = providercheckBox;
	}

	public String getServiceDate() {
		return serviceDate;
	}

	public void setServiceDate(String serviceDate) {
		this.serviceDate = serviceDate;
	}

	public String getServicestatus() {
		return servicestatus;
	}

	public void setServicestatus(String servicestatus) {
		this.servicestatus = servicestatus;
	}

	public Integer[] getServicescheckBox() {
		return servicescheckBox;
	}

	public void setServicescheckBox(Integer[] servicescheckBox) {
		this.servicescheckBox = servicescheckBox;
	}

	public Integer getServiceConfigId() {
		return serviceConfigId;
	}

	public void setServiceConfigId(Integer serviceConfigId) {
		this.serviceConfigId = serviceConfigId;
	}

	public String getServiceConfigName() {
		return serviceConfigName;
	}

	public void setServiceConfigName(String serviceConfigName) {
		this.serviceConfigName = serviceConfigName;
	}

	public String getMainMenu() {
		return mainMenu;
	}

	public void setMainMenu(String mainMenu) {
		this.mainMenu = mainMenu;
	}

	public String getMainservicecheckBox() {
		return mainservicecheckBox;
	}

	public void setMainservicecheckBox(String mainservicecheckBox) {
		this.mainservicecheckBox = mainservicecheckBox;
	}

	
	
	
    
    
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
    
	
	

}
