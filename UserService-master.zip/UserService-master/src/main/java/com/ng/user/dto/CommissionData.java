/**
 * 
 */
package com.ng.user.dto;

import java.io.Serializable;

/**
 * @author gopal
 *
 */
public class CommissionData implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String txntype;
	private double commission;
    private String source;
    private String commissiontype;
    
	public String getTxntype() {
		return txntype;
	}
	public void setTxntype(String txntype) {
		this.txntype = txntype;
	}
	public double getCommission() {
		return commission;
	}
	public void setCommission(double commission) {
		this.commission = commission;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getCommissiontype() {
		return commissiontype;
	}
	public void setCommissiontype(String commissiontype) {
		this.commissiontype = commissiontype;
	}
    
    
}
