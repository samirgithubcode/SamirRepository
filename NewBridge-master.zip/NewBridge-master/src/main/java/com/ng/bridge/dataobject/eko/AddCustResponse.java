package com.ng.bridge.dataobject.eko;

public class AddCustResponse {
	private String responsetypeid;

    private String message;

    private String responsestatusid;

    private String status;

    private AddCustResData data;
    private InvalidParam invalidparams;

   

    public void setResponsetypeid (String responsetypeid)
    {
        this.responsetypeid = responsetypeid;
    }

    public String getMessage ()
    {
        return message;
    }

 
    public String getResponsetypeid ()
    {
        return responsetypeid;
    }
    public String getResponsestatusid ()
    {
        return responsestatusid;
    }

    public void setResponsestatusid (String responsestatusid)
    {
        this.responsestatusid = responsestatusid;
    }
    public void setMessage (String message)
    {
        this.message = message;
    }
    public String getStatus ()
    {
        return status;
    }

    public void setStatus (String status)
    {
        this.status = status;
    }

	public AddCustResData getData() {
		return data;
	}
	public void setInvalidparams(InvalidParam invalidparams) {
		this.invalidparams = invalidparams;
	}
	public void setData(AddCustResData data) {
		this.data = data;
	}

	public InvalidParam getInvalidparams() {
		return invalidparams;
	}
   

  

	
}
