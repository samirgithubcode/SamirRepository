package com.ng.sb.common.dataobject;

import java.io.Serializable;

public class BankCcData implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int bankCcid;
	private int binStartRange;
	private int binEndRange;
	private BankData bankData;
	
	public int getBankCcid() {
		return bankCcid;
	}
	public void setBankCcid(int bankCcid) {
		this.bankCcid = bankCcid;
	}
	public int getBinStartRange() {
		return binStartRange;
	}
	public void setBinStartRange(int binStartRange) {
		this.binStartRange = binStartRange;
	}
	public int getBinEndRange() {
		return binEndRange;
	}
	public void setBinEndRange(int binEndRange) {
		this.binEndRange = binEndRange;
	}
	public BankData getBankData() {
		return bankData;
	}
	public void setBankData(BankData bankData) {
		this.bankData = bankData;
	}
}
