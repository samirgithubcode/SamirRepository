/**
 * 
 */
package com.ng.transaction.dao;

/**
 * @author gaurav
 *
 */
public interface IFundTransferDAO extends IPaymentInstrumentDAO {

}
