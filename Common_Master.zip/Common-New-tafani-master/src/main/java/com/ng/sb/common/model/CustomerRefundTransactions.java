package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * The persistent class for the customercare refund transactions database table.
 * 
 */
@Entity
@Table(name = "cc_refund_transactions")
@XmlRootElement

@NamedQueries({
	@NamedQuery(name="CustomerRefundTransactions.findAll", query="SELECT c FROM CustomerRefundTransactions c"),
})
public class CustomerRefundTransactions implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(unique = true, nullable = false)
	private Integer id;
	@Column(name = "customerMobile")
	private String mobile;
	@Column(name = "customerName")
	private String customerName;
	@Column(name = "txn_id")
	private Long transactionId;
	@Column(name = "amount")
	private Float amount;
	@Column(name = "withCommission")
	private Integer withCommission;
	@Column(name = "initiatedBy")
	private String initiatedBy;
	@Column(name = "initiatedOn")
	@Temporal(TemporalType.TIMESTAMP)
	private Date initiationDate;
	@Column(name = "settledOn")
	@Temporal(TemporalType.TIMESTAMP)
	private Date settlementDate;
	@Column(name = "ref_txn_id")
	private Long refernceTransactionId;
	@Column(name = "status")
	private String status;
	@Column(name = "comment")
	private String comment;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Long transactionId) {
		this.transactionId = transactionId;
	}

	public String getInitiatedBy() {
		return initiatedBy;
	}

	public void setInitiatedBy(String initiatedBy) {
		this.initiatedBy = initiatedBy;
	}

	public Date getInitiationDate() {
		return initiationDate;
	}

	public void setInitiationDate(Date initiationDate) {
		this.initiationDate = initiationDate;
	}

	public Date getSettlementDate() {
		return settlementDate;
	}

	public void setSettlementDate(Date settlementDate) {
		this.settlementDate = settlementDate;
	}

	public Long getRefernceTransactionId() {
		return refernceTransactionId;
	}

	public void setRefernceTransactionId(Long refernceTransactionId) {
		this.refernceTransactionId = refernceTransactionId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Integer getWithCommission() {
		return withCommission;
	}

	public void setWithCommission(Integer withCommission) {
		this.withCommission = withCommission;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public Float getAmount() {
		return amount;
	}

	public void setAmount(Float amount) {
		this.amount = amount;
	}

}
