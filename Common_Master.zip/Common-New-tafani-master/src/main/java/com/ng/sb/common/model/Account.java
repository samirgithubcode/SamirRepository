package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the account database table.
 * 
 */
@Entity
@Table(name="account")
@NamedQueries({
@NamedQuery(name="Account.findAll", query="SELECT a FROM Account a"),
@NamedQuery(name="Account.findByAccountNumberAndIFSC", query="SELECT a FROM Account a WHERE a.accNumber = :accNumber AND a.ifsc = :ifsc"),
@NamedQuery(name="Account.findBymobileNumberAndWalletId", query="SELECT a FROM Account a WHERE a.mobileNumber = :mobileNumber AND a.walletId = :walletId")
})
public class Account implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false)
	private Integer id;

	@Column(name="accNumber")
	private String accNumber;

	@Column(name="balance")
	private Integer balance;

	@Column(name="createDate")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createDate;

	@Column(name="editDate")
	@Temporal(TemporalType.TIMESTAMP)
	private Date editDate;

	@Column(name="ifsc")
	private String ifsc;

	@Column(name="instrumentType")
	private String instrumentType;

	@Column(name="mobileNumber")
	private String mobileNumber;

	//bi-directional many-to-one association to Partner
	@ManyToOne
	@JoinColumn(name="walletId")
	private Partner walletId;

	//bi-directional many-to-one association to AccountTransaction
	@OneToMany(mappedBy="payerAccId")
	private List<AccountTransaction> payerAccTransactions;

	//bi-directional many-to-one association to AccountTransaction
	@OneToMany(mappedBy="payeeAccId")
	private List<AccountTransaction> payeeAccTransactions;

	public Account() {
		//empty
	}

	public Account(Integer id) {
		this.id = id;
	}
	
	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getAccNumber() {
		return this.accNumber;
	}

	public void setAccNumber(String accNumber) {
		this.accNumber = accNumber;
	}

	public Integer getBalance() {
		return this.balance;
	}

	public void setBalance(Integer balance) {
		this.balance = balance;
	}

	public Date getCreateDate() {
		return this.createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getEditDate() {
		return this.editDate;
	}

	public void setEditDate(Date editDate) {
		this.editDate = editDate;
	}

	public String getIfsc() {
		return this.ifsc;
	}

	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}

	public String getInstrumentType() {
		return this.instrumentType;
	}

	public void setInstrumentType(String instrumentType) {
		this.instrumentType = instrumentType;
	}

	public String getMobileNumber() {
		return this.mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public Partner getwalletId() {
		return this.walletId;
	}

	public void setwalletId(Partner walletId) {
		this.walletId = walletId;
	}

	public List<AccountTransaction> getPayerAccTransactions() {
		return this.payerAccTransactions;
	}

	public void setPayerAccTransactions(List<AccountTransaction> payerAccTransactions) {
		this.payerAccTransactions = payerAccTransactions;
	}

	public AccountTransaction addAccountTransactions1(AccountTransaction accountTransactions1) {
		getPayerAccTransactions().add(accountTransactions1);
		accountTransactions1.setPayerAccId(this);

		return accountTransactions1;
	}

	public AccountTransaction removeAccountTransactions1(AccountTransaction accountTransactions1) {
		getPayerAccTransactions().remove(accountTransactions1);
		accountTransactions1.setPayerAccId(null);

		return accountTransactions1;
	}

	public List<AccountTransaction> getAccountTransactions2() {
		return this.payeeAccTransactions;
	}

	public void setAccountTransactions2(List<AccountTransaction> payeeAccTransactions) {
		this.payeeAccTransactions = payeeAccTransactions;
	}

	public AccountTransaction addAccountTransactions2(AccountTransaction accountTransactions2) {
		getAccountTransactions2().add(accountTransactions2);
		accountTransactions2.setPayeeAccId(this);

		return accountTransactions2;
	}

	public AccountTransaction removeAccountTransactions2(AccountTransaction accountTransactions2) {
		getAccountTransactions2().remove(accountTransactions2);
		accountTransactions2.setPayeeAccId(null);

		return accountTransactions2;
	}

	 @Override
		public String toString() {
			return "Account [id=" + id + "]";
		}


    @Override
    public boolean equals(Object object) {
    	boolean check=true;
    	if(object!=null){
        if (!(object instanceof Account)) {
        	check= false;
        }
        Account other = (Account) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
    	}
        return check;
    }
    
   
	@Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }
	
}