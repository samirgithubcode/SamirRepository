/**
 * 
 */
package com.ng.bridge.service.impl;

import org.springframework.stereotype.Service;

import com.ng.bridge.service.IOtherService;
import com.ng.sb.common.util.SystemConstant;

/**
 * @author gaurav
 *
 */
@Service(SystemConstant.BRIDGE_OTHER_BRIDGE_SERVICE)
public class OtherService extends BridgeService implements IOtherService {

}
