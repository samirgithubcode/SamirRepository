/**
 * 
 */
package com.ng.bridge.service;

import com.ng.sb.common.dataobject.BridgeDataObject;

/**
 * @author gaurav
 *
 */
public interface IWalletService extends IFundTransferMgtService {

	public BridgeDataObject fundTransferWalletToWallet(BridgeDataObject bridgeDataObject);
	public BridgeDataObject fundTransferWalletToBank(BridgeDataObject bridgeDataObject);
	public BridgeDataObject fundTransferWalletToIMPS(BridgeDataObject bridgeDataObject);
	public BridgeDataObject fundTransferWalletToCC(BridgeDataObject bridgeDataObject);
}
