package com.ng.bridge.dataobject.eko;

public class TransactionEnquiryResData {

	private String amount;

    private String fee;

    private String timestamp;

    private String txStatusDesc;

    private String txStatus;

    private String recipientId;

    private String tid;

    private String serviceTax;

    private String channel;

    private String customerId;

    private String currency;

    private String bankRefNum;
    
    private String branch;
    
    
    

    public String getFee ()
    {
        return fee;
    }

    public void setFee (String fee)
    {
        this.fee = fee;
    }
    public String getAmount ()
    {
        return amount;
    }

    public void setAmount (String amount)
    {
        this.amount = amount;
    }
    public String getTimestamp ()
    {
        return timestamp;
    }

    public void setTimestamp (String timestamp)
    {
        this.timestamp = timestamp;
    }

    

    public String getTxStatus ()
    {
        return txStatus;
    }

    public void setTxStatus (String txStatus)
    {
        this.txStatus = txStatus;
    }
    public String getTxStatusDesc ()
    {
        return txStatusDesc;
    }

    public void setTxstatusDesc (String txStatusDesc)
    {
        this.txStatusDesc =  txStatusDesc;
    }
    public String getRecipientId ()
    {
        return recipientId;
    }

    public void setRecipientId (String recipientId)
    {
        this.recipientId = recipientId;
    }

    

    public String getServiceTax ()
    {
        return serviceTax;
    }

    public void setServiceTax (String serviceTax)
    {
        this.serviceTax = serviceTax;
    }
    public String getTid ()
    {
        return tid;
    }

    public void setTid (String tid)
    {
        this.tid = tid;
    }
    public String getChannel ()
    {
        return channel;
    }

    public void setChannel (String channel)
    {
        this.channel = channel;
    }

    

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

    public String getCurrency ()
    {
        return currency;
    }

    public void setCurrency (String currency)
    {
        this.currency = currency;
    }
    public String getCustomerId ()
    {
        return customerId;
    }

    public void setCustomerId (String customerId)
    {
        this.customerId = customerId;
    }
    
    public String getBankRefNum() {
		return bankRefNum;
	}

	public void setBankRefNum(String bankRefNum) {
		this.bankRefNum = bankRefNum;
	}

	@Override
    public String toString()
    {
        return "ClassPojo [amount = "+amount+", fee = "+fee+", timestamp = "+timestamp+", txstatus_desc = "+txStatusDesc+", tx_status = "+txStatus+", recipient_id = "+recipientId+", tid = "+tid+", service_tax = "+serviceTax+", channel = "+channel+", customer_id = "+customerId+", currency = "+currency+"]";
    }
}
