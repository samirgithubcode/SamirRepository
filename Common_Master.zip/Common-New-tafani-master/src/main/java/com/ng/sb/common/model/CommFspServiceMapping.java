/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "CommFspServiceMapping")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CommFspServiceMapping.findAll", query = "SELECT c FROM CommFspServiceMapping c"),
    @NamedQuery(name = "CommFspServiceMapping.findById", query = "SELECT c FROM CommFspServiceMapping c WHERE c.id = :id"),
    @NamedQuery(name = "CommFspServiceMapping.findByFspServieType", query = "SELECT c FROM CommFspServiceMapping c WHERE c.fspServieType = :fspServieType")})
public class CommFspServiceMapping implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Column(name = "fspServieType")
    private String fspServieType;
    @JoinColumn(name = "fspServicesId", referencedColumnName = "id")
    @ManyToOne
    private FSPServices fspServicesId;
    @JoinColumn(name = "partnerId", referencedColumnName = "id")
    @ManyToOne
    private Partner partnerId;
    @JoinColumn(name = "commTempId", referencedColumnName = "id")
    @ManyToOne
    private CommissionTemplate commTempId;

    public CommFspServiceMapping() {
    	//empty
    }

    public CommFspServiceMapping(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFspServieType() {
        return fspServieType;
    }

    public void setFspServieType(String fspServieType) {
        this.fspServieType = fspServieType;
    }

    public FSPServices getFspServicesId() {
        return fspServicesId;
    }

    public void setFspServicesId(FSPServices fspServicesId) {
        this.fspServicesId = fspServicesId;
    }

    public Partner getPartnerId() {
        return partnerId;
    }

    public void setPartnerId(Partner partnerId) {
        this.partnerId = partnerId;
    }

    public CommissionTemplate getCommTempId() {
        return commTempId;
    }

    public void setCommTempId(CommissionTemplate commTempId) {
        this.commTempId = commTempId;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.CommFspServiceMapping[ id=" + id + " ]";
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof CommFspServiceMapping)) {
            return false;
        }
        boolean check=true;
        CommFspServiceMapping other = (CommFspServiceMapping) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }
    
    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }
    
   
    
}
