/**
 * 
 */
package com.ng.sb.common.dataobject;

import java.util.HashMap;
import java.util.Map;

import com.ng.sb.common.dataobject.InstrumentData.Sequence;
import com.ng.sb.common.dataobject.ServiceMappingDef.Type;

/**
 * @author gaurav
 *
 */
public class SelectedPartnerSequenceData extends BaseObjectData {
	private static final long serialVersionUID = 1L;
	private Map<Sequence, PartnerSequence> directPartnerMap = new HashMap<>();
	private PartnerSequence fspPartnerSequence;
	private PartnerSequence regInstFspPartnerSequence;
	private Type type;
	

	public Map<Sequence, PartnerSequence> getDirectPartnerMap() {
		return directPartnerMap;
	}

	public void setDirectPartnerMap(Map<Sequence, PartnerSequence> directPartnerMap) {
		this.directPartnerMap = directPartnerMap;
	}

	public PartnerSequence getFspPartnerSequence() {
		return fspPartnerSequence;
	}

	public void setFspPartnerSequence(PartnerSequence fspPartnerSequence) {
		this.fspPartnerSequence = fspPartnerSequence;
	}

	public PartnerSequence getRegInstFspPartnerSequence() {
		return regInstFspPartnerSequence;
	}

	public void setRegInstFspPartnerSequence(
			PartnerSequence regInstFspPartnerSequence) {
		this.regInstFspPartnerSequence = regInstFspPartnerSequence;
	}

	public Type getType() {
		return type;
	}

	public void setType(Type type) {
		this.type = type;
	}

}
