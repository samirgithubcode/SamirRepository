package com.ng.transaction.dto.sbi;

public class CustomerRegistrationGenericRequestMsgDTO {
	
	private String requestMsg;
	
	private Integer pspId;

	public String getRequestMsg() {
		return requestMsg;
	}

	public void setRequestMsg(String requestMsg) {
		this.requestMsg = requestMsg;
	}

	public Integer getPspId() {
		return pspId;
	}

	public void setPspId(Integer pspId) {
		this.pspId = pspId;
	}
}
