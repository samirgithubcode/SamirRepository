package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * @author abhishek
 *
 */
@Entity
@Table(name="HostSVLongCodeHistory")
@NamedQuery(name="HostSVLongCodeHistory.findAll", query="SELECT h FROM HostSVLongCodeHistory h")
public class HostSVLongCodeHistory implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;

	@Column(name="longcode")
	private String longcode;

	//bi-directional many-to-one association to HostSubVersion
	@ManyToOne
	@JoinColumn(name="hsvId")
	private HostSubVersion hsvId;

	public HostSVLongCodeHistory() {
		//empty
	}
	
	public HostSVLongCodeHistory(Integer id) {
		this.id = id;
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getLongcode() {
		return this.longcode;
	}

	public void setLongcode(String longcode) {
		this.longcode = longcode;
	}

	public HostSubVersion getHsvId() {
		return this.hsvId;
	}

	public void setHsvId(HostSubVersion hsvId) {
		this.hsvId = hsvId;
	}
	@Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof HostSVLongCodeHistory)) {
            return false;
        }
        HostSVLongCodeHistory other = (HostSVLongCodeHistory) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.HostSVLongCodeHistory[ id=" + id + " ]";
    }
}