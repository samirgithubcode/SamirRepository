/**
 * 
 */
package com.ng.pnb.invoker.util;

import java.io.IOException;
import java.util.Date;
import java.util.Map;

import org.jpos.iso.ISOException;
import org.jpos.iso.ISOMsg;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ng.pnb.bridge.dao.impl.IPNBDao;
import com.ng.pnb.bridge.invoker.PNBUtility;
import com.ng.pnb.bridge.iso.IISOMessageCreator;
import com.ng.pnb.bridge.iso.IISOMessageParser;
import com.ng.pnb.bridge.service.ISocketService;
import com.ng.sb.common.dataobject.BridgeDataObject;
import com.ng.sb.common.dataobject.BridgeDataObject.ServiceType;
import com.ng.sb.common.dataobject.BridgeDataResponse;
import com.ng.sb.common.dataobject.BridgeDataResponse.Status;
import com.ng.sb.common.dataobject.HostSubVersionData.ProviderRelation;
import com.ng.sb.common.dataobject.ProvidersData;
import com.ng.sb.common.dataobject.ResponseObject;
import com.ng.sb.common.model.CustomerDetails;
import com.ng.sb.common.model.InternalAccountMaster;
import com.ng.sb.common.model.PoolAccount;
import com.ng.sb.common.util.ErrorCodes;
import com.ng.sb.common.util.SystemConstant;

/**
 * @author gopal
 *
 */
@Component("isoHandler")
public class ISOHandler 
{
	@Autowired
	IISOMessageCreator genericIsoMessageCreator;
	
	@Autowired
	ISocketService socketService;
	
	@Autowired
	IISOMessageParser isoMessageParser;
	
	@Autowired
	PNBUtility pnbUtility;
	
	@Autowired
	IPNBDao pnbDao;
	
	public BridgeDataResponse processChequeStatus(BridgeDataObject bridgeDataObject)
	{
		BridgeDataResponse response = new BridgeDataResponse();
		
		try {
			ISOMsg responseMsg = socketService.writeOnSocket(bridgeDataObject.getTransactionData().getTransactionId(), genericIsoMessageCreator.createChequeStatusMessage(bridgeDataObject));
			
			if(responseMsg != null)
			{
				Map<Integer,String> isoMap = isoMessageParser.parseMessage(bridgeDataObject.getTransactionData().getTransactionId(), responseMsg);
				
				if(isoMap != null && !isoMap.isEmpty() && isoMap.get(39).equals("000"))
				{
					pnbUtility.createChequeStatusFSPResponse(bridgeDataObject, isoMap);
				
					response = bridgeDataObject.getBridgeResponse();
					
					return response;
					
				}else{
					pnbUtility.createErrorResponse(bridgeDataObject, Integer.parseInt(isoMap.get(39)) );
					response = bridgeDataObject.getBridgeResponse();
					response.setStatus(Status.FAILED);
					
					return response;
				}
			}else{
				pnbUtility.createErrorResponse(bridgeDataObject);
				
				response = bridgeDataObject.getBridgeResponse();
				response.setStatus(Status.FAILED);
				
				return response;
			}
		} catch (NumberFormatException | IOException | ISOException e) {
			e.printStackTrace();
		}
		
		return response;
	}

	public BridgeDataResponse processBankBalanceCheck(BridgeDataObject bridgeDataObject) 
	{
		BridgeDataResponse response = new BridgeDataResponse();
		
		try {
			ISOMsg responseMsg = socketService.writeOnSocket(bridgeDataObject.getTransactionData().getTransactionId(), genericIsoMessageCreator.createBalEnquiryMessage(bridgeDataObject));
			
			if(responseMsg != null)
			{
				Map<Integer,String> isoMap = isoMessageParser.parseMessage(bridgeDataObject.getTransactionData().getTransactionId(), responseMsg);
				
				if(isoMap != null && !isoMap.isEmpty() && isoMap.get(39).equals("000"))
				{
					pnbUtility.createBalanceEnquiryFSPResponse(bridgeDataObject, isoMap);
				
					response = bridgeDataObject.getBridgeResponse();
					
					return response;
					
				}else{
					pnbUtility.createErrorResponse(bridgeDataObject);
					response = bridgeDataObject.getBridgeResponse();
					response.setStatus(Status.FAILED);
					
					return response;
				}
			}else{
				pnbUtility.createErrorResponse(bridgeDataObject);
				
				response = bridgeDataObject.getBridgeResponse();
				response.setStatus(Status.FAILED);
				
				return response;
			}
		} catch (NumberFormatException | IOException | ISOException e) {
			e.printStackTrace();
		}
		
		return response;
	}
	
	public BridgeDataResponse processWalletBalanceCheck(BridgeDataObject bridgeDataObject) 
	{
		BridgeDataResponse response = new BridgeDataResponse();
		
		try {
			ISOMsg responseMsg = socketService.writeOnSocket(bridgeDataObject.getTransactionData().getTransactionId(), genericIsoMessageCreator.createWalletBalanceEnquiryMessage(bridgeDataObject));
			
			if(responseMsg != null)
			{
				Map<Integer,String> isoMap = isoMessageParser.parseMessage(bridgeDataObject.getTransactionData().getTransactionId(), responseMsg);
				
				if(isoMap != null && !isoMap.isEmpty() && isoMap.get(39).equals("000"))
				{
					pnbUtility.createBalanceEnquiryFSPResponse(bridgeDataObject, isoMap);
				
					response = bridgeDataObject.getBridgeResponse();
					
					return response;
					
				}else{
					pnbUtility.createErrorResponse(bridgeDataObject);
					response = bridgeDataObject.getBridgeResponse();
					response.setStatus(Status.FAILED);
					
					return response;
				}
			}else{
				pnbUtility.createErrorResponse(bridgeDataObject);
				
				response = bridgeDataObject.getBridgeResponse();
				response.setStatus(Status.FAILED);
				
				return response;
			}
			
		} catch (NumberFormatException | IOException | ISOException e) {
			e.printStackTrace();
		}
		
		return response;
	}
	
	
	public BridgeDataResponse processBankingTxnHistory(BridgeDataObject bridgeDataObject)
	{
		BridgeDataResponse response = new BridgeDataResponse();
		
		try 
		{
		ISOMsg responseMsg = socketService.writeOnSocket(bridgeDataObject.getTransactionData().getTransactionId(), genericIsoMessageCreator.createMiniStatementMessage(bridgeDataObject));
		
			if(responseMsg != null)
			{
				Map<Integer,String> isoMap = isoMessageParser.parseMessage(bridgeDataObject.getTransactionData().getTransactionId(), responseMsg);
				
				if(isoMap != null && !isoMap.isEmpty() && isoMap.get(39).equals("000"))
				{
					pnbUtility.createMiniStatementFSPResponse(bridgeDataObject, isoMap);
				
					response = bridgeDataObject.getBridgeResponse();
					
					return response;
					
				}else{
					pnbUtility.createErrorResponse(bridgeDataObject);
					response = bridgeDataObject.getBridgeResponse();
					response.setStatus(Status.FAILED);
					
					return response;
				}
			}else{
				pnbUtility.createErrorResponse(bridgeDataObject);
				
				response = bridgeDataObject.getBridgeResponse();
				response.setStatus(Status.FAILED);
				
				return response;
			}
		} catch (NumberFormatException | IOException | ISOException e) {
			e.printStackTrace();
		}
		
		return response;
	}
	
	public BridgeDataResponse processUtilityPaymentsFromBank(BridgeDataObject bridgeDataObject)
	{
		BridgeDataResponse response = new BridgeDataResponse();
		try{
			ProvidersData fromCache = bridgeDataObject.getHostSubVersionData().getProviderMap().get(ProviderRelation.FSP_PROVIDER).get(new ProvidersData(bridgeDataObject.getProvider().getCode()));
			
			ProvidersData requestDetals = bridgeDataObject.getProvider();
			
			String transactionDetails = "Utility Payment:"+fromCache.getCategory().getName()+"-"+fromCache.getName()+"-"+requestDetals.getSubscriberId();
			
			ISOMsg responseMsg = socketService.writeOnSocket(bridgeDataObject.getTransactionData().getTransactionId(), genericIsoMessageCreator.createFundDebitMessage(bridgeDataObject,transactionDetails));
			
			if(responseMsg != null)
			{
				Map<Integer,String> isoMap = isoMessageParser.parseMessage(bridgeDataObject.getTransactionData().getTransactionId(), responseMsg);
				
				if(isoMap != null && !isoMap.isEmpty() && isoMap.get(39).equals("000"))
				{
					String currentBalance = pnbUtility.getCurrentBalanceFromDebitCreditResponse(isoMap.get(48));
					
					CustomerDetails customerDetails = pnbDao.getCustomerDetailsByAccount(bridgeDataObject.getPayerBankAccount().getAccountNumber(), bridgeDataObject.getPayerBankAccount().getIfscCode());
				
					response = managePoolAndExternalCall(bridgeDataObject.getServiceType(),customerDetails , bridgeDataObject, true,  currentBalance, transactionDetails);
					
					return response;
					
				}else{
					pnbUtility.createBankToBankFSPResponse(bridgeDataObject, isoMap);
					response = bridgeDataObject.getBridgeResponse();
					response.setStatus(Status.FAILED);
					
					return response;
				}
			}else{
				pnbUtility.createErrorResponse(bridgeDataObject);
				
				response = bridgeDataObject.getBridgeResponse();
				response.setStatus(Status.FAILED);
				
				return response;
			}
			
		}catch(IOException | ISOException e)
		{
			pnbUtility.createErrorResponse(bridgeDataObject);
			
			response = bridgeDataObject.getBridgeResponse();
			response.setStatus(Status.FAILED);
			
			return response;
		}
	}
	
	
	public BridgeDataResponse processFundTransferWalletToBank(BridgeDataObject bridgeDataObject) 
	{
		BridgeDataResponse response = new BridgeDataResponse();
		try{
			
			String transactionDetails = "";
			ISOMsg responseMsg = socketService.writeOnSocket(bridgeDataObject.getTransactionData().getTransactionId(), genericIsoMessageCreator.createWalletDebitMessage(bridgeDataObject,transactionDetails));
			
			if(responseMsg != null)
			{
				Map<Integer,String> isoMap = isoMessageParser.parseMessage(bridgeDataObject.getTransactionData().getTransactionId(), responseMsg);
				
				if(isoMap != null && !isoMap.isEmpty() && isoMap.get(39).equals("000"))
				{
					String currentBalance = pnbUtility.getCurrentBalanceFromDebitCreditResponse(isoMap.get(48));
					
					CustomerDetails customerDetails = pnbDao.getCustomerDetailsByAccount(bridgeDataObject.getPayerBankAccount().getAccountNumber(), bridgeDataObject.getPayerBankAccount().getIfscCode());
				
					response = managePoolAndExternalCall(bridgeDataObject.getServiceType(),customerDetails , bridgeDataObject, true, currentBalance, transactionDetails );
					
					return response;
					
				}else{
					pnbUtility.createBankToBankFSPResponse(bridgeDataObject, isoMap);
					response = bridgeDataObject.getBridgeResponse();
					response.setStatus(Status.FAILED);
					
					return response;
				}
			}else{
				pnbUtility.createErrorResponse(bridgeDataObject);
				
				response = bridgeDataObject.getBridgeResponse();
				response.setStatus(Status.FAILED);
				
				return response;
			}
		}catch(IOException | ISOException e)
		{
			pnbUtility.createErrorResponse(bridgeDataObject);
			
			response = bridgeDataObject.getBridgeResponse();
			response.setStatus(Status.FAILED);
			
			return response;
		}	
	}
	
	public BridgeDataResponse processFundTransferBankToWallet(BridgeDataObject bridgeDataObject) 
	{
		BridgeDataResponse response = new BridgeDataResponse();
		try{
			
			String transactionDetails = "Wallet:"+bridgeDataObject.getPayeeWallet().getWalletCode()+"-"+bridgeDataObject.getPayeeWallet().getMsisdn();
			
			ISOMsg responseMsg = socketService.writeOnSocket(bridgeDataObject.getTransactionData().getTransactionId(), genericIsoMessageCreator.createFundDebitMessage(bridgeDataObject, transactionDetails));
			
			if(responseMsg != null)
			{
				Map<Integer,String> isoMap = isoMessageParser.parseMessage(bridgeDataObject.getTransactionData().getTransactionId(), responseMsg);
				
				if(isoMap != null && !isoMap.isEmpty() && isoMap.get(39).equals("000"))
				{
					String currentBalance = pnbUtility.getCurrentBalanceFromDebitCreditResponse(isoMap.get(48));
					
					CustomerDetails customerDetails = pnbDao.getCustomerDetailsByAccount(bridgeDataObject.getPayerBankAccount().getAccountNumber(), bridgeDataObject.getPayerBankAccount().getIfscCode());
				
					response = managePoolAndExternalCall(bridgeDataObject.getServiceType(),customerDetails , bridgeDataObject, true, currentBalance, transactionDetails );
					
					return response;
					//Credit Amount to Pool A/c
				}else{
					pnbUtility.createBankToBankFSPResponse(bridgeDataObject, isoMap);
					response = bridgeDataObject.getBridgeResponse();
					response.setStatus(Status.FAILED);
					
					return response;
				}
			}else{
				pnbUtility.createErrorResponse(bridgeDataObject);
				
				response = bridgeDataObject.getBridgeResponse();
				response.setStatus(Status.FAILED);
				
				return response;
			}
			
		}catch(IOException | ISOException e)
		{
			pnbUtility.createErrorResponse(bridgeDataObject);
			
			response = bridgeDataObject.getBridgeResponse();
			response.setStatus(Status.FAILED);
			
			return response;
		}	
	}
	
	private synchronized BridgeDataResponse managePoolAndExternalCall(ServiceType serviceType, CustomerDetails customerDetails, BridgeDataObject bridgeDataObject, boolean isOnUsTransaction, String updatedBalance, String transactionDetails) 
	{
		BridgeDataResponse response = new BridgeDataResponse();
		
		try{
			
			InternalAccountMaster accountMaster = pnbDao.getAccountMaster(PnbConstants.LIEN_ACCOUNT_TYPE);
			
			PoolAccount poolAccount = new PoolAccount();
			
			if(bridgeDataObject.getPayerBankAccount() != null)
			{
				poolAccount.setInstrument(SystemConstant.BANK);
				poolAccount.setAccountNumber(Long.parseLong(bridgeDataObject.getPayerBankAccount().getAccountNumber()));
				
			}else if(bridgeDataObject.getPayerWallet() != null)
			{
				poolAccount.setInstrument(SystemConstant.WALLETS);
				poolAccount.setAccountNumber(Long.parseLong(bridgeDataObject.getPayerWallet().getMsisdn()));
			}
			
			if(bridgeDataObject.getPayerBankAccount() != null)
			{
				poolAccount.setTransactionDescription(bridgeDataObject.getServiceType().toString() + ":" + bridgeDataObject.getPayerBankAccount().getAccountNumber()+"-"+bridgeDataObject.getPayerBankAccount().getIfscCode());
			}else if(bridgeDataObject.getPayeeWallet() != null)
			{
				poolAccount.setTransactionDescription(bridgeDataObject.getServiceType().toString() + ":" + bridgeDataObject.getPayeeWallet().getMsisdn()+"-"+bridgeDataObject.getPayeeWallet().getWalletCode());
			}
			
			poolAccount.setOpeningBalance(accountMaster.getAccountBalance());
			
			poolAccount.setCustomerId(customerDetails.getCustomerId());
			poolAccount.setTransactionAmount((double)bridgeDataObject.getAmount());
			poolAccount.setTransactionId(bridgeDataObject.getTransactionData().getTransactionId());
			poolAccount.setTransactionNature(SystemConstant.TRANSACTION_NATURE_CREDIT);
			poolAccount.setTransactionStatus(SystemConstant.SUCCESS);
			poolAccount.setTransactionStatusDescription(SystemConstant.SUCCESS);
			poolAccount.setTransactionType(bridgeDataObject.getServiceType().toString());
			poolAccount.setTrasactionOn(new Date());
			
			poolAccount.setClosingBalance(accountMaster.getAccountBalance() + (double)bridgeDataObject.getAmount());
			
			boolean saveStatus = pnbDao.saveEntity(poolAccount);
			
			accountMaster.setAccountBalance(accountMaster.getAccountBalance() + (double)bridgeDataObject.getAmount());
			accountMaster.setUpdatedOn(new Date());
			
			pnbDao.updateEntity(accountMaster);
			
			ResponseObject externalCallResponse = null;
			
			String responseMessage = null;
			
			if(saveStatus)
			{
				
				switch(serviceType)
				{
				
				case BANKING_FT_B_TO_B:
					externalCallResponse = new ResponseObject(); //call NPCI Api
					
					externalCallResponse.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode().intValue());
					externalCallResponse.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
					
					String payerAccount = pnbUtility.getMaskedAccountNumber(bridgeDataObject.getPayerBankAccount().getAccountNumber());
					
					String payeeAccount = pnbUtility.getMaskedAccountNumber(bridgeDataObject.getPayeeBankAccount().getAccountNumber());
					
					if(externalCallResponse.getStatus().intValue() == ErrorCodes.REQUEST_SUCCESSFUL.getCode().intValue())
						responseMessage = PnbConstants.AC + payerAccount + "  has been debited successfully with INR "+ bridgeDataObject.getAmount()+" for Fund transfer to "+ PnbConstants.AC_NO + payeeAccount+".Current balance is INR "+updatedBalance+".";
					else
						responseMessage = "Fund transfer from your  A/C  "+payerAccount+"  to  A/C  "+payeeAccount+"  is Failed. Please try after some times.";
					
					break;
					
				case BANKING_FT_B_TO_WALLET:
					//externalCallResponse = null; //call Wallet Credit API
					
					externalCallResponse = new ResponseObject();
					
					externalCallResponse.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
					externalCallResponse.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
					break;
					
				case BILL_PAY_BY_B:
					//externalCallResponse = null; //call BillDesk API
					externalCallResponse = new ResponseObject();
					
					externalCallResponse.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
					externalCallResponse.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
					
					break;
					
				case BILL_PAY_BY_WALLET:
					//externalCallResponse = null; //call BillDesk Api
					externalCallResponse = new ResponseObject();
					
					externalCallResponse.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
					externalCallResponse.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
					
					break;
					
				case TOP_UP_RECH_BY_B:
					//externalCallResponse = null; //call BillDesk API
					
					externalCallResponse = new ResponseObject();
					
					externalCallResponse.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
					externalCallResponse.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());					
					break;
					
				case TOP_UP_RECH_BY_WALLET:
					//externalCallResponse = null; //call BillDesk API
					
					externalCallResponse = new ResponseObject();
					
					externalCallResponse.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
					externalCallResponse.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
					
					
					break;
					
				case OTH_PAY_RET_B_TO_WALLET:
					//externalCallResponse = null; //call Wallet Credit Api
					
					externalCallResponse = new ResponseObject();
					
					externalCallResponse.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
					externalCallResponse.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
					
					break;
					
				case OTH_PAY_RET_WALLET_TO_B:
					//externalCallResponse = null; //call NPCI API
					
					externalCallResponse = new ResponseObject();
					
					externalCallResponse.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
					externalCallResponse.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
					
					break;
					
				case OTH_PAY_INDI_B_TO_WALLET:
					//externalCallResponse = null; //call Wallet Credit API
					
					externalCallResponse = new ResponseObject();
					
					externalCallResponse.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
					externalCallResponse.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
					
					break;
					
				case OTH_PAY_INDI_WALLET_TO_B:
					//externalCallResponse = null; //call NPCI Api
					
					externalCallResponse = new ResponseObject();
					
					externalCallResponse.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
					externalCallResponse.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
					
					break;
					
				}
				
				
				if(externalCallResponse.getStatus().intValue() == ErrorCodes.REQUEST_SUCCESSFUL.getCode().intValue())
				{
					poolAccount.setTransactionStatus(SystemConstant.SUCCESS);
					poolAccount.setTransactionStatusDescription(SystemConstant.SUCCESS);
					
					poolAccount.setOpeningBalance(poolAccount.getClosingBalance());
					poolAccount.setClosingBalance(poolAccount.getClosingBalance() - (double)bridgeDataObject.getAmount());
					
					poolAccount.setTransactionNature(SystemConstant.TRANSACTION_NATURE_DEBIT);
					poolAccount.setTrasactionOn(new Date());
					poolAccount.setId(null);

					pnbDao.saveEntity(poolAccount);
					
					accountMaster.setAccountBalance(accountMaster.getAccountBalance() - (double)bridgeDataObject.getAmount());
					accountMaster.setUpdatedOn(new Date());
					
					pnbDao.updateEntity(accountMaster);
					
					response.setStatus(Status.SUCCESS);
					response.setResponseMsg(responseMessage);
					
					return response;
					
				}else 
				{
				
					ISOMsg creditResponseMsg = socketService.writeOnSocket(bridgeDataObject.getTransactionData().getTransactionId(), genericIsoMessageCreator.createFundCreditMessage(bridgeDataObject, transactionDetails));
					
					if(creditResponseMsg != null && creditResponseMsg.hasField(39) && creditResponseMsg.getString(39).equals("000"))
					{
						poolAccount.setTransactionStatus(SystemConstant.REFUNDED);
						poolAccount.setTransactionStatusDescription(externalCallResponse.getMessage());
						
						poolAccount.setOpeningBalance(poolAccount.getClosingBalance());
						poolAccount.setClosingBalance(poolAccount.getClosingBalance() - (double)bridgeDataObject.getAmount());
						
						poolAccount.setTransactionNature(SystemConstant.TRANSACTION_NATURE_DEBIT);
						poolAccount.setTrasactionOn(new Date());
						poolAccount.setId(null);

						boolean updateStatus = pnbDao.saveEntity(poolAccount);
						
						accountMaster.setAccountBalance(accountMaster.getAccountBalance() - (double)bridgeDataObject.getAmount());
						accountMaster.setUpdatedOn(new Date());
						
						pnbDao.updateEntity(accountMaster);
					}
					
					response.setStatus(Status.SUCCESS);
					response.setResponseMsg(responseMessage);
					
					return response;
				}
			}else{
			
				ISOMsg creditResponseMsg = socketService.writeOnSocket(bridgeDataObject.getTransactionData().getTransactionId(), genericIsoMessageCreator.createFundCreditMessage(bridgeDataObject, transactionDetails));
				
				response.setStatus(Status.FAILED);
				response.setResponseMsg("Fund transfer from your  A/C  "+bridgeDataObject.getPayerBankAccount().getAccountNumber()+"  to  A/C  "+bridgeDataObject.getPayeeBankAccount().getAccountNumber()+"  is Failed.");
				
				return response;
			}
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return response;
	}
}
