/**
 * 
 */
package com.ng.user.db.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ng.sb.common.model.AccountLoginInfo;
import com.ng.sb.common.model.Address;
import com.ng.sb.common.model.CustomerDetails;
import com.ng.sb.common.model.InventoryMgmt;
import com.ng.sb.common.model.Menu;
import com.ng.sb.common.model.MerchantInfo;
import com.ng.sb.common.model.MerchantUsers;
import com.ng.sb.common.model.Subscriber;
import com.ng.sb.common.util.ExceptionUtils;
import com.ng.sb.common.util.UserType;
import com.ng.user.db.IUserDao;
import com.ng.user.logger.UserServiceLogger;
import com.ng.user.utils.UserServiceConstants;

/**
 * @author gopal
 *
 */
@Transactional
@Repository(value="userDao")
public class UserDaoImpl extends BaseDaoImpl implements IUserDao 
{

	public Object getLoginInfo(String loginId, int userTypeId) 
	{
		Object loginInfo = null;
		try{
			
			if(userTypeId == UserType.SUBSCRIBER.getUserTypeId())
			{
				loginInfo = findObjectByNamedQuery("Subscriber.findByAnyId", createMapForQueryParams(
							new String[] { "userId" },
							new Object[] { loginId }), Subscriber.class);
			}
			else if(userTypeId == UserType.AGENT.getUserTypeId())
			{
				loginInfo = findObjectByNamedQuery("AccountLoginInfo.findByAnyId", createMapForQueryParams(
							new String[] { "userId" },
							new Object[] { loginId }), AccountLoginInfo.class);
			}else if(userTypeId == UserType.MERCHANT.getUserTypeId())
			{
				loginInfo = findObjectByNamedQuery("MerchantUsers.findByMobileNumber", createMapForQueryParams(
							new String[] { "mobileNumber" },
							new Object[] { loginId }), MerchantUsers.class);
			}
			
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), UserServiceConstants.PACKAGE_FOR_EXCEPTION);
			
			UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
		}
		
		return loginInfo;
	}

	@Override
	public Subscriber getSubscriberDetailsById(String subscriberId) 
	{
		Subscriber subscriberInfo = null;
		try{
			
			
				subscriberInfo = findObjectByNamedQuery("Subscriber.findById", createMapForQueryParams(
							new String[] { "id" },
							new Object[] { Integer.parseInt(subscriberId) }), Subscriber.class);
			
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), UserServiceConstants.PACKAGE_FOR_EXCEPTION);
			
			UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
		}
		
		return subscriberInfo;
	}

	@Override
	public AccountLoginInfo getAccountDetailsById(String accountId) 
	{
		AccountLoginInfo subscriberInfo = null;
		try{
			
			
				subscriberInfo = findObjectByNamedQuery("AccountLoginInfo.findById", createMapForQueryParams(
							new String[] { "id" },
							new Object[] { Integer.parseInt(accountId) }), AccountLoginInfo.class);
			
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), UserServiceConstants.PACKAGE_FOR_EXCEPTION);
			
			UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
		}
		
		return subscriberInfo;
	}

	@Override
	public List<Menu> getAllActiveMenus() throws Exception 
	{
		List<Menu> menuDetails= new ArrayList<>();
		
		try
		{
			
			menuDetails = (List<Menu>) findByNamedQuery("Menu.findAllActive",new String[] { }, new Object[] {});
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		
		return menuDetails;
	}

	@Override
	public InventoryMgmt getInventoryDetails(String externalNo) 
	{
		InventoryMgmt inventoryDetail = null;
		try{
			
			
				inventoryDetail = findObjectByNamedQuery("InventoryMgmt.findByExternalNo", createMapForQueryParams(
							new String[] { "externalNo" },
							new Object[] { Long.parseLong(externalNo) }), InventoryMgmt.class);
			
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), UserServiceConstants.PACKAGE_FOR_EXCEPTION);
			
			UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
		}
		
		return inventoryDetail;
	}

	@Override
	public CustomerDetails getAccountDeails(String customerId) throws Exception 
	{
		CustomerDetails customerData = null;
		try{
			
			
				customerData = findObjectByNamedQuery("CustomerDetails.findByCustId", createMapForQueryParams(
							new String[] { "customerId" },
							new Object[] { customerId }), CustomerDetails.class);
			
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), UserServiceConstants.PACKAGE_FOR_EXCEPTION);
			
			UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
		}
		
		return customerData;
	}

	@Override
	public Subscriber getSubscriberByCustomerId(String customerId) {
		Subscriber subscriberInfo = null;
		try{
			
			
				subscriberInfo = findObjectByNamedQuery("Subscriber.findByCustId", createMapForQueryParams(
							new String[] { "customerId" },
							new Object[] { customerId }), Subscriber.class);
			
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), UserServiceConstants.PACKAGE_FOR_EXCEPTION);
			
			UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
		}
		
		return subscriberInfo;
	}

	@Override
	public Address getAddressDetailsByPin(String pincode) 
	{
		Address subscriberInfo = null;
		try{
			
			
				subscriberInfo = findObjectByNamedQuery("Address.findByPincode", createMapForQueryParams(
							new String[] { "pincode" },
							new Object[] { pincode }), Address.class);
			
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), UserServiceConstants.PACKAGE_FOR_EXCEPTION);
			
			UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
		}
		
		return subscriberInfo;
	}

	@Override
	public Subscriber getSubscriberDetailsByMsisdn(String msisdn) {
		Subscriber subscriberInfo = null;
		try{
			
			
				subscriberInfo = findObjectByNamedQuery("Subscriber.findByMsisdn", createMapForQueryParams(
							new String[] { "msisdn" },
							new Object[] { msisdn }), Subscriber.class);
			
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), UserServiceConstants.PACKAGE_FOR_EXCEPTION);
			
			UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
		}
		
		return subscriberInfo;
	}

	@Override
	public MerchantInfo getMerchantDetailsByMsisdn(String msisdn) 
	{
		MerchantInfo merchantDetails = null;
		try{
			
			
				merchantDetails = findObjectByNamedQuery("MerchantInfo.findByContactNumber", createMapForQueryParams(
							new String[] { "contactNumber" },
							new Object[] { msisdn }), MerchantInfo.class);
			
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), UserServiceConstants.PACKAGE_FOR_EXCEPTION);
			
			UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
		}
		
		return merchantDetails;
	}
}
