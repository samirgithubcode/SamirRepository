/**
 * 
 */
package com.ng.bridge.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ng.bridge.service.IBankingService;
import com.ng.bridge.service.IPartnerManagementService;
import com.ng.bridge.util.NewConstants;
import com.ng.sb.common.dataobject.BridgeDataObject;
import com.ng.sb.common.exception.BridgeObjectDataException;
import com.ng.sb.common.util.SystemConstant;

/**
 * @author gaurav
 *
 */
@Service(value=SystemConstant.BRIDGE_BANKING_SERVICE)
public class BankingService extends FundTransferMgtService implements IBankingService {

	private static final Logger LOGGER = LoggerFactory.getLogger(BankingService.class);
	
	@Autowired
	IPartnerManagementService partnerManagementService;
	@Override
	public BridgeDataObject fundTransferIMPSToBank(BridgeDataObject bridgeDataObject) {
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge BankingService -  fundTransferIMPSToBank method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in fundTransferIMPSToBank in BankingService:"+ e);
		}
		return null;
	}

	@Override
	public BridgeDataObject fundTransferBankToBank(BridgeDataObject bridgeDataObject) {
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge BankingService -  fundTransferBankToBank method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in fundTransferBankToBank in BankingService:"+ e);
		}
		return null;
	}

	@Override
	public BridgeDataObject fundTransferBankToIMPS(BridgeDataObject bridgeDataObject) {
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge BankingService -  fundTransferBankToIMPS method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in fundTransferBankToIMPS in BankingService:"+ e);
		}
		return null;
	}
	@Override
	public BridgeDataObject fundTransferBankToCC(BridgeDataObject bridgeDataObject) {
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge BankingService -  fundTransferBankToCC method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in fundTransferBankToCC in BankingService:"+ e);
		}
		return null;
	}





	@Override
	public BridgeDataObject fundTransferBankToWallet(BridgeDataObject bridgeDataObject) {
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge BankingService -  fundTransferBankToWallet method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in fundTransferBankToWallet in BankingService:"+ e);
		}
		return null;
	}
	@Override
	public BridgeDataObject fundTransferIMPSToIMPS(BridgeDataObject bridgeDataObject) {
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge BankingService -  fundTransferIMPSToIMPS method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in fundTransferIMPSToIMPS in BankingService:"+ e);
		}
		return null;
	}

	@Override
	public BridgeDataObject fundTransferIMPSToCC(BridgeDataObject bridgeDataObject) {
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge BankingService -  fundTransferIMPSToCC method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in fundTransferIMPSToCC in BankingService:"+ e);
		}
		return null;
	}

	@Override
	public BridgeDataObject fundTransferIMPSToWallet(BridgeDataObject bridgeDataObject) {
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge BankingService -  fundTransferIMPSToWallet method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in fundTransferIMPSToWallet in BankingService:"+ e);
		}
		return null;
	}

	@Override
	public BridgeDataObject cashWithdraw(BridgeDataObject bridgeDataObject) {
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge BankingService -  cashWithdraw method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in cashWithdraw in BankingService:"+ e);
		}
		return null;
	}

	@Override
	public BridgeDataObject moneyTransfer(BridgeDataObject bridgeDataObject) {
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge BankingService -  moneyTransfer method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in moneyTransfer in BankingService:"+ e);
		}
		return null;
	}

	@Override
	public BridgeDataObject fundTransferCCToBank(BridgeDataObject bridgeDataObject) {
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge BankingService -  fundTransferCCToBank method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in fundTransferCCToBank in BankingService:"+ e);
		}
		return null;
	}

	@Override
	public BridgeDataObject fundTransferCCToIMPS(BridgeDataObject bridgeDataObject) {
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge BankingService -  fundTransferCCToIMPS method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in fundTransferCCToIMPS in BankingService:"+ e);
		}
		return null;
	}

	@Override
	public BridgeDataObject fundTransferCCToCC(BridgeDataObject bridgeDataObject) {
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge BankingService -  fundTransferCCToCC method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in fundTransferCCToCC in BankingService:"+ e);
		}
		return null;
	}

	@Override
	public BridgeDataObject fundTransferCCToWallet(BridgeDataObject bridgeDataObject) {
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge BankingService -  fundTransferCCToWallet method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in fundTransferCCToWallet in BankingService:"+ e);
		}
		return null;
	}

	
	
	

	
}
