package com.ng.sb.common.dataobject;

import java.util.Map;

public class AccountTypeData  extends BaseObjectData{
	private static final long serialVersionUID = 1L;
	private String accountType;

	private Map<Integer,String> accountMap;
	private Integer accountTypeId;
	private String menucheckBox;

	private String accountcheckBox;
	private String[] sysAccountGroupArray;
	public String[] getSysAccountGroupArray() {
		return sysAccountGroupArray;
	}

	public void setSysAccountGroupArray(String[] sysAccountGroupArray) {
		this.sysAccountGroupArray = sysAccountGroupArray;
	}
	public String getAccountcheckBox() {
		return accountcheckBox;
	}

	public void setAccountcheckBox(String accountcheckBox) {
		this.accountcheckBox = accountcheckBox;
	}

	
	public String getMenucheckBox() {
		return menucheckBox;
	}

	public void setMenucheckBox(String menucheckBox) {
		this.menucheckBox = menucheckBox;
	}

	
	public Map<Integer, String> getAccountMap() {
		return accountMap;
	}

	public void setAccountMap(Map<Integer, String> accountMap) {
		this.accountMap = accountMap;
	}

	public Integer getAccountTypeId() {
		
		
		return accountTypeId;
	}

	public void setAccountTypeId(Integer accountTypeId) {
		this.accountTypeId = accountTypeId;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	
}
