package com.ng.sb.common.dataobject;

import java.util.Date;
import java.util.List;

import com.ng.sb.common.model.Address;
import com.ng.sb.common.model.KYCDescriptor;

public class SEissuanceResponseData extends PlatformResponseData implements ValidationBean {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	    private Integer mobileCode;
	    private String msisdn;
	    private String parentMSISDN;
	    private String surname;
	    private Date dateOfBirth;
	    private String address;
	    private Address addressId;
	    private String emailId;
	    private Date addDate;
	    private Date editDate;
	    private Integer invalidLPinCount;
	    private Integer invalidTPinCount;
	    private String status;
	    private short kycGiven;
	    private short kycValidated;
	    private KYCDescriptor kycDescriptorId;
		private String subscriberType;
	    private String custId;
	    private String masterVersion;
	    private String hostSubVersion;
	    private Long externalnumber;
	    private List<SEissuanceResponseData> selist;
	    private String productStatus;
	    
	    
	    
	    public String getProductStatus() {
			return productStatus;
		}
		public void setProductStatus(String productStatus) {
			this.productStatus = productStatus;
		}
		public String getMasterVersion() {
			return masterVersion;
		}
		public void setMasterVersion(String masterVersion) {
			this.masterVersion = masterVersion;
		}
		public String getHostSubVersion() {
			return hostSubVersion;
		}
		public void setHostSubVersion(String hostSubVersion) {
			this.hostSubVersion = hostSubVersion;
		}
		public List<SEissuanceResponseData> getSelist() {
			return selist;
		}
		public void setSelist(List<SEissuanceResponseData> selist) {
			this.selist = selist;
		}
	
		public Long getExternalnumber() {
			return externalnumber;
		}
		public void setExternalnumber(Long externalnumber) {
			this.externalnumber = externalnumber;
		}
		
		public Integer getMobileCode() {
			return mobileCode;
		}
		public void setMobileCode(Integer mobileCode) {
			this.mobileCode = mobileCode;
		}
		public String getMsisdn() {
			return msisdn;
		}
		public void setMsisdn(String msisdn) {
			this.msisdn = msisdn;
		}
		public String getParentMSISDN() {
			return parentMSISDN;
		}
		public void setParentMSISDN(String parentMSISDN) {
			this.parentMSISDN = parentMSISDN;
		}
		
		public String getSurname() {
			return surname;
		}
		public void setSurname(String surname) {
			this.surname = surname;
		}
		public Date getDateOfBirth() {
			return dateOfBirth;
		}
		public void setDateOfBirth(Date dateOfBirth) {
			this.dateOfBirth = dateOfBirth;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		public Address getAddressId() {
			return addressId;
		}
		public void setAddressId(Address addressId) {
			this.addressId = addressId;
		}
		public String getEmailId() {
			return emailId;
		}
		public void setEmailId(String emailId) {
			this.emailId = emailId;
		}
		public Date getAddDate() {
			return addDate;
		}
		public void setAddDate(Date addDate) {
			this.addDate = addDate;
		}
		public Date getEditDate() {
			return editDate;
		}
		public void setEditDate(Date editDate) {
			this.editDate = editDate;
		}
		public Integer getInvalidLPinCount() {
			return invalidLPinCount;
		}
		public void setInvalidLPinCount(Integer invalidLPinCount) {
			this.invalidLPinCount = invalidLPinCount;
		}
		public Integer getInvalidTPinCount() {
			return invalidTPinCount;
		}
		public void setInvalidTPinCount(Integer invalidTPinCount) {
			this.invalidTPinCount = invalidTPinCount;
		}
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		public short getKycGiven() {
			return kycGiven;
		}
		public void setKycGiven(short kycGiven) {
			this.kycGiven = kycGiven;
		}
		public short getKycValidated() {
			return kycValidated;
		}
		public void setKycValidated(short kycValidated) {
			this.kycValidated = kycValidated;
		}
		public KYCDescriptor getKycDescriptorId() {
			return kycDescriptorId;
		}
		public void setKycDescriptorId(KYCDescriptor kycDescriptorId) {
			this.kycDescriptorId = kycDescriptorId;
		}
		public String getSubscriberType() {
			return subscriberType;
		}
		public void setSubscriberType(String subscriberType) {
			this.subscriberType = subscriberType;
		}
		public String getCustId() {
			return custId;
		}
		public void setCustId(String custId) {
			this.custId = custId;
		}
		public static long getSerialversionuid() {
			return serialVersionUID;
		}
	
	

}
