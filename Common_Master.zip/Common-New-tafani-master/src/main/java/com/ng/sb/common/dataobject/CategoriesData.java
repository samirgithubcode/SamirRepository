package com.ng.sb.common.dataobject;

import java.util.HashMap;
import java.util.Map;

/**
 * @author abhishek
 *
 */
public class CategoriesData extends  BaseObjectData {

		private static final long serialVersionUID = 1L;
		private Map<ProvidersData, ProvidersData> providersMap = new HashMap<>();
		
		public CategoriesData() {
			//default constructor
		}

		public CategoriesData(Integer id) {
			super.setId(id);
		}

		public Map<ProvidersData, ProvidersData> getProvidersMap() {
			return providersMap;
		}

		public void setProvidersMap(Map<ProvidersData, ProvidersData> providersMap) {
			this.providersMap = providersMap;
		}

		@Override
		public boolean equals(Object obj) {
			if (obj == null) {
				return false;
			}
			if (obj instanceof CategoriesData) {
				
				boolean check=false;
				
				CategoriesData other = (CategoriesData) obj;
				 if (getId() == other.getId()) {
					 check= true;
				}
				return check;
			}
			return super.equals(obj);
		}

		@Override
		public int hashCode() {
			if ( this.getId() != null) {
				return this.getId() * 7 ;
			} else {
				return 0;
			}

		}
}
