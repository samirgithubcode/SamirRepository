/**
 * 
 */
package com.ng.transaction.data;

import com.ng.sb.common.dataobject.ValidationBean;

/**
 * @author gopal
 *
 */
public class BankingData implements ValidationBean {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String ifscCode;
	private String accountNumber;
	private String bPin;
	private int chequeNumber;
	
	private String oldPin;
	private String newPin;
	private String settingPin;
	
	public String getIfscCode() {
		return ifscCode;
	}
	
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}
	
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getbPin() {
		return bPin;
	}
	public void setbPin(String bPin) {
		this.bPin = bPin;
	}

	public int getChequeNumber() {
		return chequeNumber;
	}

	public void setChequeNumber(int chequeNumber) {
		this.chequeNumber = chequeNumber;
	}

	public String getOldPin() {
		return oldPin;
	}

	public void setOldPin(String oldPin) {
		this.oldPin = oldPin;
	}

	public String getNewPin() {
		return newPin;
	}

	public void setNewPin(String newPin) {
		this.newPin = newPin;
	}

	public String getSettingPin() {
		return settingPin;
	}

	public void setSettingPin(String settingPin) {
		this.settingPin = settingPin;
	}
}
