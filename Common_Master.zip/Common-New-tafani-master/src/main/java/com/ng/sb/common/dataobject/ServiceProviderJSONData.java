package com.ng.sb.common.dataobject;

import java.util.HashMap;
import java.util.Map;

public class ServiceProviderJSONData {
	private Integer serviceId;
	private Long categoryId;
	Map<Integer, Integer> providerMap = new HashMap<>();
	Map<Integer,String> providerMapFsp = new HashMap<>();

	public Integer getServiceId() {
		return serviceId;
	}

	public void setServiceId(Integer serviceId) {
		this.serviceId = serviceId;
	}

	public Long getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(Long categoryId) {
		this.categoryId = categoryId;
	}

	public Map<Integer, Integer> getProviderMap() {
		return providerMap;
	}

	public void setProviderMap(Map<Integer, Integer> providerMap) {
		this.providerMap = providerMap;
	}

	public Map<Integer, String> getProviderMapFsp() {
		return providerMapFsp;
	}

	public void setProviderMapFsp(Map<Integer, String> providerMapFsp) {
		this.providerMapFsp = providerMapFsp;
	}


}
