package com.ng.sb.common.dataobject;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.web.multipart.MultipartFile;

import com.ng.sb.common.model.MerchantKyc;

/**
 * @author abhishek
 *
 */

public class MerchantData {

	private static final long serialVersionUID = 1L;
	private String contactPersonName;
	private String merchantCompanyName;
	private Integer companyId;
	private String lattitude;
	private String merchantType;
	private String houseNumber;
	private String city;
	private String branch;
	private String bankName;
	private String comment;
	private Integer userId;
	private String landmark;
	private String bankAddress;
	private String merchantCategoryId;
	private Map<String, String> merchants;
	private Map<Integer, String> countries;
	private Map<Integer, String> states;
	private Integer pin;
	private int noOfTill;
	private String[] tillIp;
	private String[] tillNames;
	private String[] tillName;
	private String[] tillDesc;
	private List<KYCUpgradeData> idproofs;
	private Map<Integer,String> businessIdProofs;
	private String region;
	private String address;
	private String addressTwo;
	private String  parentMerchantId;
	private Integer pinaddressId;
	private Integer pinCode;
	private String locality;
	private String district;
	private Integer state;
	private Integer country;
	private String email;
	private String mobileNumber;
	private String loginPin;
	private String invoice;
	private String statess;
	private String countrys;
	private String randomNo;
	private List<TillDescription> tillDescriptions;
	private String[] tillIps;
	private Integer under;
	private String dob;
	private boolean merchantStatus;
	private Map<Integer, String> corporateMerchants;
	private Integer corporateMerchant;
	private String merchantStyle;
	private String status;
	private Boolean hostDiCheck;
	private String underType;
	private String underName;
	private String encryptionKey;
	private String financialInstrument;
	private String walletName;
	private Map<Integer,String> wallets;
	private String contactNumber;
	private Integer[] walletIds;
	private Integer[] tillCheck;
	private Integer[] merchantIpIds;
	private Integer[] tillChecks;
	private Map<String,String> mapData;
	private Map<String,String> oldTils;
	private String merchantCategory;
	private Integer counterType;
	private String currencyCode;
	private String url;
	private Integer id;
	private Integer refmerchantInfoId;
	private String deviceTpye;
	private String externalNo;
	private String inetrnalNo;
	private String addedOn;
	private String modifiedDate;
	private Date addedBy;
	private Integer merchantNumber;
	private  MultipartFile  uploadFilePath;
	private String valid;
	private Integer invalid;
	private Integer records;
	private String accountNumber;
	private String ifscCode;
	private String parameterName;
	private Integer value;
	private Set setting;
	private String accountType;
	private String check;
	private String radio;
	private boolean marchantStatus;
	private String approve;
	private List<MerchantKyc> merchantKycDetails;
	private List<KYCDescriptorData> descriptorDatas;
	private List<MerchantKycDto> kyc;
	private List<MerchantSetting> settingDto;
	private Integer[] idProofCheck;
	private Integer[] businessIdProofCheck;
	private String [] idName;
	private String [] idNo;
	private String [] startDate;
	private String [] endDate;
	private String merchantId;
	private String longitude;
	private String latitude;
	private String  type;
	private List<InventoryDto> inventoryDto;
	private String licenseEdit;
	private String name;
	private String mobilenumber;
	private String GstOrVat;
	private String tinno;
	private String merchantName;
	private String establishednoOrlicenseno;
	private Date validfrom;
	private  MultipartFile[] file;
	private  MultipartFile[] businessFile;
	private Date validto;
	private String [] personalStartDate;
	private String [] personalEndDate;
	private String [] personalKycIds;
	private String merchantPassword;
	private List<MerchantData> outletList;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobilenumber() {
		return mobilenumber;
	}
	public void setMobilenumber(String mobilenumber) {
		this.mobilenumber = mobilenumber;
	}
	public String getGstOrVat() {
		return GstOrVat;
	}
	public void setGstOrVat(String gstOrVat) {
		GstOrVat = gstOrVat;
	}
	public String getTinno() {
		return tinno;
	}
	public void setTinno(String tinno) {
		this.tinno = tinno;
	}
	public String getEstablishednoOrlicenseno() {
		return establishednoOrlicenseno;
	}
	public void setEstablishednoOrlicenseno(String establishednoOrlicenseno) {
		this.establishednoOrlicenseno = establishednoOrlicenseno;
	}
	public Date getValidfrom() {
		return validfrom;
	}
	public void setValidfrom(Date validfrom) {
		this.validfrom = validfrom;
	}
	public Date getValidto() {
		return validto;
	}
	public void setValidto(Date validto) {
		this.validto = validto;
	}

	
	public String getLicenseEdit() {
		return licenseEdit;
	}
	public void setLicenseEdit(String licenseEdit) {
		this.licenseEdit = licenseEdit;
	}
	public List<InventoryDto> getInventoryDto() {
		return inventoryDto;
	}
	public void setInventoryDto(List<InventoryDto> inventoryDto) {
		this.inventoryDto = inventoryDto;
	}
	public List<KYCDescriptorData> getDescriptorDatas() {
		return descriptorDatas;
	}
	public String getMerchantCategoryId() {
		return merchantCategoryId;
	}


	public void setMerchantCategoryId(String merchantCategoryId) {
		this.merchantCategoryId = merchantCategoryId;
	}




	public List<MerchantKycDto> getKyc() {
		return kyc;
	}


	public void setKyc(List<MerchantKycDto> kyc) {
		this.kyc = kyc;
	}


	public List<MerchantSetting> getSettingDto() {
		return settingDto;
	}


	public void setSettingDto(List<MerchantSetting> settingDto) {
		this.settingDto = settingDto;
	}


	public void setDescriptorDatas(List<KYCDescriptorData> descriptorDatas) {
		this.descriptorDatas = descriptorDatas;
	}


	public List<MerchantKyc> getMerchantKycDetails() {
		return merchantKycDetails;
	}


	public void setMerchantKycDetails(List<MerchantKyc> merchantKycDetails) {
		this.merchantKycDetails = merchantKycDetails;
	}
	
	public String getRadio() {
		return radio;
	}

	
	public void setRadio(String radio) {
		this.radio = radio;
	}

	
	public MultipartFile[] getFile() {
		return file;
	}

	public void setFile(MultipartFile[] file) {
		this.file = file;
	}

	public Integer[] getIdProofCheck() {
		return idProofCheck;
	}

	public void setIdProofCheck(Integer[] idProofCheck) {
		this.idProofCheck = idProofCheck;
	}


	public Set getSetting() {
		return setting;
	}

	public void setSetting(Set setting) {
		this.setting = setting;
	}

	public String getCheck() {
		return check;
	}

	public void setCheck(String check) {
		this.check = check;
	}

	public String getParameterName() {
		return parameterName;
	}

	public void setParameterName(String parameterName) {
		this.parameterName = parameterName;
	}

	public Integer getValue() {
		return value;
	}

	public void setValue(Integer value) {
		this.value = value;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getIfscCode() {
		return ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	public String getValid() {
		return valid;
	}

	public void setValid(String valid) {
		this.valid = valid;
	}

	public Integer getInvalid() {
		return invalid;
	}

	public void setInvalid(Integer invalid) {
		this.invalid = invalid;
	}

	public Integer getRecords() {
		return records;
	}

	public void setRecords(Integer records) {
		this.records = records;
	}

	public MultipartFile getUploadFilePath() {
		return uploadFilePath;
	}

	public void setUploadFilePath(MultipartFile uploadFilePath) {
		this.uploadFilePath = uploadFilePath;
	}

	public Integer getMerchantNumber() {
		return merchantNumber;
	}

	public void setMerchantNumber(Integer merchantNumber) {
		this.merchantNumber = merchantNumber;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getRefmerchantInfoId() {
		return refmerchantInfoId;
	}

	public void setRefmerchantInfoId(Integer refmerchantInfoId) {
		this.refmerchantInfoId = refmerchantInfoId;
	}

	public String getDeviceTpye() {
		return deviceTpye;
	}

	public void setDeviceTpye(String deviceTpye) {
		this.deviceTpye = deviceTpye;
	}

	public String getExternalNo() {
		return externalNo;
	}

	public void setExternalNo(String externalNo) {
		this.externalNo = externalNo;
	}

	public String getInetrnalNo() {
		return inetrnalNo;
	}

	public void setInetrnalNo(String inetrnalNo) {
		this.inetrnalNo = inetrnalNo;
	}

	public String getAddedOn() {
		return addedOn;
	}

	public void setAddedOn(String addedOn) {
		this.addedOn = addedOn;
	}

	public Date getAddedBy() {
		return addedBy;
	}

	public void setAddedBy(Date addedBy) {
		this.addedBy = addedBy;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public Integer getCounterType() {
		return counterType;
	}

	public void setCounterType(Integer counterType) {
		this.counterType = counterType;
	}

	public String getMerchantCategory() {
		return merchantCategory;
	}

	public String getParentMerchantId() {
		return parentMerchantId;
	}


	public void setParentMerchantId(String parentMerchantId) {
		this.parentMerchantId = parentMerchantId;
	}


	public String getLoginPin() {
		return loginPin;
	}


	public void setLoginPin(String loginPin) {
		this.loginPin = loginPin;
	}


	public String getInvoice() {
		return invoice;
	}


	public void setInvoice(String invoice) {
		this.invoice = invoice;
	}


	public String getAccountType() {
		return accountType;
	}


	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}


	public void setMerchantCategory(String merchantCategory) {
		this.merchantCategory = merchantCategory;
	}

	
	
	
	public String getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

	public String getStatess() {
		return statess;
	}

	public void setStatess(String statess) {
		this.statess = statess;
	}

	public String getCountrys() {
		return countrys;
	}

	public void setCountrys(String countrys) {
		this.countrys = countrys;
	}

	
	public Integer getPinaddressId() {
		return pinaddressId;
	}

	public void setPinaddressId(Integer pinaddressId) {
		this.pinaddressId = pinaddressId;
	}

	public Integer getPinCode() {
		return pinCode;
	}

	public void setPinCode(Integer pinCode) {
		this.pinCode = pinCode;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getAddressTwo() {
		return addressTwo;
	}

	public void setAddressTwo(String addressTwo) {
		this.addressTwo = addressTwo;
	}

	public String getLocality() {
		return locality;
	}

	public void setLocality(String locality) {
		this.locality = locality;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}



	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public Integer getCountry() {
		return country;
	}

	public void setCountry(Integer country) {
		this.country = country;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	
	
	public String[] getTillNames() {
		return tillNames;
	}

	public void setTillNames(String[] tillNames) {
		this.tillNames = tillNames;
	}



	public List<TillDescription> getTillDescriptions() {
		return tillDescriptions;
	}
	public void setTillDescriptions(List<TillDescription> tillDescriptions) {
		this.tillDescriptions = tillDescriptions;
	}
	public String[] getTillIps() {
		return tillIps;
	}

	public void setTillIps(String[] tillIps) {
		this.tillIps = tillIps;
	}

	
	
	public Integer[] getTillChecks() {
		return tillChecks;
	}

	public void setTillChecks(Integer[] tillChecks) {
		this.tillChecks = tillChecks;
	}

	public Integer[] getMerchantIpIds() {
		return merchantIpIds;
	}

	public void setMerchantIpIds(Integer[] merchantIpIds) {
		this.merchantIpIds = merchantIpIds;
	}

	public Integer[] getTillCheck() {
		return tillCheck;
	}

	public void setTillCheck(Integer[] tillCheck) {
		this.tillCheck = tillCheck;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getWalletName() {
		return walletName;
	}

	public void setWalletName(String walletName) {
		this.walletName = walletName;
	}

	public String getFinancialInstrument() {
		return financialInstrument;
	}

	public void setFinancialInstrument(String financialInstrument) {
		this.financialInstrument = financialInstrument;
	}

	public String getUnderType() {
		return underType;
	}

	public void setUnderType(String underType) {
		this.underType = underType;
	}

	public String getMerchantCompanyName() {
		return merchantCompanyName;
	}

	public void setMerchantCompanyName(String merchantCompanyName) {
		this.merchantCompanyName = merchantCompanyName;
	}

	public String getMerchantType() {
		return merchantType;
	}

	public void setMerchantType(String merchantType) {
		this.merchantType = merchantType;
	}

	public String getHouseNumber() {
		return houseNumber;
	}

	public void setHouseNumber(String houseNumber) {
		this.houseNumber = houseNumber;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getLandmark() {
		return landmark;
	}

	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}

	

	
	
	public Map<Integer, String> getCountries() {
		return countries;
	}

	public void setCountries(Map<Integer, String> countries) {
		this.countries = countries;
	}

	public Map<Integer, String> getStates() {
		return states;
	}

	public void setStates(Map<Integer, String> states) {
		this.states = states;
	}

	public Integer getPin() {
		return pin;
	}

	public void setPin(Integer pin) {
		this.pin = pin;
	}

	public int getNoOfTill() {
		return noOfTill;
	}

	public void setNoOfTill(int noOfTill) {
		this.noOfTill = noOfTill;
	}

	public Integer getUnder() {
		return under;
	}

	public Integer getCorporateMerchant() {
		return corporateMerchant;
	}

	public void setCorporateMerchant(Integer corporateMerchant) {
		this.corporateMerchant = corporateMerchant;
	}

	public String getUnderName() {
		return underName;
	}

	public void setUnderName(String underName) {
		this.underName = underName;
	}

	public void setUnder(Integer under) {
		this.under = under;
	}

	public Map<Integer, String> getCorporateMerchants() {
		return corporateMerchants;
	}

	public void setCorporateMerchants(Map<Integer, String> corporateMerchants) {
		this.corporateMerchants = corporateMerchants;
	}

	public String getMerchantStyle() {
		return merchantStyle;
	}

	public void setMerchantStyle(String merchantStyle) {
		this.merchantStyle = merchantStyle;
	}
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	public Boolean getHostDiCheck() {
		return hostDiCheck;
	}

	public void setHostDiCheck(Boolean hostDiCheck) {
		this.hostDiCheck = hostDiCheck;
	}

	public String getEncryptionKey() {
		return encryptionKey;
	}

	public void setEncryptionKey(String encryptionKey) {
		this.encryptionKey = encryptionKey;
	}

	public void setWallets(Map<Integer,String> wallets) {
		this.wallets = wallets;
	}
	
	public Map<Integer,String> getWallets() {
		return wallets;
	}

	public Integer[] getWalletIds() {
		return walletIds;
	}

	public void setWalletIds(Integer[] walletIds) {
		this.walletIds = walletIds;
	}

	public String[] getTillIp() {
		return tillIp;
	}

	public void setTillIp(String[] tillIp) {
		this.tillIp = tillIp;
	}

	public Map<String, String> getMapData() {
		return mapData;
	}

	public void setMapData(Map<String, String> mapData) {
		this.mapData = mapData;
	}

	public Map<String, String> getOldTils() {
		return oldTils;
	}

	public void setOldTils(Map<String, String> oldTils) {
		this.oldTils = oldTils;
	}

	/**
	 * @return the idNo
	 */
	public String [] getIdNo() {
		return idNo;
	}

	public String  getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	/**
	 * @param idNo the idNo to set
	 */
	public void setIdNo(String [] idNo) {
		this.idNo = idNo;
	}
	public String getLattitude() {
		return lattitude;
	}
	public void setLattitude(String lattitude) {
		this.lattitude = lattitude;
	}
	public String[] getTillName() {
		return tillName;
	}
	public void setTillName(String[] tillName) {
		this.tillName = tillName;
	}
	/*public List<TillDecription> getTillDesc() {
		return tillDesc;
	}
	public void setTillDesc(List<TillDecription> tillDesc) {
		this.tillDesc = tillDesc;
	}*/
	public String[] getTillDesc() {
		return tillDesc;
	}
	public void setTillDesc(String[] tillDesc) {
		this.tillDesc = tillDesc;
	}
	public String getContactPersonName() {
		return contactPersonName;
	}
	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}
	public Integer[] getBusinessIdProofCheck() {
		return businessIdProofCheck;
	}
	public void setBusinessIdProofCheck(Integer[] businessIdProofCheck) {
		this.businessIdProofCheck = businessIdProofCheck;
	}
	public String[] getIdName() {
		return idName;
	}
	public void setIdName(String[] idName) {
		this.idName = idName;
	}
	public MultipartFile[] getBusinessFile() {
		return businessFile;
	}
	public void setBusinessFile(MultipartFile[] businessFile) {
		this.businessFile = businessFile;
	}
	public String[] getStartDate() {
		return startDate;
	}
	public void setStartDate(String[] startDate) {
		this.startDate = startDate;
	}
	public String[] getEndDate() {
		return endDate;
	}
	public void setEndDate(String[] endDate) {
		this.endDate = endDate;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getRandomNo() {
		return randomNo;
	}
	public void setRandomNo(String randomNo) {
		this.randomNo = randomNo;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getMerchantName() {
		return merchantName;
	}
	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}
	public String getMerchantPassword() {
		return merchantPassword;
	}
	public void setMerchantPassword(String merchantPassword) {
		this.merchantPassword = merchantPassword;
	}
	public boolean isMarchantStatus() {
		return marchantStatus;
	}
	public void setMarchantStatus(boolean marchantStatus) {
		this.marchantStatus = marchantStatus;
	}
	public boolean isMerchantStatus() {
		return merchantStatus;
	}
	public void setMerchantStatus(boolean merchantStatus) {
		this.merchantStatus = merchantStatus;
	}
	public Integer getCompanyId() {
		return companyId;
	}
	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getBankAddress() {
		return bankAddress;
	}
	public void setBankAddress(String bankAddress) {
		this.bankAddress = bankAddress;
	}
	public List<KYCUpgradeData> getIdproofs() {
		return idproofs;
	}
	public void setIdproofs(List<KYCUpgradeData> idproofs) {
		this.idproofs = idproofs;
	}
	public Map<Integer, String> getBusinessIdProofs() {
		return businessIdProofs;
	}
	public void setBusinessIdProofs(Map<Integer, String> businessIdProofs) {
		this.businessIdProofs = businessIdProofs;
	}
	public String[] getPersonalStartDate() {
		return personalStartDate;
	}
	public void setPersonalStartDate(String[] personalStartDate) {
		this.personalStartDate = personalStartDate;
	}
	public String[] getPersonalEndDate() {
		return personalEndDate;
	}
	public void setPersonalEndDate(String[] personalEndDate) {
		this.personalEndDate = personalEndDate;
	}
	public String[] getPersonalKycIds() {
		return personalKycIds;
	}
	public void setPersonalKycIds(String[] personalKycIds) {
		this.personalKycIds = personalKycIds;
	}
	public Map<String, String> getMerchants() {
		return merchants;
	}
	public void setMerchants(Map<String, String> merchants) {
		this.merchants = merchants;
	}
	public List<MerchantData> getOutletList() {
		return outletList;
	}
	public void setOutletList(List<MerchantData> outletList) {
		this.outletList = outletList;
	}
	public String getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getApprove() {
		return approve;
	}
	public void setApprove(String approve) {
		this.approve = approve;
	}
	
	
	
	
}
