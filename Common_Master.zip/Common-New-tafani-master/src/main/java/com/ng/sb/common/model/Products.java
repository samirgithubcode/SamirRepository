/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Collection;

import javax.persistence.*;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author amardeep
 */
@Entity
@Table(name = "Products")
@XmlRootElement
@NamedQueries({
	 @NamedQuery(name = "Products.findAll", query = "SELECT p FROM Products p"),
    @NamedQuery(name = "Products.findById", query = "SELECT p FROM Products p WHERE p.id = :id"),
    @NamedQuery(name = "Products.findByCode", query = "SELECT p FROM Products p WHERE p.code = :code"),
    @NamedQuery(name = "Products.findByName", query = "SELECT p FROM Products p WHERE p.productName = :name"),
    @NamedQuery(name = "Products.findIdByName", query = "SELECT p.id FROM Products p WHERE p.productName = :name"),
    @NamedQuery(name = "Products.findByType", query = "SELECT p FROM Products p WHERE p.type = :type"),
    @NamedQuery(name = "Products.findByImage1", query = "SELECT p FROM Products p WHERE p.image = :image1"),
    @NamedQuery(name = "Products.findMaxProductCode", query = "SELECT MAX(s.code) FROM Products s"),
    @NamedQuery(name = "Products.findCodeById", query = "SELECT p FROM Products p WHERE p.id = :productId"),
    @NamedQuery(name = "Products.countbyproductName", query = "SELECT count(*) FROM Products p WHERE p.productName =:productName"),
    @NamedQuery(name = "Products.countbyNameandId", query = "SELECT count(*) FROM Products p WHERE p.productName =:productName and p.id =:id"),
    @NamedQuery(name = "Products.findIdbycode", query = "SELECT p FROM Products p WHERE p.code =:code"),
    @NamedQuery(name = "Products.findByCommission", query = "SELECT p FROM Products p WHERE p.commissionRequired =:commissionRequired"),
    @NamedQuery(name = "Products.findUniqueProductList", query = "SELECT p FROM Products p GROUP BY p.type"),
    @NamedQuery(name = "Products.findProductsByTypes", query = "SELECT p FROM Products p where p.type IN (:productType)"),
  
    
})
public class Products implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "type")
    private String type;
    @Basic(optional = false)
    @Column(name = "productName")
    private String productName;
	@Basic(optional = false)
	@Column(name = "description")
	private String description;
	@Basic(optional = false)
	@Column(name="code")
	private String code;
	@Basic(optional = false)
	@Column(name="image")
	private String image;
	@Basic(optional = false)
	@Column(name="isCommissionable")
	private Integer commissionRequired;
	@Column(name="uniqueProductCode")
	private String uniqueProductCode;
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "productId")
    private Collection<InventorySummary> inventorySummaryCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "productId")
    private Collection<InventoryMgmt> inventoryMgmtCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "productId")
    private Collection<ProductInventorySummary> productInventorySummaryCollection;
    @OneToMany(mappedBy = "productId")
    private Collection<InventoryOrder> inventoryOrderCollection;
   
    @OneToMany(mappedBy = "productId")
    private Collection<InventoryOrderHistory> inventoryOrderHistoryCollection;
    @OneToMany(mappedBy = "productId")
    private Collection<Inventory> inventoryCollection;
    
    @OneToMany(mappedBy = "productId")
    private Collection<PayCardApps> payCardApp;
    
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "productId")
    private Collection<CardDetails> cardDetails;
    
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "productId")
    private Collection<CardApps> cardApps;
	public Products() {
    	//empty
    }

    public Products(Integer id) {
        this.id = id;
    }

    public Products(Integer id, String productName, String type,String code) {
        this.id = id;
        this.productName = productName;
        this.type = type;
        this.code = code;
    }

    public Products(String productVersionName) {
    	 this.productName = productVersionName;
	}
    public Collection<PayCardApps> getPayCardApp() {
		return payCardApp;
	}

	public void setPayCardApp(Collection<PayCardApps> payCardApp) {
		this.payCardApp = payCardApp;
	}
	public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getCommissionRequired() {
		return commissionRequired;
	}

	public void setCommissionRequired(Integer commissionRequired) {
		this.commissionRequired = commissionRequired;
	}

	public Collection<CardDetails> getCardDetails() {
		return cardDetails;
	}

	public void setCardDetails(Collection<CardDetails> cardDetails) {
		this.cardDetails = cardDetails;
	}

	public Collection<CardApps> getCardApps() {
		return cardApps;
	}

	public void setCardApps(Collection<CardApps> cardApps) {
		this.cardApps = cardApps;
	}

	public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

    public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	@XmlTransient
    public Collection<InventorySummary> getInventorySummaryCollection() {
        return inventorySummaryCollection;
    }

    public void setInventorySummaryCollection(Collection<InventorySummary> inventorySummaryCollection) {
        this.inventorySummaryCollection = inventorySummaryCollection;
    }

    @XmlTransient
    public Collection<InventoryMgmt> getInventoryMgmtCollection() {
        return inventoryMgmtCollection;
    }

    public void setInventoryMgmtCollection(Collection<InventoryMgmt> inventoryMgmtCollection) {
        this.inventoryMgmtCollection = inventoryMgmtCollection;
    }

    @XmlTransient
    public Collection<ProductInventorySummary> getProductInventorySummaryCollection() {
        return productInventorySummaryCollection;
    }

    public void setProductInventorySummaryCollection(Collection<ProductInventorySummary> productInventorySummaryCollection) {
        this.productInventorySummaryCollection = productInventorySummaryCollection;
    }

    @XmlTransient
    public Collection<InventoryOrder> getInventoryOrderCollection() {
        return inventoryOrderCollection;
    }

    public void setInventoryOrderCollection(Collection<InventoryOrder> inventoryOrderCollection) {
        this.inventoryOrderCollection = inventoryOrderCollection;
    }

    

    @XmlTransient
    public Collection<InventoryOrderHistory> getInventoryOrderHistoryCollection() {
        return inventoryOrderHistoryCollection;
    }

    public void setInventoryOrderHistoryCollection(Collection<InventoryOrderHistory> inventoryOrderHistoryCollection) {
        this.inventoryOrderHistoryCollection = inventoryOrderHistoryCollection;
    }

    @XmlTransient
    public Collection<Inventory> getInventoryCollection() {
        return inventoryCollection;
    }

    public void setInventoryCollection(Collection<Inventory> inventoryCollection) {
        this.inventoryCollection = inventoryCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof Products)) {
            return false;
        }
        Products other = (Products) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.Products[ id=" + id + " ]";
    }

	public String getUniqueProductCode() {
		return uniqueProductCode;
	}

	public void setUniqueProductCode(String uniqueProductCode) {
		this.uniqueProductCode = uniqueProductCode;
	}
    
}
