package com.ng.sb.common.dataobject;

import java.sql.Date;
import java.util.List;

public class TokenData {
	private String[] sysAccountGroupArray;
	private String name;
	private Integer Id;
	private String productType;
	private Integer status;
	private Date addedOn;
	private String addedBy;
	private String modifiedBy;
	private Date modifiedOn;
	private Integer count;
	private Integer priority;
	private String tokenString;
	/**
	 * @return the tokenString
	 */
	public String getTokenString() {
		return tokenString;
	}

	/**
	 * @param tokenString the tokenString to set
	 */
	public void setTokenString(String tokenString) {
		this.tokenString = tokenString;
	}

	public Integer getPriority() {
		return priority;
	}

	public void setPriority(Integer priority) {
		this.priority = priority;
	}

	public Integer getCount() {
		return count;
	}

	public void setCount(Integer count) {
		this.count = count;
	}

	List<TokenData> data;

	public List<TokenData> getData() {
		return data;
	}

	public void setData(List<TokenData> data) {
		this.data = data;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getId() {
		return Id;
	}

	public void setId(Integer id) {
		Id = id;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Date getAddedOn() {
		return addedOn;
	}

	public void setAddedOn(Date addedOn) {
		this.addedOn = addedOn;
	}

	public String getAddedBy() {
		return addedBy;
	}

	public void setAddedBy(String addedBy) {
		this.addedBy = addedBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public String[] getSysAccountGroupArray() {
		return sysAccountGroupArray;
	}

	public void setSysAccountGroupArray(String[] sysAccountGroupArray) {
		this.sysAccountGroupArray = sysAccountGroupArray;
	}
}
