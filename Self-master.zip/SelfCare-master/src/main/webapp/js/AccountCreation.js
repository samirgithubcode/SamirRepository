/**
 * 
 */
var fflag=true;
var kflag=true;
var completecheck=true;

function selectType(event)
{
	$("#SearchByAutoSearch").hide();
	$("#SearchByTable").hide();
	$("#header").hide();
	$("#host").hide();
	$("#host1").hide();
	$("#host2").hide();
	$("#hostRowId").hide();
	$("#header1").hide();
	$("#hostId").val('');
	$("#vendorId").val('');
	$("#hostErrorId").html('');
	
var sel= $("#Select_type").val();
 
if(sel=='HOST')
	{
	$("#hostRowId").show();
	$("#host").show();
	$("#host1").show();
	$("#host2").show();
	
	$("#vendor1").hide();
	$("#vendor").hide();
	$("#vendor2").hide();
	$("#table_id").hide();
	$("#header1").hide();
	
	}
if(sel=='VENDOR')
	{
	$("#hostRowId").show();
	$("#vendor1").show();
	$("#vendor").show();
	$("#vendor2").show();
	$("#table_id").hide();
	$("#header1").hide();
	$("#vendorId").show();
	}
if(sel=='0')
	{
	$("Select_type").show();
	$("#hostRowId").show();
	$("#vendorId").hide();
	$("#vendor").hide();
	$("#vendor1").hide();
	$("#vendor2").hide();
	$("#table_id").hide();
	}



}

function hideSearchBy()
{
	$("#SearchByTable").hide();
	$("#SearchByAutoSearch").hide();
	$("#table_id").hide();
	$("input[name=radioGroup]").attr('checked', false);
	$("input:radio").removeAttr("checked");
	$("#email").val('');
	$("#mobile").val('');
	$("#userName").val('');
	
	
	
	
	}


function checkEcryption(event,encryptionKeyErrorId)
{
	var name = $("#encryptionKeyId").val();
	var completeCheck=true;
	$.ajax({
		url: 'encryptionKey',
		type:'POST',
		data:'encryptionKeyId='+encryptionKey,
		success:function(response)
		{
			if(response==0)
			{
			
				$('#encryptionKeyErrorId').html("<font color='green'><b>Name Available!!</b></font>");
				completeCheck = true;
			}else
			{
				$('#encryptionKeyErrorId').html("<font color='red'><b> Name already exists!!</b></font>");
				$('#encryptionKeyId').val('');
				completeCheck = false;
			}
		}
	});


}






function validateAccountType(){
	
	if($("#accountTypeId").val()==''){
		$('#accountErrorCode').html("<b><font color='red'>Select account type.</font></b>");
		return false;
	}
}


function addMore(tableId){
	var hiddenAccountNo=parseInt($("#hiddenAccountNo").val())+1; 
	var table=document.getElementById(tableId);
	var tr=table.insertRow();
	tr.setAttribute("id","row"+hiddenAccountNo);
	
	//========== name ============
	var td=tr.insertCell();
	var input=document.createElement('input');
	input.setAttribute("id","name"+hiddenAccountNo);
	input.setAttribute("name","nameArr");
	input.setAttribute("type","text");
	input.setAttribute("placeholder","Enter name");
	input.setAttribute("style","width:100px;");
	input.setAttribute("onfocus","emptyerror(event,'nameErrorId"+hiddenAccountNo+"')");
	td.appendChild(input);
	tr.appendChild(td);
	
	//========== email ============
	var td=tr.insertCell();
	var input=document.createElement('input');
	input.setAttribute("id","email"+hiddenAccountNo);
	input.setAttribute("name","emailArr");
	input.setAttribute("type","text");
	input.setAttribute("placeholder","Enter email");
	input.setAttribute("style","width:100px;");
	input.setAttribute("onfocus","emptyerror(event,'emailErrorId"+hiddenAccountNo+"')");
	td.appendChild(input);
	tr.appendChild(td);
	
	//========== mobile ============
	var td=tr.insertCell();
	var input=document.createElement('input');
	input.setAttribute("id","mobile"+hiddenAccountNo);
	input.setAttribute("name","mobileArr");
	input.setAttribute("type","text");
	input.setAttribute("placeholder","Enter mobile");
	input.setAttribute("style","width:100px;");
	input.setAttribute("maxlength","10");
	input.setAttribute("onfocus","emptyerror(event,'mobileErrorId"+hiddenAccountNo+"')");
	input.setAttribute("onchange","checkDuplicateMobile(this.id)");
	td.appendChild(input);
	tr.appendChild(td);
	
	//========== login name ============
	var td=tr.insertCell();
	var input=document.createElement('input');
	input.setAttribute("id","loginName"+hiddenAccountNo);
	input.setAttribute("name","loginNameArr");
	input.setAttribute("type","text");
	input.setAttribute("placeholder","Enter login name");
	input.setAttribute("style","width:100px;");
	input.setAttribute("onfocus","emptyerror(event,'loginNameErrorId"+hiddenAccountNo+"')");
	input.setAttribute("onchange","checkDuplicateLoginName(this.id)");
	td.appendChild(input);
	tr.appendChild(td);
	
	//========== password ============
	var td=tr.insertCell();
	var input=document.createElement('input');
	input.setAttribute("id","password"+hiddenAccountNo);
	input.setAttribute("name","passwordArr");
	input.setAttribute("type","password");
	input.setAttribute("placeholder","Enter password");
	input.setAttribute("style","width:100px;");
	input.setAttribute("onfocus","emptyerror(event,'passwordErrorId"+hiddenAccountNo+"')");
	td.appendChild(input);
	tr.appendChild(td);
	
	//=========== status =============
	var td=tr.insertCell();
	var select=document.createElement('select');
	select.setAttribute("id","status"+hiddenAccountNo);
	select.setAttribute("name","statusArr");
	select.setAttribute("style","width:100px;");
	
	select.options[select.options.length] = new Option("Unblocked","0");
	select.options[select.options.length] = new Option("Blocked","1");
	
	td.appendChild(select);
	tr.appendChild(td);
	
	
	//=========== account Type =============
	var td=tr.insertCell();
	var select=document.createElement('select');
	select.setAttribute("id","accountType"+hiddenAccountNo);
	select.setAttribute("name","accountTypeArr");
	select.setAttribute("style","width:150px;");
	
	td.appendChild(select);
	tr.appendChild(td);
	
	//========== remove button ============
	var td=tr.insertCell();
	var input=document.createElement('input');
	input.setAttribute("id","removeBtn"+hiddenAccountNo);
	input.setAttribute("value","Remove");
	input.setAttribute("type","button");
	input.setAttribute("onclick","removeRow('row"+hiddenAccountNo+"')");
	td.appendChild(input);
	tr.appendChild(td);
	
	table.appendChild(tr);
	
	var tr=table.insertRow();
	var errorRow="erow"+hiddenAccountNo;
	tr.setAttribute("id",errorRow);
	
	var td=tr.insertCell();
	var lab=document.createElement('label');
	lab.setAttribute("id","nameErrorId"+hiddenAccountNo);
	td.appendChild(lab);
	tr.appendChild(td);
	
	var td=tr.insertCell();
	var lab=document.createElement('label');
	lab.setAttribute("id","emailErrorId"+hiddenAccountNo);
	td.appendChild(lab);
	tr.appendChild(td);
	
	var td=tr.insertCell();
	var lab=document.createElement('label');
	lab.setAttribute("id","mobileErrorId"+hiddenAccountNo);
	td.appendChild(lab);
	tr.appendChild(td);
	
	var td=tr.insertCell();
	var lab=document.createElement('label');
	lab.setAttribute("id","loginNameErrorId"+hiddenAccountNo);
	td.appendChild(lab);
	tr.appendChild(td);
	
	var td=tr.insertCell();
	var lab=document.createElement('label');
	lab.setAttribute("id","passwordErrorId"+hiddenAccountNo);
	td.appendChild(lab);
	tr.appendChild(td);
	
	table.appendChild(tr);
	$('#accountType2 option').clone().appendTo('#accountType'+hiddenAccountNo); // copy first dropdown option in another
	$("#hiddenAccountNo").val(hiddenAccountNo);
}

function removeRow(rowId){
	$("#"+rowId).remove();
	$("#e"+rowId).remove();
	
}
//function emptyStates(){
//	var countryId=$("#"+countryId).text();
//}

function getStates(countryId,stateId){
	var countryId=$("#"+countryId).val();
	if(countryId.length==0){
		return false;
	}
	if(countryId=="0")
		{
		
		 $('#'+stateId).find('option:not(:first)').remove();
		
		}
	 //========== ajax call ==============
	 $.ajax({
		  url: 'getStates',
		  type: 'POST',
		  data: 'countryId='+countryId,
		  success: function(data) {
			  obj=data.stateMap;
			  obj=JSON.stringify(obj);
			  var arr=getSortedArray(obj);
			  $('#'+stateId).find('option:not(:first)').remove();
			  for(var i=0;i<arr.length;i++){
				  var key=arr[i].key;
				  var value=arr[i].value;
				  $("#"+stateId).append(new Option(value,key));
			  }
		  },
		  error: function(e) {
		//	alert("error: "+e);
		  }
		});
}

function accountVisbility(){
	var groupCode=$("#hiddenAccountGroupCode").val();
	if(groupCode=='HO'){
		$("#hostRow").hide();
		$("#distributorRow").hide();
		$("#subDistributorRow").hide();
		$("#retailerRow").hide();
		$("#tableForHost").show();
		$("#encryptionRowId").show();
	}
	else if(groupCode=='DI'){
		$("#hostRow").show();
		$("#distributorRow").hide();
		$("#subDistributorRow").hide();
		$("#retailerRow").hide();
		$("#tableForHost").hide();
		$("#encryptionRowId").show();
	}
	else if(groupCode=='SD'){
		$("#hostRow").show();
		$("#distributorRow").show();
		$("#subDistributorRow").hide();
		$("#retailerRow").hide();
		$("#tableForHost").hide();
		$("#encryptionRowId").show();
	}
	else if(groupCode=='RE'){
		$("#hostRow").show();
		$("#distributorRow").show();
		$("#subDistributorRow").show();
		$("#retailerRow").hide();
		$("#tableForHost").hide();
		$("#encryptionRowId").show();
	}
	else if(groupCode=='BC'){
		$("#hostRow").show();
		$("#distributorRow").show();
		$("#subDistributorRow").show();
		$("#retailerRow").show();
		$("#tableForHost").hide();
		$("#encryptionRowId").hide();
	}
	
	else if(groupCode=='VE')
		{
		
		
		$("#hostRow").hide();
		$("#distributorRow").hide();
		$("#subDistributorRow").hide();
		$("#retailerRow").hide();
		$("#tableForHost").hide();
		$("#encryptionRowId").hide();

		}
}

function getAccount(parentId,parentCode,childId,subDistributorId){
	var parentId=$("#"+parentId).val();
	if(parentId.length==0){
	$("#"+childId).val("");
		$("#"+subDistributorId).val("");
		return false;
	}
	
	 //========== ajax call ==============
	 $.ajax({
		  url: 'getAccount',
		  type: 'POST',
		  data: 'parentId='+parentId+'&parentCode='+parentCode,
		  success: function(data) {
			  data=data.platformChain;
			  var obj;
			  if(parentCode=='HO'){
				  obj=data.distributorMap;
			  }
			  else if(parentCode=='DI'){
				  obj=data.subDistributorMap;
			  }
			  else if(parentCode=='SD'){
				  obj=data.retailerMap;
			  }
			  obj=JSON.stringify(obj);
			  var arr=getSortedArray(obj);
			  $('#'+childId).find('option:not(:first)').remove();
			  $('#'+subDistributorId).find('option:not(:first)').remove();
			  for(var i=0;i<arr.length;i++){
				  var key=arr[i].key;
				  var value=arr[i].value;
				  $("#"+childId).append(new Option(value,key));
				  $("#"+subDistributorId).append(new Option(value,key));
			  }
		  },
		  error: function(e) {
		//	alert("error: "+e);
		  }
		});
	
	
}
var flag = true;
function checkDuplicateAccount(){
	var companyName=$("#companyNameId").val();
	var groupCode=$("#hiddenAccountGroupCode").val();
	var parentId=0;
	if(groupCode=='DI'){
		parentId=$("#hostId").val();
	}
	else if(groupCode=='SD'){
		parentId=$("#distributorId").val();
	}
	else if(groupCode=='RE'){
		parentId=$("#subDistributorId").val();
	}
	else if(groupCode=='BC'){
		parentId=$("#retailerId").val();
	}
	//alert(companyName+" "+groupCode+" "+parentId);
	
	//========== ajax call ==============
	var cname=$("#companyNameId").val();
	cname = cname.replace(/\s/g,'');
	var editFlag = function(){
		var finaleditflag=true;	
	if(cname.length!=0){
	 $.ajax({
		 async: false,
			  url: 'checkDuplicateAccount',
			  type: 'POST',
			  data: 'companyName='+companyName+'&groupCode='+groupCode+'&parentId='+parentId,
			  success: function(data) {
				  finaleditflag=data.flag;
				  if(finaleditflag==true){
					  $('#companyNameErrorId').html("<b><font color='red'>Company name not available.</font></b>");
					  $("#companyNameId").val('');
				  }
				  else if(finaleditflag==false)
				  {
					  $('#companyNameErrorId').html("<b><font color='green'>Company name available.</font></b>");
				  }
				  },
				/* if(flag=="false"){
					 
					 event.preventDefault();
					 return false;
				 }
				*/
				 
			 error: function(e) {
			
			}
		});
	 }
	return finaleditflag;
	}();
	 return editFlag;
}

function checkDuplicateAccountEdit(){
	var companyName=$("#companyNameId").val();
	//========== ajax call ==============
	var cname=$("#companyNameId").val().trim();
	cname = cname.replace(/\s/g,'');
	var editFlag = function(){
	var finaleditflag=true;	
	if(cname.length!=0){
	 $.ajax({
			  async: false,
			  url: 'checkDuplicateAccountEdit',
			  type: 'POST',
			  data: 'companyName='+companyName,
			  success: function(data) {
				  var editflag=data.flag;
				  if(editflag==true){
					  $('#companyNameErrorId').html("<b><font color='red'>Company name not available.</font></b>");
					  $("#companyNameId").val('');
					  finaleditflag= editflag;
				  }
				  else if(editflag==false)
				  {
					  $('#companyNameErrorId').html("<b><font color='green'>Company name available.</font></b>");
					  finaleditflag= editflag; 
				  }
			  },
			 error: function(e) {
			}
		});
	 }
	return finaleditflag;
	}();
	 return editFlag;
}

function checkDuplicateEncryptionKey(){
	
	var encryptionKey=$("#encryptionKeyId").val().trim();
	var groupCode=$("#hiddenAccountGroupCode").val();
	var parentId=0;
	if(groupCode=='DI'){
		parentId=$("#hostId").val();
	}
	else if(groupCode=='SD'){
		parentId=$("#distributorId").val();
	}
	else if(groupCode=='RE'){
		parentId=$("#subDistributorId").val();
	}
	else if(groupCode=='BC'){
		parentId=$("#retailerId").val();
	}
		 var completeCheck=true;
		 if(encryptionKey.length()>0){
	 $.ajax({
	  url: 'checkDuplicateEncryptionKey',
	  async: false,
	  type:'POST',
	  data:'encryptionKey='+encryptionKey+'&groupCode='+groupCode+'&parentId='+parentId,
	  success:function(response)
	  {
	   if(response!=0)
	   {
	    $('#encryptionKeyErrorId').html("<font color='red'><b>Encryption Key already exists!!</b></font>");
	    $('#encryptionKeyId').val('');
	    completeCheck = false;
	   }else
	   {
	    $('#encryptionKeyErrorId').html("<font color='green'><b> Encryption Key Available!!</b></font>");
	    completeCheck = true;
	   }
	  }
	 });
	 }
}
var keyflag;
function checkDuplicateEncryptionKeyEdit(){
	var encryptionKey=$("#encryptionKeyId").val().trim();
	if(encryptionKey.length==0){
		$('#encryptionKeyErrorId').html("<b><font color='red'>Enter unique encryption key.</font></b>");
	flag="false";}
	var groupCode=$("#hiddenAccountGroupCode").val();
	var parentId=0;
	if(groupCode=='DI'){
		parentId=$("#hostId").val();
	}
	else if(groupCode=='SD'){
		parentId=$("#distributorId").val();
	}
	else if(groupCode=='RE'){
		parentId=$("#subDistributorId").val();
	}
	else if(groupCode=='BC'){
		parentId=$("#retailerId").val();
	}
		 var completeCheck=true;
	 $.ajax({
	  url: 'checkDuplicateEncryptionKeyEdit',
	  type:'POST',
	  data:'encryptionKey='+encryptionKey+'&groupCode='+groupCode+'&parentId='+parentId,
	  success:function(response)
	  {
	   if(response!=0)
	   {
	    $('#encryptionKeyErrorId').html("<font color='red'><b>Encryption Key already exists!!</b></font>");
	    $('#encryptionKeyId').val('');
	    keyflag = false;
	   }else
	   {
	    $('#encryptionKeyErrorId').html("<font color='green'><b> Encryption Key Available!!</b></font>");
	    keyflag = true;
	   }
	  }
	 });
	return keyflag;
}



var coid=0;
function getId(companyName){
	
	 $.ajax({
		  url: 'getIdbyCompanyName',
		  type:'POST',
		  data:'companyName='+companyName,
		  success:function(response)
		  {
		   coid=response;
		  }
		 });
		
	
	
}

function validateAccountEditForm(event,ediOrNew){
	var flag=true;
	var editfinalflag=true;
	var companyName=$("#companyNameId").val();
	var groupCode=$("#hiddenAccountGroupCode").val();
	var parentId=0;
	if(groupCode=='DI'){
		parentId=$("#hostId").val();
	}
	else if(groupCode=='SD'){
		parentId=$("#distributorId").val();
	}
	else if(groupCode=='RE'){
		parentId=$("#subDistributorId").val();
	}
	else if(groupCode=='BC'){
		parentId=$("#retailerId").val();
	}

	$('#submitDIV').hide();
	$('#submitWaitDIV').show();
	var regURL = /(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/;
	var iPAddressRegex= /\b(?:\d{1,3}\.){3}\d{1,3}\b/;

	var groupCode=$("#hiddenAccountGroupCode").val();
	if(groupCode=='DI'){
		if($("#hostId").val()==''){
			$('#hostErrorId').html("<b><font color='red'>Select host.</font></b>");
			flag="false";
		}
		else{
			$('#hostErrorId').html("");
		}
	}
	else if(groupCode=='SD'){
		if($("#hostId").val()==''){
			$('#hostErrorId').html("<b><font color='red'>Select host.</font></b>");
			flag="false";
		}
		else{
			$('#hostErrorId').html("");
		}
		if($("#distributorId").val()==''){
			$('#distributorErrorId').html("<b><font color='red'>Select disitributor.</font></b>");
			flag="false";
		}
		else{
			$('#distributorErrorId').html("");
		}
	}
	else if(groupCode=='RE'){
		if($("#hostId").val()==''){
			$('#hostErrorId').html("<b><font color='red'>Select host.</font></b>");
			flag="false";
		}
		else{
			$('#hostErrorId').html("");
		}

		if($("#distributorId").val()==''){
			$('#distributorErrorId').html("<b><font color='red'>Select disitributor.</font></b>");
			flag="false";
		}
		else{
			$('#distributorErrorId').html("");
		}

		if($("#subDistributorId").val()==''){
			$('#subDistributorErrorId').html("<b><font color='red'>Select sub-disitributor.</font></b>");
			flag="false";
		}
		else{
			$('#subDistributorErrorId').html("");
		}
	}
	else if(groupCode=='BC'){
		if($("#hostId").val()==''){
			$('#hostErrorId').html("<b><font color='red'>Select host.</font></b>");
			flag="false";
		}
		else{
			$('#hostErrorId').html("");
		}

		if($("#distributorId").val()==''){
			$('#distributorErrorId').html("<b><font color='red'>Select disitributor.</font></b>");
			flag="false";
		}
		else{
			$('#distributorErrorId').html("");
		}

		if($("#subDistributorId").val()==''){
			$('#subDistributorErrorId').html("<b><font color='red'>Select sub-disitributor.</font></b>");
			flag="false";
		}
		else{
			$('#subDistributorErrorId').html("");
		}

		if($("#retailerId").val()==''){
			$('#retailerErrorId').html("<b><font color='red'>Select retailer.</font></b>");
			flag="false";
		}
		else{
			$('#retailerErrorId').html("");
		}
	}

	if($("#companyNameId").val()==''){
		$('#companyNameErrorId').html("<b><font color='red'>Enter company name.</font></b>");
		flag="false";
	}
	else{
		var cname=$("#companyNameId").val();
		cname = cname.replace(/\s/g,'');
		if(cname.length==0){
			$('#companyNameErrorId').html("<b><font color='red'>Enter company name.</font></b>");
			flag="false";
		}else{
			$('#companyNameErrorId').html("");
		}

	}
	var countryCodeId=$("#countryCodeId").val().trim();
	var mobileNumber=$("#mobileNumber").val().trim();
	
	if((countryCodeId.length==0)&&(mobileNumber.length==0)){
		$('#mobileNumberErrorId').html("<b><font color='red'>Kindly enter Mobile Number.</font></b>");
		flag="false";
		
	}
	else{
		if((countryCodeId.length==0)&&(mobileNumber.length!=0)){
			$('#mobileNumberErrorId').html("<b><font color='red'>Kindly select Country Code.</font></b>");
			flag="false";
			
		}
		if((countryCodeId.length!=0)&&(mobileNumber.length==0)){
			$('#mobileNumberErrorId').html("<b><font color='red'>Kindly enter Mobile Number.</font></b>");
			flag="false";
			
		}
		
	}
var mobLength=$('#mobileNumber').val().trim();
	if(mobLength.length<10){
		$('#mobileNumberErrorId').html("<b><font color='red'>Mobile Number should be 10 digit long.</font></b>")
		flag="false";
	}
var alternateMobileNumber=$('#alternateMobileNumber').val().trim();
	
	//alert(mobLength);
if(alternateMobileNumber.length!=0){
	if(alternateMobileNumber.length<10){
		$('#alternateMobileNumberErrorId').html("<b><font color='red'>Mobile Number should be 10 digit long.</font></b>")
		flag="false";
	}
	}
	
	/*if(countryCodeId.length==0){
		$('#mobileNumberErrorId').html("<b><font color='red'>Kindly select Country Code.</font></b>");
		flag="false";
		
	}
	else{
		if(mobileNumber.length==0){
			$('#mobileNumberErrorId').html("<b><font color='red'>Kindly enter Mobile Number.</font></b>");
			flag="false";
		}
	}*/
	
	var emailId=$('#emailId').val().trim();
	if(emailId.length==0){
		$('#lab_Email_IdErrorId').html("<b><font color='red'>Kindly enter E-mail ID.</font></b>");
		flag="false";
	}else{
	var email=emailValidation(event,'emailId','lab_Email_IdErrorId');
	}
	var address=$('#address').val().trim();
	if(address.length==0){
		$('#lab_addressErrorId').html("<b><font color='red'>Kindly enter Address.</font></b>");
		flag="false";
	}
	
	var pinCode=$('#pinCode').val().trim();
	if(pinCode.length==0){
		$('#lab_pinCodeErrorId').html("<b><font color='red'>Kindly enter PIN code.</font></b>");
		flag="false";
	}
	if(pinCode.length!=0){
	var locality=$("#locality").val().trim();
	if(locality.length==0){
		$('#buttonClickErrorId').html("<b><font color='red'>Kindly click Fetch Address.</font></b>");
		flag="false";
	}
	}
	


	/*if($("#houseNoId").val()==''){
		
		 $('#houseNoStreetErrorId').html("<b><font color='red'>Enter House No.</font></b>");
		 flag="false";
	}
	else{

		var houseNo=$("#houseNoId").val();
		houseNo = houseNo.replace(/\s/g,'');

		if(houseNo.length==0){
			
			 $('#houseNoStreetErrorId').html("<b><font color='red'>Enter House No.</font></b>");
			 flag="false";
		}
		else{

			$('#houseNoStreetErrorId').html("");
		}

	}

	if($("#cityId").val()==''){
		$('#cityErrorId').html("<b><font color='red'>Enter city name.</font></b>");
		flag="false";
	}
	else{
		var city=$("#cityId").val();
		city = city.replace(/\s/g,'');
		if(city.length==0){
			$('#cityErrorId').html("<b><font color='red'>Enter city name.</font></b>");
			flag="false";
		}
		else{
			if(!isNaN(city)){
				$('#cityErrorId').html("<b><font color='red'>Invalid city name.</font></b>");
				flag="false";
			}else{
				$('#cityErrorId').html("");
			}
		}

	}
	if($("#countryId").val()==0){
		$('#countryErrorId').html("<b><font color='red'>select country name</font></b>");
		flag="false";
	}
	else{
		$('#countryErrorId').html("");
	}

	if($("#stateId").val()==''){
		$('#stateErrorId').html("<b><font color='red'>Select state.</font></b>");
		flag="false";
	}
	else{
		$('#stateErrorId').html("");
	}

	if($("#pinCodeId").val()==''){
		$('#pinCodeErrorId').html("<b><font color='red'>Enter pin code.</font></b>");
		flag="false";
	}
	else{
		var firstChar=$("#pinCodeId").val().charAt(0);
		if(parseInt(firstChar)==0){
			$('#pinCodeErrorId').html("<b><font color='red'>Enter valid pin code.</font></b>");
			flag="false";
		}else{
			if($("#pinCodeId").val().length!=6){
				$('#pinCodeErrorId').html("<b><font color='red'>Enter 6-digit pin code.</font></b>");
				flag="false";
			}else{
				$('#pinCodeErrorId').html("");
			}
		}
	}
*/
	if(groupCode=='HO'){
		if($("#deploymentTypeId").val()=='SAAS'){
			if($("#gatewayIpId").val()==''){
				$('#gatewayIpErrorId').html("<b><font color='red'>Enter gateway IP.</font></b>");
				flag="false";
			}
			else{
				if(!iPAddressRegex.test($("#gatewayIpId").val())){
					$('#gatewayIpErrorId').html("<b><font color='red'>Enter valid IP.</font></b>");
					flag="false";
				}
				else{
					$('#gatewayIpErrorId').html("");	
				}

			}
		}
		else{
			var gatewayIp=$("#gatewayIpId").val();
			var porTId=$("#portId").val();
			var urLId=$("#urlId").val();
			if(gatewayIp.length>0 && porTId.length==0 ){
				$('#urlErrorId').html("<b><font color='red'>Enter either IP and Port or URL.</font></b>");
				flag="false";	
				
			}
			if(gatewayIp.length==0 && porTId.length>0 ){
				$('#urlErrorId').html("<b><font color='red'>Enter either IP and Port or URL.</font></b>");
				flag="false";	
				
			}
			if(gatewayIp.length>0||porTId.length>0 ){
				if(urLId.length>0)
				{
					$('#urlErrorId').html("<b><font color='red'>Enter either IP and Port or URL.</font></b>");
					flag="false";
				}
			}	
			else	if($("#gatewayIpId").val()=='' && $("#portId").val()==''){
					if($("#urlId").val()==''){
						$('#urlErrorId').html("<b><font color='red'>Enter either IP and Port or URL.</font></b>");
						flag="false";
					}
					else{
						var url=$("#urlId").val();
						url = url.replace(/\s/g,'');
						if(url.length==0){
							$('#urlErrorId').html("<b><font color='red'>Enter either URL or IP and Port.</font></b>");
							flag="false";
						}
						else if(!regURL.test(url)){
							$('#urlErrorId').html("<b><font color='red'>Enter valid URL.</font></b>");
							flag="false";
						}
						else{
							$('#urlErrorId').html("");
						}

					}
				}

				else{
					$('#urlErrorId').html("");
					if($("#gatewayIpId").val()==''){
						$('#gatewayIpErrorId').html("<b><font color='red'>Enter the IP.</font></b>");
						flag="false";
					}
					else{
						if(!iPAddressRegex.test($("#gatewayIpId").val())){
							$('#gatewayIpErrorId').html("<b><font color='red'>Enter valid IP.</font></b>");
							flag="false";
						}
						else{
							$('#gatewayIpErrorId').html("");	
						}
					}

					if($("#portId").val()==''){
						$('#portErrorId').html("<b><font color='red'>Enter the port.</font></b>");
						flag="false";
					}
					else{
						if($("#portId").val().length!=4){
							$('#portErrorId').html("<b><font color='red'>Enter 4-digit port.</font></b>");
							flag="false";
						}else{
							var firstChar=$("#portId").val().charAt(0);
							if(parseInt(firstChar)==0){
								$('#portErrorId').html("<b><font color='red'>Enter valid port.</font></b>");
								flag="false";
							}else{
								$('#portErrorId').html("");
							}
						}
					}
				}
			}
		}

		if(groupCode=='HO'||groupCode=='DI'||groupCode=='SD'||groupCode=='RE'){
			if($("#encryptionKeyId").val().trim().length==0){
				$('#encryptionKeyErrorId').html("<b><font color='red'>Enter unique encryption key.</font></b>");
				flag="false";
			}
			else{
				if(($("#encryptionKeyId").val().length>=24) && ($("#encryptionKeyId").val().length <=48) ){
					$('#encryptionKeyErrorId').html("");
				}
				else{
					$('#encryptionKeyErrorId').html("<b><font color='red'>Enter minimum 24 characters encryption key.</font></b>");
					flag="false";
				}

			}
		}
		//alert(flag)
		 kflag=checkDuplicateEncryptionKyEdit();
			if(kflag==false){
				flag="false";
			}
		
		//alert("flag  "+flag)
		if(flag==true){
		var finalflg= checkDuplicateAccountEdit();
		//alert("finalflg after checkDuplicateAccountEdit "+finalflg)
			 if(finalflg==true){
				 flag="false";
					
				}
			 else{
				 flag="true"; 
			 }
		}
		//alert("flag after checkDuplicateAccountEdit "+flag)
		
		if(flag=="false"){
			$('#submitDIV').show();
			$('#submitWaitDIV').hide();
			event.preventDefault();
			return false;
		}else if(editfinalflag=="true"){
			//$("#accountform").submit();
			}
	}


//======================= account creation submit ===========================
function validateAccountCreationForm(event,ediOrNew){
	var flag="true";
	var companyName=$("#companyNameId").val();
	var groupCode=$("#hiddenAccountGroupCode").val();
	var parentId=0;
	if(groupCode=='DI'){
		parentId=$("#hostId").val();
	}
	else if(groupCode=='SD'){
		parentId=$("#distributorId").val();
	}
	else if(groupCode=='RE'){
		parentId=$("#subDistributorId").val();
	}
	else if(groupCode=='BC'){
		parentId=$("#retailerId").val();
	}

	$('#submitDIV').hide();
	$('#submitWaitDIV').show();
	var regURL = /(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/;
	var iPAddressRegex= /\b(?:\d{1,3}\.){3}\d{1,3}\b/;

	var groupCode=$("#hiddenAccountGroupCode").val();
	if(groupCode=='DI'){
		if($("#hostId").val()==''){
			$('#hostErrorId').html("<b><font color='red'>Select host.</font></b>");
			flag="false";
		}
		else{
			$('#hostErrorId').html("");
		}
	}
	else if(groupCode=='SD'){
		if($("#hostId").val()==''){
			$('#hostErrorId').html("<b><font color='red'>Select host.</font></b>");
			flag="false";
		}
		else{
			$('#hostErrorId').html("");
		}
		if($("#distributorId").val()==''){
			$('#distributorErrorId').html("<b><font color='red'>Select disitributor.</font></b>");
			flag="false";
		}
		else{
			$('#distributorErrorId').html("");
		}
	}
	else if(groupCode=='RE'){
		if($("#hostId").val()==''){
			$('#hostErrorId').html("<b><font color='red'>Select host.</font></b>");
			flag="false";
		}
		else{
			$('#hostErrorId').html("");
		}

		if($("#distributorId").val()==''){
			$('#distributorErrorId').html("<b><font color='red'>Select disitributor.</font></b>");
			flag="false";
		}
		else{
			$('#distributorErrorId').html("");
		}

		if($("#subDistributorId").val()==''){
			$('#subDistributorErrorId').html("<b><font color='red'>Select sub-disitributor.</font></b>");
			flag="false";
		}
		else{
			$('#subDistributorErrorId').html("");
		}
	}
	else if(groupCode=='BC'){
		if($("#hostId").val()==''){
			$('#hostErrorId').html("<b><font color='red'>Select host.</font></b>");
			flag="false";
		}
		else{
			$('#hostErrorId').html("");
		}

		if($("#distributorId").val()==''){
			$('#distributorErrorId').html("<b><font color='red'>Select disitributor.</font></b>");
			flag="false";
		}
		else{
			$('#distributorErrorId').html("");
		}

		if($("#subDistributorId").val()==''){
			$('#subDistributorErrorId').html("<b><font color='red'>Select sub-disitributor.</font></b>");
			flag="false";
		}
		else{
			$('#subDistributorErrorId').html("");
		}

		if($("#retailerId").val()==''){
			$('#retailerErrorId').html("<b><font color='red'>Select retailer.</font></b>");
			flag="false";
		}
		else{
			$('#retailerErrorId').html("");
		}
	}
	if($("#companyNameId").val()==''){
		$('#companyNameErrorId').html("<b><font color='red'>Enter company name.</font></b>");
		flag="false";
	}
	else{
		var cname=$("#companyNameId").val();
		cname = cname.replace(/\s/g,'');
		if(cname.length==0){
			$('#companyNameErrorId').html("<b><font color='red'>Enter company name.</font></b>");
			flag="false";
		}else{
			$('#companyNameErrorId').html("");
		}
	}
	var countryCodeId=$("#countryCodeId").val().trim();
	var mobileNumber=$("#mobileNumber").val().trim();
	
	if((countryCodeId.length==0)&&(mobileNumber.length==0)){
		$('#mobileNumberErrorId').html("<b><font color='red'>Kindly enter Mobile Number.</font></b>");
		flag="false";
		
	}
	else{
		if((countryCodeId.length==0)&&(mobileNumber.length!=0)){
			$('#mobileNumberErrorId').html("<b><font color='red'>Kindly select Country Code.</font></b>");
			flag="false";
			
		}
		if((countryCodeId.length!=0)&&(mobileNumber.length==0)){
			$('#mobileNumberErrorId').html("<b><font color='red'>Kindly enter Mobile Number.</font></b>");
			flag="false";
			
		}
		
	}
	
	/*if(countryCodeId.length==0){
		$('#mobileNumberErrorId').html("<b><font color='red'>Kindly select Country Code.</font></b>");
		flag="false";
		
	}
	else{
		if(mobileNumber.length==0){
			$('#mobileNumberErrorId').html("<b><font color='red'>Kindly enter Mobile Number.</font></b>");
			flag="false";
		}
	}*/
	
	var emailId=$('#emailId').val().trim();
	if(emailId.length==0){
		$('#lab_Email_IdErrorId').html("<b><font color='red'>Kindly enter E-mail ID.</font></b>");
		flag="false";
	}
	
	var address=$('#address').val().trim();
	if(address.length==0){
		$('#lab_addressErrorId').html("<b><font color='red'>Kindly enter Address.</font></b>");
		flag="false";
	}
	
	var pinCode=$('#pinCode').val().trim();
	if(pinCode.length==0){
		$('#lab_pinCodeErrorId').html("<b><font color='red'>Kindly enter PIN code.</font></b>");
		flag="false";
	}
	if(pinCode.length!=0){
	var locality=$("#locality").val().trim();
	if(locality.length==0){
		$('#buttonClickErrorId').html("<b><font color='red'>Kindly click Fetch Address.</font></b>");
		flag="false";
	}
	}
	
	
	/*if($("#houseNoId").val()==''){
		
		 $('#houseNoStreetErrorId').html("<b><font color='red'>Enter House No.</font></b>");
		 flag="false";
	}
	else{

		var houseNo=$("#houseNoId").val();
		houseNo = houseNo.replace(/\s/g,'');

		if(houseNo.length==0){
			
			 $('#houseNoStreetErrorId').html("<b><font color='red'>Enter House No.</font></b>");
			 flag="false";
		}
		else{

			$('#houseNoStreetErrorId').html("");
		}

	}
	if($("#cityId").val()==''){
		$('#cityErrorId').html("<b><font color='red'>Enter city name.</font></b>");
		flag="false";
	}
	else{
		var city=$("#cityId").val();
		city = city.replace(/\s/g,'');
		if(city.length==0){
			$('#cityErrorId').html("<b><font color='red'>Enter city name.</font></b>");
			flag="false";
		}
		else{
			if(!isNaN(city)){
				$('#cityErrorId').html("<b><font color='red'>Invalid city name.</font></b>");
				flag="false";
			}else{
				$('#cityErrorId').html("");
			}
		}

	}
	if($("#countryId").val()==0){
		$('#countryErrorId').html("<b><font color='red'>select country name</font></b>");
		flag="false";
	}
	else{
		$('#countryErrorId').html("");
	}

	if($("#stateId").val()==''){
		$('#stateErrorId').html("<b><font color='red'>Select state.</font></b>");
		flag="false";
	}
	else{
		$('#stateErrorId').html("");
	}
	if($("#pinCodeId").val()==''){
		$('#pinCodeErrorId').html("<b><font color='red'>Enter pin code.</font></b>");
		flag="false";
	}
	else{
		var firstChar=$("#pinCodeId").val().charAt(0);
		if(parseInt(firstChar)==0){
			$('#pinCodeErrorId').html("<b><font color='red'>Enter valid pin code.</font></b>");
			flag="false";
		}else{
			if($("#pinCodeId").val().length!=6){
				$('#pinCodeErrorId').html("<b><font color='red'>Enter 6-digit pin code.</font></b>");
				flag="false";
			}else{
				$('#pinCodeErrorId').html("");
			}

		}

	}
*/	
	if(groupCode=='HO'){
		if($("#deploymentTypeId").val()=='SAAS'){
			if($("#gatewayIpId").val()==''){
				$('#gatewayIpErrorId').html("<b><font color='red'>Enter gateway IP.</font></b>");
				flag="false";
			}
			else{
			
				if(!iPAddressRegex.test($("#gatewayIpId").val())){
					$('#gatewayIpErrorId').html("<b><font color='red'>Enter valid IP.</font></b>");
					flag="false";
				}
				else{
					$('#gatewayIpErrorId').html("");	
				}

			}
		}
		else{
			var gatewayIp=$("#gatewayIpId").val().trim();
			var porTId=$("#portId").val().trim();
			//alert(porTId);
			var urLId=$("#urlId").val().trim();
			if(gatewayIp.length>0 && porTId.length==0 ){
				$('#urlErrorId').html("<b><font color='red'>Enter either IP and Port or URL.</font></b>");
				flag="false";	
				
			}
			if(gatewayIp.length==0 && porTId.length>0 ){
				$('#urlErrorId').html("<b><font color='red'>Enter either IP and Port or URL.</font></b>");
				flag="false";	
				
			}
			if(gatewayIp.length>0||porTId.length>0 ){
				if(urLId.length>0)
				{
					$('#urlErrorId').html("<b><font color='red'>Enter either IP and Port or URL.</font></b>");
					flag="false";
				}
			}	

			else	if($("#gatewayIpId").val()=='' && $("#portId").val()==''){
					if($("#urlId").val()==''){
						$('#urlErrorId').html("<b><font color='red'>Enter either IP and Port or URL.</font></b>");
						flag="false";
					}
					else{
						var url=$("#urlId").val();
						url = url.replace(/\s/g,'');
						if(url.length==0){
							$('#urlErrorId').html("<b><font color='red'>Enter either URL or IP and Port.</font></b>");
							flag="false";
						}
						else if(!regURL.test(url)){
							$('#urlErrorId').html("<b><font color='red'>Enter valid URL.</font></b>");
							flag="false";
						}
						else{
							$('#urlErrorId').html("");
						}

					}
				}

				else{
					$('#urlErrorId').html("");
					if($("#gatewayIpId").val()==''){
						$('#gatewayIpErrorId').html("<b><font color='red'>Enter the IP.</font></b>");
						flag="false";
					}
					else{
						if(!iPAddressRegex.test($("#gatewayIpId").val())){
							$('#gatewayIpErrorId').html("<b><font color='red'>Enter valid IP.</font></b>");
							flag="false";
						}
						else{
							$('#gatewayIpErrorId').html("");	
						}
					}

					if($("#portId").val()==''){
						$('#portErrorId').html("<b><font color='red'>Enter the port.</font></b>");
						flag="false";
					}
					else{
						if($("#portId").val().length!=4){
							$('#portErrorId').html("<b><font color='red'>Enter 4-digit port.</font></b>");
							flag="false";
						}else{
							var firstChar=$("#portId").val().charAt(0);
							if(parseInt(firstChar)==0){
								$('#portErrorId').html("<b><font color='red'>Enter valid port.</font></b>");
								flag="false";
							}else{
								$('#portErrorId').html("");
							}
						}



					}
				}
			}
		}
//	alert("to start checkinggggggggggggggggggggggggggggggggggggggggggg");
		if(groupCode=='HO'||groupCode=='DI'||groupCode=='SD'||groupCode=='RE'){
			if($("#encryptionKeyId").val().trim()==''){
				$('#encryptionKeyErrorId').html("<b><font color='red'>Enter unique encryption key.</font></b>");
				flag="false";
			}
			else{
				if(($("#encryptionKeyId").val().length>=24) && ($("#encryptionKeyId").val().length <=48) ){
					$('#encryptionKeyErrorId').html("");
				}
				else{
					$('#encryptionKeyErrorId').html("<b><font color='red'>Enter minimum 24 characters encryption key.</font></b>");
					flag="false";
				}

			}
		}
		//alert("first  "+flag)
		 if(flag=="true"){
			 
		//	 alert("to start checking");
			kflag=checkDuplicateEncryptionKy();
			// alert("checking ends");
			//alert("key flag  "+kflag);
			if(kflag==false){
				flag="false";
			}
			if(kflag==true){
			var fl=checkDuplicateAccount();
			//alert("result ajax "+fl)
			if(fl==true){
				$('#submitDIV').show();
				$('#submitWaitDIV').hide();
				event.preventDefault();
				return false;
				
			}else if(fl==false){
				return true;}

			}
		 }
		if(flag=="false"){
			$('#submitDIV').show();
			$('#submitWaitDIV').hide();
			event.preventDefault();
			return false;
			
		}
		
	}
function checkDuplicateEncryptionKy(){
	var encryptionKey=$("#encryptionKeyId").val().trim();
	var groupCode=$("#hiddenAccountGroupCode").val();
	var parentId=0;
	if(groupCode=='DI'){
		parentId=$("#hostId").val();
	}
	else if(groupCode=='SD'){
		parentId=$("#distributorId").val();
	}
	else if(groupCode=='RE'){
		parentId=$("#subDistributorId").val();
	}
	else if(groupCode=='BC'){
		parentId=$("#retailerId").val();
	}
		// var completeCheck=true;
		 var editFlag = function(){
				var completeCheck=true;	
		if(encryptionKey.length!=0) {
	 $.ajax({
	  url: 'checkDuplicateEncryptionKey',
	  async: false,
	  type:'POST',
	  data:'encryptionKey='+encryptionKey+'&groupCode='+groupCode+'&parentId='+parentId,
	  success:function(response)
	  {
		  //alert("in ajax" +response)
	   if(response!=0)
	   {
		 
	    $('#encryptionKeyErrorId').html("<font color='red'><b>Encryption Key already exists!!</b></font>");
	    $('#encryptionKeyId').val('');
	    completeCheck = false;
	   }else
	   {
	    $('#encryptionKeyErrorId').html("<font color='green'><b> Encryption Key Available!!</b></font>");
	   
	    completeCheck = true;
	   }
	  }
	 });
		}
		//alert("in "+completeCheck);
		return completeCheck;
		}();
		//alert(" out "+editFlag);
		 return editFlag;
	}
	
function checkDuplicateEncryptionKyEdit(){
	var encryptionKey=$("#encryptionKeyId").val().trim();
	var groupCode=$("#hiddenAccountGroupCode").val();
	var parentId=0;
	if(groupCode=='DI'){
		parentId=$("#hostId").val();
	}
	else if(groupCode=='SD'){
		parentId=$("#distributorId").val();
	}
	else if(groupCode=='RE'){
		parentId=$("#subDistributorId").val();
	}
	else if(groupCode=='BC'){
		parentId=$("#retailerId").val();
	}
	if(encryptionKey.length!=0) {	 
	 $.ajax({
	  url: 'checkDuplicateEncryptionKeyEdit',
	  async: false, 
	  type:'POST',
	  data:'encryptionKey='+encryptionKey+'&groupCode='+groupCode+'&parentId='+parentId,
	  success:function(response)
	  {
	   if(response!=0)
	   {
	    $('#encryptionKeyErrorId').html("<font color='red'><b>Encryption Key already exists!!</b></font>");
	    $('#encryptionKeyId').val('');
	    fflag = false;
	   }else
	   {
		 
	    $('#encryptionKeyErrorId').html("<font color='green'><b> Encryption Key Available!!</b></font>");
	   
	    fflag = true;
	   }
	  }
	 });
	return fflag;
	 }
}

function getMobileIdArray(){
	 var input = document.getElementsByTagName('input');
	 var mobileArr=[];
     for (var counter=0; counter<input.length; counter++) {
          if (input[counter].type=='text' && input[counter].name=='mobileArr') {
        	  mobileArr.push(input[counter].id);  
         }
     }
     return mobileArr;
}

function getLoginNameIdArray(){
	 var input = document.getElementsByTagName('input');
	 var loginNameArr=[];
    for (var counter=0; counter<input.length; counter++) {
         if (input[counter].type=='text' && input[counter].name=='loginNameArr') {
        	 loginNameArr.push(input[counter].id);  
        }
    }
    return loginNameArr;
}

function checkDuplicateMobile(id){
	var num = id.replace( /^\D+/g, '');
	var mobile=$("#"+id).val();
	//========== ajax call ==============
	 $.ajax({
		  url: 'checkDuplicateMobile',
		  type: 'POST',
		  data: 'mobile='+mobile,
		  success: function(data) {
			  var flag=data.flag;
			  if(flag==true){
				  $('#mobileErrorId'+num).html("<b><font color='red'>Mobile already exists.</font></b>");
				  $("#"+id).val('');
			  }
		  },
		  error: function(e) {
			//alert("error: "+e);
		  }
		  
	});
}

function checkDuplicateLoginName(id){
	var num = id.replace( /^\D+/g, '');
	var loginName=$("#"+id).val();
	//========== ajax call ==============
	 $.ajax({
		  url: 'checkDuplicateLoginName',
		  type: 'POST',
		  data: 'loginName='+loginName,
		  success: function(data) {
			  var flag=data.flag;
			  if(flag==true){
				  $('#loginNameErrorId'+num).html("<b><font color='red'>Login name already exists.</font></b>");
				  $("#"+id).val('');
			  }
		  },
		  error: function(e) {
			//alert("error: "+e);
		  }
		  
	});
}

$(document).ready(function(){
	 $("#deploymentTypeId").change(function() {
		    var id = $(this);
		    var value=id.val();
		    if(value=='SAAS'){
		    	$("#portRow").hide();
		    	 $('#urlErrorId').html("");
		    }
		    else{
		    	$("#portRow").show();
		    }
	 });
});



$(document).ready(function(){
	 $("#accountTypeId").change(function() {
		   $('#msgId').html("");
	 });
});

$(document).ready(function(){
	 var groupCode=$("#hiddenLoginGroupCodeId").val();
	 if(groupCode!='PP'){
		 $("#hostRowId").hide();
	 }
});

function showLogo(){
	var src=$('#logoImage').attr('src');
	if(src!=''){
		var lastIndex=src.lastIndexOf("/");
		var imageName=src.substring(lastIndex+1);
		$("#logoName").html(imageName);
	}
}

function makeDropDownReadOnly(hiddenAccountTypeId){
	var accountType=$("#"+hiddenAccountTypeId).val();
	if(accountType=='DI'){ // distributor
		makeDropdownReadonly('hostId');
	}
	else if(accountType=='SD'){ // sub-distributor
		makeDropdownReadonly('hostId');
		makeDropdownReadonly('distributorId');
	}
	else if(accountType=='RE'){ // retailer
		makeDropdownReadonly('hostId');
		makeDropdownReadonly('distributorId');
		makeDropdownReadonly('subDistributorId');
	}
	else if(accountType=='BC'){ // bc
		makeDropdownReadonly('hostId');
		makeDropdownReadonly('distributorId');
		makeDropdownReadonly('subDistributorId');
		makeDropdownReadonly('retailerId');
	}
	
}

function emptyMessage(){
	$('#msgId').html("");
}

function validateHost() {
	
	
	/* $("#SearchByTable").show();
	 $("#SearchByAutoSearch").show();*/
	
	var hostIdVal=$("#hostId").val();

	if($("#hostId").val()==''){
		$('#hostErrorId').html("<b><font color='red'>Select host.</font></b>");
		return false;
	}
	
	else{
		
		//alert("host selected");
		$("#hostRowId").show();
		$("#host").show();
		$("#host1").show();
		$("#host2").show();
		$("#hostId").show();
		
	}
	 
		if(sel=='HOST')
		{
		$("#hostRowId").show();
		$("#host").show();
		$("#host1").show();
		$("#host2").show();
		$("#hostId").show();
		$("#vendor1").hide();
		$("#vendor").hide();
		$("#vendor2").hide();
		$("#table_id").hide();
		$("#header1").hide();
		
		}
	
	 $("#hostId").show();
		
	 
	 
}

function validatevendor() {
	
	/* $("#SearchByTable").show();
	 $("#SearchByAutoSearch").show();*/
	 if($("#vendorId").val()==''){
			$('#hostErrorId').html("<b><font color='red'>Select vendor.</font></b>");
			return false;
		}
	 
	 
}

function emptyLanmarkErrorId(){
	$('#landMarkErrorId').html("");
}

function emptyHostErrorId(){
	$('#hostErrorId').html("");
}

function disappearMsg(){
	$('#successmsg1').html("");
	$('#errormsg1').html("");
	
}

function fetchAddress(){
	$("#addressSelectDivId").show();
	$('#buttonClickErrorId').html("");
	var pinCode = $('#pinCode').val().trim(); 
	if(pinCode.length==0){
		$('#lab_pinCodeErrorId').html("<b><font color='red'>Kindly enter PIN Code.</font></b>");
		return false;
	}
	else if((pinCode<=110000)||(pinCode>=855118)){
		$('#lab_pinCodeErrorId').html("<b><font color='red'>Kindly enter valid PIN Code.</font></b>");
		return false;
	}

	
	if(pinCode.length<6){
		
		$('#lab_pinCodeErrorId').html("<b><font color='red'>PIN Code should be 6 digit long.</font></b>");
		return false;
	}
	else{
	if(pinCode.length>0){ 	
	   $.ajax({
		   url: '/selfcare/AdminUI/UserMgmt/fetchAddress',
		   type: "POST",
		   data: "pinCode="+pinCode,
		   success:function(response){
			   var addressData = response;
			   if(addressData.length>0){
			   $('#addressSelectTableId').html("<tr><td align='center' width='100%' colspan='6'><b>Select Address</b></td></tr>");
			   $('#addressSelectTableId').append("<tr><td align='center'><table border='2' width='100%'  cellspacing='1' cellpadding='0' class='tableMain'>");
			   $('#addressSelectTableId').append("<tr><td width='10%'>Select</td><td width='25%'>Location</td><td width='15%'>PIN Code</td><td width='20%'>District</td><td width='15%'>State</td><td width='10%'>Country</td></tr>");
			   for(var i=0;i<addressData.length;i++){
				   
				   $('#addressSelectTableId').append('<tr><td><input type="radio" id="addressSelectionId'+addressData[i].id+'" name="addressSelectionId" value='+addressData[i].id+' onchange="fillAddressDetail(\''+addressData[i].id+'\',\''+addressData[i].location+'\',\''+addressData[i].pincode+'\',\''+addressData[i].district+'\',\''+addressData[i].state+'\',\''+addressData[i].country+'\',\''+addressData[i].region+'\');"/></td><td>'+addressData[i].location+'</td><td>'+addressData[i].pincode+'</td><td>'+addressData[i].district+'</td><td>'+addressData[i].state+'</td><td>'+addressData[i].country+'</td></tr>');
			   }
			   $('#addressSelectTableId').append("</table></td></tr>");
			  /* $('#addressSelectDivId').dialog({
					width: 525,
					height: 350,
					
					title: '\tSelect Address',
					buttons : {
						"OK" : function (response)
						{
							$(this).dialog("close");
						},
			   "CANCEL" : function(response){
				   $(this).dialog("close");
			   }
					}
			   });*/
		   }else{
			   $('#lab_pinCodeErrorId').html("<b><font color='red'>Kindly enter valid PIN Code.</font></b>");
		   }
		   }
	   });	
	   
	}
	}
	}
	


function fillAddressDetail(id,location,pincode,district,state,country,region){
	$("#addressSelectDivId").hide();
	if($('#addressSelectionId'+id).is(':checked')){
		$('#pinCode').val(pincode);
		$('#locality').val(location);
		$('#region').val(region);
		$('#district').val(district);
		$('#state').val(state);
		$('#country').val(country);
		$('#pinaddressId').val(id);
		//alert(id);
		
	
	}
}


function textAreaAdjust(el) {
	el.style.height = (el.scrollHeight > el.clientHeight) ? (el.scrollHeight)+"px" : "60px";
	}


function pinLength(event,lab_pinCodeErrorId){
	
	var pinLength=$('#pinCode').val();
	
	//alert(pinLength);
	if(pinLength<6){
		$('#lab_pinCodeErrorId').html("<b><font color='red'>PIN Code should be 6 digit long.</font></b>")
		return false;
	}
}

function changePinCode(){
	var address=$('#address').val('');
	var address2=$('#address2').val('');
	var locality=$('#locality').val('');
	var district=$('#district').val('');
	var country=$('#country').val('');
	var region=$('#region').val('');
	var state=$('#state').val('');
	
}


function mobLength(event,mobileNumberErrorId){
	
	var mobLength=$('#mobileNumber').val().trim();
	
	if(mobLength.length<10){
		$('#mobileNumberErrorId').html("<b><font color='red'>Mobile Number should be 10 digit long.</font></b>")
		return false;
	}
var alternateMobileNumber=$('#alternateMobileNumber').val().trim();
	
if(alternateMobileNumber.length!=0){
	if(alternateMobileNumber.length<10){
		$('#alternateMobileNumberErrorId').html("<b><font color='red'>Mobile Number should be 10 digit long.</font></b>")
		return false;
	}
	}
}

var check=true;
function checkUniqueUserEmailId(){
	
	var userEmailId=$("#emailId").val();
	
	var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
  if (emailReg.test(userEmailId)) {
  	$('#lab_Email_IdErrorId').html("");
  	$.ajax({
  		type: "post",
  		async:false,
  		url: 'checkUniqueUserEmailId',
  		cache: false,
  		data:{userEmailId :userEmailId},
  		success: function(response){
  			if(response!=""){
  				check=false;
  				$("#userEmailId").val('');
  				$("#finalFlag").val('false');
  				$('#lab_Email_IdErrorId').html("<b><font color='red'>"+response+"</font></b>");
  			}else{
  				$("#finalFlag").val("");
  			}
  		},	error: function(errorThrown){ return false;	}
  	});
  }
  else {
		$('#lab_Email_IdErrorId').html("<b><font color='red'>Kindly enter valid E-mail ID</font></b>");
		$("#userEmailId").val("");
		completeCheck = false;
		event.preventDefault();
	}
	return check;
}

var check=true;
function checkUniqueUserMobileNumber(){
	var check=true;
	var userMobile=$("#mobileNumber").val();
	$.ajax({
		type: "post",
		url: 'checkUniqueUserMobileNumber',
		async: false,
		cache: false,
		data:{userMobile :userMobile},
		success: function(response){
			if(response!=""){
				check= false;
				$("#mobileNumber").val('');
				$("#finalFlag").val('false');
				$('#mobileNumberErrorId').html("<b><font color='red'>"+response+"</font></b>");
			}else{
				$("#finalFlag").val("");
			}
		},	error: function(errorThrown){ 
		
			
			return false;	}
	});
	return check;
}

var radioboxid;
function getRaioTextValue(selectedRadioTdId,divId){

    
	$("#newPassword").val('');
	$("#cnfPassword").val('');
	
	$("#lable_cnfPasswordErrorId").html('');
		$("#lable_emailOrUserIdErrorId").html('');
	$('#newPassword').attr("value", "");
	$('#cnfPassword').attr("value", "");
			$("#lable_emailOrUserIdErrorId").html('');
		 $("#lable_newPasswordErrorId").html("");
		$("#lable_cnfPasswordErrorId").html('');

	$("#emailMobileUserTextboxTable").remove();
	$('#notMatchMessage').html('');
	
	//$('#emailMobileUserTextbox').remove();
	var selectedRadioType=$("#"+selectedRadioTdId).text().trim();
	radioboxid=selectedRadioType;
	
	
	var errorId="'lable_emailOrUserIdErrorId'";
	//alert(" get RadioTextValue :"+selectedRadioType +" div Id :"+divId);
	if(selectedRadioType==='Mobile Number'){
		
		var html='<table id="emailMobileUserTextboxTable" width="60%">'+
        '<tr id="emailMobileUserTextbox">'+
	      '<td id="selectedRadioTypeId" align="right" width="45%"><font color="red">*&nbsp;</font>'+selectedRadioType+'&nbsp;:&nbsp;&nbsp;</td><td width="55%" align="left"><input type="text" id="emailOrUserId" name="'+selectedRadioType+'" maxlength="10" onkeypress="onlyNumric(event,'+errorId+');validatemob();" onclick="emptyerror(event,'+errorId+');" /></td>'+
	      '</tr>'+
	      '<tr><td  width="45%"></td><td width="55%" id="lable_emailOrUserIdErrorId" align="left"></td></tr>'+
	      '</table>';
	}else{
 var html='<table id="emailMobileUserTextboxTable" width="60%">'+
           '<tr id="emailMobileUserTextbox">'+
	      '<td id="selectedRadioTypeId" align="right" width="45%"><font color="red">*&nbsp;</font>'+selectedRadioType+'&nbsp;:&nbsp;&nbsp;</td><td width="55%" align="left"><input type="text" id="emailOrUserId" name="'+selectedRadioType+'" onclick="emptyerror(event,'+errorId+');" onkeypress="validatemob();"/></td>'+
	      '</tr>'+
	      '<tr><td  width="45%"></td><td width="55%" id="lable_emailOrUserIdErrorId" align="left"></td></tr>'+
	      '</table>';
	}
 $(html).appendTo($("#"+divId));
 $("#"+divId).show();
 
 
 
 
 
 $('#resetByErrorId').html("");
// $("#"+selectedRadioTdId).attr('checked', 'checked');
 //$('#emailMobileUserTextbox').remove();
	
}

function validateResetPasswordPage(){
		//alert("validationResetPasswordPage ");
	
	var completeCheck = true;
	
	
	
	//********************************* Check Radio Button ************************************************
	if(!($('#email').is(":checked")) && (!($('#mobile').is(":checked"))) && (!($('#userName').is(":checked"))))
	{
		$('#resetByErrorId').html("");
		$('#resetByErrorId').html("<b><font color='red'>Kindly check atleast one radio button !</font></b>");
		completeCheck = false;
	}
	else{
		var emailMobileUserId=$("#emailOrUserId").val().trim();
		var selectedRadioType=$("#selectedRadioTypeId").text().trim();
		if(emailMobileUserId.length<=0){
			
			$("#lable_emailOrUserIdErrorId").html('<b><font color=red>Kindly enter  '+selectedRadioType.substring(2,selectedRadioType.length-1)+ '</font></b>');
			 completeCheck = false;
		}
	}
	
	/* if(!($('#email').is(':checked')) && !($('#mobile').is(':checked')) && !($('#userName').is(':checked')))
	 {
		// alert("hyfghgh ");
		 $('#resetByErrorId').html("");
		 $('#resetByErrorId').html("<b><font color='red'>Kindly Choose One Radio  !</font></b>");
		 completeCheck = false;
	 }
	 else{
		 $('#resetByErrorId').html("<b><font color='red'>Kindly Choose One Radio  !</font></b>");
		 completeCheck = false;
	 }*/
	var newPassword=$("#newPassword").val();
	
	
	if(newPassword.length<=0){
		
		 $("#lable_newPasswordErrorId").html("<b><font color='red'>Kindly enter new password</font></b>");
		 completeCheck = false;
	 }
	var cnfPassword =$("#cnfPassword").val();
	
	if(cnfPassword.length<=0){
		$("#lable_cnfPasswordErrorId").html("<b><font color='red'>Kindly enter confirm password</font></b>");
		completeCheck = false;
	}
	if(newPassword!==cnfPassword){
		
		$("#lable_cnfPasswordErrorId").html("<b><font color='red'>Password does not match</font></b>");
		completeCheck = false;
	}
	
	
	if(!completeCheck){
		
		return false;
	}
	
	
	
	
	
}

function validatemob()
{
	

//var emailId=$("#emailOrUserId").val();
	//var emailId=	element.getElementsByTagName("Email").val;
	var emailId=$("input[name='Email']").val();
var mobno=$("input[name='Mobile Number']").val();
var user=	$("input[name='UserName']").val();
//var selectedRadioType=$("#"+selectedRadioTdId).text().trim();
//alert(emailId);
//alert(mobno+"mob");
//alert(user+"user");
//alert(radioboxid+"radio");
//var emailId = document.getElementById("emailOrUserId");
	if(radioboxid==='Mobile Number')
		{
		$("#emailOrUserId").autocomplete({  
			
		    source : function(request, response) {
		    	
		    	
		  	  $.ajax({
		            url : "userMobileNoUrl",
		            type : "GET",
		            data :'mobno='+mobno, 
		            success : function(data) {
		          	  response($.map(data, function (item) {
		          	        return item.split(",");
		          	    })); 
		            }
		    });
		}
		});
		
		}
	if(radioboxid==='user'){
$("#emailOrUserId").autocomplete({  
			
		    source : function(request, response) {
		    	
		    	
		  	  $.ajax({
		            url : "userNameUrl",
		            type : "GET",
		            data :'user='+user, 
		            success : function(data) {
		          	  response($.map(data, function (item) {
		          	        return item.split(",");
		          	    })); 
		            }
		    });
		}
		});	
	}
	if(radioboxid==='Email')
	{
$("#emailOrUserId").autocomplete({  
	
    source : function(request, response) {
    	
    	
  	  $.ajax({
            url : "useremailUrl",
            type : "GET",
            data :'emailId='+emailId, 
            success : function(data) {
          	  response($.map(data, function (item) {
          	        return item.split(",");
          	    })); 
            }
    });
}
});
	}
		}

var radio="";
function radioSelect(identity)
{
	radio="";
	radio=identity;
}


function onkeyUpp()

{$('#table_id').html("");}


function nameSelect() {
	//alert("hi")
	$("#select_onbehalf")
			.autocomplete( 
					{ 
						source : function(request, response) {
							//alert("autocomplete");
							var adminUi = "/AdminUI";
							var tagName = $("#select_onbehalf").val();
							var contextPath = $("#contextPath").val();
							var hostId = $("#hostId").val();
							var controllerPath = contextPath + adminUi
							$
									.ajax({
										url : controllerPath
												+ "/autosearch/getTags",
										type : "GET",
										data : 'tagName=' + tagName + '&radio='
												+ radio + '&hostId=' + hostId,
										success : function(data) {
											//alert(data)
											if (data.length == 0) {
												$('#onbehalfErrorId')
														.html(
																"<b><font color='red'>Name Does Not Exist</font></b>");
											}
											response($.map(data,
													function(item) {
														return item.split(",");
													}));
										}
									});
						},
						/*select: function (event, ui) { 
							//alert("changed");
							getInfo(); }*/
					
					
					});
/*	$("#select_onbehalf").trigger("change");*/
}

function getInfo()
{//alert("getinfo");
	
	var personDetails = $("#select_onbehalf").val();
	//alert(personDetails)
	$("#SearchByTable").show();
	$("#SearchBy").show();
	$("#accountSearchBy").show();
	$("#SearchByAutoSearch").show();

	
	var adminUi = "/AdminUI";
	var contextPath = $("#contextPath").val();
	var controllerPath = contextPath + adminUi
	$.ajax({
		type: "get",
		url : controllerPath
		+ "/autosearch/getInfo",
		data : 'personDetails=' + personDetails,
		success: function(response){
			//alert(response)
			var valuess=response;
			if ($.isEmptyObject(response)) 
			{
				$('#errorId').html("<b><font color='red'>There are no accounts to display.</font></b>");
				$('#template_details').html('');
			}
			
			
			else
				{
					
					$("#SearchByTable").show();
					$('#table_id').html("");
					$('#table_id').html('<thead><tr class="mainTableHeader"><th>Company Name</th><th>Account Type</th><th>Address</th><th>Phone Number</th><th>E-mail Id</th><th>Host</th><th>Distributor</th><th>Sub-Distributor</th><th>Agent</th><th>Action</th></tr></thead><tbody>');
					$('#table_id').append('<tr><td align="center">'+valuess.companyName+'</td><td align="center">'+valuess.accountType+'</td><td align="center">'+valuess.address+'</td><td align="center">'+valuess.mobileNo+'</td><td align="center">'+valuess.emailId+'</td><td align="center">'+valuess.hostName+'</td><td align="center">'+valuess.distributorName+'</td><td align="center">'+valuess.subDistributorName+'</td><td align="center">'+valuess.retailerName+'</td><td align="center"><a href='+controllerPath+'/account/edit?id='+valuess.id+'><img title="edit" src='+contextPath+'/images/edit.gif style="cursor: hand" align="center"></a></td></tr>');
				}		
		}
	});
}

