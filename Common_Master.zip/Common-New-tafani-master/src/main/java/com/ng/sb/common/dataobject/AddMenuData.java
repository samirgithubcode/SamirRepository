package com.ng.sb.common.dataobject;

public class AddMenuData extends BaseObjectData {
	private static final long serialVersionUID = 1L;
	private String menuDescription;
	private String description;
	private String accountTypeId;
	private Integer menuIndex;
	private String parentId;
	private Integer placement;
	private String status;
	private String action;
	private Integer priority;
	private String accountcheckBox;
	private String[] sysAccountGroupArray;
	private Integer ismenu;
	
	public Integer getIsmenu() {
		return ismenu;
	}

	public void setIsmenu(Integer ismenu) {
		this.ismenu = ismenu;
	}

	public String[] getSysAccountGroupArray() {
		return sysAccountGroupArray;
	}

	public void setSysAccountGroupArray(String[] sysAccountGroupArray) {
		this.sysAccountGroupArray = sysAccountGroupArray;
	}

	public String getAccountcheckBox() {
		return accountcheckBox;
	}

	public void setAccountcheckBox(String accountcheckBox) {
		this.accountcheckBox = accountcheckBox;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getAccountTypeId() {
		return accountTypeId;
	}

	public void setAccountTypeId(String accountTypeId) {
		this.accountTypeId = accountTypeId;
	}

	public Integer getMenuIndex() {
		return menuIndex;
	}

	public void setMenuIndex(Integer menuIndex) {
		this.menuIndex = menuIndex;
	}

	public String getParentId() {
		return parentId;
	}

	public void setParentId(String parentId) {
		this.parentId = parentId;
	}

	public Integer getPlacement() {
		return placement;
	}

	public void setPlacement(Integer placement) {
		this.placement = placement;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public Integer getPriority() {
		return priority;
	}

	public void setPriority(Integer priority) {
		this.priority = priority;
	}

	public String getMenuDescription() {
		return menuDescription;
	}

	public void setMenuDescription(String menuDescription) {
		this.menuDescription = menuDescription;
	}

}
