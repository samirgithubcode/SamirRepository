package com.ng.bridge.dataobject.eko;

public class BankDetailRes {
	private String responsetypeid;

    private String message;

    private String responsestatusid;

    private String status;

    private BankDetailResData data;

 

    public String getMessage ()
    {
        return message;
    }

    public void setMessage (String message)
    {
        this.message = message;
    }

    
    public void setResponsestatusid (String responsestatusid)
    {
        this.responsestatusid = responsestatusid;
    }
    public String getResponsetypeid ()
    {
        return responsetypeid;
    }

    public void setResponsetypeid (String responsetypeid)
    {
        this.responsetypeid = responsetypeid;
    }
    public String getStatus ()
    {
        return status;
    }

	public BankDetailResData getData() {
		return data;
	}

	public void setData(BankDetailResData data) {
		this.data = data;
	}
    public String getResponsestatusid ()
    {
        return responsestatusid;
    }

    public void setStatus (String status)
    {
        this.status = status;
    }


 

 

	
}
