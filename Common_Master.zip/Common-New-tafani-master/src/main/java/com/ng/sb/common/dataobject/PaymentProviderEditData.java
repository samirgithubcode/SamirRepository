package com.ng.sb.common.dataobject;

import java.util.List;
import java.util.Map;

public class PaymentProviderEditData {

	private int id;
	private String payProviderName;
	private String providerCode;
	private String providerMsisdn;
	private String providerMmid;
	private Map<Integer,String> providerCategories;
	private List provCategories;
	private String providerDescription;
	
	public String getProviderDescription() {
		return providerDescription;
	}
	public void setProviderDescription(String providerDescription) {
		this.providerDescription = providerDescription;
	}
	public List getProvCategories() {
		return provCategories;
	}
	public void setProvCategories(List provCategories) {
		this.provCategories = provCategories;
	}
	public Map<Integer, String> getProviderCategories() {
		return providerCategories;
	}
	public void setProviderCategories(Map<Integer, String> providerCategories) {
		this.providerCategories = providerCategories;
	}
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the payProviderName
	 */
	public String getPayProviderName() {
		return payProviderName;
	}
	/**
	 * @param payProviderName the payProviderName to set
	 */
	public void setPayProviderName(String payProviderName) {
		this.payProviderName = payProviderName;
	}
	/**
	 * @return the providerCode
	 */
	public String getProviderCode() {
		return providerCode;
	}
	/**
	 * @param providerCode the providerCode to set
	 */
	public void setProviderCode(String providerCode) {
		this.providerCode = providerCode;
	}
	/**
	 * @return the providerMsisdn
	 */
	public String getProviderMsisdn() {
		return providerMsisdn;
	}
	/**
	 * @param providerMsisdn the providerMsisdn to set
	 */
	public void setProviderMsisdn(String providerMsisdn) {
		this.providerMsisdn = providerMsisdn;
	}
	/**
	 * @return the providerMmid
	 */
	public String getProviderMmid() {
		return providerMmid;
	}
	/**
	 * @param providerMmid the providerMmid to set
	 */
	public void setProviderMmid(String providerMmid) {
		this.providerMmid = providerMmid;
	}
	
}

