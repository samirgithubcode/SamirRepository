package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name = "inventorykeymgmt")
@XmlRootElement
//@NamedQueries({
//    @NamedQuery(name ="KeyMgmt.findByKeyId",query="SELECT k from KeyMgmt k where k.id=:keyId"),
//    @NamedQuery(name ="KeyMgmt.findByInventoryIdId",query="SELECT k from KeyMgmt k where k.inventory_id=:inventoryId"),
//    @NamedQuery(name ="KeyMgmt.findByKeyName",query="SELECT k from KeyMgmt k where k.keyName=:keyName"),
//})
public class InventoryKeyMgmt implements Serializable {
	
    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    
    @JoinColumn(name = "inventory_id", referencedColumnName = "id")
    @ManyToOne
    private InventoryMgmt inventory_id;
    
    private String keyName;
    
    private String keyValue;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public InventoryMgmt getInventory_id() {
		return inventory_id;
	}

	public void setInventory_id(InventoryMgmt inventory_id) {
		this.inventory_id = inventory_id;
	}

	public String getKeyName() {
		return keyName;
	}

	public void setKeyName(String keyName) {
		this.keyName = keyName;
	}

	public String getKeyValue() {
		return keyValue;
	}

	public void setKeyValue(String keyValue) {
		this.keyValue = keyValue;
	}

	@Override
	public String toString() {
		return "KeyMgmt [id=" + id + ", inventory_id=" + inventory_id
				+ ", keyName=" + keyName + ", keyValue=" + keyValue + "]";
	}

	public InventoryKeyMgmt(InventoryMgmt inventory_id, String keyName,
			String keyValue) {
		super();
		this.inventory_id = inventory_id;
		this.keyName = keyName;
		this.keyValue = keyValue;
	}

	public InventoryKeyMgmt() {
		super();
	}
    
	
	
	
}
