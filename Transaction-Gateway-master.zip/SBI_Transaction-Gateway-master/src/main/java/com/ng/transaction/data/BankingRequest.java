/**
 * 
 */
package com.ng.transaction.data;

import com.ng.sb.common.dataobject.ValidationBean;

/**
 * @author gopal
 *
 */
public class BankingRequest implements ValidationBean 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -5770381873555705911L;

	private BankingData payerBankAccount;
	
	private BankingData payeeBankAccount;

	private int txnAmount;
	
	private ProviderDetails provider;
	
	private WalletDetails payeeWallet;
	
	public BankingData getPayerBankAccount() {
		return payerBankAccount;
	}

	public void setPayerBankAccount(BankingData payerBankAccount) {
		this.payerBankAccount = payerBankAccount;
	}

	public BankingData getPayeeBankAccount() {
		return payeeBankAccount;
	}

	public void setPayeeBankAccount(BankingData payeeBankAccount) {
		this.payeeBankAccount = payeeBankAccount;
	}

	public int getTxnAmount() {
		return txnAmount;
	}

	public void setTxnAmount(int txnAmount) {
		this.txnAmount = txnAmount;
	}

	public ProviderDetails getProvider() {
		return provider;
	}

	public void setProvider(ProviderDetails provider) {
		this.provider = provider;
	}

	public WalletDetails getPayeeWallet() {
		return payeeWallet;
	}

	public void setPayeeWallet(WalletDetails payeeWallet) {
		this.payeeWallet = payeeWallet;
	}
	
}
