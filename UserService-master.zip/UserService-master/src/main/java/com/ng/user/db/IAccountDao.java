/**
 * 
 */
package com.ng.user.db;

import java.util.List;

import com.ng.sb.common.model.AccountLoginInfo;
import com.ng.sb.common.model.AgentApiMapping;
import com.ng.sb.common.model.InternalAccountMaster;
import com.ng.user.dto.TxnHistoryRequest;
import com.ng.user.dto.TxnHistoryResponse;

/**
 * @author gopal
 *
 */
public interface IAccountDao extends IBaseDao {

	public List<TxnHistoryResponse> getTxnHistory(TxnHistoryRequest txnHistoryRequest);
	
	public InternalAccountMaster getInternalAccountMaster(String accountNumber, String accountType);
	
	public List<AgentApiMapping> getServiceMappings(AccountLoginInfo accountLoginInfo);
}
