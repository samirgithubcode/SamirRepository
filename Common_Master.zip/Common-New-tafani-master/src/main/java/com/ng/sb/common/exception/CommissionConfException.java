/**
 * 
 */
package com.ng.sb.common.exception;

/**
 * @author gaurav
 *
 */
public class CommissionConfException extends Exception {
	
	public CommissionConfException(String message){
		super(message);
	}

}
