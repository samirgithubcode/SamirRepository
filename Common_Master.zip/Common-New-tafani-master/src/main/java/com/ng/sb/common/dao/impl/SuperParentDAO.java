/**
 * 
 */
package com.ng.sb.common.dao.impl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ng.sb.common.dao.IDAO;
import com.ng.sb.common.dataobject.BaseObjectData.MappingEnum;
import com.ng.sb.common.dataobject.BaseObjectData.UserType;
import com.ng.sb.common.exception.GenericException;
import com.ng.sb.common.model.AccountInfo;
import com.ng.sb.common.model.AccountInfoMapping;
import com.ng.sb.common.model.SysAccountGroup;
//code refactor by Ram [3-MAR-16]
import com.ng.sb.common.util.SystemConstant;

/**
 * @author gaurav
 * Abstract DAO which will contain common Implementation. 
 */
@Repository(value=SystemConstant.SUPER_PARENT_DAO)
public  class SuperParentDAO implements IDAO,Serializable {
	private static final Logger LOGGER = LoggerFactory.getLogger(SuperParentDAO.class);
	private static final long serialVersionUID = 1L;
	
	@PersistenceContext
	protected transient EntityManager entityManager;
	
	@PersistenceContext
	@Qualifier("entityManagerFactory1")
	protected transient EntityManager entityManager1;
	
	public List<AccountInfoMapping> getAcctInfoMapping(Integer sourceId,MappingEnum mappingType)
	{
		List<AccountInfoMapping> resultData = new ArrayList<>();
		if(sourceId!=null && sourceId>0 && mappingType!=null){
			try {
				resultData = getMappings(sourceId, mappingType,null);
			} catch (Exception e) {
				LOGGER.info("**Exception Occure in Method in AbstractDAO :"+e);
			}
		}
		return resultData;
	}
	
	public List<AccountInfoMapping> getAcctInfoMapping(Integer sourceId,MappingEnum mappingType,UserType userType){
		List<AccountInfoMapping> resultData = new ArrayList<>();
		if(sourceId!=null && sourceId>0 && mappingType!=null){
			try {
				resultData= getMappings(sourceId, mappingType,userType);
			} catch (Exception e) {
				LOGGER.info("**Exception Occure  in AbstractDAO :"+e);
			}
		}
		return resultData;
	}
	
	public List<AccountInfoMapping> getAcctInfoMapping2(Integer destinationId,MappingEnum mappingType){
		List<AccountInfoMapping> resultData = new ArrayList<>();
		if(destinationId!=null && destinationId>0 && mappingType!=null){
			resultData= getMappings2(destinationId, mappingType);
		}
		return resultData;
	}
	//HOST_ALL_WALLETS_MAPPING
	private List<AccountInfoMapping> getMappings(Integer sourceId,MappingEnum mappingType,UserType userType) {
		List<String> mapTypeList=new ArrayList<>();
		TypedQuery<AccountInfoMapping> query;
		try
		{
		if(mappingType==MappingEnum.HOST_ALL_WALLETS_MAPPING){
			mapTypeList.add(MappingEnum.HOST_EWALLET_MAPPING.name());
			mapTypeList.add(MappingEnum.HOST_IWALLET_MAPPING.name());
			mapTypeList.add(MappingEnum.HOST_FSP_MAPPING.name());
		}
		else if(mappingType==MappingEnum.HOST_ALL_WALLETS_AND_PARTNERS_MAPPING){
				mapTypeList.add(MappingEnum.HOST_EWALLET_MAPPING.name());
				mapTypeList.add(MappingEnum.HOST_IWALLET_MAPPING.name());
				mapTypeList.add(MappingEnum.HOST_FSP_MAPPING.name());
				mapTypeList.add(MappingEnum.HOST_PARTNER_MAPPING.name());
		}
		else{
			mapTypeList.add(mappingType.name());
		}
		if(userType==null){
			entityManager.createNamedQuery("AccountInfoMapping.findRelBySource", AccountInfoMapping.class);
		}else{
			query=entityManager.createNamedQuery("AccountInfoMapping.findBySourceIdAndMappingTypeAndWalletType", AccountInfoMapping.class);
			query.setParameter("walletType", userType.name());
		}
		query=entityManager.createNamedQuery("AccountInfoMapping.findRelBySource", AccountInfoMapping.class);
		query.setParameter("sourceId", sourceId);
		query.setParameter("mappingType", mapTypeList);
		return query.getResultList();
		}
		catch(Exception exception)
		{
			LOGGER.info("**Exception Occure  in AbstractDAO :"+exception);
			return new ArrayList<>();
		}
	}
	private List<AccountInfoMapping> getMappings2(Integer destinationId,MappingEnum mappingType){
		List<String> mapTypeList=new ArrayList<>();
		TypedQuery<AccountInfoMapping> query;
		if(mappingType==MappingEnum.HOST_ALL_WALLETS_MAPPING){
			mapTypeList.add(MappingEnum.HOST_EWALLET_MAPPING.name());
			mapTypeList.add(MappingEnum.HOST_IWALLET_MAPPING.name());
			mapTypeList.add(MappingEnum.HOST_FSP_MAPPING.name());
		}else{
			mapTypeList.add(mappingType.name());
		}
		query=entityManager.createNamedQuery("AccountInfoMapping.findRelByDestination", AccountInfoMapping.class);
		query.setParameter("destinationId", destinationId);
		query.setParameter("mappingType", mapTypeList);
		return query.getResultList();
	}
	
	@Transactional
	public List<AccountInfo> getAccountInfoByGroupId(Integer accountGroupId){
		LOGGER.info("****Start Method getAccountInfoByGroupId() in AbstractDAO ");
		List<AccountInfo> accountInfoList=null;
		TypedQuery<AccountInfo> query = null;
		try{
			query = entityManager.createNamedQuery("AccountInfo.findByAccountGroupId",AccountInfo.class);
			query.setParameter("accountGroupId",accountGroupId);
			accountInfoList=query.getResultList();
		}
		catch(Exception e){ 
			LOGGER.info("**Exception Occure in Method in getAccountInfoByGroupId() in AbstractDAO :"+e);
			throw new GenericException(e.getMessage());
		}
		return accountInfoList;
	}
	@Transactional
	public AccountInfo getAccountInfoById(Integer id){
		LOGGER.info("*****Start Method getAccountInfoById() in AbstractDAO ");
		TypedQuery<AccountInfo> query = null;
		try{
			query = entityManager.createNamedQuery("AccountInfo.findById", AccountInfo.class);
			query.setParameter("id",id);
			return query.getSingleResult();
		}
		catch(Exception e){
			LOGGER.info("Exception in getAccountInfoById() in AbstractDAO : "+e);
			throw new GenericException(e.getMessage());
		}
	}
	
	@Transactional
	public void saveAccountInfoMapping(AccountInfoMapping accountInfoMapping){
		LOGGER.info("*****Start Method saveAccountInfoMapping() in AbstractDAO ");
		try{
			
			AccountInfo sourceId = accountInfoMapping.getSourceId();
			AccountInfo destinationId = accountInfoMapping.getDestinationId();
			String mappingType = accountInfoMapping.getMappingType();
			
			TypedQuery<AccountInfoMapping> query = entityManager.createNamedQuery("AccountInfoMapping.findBySourceIdDestionationIdAndMappingType", AccountInfoMapping.class);
			query.setParameter("sourceId",sourceId);
			query.setParameter("destinationId",destinationId);
			query.setParameter("mappingTypes",mappingType);
			List<AccountInfoMapping> accountInfoMaps =  query.getResultList();
			if(!accountInfoMaps.isEmpty())
			{
				entityManager.merge(accountInfoMapping);
				
			}
			entityManager.persist(accountInfoMapping);
			
		}
		catch(Exception e){
			LOGGER.info("Exception occured in  AbstractDAO : "+e);
		
		}
		
	}
	
	public List<AccountInfo> getAccountInfoByParentId(Integer parentId) {
		List<AccountInfo> list=new ArrayList<>();
		try{
			TypedQuery<AccountInfo> query = entityManager.createNamedQuery("AccountInfo.findByParentId", AccountInfo.class);
			query.setParameter("parentId",new AccountInfo(parentId));
			list=query.getResultList();
		}
		catch(Exception e){
			LOGGER.info("Exception occured in  AbstractDAO : "+e);	
		}
		return list;
	}
	
	
	/**
	 * @param serviceCategoryId
	 * @return
	 */
	
	
	//code refactor by Ram [3-MAR-16]
	
	
	@Transactional
	public List<AccountInfoMapping> getMappingsForPartnerAndWallets(MappingEnum mappingType){
		List<String> mapTypeList=new ArrayList<>();
		List<AccountInfoMapping> accountInfoMaps = new ArrayList<>();
		TypedQuery<AccountInfoMapping> query;
		if(mappingType==MappingEnum.HOST_ALL_WALLETS_MAPPING){
			mapTypeList.add(MappingEnum.HOST_FSP_MAPPING.name());
			mapTypeList.add(MappingEnum.HOST_EWALLET_MAPPING.name());
			mapTypeList.add(MappingEnum.HOST_IWALLET_MAPPING.name());
		}
		else if(mappingType==MappingEnum.HOST_ALL_WALLETS_AND_PARTNERS_MAPPING){
				
				mapTypeList.add(MappingEnum.HOST_IWALLET_MAPPING.name());
				mapTypeList.add(MappingEnum.HOST_EWALLET_MAPPING.name());
				mapTypeList.add(MappingEnum.HOST_PARTNER_MAPPING.name());
				mapTypeList.add(MappingEnum.HOST_FSP_MAPPING.name());
		}
		else{
			mapTypeList.add(mappingType.name());
		}
		try{
			query=entityManager.createNamedQuery("AccountInfoMapping.findByMappingType", AccountInfoMapping.class);
			query.setParameter("mappingTypes", mapTypeList);
			accountInfoMaps =  query.getResultList();
		}
		catch(Exception e){ 
			LOGGER.info("Exception Occured in Method in getMappingsForPartnerAndWallets() in AbstractDao :"+e);
		}
		return accountInfoMaps;
	}
	
	
	public boolean updateObject(Object obj){
		LOGGER.info("****Start Method updateDbObject() ************");
		boolean flag=true;
		try{
			entityManager.merge(obj);	
		}
		catch(Exception e){ 
			LOGGER.info("**Exception Occure in Method in updateDbObject():"+e);
			flag=false;
		}
		return flag;
	}
	
	public SysAccountGroup getSysAccountGroupById(int id){
		SysAccountGroup group=new SysAccountGroup();
		try{
			TypedQuery<SysAccountGroup> query =entityManager.createNamedQuery("SysAccountGroup.findById",SysAccountGroup.class);
			query.setParameter("id",id);
			group=query.getSingleResult();
		}
		catch(Exception e){
			LOGGER.info("**Exception Occure in Method in getSysAccountGroupById():"+e);
		}
		return group;
	}

	@Override
	public boolean persistObject(Object entity) 
	{
		if(entity == null)
			return false;
		
		try{
			
			entityManager.persist(entity);
			
			return true;
		}catch(Exception e)
		{
			LOGGER.info(""+e);
		}
	    
		return false;
	}
	
}
