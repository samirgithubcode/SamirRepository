/**
 * 
 */
package com.ng.sb.common.dataobject;

import java.io.Serializable;
import java.util.List;

import com.ng.sb.common.model.CustomerCards;
import com.ng.sb.common.model.CustomerDetails;
import com.ng.sb.common.model.CustomerWallets;
import com.ng.sb.common.model.OverlayMerchants;
import com.ng.sb.common.model.PayeeDetails;

/**
 * @author gopal
 *
 */
public class CustomerAccountData implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5154532123021119276L;
	
	private List<CustomerDetails> accountData;
	
	private List<CustomerWallets> walletData;

	private List<CustomerCards> cardsData;
	
	private List<PayeeDetails> payeeData;
	
	private List<OverlayMerchants> merchantData;
	
	private String customerMsisdn;

	private String overlayToken;
	
	public List<CustomerDetails> getAccountData() {
		return accountData;
	}

	public void setAccountData(List<CustomerDetails> accountData) {
		this.accountData = accountData;
	}

	
	public String getCustomerMsisdn() {
		return customerMsisdn;
	}

	public void setCustomerMsisdn(String customerMsisdn) {
		this.customerMsisdn = customerMsisdn;
	}

	public List<CustomerWallets> getWalletData() {
		return walletData;
	}

	public void setWalletData(List<CustomerWallets> walletData) {
		this.walletData = walletData;
	}

	public List<CustomerCards> getCardsData() {
		return cardsData;
	}

	public void setCardsData(List<CustomerCards> cardsData) {
		this.cardsData = cardsData;
	}

	public List<PayeeDetails> getPayeeData() {
		return payeeData;
	}

	public void setPayeeData(List<PayeeDetails> payeeData) {
		this.payeeData = payeeData;
	}

	public List<OverlayMerchants> getMerchantData() {
		return merchantData;
	}

	public void setMerchantData(List<OverlayMerchants> merchantData) {
		this.merchantData = merchantData;
	}

	public String getOverlayToken() {
		return overlayToken;
	}

	public void setOverlayToken(String overlayToken) {
		this.overlayToken = overlayToken;
	}
	
}
