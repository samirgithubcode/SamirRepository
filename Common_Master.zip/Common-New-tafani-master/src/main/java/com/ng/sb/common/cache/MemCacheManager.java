/**
 * 
 */
package com.ng.sb.common.cache;

import org.slf4j.Logger;

import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache.ValueWrapper;
import org.springframework.stereotype.Component;

import com.google.code.ssm.spring.SSMCache;
import com.google.code.ssm.spring.SSMCacheManager;

/**
 * @author gopal
 *
 */
@Component("cacheManager")
public class MemCacheManager {
	private static final Logger LOGGER = LoggerFactory.getLogger(MemCacheManager.class);
	@Autowired
    private SSMCacheManager	 ssmCacheManager;
	
	
	public boolean isKeyAvailable(Object cacheKey, MemCacheUtils cache) 
	{
		try{
			
			if(cacheKey == null || cache == null)
			{
				return false;
			}
			
			SSMCache ssmCache = ssmCacheManager.getCache(cache.getCacheName());
			
			if(ssmCache == null)
			{
				return false;
			}
			
		 ValueWrapper wrapper = ssmCache.get(cacheKey);
		
		  return (wrapper == null)?false:true;
		  
		}catch(RuntimeException e)
		{
			LOGGER.info(""+e);
			throw e;
		}
	}
	
	
	
	public boolean addToCache(Object cacheKey, Object cacheValue, MemCacheUtils cache)
	{
		try{
			
			if(cacheKey == null || cache == null)
			{
				return false;
			}
			
			SSMCache ssmCache = ssmCacheManager.getCache(cache.getCacheName());
			
			if(ssmCache == null)
			{
				return false;
			}
			
		  ssmCache.put(cacheKey, cacheValue);
		
		  return true;
		  
		}catch(RuntimeException e)
		{
			LOGGER.info(""+e);
			throw e;
		}
	}
	
	public boolean addToCacheIfAbsent(Object cacheKey, Object cacheValue, MemCacheUtils cache) 
	{
		try{
			
			if(cacheKey == null || cache == null)
			{
				return false;
			}
			
			SSMCache ssmCache = ssmCacheManager.getCache(cache.getCacheName());
			
			if(ssmCache == null)
			{
				return false;
			}
			
		  ssmCache.putIfAbsent(cacheKey, cacheValue);
		
		  return true;
		  
		}catch(RuntimeException e)
		{
			LOGGER.info(""+e);
			throw e;
		}
	}
	
	public boolean removeFromCache(Object cacheKey, MemCacheUtils cache)
	{
		try{
			
			if(cacheKey == null || cache == null)
			{
				return false;
			}
			
			SSMCache ssmCache = ssmCacheManager.getCache(cache.getCacheName());
			
			if(ssmCache == null)
			{
				return false;
			}
			
		  ssmCache.evict(cacheKey);
		
		  return true;
		  
		}catch(RuntimeException e)
		{
			LOGGER.info(""+e);
			throw e;
		}
	}
	
	public Object getFromCache(Object cacheKey, MemCacheUtils cache)
	{
			if(cacheKey == null || cache == null)
			{
				return null;
			}
			
			SSMCache ssmCache = ssmCacheManager.getCache(cache.getCacheName());
			
		  ValueWrapper objectValue = ssmCache.get(cacheKey);
		  
		  if(objectValue != null)
		  {
			  removeFromCache(cacheKey, cache);
			  addToCache(cacheKey, objectValue.get(), cache);
			  
			  return objectValue.get();
		  }else
			  
		  return null;
	}
	
	public <T> T getFromCache(Object cacheKey,Class<T> classType, MemCacheUtils cache)
	{
		try{
			
			if(cacheKey == null || cache == null)
			{
				return null;
			}
			
			SSMCache ssmCache = ssmCacheManager.getCache(cache.getCacheName());
			
			ValueWrapper value = ssmCache.get(cacheKey);
			
			
			if(value != null && value.get() != null)
			{
				Object requested = Class.forName(classType.getName()).newInstance();
				
				Object obj = value.get();
				
				BeanUtils.copyProperties(obj, requested);
				
				removeFromCache(cacheKey, cache);
				addToCache(cacheKey, requested, cache);
				
				
				return (T)requested;
			}
		    
		}catch(Exception e)
		{
			LOGGER.info(""+e);
		}
		
		return null;
	}
	
	
	public boolean clearCache(MemCacheUtils cache) 
	{
		try{
			
			if(cache == null)
			{
				return false;
			}
			
			SSMCache ssmCache = ssmCacheManager.getCache(cache.getCacheName());
			
			if(ssmCache == null)
			{
				return false;
			}
			
		  ssmCache.clear();
		
		  return true;
		  
		}catch(RuntimeException e)
		{
			LOGGER.info(""+e);
			throw e;
		}
		
	}
	
	
}
