/**
 * 
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author gopal
 *
 */
@Entity
@Table(name="subscriber_kyc_threshold")
@NamedQueries({
@NamedQuery(name="SubscriberKycThreshold.findAll", query="SELECT th FROM SubscriberKycThreshold th"),
@NamedQuery(name="SubscriberKycThreshold.findBySubscriberId", query="SELECT th FROM SubscriberKycThreshold th where th.subscriberId=:subscriberId"),
})


public class SubscriberKycThreshold implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5094506819467873492L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	@Column(name = "subscriberId")
	private Integer subscriberId;

	@Column(name = "kyc_threshold_id")
	private Integer kycThresholdId;
	
	@Column(name = "daily_debit_limit")
	private String dailyDebitLimit;
	
	@Column(name = "daily_credit_limit")
	private String dailyCreditLimit;
	
	@Column(name = "daily_txn_count")
	private Integer dailyTxnCount;
	
	@Column(name = "monthly_debit_limit")
	private String monthlyDebitLimit;
	
	@Column(name = "monthly_credit_limit")
	private String monthlyCreditLimit;
	
	@Column(name = "monthly_txn_count")
	private Integer monthlyTxnCount;
	
	@Column(name = "yearly_debit_limit")
	private String yearlyDebitLimit;
	
	@Column(name = "yearly_credit_limit")
	private String yearlyCreditLimit;
	
	@Column(name = "yearly_txn_count")
	private Integer yearlyTxnCount;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "last_updated")
	private Date lastUpdated;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_on")
	private Date ctratiodOn;
	

	public Date getCtratiodOn() {
		return ctratiodOn;
	}

	public void setCtratiodOn(Date ctratiodOn) {
		this.ctratiodOn = ctratiodOn;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getSubscriberId() {
		return subscriberId;
	}

	public void setSubscriberId(Integer subscriberId) {
		this.subscriberId = subscriberId;
	}

	public Integer getKycThresholdId() {
		return kycThresholdId;
	}

	public void setKycThresholdId(Integer kycThresholdId) {
		this.kycThresholdId = kycThresholdId;
	}

	public String getDailyDebitLimit() {
		return dailyDebitLimit;
	}

	public void setDailyDebitLimit(String dailyDebitLimit) {
		this.dailyDebitLimit = dailyDebitLimit;
	}

	public String getDailyCreditLimit() {
		return dailyCreditLimit;
	}

	public void setDailyCreditLimit(String dailyCreditLimit) {
		this.dailyCreditLimit = dailyCreditLimit;
	}

	public Integer getDailyTxnCount() {
		return dailyTxnCount;
	}

	public void setDailyTxnCount(Integer dailyTxnCount) {
		this.dailyTxnCount = dailyTxnCount;
	}

	public String getMonthlyDebitLimit() {
		return monthlyDebitLimit;
	}

	public void setMonthlyDebitLimit(String monthlyDebitLimit) {
		this.monthlyDebitLimit = monthlyDebitLimit;
	}

	public String getMonthlyCreditLimit() {
		return monthlyCreditLimit;
	}

	public void setMonthlyCreditLimit(String monthlyCreditLimit) {
		this.monthlyCreditLimit = monthlyCreditLimit;
	}

	public Integer getMonthlyTxnCount() {
		return monthlyTxnCount;
	}

	public void setMonthlyTxnCount(Integer monthlyTxnCount) {
		this.monthlyTxnCount = monthlyTxnCount;
	}

	public String getYearlyDebitLimit() {
		return yearlyDebitLimit;
	}

	public void setYearlyDebitLimit(String yearlyDebitLimit) {
		this.yearlyDebitLimit = yearlyDebitLimit;
	}

	public String getYearlyCreditLimit() {
		return yearlyCreditLimit;
	}

	public void setYearlyCreditLimit(String yearlyCreditLimit) {
		this.yearlyCreditLimit = yearlyCreditLimit;
	}

	public Integer getYearlyTxnCount() {
		return yearlyTxnCount;
	}

	public void setYearlyTxnCount(Integer yearlyTxnCount) {
		this.yearlyTxnCount = yearlyTxnCount;
	}

	public Date getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}
		
}
