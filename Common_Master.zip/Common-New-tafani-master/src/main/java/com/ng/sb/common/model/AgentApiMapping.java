package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "agent_api_mapping")
@NamedQueries({
	@NamedQuery(name="AgentApiMapping.findAllAgents", query="SELECT DISTINCT a.agentUserId FROM AgentApiMapping a Where a.agentUserId!=NULL And a.mappingStatus=1"),
	@NamedQuery(name="AgentApiMapping.findAllAgentCompany", query="SELECT DISTINCT a.agentCompanyId FROM AgentApiMapping a Where a.agentCompanyId!=NULL And a.mappingStatus=1"),
	@NamedQuery(name="AgentApiMapping.findAgentServices", query="SELECT a.apiServiceId FROM AgentApiMapping a Where (a.agentUserId=:agentId OR a.agentCompanyId=:agentId) And a.mappingStatus=1"),
	@NamedQuery(name="AgentApiMapping.findServicesByAgent", query="SELECT a FROM AgentApiMapping a Where a.agentUserId=:agentId And a.mappingStatus=1"),
	@NamedQuery(name="AgentApiMapping.findServicesByAgentCompany", query="SELECT a FROM AgentApiMapping a Where a.agentCompanyId=:agentCompanyId And a.mappingStatus=1"),
    })
public class AgentApiMapping implements Serializable {
    private static final long serialVersionUID = 1L;
   
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
    
    @ManyToOne(optional = true)
    @JoinColumn(name = "agentUserId", referencedColumnName="id")
    private AccountLoginInfo agentUserId;
    
    @ManyToOne(optional = true)
    @JoinColumn(name = "agentCompanyId", referencedColumnName="id")
    private AccountInfo agentCompanyId;
    
    
    @ManyToOne(optional = true)
    @JoinColumn(name="apiServiceId", referencedColumnName="id")
    private ApiServices apiServiceId;
    
    @Column(name = "createdOn")
    @Temporal(TemporalType.DATE)
    private Date createdOn;
    
    @Column(name = "createdBy")
    private Integer createdBy;
    
    @Column(name = "mappingStatus" ,columnDefinition = "tinyint default true")
    private boolean mappingStatus=true;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public AccountLoginInfo getAgentUserId() {
		return agentUserId;
	}

	public void setAgentUserId(AccountLoginInfo agentUserId) {
		this.agentUserId = agentUserId;
	}

	public AccountInfo getAgentCompanyId() {
		return agentCompanyId;
	}

	public void setAgentCompanyId(AccountInfo agentCompanyId) {
		this.agentCompanyId = agentCompanyId;
	}

	public ApiServices getApiServiceId() {
		return apiServiceId;
	}

	public void setApiServiceId(ApiServices apiServiceId) {
		this.apiServiceId = apiServiceId;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public boolean isMappingStatus() {
		return mappingStatus;
	}

	public void setMappingStatus(boolean mappingStatus) {
		this.mappingStatus = mappingStatus;
	}
    
}
