package com.ng.sb.common.dataobject;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "TransactionRequestData")
public class TransactionRequestData extends BaseObjectData {
	public Integer getSubqueryid() {
		return subqueryid;
	}
	public void setSubqueryid(Integer subqueryid) {
		this.subqueryid = subqueryid;
	}
	private static final long serialVersionUID = 1L;
	private String key;
	private Integer amount;
	private String transactiontype;
	private TransactionProviderData providerData; 
	private Wallet payerWallet;
	private Wallet payeeWallet;
	private String payerTransactionId;
	private Integer subqueryid;
	public String getCheckBox() {
		return checkBox;
	}
	public void setCheckBox(String checkBox) {
		this.checkBox = checkBox;
	}
	private String checkBox; 
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	private String transactionDate;
	  private String startDate;
	    private String endDate;
	    private String txnType;
	    private Integer txnStatus;
	    private Integer  txnCount;
	private TransactionResponse[] txnResponse;
	private String transactionNature;
	private Integer closingBalance;
	private String status;
	
	private String customerId;
	
	private String customerMsisdn;
	
	private String overlayExternalNo;
	private String appName;
	private String currencyCode;

	
	public String getCurrencyCode() {
		return currencyCode;
	}
	
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
	public String getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public Integer getAmount() {
		return amount;
	}
	public void setAmount(Integer amount) {
		this.amount = amount;
	}
	public String getTransactiontype() {
		return transactiontype;
	}
	public void setTransactiontype(String transactiontype) {
		this.transactiontype = transactiontype;
	}
	public TransactionProviderData getProviderData() {
		return providerData;
	}
	public void setProviderData(TransactionProviderData providerData) {
		this.providerData = providerData;
	}
	public Wallet getPayerWallet() {
		return payerWallet;
	}
	public void setPayerWallet(Wallet payerWallet) {
		this.payerWallet = payerWallet;
	}
	public Wallet getPayeeWallet() {
		return payeeWallet;
	}
	public void setPayeeWallet(Wallet payeeWallet) {
		this.payeeWallet = payeeWallet;
	}
	public String getPayerTransactionId() {
		return payerTransactionId;
	}
	public void setPayerTransactionId(String payerTransactionId) {
		this.payerTransactionId = payerTransactionId;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getTxnType() {
		return txnType;
	}
	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}
	public Integer getTxnStatus() {
		return txnStatus;
	}
	public void setTxnStatus(Integer txnStatus) {
		this.txnStatus = txnStatus;
	}
	public Integer getTxnCount() {
		return txnCount;
	}
	public void setTxnCount(Integer txnCount) {
		this.txnCount = txnCount;
	}
	public TransactionResponse[] getTxnResponse() {
		return txnResponse;
	}
	public void setTxnResponse(TransactionResponse[] txnResponse) {
		this.txnResponse = txnResponse;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getCustomerMsisdn() {
		return customerMsisdn;
	}
	public void setCustomerMsisdn(String customerMsisdn) {
		this.customerMsisdn = customerMsisdn;
	}
	public String getOverlayExternalNo() {
		return overlayExternalNo;
	}
	public void setOverlayExternalNo(String overlayExternalNo) {
		this.overlayExternalNo = overlayExternalNo;
	}
	public String getTransactionNature() {
		return transactionNature;
	}
	public void setTransactionNature(String transactionNature) {
		this.transactionNature = transactionNature;
	}
	public Integer getClosingBalance() {
		return closingBalance;
	}
	public void setClosingBalance(Integer closingBalance) {
		this.closingBalance = closingBalance;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
}
