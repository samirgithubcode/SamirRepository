/**
 * 
 */
package com.ng.transaction.data;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.ng.sb.common.dataobject.ValidationBean;

/**
 * @author gopal
 *
 */
public class AccountData implements ValidationBean {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6568946684540055732L;
	
	private String customerId;
	
	private String accountNumber;

	private String ifscCode;
	
	private String actionByName;
	
	private String actionById;
	
	private String actionByNumber;
	
	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column (name = "addedOn")
	private Date addedOn;
}
