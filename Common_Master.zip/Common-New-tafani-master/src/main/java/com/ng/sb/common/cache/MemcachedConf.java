/**
 * 
 */
package com.ng.sb.common.cache;

import java.util.HashSet;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.google.code.ssm.CacheFactory;
import com.google.code.ssm.api.format.SerializationType;
import com.google.code.ssm.config.DefaultAddressProvider;
import com.google.code.ssm.providers.CacheConfiguration;
import com.google.code.ssm.providers.spymemcached.MemcacheClientFactoryImpl;
import com.google.code.ssm.spring.SSMCache;
import com.google.code.ssm.spring.SSMCacheManager;
import com.google.code.ssm.transcoders.JavaTranscoder;
import com.ng.sb.common.dataobject.PlatformLoginData;


/**
 * @author gopal
 *
 */
@ComponentScan("com.google.code.ssm")
@EnableCaching
@Configuration
public class MemcachedConf {
	private static final Logger LOGGER = LoggerFactory.getLogger(MemcachedConf.class);
	
    
	@Autowired
	MemcacheClientFactoryImpl clientFactory;
	@Autowired
	PlatformLoginData platformLoginData;
	
	@Bean
    public SSMCacheManager getCacheManager() 
    {
    	Set<SSMCache> caches = new HashSet<>();
    	
    	try{
			for(MemCacheUtils cache : MemCacheUtils.values())
			{
				CacheFactory cacheFactory = new CacheFactory();
			    cacheFactory.setCacheName(cache.getCacheName());
			    cacheFactory.setCacheClientFactory(clientFactory);
			    /*
			     replace platformLoginData.getLocalCacheAddress() with platformLoginData.getPnbSocketIP() at the time of deployment in server
			     */
			    cacheFactory.setAddressProvider(new DefaultAddressProvider(platformLoginData.getLocalCacheAddress()+":11211"));
			    cacheFactory.setConfiguration(cacheConfiguration());
			    cacheFactory.setDefaultSerializationType(SerializationType.JAVA);
			    cacheFactory.setJavaTranscoder(new JavaTranscoder());
				
				SSMCache ssmCache = new SSMCache(cacheFactory.getObject(), cache.getTimeToLive(), cache.isAllowClear());
				caches.add(ssmCache);
			}
    	}catch(Exception e){
    		LOGGER.debug("exception occured"+ e);    		
    	}
    	
        SSMCacheManager ssmCacheManager = new SSMCacheManager();
        ssmCacheManager.setCaches(caches);

        return ssmCacheManager;
    }
    
    
    private CacheConfiguration cacheConfiguration() {

    	CacheConfiguration cacheConfiguration = new CacheConfiguration();
    	cacheConfiguration.setConsistentHashing(true);
    	cacheConfiguration.setUseNameAsKeyPrefix(true);
    	cacheConfiguration.setKeyPrefixSeparator("#");
    	
        return cacheConfiguration;
    }
    
    @Bean
    public MemcacheClientFactoryImpl getMemcacheClient()
    {
    	return new MemcacheClientFactoryImpl();
    }
}
