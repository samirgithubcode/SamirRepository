/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "userBiller")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "UserBiller.findAll", query = "SELECT u FROM UserBiller u"),
    @NamedQuery(name = "UserBiller.findById", query = "SELECT u FROM UserBiller u WHERE u.id = :id"),
    @NamedQuery(name = "UserBiller.findByMsisdn", query = "SELECT u FROM UserBiller u WHERE u.msisdn = :msisdn"),
    @NamedQuery(name = "UserBiller.findBySubAccId", query = "SELECT u FROM UserBiller u WHERE u.subAccId = :subAccId"),
    @NamedQuery(name = "UserBiller.findByProviderCode", query = "SELECT u FROM UserBiller u WHERE u.providerCode = :providerCode"),
    @NamedQuery(name = "UserBiller.findByProviderName", query = "SELECT u FROM UserBiller u WHERE u.providerName = :providerName"),
    @NamedQuery(name = "UserBiller.findByPCatCode", query = "SELECT u FROM UserBiller u WHERE u.pCatCode = :pCatCode"),
    @NamedQuery(name = "UserBiller.findByPCatName", query = "SELECT u FROM UserBiller u WHERE u.pCatName = :pCatName"),
    @NamedQuery(name = "UserBiller.findByDate", query = "SELECT u FROM UserBiller u WHERE u.date = :date")})
public class UserBiller implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "msisdn")
    private String msisdn;
    @Basic(optional = false)
    @Column(name = "subAccId")
    private String subAccId;
    @Basic(optional = false)
    @Column(name = "providerCode")
    private int providerCode;
    @Basic(optional = false)
    @Column(name = "providerName")
    private String providerName;
    @Basic(optional = false)
    @Column(name = "pCatCode")
    private int pCatCode;
    @Column(name = "pCatName")
    private String pCatName;
    @Basic(optional = false)
    @Column(name = "date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date date;
    @JoinColumn(name = "userId", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Subscriber userId;

    public UserBiller() {
    	//default constructor
    }

    public UserBiller(Integer id) {
        this.id = id;
    }

    public UserBiller(Integer id, String msisdn, String subAccId, int providerCode, String providerName, int pCatCode, Date date) {
        this.id = id;
        this.msisdn = msisdn;
        this.subAccId = subAccId;
        this.providerCode = providerCode;
        this.providerName = providerName;
        this.pCatCode = pCatCode;
        this.date = date;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMsisdn() {
        return msisdn;
    }

    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }

    public String getSubAccId() {
        return subAccId;
    }

    public void setSubAccId(String subAccId) {
        this.subAccId = subAccId;
    }

    public int getProviderCode() {
        return providerCode;
    }

    public void setProviderCode(int providerCode) {
        this.providerCode = providerCode;
    }

    public String getProviderName() {
        return providerName;
    }

    public void setProviderName(String providerName) {
        this.providerName = providerName;
    }

    public int getPCatCode() {
        return pCatCode;
    }

   

    public void setPCatName(String pCatName) {
        this.pCatName = pCatName;
    }

   

    public Subscriber getUserId() {
        return userId;
    }

    public void setUserId(Subscriber userId) {
        this.userId = userId;
    }
    
    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
    
    public void setPCatCode(int pCatCode) {
        this.pCatCode = pCatCode;
    }

    public String getPCatName() {
        return pCatName;
    }
    

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof UserBiller)) {
            return false;
        }
        UserBiller other = (UserBiller) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.UserBiller[ id=" + id + " ]";
    }
    
}
