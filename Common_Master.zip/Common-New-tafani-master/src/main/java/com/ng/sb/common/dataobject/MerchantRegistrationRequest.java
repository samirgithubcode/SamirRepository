package com.ng.sb.common.dataobject;
import java.sql.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.web.multipart.MultipartFile;

import com.ng.sb.common.model.MerchantKyc;
public class MerchantRegistrationRequest  {


	

	/**
	 * @author abhishek
	 *
	 */





	/*"merchantId"    : 101,
	"merchantName"	: "Deepak",
	"merchantType"	: "CORPORATE_MERCHANT",
	"address" : "D-443, New Usmanpur",
	"locality" : "sdfsfgsgfs",
	"district" : "North East",
	"city" : "Delhi",
	"state" : "Delhi",
	"country" : "India",
	"pincode" : 110053,
	"longitude": "45dfg3",
	"lattitude" : "5235ss",
	"noOfTill"	: 5,
	"parentMerchantId" :1,
	"mobileNumber" : "9811221010",
	"status"	: "ACTIVE",
	"email"	: "amar@nextgentele.in",
	"loginPin" : "ssdfewrfgsewrsdfserws",
	"invoice" : "manual",
	"ifsc" : "SBIN00001189",
	"accountNumber" : "343455434535",
	"accountType" : "Saving",
	"currencyCode" : "AU",
	"merchantCategory": "Telecommunications",*/

		private static final long serialVersionUID = 1L;
		private String merchantName;
		private String lattitude;
		private String merchantType;
		private String houseNumber;
		private String city;
		private String landmark;
		private String merchantCategoryId;
		private Map<Integer, String> countries;
		private Map<Integer, String> states;
		private Integer pin;
		private Integer noOfTill;
		//private List<String> tillName;
//		private String[] tillDescription;
		private String[] tillIp;
		private String[] tillNames;
		private String[] tillName;
		private String[] tillDesc;
		private String region;
		private String address;
		private String addressTwo;
		private String  parentMerchantId;
		private Integer pinaddressId;
		private Integer pinCode;
		private String locality;
		private String district;
		private Integer state;
		private Integer country;
		private String email;
		private String mobileNumber;
		private String loginPin;
		private String invoice;
		private String statess;
		private String countrys;
		private String[] tillDescriptions;
		private String[] tillIps;
		private Integer under;
		private Map<Integer, String> corporateMerchants;
		private Integer corporateMerchant;
		private String merchantStyle;
		private String status;
		private Boolean hostDiCheck;
		private String underType;
		private String underName;
		private String encryptionKey;
		private String financialInstrument;
		private String walletName;
		private Map<Integer,String> wallets;
		private String contactNumber;
		private Integer[] walletIds;
		private Integer[] tillCheck;
		private Integer[] merchantIpIds;
		private Integer[] tillChecks;
		private Map<String,String> mapData;
		private Map<String,String> oldTils;
		private String merchantCategory;
		private Integer counterType;
		private String currencyCode;
		private Integer id;
		private Integer refmerchantInfoId;
		private String deviceTpye;
		private String externalNo;
		private String inetrnalNo;
		private Date addedOn;
		private Date addedBy;
		private Integer merchantNumber;
		private transient  MultipartFile  uploadFilePath;
		private Integer valid;
		private Integer invalid;
		private Integer records;
		private String accountNumber;
		private String ifscCode;
		private String parameterName;
		private Integer value;
		private Set setting;
		private String accountType;
		private String check;
		private String radio;
		private List<MerchantKyc> merchantKycDetails;
		private List<KYCDescriptorData> descriptorDatas;
//		private List<TillDecription> tillDesc;
		private List<MerchantKycDto> kyc;
		private List<MerchantSetting> settingDto;
		private Integer[] idProofCheck;
		private String [] idNo;
		private String merchantId;

		private String longitude;
		
		
		private String latitude;
		
		public List<KYCDescriptorData> getDescriptorDatas() {
			return descriptorDatas;
		}
		public String getMerchantCategoryId() {
			return merchantCategoryId;
		}


		public void setMerchantCategoryId(String merchantCategoryId) {
			this.merchantCategoryId = merchantCategoryId;
		}

//		public List<TillDecription> getTillDesc() {
//			return tillDesc;
//		}
	//
	//
//		public void setTillDesc(List<TillDecription> tillDesc) {
//			this.tillDesc = tillDesc;
//		}


		public List<MerchantKycDto> getKyc() {
			return kyc;
		}


		public void setKyc(List<MerchantKycDto> kyc) {
			this.kyc = kyc;
		}


		public List<MerchantSetting> getSettingDto() {
			return settingDto;
		}


		public void setSettingDto(List<MerchantSetting> settingDto) {
			this.settingDto = settingDto;
		}


		public void setDescriptorDatas(List<KYCDescriptorData> descriptorDatas) {
			this.descriptorDatas = descriptorDatas;
		}


		public List<MerchantKyc> getMerchantKycDetails() {
			return merchantKycDetails;
		}


		public void setMerchantKycDetails(List<MerchantKyc> merchantKycDetails) {
			this.merchantKycDetails = merchantKycDetails;
		}
		
		public String getRadio() {
			return radio;
		}

		
		public void setRadio(String radio) {
			this.radio = radio;
		}

		private transient MultipartFile[] file;
		
		public MultipartFile[] getFile() {
			return file;
		}

		public void setFile(MultipartFile[] file) {
			this.file = file;
		}

		public Integer[] getIdProofCheck() {
			return idProofCheck;
		}

		public void setIdProofCheck(Integer[] idProofCheck) {
			this.idProofCheck = idProofCheck;
		}


		public Set getSetting() {
			return setting;
		}

		public void setSetting(Set setting) {
			this.setting = setting;
		}

		public String getCheck() {
			return check;
		}

		public void setCheck(String check) {
			this.check = check;
		}

		public String getParameterName() {
			return parameterName;
		}

		public void setParameterName(String parameterName) {
			this.parameterName = parameterName;
		}

		public Integer getValue() {
			return value;
		}

		public void setValue(Integer value) {
			this.value = value;
		}

		public String getAccountNumber() {
			return accountNumber;
		}

		public void setAccountNumber(String accountNumber) {
			this.accountNumber = accountNumber;
		}

		public String getIfscCode() {
			return ifscCode;
		}

		public void setIfscCode(String ifscCode) {
			this.ifscCode = ifscCode;
		}

		public Integer getValid() {
			return valid;
		}

		public void setValid(Integer valid) {
			this.valid = valid;
		}

		public Integer getInvalid() {
			return invalid;
		}

		public void setInvalid(Integer invalid) {
			this.invalid = invalid;
		}

		public Integer getRecords() {
			return records;
		}

		public void setRecords(Integer records) {
			this.records = records;
		}

		public MultipartFile getUploadFilePath() {
			return uploadFilePath;
		}

		public void setUploadFilePath(MultipartFile uploadFilePath) {
			this.uploadFilePath = uploadFilePath;
		}

		public Integer getMerchantNumber() {
			return merchantNumber;
		}

		public void setMerchantNumber(Integer merchantNumber) {
			this.merchantNumber = merchantNumber;
		}

		public Integer getId() {
			return id;
		}

		public void setId(Integer id) {
			this.id = id;
		}

		public Integer getRefmerchantInfoId() {
			return refmerchantInfoId;
		}

		public void setRefmerchantInfoId(Integer refmerchantInfoId) {
			this.refmerchantInfoId = refmerchantInfoId;
		}

		public String getDeviceTpye() {
			return deviceTpye;
		}

		public void setDeviceTpye(String deviceTpye) {
			this.deviceTpye = deviceTpye;
		}

		public String getExternalNo() {
			return externalNo;
		}

		public void setExternalNo(String externalNo) {
			this.externalNo = externalNo;
		}

		public String getInetrnalNo() {
			return inetrnalNo;
		}

		public void setInetrnalNo(String inetrnalNo) {
			this.inetrnalNo = inetrnalNo;
		}

		public Date getAddedOn() {
			return addedOn;
		}

		public void setAddedOn(Date addedOn) {
			this.addedOn = addedOn;
		}

		public Date getAddedBy() {
			return addedBy;
		}

		public void setAddedBy(Date addedBy) {
			this.addedBy = addedBy;
		}

		public String getLatitude() {
			return latitude;
		}

		public void setLatitude(String latitude) {
			this.latitude = latitude;
		}

		public String getLongitude() {
			return longitude;
		}

		public void setLongitude(String longitude) {
			this.longitude = longitude;
		}

		public String getCurrencyCode() {
			return currencyCode;
		}

		public void setCurrencyCode(String currencyCode) {
			this.currencyCode = currencyCode;
		}

		public Integer getCounterType() {
			return counterType;
		}

		public void setCounterType(Integer counterType) {
			this.counterType = counterType;
		}

		public String getMerchantCategory() {
			return merchantCategory;
		}

		public String getParentMerchantId() {
			return parentMerchantId;
		}


		public void setParentMerchantId(String parentMerchantId) {
			this.parentMerchantId = parentMerchantId;
		}


		public String getLoginPin() {
			return loginPin;
		}


		public void setLoginPin(String loginPin) {
			this.loginPin = loginPin;
		}


		public String getInvoice() {
			return invoice;
		}


		public void setInvoice(String invoice) {
			this.invoice = invoice;
		}


		public String getAccountType() {
			return accountType;
		}


		public void setAccountType(String accountType) {
			this.accountType = accountType;
		}


		public void setMerchantCategory(String merchantCategory) {
			this.merchantCategory = merchantCategory;
		}

		
		
		
		public String getMerchantId() {
			return merchantId;
		}

		public void setMerchantId(String merchantId) {
			this.merchantId = merchantId;
		}

		public String getStatess() {
			return statess;
		}

		public void setStatess(String statess) {
			this.statess = statess;
		}

		public String getCountrys() {
			return countrys;
		}

		public void setCountrys(String countrys) {
			this.countrys = countrys;
		}

		
		public Integer getPinaddressId() {
			return pinaddressId;
		}

		public void setPinaddressId(Integer pinaddressId) {
			this.pinaddressId = pinaddressId;
		}

		public Integer getPinCode() {
			return pinCode;
		}

		public void setPinCode(Integer pinCode) {
			this.pinCode = pinCode;
		}

		public String getRegion() {
			return region;
		}

		public void setRegion(String region) {
			this.region = region;
		}

		public String getAddress() {
			return address;
		}

		public void setAddress(String address) {
			this.address = address;
		}

		public String getAddressTwo() {
			return addressTwo;
		}

		public void setAddressTwo(String addressTwo) {
			this.addressTwo = addressTwo;
		}

		public String getLocality() {
			return locality;
		}

		public void setLocality(String locality) {
			this.locality = locality;
		}

		public String getDistrict() {
			return district;
		}

		public void setDistrict(String district) {
			this.district = district;
		}



		public Integer getState() {
			return state;
		}

		public void setState(Integer state) {
			this.state = state;
		}

		public Integer getCountry() {
			return country;
		}

		public void setCountry(Integer country) {
			this.country = country;
		}

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		public String getMobileNumber() {
			return mobileNumber;
		}

		public void setMobileNumber(String mobileNumber) {
			this.mobileNumber = mobileNumber;
		}

		
		
		public String[] getTillNames() {
			return tillNames;
		}

		public void setTillNames(String[] tillNames) {
			this.tillNames = tillNames;
		}

		public String[] getTillDescriptions() {
			return tillDescriptions;
		}

		public void setTillDescriptions(String[] tillDescriptions) {
			this.tillDescriptions = tillDescriptions;
		}

		public String[] getTillIps() {
			return tillIps;
		}

		public void setTillIps(String[] tillIps) {
			this.tillIps = tillIps;
		}

		
		
		public Integer[] getTillChecks() {
			return tillChecks;
		}

		public void setTillChecks(Integer[] tillChecks) {
			this.tillChecks = tillChecks;
		}

		public Integer[] getMerchantIpIds() {
			return merchantIpIds;
		}

		public void setMerchantIpIds(Integer[] merchantIpIds) {
			this.merchantIpIds = merchantIpIds;
		}

		public Integer[] getTillCheck() {
			return tillCheck;
		}

		public void setTillCheck(Integer[] tillCheck) {
			this.tillCheck = tillCheck;
		}

		public String getContactNumber() {
			return contactNumber;
		}

		public void setContactNumber(String contactNumber) {
			this.contactNumber = contactNumber;
		}

		public String getWalletName() {
			return walletName;
		}

		public void setWalletName(String walletName) {
			this.walletName = walletName;
		}

		public String getFinancialInstrument() {
			return financialInstrument;
		}

		public void setFinancialInstrument(String financialInstrument) {
			this.financialInstrument = financialInstrument;
		}

		public String getUnderType() {
			return underType;
		}

		public void setUnderType(String underType) {
			this.underType = underType;
		}

		public String getMerchantName() {
			return merchantName;
		}

		public void setMerchantName(String merchantName) {
			this.merchantName = merchantName;
		}

		public String getMerchantType() {
			return merchantType;
		}

		public void setMerchantType(String merchantType) {
			this.merchantType = merchantType;
		}

		public String getHouseNumber() {
			return houseNumber;
		}

		public void setHouseNumber(String houseNumber) {
			this.houseNumber = houseNumber;
		}

		public String getCity() {
			return city;
		}

		public void setCity(String city) {
			this.city = city;
		}

		public String getLandmark() {
			return landmark;
		}

		public void setLandmark(String landmark) {
			this.landmark = landmark;
		}

		

		
		
		public Map<Integer, String> getCountries() {
			return countries;
		}

		public void setCountries(Map<Integer, String> countries) {
			this.countries = countries;
		}

		public Map<Integer, String> getStates() {
			return states;
		}

		public void setStates(Map<Integer, String> states) {
			this.states = states;
		}

		public Integer getPin() {
			return pin;
		}

		public void setPin(Integer pin) {
			this.pin = pin;
		}

		public Integer getNoOfTill() {
			return noOfTill;
		}

		public void setNoOfTill(Integer noOfTill) {
			this.noOfTill = noOfTill;
		}

//		public List<String> getTillName() {
//			return tillName;
//		}
	//
//		public void setTillName(List<String> tillName) {
//			this.tillName = tillName;
//		}

	/*	public String[] getTillDescription() {
			return tillDescription;
		}

		public void setTillDescription(String[] tillDescription) {
			this.tillDescription = tillDescription;
		}
	*/
		public Integer getUnder() {
			return under;
		}

		public Integer getCorporateMerchant() {
			return corporateMerchant;
		}

		public void setCorporateMerchant(Integer corporateMerchant) {
			this.corporateMerchant = corporateMerchant;
		}

		public String getUnderName() {
			return underName;
		}

		public void setUnderName(String underName) {
			this.underName = underName;
		}

		public void setUnder(Integer under) {
			this.under = under;
		}

		public Map<Integer, String> getCorporateMerchants() {
			return corporateMerchants;
		}

		public void setCorporateMerchants(Map<Integer, String> corporateMerchants) {
			this.corporateMerchants = corporateMerchants;
		}

		public String getMerchantStyle() {
			return merchantStyle;
		}

		public void setMerchantStyle(String merchantStyle) {
			this.merchantStyle = merchantStyle;
		}
		
		public String getStatus() {
			return status;
		}

		public void setStatus(String status) {
			this.status = status;
		}
		
		public Boolean getHostDiCheck() {
			return hostDiCheck;
		}

		public void setHostDiCheck(Boolean hostDiCheck) {
			this.hostDiCheck = hostDiCheck;
		}

		public String getEncryptionKey() {
			return encryptionKey;
		}

		public void setEncryptionKey(String encryptionKey) {
			this.encryptionKey = encryptionKey;
		}

		public void setWallets(Map<Integer,String> wallets) {
			this.wallets = wallets;
		}
		
		public Map<Integer,String> getWallets() {
			return wallets;
		}

		public Integer[] getWalletIds() {
			return walletIds;
		}

		public void setWalletIds(Integer[] walletIds) {
			this.walletIds = walletIds;
		}

		public String[] getTillIp() {
			return tillIp;
		}

		public void setTillIp(String[] tillIp) {
			this.tillIp = tillIp;
		}

		public Map<String, String> getMapData() {
			return mapData;
		}

		public void setMapData(Map<String, String> mapData) {
			this.mapData = mapData;
		}

		public Map<String, String> getOldTils() {
			return oldTils;
		}

		public void setOldTils(Map<String, String> oldTils) {
			this.oldTils = oldTils;
		}

		/**
		 * @return the idNo
		 */
		public String [] getIdNo() {
			return idNo;
		}

		/**
		 * @param idNo the idNo to set
		 */
		public void setIdNo(String [] idNo) {
			this.idNo = idNo;
		}
		public String getLattitude() {
			return lattitude;
		}
		public void setLattitude(String lattitude) {
			this.lattitude = lattitude;
		}
		public String[] getTillName() {
			return tillName;
		}
		public void setTillName(String[] tillName) {
			this.tillName = tillName;
		}
		/*public List<TillDecription> getTillDesc() {
			return tillDesc;
		}
		public void setTillDesc(List<TillDecription> tillDesc) {
			this.tillDesc = tillDesc;
		}*/
		public String[] getTillDesc() {
			return tillDesc;
		}
		public void setTillDesc(String[] tillDesc) {
			this.tillDesc = tillDesc;
		}

}
