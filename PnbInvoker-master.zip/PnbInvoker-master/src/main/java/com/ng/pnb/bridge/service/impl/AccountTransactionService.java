package com.ng.pnb.bridge.service.impl;

import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ng.pnb.bridge.dao.impl.IAccountTransactionDAO;
import com.ng.pnb.bridge.service.IAccountTransactionService;
import com.ng.pnb.invoker.util.AccountTransactionData;
import com.ng.pnb.invoker.util.AccountTransactionData.EListOrString;
import com.ng.sb.common.dataobject.BankAccount;
import com.ng.sb.common.dataobject.BridgeDataObject;
import com.ng.sb.common.dataobject.BridgeDataObject.ServiceType;
import com.ng.sb.common.dataobject.Wallet;
import com.ng.sb.common.exception.BankingException;
import com.ng.sb.common.model.Account;
import com.ng.sb.common.model.AccountTransaction;
import com.ng.sb.common.model.CustomerWallets;
import com.ng.sb.common.model.Partner;
import com.ng.sb.common.model.WalletCredentials;
import com.ng.sb.common.util.EncryptionUtils;
import com.ng.sb.common.util.SystemConstant;

@Service("AccountTransactionService")
public class AccountTransactionService implements IAccountTransactionService{

	@Autowired IAccountTransactionDAO iAccountTransactionDAO;
	private static final Logger LOGGER = LoggerFactory.getLogger(AccountTransactionService.class);
	@Override
	public AccountTransactionData performTransaction(BridgeDataObject bridgeDataObject) throws Exception 
	{
		LOGGER.info("Execution start of performTransaction() method in AccountTransactionService");
		AccountTransactionData accountTransactionData = new AccountTransactionData();
		try
		{
		if(bridgeDataObject!=null && bridgeDataObject.getServiceType()!=null)
		{
			if(bridgeDataObject.getServiceType()==ServiceType.OTH_PAY_RET_WALLET_TO_B ||  bridgeDataObject.getServiceType()==ServiceType.OTH_PAY_INDI_WALLET_TO_B)
			{
				LOGGER.info("Execution start for WALLET to BANK FUND TRANSFER");
				Account payerWallet = validateWallet(bridgeDataObject.getPayerWallet());
				Account payeeAccount = validateBankAccount(bridgeDataObject.getPayeeBankAccount());
				
				if(validateWalletPIN(bridgeDataObject.getPayerWallet()))
				{
					AccountTransaction accountTransaction = doTransactions(payerWallet, payeeAccount, bridgeDataObject);
					if(accountTransaction!=null){
						accountTransactionData.setSuccess(true);
						accountTransactionData.setSuccessMessage("your  "+accountTransaction.getPayerAccId().getwalletId().getName()+"  wallet having id  "+accountTransaction.getPayerAccId().getMobileNumber()+"  has been debited succesfully with amount INR"+accountTransaction.getTxnAmount());
						accountTransactionData.setSuccessMessage("Fund transfer from your  "+accountTransaction.getPayerAccId().getwalletId().getName()+"  wallet having id  "+accountTransaction.getPayerAccId().getMobileNumber()+"  to A/C  "+accountTransaction.getPayeeAccId().getAccNumber()+"  is successful. Your current balance is  "+accountTransaction.getPayerAccId().getBalance()+".");
						accountTransactionData.setListOrString(EListOrString.S);
					}else{
						accountTransactionData.setSuccess(false);
						accountTransactionData.setSuccessMessage("Insufficient balance in your "+accountTransaction.getPayerAccId().getwalletId().getName()+"  wallet having id  "+accountTransaction.getPayerAccId().getMobileNumber()+" for transaction.");
						accountTransactionData.setSuccessMessage("Insufficient balance in your "+payerWallet.getwalletId().getName()+"  wallet having id  "+payerWallet.getMobileNumber()+"  for transaction.");
					}
				}else{
					accountTransactionData.setSuccess(true);
					accountTransactionData.setSuccessMessage("Invalid PIN for given Wallet.");
					accountTransactionData.setListOrString(EListOrString.S);
					
				}
			}else if(bridgeDataObject.getServiceType()==ServiceType.MWALLET_AG_TOP_UP_ONLINE_W_T_W || bridgeDataObject.getServiceType()==ServiceType.OTH_PAY_RET_WALLET_TO_WALLET || bridgeDataObject.getServiceType()==ServiceType.OTH_PAY_INDI_WALLET_TO_WALLET)
			{
				LOGGER.info("Execution start for WALLET to WALLET Fund Transfer");
				Account payerWallet = validateWallet(bridgeDataObject.getPayerWallet());
				Account payeeWallet = validateWallet(bridgeDataObject.getPayeeWallet());
				
				if(validateWalletPIN(bridgeDataObject.getPayerWallet()))
				{
				
					AccountTransaction accountTransaction = doTransactions(payerWallet, payeeWallet, bridgeDataObject);
					if(accountTransaction!=null){
						accountTransactionData.setSuccess(true);
						accountTransactionData.setSuccessMessage("your  "+accountTransaction.getPayerAccId().getwalletId().getName()+"  wallet having id  "+accountTransaction.getPayerAccId().getMobileNumber()+"  has been debited succesfully with amount INR"+accountTransaction.getTxnAmount());
						accountTransactionData.setSuccessMessage("Fund transfer from your  "+payerWallet.getwalletId().getName()+"  wallet having id  "+payerWallet.getMobileNumber()+"  to  "+payeeWallet.getwalletId().getName()+"  wallet having id  "+payeeWallet.getMobileNumber()+" is successful. Your current balance is "+accountTransaction.getPayerAccId().getBalance()+".");
						accountTransactionData.setListOrString(EListOrString.S);
					}else{
						accountTransactionData.setSuccess(false);
						accountTransactionData.setSuccessMessage("Insufficient balance in your "+accountTransaction.getPayerAccId().getwalletId().getName()+"  wallet having id  "+accountTransaction.getPayerAccId().getMobileNumber()+" for transaction.");
						accountTransactionData.setSuccessMessage("Insufficient balance in your "+payerWallet.getwalletId().getName()+"  wallet having id  "+payerWallet.getMobileNumber()+"  for transaction.");
					}
				}else{
					accountTransactionData.setSuccess(true);
					accountTransactionData.setSuccessMessage("Invalid PIN for given Wallet.");
					accountTransactionData.setListOrString(EListOrString.S);
					
				}
			}else if(bridgeDataObject.getServiceType()==ServiceType.MWALLET_AG_CHK_BAL || bridgeDataObject.getServiceType()==ServiceType.MWALLET_CUST_CHK_BAL)
			{
				LOGGER.info("Execution start for WALLET BALANCE ENQUIRY");
				if(validateWalletPIN(bridgeDataObject.getPayerWallet()))
				{
					Account payerAccount = walletBalanceEnquiry(bridgeDataObject.getPayerWallet());
					
					accountTransactionData.setSuccess(true);
					accountTransactionData.setSuccessMessage("Balance in your  "+payerAccount.getwalletId().getName()+" wallet having id "+payerAccount.getMobileNumber()+" is INR"+payerAccount.getBalance());
					accountTransactionData.setListOrString(EListOrString.S);
				}else{
					accountTransactionData.setSuccess(false);
					accountTransactionData.setErrorMessage("Invalid PIN for given Wallet.");
					accountTransactionData.setListOrString(EListOrString.S);
					
				}
			}else if(bridgeDataObject.getServiceType()==ServiceType.TOP_UP_RECH_BY_WALLET || bridgeDataObject.getServiceType()==ServiceType.BILL_PAY_BY_WALLET)
			{
				LOGGER.info("Execution start for TOP_UP_RECH_BY_WALLET OR BILL_PAY_BY_WALLET");
				if(validateWalletPIN(bridgeDataObject.getPayerWallet()))
				{
					//Account payerAccount = walletBalanceEnquiry(bridgeDataObject.getPayerWallet());
					CustomerWallets wallet = getWalletCredential(bridgeDataObject.getPayerWallet());
					
					wallet.setCurrentBalance((wallet.getCurrentBalance() - bridgeDataObject.getAmount()));
					
					iAccountTransactionDAO.updateEntity(wallet);
					
					accountTransactionData.setSuccess(true);
					if(bridgeDataObject.getServiceType()==ServiceType.TOP_UP_RECH_BY_WALLET)
					accountTransactionData.setSuccessMessage("Your Recharge for "+bridgeDataObject.getProvider().getSubscriberId()+" done successfully.Current Wallet balance is : "+wallet.getCurrentBalance()+".");
					else
						accountTransactionData.setSuccessMessage("Your Bill Payment for "+bridgeDataObject.getProvider().getSubscriberId()+" done successfully.Current Wallet balance is : "+wallet.getCurrentBalance()+".");
					
					accountTransactionData.setListOrString(EListOrString.S);
				}else{
					accountTransactionData.setSuccess(false);
					accountTransactionData.setErrorMessage("Invalid PIN for given Wallet.");
					accountTransactionData.setListOrString(EListOrString.S);
					
				}
			}else if(bridgeDataObject.getServiceType()==ServiceType.SETTINGS_CREATE_PIN_WALLET)
			{
				LOGGER.info("Execution start for SETTINGS CREATE PIN WALLET");
				
				CustomerWallets walletCredentials = getWalletCredential(bridgeDataObject.getPayerWallet());
				
				/*if(walletCredentials == null)
				{
					boolean addStatus = createWalletCredential(bridgeDataObject.getPayerWallet());
					
					accountTransactionData.setSuccess(true);
					
					if(addStatus)
						accountTransactionData.setSuccessMessage("Wallet PIN created successfully for given Wallet.");
					else
						accountTransactionData.setSuccessMessage("Wallet PIN creation failed.Please try after some times.");
					
					accountTransactionData.setListOrString(EListOrString.S);	
				}else{
					
					accountTransactionData.setSuccess(true);
					accountTransactionData.setSuccessMessage("Wallet PIN is already created for given Wallet.");
					accountTransactionData.setListOrString(EListOrString.S);
				}*/
				
				if(walletCredentials == null)
				{
					
					accountTransactionData.setSuccess(true);
					accountTransactionData.setSuccessMessage("Invalid Wallet Details.");
					accountTransactionData.setListOrString(EListOrString.S);
					
				}else{
					
					if(walletCredentials.getWalletPin() != null && !walletCredentials.getWalletPin().isEmpty())
					{
						accountTransactionData.setSuccess(true);
						accountTransactionData.setSuccessMessage("Invalid Wallet Details.");
						accountTransactionData.setListOrString(EListOrString.S);
					}else{
					
					accountTransactionData.setSuccess(true);
					
					walletCredentials.setWalletPin(EncryptionUtils.sha256Hash(bridgeDataObject.getPayerWallet().getWalletPin().toString()));
					
					walletCredentials.setModifiedOn(new Date());
					
					iAccountTransactionDAO.updateEntity(walletCredentials);
					
					accountTransactionData.setSuccessMessage("Wallet PIN created successfully for given Wallet.");
					
					accountTransactionData.setListOrString(EListOrString.S);
					}
				}
				
			}else if(bridgeDataObject.getServiceType()==ServiceType.SETTINGS_CHANGE_PIN_WALLET)
			{
				LOGGER.info("Execution start for SETTINGS CHANGE PIN WALLET");
				
				CustomerWallets walletCredentials = getWalletCredential(bridgeDataObject.getPayerWallet());
				
				if(walletCredentials == null)
				{
					accountTransactionData.setSuccess(true);
					accountTransactionData.setSuccessMessage("Invalid Wallet Details.");
					accountTransactionData.setListOrString(EListOrString.S);
					
						
				}else{
					
					if(walletCredentials.getWalletPin() == null || walletCredentials.getWalletPin().isEmpty())
					{
						accountTransactionData.setSuccess(true);
						accountTransactionData.setSuccessMessage("Wallet PIN not created.");
						accountTransactionData.setListOrString(EListOrString.S);
					}else{
					
					accountTransactionData.setSuccess(true);
					
					if(walletCredentials.getWalletPin().equalsIgnoreCase(EncryptionUtils.sha256Hash(bridgeDataObject.getPayerWallet().getOldWalletPin().toString())))
					{
						walletCredentials.setWalletPin(EncryptionUtils.sha256Hash(bridgeDataObject.getPayerWallet().getWalletPin().toString()));
						walletCredentials.setModifiedOn(new Date());
						
					   boolean updateStatus = updateWalletCredential(walletCredentials);
					   
					   if(updateStatus)
						   accountTransactionData.setSuccessMessage("Wallet PIN updated successfully for given Wallet.");
					   else{
						   //accountTransactionData.setSuccess(false);
						   accountTransactionData.setErrorMessage("Wallet PIN updation failed for given Wallet.Please try after some times.");
					   }
					}else{
						//accountTransactionData.setSuccess(false);
						accountTransactionData.setErrorMessage("Invalid old wallet PIN for given Wallet.");
					}
					
					accountTransactionData.setListOrString(EListOrString.S);
					}
					
				}
				
			}
		}
		
	}catch(Exception e)
	{
		accountTransactionData.setSuccess(true);
		accountTransactionData.setSuccessMessage(e.getMessage());
		accountTransactionData.setListOrString(EListOrString.S);
	}
		return accountTransactionData;
	}
	
	@Transactional
	private Account bankBalanceEnquiry(BankAccount payerBankAccount) {
		Account payerAccount = null;
		try{
			LOGGER.info("Execution start of bankBalanceEnquiry in AccountTransactionService");
			payerAccount = validateBankAccount(payerBankAccount);
		}catch(Exception ex){
			ex.printStackTrace();
			LOGGER.debug("Exception caught in bankBalanceEnquiry() method of AccountTransactionService");
		}
		LOGGER.info("Execution end of bankBalanceEnquiry in AccountTransactionService");
		return payerAccount;
	}
	
	
    @Transactional
	private Account walletBalanceEnquiry(Wallet payerWallet) {
		Account payerWalletAccount = null;
		try{
			LOGGER.info("Execution start of walletBalanceEnquiry in AccountTransactionService");
			payerWalletAccount = validateWallet(payerWallet);
		}catch(Exception ex){
			ex.printStackTrace();
			LOGGER.debug("Exception caught in walletBalanceEnquiry() method of AccountTransactionService");
		}
		LOGGER.info("Execution end of walletBalanceEnquiry in AccountTransactionService");
		return payerWalletAccount;
	}
	@Transactional
	private List<AccountTransaction> miniStatement(BankAccount payerBankAccount) {
		Account payerAccount = null;
		List<AccountTransaction> accountTransactions = null;
		try{
			LOGGER.info("Execution start for miniStatement for BANK");
			payerAccount = validateBankAccount(payerBankAccount);
			accountTransactions = iAccountTransactionDAO.getMiniStatement(payerAccount);
		}catch(Exception ex){
			ex.printStackTrace();
			LOGGER.debug("Exception caught in miniStatement() method of AccountTransactionService");
		}
		return accountTransactions;
	}

	@Transactional
	private Account validateWallet(Wallet payeeWallet) {
		List<Account> accountList = null;
		Account account = null;
		Map<Integer,Partner> walletMap = new LinkedHashMap<Integer,Partner>();
		try{
			LOGGER.info("Execution start of validateWallet in AccountTransactionService");
			if(payeeWallet!=null){
				List<Partner>walletsList = iAccountTransactionDAO.fetchAllWalets();
				if(walletsList!=null){
					for(Partner partner:walletsList){
						walletMap.put(partner.getPartnerCode(),partner);
					}
				}
				accountList = iAccountTransactionDAO.validateWallet(payeeWallet,walletMap);
				if(accountList==null || accountList.isEmpty()){
					account = new Account();
					account.setBalance(SystemConstant.BALANCE);
					account.setCreateDate(new Date());
					account.setMobileNumber(payeeWallet.getMsisdn());
					account.setwalletId(walletMap.get(payeeWallet.getWalletCode()));
					account.setInstrumentType(SystemConstant.WALLETS);
					account = iAccountTransactionDAO.saveAccount(account);
				}else{
					return accountList.get(0);
				}
			}
		}catch(Exception ex){
			ex.printStackTrace();
			LOGGER.debug("Exception caught in valideateWallet() method in AccountTransactionService");
		}
		LOGGER.info("Execution end of validateWallet in AccountTransactionService");
		return account;
	}

	@Transactional
	private Account validateBankAccount(BankAccount bankAccount){
		List<Account> accountList = null;
		Account account = null;
		try{
		if(bankAccount !=null){
			accountList = iAccountTransactionDAO.validateBank(bankAccount);
			if(accountList==null||accountList.isEmpty()){
				account = new Account();
				account.setAccNumber(bankAccount.getAccountNumber());
				account.setBalance(SystemConstant.BALANCE);
				account.setMobileNumber(bankAccount.getMsisdn());
				account.setIfsc(bankAccount.getIfscCode());
				account.setInstrumentType(SystemConstant.BANK);
				account.setCreateDate(new Date());
				account = iAccountTransactionDAO.saveAccount(account);
			}else{
				return accountList.get(0);
			}
		}
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return account;
	}
	
	
	@Transactional
	private CustomerWallets getWalletCredential(Wallet walletDetails)
	{
		CustomerWallets walletCredentials = null;
		try{
		
			walletCredentials = iAccountTransactionDAO.getWallletDetails(walletDetails);
			
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return walletCredentials;
	}
	
	@Transactional
	private boolean createWalletCredential(Wallet walletDetails)
	{
		WalletCredentials walletCredentials = null;
		try{
		
			walletCredentials = new WalletCredentials();
			
			walletCredentials.setUserMsisdn(Long.parseLong(walletDetails.getMsisdn()));
			walletCredentials.setWalletId(walletDetails.getWalletCode());
			walletCredentials.setWalletPin(EncryptionUtils.sha256Hash(walletDetails.getWalletPin().toString()));
			walletCredentials.setAddedOn(new Date());
			
			boolean addStatus = iAccountTransactionDAO.saveEntity(walletCredentials);
			
			return addStatus;
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return false;
	}
	
	@Transactional
	private boolean updateWalletCredential(CustomerWallets walletCredentials)
	{
		
		try{
			
			boolean updateStatus = iAccountTransactionDAO.updateEntity(walletCredentials);
			
			return updateStatus;
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return false;
	}
	@Transactional
	private AccountTransaction doTransactions(Account payerAccount,Account payeeAccount,BridgeDataObject bridgeDataObject)
	{
		LOGGER.debug("*********** Method doTransactions() starts executing in AccountTransactionService *************");
		AccountTransaction accountTransaction=null;
		if(payerAccount!=null && payeeAccount!=null)
		{
			try
			{
				if(payerAccount.getBalance()>=bridgeDataObject.getAmount())
				{
					accountTransaction= new AccountTransaction();
					accountTransaction.setPayerAccId(payerAccount);
					accountTransaction.setPayeeAccId(payeeAccount);
					accountTransaction.setTxnAmount(bridgeDataObject.getAmount());
					accountTransaction.setCreateDate(new Date());
					iAccountTransactionDAO.saveAccountTransaction(accountTransaction);
					LOGGER.debug("*********** transaction completed in doTransactions() method in AccountTransactionService *************");
					manageBalance(accountTransaction);
				}
				else
				{
					
				}
				return accountTransaction;
			}
			catch(Exception e)
			{
				LOGGER.debug("*********** Exception at doTransactions() method in AccountTransactionService *************");
				e.printStackTrace();
			}
			}
		return accountTransaction;
	}
	
	@Transactional
	private AccountTransaction manageBalance(AccountTransaction accountTransaction)
	{
		LOGGER.debug("*********** Method managebalance() starts executing in AccountTransactionService *************");
		Account payerAccount=accountTransaction.getPayerAccId();
		Account payeeAccount=accountTransaction.getPayeeAccId();
		if(payerAccount!=null && payeeAccount!=null)
		{
			try
			{
				Integer payerBalance=payerAccount.getBalance();
				Integer payeeBalance=payeeAccount.getBalance();
				
				if(!payerAccount.equals(payeeAccount))
				{
				LOGGER.debug("*********** Inside try block of managebalance() method in AccountTransactionService *************");
				payerAccount.setBalance(payerBalance-accountTransaction.getTxnAmount());
				payeeAccount.setBalance(payeeBalance+accountTransaction.getTxnAmount());
				iAccountTransactionDAO.updateAccounts(payerAccount);
				iAccountTransactionDAO.updateAccounts(payeeAccount);
				LOGGER.debug("*********** transaction Completed in managebalance() method in AccountTransactionService *************");
				}else{
					payerAccount.setBalance(payerBalance-accountTransaction.getTxnAmount());
					iAccountTransactionDAO.updateAccounts(payerAccount);
				}
				return accountTransaction;
			}
			catch(Exception e)
			{
				LOGGER.debug("*********** Exception at managebalance() method in AccountTransactionService *************");
				e.printStackTrace();
			}
		}
		return accountTransaction;
	}
	
	
	@Transactional
	private boolean validateWalletPIN(Wallet walletDetails)
	{
		LOGGER.debug("*********** Method validateWalletPIN() starts executing in AccountTransactionService *************");
				CustomerWallets walletCredentials = getWalletCredential(walletDetails);
			
				if(walletCredentials == null)
					throw new RuntimeException("Invalid Wallet details.");
				
				if(walletCredentials.getWalletPin() == null)
					throw new RuntimeException("Wallet PIN not set for given wallet.");
				
				if(!walletCredentials.getWalletPin().isEmpty() && walletCredentials.getWalletPin().equalsIgnoreCase(EncryptionUtils.sha256Hash(walletDetails.getWalletPin().toString())))
				{
				  return true;
				}
			
			return false;
	}
	
	@Override
	public AccountTransactionData deductAmountFromBank(BridgeDataObject bridgeDataObject) throws Exception 
	{
		AccountTransactionData accountTransactionData = new AccountTransactionData();
		
		bridgeDataObject.getPayerBankAccount().setMsisdn(bridgeDataObject.getTransactionData().getMsisdn());
		
		Account payerAccount = validateBankAccount(bridgeDataObject.getPayerBankAccount());
		//Account payeeAccount = validateBankAccount(bridgeDataObject.getPayeeBankAccount());
		try
		{
		AccountTransaction accountTransaction=null;
		  if(payerAccount!=null )
		  {
			if(payerAccount.getBalance()>=bridgeDataObject.getAmount())
				{
					accountTransaction= new AccountTransaction();
					accountTransaction.setPayerAccId(payerAccount);
					accountTransaction.setPayeeAccId(payerAccount);
					accountTransaction.setTxnAmount(bridgeDataObject.getAmount());
					accountTransaction.setCreateDate(new Date());
					iAccountTransactionDAO.saveAccountTransaction(accountTransaction);
					LOGGER.debug("*********** transaction completed in doTransactions() method in AccountTransactionService *************");
					manageBalance(accountTransaction);
				}
			}
			
		  if(accountTransaction!=null){
				accountTransactionData.setSuccess(true);
				accountTransactionData.setSuccessMessage("Your "+bridgeDataObject.getProvider().getCategory().getName()+" bill for "+bridgeDataObject.getProvider().getSubscriberId()+" paid successfully.Your current balance is INR"+accountTransaction.getPayerAccId().getBalance()+".");
				//accountTransactionData.setSuccessMessage("Fund transfer from your  A/C  "+accountTransaction.getPayerAccId().getAccNumber()+"  to  A/C  "+accountTransaction.getPayeeAccId().getAccNumber()+"  is successful. Your current balance is "+accountTransaction.getPayerAccId().getBalance()+".");
				accountTransactionData.setListOrString(EListOrString.S);
			}else{
				accountTransactionData.setSuccess(false);
				accountTransactionData.setSuccessMessage("Insufficient balance in your A/C  "+payerAccount.getAccNumber()+"  for transaction.");
			}
		  
		
	   }catch(Exception e)
		{
			LOGGER.debug("*********** Exception at doTransactions() method in AccountTransactionService *************");
			e.printStackTrace();
		}
		
		return accountTransactionData;
	}
	@Override
	public AccountTransactionData billPayFromWallet(BridgeDataObject bridgeDataObject) throws Exception 
	{
		AccountTransactionData accountTransactionData = new AccountTransactionData();
		
		Account payerAccount = validateWallet(bridgeDataObject.getPayerWallet());
		
		//Account payeeAccount = validateBankAccount(bridgeDataObject.getPayeeBankAccount());
		try
		{
		AccountTransaction accountTransaction=null;
		  if(payerAccount!=null )
		  {
			if(payerAccount.getBalance()>=bridgeDataObject.getAmount())
				{
					accountTransaction= new AccountTransaction();
					accountTransaction.setPayerAccId(payerAccount);
					accountTransaction.setPayeeAccId(payerAccount);
					accountTransaction.setTxnAmount(bridgeDataObject.getAmount());
					accountTransaction.setCreateDate(new Date());
					iAccountTransactionDAO.saveAccountTransaction(accountTransaction);
					LOGGER.debug("*********** transaction completed in doTransactions() method in AccountTransactionService *************");
					manageBalance(accountTransaction);
				}
			}
			
		  if(accountTransaction!=null){
				accountTransactionData.setSuccess(true);
				accountTransactionData.setSuccessMessage("Your "+bridgeDataObject.getProvider().getCategory().getName()+" bill for "+bridgeDataObject.getProvider().getSubscriberId()+" paid successfully.Your current balance is INR"+accountTransaction.getPayerAccId().getBalance()+".");
				//accountTransactionData.setSuccessMessage("Fund transfer from your  A/C  "+accountTransaction.getPayerAccId().getAccNumber()+"  to  A/C  "+accountTransaction.getPayeeAccId().getAccNumber()+"  is successful. Your current balance is "+accountTransaction.getPayerAccId().getBalance()+".");
				accountTransactionData.setListOrString(EListOrString.S);
			}else{
				accountTransactionData.setSuccess(false);
				accountTransactionData.setSuccessMessage("Insufficient balance in your wallet  "+payerAccount.getAccNumber()+"  for transaction.");
			}
		  
		
	   }catch(Exception e)
		{
			LOGGER.debug("*********** Exception at doTransactions() method in AccountTransactionService *************");
			e.printStackTrace();
		}
		
		return accountTransactionData;
	}
	@Override
	public AccountTransactionData topUpFromWallet(BridgeDataObject bridgeDataObject) throws Exception 
	{
		
		AccountTransactionData accountTransactionData = new AccountTransactionData();
		
		Account payerAccount = validateWallet(bridgeDataObject.getPayerWallet());
		
		//Account payeeAccount = validateBankAccount(bridgeDataObject.getPayeeBankAccount());
		try
		{
		AccountTransaction accountTransaction=null;
		  if(payerAccount!=null )
		  {
			if(payerAccount.getBalance()>=bridgeDataObject.getAmount())
				{
					accountTransaction= new AccountTransaction();
					accountTransaction.setPayerAccId(payerAccount);
					accountTransaction.setPayeeAccId(payerAccount);
					accountTransaction.setTxnAmount(bridgeDataObject.getAmount());
					accountTransaction.setCreateDate(new Date());
					iAccountTransactionDAO.saveAccountTransaction(accountTransaction);
					LOGGER.debug("*********** transaction completed in doTransactions() method in AccountTransactionService *************");
					manageBalance(accountTransaction);
				}
			}
			
		  if(accountTransaction!=null){
				accountTransactionData.setSuccess(true);
				accountTransactionData.setSuccessMessage("Your "+bridgeDataObject.getProvider().getCategory().getName()+" recharge for "+bridgeDataObject.getProvider().getSubscriberId()+" done successfully.Your current wallet balance is INR"+accountTransaction.getPayerAccId().getBalance()+".");
				//accountTransactionData.setSuccessMessage("Fund transfer from your  A/C  "+accountTransaction.getPayerAccId().getAccNumber()+"  to  A/C  "+accountTransaction.getPayeeAccId().getAccNumber()+"  is successful. Your current balance is "+accountTransaction.getPayerAccId().getBalance()+".");
				accountTransactionData.setListOrString(EListOrString.S);
			}else{
				accountTransactionData.setSuccess(false);
				accountTransactionData.setSuccessMessage("Insufficient balance in your wallet  "+payerAccount.getAccNumber()+"  for transaction.");
			}
		  
		
	   }catch(Exception e)
		{
			LOGGER.debug("*********** Exception at doTransactions() method in AccountTransactionService *************");
			e.printStackTrace();
		}
		
		return accountTransactionData;
	}
	@Override
	public AccountTransactionData topUpFromBank(BridgeDataObject bridgeDataObject) throws Exception 
	{
AccountTransactionData accountTransactionData = new AccountTransactionData();
		
		bridgeDataObject.getPayerBankAccount().setMsisdn(bridgeDataObject.getTransactionData().getMsisdn());
		
		Account payerAccount = validateBankAccount(bridgeDataObject.getPayerBankAccount());
		//Account payeeAccount = validateBankAccount(bridgeDataObject.getPayeeBankAccount());
		try
		{
		AccountTransaction accountTransaction=null;
		  if(payerAccount!=null )
		  {
			if(payerAccount.getBalance()>=bridgeDataObject.getAmount())
				{
					accountTransaction= new AccountTransaction();
					accountTransaction.setPayerAccId(payerAccount);
					accountTransaction.setPayeeAccId(payerAccount);
					accountTransaction.setTxnAmount(bridgeDataObject.getAmount());
					accountTransaction.setCreateDate(new Date());
					iAccountTransactionDAO.saveAccountTransaction(accountTransaction);
					LOGGER.debug("*********** transaction completed in doTransactions() method in AccountTransactionService *************");
					manageBalance(accountTransaction);
				}
			}
			
		  if(accountTransaction!=null){
				accountTransactionData.setSuccess(true);
				accountTransactionData.setSuccessMessage("Your "+bridgeDataObject.getProvider().getCategory().getName()+" recharge for "+bridgeDataObject.getProvider().getSubscriberId()+" done successfully.Your current A/c balance is INR"+accountTransaction.getPayerAccId().getBalance()+".");
				//accountTransactionData.setSuccessMessage("Fund transfer from your  A/C  "+accountTransaction.getPayerAccId().getAccNumber()+"  to  A/C  "+accountTransaction.getPayeeAccId().getAccNumber()+"  is successful. Your current balance is "+accountTransaction.getPayerAccId().getBalance()+".");
				accountTransactionData.setListOrString(EListOrString.S);
			}else{
				accountTransactionData.setSuccess(false);
				accountTransactionData.setSuccessMessage("Insufficient balance in your A/C  "+payerAccount.getAccNumber()+"  for transaction.");
			}
		  
		
	   }catch(Exception e)
		{
			LOGGER.debug("*********** Exception at doTransactions() method in AccountTransactionService *************");
			e.printStackTrace();
		}
		
		return accountTransactionData;
	}
}
