package com.ng.sb.common.dataobject;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.NONE)
@XmlRootElement (name="responseContent")
public class SubscriberRegistrationData {
	//implements Serializable

	@XmlElement(name="msisdn",namespace="msisdn")
	private String msisdn;
	
	@XmlElement(name="externalNumber")
	private String externalNumber;
	
	@XmlElement(name="internalNumber")
	private String internalNumber;
	
	@XmlElement(name="productCode")
	private String productCode;
	
	@XmlElement(name="customerType")
	private String customerType;
	
	@XmlElement(name="masterVersion")
	private String masterVersion;
	
	@XmlElement(name="hostId")
	private String hostId;
	
	@XmlElement(name="statusMessage")
	private String statusMessage;
	
	@XmlElement(name="hostCode")
	private String hostCode;
	
	@XmlElement(name="subscriberName")
	private String subscriberName;
	
	
	public String getSubscriberName() {
		return subscriberName;
	}
	public void setSubscriberName(String subscriberName) {
		this.subscriberName = subscriberName;
	}
	public String getHostCode() {
		return hostCode;
	}
	public void setHostCode(String hostCode) {
		this.hostCode = hostCode;
	}
	public String getMasterVersion() {
		return masterVersion;
	}
	public String getStatusMessage() {
		return statusMessage;
	}
	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public void setMasterVersion(String masterVersion) {
		this.masterVersion = masterVersion;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public String getExternalNumber() {
		return externalNumber;
	}
	public void setExternalNumber(String externalNumber) {
		this.externalNumber = externalNumber;
	}
	public String getInternalNumber() {
		return internalNumber;
	}
	public void setInternalNumber(String internalNumber) {
		this.internalNumber = internalNumber;
	}
	public String getProductCode() {
		return productCode;
	}
	
	public String getCustomerType() {
		return customerType;
	}
	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}
	public String getHostId() {
		return hostId;
	}
	public void setHostId(String hostId) {
		this.hostId = hostId;
	}
	
}
