package com.ng.bridge.dataobject.eko;

public class VerifyCustResData {
	private String state;

    private String customerTypeId;

    private String customerId;

  
    public String getCustomerId ()
    {
        return customerId;
    }

    public void setCustomerId (String customerId)
    {
        this.customerId = customerId;
    }
    public String getState ()
    {
        return state;
    }

    public void setState (String state)
    {
        this.state = state;
    }
    public String getCustomerIdType ()
    {
        return customerTypeId;
    }

    public void setCustomerIdType (String customerTypeId)
    {
        this.customerTypeId = customerTypeId;
    }
 


    @Override
    public String toString()
    {
        return "ClassPojo [state = "+state+", customer_id_type = "+customerTypeId+", customer_id = "+customerId+"]";
    }
}
