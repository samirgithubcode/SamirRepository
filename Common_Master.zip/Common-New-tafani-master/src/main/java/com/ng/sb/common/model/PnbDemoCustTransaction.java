package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * @author abhishek
 *
 */
@Entity
@Table(name="pnbDemoCustTransaction")
@NamedQuery(name="PnbDemoCustTransaction.findAll", query="SELECT p FROM PnbDemoCustTransaction p")
public class PnbDemoCustTransaction implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false)
	private Integer id;

	@Column(name="payeeAccountNo")
	private String payeeAccountNo;

	@Column(name="payeeBalAftrTxn")
	private Integer payeeBalAftrTxn;

	@Column(name="payeeBalBfrTxn")
	private Integer payeeBalBfrTxn;

	@Column(name="payeeIfscCode")
	private String payeeIfscCode;

	@Column(name="payeeInstrument")
	private String payeeInstrument;

	@Column(name="payerAccountNo")
	private String payerAccountNo;

	@Column(name="payerBalAftrTxn")
	private Integer payerBalAftrTxn;

	@Column(name="payerBalBfrTxn")
	private Integer payerBalBfrTxn;

	@Column(name="payerIfscCode")
	private String payerIfscCode;

	@Column(name="payerInstrument")
	private String payerInstrument;

	@Column(name="transactionAmount")
	private Integer transactionAmount;

	@Column(name="transactionId")
	private String transactionId;

	@Column(name="transactionType")
	private String transactionType;

	//bi-directional many-to-one association to Partner
	@ManyToOne
	@JoinColumn(name="payeeWalletId")
	private Partner payeeWalletId;

	//bi-directional many-to-one association to Subscriber
	@ManyToOne
	@JoinColumn(name="payerSubscriberId")
	private Subscriber payerSubscriberId;

	//bi-directional many-to-one association to Subscriber
	@ManyToOne
	@JoinColumn(name="payeeSubscriberId")
	private Subscriber payeeSubscriberId;

	//bi-directional many-to-one association to Partner
	@ManyToOne
	@JoinColumn(name="payerWalletId")
	private Partner payerWalletId;

	public PnbDemoCustTransaction() {
		//empty
	}

	public PnbDemoCustTransaction(Integer id) {
		this.id = id;
	}
	
	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getPayeeAccountNo() {
		return this.payeeAccountNo;
	}

	public void setPayeeAccountNo(String payeeAccountNo) {
		this.payeeAccountNo = payeeAccountNo;
	}

	public Integer getPayeeBalAftrTxn() {
		return this.payeeBalAftrTxn;
	}

	public void setPayeeBalAftrTxn(Integer payeeBalAftrTxn) {
		this.payeeBalAftrTxn = payeeBalAftrTxn;
	}

	public Integer getPayeeBalBfrTxn() {
		return this.payeeBalBfrTxn;
	}

	public void setPayeeBalBfrTxn(Integer payeeBalBfrTxn) {
		this.payeeBalBfrTxn = payeeBalBfrTxn;
	}

	public String getPayeeIfscCode() {
		return this.payeeIfscCode;
	}

	public void setPayeeIfscCode(String payeeIfscCode) {
		this.payeeIfscCode = payeeIfscCode;
	}

	public String getPayeeInstrument() {
		return this.payeeInstrument;
	}

	public void setPayeeInstrument(String payeeInstrument) {
		this.payeeInstrument = payeeInstrument;
	}

	public String getPayerAccountNo() {
		return this.payerAccountNo;
	}

	public void setPayerAccountNo(String payerAccountNo) {
		this.payerAccountNo = payerAccountNo;
	}

	public Integer getPayerBalAftrTxn() {
		return this.payerBalAftrTxn;
	}

	public void setPayerBalAftrTxn(Integer payerBalAftrTxn) {
		this.payerBalAftrTxn = payerBalAftrTxn;
	}

	public Integer getPayerBalBfrTxn() {
		return this.payerBalBfrTxn;
	}

	public void setPayerBalBfrTxn(Integer payerBalBfrTxn) {
		this.payerBalBfrTxn = payerBalBfrTxn;
	}

	public String getPayerIfscCode() {
		return this.payerIfscCode;
	}

	public void setPayerIfscCode(String payerIfscCode) {
		this.payerIfscCode = payerIfscCode;
	}

	public String getPayerInstrument() {
		return this.payerInstrument;
	}

	public void setPayerInstrument(String payerInstrument) {
		this.payerInstrument = payerInstrument;
	}

	public Integer getTransactionAmount() {
		return this.transactionAmount;
	}

	public void setTransactionAmount(Integer transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	public String getTransactionId() {
		return this.transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public String getTransactionType() {
		return this.transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public Partner getPayeeWalletId() {
		return this.payeeWalletId;
	}

	public void setPayeeWalletId(Partner payeeWalletId) {
		this.payeeWalletId = payeeWalletId;
	}

	public Subscriber getPayerSubscriberId() {
		return this.payerSubscriberId;
	}

	public void setPayerSubscriberId(Subscriber payerSubscriberId) {
		this.payerSubscriberId = payerSubscriberId;
	}

	public Subscriber getPayeeSubscriberId() {
		return this.payeeSubscriberId;
	}

	public void setPayeeSubscriberId(Subscriber payeeSubscriberId) {
		this.payeeSubscriberId = payeeSubscriberId;
	}

	public Partner getPayerWalletId() {
		return this.payerWalletId;
	}

	public void setPayerWalletId(Partner payerWalletId) {
		this.payerWalletId = payerWalletId;
	}
	
	@Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof PnbDemoCustTransaction)) {
            return false;
        }
        PnbDemoCustTransaction other = (PnbDemoCustTransaction) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }
	
	@Override
	public String toString() {
		return "PnbDemoCustTransaction [id=" + id + "]";
	}

}