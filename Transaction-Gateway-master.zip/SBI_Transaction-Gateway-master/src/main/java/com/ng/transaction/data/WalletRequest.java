/**
 * 
 */
package com.ng.transaction.data;

import com.ng.sb.common.dataobject.ValidationBean;

/**
 * @author gopal
 *
 */
public class WalletRequest implements ValidationBean {

	/**
	 * 
	 */
	private static final long serialVersionUID = -9129301405300655959L;

	private int amount;
	private WalletDetails payerWallet;
	private BankingData payerBankAccount;
	private BankingData payeeBankAccount;
	private ProviderDetails provider;
	private WalletDetails payeeWallet;
	
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public WalletDetails getPayerWallet() {
		return payerWallet;
	}
	public void setPayerWallet(WalletDetails payerWallet) {
		this.payerWallet = payerWallet;
	}
	public BankingData getPayerBankAccount() {
		return payerBankAccount;
	}
	public void setPayerBankAccount(BankingData payerBankAccount) {
		this.payerBankAccount = payerBankAccount;
	}
	public ProviderDetails getProvider() {
		return provider;
	}
	public void setProvider(ProviderDetails provider) {
		this.provider = provider;
	}
	public BankingData getPayeeBankAccount() {
		return payeeBankAccount;
	}
	public void setPayeeBankAccount(BankingData payeeBankAccount) {
		this.payeeBankAccount = payeeBankAccount;
	}
	public WalletDetails getPayeeWallet() {
		return payeeWallet;
	}
	public void setPayeeWallet(WalletDetails payeeWallet) {
		this.payeeWallet = payeeWallet;
	} 
}
