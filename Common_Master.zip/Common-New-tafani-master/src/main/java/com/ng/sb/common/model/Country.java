/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Collection;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "country")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Country.findAll", query = "SELECT c FROM Country c"),
    @NamedQuery(name = "Country.findById", query = "SELECT c FROM Country c WHERE c.id = :id"),
    @NamedQuery(name = "Country.findByCountryName", query = "SELECT c FROM Country c WHERE c.countryName = :countryName"),
    @NamedQuery(name = "Country.findByCountryCode", query = "SELECT c FROM Country c WHERE c.countryCode = :countryCode"),
    @NamedQuery(name = "Country.findByCountryIsdCode", query = "SELECT c FROM Country c WHERE c.countryIsdCode = :countryIsdCode"),
    @NamedQuery(name = "Country.findByStatus", query = "SELECT c FROM Country c WHERE c.status = :status"),
    @NamedQuery(name = "Country.findByDefault1", query = "SELECT c FROM Country c WHERE c.default1 = :default1"),
    @NamedQuery(name = "Country.findByDescription", query = "SELECT c FROM Country c WHERE c.description = :description")})
public class Country implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
    @Basic(optional = false)
    @Column(name = "country_name", nullable = false, length = 20)
    private String countryName;
    @Basic(optional = false)
    @Column(name = "country_code", nullable = false)
    private int countryCode;
    @Column(name = "country_isd_code")
    private Integer countryIsdCode;
    @Column(name = "status")
    private Boolean status;
    @Column(name = "default")
    private Boolean default1;
    @Column(name = "description", length = 100)
    private String description;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "countryId")
    private Collection<State> stateCollection;
    @OneToMany(mappedBy = "country")
    private Collection<AccountInfo> accountInfoCollection;
  
	public Country() {
		//default constructor
    }

    public Country(Integer id) {
        this.id = id;
    }

    public Country(Integer id, String countryName, int countryCode) {
        this.id = id;
        this.countryName = countryName;
        this.countryCode = countryCode;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public int getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(int countryCode) {
        this.countryCode = countryCode;
    }

    public Integer getCountryIsdCode() {
        return countryIsdCode;
    }

    public void setCountryIsdCode(Integer countryIsdCode) {
        this.countryIsdCode = countryIsdCode;
    }

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }

    public Boolean getDefault1() {
        return default1;
    }

    public void setDefault1(Boolean default1) {
        this.default1 = default1;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }
    
    @XmlTransient
    public Collection<State> getStateCollection() {
        return stateCollection;
    }

    public void setStateCollection(Collection<State> stateCollection) {
        this.stateCollection = stateCollection;
    }

    @XmlTransient
    public Collection<AccountInfo> getAccountInfoCollection() {
        return accountInfoCollection;
    }

    public void setAccountInfoCollection(Collection<AccountInfo> accountInfoCollection) {
        this.accountInfoCollection = accountInfoCollection;
    }

   

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof Country)) {
            return false;
        }
       
        Country other = (Country) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }
    
   

    @Override
    public String toString() {
        return "com.ng.sb.common.model.Country[ id=" + id + " ]";
    }
    
}
