/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Collection;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "InventoryMgmt")
@XmlRootElement
@NamedQueries({
	@NamedQuery(name = "InventoryMgmt.findByProdIdandMasterVersionIdandAccountId", query = "SELECT i FROM InventoryMgmt i WHERE i.productId = :productId and i.mvId IN :mvId and i.accountId IN :accountId"),
    @NamedQuery(name = "InventoryMgmt.findAll", query = "SELECT i FROM InventoryMgmt i"),
    @NamedQuery(name = "InventoryMgmt.findAllbyAccountId", query = "SELECT i FROM InventoryMgmt i WHERE i.accountId=:accountId"),
    @NamedQuery(name = "InventoryMgmt.findAllbyAccountIdinGrouping", query = "SELECT i  FROM InventoryMgmt i WHERE i.accountId=:accountId group by i.productId,i.mvId,i.productTypeId"),
    @NamedQuery(name = "InventoryMgmt.findById", query = "SELECT i FROM InventoryMgmt i WHERE i.id = :id"),
    @NamedQuery(name = "InventoryMgmt.findByInternalNo", query = "SELECT i FROM InventoryMgmt i WHERE i.internalNo = :internalNo"),
    @NamedQuery(name = "InventoryMgmt.findByExternalNo", query = "SELECT i FROM InventoryMgmt i WHERE i.externalNo = :externalNo"),
    @NamedQuery(name = "InventoryMgmt.findByCustomerMSISDN", query = "SELECT i FROM InventoryMgmt i WHERE i.customerMSISDN = :customerMSISDN"),
    @NamedQuery(name = "InventoryMgmt.findByPossessionStatus", query = "SELECT i FROM InventoryMgmt i WHERE i.actualPossessionStatus = :possessionStatus"),
    @NamedQuery(name = "InventoryMgmt.findByProductStatus", query = "SELECT i FROM InventoryMgmt i WHERE i.productStatus = :productStatus"),
    @NamedQuery(name = "InventoryMgmt.findByAddDate", query = "SELECT i FROM InventoryMgmt i WHERE i.addDate = :addDate"),
    @NamedQuery(name = "InventoryMgmt.findByEditDate", query = "SELECT i FROM InventoryMgmt i WHERE i.editDate = :editDate"),
    @NamedQuery(name = "InventoryMgmt.findSerialNo", query = "SELECT i FROM InventoryMgmt i WHERE i.mvId=:mvId AND i.productId=:productId AND i.accountId=:accountId AND i.actualPossessionStatus=:possessionStatus"),
    @NamedQuery(name = "InventoryMgmt.findAgentByAccountIdandPossessionStatus", query = "SELECT i FROM InventoryMgmt i WHERE i.mvId=:mvId AND i.productId=:productId AND i.accountId=:accountId AND i.actualPossessionStatus=:possessionStatus AND i.customerMSISDN IS NULL"),
    @NamedQuery(name = "InventoryMgmt.findSEById", query = "SELECT i FROM InventoryMgmt i WHERE i.id = :id"),
    @NamedQuery(name = "InventoryMgmt.findSEByExternalNumber", query = "SELECT i FROM InventoryMgmt i WHERE i.externalNo = :externalNo"),
    @NamedQuery(name = "InventoryMgmt.findUserInformation", query = "SELECT i FROM InventoryMgmt i WHERE i.accountId.accountCode = :hcode AND i.mvId.code= :mvCode AND i.externalNo= :externalNo And i.productId.code= :productCode"),
    @NamedQuery(name = "InventoryMgmt.findUserByMoblie", query = "SELECT i FROM InventoryMgmt i WHERE i.customerMSISDN = :custMobile"),
    @NamedQuery(name = "InventoryMgmt.findExternalNumber", query = "SELECT i FROM InventoryMgmt i WHERE i.id= :externalNumber"),
	@NamedQuery(name = "InventoryMgmt.findAllbySold", query = "SELECT i FROM InventoryMgmt i WHERE i.customerMSISDN= NULL"),
	@NamedQuery(name = "InventoryMgmt.findSEByExternalNumberAndUnSold", query = "SELECT i FROM InventoryMgmt i WHERE i.externalNo = :externalNo"),
	@NamedQuery(name = "InventoryMgmt.findAllbyUnSold", query = "SELECT i FROM InventoryMgmt i WHERE i.customerMSISDN IS NOT NULL"),
	@NamedQuery(name = "InventoryMgmt.findExtProductMaster", query = "SELECT i FROM InventoryMgmt i WHERE i.mvId=:mvId AND i.productId=:productId AND i.externalNo=:externalNo"),
	@NamedQuery(name = "InventoryMgmt.findByExternalAndAgent", query = "SELECT i FROM InventoryMgmt i WHERE i.externalNo = :externalNo and i.accountId = :accountId "),
	@NamedQuery(name = "InventoryMgmt.findByMobileAndBankId", query = "SELECT i FROM InventoryMgmt i WHERE i.customerMSISDN = :customerMobile and i.productTypeId.bankId.id = :bankId "),
	@NamedQuery(name = "InventoryMgmt.findByCustomerId", query = "SELECT i FROM InventoryMgmt i WHERE i.customerId = :customerId "),
	@NamedQuery(name = "InventoryMgmt.findByProductMVAndSize", query = "SELECT i FROM InventoryMgmt i WHERE i.mvId=:mvId AND i.productId=:productId AND i.packageId is NULL"),
	@NamedQuery(name = "InventoryMgmt.findByProductandPackageNull", query = "SELECT i FROM InventoryMgmt i WHERE  i.productId=:productId AND i.packageId is NULL"),
	@NamedQuery(name = "InventoryMgmt.findByProductCardTypeAndSize", query ="SELECT i FROM InventoryMgmt i WHERE i.productTypeId=:cardDetailsId AND i.productId=:productId AND i.packageId is NULL"),
	@NamedQuery(name = "InventoryMgmt.findallbyAccountId&product&namemaster", query = "SELECT i FROM InventoryMgmt i WHERE i.accountId=:accountId AND i.mvId=:mv AND i.productId=:pv AND i.packageId is NOT NULL"),//(need to discuss later)
	@NamedQuery(name = "InventoryMgmt.getByPackaging", query = "SELECT i FROM InventoryMgmt i WHERE i.packageId =:packageId"),
	@NamedQuery(name = "InventoryMgmt.findAllProductsForAllUserTypeCard", query = "SELECT i FROM InventoryMgmt i WHERE i.accountId=:accountId AND i.productId=:productId AND i.actualPossessionStatus=:allotStatus AND i.productTypeId=:productTypeId"),
	@NamedQuery(name = "InventoryMgmt.findAllproductsForAllUserMasterversion", query = "SELECT i FROM InventoryMgmt i WHERE i.accountId=:accountId AND i.productId=:productId AND i.actualPossessionStatus=:allotStatus AND i.mvId=:mvId"),
	@NamedQuery(name = "InventoryMgmt.findbyLoginId", query = "SELECT i FROM InventoryMgmt i WHERE i.customerMSISDN=:loginId"),
	@NamedQuery(name = "InventoryMgmt.findByProductAndSize", query = "SELECT i FROM InventoryMgmt i WHERE   i.productId=:productId AND i.packageId is NULL"),
	@NamedQuery(name = "InventoryMgmt.findallbyAccountId&ProductId", query = "SELECT i FROM InventoryMgmt i WHERE i.accountId=:accountId AND  i.productId=:pv "),//AND i.packageId is NOT NULL(need to discuss later)
	//@NamedQuery(name = "InventoryMgmt.findByMobileAndProduct", query = "SELECT i FROM InventoryMgmt i WHERE i.productId=:productId AND i.customerMSISDN = :mobileNumber "),//AND i.packageId is NOT NULL(need to discuss later)

	
	
	@NamedQuery(name = "InventoryMgmt.findByBankIdAndMobileNumber", query = "SELECT i FROM InventoryMgmt i WHERE i.productTypeId.bankId.id=:bankId AND i.customerMSISDN = :customerMSISDN"),
	//@NamedQuery(name = "InventoryMgmt.findBycustomerMSISDNAndBankId", query = "SELECT i FROM InventoryMgmt i WHERE i.productTypeId.bankId.id=:bankId AND i.customerMSISDN = :customerMSISDN AND i.productStatus='OK' ")
	@NamedQuery(name = "InventoryMgmt.findBycustomerMSISDNAndBankId", query = "SELECT i FROM InventoryMgmt i WHERE i.productTypeId.bankId.id=:bankId AND i.customerMSISDN = :customerMSISDN"),
	@NamedQuery(name = "InventoryMgmt.findBycustomerByMSISDN", query = "SELECT i FROM InventoryMgmt i WHERE i.customerMSISDN = :customerMSISDN"),
	@NamedQuery(name = "InventoryMgmt.findByInventoryId", query = "SELECT i FROM InventoryMgmt i where i.id=:id AND i.productStatus='OK'"),

	
	@NamedQuery(name = "InventoryMgmt.findByMobileAndProduct", query = "SELECT i FROM InventoryMgmt i WHERE i.productId=:productId AND i.customerMSISDN = :mobileNumber And i.productStatus=:productStatus "),
	@NamedQuery(name = "InventoryMgmt.getTotalUnitsInStockwithMasterVersion", query = "SELECT count(i.id) from InventoryMgmt i where i.accountId = :accountId and i.actualPossessionStatus = :possessionStatus and i.productStatus = :productStatus and i.mvId = :mvId"),
	@NamedQuery(name = "InventoryMgmt.findInventoryMgmntByPackageId", query = "SELECT i from InventoryMgmt i where i.packageId=:packageId"),
	@NamedQuery(name = "InventoryMgmt.findSEByExternalNumberByAccountTypeAndPossision", query = "SELECT i FROM InventoryMgmt i WHERE i.externalNo = :externalNo AND i.accountId=:accountId AND i.actualPossessionStatus = :possessionStatus AND i.productStatus='OK'"),
	
})

public class InventoryMgmt implements Serializable {
	
	
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Column(name = "internalNo")
    private BigDecimal internalNo;
    @Column(name = "externalNo")
    private Long externalNo;
    @Column(name = "customerMSISDN")
    private String customerMSISDN;
    @Column(name = "productStatus")
    private String productStatus;
    @Column(name = "customerStatus")
    private String customerStatus;
    @Column(name = "actualPossessionStatus")
    private String actualPossessionStatus;
    @Column(name = "addDate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date addDate;
    @Column(name = "editDate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date editDate;
    
    
    @Column(name = "customerId")
    private String customerId;
    
    @JoinColumn(name = "productTypeId", referencedColumnName = "id")
    @ManyToOne
    private CardDetails productTypeId;
    @Column(name = "smsCenter")
    private String smsCenter;
    @Column(name = "PukCode")
    private String pukCode;
    @JoinColumn(name = "mvId", referencedColumnName = "id")
    @ManyToOne
    private MasterVersion mvId;
    
	@JoinColumn(name = "productId", referencedColumnName = "id")
	@ManyToOne(optional = false)
	private Products productId;
    
    @JoinColumn(name = "accountId", referencedColumnName = "id")
    @ManyToOne
    private AccountInfo accountId;
    
    @JoinColumn(name = "addById", referencedColumnName = "id")
    @ManyToOne
    private AccountLoginInfo addById;
    @JoinColumn(name = "editById", referencedColumnName = "id")
    @ManyToOne
    private AccountLoginInfo editById;

	@JoinColumn(name = "boxId", referencedColumnName = "id")
	@ManyToOne(fetch = FetchType.LAZY)
	private BoxDetails boxId;
    
    @JoinColumn(name = "packageId", referencedColumnName = "id")
    @ManyToOne(fetch = FetchType.LAZY)
    private Packaging packageId;
    
    
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "inventory_id", fetch = FetchType.LAZY)
    @Fetch(FetchMode.SELECT)
    private Collection<InventoryKeyMgmt> inventoryKeys;
    
    public AccountInfo getAccountId() {
		return accountId;
	}

	public void setAccountId(AccountInfo accountId) {
		this.accountId = accountId;
	}

	@Column(name="reasonForDeactivation")
    private String reasonForDeactivation;
    

    public InventoryMgmt() {
    	//empty
    }

    public InventoryMgmt(Integer id) {
        this.id = id;
    }

    public InventoryMgmt(InventoryMgmt invmgmnt , int count){
    	
    }
    
    public InventoryMgmt(Integer id,  BigDecimal internalNo, Long externalNo, Date addDate) {
        this.id = id;
        this.internalNo = internalNo;
        this.externalNo = externalNo;
        this.addDate = addDate;
    }

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	
    
    public CardDetails getProductTypeId() {
		return productTypeId;
	}

	public void setProductTypeId(CardDetails productTypeId) {
		this.productTypeId = productTypeId;
	}

	
    
    public String getSmsCenter() {
		return smsCenter;
	}

	public void setSmsCenter(String smsCenter) {
		this.smsCenter = smsCenter;
	}
	
	
    
    
    public Packaging getPackageId() {
		return packageId;
	}

	public void setPackageId(Packaging packageId) {
		this.packageId = packageId;
	}

	public String getActualPossessionStatus() {
		return actualPossessionStatus;
	}

	public void setActualPossessionStatus(String actualPossessionStatus) {
		this.actualPossessionStatus = actualPossessionStatus;
	}
    public BoxDetails getBoxId() {
		return boxId;
	}

	public void setBoxId(BoxDetails boxId) {
		this.boxId = boxId;
	}

	public String getPukCode() {
		return pukCode;
	}

	public void setPukCode(String pukCode) {
		this.pukCode = pukCode;
	}

	public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    
    public String getCustomerStatus() {
		return customerStatus;
	}

	public void setCustomerStatus(String customerStatus) {
		this.customerStatus = customerStatus;
	}
        public BigDecimal getInternalNo() {
        return internalNo;
    }

    public void setInternalNo(BigDecimal internalNo) {
        this.internalNo = internalNo;
    }

    public Long getExternalNo() {
        return externalNo;
    }

    public void setExternalNo(Long externalNo) {
        this.externalNo = externalNo;
    }

    public String getCustomerMSISDN() {
        return customerMSISDN;
    }

    public void setCustomerMSISDN(String customerMSISDN) {
        this.customerMSISDN = customerMSISDN;
    }

    public String getProductStatus() {
        return productStatus;
    }

    public void setProductStatus(String productStatus) {
        this.productStatus = productStatus;
    }

    public Date getAddDate() {
        return addDate;
    }

    public void setAddDate(Date addDate) {
        this.addDate = addDate;
    }

    public Date getEditDate() {
        return editDate;
    }

    public void setEditDate(Date editDate) {
        this.editDate = editDate;
    }


    
    public MasterVersion getMvId() {
        return mvId;
    }

    public void setMvId(MasterVersion mvId) {
        this.mvId = mvId;
    }

    public Products getProductId() {
        return productId;
    }

    public void setProductId(Products productId) {
        this.productId = productId;
    }


    
  

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

	

	public AccountLoginInfo getAddById() {
		return addById;
	}

	public void setAddById(AccountLoginInfo addById) {
		this.addById = addById;
	}

	public AccountLoginInfo getEditById() {
		return editById;
	}

	public void setEditById(AccountLoginInfo editById) {
		this.editById = editById;
	}

	public String getReasonForDeactivation() {
		return reasonForDeactivation;
	}

	public void setReasonForDeactivation(String reasonForDeactivation) {
		this.reasonForDeactivation = reasonForDeactivation;
	}

	@Override
    public boolean equals(Object object) {
		
	boolean	check= true;
	if(object!=null){
        if (!(object instanceof InventoryMgmt)) {
        	check= false;
        }
        InventoryMgmt other = (InventoryMgmt) object;
        if((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
	}
        return check;
        
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.InventoryMgmt[ id=" + id + " ]";
    }

	public Collection<InventoryKeyMgmt> getInventoryKeys() {
		return inventoryKeys;
	}

	public void setInventoryKeys(Collection<InventoryKeyMgmt> inventoryKeys) {
		this.inventoryKeys = inventoryKeys;
	}


    
}