function validateDenomination(event)
{
	var flag = true;
	var denominationValue = $('#denominationValue').val().trim();
	var a;
	/*for (var i = 0, j = denominationValue.length; i < j; i++) {
		if(i==0){*/
			a=denominationValue[0];
		/*}
	}*/
	if(a==0){
		
		$('#lab_denominationValueErrorId').html("<b><font color='red'>Denomination Value can not be started with zero!!</font></b>");
		$('#denominationValue').val('');
		flag= false;
	}
	
	
	
	if(denominationValue==0)
	{
		$('#lab_denominationValueErrorId').html("<b><font color='red'>Denomination Value can not be 0 !!</font></b>");
		$('#denominationValue').val('');
		flag = false;
	}
	if(denominationValue.length == 0)
	{
		$('#lab_denominationValueErrorId').html("<b><font color='red'>Denomination Value can not be empty!!</font></b>");
		flag = false;
	}
	
	
	
	
	if(flag == false)
	{
		event.preventDefault();
	}
	else
	{
		$('#denominationCreation').submit();
	}
}


function removeDenomination(rowId,id)
{
		
	$.ajax({
		type:"POST",
		url :"removeDenomination",
		data :"id="+id,
		success:function(response)
		{
		
		}
	});
	$("#denominationListTable").on('click', '.rwDel', function () {
	    $(this).closest('tr').remove();
	});
}