package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.ColumnTransformer;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;


/**
 * The persistent class for the MerchantInfo database table.
 * 
 */
@Entity
@Table(name="MerchantInfo")
@NamedQueries
({
@NamedQuery(name="MerchantInfo.findAll", query="SELECT m FROM MerchantInfo m"),
@NamedQuery(name="MerchantInfo.findByCorporateMerchant", query ="SELECT m FROM MerchantInfo m where m.type = :type"),
@NamedQuery(name="MerchantInfo.findBykey", query ="SELECT m FROM MerchantInfo m where m.threedesKey = :key"),
@NamedQuery(name="MerchantInfo.findById", query ="SELECT m FROM MerchantInfo m where m.id = :id"),
@NamedQuery(name="MerchantInfo.findByhId", query ="SELECT m FROM MerchantInfo m where m.hId = :id"),
@NamedQuery(name="MerchantInfo.findBydId", query ="SELECT m FROM MerchantInfo m where m.dId = :id"),
@NamedQuery(name="MerchantInfo.findBysdId", query ="SELECT m FROM MerchantInfo m where m.sdId = :id"),
@NamedQuery(name="MerchantInfo.findByaId", query ="SELECT m FROM MerchantInfo m where m.aId = :id"),
@NamedQuery(name="MerchantInfo.findByParentId", query ="SELECT m FROM MerchantInfo m where m.parentMerchantId = :parentMerchantId"),
@NamedQuery(name="MerchantInfo.findByContactNumber", query ="SELECT m FROM MerchantInfo m where m.aacontactNumber = :contactNumber"),
@NamedQuery(name="MerchantInfo.findByContactNumberAndId", query ="SELECT m FROM MerchantInfo m where m.id = :id AND m.aacontactNumber = :contactNumber"),
@NamedQuery(name="MerchantInfo.findByMerchantId", query ="SELECT m FROM MerchantInfo m where m.id = :id "),
@NamedQuery(name="MerchantInfo.findByMerchantIdUnique", query ="SELECT m FROM MerchantInfo m where m.merchantId = :merchantId"),
@NamedQuery(name="MerchantInfo.findByMobileAndEmail", query ="SELECT m FROM MerchantInfo m where (m.aacontactNumber = :contactNumber OR m.email=:email)"),
@NamedQuery(name="MerchantInfo.findByAccntAndIfsc", query ="SELECT m FROM MerchantInfo m where (m.accountNumber = :accountNumber AND m.iFSCCode=:iFSCCode)"),


})
public class MerchantInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "id", unique=true, nullable=false)
	private Integer id;

	@Column(name = "city", nullable=false, length=30)
	private String city;
  
	@Column(name = "merchantCategoryId")
	private Integer merchantCategoryId;
	
	@Column(name = "district")
	@ColumnTransformer(write="AES_ENCRYPT(?, contactNumber)",read="AES_DECRYPT(district, contactNumber)")
	private String district;
	
	
	@Column(name = "region")
	@ColumnTransformer(write="AES_ENCRYPT(?, contactNumber)",read="AES_DECRYPT(region, contactNumber)")
	private String region;


	@Column(name = "country", nullable=false)
	private String country;

	@Column(name = "houseNumber", nullable=false, length=30)
	private String houseNumber;

	@Column(name = "landmark", length=50)
	private String landmark;

	@Column(name = "merchantCategory", length=100)
	private String merchantCategory;

	@Column(name = "merchantId", length=10)
	private String merchantId;
	
	
	@Column(name = "counterType")
	private Integer counterType;
	
	@Column(name = "merchantType")
	private  String merchantType;
	
	@Column(name = "merchantStatus")
	private  String merchantStatus;
	
	@Column(name = "comment")
	private  String comment;
	

	@Column(name = "companyName", nullable=false, length=50)
	@ColumnTransformer(write="AES_ENCRYPT(?, contactNumber)",read="AES_DECRYPT(companyName, contactNumber)")
	private String companyName;
	
	@Column(name = "contactPersonName", nullable=false)
	@ColumnTransformer(write="AES_ENCRYPT(?, contactNumber)",read="AES_DECRYPT(contactPersonName, contactNumber)")
	private String contactPersonName;
	@Column(name = "locality")
	@ColumnTransformer(write="AES_ENCRYPT(?, contactNumber)",read="AES_DECRYPT(locality, contactNumber)")
	private String locality;
	@Column(name="noOfTill")
	private Integer noOfTill;
	@Column(name="address1")
	private String address1;
	@Column(name="address2")
	private String address2;
	@Column(name="pin", nullable=false)
	private Integer pin;

	@Column(name="state", nullable=false)
	private String state;

	@Column(name="status", nullable=false)
	private String status;

	@Column(name="type", nullable=false)
	private String type;
	
	@Column(name="3desKey")
	private String threedesKey;

	@Column(name="contactNumber")
	private String aacontactNumber;
	
	@Column(name = "longitude")
	private String longitude;

	@Column(name = "latitude")
	private String latitude;
	
	@Column(name = "accountNumber")
	private String accountNumber;

	@Column(name = "IFSCCode")
	private String iFSCCode;
	
	@Column(name = "email")
	private String email;
	
	@Column(name = "verifiedOn")
	private Date verifiedOn;
	
	@Column(name = "verifiedBy")
	private Integer verifiedBy;
	
	@Column(name="loginPin")
	private String loginPin;

	//bi-directional many-to-one association to MerchantInfo
	@ManyToOne
	@JoinColumn(name="parentMerchantId")
	private MerchantInfo parentMerchantId;
	//bi-directional many-to-one association to AccountInfo
	@ManyToOne
	@JoinColumn(name="hId")
	private AccountInfo hId;

	//bi-directional many-to-one association to AccountInfo
	@ManyToOne
	@JoinColumn(name="dId")
	private AccountInfo dId;

	//bi-directional many-to-one association to AccountInfo
	@ManyToOne
	@JoinColumn(name="sdId")
	private AccountInfo sdId;

	//bi-directional many-to-one association to AccountInfo
	@ManyToOne
	@JoinColumn(name="aId")
	private AccountInfo aId;

	//bi-directional many-to-one association to AccountInfo
	@ManyToOne
	@JoinColumn(name="under", nullable=false)
	private AccountInfo under;

	//bi-directional many-to-one association to MerchantTillMapping
	@OneToMany(mappedBy="merchantId", fetch = FetchType.EAGER)
	@Fetch(FetchMode.SELECT)
	private List<MerchantTillMapping> merchantTillMappings;

	@OneToMany(mappedBy="merchantInfo", fetch = FetchType.EAGER)
	@Fetch(FetchMode.SELECT)
	private List<MerchantIpMapping> merchantIpMappings;
	
	
	@OneToMany(mappedBy="merchantId", fetch = FetchType.EAGER)
	@Fetch(FetchMode.SELECT)
	private List<CustMerchFinInstMapping> custMerchFinInstMappings; 
	@ManyToOne
    @JoinColumn(name="addressId", referencedColumnName="id")
	private Address addressId;
	
	@Column(name="addedOn")
	private  Date addedOn;
	
	@Column(name="updatedOn")
	private  Date updatedOn;
	
	@Column(name="onboardedBy")
	private  String onboardedBy;
	
	public String getMerchantType() {
		return merchantType;
	}

	public void setMerchantType(String merchantType) {
		this.merchantType = merchantType;
	}

	public Integer getMerchantCategoryId() {
		return merchantCategoryId;
	}

	public void setMerchantCategoryId(Integer merchantCategoryId) {
		this.merchantCategoryId = merchantCategoryId;
	}
	public String getMerchantCategory() {
		return merchantCategory;
	}

	public void setMerchantCategory(String merchantCategory) {
		this.merchantCategory = merchantCategory;
	}

	public String getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}


	public String getLoginPin() {
		return loginPin;
	}

	public void setLoginPin(String loginPin) {
		this.loginPin = loginPin;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getIFSCCode() {
		return iFSCCode;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public void setIFSCCode(String iFSCCode) {
		this.iFSCCode = iFSCCode;
	}



	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getlatitude() {
		return latitude;
	}

	public void setlatitude(String latitude) {
		this.latitude = latitude;
	}



	/**
	 * @return the updatedOn
	 */
	public Date getUpdatedOn() {
		return updatedOn;
	}

	/**
	 * @param updatedOn the updatedOn to set
	 */
	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	/**
	 * @return the addedOn
	 */
	public Date getAddedOn() {
		return addedOn;
	}

	/**
	 * @param addedOn the addedOn to set
	 */
	public void setAddedOn(Date addedOn) {
		this.addedOn = addedOn;
	}

	public MerchantInfo() {
		//empty
	}

	public MerchantInfo(Integer id)
	{
		this.id = id;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}


	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	
	public String getHouseNumber() {
		return this.houseNumber;
	}

	public void setHouseNumber(String houseNumber) {
		this.houseNumber = houseNumber;
	}

	public String getLandmark() {
		return this.landmark;
	}

	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}


	public Integer getNoOfTill() {
		return this.noOfTill;
	}

	public void setNoOfTill(Integer noOfTill) {
		this.noOfTill = noOfTill;
	}

	public Integer getPin() {
		return this.pin;
	}

	public void setPin(Integer pin) {
		this.pin = pin;
	}



	public Address getAddressId() {
		return addressId;
	}

	public void setAddressId(Address addressId) {
		this.addressId = addressId;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getType() {
		return this.type;
	}

	public String getThreedesKey() {
		return threedesKey;
	}

	public void setThreedesKey(String threedesKey) {
		this.threedesKey = threedesKey;
	}

	public void setType(String type) {
		this.type = type;
	}

	public MerchantInfo getParentMerchantId() {
		return this.parentMerchantId;
	}

	public void setParentMerchantId(MerchantInfo parentMerchantId) {
		this.parentMerchantId = parentMerchantId;
	}


	public AccountInfo getHId() {
		return this.hId;
	}

	public void setHId(AccountInfo hId) {
		this.hId = hId;
	}

	public AccountInfo getDId() {
		return this.dId;
	}

	public void setDId(AccountInfo dId) {
		this.dId = dId;
	}

	public AccountInfo getSdId() {
		return this.sdId;
	}

	public void setSdId(AccountInfo sdId) {
		this.sdId = sdId;
	}

	public AccountInfo getAId() {
		return this.aId;
	}

	public void setAId(AccountInfo aId) {
		this.aId = aId;
	}

	public AccountInfo getUnder() {
		return this.under;
	}

	public void setUnder(AccountInfo under) {
		this.under = under;
	}

	public String getContactNumber() {
		return aacontactNumber;
	}

	public void setContactNumber(String aacontactNumber) {
		this.aacontactNumber = aacontactNumber;
	}
	
	public List<MerchantTillMapping> getMerchantTillMappings() {
		return merchantTillMappings;
	}

	public void setMerchantTillMappings(List<MerchantTillMapping> merchantTillMappings) {
		this.merchantTillMappings = merchantTillMappings;
	}

	public List<MerchantIpMapping> getMerchantIpMappings() {
		return merchantIpMappings;
	}

	public void setMerchantIpMappings(List<MerchantIpMapping> merchantIpMappings) {
		this.merchantIpMappings = merchantIpMappings;
	}

	public List<CustMerchFinInstMapping> getCustMerchFinInstMappings() {
		return custMerchFinInstMappings;
	}

	public void setCustMerchFinInstMappings(List<CustMerchFinInstMapping> custMerchFinInstMappings) {
		this.custMerchFinInstMappings = custMerchFinInstMappings;
	}

	public Integer getCounterType() {
		return counterType;
	}

	public void setCounterType(Integer counterType) {
		this.counterType = counterType;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getContactPersonName() {
		return contactPersonName;
	}

	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}

	public String getOnboardedBy() {
		return onboardedBy;
	}

	public void setOnboardedBy(String onboardedBy) {
		this.onboardedBy = onboardedBy;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getLocality() {
		return locality;
	}

	public void setLocality(String locality) {
		this.locality = locality;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getiFSCCode() {
		return iFSCCode;
	}

	public void setiFSCCode(String iFSCCode) {
		this.iFSCCode = iFSCCode;
	}

	public AccountInfo gethId() {
		return hId;
	}

	public void sethId(AccountInfo hId) {
		this.hId = hId;
	}

	public AccountInfo getdId() {
		return dId;
	}

	public void setdId(AccountInfo dId) {
		this.dId = dId;
	}

	public AccountInfo getaId() {
		return aId;
	}

	public void setaId(AccountInfo aId) {
		this.aId = aId;
	}

	public String getMerchantStatus() {
		return merchantStatus;
	}

	public void setMerchantStatus(String merchantStatus) {
		this.merchantStatus = merchantStatus;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getAacontactNumber() {
		return aacontactNumber;
	}

	public void setAacontactNumber(String aacontactNumber) {
		this.aacontactNumber = aacontactNumber;
	}

	public Date getVerifiedOn() {
		return verifiedOn;
	}

	public void setVerifiedOn(Date verifiedOn) {
		this.verifiedOn = verifiedOn;
	}

	public Integer getVerifiedBy() {
		return verifiedBy;
	}

	public void setVerifiedBy(Integer verifiedBy) {
		this.verifiedBy = verifiedBy;
	}

}