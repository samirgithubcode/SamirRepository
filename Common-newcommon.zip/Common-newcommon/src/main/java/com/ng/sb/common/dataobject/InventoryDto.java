package com.ng.sb.common.dataobject;

import java.math.BigDecimal;

public class InventoryDto {

	private BigDecimal iccdNumber;
	private Long externalNumber;
	private String addedOn;
	private String addedBy;
	private String modifiedBy;
	private String modifiedOn;
	private String remarks;
	private String productType;
	private String status;
	private String mobileNumber;
	
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public BigDecimal getIccdNumber() {
		return iccdNumber;
	}
	public void setIccdNumber(BigDecimal bigDecimal) {
		this.iccdNumber = bigDecimal;
	}
	public Long getExternalNumber() {
		return externalNumber;
	}
	public void setExternalNumber(Long long1) {
		this.externalNumber = long1;
	}
	public String getAddedOn() {
		return addedOn;
	}
	public void setAddedOn(String addedOn) {
		this.addedOn = addedOn;
	}
	public String getAddedBy() {
		return addedBy;
	}
	public void setAddedBy(String addedBy) {
		this.addedBy = addedBy;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public String getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(String modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
}
