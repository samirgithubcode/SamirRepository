/**
 * 
 */
package com.ng.user.dto;

import org.hibernate.validator.constraints.NotBlank;

import com.ng.sb.common.dataobject.ValidationBean;

/**
 * @author gopal
 *
 */
public class OtpRequest implements ValidationBean {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7452115084495946842L;

	@NotBlank(message="Customer MSISDN cannot be blank")
	private String customerMsisdn;
	
	private String otpPurpose;
	
	private Integer otpLength = 6;
	
	private Boolean alphaNumeric;
	
	private Integer validFor;

	public String getCustomerMsisdn() {
		return customerMsisdn;
	}

	public void setCustomerMsisdn(String customerMsisdn) {
		this.customerMsisdn = customerMsisdn;
	}

	public String getOtpPurpose() {
		return otpPurpose;
	}

	public void setOtpPurpose(String otpPurpose) {
		this.otpPurpose = otpPurpose;
	}

	public Integer getOtpLength() {
		return otpLength;
	}

	public void setOtpLength(Integer otpLength) {
		this.otpLength = otpLength;
	}

	public Boolean getAlphaNumeric() {
		return alphaNumeric;
	}

	public void setAlphaNumeric(Boolean alphaNumeric) {
		this.alphaNumeric = alphaNumeric;
	}

	public Integer getValidFor() {
		return validFor;
	}

	public void setValidFor(Integer validFor) {
		this.validFor = validFor;
	}
	
	
}
