/**
 * 
 */
package com.ng.sb.common.exception;

public class RangeDetailsException  extends RuntimeException {
	private static final long serialVersionUID = 1L;
	
	public RangeDetailsException(String message){
		super(message);
	}
}