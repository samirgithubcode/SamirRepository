/**
 * 
 */
package com.ng.sb.common.dataobject;

import java.util.Map;
import java.util.Set;

/**
 * @author gaurav
 *
 */
public class HostSubVersionData extends BaseObjectData {

	public enum ProviderRelation{
		DIRECT_PROVIDER,
		FSP_PROVIDER,
		REGISTERED_INSTRUMENT_FSP_PROVIDER
	}
	public HostSubVersionData() {
		//default constructor
	}

	public HostSubVersionData(Integer id) {
		super.setId(id);
	}

	private static final long serialVersionUID = 1L;

	private MasterVersionData masterVersionData;
	private AccountInfoData host;
	private Map<ServiceConfigData,ServiceConfigData> serviceConfigMap;
	private Map<FSPServicesData, FSPServicesData> fspServiceMap;
	private Map<InstrumentData, InstrumentData> instrumentMap;
	private Map<CategoryData, CategoryData> categoryMap;
	private Map<ProviderRelation, Map<ProvidersData,ProvidersData>> providerMap;
	private Set<PartnerPreferenceData> partnerPreferences;
	public MasterVersionData getMasterVersionData() {
		return masterVersionData;
	}

	public void setMasterVersionData(MasterVersionData masterVersionData) {
		this.masterVersionData = masterVersionData;
	}

	public AccountInfoData getHost() {
		return host;
	}

	public void setHost(AccountInfoData host) {
		this.host = host;
	}

	public Map<FSPServicesData, FSPServicesData> getFspServiceMap() {
		return fspServiceMap;
	}

	public void setFspServiceMap(Map<FSPServicesData, FSPServicesData> fspServiceMap) {
		this.fspServiceMap = fspServiceMap;
	}

	public Map<ServiceConfigData, ServiceConfigData> getServiceConfigMap() {
		return serviceConfigMap;
	}

	public void setServiceConfigMap(
			Map<ServiceConfigData, ServiceConfigData> serviceConfigMap) {
		this.serviceConfigMap = serviceConfigMap;
	}

	public Map<InstrumentData, InstrumentData> getInstrumentMap() {
		return instrumentMap;
	}

	public void setInstrumentMap(
			Map<InstrumentData, InstrumentData> instrumentMap) {
		this.instrumentMap = instrumentMap;
	}

	public Map<ProviderRelation, Map<ProvidersData, ProvidersData>> getProviderMap() {
		return providerMap;
	}

	public void setProviderMap(
			Map<ProviderRelation, Map<ProvidersData, ProvidersData>> providerMap) {
		this.providerMap = providerMap;
	}

	

	public Set<PartnerPreferenceData> getPartnerPreferences() {
		return partnerPreferences;
	}

	public void setPartnerPreferences(Set<PartnerPreferenceData> partnerPreferences) {
		this.partnerPreferences = partnerPreferences;
	}

	public Map<CategoryData, CategoryData> getCategoryMap() {
		return categoryMap;
	}

	public void setCategoryMap(Map<CategoryData, CategoryData> categoryMap) {
		this.categoryMap = categoryMap;
	}

	@Override
	public boolean equals(Object obj) {
		if(obj==null){
			return false;
		}
		boolean check=false;
		if( obj instanceof HostSubVersionData){
			HostSubVersionData other = (HostSubVersionData)obj;
			if(this==other || super.getId()==other.getId()){
				check= true;
			}
			return check;
		}
		return super.equals(obj);
	}
	
	@Override
	public int hashCode() {
		if(super.getId()!=null){
			return super.getId()*7;	
		}else{
			return 0;
		}
		
	}

	

}
