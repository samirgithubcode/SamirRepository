package com.ng.sb.common.dataobject;

import java.util.List;

public class KycValidationCustomerData {

	private Integer custId;
	private String custName;
	private String custMsisdn;
	private String custAddDate;
	private String custStatus;
	private List<SubscriberIdProofsData> idList;
	
	
	public Integer getCustId() {
		return custId;
	}
	public void setCustId(Integer custId) {
		this.custId = custId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getCustMsisdn() {
		return custMsisdn;
	}
	public void setCustMsisdn(String custMsisdn) {
		this.custMsisdn = custMsisdn;
	}
	public String getCustAddDate() {
		return custAddDate;
	}
	public void setCustAddDate(String finalActDate) {
		this.custAddDate = finalActDate;
	}
	public String getCustStatus() {
		return custStatus;
	}
	public void setCustStatus(String custStatus) {
		this.custStatus = custStatus;
	}
	public List<SubscriberIdProofsData> getIdList() {
		return idList;
	}
	public void setIdList(List<SubscriberIdProofsData> idList) {
		this.idList = idList;
	}
	
}
