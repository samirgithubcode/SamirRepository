package com.ng.transaction.service.impl;

import java.net.URI;
import java.util.ArrayList;

import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.ng.transaction.util.Constants;
import com.ng.transaction.util.CryptoUtil;
import com.ng.sb.common.dataobject.TransactionData;
import com.ng.transaction.dto.sbi.CustomerRegistrationGenericRequestMsgDTO;
import com.ng.transaction.dto.sbi.CustomerRegistrationRequestDTO;
import com.ng.transaction.dto.sbi.CustomerRegistrationRequestDTO.AccountList;
import com.ng.transaction.dto.sbi.CustomerRegistrationRequestDTO.AddInfo;
import com.ng.transaction.dto.sbi.CustomerRegistrationRequestDTO.DeviceInfo;
import com.ng.transaction.dto.sbi.CustomerRegistrationRequestDTO.RequestInfo;
import com.ng.transaction.dto.sbi.CustomerRegistrationRequestDTO.UserInfo;
import com.ng.transaction.service.ISBITransactionService;

@Service
public class SBITransactionService implements ISBITransactionService {
		
	@Bean
	public RestTemplate restTemplate() {
	    return new RestTemplate();
	}
	
	@Override
	public ResponseEntity<String> registerCustomerToSBI(TransactionData data) throws Exception{
		CustomerRegistrationRequestDTO dto = new CustomerRegistrationRequestDTO();
		RequestInfo info = dto.getRequestInfo();
		
		info.setPspId(Constants.PSP_ID);
		info.setPspRefNo(Constants.PSP_REF_NO);
		dto.setRequestInfo(info);
		
		UserInfo userInfo = dto.getUserInfo();
		userInfo.setEmail("");
		userInfo.setName("");
		userInfo.setVirtualAddress("");
		dto.setUserInfo(userInfo);
		
		DeviceInfo deviceInfo = dto.getDeviceInfo();
		deviceInfo.setAndroidId(Constants.DUMMY_STRING);
		deviceInfo.setAppName(Constants.APPLICATION_NAME);
		deviceInfo.setBluetoothMac(Constants.DUMMY_STRING);
		deviceInfo.setCapability(Constants.DUMMY_STRING);
		deviceInfo.setDeviceId(Constants.DEVICE_ID);
		deviceInfo.setDeviceType(Constants.DEVICE_TYPE);
		deviceInfo.setGeoCode(Constants.DUMMY_STRING);
		deviceInfo.setIp(Constants.DUMMY_STRING);
		deviceInfo.setLocation(Constants.DUMMY_STRING);
		deviceInfo.setMobileNo("MSISDN");
		deviceInfo.setOs(Constants.DUMMY_STRING);
		deviceInfo.setSimId(Constants.DUMMY_STRING);
		deviceInfo.setWifiMac(Constants.DUMMY_STRING);
		dto.setDeviceInfo(deviceInfo);
		
		AddInfo addInfo = dto.getAddInfo();
		addInfo.setAddInfo1("");
		dto.setAddInfo(addInfo);
		
		ArrayList<AccountList> accountList = dto.getAccountList();
		
		AccountList account = dto.getAccount();
		account.setAccountName("");
		account.setAccountNumber("");
		account.setAccountType("");
		account.setIfscCode("");
		account.setPreferredFlag(Constants.PREFERRED_FLAG);
		accountList.add(account);
		
		dto.setAccountList(accountList);		

		CryptoUtil crypt = new CryptoUtil();
		String requestMsg = crypt.AESEncryption(dto);
		
		CustomerRegistrationGenericRequestMsgDTO requestMsgDto = new CustomerRegistrationGenericRequestMsgDTO();
		requestMsgDto.setPspId(Constants.PSP_ID);
		requestMsgDto.setRequestMsg(requestMsg);
				
		URI uri = new URI(Constants.BASE_URL + Constants.CUSTOMER_REGISTRATION_ENDPOINT);

		HttpHeaders headers = new HttpHeaders();
	    headers.set("SecretKey", "Update this with the encrypted secret key used for encrypting the payload");    
	    
	    HttpEntity<CustomerRegistrationGenericRequestMsgDTO> request = new HttpEntity<>(requestMsgDto, headers);	    
	    ResponseEntity<String> result = restTemplate().postForEntity(uri, request, String.class);
	
	    return result;
	}
}