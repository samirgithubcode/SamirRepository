package com.ng.transaction.service.impl;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.stereotype.Service;

import com.ng.sb.common.dataobject.AccountInfo;
import com.ng.sb.common.dataobject.Actor;
import com.ng.sb.common.dataobject.IConstants;
import com.ng.sb.common.dataobject.OverlayIssuance;
import com.ng.sb.common.dataobject.ResponseObject;
import com.ng.sb.common.dataobject.TransactionRequestData;
import com.ng.sb.common.model.CustMerchFinInstMapping;
import com.ng.sb.common.model.CustomerAccountHistory;
import com.ng.sb.common.model.CustomerDetails;
import com.ng.sb.common.model.InventoryMgmt;
import com.ng.sb.common.model.InventoryMgmtHistory;
import com.ng.sb.common.model.MerchantInfo;
import com.ng.sb.common.model.Partner;
import com.ng.sb.common.model.PartnerProviderMapping;
import com.ng.sb.common.model.Provider;
import com.ng.sb.common.model.Subscriber;
import com.ng.sb.common.model.TransactionSecureService;
import com.ng.sb.common.service.impl.SuperParentService;
import com.ng.sb.common.util.CommonUtils;
import com.ng.sb.common.util.ErrorCodes;
import com.ng.sb.common.util.SystemConstant;
import com.ng.sb.common.util.ThreeDESEncryption;
import com.ng.sb.common.util.TransactionIdGenerator;
import com.ng.transaction.dao.ISecureTransactionDAO;
import com.ng.transaction.data.SecureTransactionResponse;
import com.ng.transaction.logger.Log4jImpl;
import com.ng.transaction.logger.TxnLogger;
import com.ng.transaction.service.ISecureTransactionService;
import com.ng.transaction.util.AccountStatus;
import com.ng.transaction.util.InventoryStatus;
import com.ng.transaction.util.OverlayStatus;
import com.ng.transaction.util.SyncingThread;
@Service
public class SecureTransactionService  extends SuperParentService implements ISecureTransactionService {
	
	@Autowired
	ISecureTransactionDAO iSecureTransactionDAO;
	
	@Override
	public SecureTransactionResponse transferMoneyToWallet(TransactionRequestData transactionRequestData) {
		SecureTransactionResponse secureTransactionResponse= new SecureTransactionResponse();
		try
		{
		String transactionId=new TransactionIdGenerator().genTransId();
		TransactionSecureService securerTansactionService= new TransactionSecureService();
		securerTansactionService.setTransationDate(new Date());
		securerTansactionService.setPayerTransactionId(transactionRequestData.getPayerWallet().getTelcoTransationId());
		Boolean checkKey=checkKey(transactionRequestData.getKey());
		if(!checkKey)
		{
			if(transactionRequestData.getTransactiontype().equals(IConstants.W_W))
				secureTransactionResponse.setTransactionType(IConstants.W_W);
			else
				securerTansactionService.setTransactionType(transactionRequestData.getTransactiontype().equals(IConstants.BILL_PAY)?IConstants.BILL_PAY:IConstants.TOP_UP);
			securerTansactionService.setStatus("fail");
			securerTansactionService.setTransationDate(new Date());
			iSecureTransactionDAO.saveTransactionServiceData(securerTansactionService);
			secureTransactionResponse.setResponseCode(101);
			secureTransactionResponse.setResponseMessage(SystemConstant.WRONGKEY);
			secureTransactionResponse.setPayerWallet(transactionRequestData.getPayerWallet());
			secureTransactionResponse.setTransactionId(transactionId);
			return secureTransactionResponse;
		}
		if(transactionRequestData.getAmount()<=0)
		{
			if(transactionRequestData.getTransactiontype().equals(IConstants.W_W))
				secureTransactionResponse.setTransactionType(IConstants.W_W);
			else
				securerTansactionService.setTransactionType(transactionRequestData.getTransactiontype().equals(IConstants.BILL_PAY)?IConstants.BILL_PAY:IConstants.TOP_UP);
				securerTansactionService.setStatus("fail");
				securerTansactionService.setTransationDate(new Date());
				iSecureTransactionDAO.saveTransactionServiceData(securerTansactionService);
				secureTransactionResponse.setResponseCode(102);
				secureTransactionResponse.setResponseMessage(SystemConstant.INVALIDAMOUNT);
				secureTransactionResponse.setPayerWallet(transactionRequestData.getPayerWallet());
				secureTransactionResponse.setTransactionId(transactionId);
				return secureTransactionResponse;
		}
		Partner partner=iSecureTransactionDAO.checkWalletStatus(transactionRequestData.getPayerWallet().getWalletCode());
		if(partner==null)
		{
			if(transactionRequestData.getTransactiontype().equals(IConstants.W_W))
				secureTransactionResponse.setTransactionType(IConstants.W_W);
			else
				securerTansactionService.setTransactionType(transactionRequestData.getTransactiontype().equals(IConstants.BILL_PAY)?IConstants.BILL_PAY:IConstants.TOP_UP);
			securerTansactionService.setStatus("fail");
			securerTansactionService.setTransationDate(new Date());
			iSecureTransactionDAO.saveTransactionServiceData(securerTansactionService);
			secureTransactionResponse.setResponseCode(110);
			secureTransactionResponse.setResponseMessage(SystemConstant.WRONGPAYERWALLET);
			secureTransactionResponse.setPayerWallet(transactionRequestData.getPayerWallet());
			secureTransactionResponse.setTransactionId(transactionId);
			return secureTransactionResponse;
		}
		CustMerchFinInstMapping custMerchFinInstMapping=iSecureTransactionDAO.getPayerDetails(partner);
		if(custMerchFinInstMapping==null)
		{
			if(transactionRequestData.getTransactiontype().equals(IConstants.W_W))
				secureTransactionResponse.setTransactionType(IConstants.W_W);
			else
				securerTansactionService.setTransactionType(transactionRequestData.getTransactiontype().equals(IConstants.BILL_PAY)?IConstants.BILL_PAY:IConstants.TOP_UP);
			securerTansactionService.setStatus("fail");
			/*securerTansactionService.setTransationDate(new Date());*/
			iSecureTransactionDAO.saveTransactionServiceData(securerTansactionService);
			secureTransactionResponse.setResponseCode(111);
			secureTransactionResponse.setResponseMessage(SystemConstant.WRONGTELCO);
			secureTransactionResponse.setPayerWallet(transactionRequestData.getPayerWallet());
			secureTransactionResponse.setTransactionId(transactionId);
			return secureTransactionResponse;
		}
		securerTansactionService.setPayerTelcoId(custMerchFinInstMapping.getMerchantId());
		securerTansactionService.setInitiator(IConstants.TELCO);
		securerTansactionService.setPayerWalletCode(transactionRequestData.getPayerWallet().getWalletCode());
		securerTansactionService.setPayerWalletId(transactionRequestData.getPayerWallet().getMsisdn());
		securerTansactionService.setCreditAmount(transactionRequestData.getAmount());
		securerTansactionService.setHostTransactionId(transactionId);
		securerTansactionService.setStatus(IConstants.SUCCESS);
		securerTansactionService.setTransationDate(new Date());
		if(transactionRequestData.getTransactiontype().equals(IConstants.W_W))
		{
			securerTansactionService.setTransactionType(IConstants.W_W);
			secureTransactionResponse.setTransactionType(IConstants.W_W);
		}	
		else
		{
			securerTansactionService.setTransactionType(transactionRequestData.getTransactiontype().equals(IConstants.BILL_PAY)?IConstants.BILL_PAY:IConstants.TOP_UP);
			secureTransactionResponse.setTransactionType(IConstants.W_W);
		}
		
		if(securerTansactionService.getTransactionType().equals("W_W"))
		{	
			iSecureTransactionDAO.saveTransactionServiceData(securerTansactionService);
			transferMoneyToPayeeWallet(transactionRequestData,secureTransactionResponse,securerTansactionService);
		}
		else
		{
			securerTansactionService.setSubscriberId(transactionRequestData.getProviderData().getSubscriberId());
			iSecureTransactionDAO.saveTransactionServiceData(securerTansactionService);
			billPayOrTopup(transactionRequestData,secureTransactionResponse,securerTansactionService);
		}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return secureTransactionResponse;
	}

	private SecureTransactionResponse billPayOrTopup(TransactionRequestData transactionRequestData,SecureTransactionResponse secureTransactionResponse, TransactionSecureService securerTansactionService) 
	{
		String transactionId=new TransactionIdGenerator().genTransId();
		securerTansactionService.setPayeeTransactionId(transactionId);
		try
		{
		Provider provider =iSecureTransactionDAO.findProviderByCode(transactionRequestData.getProviderData().getCode());
		if(provider!=null)
		{
			List<PartnerProviderMapping> partnerProviderMappings=(List<PartnerProviderMapping>) provider.getPartnerProviderMappingCollection();
			PartnerProviderMapping partnerProviderMapping=partnerProviderMappings.get(0);
			Partner partner=partnerProviderMapping.getPartnerId();
			securerTansactionService.setProviderCode(transactionRequestData.getProviderData().getCode());
			securerTansactionService.setProviderId(provider);
			securerTansactionService.setPartnerId(partner);
			iSecureTransactionDAO.updateTransactionServiceData(securerTansactionService);
			securerTansactionService.setDebitAmount(transactionRequestData.getAmount());
			securerTansactionService.setCreditAmount(null);
			securerTansactionService.setInitiator(IConstants.HOST);
			iSecureTransactionDAO.saveTransactionServiceData(securerTansactionService);
			secureTransactionResponse.setResponseCode(100);
			secureTransactionResponse.setResponseMessage(SystemConstant.SUCCESS);
			secureTransactionResponse.setPayerWallet(transactionRequestData.getPayerWallet());
			secureTransactionResponse.setProviderData(transactionRequestData.getProviderData());
			secureTransactionResponse.setTransactionId(transactionId);
			return secureTransactionResponse;
		}
		else
		{
			securerTansactionService.setStatus("fail");
			securerTansactionService.setTransationDate(new Date());
			securerTansactionService.setInitiator(IConstants.HOST);
			iSecureTransactionDAO.saveTransactionServiceData(securerTansactionService);
			secureTransactionResponse.setResponseCode(106);
			secureTransactionResponse.setResponseMessage(SystemConstant.WRONGPROVIDERCODE);
			secureTransactionResponse.setPayerWallet(transactionRequestData.getPayerWallet());
			secureTransactionResponse.getProviderData().setProviderTransactionId(transactionId);
			secureTransactionResponse.setProviderData(transactionRequestData.getProviderData());
			secureTransactionResponse.setTransactionId(transactionId);
			return secureTransactionResponse;
		}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return secureTransactionResponse;
		}

	private Boolean checkKey(String key) {
		ThreeDESEncryption threeDESEncryption = new ThreeDESEncryption();
		Boolean keyResult=false;
		try {
			System.out.println(getPlatformLoginData().getSysPass3desKey());
			MerchantInfo merchantInfo= iSecureTransactionDAO.checkKey(threeDESEncryption.encrypt(key, getPlatformLoginData().getSysPass3desKey()));
			if(merchantInfo==null)
			{
				return keyResult;
			}
			else
			{
				keyResult=true;
				return keyResult;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return keyResult;
	}
	
	public SecureTransactionResponse transferMoneyToPayeeWallet(TransactionRequestData transactionRequestData,SecureTransactionResponse secureTransactionResponse,TransactionSecureService securerTansactionService)
	{
		String transactionId=new TransactionIdGenerator().genTransId();
		transactionRequestData.getPayeeWallet().setTelcoTransationId(transactionId);
		Partner partner = new Partner();
		try {
			partner=iSecureTransactionDAO.checkWalletStatus(transactionRequestData.getPayeeWallet().getWalletCode());
			if(partner==null)
			{
				securerTansactionService.setStatus("fail");
				securerTansactionService.setTransationDate(new Date());
				securerTansactionService.setInitiator(IConstants.HOST);
				iSecureTransactionDAO.saveTransactionServiceData(securerTansactionService);
				secureTransactionResponse.setResponseCode(110);
				secureTransactionResponse.setResponseMessage(SystemConstant.WRONGWALLETMSG);
				secureTransactionResponse.setPayerWallet(transactionRequestData.getPayerWallet());
				secureTransactionResponse.setPayeeWallet(transactionRequestData.getPayeeWallet());
				secureTransactionResponse.setTransactionId(transactionId);
				return secureTransactionResponse;
			}
			securerTansactionService.setPayeeTransactionId(transactionId);
			
			iSecureTransactionDAO.updateTransactionServiceData(securerTansactionService);
			securerTansactionService.setPayeeWalletCode(transactionRequestData.getPayeeWallet().getWalletCode());
			securerTansactionService.setPayeeWalletId(transactionRequestData.getPayeeWallet().getMsisdn());
			securerTansactionService.setStatus(SystemConstant.SUCCESS);
			securerTansactionService.setDebitAmount(securerTansactionService.getCreditAmount());
			securerTansactionService.setInitiator(IConstants.HOST);
			securerTansactionService.setCreditAmount(null);
			TransactionSecureService securerTansactionServiceNew=new TransactionSecureService();  
			BeanUtils.copyProperties(securerTansactionServiceNew, securerTansactionService);
			securerTansactionServiceNew.setId(null);
			iSecureTransactionDAO.saveTransactionServiceData(securerTansactionServiceNew);
			secureTransactionResponse.setResponseCode(100);
			secureTransactionResponse.setResponseMessage(SystemConstant.SUCCESS);
			secureTransactionResponse.setPayerWallet(transactionRequestData.getPayerWallet());
			secureTransactionResponse.setPayeeWallet(transactionRequestData.getPayeeWallet());
			secureTransactionResponse.setTransactionId(transactionId);
			return secureTransactionResponse;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return secureTransactionResponse;}

	@Transactional(rollbackOn=Exception.class)
	@Override
	public ResponseObject overlayIssuance(OverlayIssuance overlayIssuanceData) throws Exception
	{
		ResponseObject response = new ResponseObject();
		
		boolean subscriberStatus = false;
		boolean inventoryStatus = false;
		//SyncingThread syncThread = getSyncThread();
		try{
			
			if(overlayIssuanceData == null || overlayIssuanceData.getCustomerMsisdn() == null || overlayIssuanceData.getExternalNumber() == null)
			{
				response.setStatus(ErrorCodes.REQUIRED_PARAMETERS_MISSING.getCode());
				response.setMessage(ErrorCodes.REQUIRED_PARAMETERS_MISSING.getMessage());
				
				return response;
			}
			
			if(overlayIssuanceData.getCustomerMsisdn().length() != 12)
			{
				response.setStatus(ErrorCodes.INVALID_MOBILE_NUMBER.getCode());
				response.setMessage(ErrorCodes.INVALID_MOBILE_NUMBER.getMessage());
				
				return response;
			}
			
			InventoryMgmt inventory = iSecureTransactionDAO.fetchInventoryDetails(overlayIssuanceData.getExternalNumber());
			
			if(inventory == null || !inventory.getProductStatus().equals(SystemConstant.OK))
			{
				response.setStatus(ErrorCodes.INVALID_OVERLAY_EXTERNAL_NUMBER.getCode());
				response.setMessage(ErrorCodes.INVALID_OVERLAY_EXTERNAL_NUMBER.getMessage() + overlayIssuanceData.getExternalNumber());
				
				return response;
			}
			
			if(inventory.getCustomerMSISDN() != null && !inventory.getCustomerMSISDN().isEmpty())
			{
				response.setStatus(ErrorCodes.OVERLAY_ALREADY_ISSUED.getCode());
				response.setMessage(ErrorCodes.OVERLAY_ALREADY_ISSUED.getMessage());
				
				return response;
			}
			
			Subscriber subscriber = iSecureTransactionDAO.fetchSubscriberDetails(overlayIssuanceData.getCustomerMsisdn());
			
			if(subscriber == null)
				subscriber = new Subscriber();
			
			if(subscriber.getInvMgtId() != null)
			{
				response.setStatus(ErrorCodes.OVERLAY_ALREADY_ISSUED_TO_CUSTOMER.getCode());
				response.setMessage(ErrorCodes.OVERLAY_ALREADY_ISSUED_TO_CUSTOMER.getMessage() + subscriber.getInvMgtId().getExternalNo());
				
				response.setExternalNumber(subscriber.getInvMgtId().getExternalNo().toString());
				response.setCurrentStatus(subscriber.getInvMgtId().getProductStatus());
				return response;
			}
			
			Actor actor = overlayIssuanceData.getActor();
			
			inventory.setProductStatus(SystemConstant.OK);
			inventory.setIssueDate(new Date());
			inventory.setIssuerId(actor.getId());
			inventory.setIssuerName(actor.getName());
			inventory.setIssuerNumber(actor.getSrNo());
			//inventory.setCustomerId(overlayIssuanceData.getCustomerID());
			
			subscriber.setMsisdn(overlayIssuanceData.getCustomerMsisdn());
			subscriber.setInvMgtId(inventory);
			subscriber.setHsvId(iSecureTransactionDAO.getHostSubVersion(inventory.getMvId(), inventory.getAccountId()));
			//subscriber.setCustId(overlayIssuanceData.getCustomerID());
			subscriber.setStatus(SystemConstant.ACTIVE);
			subscriber.setAddDate(new Date());
			
			subscriberStatus = iSecureTransactionDAO.updateSubscriber(subscriber);
			
			if(subscriberStatus)
			{
				inventory.setCustomerMSISDN(overlayIssuanceData.getCustomerMsisdn());
			
				inventoryStatus = iSecureTransactionDAO.updateInventory(inventory);
			}
			
			List<AccountInfo> accountList = overlayIssuanceData.getAccountList();

			for(AccountInfo accountInfo : accountList){
				
				String accountNumber = formatAccountNumber(accountInfo.getAccountNumber());
				
				boolean isValidBankIfscMapping = iSecureTransactionDAO.isValidIfscCodeBankMapping(accountInfo.getIfscCode(), accountInfo.getBankId());
				
				if(isValidBankIfscMapping)
				{
					CustomerDetails accountDetail = iSecureTransactionDAO.fetchCustomerAccountDetails(accountInfo.getCustomerID(), accountInfo.getAccountNumber(), accountInfo.getBankId());
					
					if(accountDetail == null)
					{
							accountDetail = new CustomerDetails();
							accountDetail.setCustomerMsisdn(overlayIssuanceData.getCustomerMsisdn());
							accountDetail.setBankId(accountInfo.getBankId());
							accountDetail.setBankName(accountInfo.getBankName());
							accountDetail.setAccountName(accountInfo.getAccountName());
							accountDetail.setAccountNumber(accountNumber);
							if(accountInfo.getAccountOpeningDate() != null && !accountInfo.getAccountOpeningDate().isEmpty())
								accountDetail.setAccountOpenDate(CommonUtils.getDateFromString(accountInfo.getAccountOpeningDate(), "ddMMyyyy"));
							
							accountDetail.setAccountStatus("A");
							accountDetail.setAccountType(accountInfo.getAccountType());
							accountDetail.setAddedOn(new Date());
							accountDetail.setCustomerId(accountInfo.getCustomerID());
							accountDetail.setCustomerName(overlayIssuanceData.getCustomerName());
							
							if(accountInfo.getIfscCode() == null || accountInfo.getIfscCode().isEmpty())
								throw new Exception("IFSC Code can not be blank.");
							
							accountDetail.setIfscCode(accountInfo.getIfscCode());
							accountDetail.setUserId(accountInfo.getUserId());
							
							boolean addCustomerDetails = iSecureTransactionDAO.addCustomerDetails(accountDetail);
							
							if(addCustomerDetails)
							{
								CustomerAccountHistory history = new  CustomerAccountHistory();
								
								history.setCustomerId(accountDetail.getCustomerId());
								history.setAccountNumber(accountDetail.getAccountNumber());
								history.setIfscCode(accountDetail.getIfscCode());
								history.setSubscriberAccountId(accountDetail);
								history.setActionName(AccountStatus.ADD.getActionName());
								history.setActionById(overlayIssuanceData.getActor().getId());
								history.setActionByName(overlayIssuanceData.getActor().getName());
								history.setActionByNumber(overlayIssuanceData.getActor().getSrNo());
								history.setAddedOn(new Date());
								
								iSecureTransactionDAO.addEntity(history);
							}
						}else{
							throw new Exception("Account details already exists.");
						}
				}else{
					throw new Exception("Invalid BankId or IFSC code.");
				}
							
			}
			
			
			
			if(subscriberStatus && inventoryStatus)
			{
				response.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
				response.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage() );
				
			}else{
				response.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
				response.setMessage(ErrorCodes.REQUEST_FAILED.getMessage());
				
			}
			
			/*syncThread.setCustomerId(overlayIssuanceData.getCustomerID());
			
			syncThread.start();*/
			
			return response;
			
		}catch(Exception e)
		{
			e.printStackTrace();
			
			throw e;
		}
	
	}

	private String formatAccountNumber(String accountNumber) 
	{
		String formattedAccountNumber = accountNumber.replace("-", "");
		
		formattedAccountNumber = formattedAccountNumber.replace(" ", "");
		
		return formattedAccountNumber;
	}

	@Override
	public ResponseObject addCustomerDetails(CustomerDetails customerDetails) 
	{
	    
		ResponseObject response = new ResponseObject();
		
		try{
			
			customerDetails.setAddedOn(new Date());
			
		    boolean addStatus = iSecureTransactionDAO.addCustomerDetails(customerDetails);
		    
		    if(addStatus)
		    {
		    	response.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
		    	response.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
		    }else{
		    	
		    	response.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
		    	response.setMessage(ErrorCodes.REQUEST_FAILED.getMessage());
		    }
			
			return response;
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	
		return null;
	}

	
    
    @Lookup
	public SyncingThread getSyncThread() {
		return null;
	}

    @Transactional
	@Override
	public ResponseObject deActivateOverlay(OverlayIssuance overlayIssuanceData) throws Exception 
	{
		ResponseObject response = new ResponseObject();
		
		boolean subscriberStatus = true;
		boolean inventoryStatus = false;
		boolean validDeActivationStatus = false;
		OverlayStatus requestedStatus = null;
		
		//SyncingThread syncThread = getSyncThread();
		try{
			
			if(overlayIssuanceData == null || overlayIssuanceData.getCustomerMsisdn() == null || overlayIssuanceData.getExternalNumber() == null || overlayIssuanceData.getDeActivationReason() == null)
			{
				response.setStatus(ErrorCodes.REQUIRED_PARAMETERS_MISSING.getCode());
				response.setMessage(ErrorCodes.REQUIRED_PARAMETERS_MISSING.getMessage());
				
				return response;
			}
			
			for(OverlayStatus overlayStatus : OverlayStatus.values())
			{
				if(overlayStatus.getStatus().equalsIgnoreCase(overlayIssuanceData.getDeActivationReason()))
				{
					validDeActivationStatus = true;
					requestedStatus = overlayStatus;
					break;
				}
			}
		
			if(!validDeActivationStatus)
			{
				response.setStatus(ErrorCodes.INVALID_DEACTIVATION_REASON.getCode());
				response.setMessage(ErrorCodes.INVALID_DEACTIVATION_REASON.getMessage());
				
				return response;
			}
			
			InventoryMgmt inventory = iSecureTransactionDAO.fetchInventoryDetails(overlayIssuanceData.getExternalNumber());
			
			if(inventory == null || inventory.getCustomerMSISDN() == null || !inventory.getProductStatus().equalsIgnoreCase(SystemConstant.OK))
			{
				response.setStatus(ErrorCodes.INVALID_OVERLAY_EXTERNAL_NUMBER.getCode());
				response.setMessage(ErrorCodes.INVALID_OVERLAY_EXTERNAL_NUMBER.getMessage() + overlayIssuanceData.getExternalNumber());
				
				return response;
			}
			
			Subscriber subscriber = iSecureTransactionDAO.fetchSubscriberDetails(overlayIssuanceData.getCustomerMsisdn());
			
			if(subscriber == null || subscriber.getInvMgtId() == null || subscriber.getInvMgtId().getId().intValue() !=  inventory.getId().intValue())
			{
				response.setStatus(ErrorCodes.INVALID_MOBILE_NUMBER_OR_EXTERNAL_NUMBER.getCode());
				response.setMessage(ErrorCodes.INVALID_MOBILE_NUMBER_OR_EXTERNAL_NUMBER.getMessage());
				
				return response;
			}
			
			Actor actor = overlayIssuanceData.getActor();
			
			inventory.setDeactivateDate(new Date());
			inventory.setDeactivatorId(actor.getId());
			inventory.setDeactivatorName(actor.getName());
			inventory.setDeactivatorNumber(actor.getSrNo());
			inventory.setProductStatus(overlayIssuanceData.getDeActivationReason());
			
			InventoryMgmtHistory inventoryHistory = new InventoryMgmtHistory();
			
			inventoryHistory.setInventoryId(inventory);
			inventoryHistory.setActionName(InventoryStatus.DE_ACTIVATE.getActionName());
			inventoryHistory.setActionById(actor.getId());
			inventoryHistory.setActionByName(actor.getName());
			inventoryHistory.setActionByNumber(actor.getSrNo());
			inventoryHistory.setAddedOn(new Date());
			
			
			if(requestedStatus.isPermanent())
			{
				subscriber.setInvMgtId(null);
				subscriber.setHsvId(null);
				
				subscriberStatus = iSecureTransactionDAO.updateSubscriber(subscriber);
			}
			
			
			
			if(subscriberStatus)
			{
				iSecureTransactionDAO.addEntity(inventoryHistory);
				
				inventoryStatus = iSecureTransactionDAO.updateInventory(inventory);
			}
			
			if(subscriberStatus && inventoryStatus)
			{
				response.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
				response.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage() );
				
			}else{
				response.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
				response.setMessage(ErrorCodes.REQUEST_FAILED.getMessage());
				
			}
			
			/*syncThread.setCustomerId(overlayIssuanceData.getCustomerID());
			
			syncThread.start();*/
			
			return response;
			
		}catch(Exception e)
		{
			e.printStackTrace();
			
			throw e;
		}
	}

	@Override
	public ResponseObject issuedList(OverlayIssuance overlayIssuanceData) throws Exception 
	{
		ResponseObject response = new ResponseObject();
		
		List<OverlayIssuance> issuedData = null;
		
		//SyncingThread syncThread = getSyncThread();
		try{
			
			issuedData = iSecureTransactionDAO.fetchIssuedList(overlayIssuanceData);
			
			if(issuedData != null && issuedData.size() > 0)
			{
				/*for(InventoryMgmt inventory : inventoryData)
				{
					if(inventory.getProductStatus().equals(SystemConstant.OK)){
						OverlayIssuance issued = new OverlayIssuance();
						
						issued.setCustomerMsisdn(inventory.getCustomerMSISDN());
						issued.setExternalNumber(inventory.getExternalNo().toString());
						issued.setIssuedOn(CommonUtils.getStringFromDate(inventory.getIssueDate(), "yyyy-MM-dd hh:mm:ss"));
						
						Actor issuer = new Actor();
						
						issuer.setId(inventory.getIssuerId());
						issuer.setName(inventory.getIssuerName());
						issuer.setSrNo(inventory.getIssuerNumber());
						
						issued.setActor(issuer);
						
						issuedData.add(issued);
					}
					
				}*/
				
				response.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
				response.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
				response.setPayload(issuedData);
			}else{
				response.setStatus(ErrorCodes.NO_RECORDS_FOUND.getCode());
				response.setMessage(ErrorCodes.NO_RECORDS_FOUND.getMessage());
			}
			
			/*syncThread.setCustomerId(overlayIssuanceData.getCustomerID());
			
			syncThread.start();*/
		}catch(Exception e)
		{
			e.printStackTrace();
			
			response.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			response.setMessage(ErrorCodes.REQUEST_FAILED.getMessage());
		}
			return response;
	}

	@Override
	public ResponseObject activateOverlay(OverlayIssuance overlayIssuanceData) throws Exception 
	{
		ResponseObject response = new ResponseObject();
		
		//boolean subscriberStatus = true;
		boolean inventoryStatus = false;
		//SyncingThread syncThread = getSyncThread();
		try{
			
			if(overlayIssuanceData == null || overlayIssuanceData.getCustomerMsisdn() == null || overlayIssuanceData.getExternalNumber() == null)
			{
				response.setStatus(ErrorCodes.REQUIRED_PARAMETERS_MISSING.getCode());
				response.setMessage(ErrorCodes.REQUIRED_PARAMETERS_MISSING.getMessage());
				
				return response;
			}
			
			InventoryMgmt inventory = iSecureTransactionDAO.fetchInventoryDetails(overlayIssuanceData.getExternalNumber());
			
			if(inventory == null || inventory.getCustomerMSISDN() == null || !inventory.getProductStatus().equalsIgnoreCase(OverlayStatus.BLOCK_BY_SYS.getStatus()))
			{
				response.setStatus(ErrorCodes.OVERLAY_CAN_NOT_BE_ACTIVATED.getCode());
				response.setMessage(ErrorCodes.OVERLAY_CAN_NOT_BE_ACTIVATED.getMessage() + overlayIssuanceData.getExternalNumber());
				
				return response;
			}
			
			Subscriber subscriber = iSecureTransactionDAO.fetchSubscriberDetails(overlayIssuanceData.getCustomerMsisdn());
			
			if(subscriber == null || !subscriber.getInvMgtId().getCustomerMSISDN().equals(subscriber.getMsisdn()))
			{
				response.setStatus(ErrorCodes.INVALID_MOBILE_NUMBER_OR_EXTERNAL_NUMBER.getCode());
				response.setMessage(ErrorCodes.INVALID_MOBILE_NUMBER_OR_EXTERNAL_NUMBER.getMessage());
				
				return response;
			}
			
			Actor actor = overlayIssuanceData.getActor();
			
			inventory.setProductStatus(SystemConstant.OK);
			inventory.setDeactivateDate(new Date());
			inventory.setDeactivatorId(actor.getId());
			inventory.setDeactivatorName(actor.getName());
			inventory.setDeactivatorNumber(actor.getSrNo());
			
			InventoryMgmtHistory inventoryHistory = new InventoryMgmtHistory();
			
			inventoryHistory.setInventoryId(inventory);
			inventoryHistory.setActionName(InventoryStatus.ACTIVATE.getActionName());
			inventoryHistory.setActionById(actor.getId());
			inventoryHistory.setActionByName(actor.getName());
			inventoryHistory.setActionByNumber(actor.getSrNo());
			inventoryHistory.setAddedOn(new Date());
			
			//subscriberStatus = iSecureTransactionDAO.updateSubscriber(subscriber);
			
			/*if(subscriberStatus)
			{*/
				iSecureTransactionDAO.addEntity(inventoryHistory);
				
				inventoryStatus = iSecureTransactionDAO.updateInventory(inventory);
			//}
			
			if(inventoryStatus)
			{
				response.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
				response.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage() );
				
			}else{
				response.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
				response.setMessage(ErrorCodes.REQUEST_FAILED.getMessage());
				
			}
			
			/*syncThread.setCustomerId(overlayIssuanceData.getCustomerID());
			
			syncThread.start();*/
			
			return response;
			
		}catch(Exception e)
		{
			e.printStackTrace();
			
			throw e;
		}
	}

	@Override
	public ResponseObject manageAccounts(OverlayIssuance overlayIssuanceData) throws Exception 
	{
		ResponseObject response = new ResponseObject();
		
		boolean validDeActivationStatus = false;
		AccountStatus requestedStatus = null;
		
		//SyncingThread syncThread = getSyncThread();
		try{
			
			if(overlayIssuanceData == null || overlayIssuanceData.getCustomerMsisdn() == null || overlayIssuanceData.getActionType() == 0 || overlayIssuanceData.getAccountData() == null)
			{
				response.setStatus(ErrorCodes.REQUIRED_PARAMETERS_MISSING.getCode());
				response.setMessage(ErrorCodes.REQUIRED_PARAMETERS_MISSING.getMessage());
				
				return response;
			}
			
			for(AccountStatus accountStatus : AccountStatus.values())
			{
				if(accountStatus.getActionCode().intValue() == overlayIssuanceData.getActionType())
				{
					validDeActivationStatus = true;
					requestedStatus = accountStatus;
					break;
				}
			}
		
			if(!validDeActivationStatus)
			{
				response.setStatus(ErrorCodes.INVALID_ACTION_TYPE.getCode());
				response.setMessage(ErrorCodes.INVALID_ACTION_TYPE.getMessage());
				
				return response;
			}
			
			Subscriber subscriber = iSecureTransactionDAO.fetchSubscriberDetails(overlayIssuanceData.getCustomerMsisdn());
			
			if(subscriber == null || subscriber.getInvMgtId() == null || !subscriber.getMsisdn().equals(overlayIssuanceData.getCustomerMsisdn()))
			{
				response.setStatus(ErrorCodes.INVALID_MOBILE.getCode());
				response.setMessage(ErrorCodes.INVALID_MOBILE.getMessage());
				
				return response;
			}
			
			switch(requestedStatus)
			{
			case ADD:
				response = addAcount(overlayIssuanceData, subscriber);
						break;
						
			case REMOVE:
				response = removeAcount(overlayIssuanceData);
						break;
				
			case DE_ACTIVATE:
				response = deActivateAcount(overlayIssuanceData);
						break;
				
			case ACTIVATE:
				response = activateAcount(overlayIssuanceData);
						break;
			}
			
			/*syncThread.setCustomerId(overlayIssuanceData.getCustomerID());
			
			syncThread.start();*/
			
			return response;
			
		}catch(Exception e)
		{
			e.printStackTrace();
			
			throw e;
		}
	}

	@Transactional(rollbackOn=Exception.class)
	private ResponseObject addAcount(OverlayIssuance overlayIssuanceData, Subscriber subscriber) throws Exception
	{
		ResponseObject responseObject = new ResponseObject();

		TxnLogger.log(this.getClass().getSimpleName(), Log4jImpl.INFO, " [REQUEST] [METHOD_NAME] "+Thread.currentThread().getStackTrace()[1].getMethodName()+" [MSISDN] "+overlayIssuanceData.getCustomerMsisdn() + " [ACCOUNT_NUMBER] "+overlayIssuanceData.getAccountData().getAccountNumber()+" [CUSTOMER_ID] "+overlayIssuanceData.getAccountData().getCustomerID()+" [USER_ID] "+overlayIssuanceData.getAccountData().getUserId()+" [BANK_ID] "+overlayIssuanceData.getAccountData().getBankId());
		
		boolean isValidBankIfscMapping = iSecureTransactionDAO.isValidIfscCodeBankMapping(overlayIssuanceData.getAccountData().getIfscCode(), overlayIssuanceData.getAccountData().getBankId());
		
		if(isValidBankIfscMapping)
		{
		
						String ifscCode = overlayIssuanceData.getAccountData().getIfscCode();
						
						if(ifscCode != null && !ifscCode.isEmpty())
						{
						
									String accountNumber = formatAccountNumber(overlayIssuanceData.getAccountData().getAccountNumber());
									CustomerDetails customerAccountData = iSecureTransactionDAO.fetchCustomerAccountDetails(overlayIssuanceData.getAccountData().getCustomerID(), accountNumber, overlayIssuanceData.getAccountData().getBankId());
									
									if(customerAccountData == null)
									{
										customerAccountData = new CustomerDetails();
										
										customerAccountData.setCustomerMsisdn(overlayIssuanceData.getCustomerMsisdn());
										customerAccountData.setCustomerId(overlayIssuanceData.getAccountData().getCustomerID());
										customerAccountData.setUserId(overlayIssuanceData.getAccountData().getUserId());
										customerAccountData.setCustomerName(subscriber.getName());
										customerAccountData.setAccountNumber(accountNumber);
										customerAccountData.setIfscCode(overlayIssuanceData.getAccountData().getIfscCode());
										customerAccountData.setAccountType(overlayIssuanceData.getAccountData().getAccountType());
										customerAccountData.setBankId(overlayIssuanceData.getAccountData().getBankId());
										customerAccountData.setBankName(overlayIssuanceData.getAccountData().getBankName());
										customerAccountData.setAccountName(overlayIssuanceData.getAccountData().getAccountName());
										
										if(overlayIssuanceData.getAccountData().getAccountOpeningDate() != null && !overlayIssuanceData.getAccountData().getAccountOpeningDate().isEmpty())
											customerAccountData.setAccountOpenDate(CommonUtils.getDateFromString(overlayIssuanceData.getAccountData().getAccountOpeningDate(), "ddMMyyyy"));
										
										customerAccountData.setAccountStatus("A");
										customerAccountData.setAddedOn(new Date());
										
										boolean status = iSecureTransactionDAO.addEntity(customerAccountData);
										
										if(status)
										{
											CustomerAccountHistory history = new  CustomerAccountHistory();
											
											history.setCustomerId(customerAccountData.getCustomerId());
											history.setAccountNumber(customerAccountData.getAccountNumber());
											history.setIfscCode(customerAccountData.getIfscCode());
											history.setSubscriberAccountId(customerAccountData);
											history.setActionName(AccountStatus.ADD.getActionName());
											history.setActionById(overlayIssuanceData.getActor().getId());
											history.setActionByName(overlayIssuanceData.getActor().getName());
											history.setActionByNumber(overlayIssuanceData.getActor().getSrNo());
											history.setAddedOn(new Date());
											
											status = iSecureTransactionDAO.addEntity(history);
											
											if(status)
											{
											responseObject.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
											responseObject.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
											
											//manageAccountsOTA(history, AccountStatus.ADD );
											
											}else{
												
												throw new Exception("Failed to add history");
											}
										}else{
											responseObject.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
											responseObject.setMessage(ErrorCodes.REQUEST_FAILED.getMessage());
										}
										
									}else{
										responseObject.setStatus(ErrorCodes.ACCOUNT_DETAILS_ALREADY_EXISTS.getCode());
										responseObject.setMessage(ErrorCodes.ACCOUNT_DETAILS_ALREADY_EXISTS.getMessage());
									}
						}else{
						
							responseObject.setStatus(ErrorCodes.INVALID_IFSC_CODE.getCode());
							responseObject.setMessage(ErrorCodes.INVALID_IFSC_CODE.getMessage());
						}
		    }else{
		    	responseObject.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
				responseObject.setMessage("Invalid BankId or IFSC code.");
		    }
		
	
		TxnLogger.log(this.getClass().getSimpleName(), Log4jImpl.INFO, " [RESPONSE] [METHOD_NAME] "+Thread.currentThread().getStackTrace()[1].getMethodName()+" [MSISDN] "+overlayIssuanceData.getCustomerMsisdn() + " [ACCOUNT_NUMBER] "+overlayIssuanceData.getAccountData().getAccountNumber()+" [CUSTOMER_ID] "+overlayIssuanceData.getAccountData().getCustomerID()+" [USER_ID] "+overlayIssuanceData.getAccountData().getUserId()+" [BANK_ID] "+overlayIssuanceData.getAccountData().getBankId() +" [RESPONSE_STATUS] "+responseObject.getStatus()+" [RESPONSE_MESSAGE] "+responseObject.getMessage());
		
		return responseObject;
	}
	
	@Transactional(rollbackOn=Exception.class)
	private ResponseObject removeAcount(OverlayIssuance overlayIssuanceData) throws Exception
	{
		
		TxnLogger.log(this.getClass().getSimpleName(), Log4jImpl.INFO, " [REQUEST] [METHOD_NAME] "+Thread.currentThread().getStackTrace()[1].getMethodName()+" [MSISDN] "+overlayIssuanceData.getCustomerMsisdn() + " [ACCOUNT_NUMBER] "+overlayIssuanceData.getAccountData().getAccountNumber()+" [CUSTOMER_ID] "+overlayIssuanceData.getAccountData().getCustomerID()+" [USER_ID] "+overlayIssuanceData.getAccountData().getUserId()+" [BANK_ID] "+overlayIssuanceData.getAccountData().getBankId());
		
		ResponseObject responseObject = new ResponseObject();
		String accountNumber = formatAccountNumber(overlayIssuanceData.getAccountData().getAccountNumber());
					CustomerDetails customerAccountData = iSecureTransactionDAO.fetchCustomerAccountDetails(overlayIssuanceData.getAccountData().getCustomerID(), accountNumber, overlayIssuanceData.getAccountData().getBankId());
					
					if(customerAccountData == null)
					{
							
							responseObject.setStatus(ErrorCodes.INVALIDACCOUNT.getCode());
							responseObject.setMessage(ErrorCodes.INVALIDACCOUNT.getMessage());
						
					}else{
						
						customerAccountData.setAccountStatus("R");
						
						boolean updateStatus = iSecureTransactionDAO.updateEntity(customerAccountData);
						
						if(updateStatus)
						{
							CustomerAccountHistory history = new  CustomerAccountHistory();
							
							history.setCustomerId(overlayIssuanceData.getAccountData().getCustomerID());
							history.setAccountNumber(accountNumber);
							history.setIfscCode(customerAccountData.getIfscCode());
							history.setSubscriberAccountId(customerAccountData);
							history.setActionName(AccountStatus.REMOVE.getActionName());
							history.setActionById(overlayIssuanceData.getActor().getId());
							history.setActionByName(overlayIssuanceData.getActor().getName());
							history.setActionByNumber(overlayIssuanceData.getActor().getSrNo());
							history.setAddedOn(new Date());
							
							boolean status = iSecureTransactionDAO.addEntity(history);
							
							if(status)
							{
							responseObject.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
							responseObject.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
							}else{
								
								throw new Exception("Failed to update history");
							}
						}
						
					}
				
					TxnLogger.log(this.getClass().getSimpleName(), Log4jImpl.INFO, " [RESPONSE] [METHOD_NAME] "+Thread.currentThread().getStackTrace()[1].getMethodName()+" [MSISDN] "+overlayIssuanceData.getCustomerMsisdn() + " [ACCOUNT_NUMBER] "+overlayIssuanceData.getAccountData().getAccountNumber()+" [CUSTOMER_ID] "+overlayIssuanceData.getAccountData().getCustomerID()+" [USER_ID] "+overlayIssuanceData.getAccountData().getUserId()+" [BANK_ID] "+overlayIssuanceData.getAccountData().getBankId() +" [RESPONSE_STATUS] "+responseObject.getStatus()+" [RESPONSE_MESSAGE] "+responseObject.getMessage());
		return responseObject;
	}
	
	
	@Transactional(rollbackOn=Exception.class)
	private ResponseObject deActivateAcount(OverlayIssuance overlayIssuanceData) throws Exception
	{
		ResponseObject responseObject = new ResponseObject();
		
		TxnLogger.log(this.getClass().getSimpleName(), Log4jImpl.INFO, " [REQUEST] [METHOD_NAME] "+Thread.currentThread().getStackTrace()[1].getMethodName()+" [MSISDN] "+overlayIssuanceData.getCustomerMsisdn() + " [ACCOUNT_NUMBER] "+overlayIssuanceData.getAccountData().getAccountNumber()+" [CUSTOMER_ID] "+overlayIssuanceData.getAccountData().getCustomerID()+" [USER_ID] "+overlayIssuanceData.getAccountData().getUserId()+" [BANK_ID] "+overlayIssuanceData.getAccountData().getBankId());
		
		String accountNumber = formatAccountNumber(overlayIssuanceData.getAccountData().getAccountNumber());
		
					CustomerDetails customerAccountData = iSecureTransactionDAO.fetchCustomerAccountDetails(overlayIssuanceData.getAccountData().getCustomerID(), accountNumber, overlayIssuanceData.getAccountData().getBankId());
					
					if(customerAccountData == null)
					{
							
							responseObject.setStatus(ErrorCodes.INVALIDACCOUNT.getCode());
							responseObject.setMessage(ErrorCodes.INVALIDACCOUNT.getMessage());
						
					}else{
						
						customerAccountData.setAccountStatus("I");
						
						boolean updateStatus = iSecureTransactionDAO.updateEntity(customerAccountData);
						
						if(updateStatus)
						{
							CustomerAccountHistory history = new  CustomerAccountHistory();
							
							history.setCustomerId(overlayIssuanceData.getAccountData().getCustomerID());
							history.setAccountNumber(accountNumber);
							history.setIfscCode(customerAccountData.getIfscCode());
							history.setSubscriberAccountId(customerAccountData);
							history.setActionName(AccountStatus.DE_ACTIVATE.getActionName());
							history.setActionById(overlayIssuanceData.getActor().getId());
							history.setActionByName(overlayIssuanceData.getActor().getName());
							history.setActionByNumber(overlayIssuanceData.getActor().getSrNo());
							history.setAddedOn(new Date());
							
							boolean status = iSecureTransactionDAO.addEntity(history);
							
							if(status)
							{
							responseObject.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
							responseObject.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
							}else{
								
								throw new Exception("Failed to update history");
							}
						}
						
					}
					TxnLogger.log(this.getClass().getSimpleName(), Log4jImpl.INFO, " [RESPONSE] [METHOD_NAME] "+Thread.currentThread().getStackTrace()[1].getMethodName()+" [MSISDN] "+overlayIssuanceData.getCustomerMsisdn() + " [ACCOUNT_NUMBER] "+overlayIssuanceData.getAccountData().getAccountNumber()+" [CUSTOMER_ID] "+overlayIssuanceData.getAccountData().getCustomerID()+" [USER_ID] "+overlayIssuanceData.getAccountData().getUserId()+" [BANK_ID] "+overlayIssuanceData.getAccountData().getBankId() +" [RESPONSE_STATUS] "+responseObject.getStatus()+" [RESPONSE_MESSAGE] "+responseObject.getMessage());
					
		return responseObject;
	}
	
	
	
	@Transactional(rollbackOn=Exception.class)
	private ResponseObject activateAcount(OverlayIssuance overlayIssuanceData) throws Exception
	{
		ResponseObject responseObject = new ResponseObject();
		
		TxnLogger.log(this.getClass().getSimpleName(), Log4jImpl.INFO, " [REQUEST] [METHOD_NAME] "+Thread.currentThread().getStackTrace()[1].getMethodName()+" [MSISDN] "+overlayIssuanceData.getCustomerMsisdn() + " [ACCOUNT_NUMBER] "+overlayIssuanceData.getAccountData().getAccountNumber()+" [CUSTOMER_ID] "+overlayIssuanceData.getAccountData().getCustomerID()+" [USER_ID] "+overlayIssuanceData.getAccountData().getUserId()+" [BANK_ID] "+overlayIssuanceData.getAccountData().getBankId());
		
		String accountNumber = formatAccountNumber(overlayIssuanceData.getAccountData().getAccountNumber());
		
					CustomerDetails customerAccountData = iSecureTransactionDAO.fetchCustomerAccountDetails(overlayIssuanceData.getAccountData().getCustomerID(), accountNumber, overlayIssuanceData.getAccountData().getBankId());
					
					if(customerAccountData == null)
					{
							
							responseObject.setStatus(ErrorCodes.INVALIDACCOUNT.getCode());
							responseObject.setMessage(ErrorCodes.INVALIDACCOUNT.getMessage());
						
					}else{
						
						if(customerAccountData.getAccountStatus().equalsIgnoreCase("A"))
						{
							responseObject.setStatus(ErrorCodes.ACCOUNT_ALREADY_ACTIVE.getCode());
							responseObject.setMessage(ErrorCodes.ACCOUNT_ALREADY_ACTIVE.getMessage());
							
							return responseObject;
						}
						
						if(customerAccountData.getAccountStatus().equalsIgnoreCase("R"))
						{
							responseObject.setStatus(ErrorCodes.INVALIDACCOUNT.getCode());
							responseObject.setMessage(ErrorCodes.INVALIDACCOUNT.getMessage());
							
							return responseObject;
						}
						
						customerAccountData.setAccountStatus("A");
						
						boolean updateStatus = iSecureTransactionDAO.updateEntity(customerAccountData);
						
						if(updateStatus)
						{
							CustomerAccountHistory history = new  CustomerAccountHistory();
							
							history.setCustomerId(overlayIssuanceData.getAccountData().getCustomerID());
							history.setAccountNumber(accountNumber);
							history.setIfscCode(customerAccountData.getIfscCode());
							history.setSubscriberAccountId(customerAccountData);
							history.setActionName(AccountStatus.ACTIVATE.getActionName());
							history.setActionById(overlayIssuanceData.getActor().getId());
							history.setActionByName(overlayIssuanceData.getActor().getName());
							history.setActionByNumber(overlayIssuanceData.getActor().getSrNo());
							history.setAddedOn(new Date());
							
							boolean status = iSecureTransactionDAO.addEntity(history);
							
							if(status)
							{
							responseObject.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
							responseObject.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
							}else{
								
								throw new Exception("Failed to update history");
							}
						}
						
					}
					TxnLogger.log(this.getClass().getSimpleName(), Log4jImpl.INFO, " [RESPONSE] [METHOD_NAME] "+Thread.currentThread().getStackTrace()[1].getMethodName()+" [MSISDN] "+overlayIssuanceData.getCustomerMsisdn() + " [ACCOUNT_NUMBER] "+overlayIssuanceData.getAccountData().getAccountNumber()+" [CUSTOMER_ID] "+overlayIssuanceData.getAccountData().getCustomerID()+" [USER_ID] "+overlayIssuanceData.getAccountData().getUserId()+" [BANK_ID] "+overlayIssuanceData.getAccountData().getBankId() +" [RESPONSE_STATUS] "+responseObject.getStatus()+" [RESPONSE_MESSAGE] "+responseObject.getMessage());
					
		return responseObject;
	}

	@Override
	public ResponseObject fetchCustomerDetails(OverlayIssuance overlayIssuanceData) throws Exception 
	{
		ResponseObject response = new ResponseObject();
		
		//SyncingThread syncThread = getSyncThread();
		try{
			
			if(overlayIssuanceData == null || overlayIssuanceData.getBankId() == null || (overlayIssuanceData.getCustomerID() == null && overlayIssuanceData.getCustomerMsisdn() == null))
			{
				response.setStatus(ErrorCodes.REQUIRED_PARAMETERS_MISSING.getCode());
				response.setMessage(ErrorCodes.REQUIRED_PARAMETERS_MISSING.getMessage());
				
				return response;
			}
			
			Subscriber subscriber = iSecureTransactionDAO.fetchSubscriberDetails(overlayIssuanceData.getCustomerMsisdn(), overlayIssuanceData.getCustomerID());
			
			if(subscriber == null)
			{
				response.setStatus(ErrorCodes.INVALID_CUSTOMER_ID_OR_MOBILE_NUMBER.getCode());
				response.setMessage(ErrorCodes.INVALID_CUSTOMER_ID_OR_MOBILE_NUMBER.getMessage());
				
				return response;
			}
			
			com.ng.transaction.data.CustomerDetails customerDetails = new com.ng.transaction.data.CustomerDetails();
			
			customerDetails.setName(subscriber.getName());
			customerDetails.setMsisdn(subscriber.getMsisdn());
			customerDetails.setCustomerId(subscriber.getCustId());
			customerDetails.setCreatedOn(CommonUtils.getStringFromDate(subscriber.getAddDate(), "dd-MM-yyyy hh:mm:ss"));
			
			List<CustomerAccountHistory> accountData = iSecureTransactionDAO.fetchSubscriberAccountDetails(overlayIssuanceData.getBankId(), overlayIssuanceData.getCustomerID(), overlayIssuanceData.getCustomerMsisdn());
			
			accountData.forEach(c -> c.setAccountNumber(CommonUtils.getFormattedAccountNumber(c.getAccountNumber())));
			accountData.forEach(c -> c.setUserId(c.getSubscriberAccountId().getUserId()));
			
			overlayIssuanceData.setCustomerMsisdn(subscriber.getMsisdn());
			
			List<OverlayIssuance> issuedData = iSecureTransactionDAO.fetchIssuedList(overlayIssuanceData);
			
			customerDetails.setAccountInfo(accountData);
			
			customerDetails.setOverlayInfo(issuedData);
			
			response.setPayload(customerDetails);
			
			response.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
			response.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage() );
				
			/*syncThread.setCustomerId(overlayIssuanceData.getCustomerID());
			
			syncThread.start();*/
			
			return response;
			
		}catch(Exception e)
		{
			e.printStackTrace();
			
			throw e;
		}
	}

	@Transactional(rollbackOn=Exception.class)
	@Override
	public ResponseObject removeAllData(OverlayIssuance overlayIssuanceData) throws Exception 
	{
		ResponseObject response = new ResponseObject();
		
		try{
			
			if(overlayIssuanceData == null || overlayIssuanceData.getCustomerMsisdn() == null)
			{
				response.setStatus(ErrorCodes.REQUIRED_PARAMETERS_MISSING.getCode());
				response.setMessage(ErrorCodes.REQUIRED_PARAMETERS_MISSING.getMessage());
				
				return response;
			}
			
			Subscriber subscriber = iSecureTransactionDAO.fetchSubscriberDetails(overlayIssuanceData.getCustomerMsisdn());
			
			List<InventoryMgmt> inventoryList = iSecureTransactionDAO.fetchInventoryDetailsByMsisdn(overlayIssuanceData.getCustomerMsisdn());
			
			if(subscriber == null || subscriber.getInvMgtId() == null || !subscriber.getMsisdn().equals(overlayIssuanceData.getCustomerMsisdn()))
			{
				response.setStatus(ErrorCodes.INVALID_MOBILE.getCode());
				response.setMessage(ErrorCodes.INVALID_MOBILE.getMessage());
				
				return response;
			}
			
			boolean isProcessed = true;
			
			List<CustomerDetails> customerAccountData = iSecureTransactionDAO.fetchCustomerDetailsByMsisdn(subscriber.getMsisdn());
			
			for(CustomerDetails customerData : customerAccountData)
			{
				List<CustomerAccountHistory> accountHistory = iSecureTransactionDAO.fetchSubscriberAccountDetails(customerData.getBankId(), customerData.getCustomerId(), customerData.getCustomerMsisdn());
				
				for(CustomerAccountHistory customerAccountHistory : accountHistory)
				{
					isProcessed = iSecureTransactionDAO.removeObject(customerAccountHistory);
					
					if(!isProcessed)
						break;
				}
				
				if(isProcessed)
				{
					isProcessed = iSecureTransactionDAO.removeObject(customerData);
				}
				
				if(!isProcessed)
					break;
			}
			
			if(!isProcessed)
			{
				throw new Exception("Issue in purging data");
			}
			
			for(InventoryMgmt inventoryMgmt : inventoryList)
			{
				inventoryMgmt.setCustomerMSISDN(null);
				inventoryMgmt.setProductStatus("OK");
				isProcessed = iSecureTransactionDAO.updateInventory(inventoryMgmt);
				
				if(!isProcessed)
					break;
			}
			
			if(!isProcessed)
			{
				throw new Exception("Issue in purging data");
			}
			
			iSecureTransactionDAO.removeObject(subscriber);
			
			response.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
			response.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
			
			/*syncThread.setCustomerId(overlayIssuanceData.getCustomerID());
			
			syncThread.start();*/
			
			return response;
			
		}catch(Exception e)
		{
			e.printStackTrace();
			
			throw e;
		}
	}
}

