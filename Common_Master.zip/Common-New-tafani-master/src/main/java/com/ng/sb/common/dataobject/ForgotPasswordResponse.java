package com.ng.sb.common.dataobject;
public class ForgotPasswordResponse implements ValidationBean {
	private static final long serialVersionUID = 8598257468870057317L;
	

	private Integer status;
	
	private String message;
	
	private String secretQuestion;

	public String getSecretQuestion() {
		return secretQuestion;
	}

	public void setSecretQuestion(String secretQuestion) {
		this.secretQuestion = secretQuestion;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	
}