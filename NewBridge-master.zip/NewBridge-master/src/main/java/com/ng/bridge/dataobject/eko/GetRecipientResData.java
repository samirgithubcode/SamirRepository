package com.ng.bridge.dataobject.eko;

public class GetRecipientResData {
	private String recipientIdType;

    private String name;

    private String recipientId;

    private String account;

    private String ifsc;

    public String getRecipientIdType ()
    {
        return recipientIdType;
    }

    public void setRecipientIdType (String recipientIdType)
    {
        this.recipientIdType = recipientIdType;
    }

    public String getName ()
    {
        return name;
    }

    public void setName (String name)
    {
        this.name = name;
    }

    public String getRecipientId ()
    {
        return recipientId;
    }

    public void setRecipientId (String recipientId)
    {
        this.recipientId = recipientId;
    }

    public String getAccount ()
    {
        return account;
    }

    public void setAccount (String account)
    {
        this.account = account;
    }

    public String getIfsc ()
    {
        return ifsc;
    }

    public void setIfsc (String ifsc)
    {
        this.ifsc = ifsc;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [recipient_id_type = "+recipientIdType+", name = "+name+", recipient_id = "+recipientId+", account = "+account+", ifsc = "+ifsc+"]";
    }
}
