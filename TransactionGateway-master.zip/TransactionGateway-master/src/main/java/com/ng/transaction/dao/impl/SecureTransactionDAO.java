package com.ng.transaction.dao.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.ng.sb.common.dataobject.Actor;
import com.ng.sb.common.dataobject.OverlayIssuance;
import com.ng.sb.common.model.AccountInfo;
import com.ng.sb.common.model.CustMerchFinInstMapping;
import com.ng.sb.common.model.CustomerAccountHistory;
import com.ng.sb.common.model.CustomerDetails;
import com.ng.sb.common.model.HostSubVersion;
import com.ng.sb.common.model.InventoryMgmt;
import com.ng.sb.common.model.MasterVersion;
import com.ng.sb.common.model.MerchantInfo;
import com.ng.sb.common.model.Partner;
import com.ng.sb.common.model.Provider;
import com.ng.sb.common.model.Subscriber;
import com.ng.sb.common.model.TransactionSecureService;
import com.ng.sb.common.util.CommonUtils;
import com.ng.sb.common.util.SystemConstant;
import com.ng.transaction.dao.ISecureTransactionDAO;
import com.ng.transaction.util.OverlayStatus;
@Repository
public class SecureTransactionDAO  extends TransactionDAO implements ISecureTransactionDAO{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = LoggerFactory.getLogger(SecureTransactionDAO.class);

	@Override
	@Transactional
	public void saveTransactionServiceData(TransactionSecureService securerTansactionService) throws Exception {
		LOGGER.debug("*********** saveTransactionServiceData() starts executing  *************");
		try
		{
			entityManager.persist(securerTansactionService);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			LOGGER.info("Exception occurred in saveTransactionServiceData() method in SecureTransactionDAO --->"+ex.getMessage());
		}
		
	}

	@Override
	@Transactional
	public TransactionSecureService updateTransactionServiceData(TransactionSecureService securerTansactionService)
			throws Exception {
		LOGGER.debug("*********** updateTransactionServiceData() starts executing  *************");
		try
		{
			entityManager.merge(securerTansactionService);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			LOGGER.info("Exception occurred in updateTransactionServiceData() method in SecureTransactionDAO --->"+ex.getMessage());
		}
		return securerTansactionService;
	}

	@Override
	@Transactional
	public MerchantInfo checkKey(String key) throws Exception {
		LOGGER.debug("****************** checkKey() starts executing ***************");
		List<MerchantInfo> list=null;
		try{
			TypedQuery<MerchantInfo> query=entityManager.createNamedQuery("MerchantInfo.findBykey",MerchantInfo.class);
			query.setParameter("key",key);
			list=query.getResultList();
			if(list.size()>0){
				return list.get(0); 
			}
			else
			{
				return null;
			}
		}
		catch(Exception e){
			LOGGER.info("Exception occurred : "+e.getLocalizedMessage());
			e.printStackTrace();
			throw e;
		}
	}

	@Override
	@Transactional
	public CustMerchFinInstMapping getPayeeDetails(String walletId,Partner wId) throws Exception {
		LOGGER.debug("****************** getPayeeDetails() starts executing ***************");
		List<CustMerchFinInstMapping> list=null;
		try{
			TypedQuery<CustMerchFinInstMapping> query=entityManager.createNamedQuery("CustMerchFinInstMapping.findByWalletCodeAndId",CustMerchFinInstMapping.class);
			query.setParameter("walletId",walletId);
			query.setParameter("wId",wId);
			list=query.getResultList();
			if(list.size()>0){
				return list.get(0); 
			}
			else
			{
				return null;
			}
		}
		catch(Exception e){
			LOGGER.info("Exception occurred : "+e.getLocalizedMessage());
			e.printStackTrace();
			throw e;
		}
	}
	
	@Override
	@Transactional
	public Partner checkWalletStatus(Integer walletCode) throws Exception {
		LOGGER.debug("****************** checkWalletStatus() starts executing ***************");
		List<Partner> list=null;
		try{
			TypedQuery<Partner> query=entityManager.createNamedQuery("Partner.findByPartnerCode",Partner.class);
			query.setParameter("partnerCode",walletCode);
			list=query.getResultList();
			if(list.size()>0){
				return list.get(0);
			}
			else{
				return null;
			}
		}
		catch(Exception e){
			LOGGER.info("Exception occurred : "+e.getLocalizedMessage());
			e.printStackTrace();
			throw e;
		}
	}

	@Override
	@Transactional
	public CustMerchFinInstMapping updateCustMerch(CustMerchFinInstMapping custMerchFinInstMapping) throws Exception {
		LOGGER.debug("*********** updateTransactionServiceData() starts executing  *************");
		try
		{
			entityManager.merge(custMerchFinInstMapping);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			LOGGER.info("Exception occurred in updateTransactionServiceData() method in SecureTransactionDAO --->"+ex.getMessage());
		}
		return custMerchFinInstMapping;
	}

	@Override
	@Transactional
	public Provider findProviderByCode(Integer providerCode) throws Exception {
		LOGGER.debug("****************** findProviderByCode() starts executing ***************");
		List<Provider> list=null;
		try{
			TypedQuery<Provider> query=entityManager.createNamedQuery("Provider.findByProviderCode",Provider.class);
			query.setParameter("providerCode",providerCode);
			list=query.getResultList();
			if(list.size()>0){
				return list.get(0);
			}
			else{
				return null;
			}
		}
		catch(Exception e){
			LOGGER.info("Exception occurred : "+e.getLocalizedMessage());
			e.printStackTrace();
			throw e;
		}
	}

	@Override
	public CustMerchFinInstMapping getPayerDetails(Partner wId) throws Exception {
		LOGGER.debug("****************** getPayerDetails() starts executing ***************");
		List<CustMerchFinInstMapping> list=null;
		try{
			TypedQuery<CustMerchFinInstMapping> query=entityManager.createNamedQuery("CustMerchFinInstMapping.findByWalletCode",CustMerchFinInstMapping.class);
			query.setParameter("wId",wId);
			list=query.getResultList();
			if(list.size()>0){
				return list.get(0); 
			}
			else
			{
				return null;
			}
		}
		catch(Exception e){
			LOGGER.info("Exception occurred : "+e.getLocalizedMessage());
			e.printStackTrace();
			throw e;
		}
	}

	@Override
	public InventoryMgmt fetchInventoryDetails(String overlayExternalNumber)  throws Exception 
	{
		LOGGER.debug("****************** fetchInventoryDetails() starts executing ***************");
		InventoryMgmt inventory = null;
		try{
			TypedQuery<InventoryMgmt> query=entityManager.createNamedQuery("InventoryMgmt.findSEByExternalNumber", InventoryMgmt.class);
			
			query.setParameter("externalNo", Long.parseLong(overlayExternalNumber));
			
			inventory = query.getSingleResult();
			
			return inventory;
		}
		catch(Exception e){
			LOGGER.info("Exception occurred : "+e.getLocalizedMessage());
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Subscriber fetchSubscriberDetails(String customerMsisdn) throws Exception 
	{
		LOGGER.debug("****************** fetchSubscriberDetails() starts executing ***************");
		Subscriber subscriber = null;
		try{
			TypedQuery<Subscriber> query=entityManager.createNamedQuery("Subscriber.findByMsisdn", Subscriber.class);
			
			query.setParameter("msisdn", customerMsisdn);
			
			subscriber = query.getSingleResult();
			
		}
		catch(Exception e){
			LOGGER.info("Exception occurred : "+e.getLocalizedMessage());
			e.printStackTrace();
		}
		
		return subscriber;
	}

	@Override
	@Transactional
	public boolean updateSubscriber(Subscriber subscriber) throws Exception {
		LOGGER.debug("****************** updateSubscriber() starts executing ***************");
		try{
			
			entityManager.merge(subscriber);
			
			return true;
		}
		catch(Exception e){
			LOGGER.info("Exception occurred : "+e.getLocalizedMessage());
			e.printStackTrace();
			throw e;
		}
	}

	@Override
	@Transactional
	public boolean updateInventory(InventoryMgmt inventory) throws Exception {
		LOGGER.debug("****************** updateInventory() starts executing ***************");
		try{
			
			entityManager.merge(inventory);
			
			return true;
		}
		catch(Exception e){
			LOGGER.info("Exception occurred : "+e.getLocalizedMessage());
			e.printStackTrace();
			throw e;
		}
	}

	@Override
	public HostSubVersion getHostSubVersion(MasterVersion masterVersionId, AccountInfo hostId) throws Exception 
	{
		LOGGER.debug("****************** getHostSubVersion() starts executing ***************");
		HostSubVersion hostSubVersion = null;
		try{
			TypedQuery<HostSubVersion> query = entityManager.createNamedQuery("HostSubVersion.findByHostIdAndMvId", HostSubVersion.class);
			
			query.setParameter("mvId", masterVersionId);
			
			query.setParameter("hostId", hostId);
			
			List<HostSubVersion> resultData = query.getResultList();
			
			if(resultData != null && !resultData.isEmpty())
			{
				hostSubVersion = resultData.get(0);
			}
			
		}
		catch(Exception e){
			LOGGER.info("Exception occurred : "+e.getLocalizedMessage());
			e.printStackTrace();
			
		}
		
		return hostSubVersion;
	}

	@Override
	@Transactional
	public boolean addCustomerDetails(CustomerDetails customerDetails)
			throws Exception {
		
		LOGGER.debug("*********** addCustomerDetails() starts executing  *************");
		try
		{
			entityManager.persist(customerDetails);
			
			return true;
			
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			LOGGER.info("Exception occurred in addCustomerDetails() method in SecureTransactionDAO --->"+ex.getMessage());
		}
		
		return false;
	}

	@Override
	public Subscriber fetchSubscriberDetailsByCustId(String customerId) throws Exception 
	{
		LOGGER.debug("****************** fetchSubscriberDetailsByCustId() starts executing ***************");
		Subscriber subscriber = null;
		try{
			TypedQuery<Subscriber> query=entityManager.createNamedQuery("Subscriber.findByCustId", Subscriber.class);
			
			query.setParameter("customerId", customerId);
			
			List<Subscriber> resultData = query.getResultList();
			
			if(resultData != null && resultData.size() > 0)
				subscriber = resultData.get(0);
			
		}
		catch(Exception e){
			LOGGER.info("Exception occurred : "+e.getLocalizedMessage());
			e.printStackTrace();
		}
		
		return subscriber;
	}

	@Override
	public List<OverlayIssuance> fetchIssuedList(OverlayIssuance overlayIssuanceData) throws Exception 
	{
		LOGGER.debug("****************** fetchIssuedList() starts executing ***************");
		List<OverlayIssuance> inventory = new ArrayList<OverlayIssuance>();
		try{
			
			StringBuilder builder = new StringBuilder();
			builder.append("select externalNo,customerMSISDN,productStatus,issuedate,issuername,issuerid,issuerno,deactivatorname,deactivatorid,deactivatorno,deactivationdate from InventoryMgmt where customerMSISDN IS NOT NULL AND issuerid IS NOT NULL ");
			
			if(overlayIssuanceData.getCustomerMsisdn() != null) 
				builder.append(" and customerMSISDN='"+overlayIssuanceData.getCustomerMsisdn()+"' ");
			
			if(overlayIssuanceData.getActor() != null && overlayIssuanceData.getActor().getId() != null) 
				builder.append(" and issuerid='"+overlayIssuanceData.getActor().getId()+"' ");
			
			if(overlayIssuanceData.getExternalNumber() != null && !overlayIssuanceData.getExternalNumber().isEmpty()) 
				builder.append(" and externalNo='"+overlayIssuanceData.getExternalNumber()+"' ");
			
			if(overlayIssuanceData.getStatus() != null && overlayIssuanceData.getStatus().equalsIgnoreCase(SystemConstant.ACTIVE)) 
				builder.append(" and productStatus IN ('OK', 'ISSUED') ");
			
			if(overlayIssuanceData.getStatus() != null && overlayIssuanceData.getStatus().equalsIgnoreCase(SystemConstant.TEMP_DEACTIVE)) 
				builder.append(" and productStatus='BLOCK_BY_SYS' ");
			
			if(overlayIssuanceData.getStatus() != null && overlayIssuanceData.getStatus().equalsIgnoreCase(SystemConstant.PERMANENT_DEACTIVE)) 
				builder.append(" and productStatus IN ('DAMAGED', 'RETURN') ");
			
			
			
			Query nativeQuery = entityManager.createNativeQuery(builder.toString());
			
			List<Object[]> resultList = nativeQuery.getResultList();
			
			for(Object[] resultData : resultList)
			{
				OverlayIssuance issuanceData = new OverlayIssuance();
				
				issuanceData.setExternalNumber(""+resultData[0]);
				issuanceData.setCustomerMsisdn((String)resultData[1]);
				issuanceData.setProductStatus(getProductStatus((String)resultData[2]));
				issuanceData.setIssuedOn(CommonUtils.getStringFromDate((Date)resultData[3], "yyyy-MM-dd hh:mm:ss"));
				
				Actor issuer = new Actor();
				
				issuer.setName((String)resultData[4]);
				issuer.setId((String)resultData[5]);
				issuer.setSrNo((String)resultData[6]);
				
				issuanceData.setActor(issuer);
				
				if(resultData[10] != null)
				{
					issuanceData.setDeActivatedOn(CommonUtils.getStringFromDate((Date)resultData[10], "yyyy-MM-dd hh:mm:ss"));
					
					Actor deActivator = new Actor();
					
					deActivator.setName((String)resultData[7]);
					deActivator.setId((String)resultData[8]);
					deActivator.setSrNo((String)resultData[9]);
					
					issuanceData.setDeActivatedBy(deActivator);
				}
				
				inventory.add(issuanceData);
			}
		}
		catch(Exception e){
			LOGGER.info("Exception occurred : "+e.getLocalizedMessage());
			e.printStackTrace();
		}
		return inventory;
	}

	private String getProductStatus(String statusString) 
	{
		String finalStatus = null;
		
		if(statusString == null || statusString.isEmpty())
			return finalStatus;
		
		try
		{
			OverlayStatus overlayStatus = OverlayStatus.getByStatus(statusString) ;
			
			finalStatus = overlayStatus.getStatusType();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return finalStatus;
		
	}
	@Transactional
	@Override
	public boolean updateEntity(Object entityObject) throws Exception 
	{
		LOGGER.debug("****************** updateEntity() starts executing ***************");
		try{
			
			entityManager.merge(entityObject);
			
			return true;
		}
		catch(Exception e){
			LOGGER.info("Exception occurred : "+e.getLocalizedMessage());
			e.printStackTrace();
			throw e;
		}
	}

	@Transactional
	@Override
	public boolean addEntity(Object entityObject) throws Exception 
	{
		LOGGER.debug("*********** addEntity() starts executing  *************");
		try
		{
			entityManager.persist(entityObject);
			
			return true;
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			LOGGER.info("Exception occurred in addEntity() method in SecureTransactionDAO --->"+ex.getMessage());
		}
		return false;
	}

	@Override
	public CustomerDetails fetchCustomerAccountDetails(String customerId, String accountNumber, String bankId) throws Exception 
		{
		LOGGER.debug("****************** fetchCustomerAccountDetails() starts executing ***************");
		List<CustomerDetails> list=null;
		try{
			TypedQuery<CustomerDetails> query=entityManager.createNamedQuery("CustomerDetails.findByCustIdUserIdAccountNumber",CustomerDetails.class);
			query.setParameter("customerId",customerId);
			query.setParameter("accountNumber",accountNumber);
			query.setParameter("bankId",bankId);
			
			list=query.getResultList();
			if(list.size()>0){
				return list.get(0); 
			}
			else
			{
				return null;
			}
		}
		catch(Exception e){
			LOGGER.info("Exception occurred : "+e.getLocalizedMessage());
			e.printStackTrace();
			throw e;
		}
	}

	@Override
	public Subscriber fetchSubscriberDetails(String customerMsisdn, String customerId) throws Exception 
	{
		LOGGER.debug("****************** fetchSubscriberDetails() starts executing ***************");
		Subscriber subscriber = null;
		TypedQuery<Subscriber> query = null;
		try{
			if(customerMsisdn != null && !customerMsisdn.isEmpty())
			{
				query=entityManager.createNamedQuery("Subscriber.findByMsisdn", Subscriber.class);
				
				query.setParameter("msisdn", customerMsisdn);
				
			}else if(customerId != null && !customerId.isEmpty())
			{
				query=entityManager.createNamedQuery("CustomerDetails.findBySubscriberByCustId", Subscriber.class);
				
				query.setParameter("customerId", customerId);
			}
			
			
			subscriber = query.getSingleResult();
			
		}
		catch(Exception e){
			LOGGER.info("Exception occurred : "+e.getLocalizedMessage());
			e.printStackTrace();
		}
		
		return subscriber;
	}

	@Override
	public List<CustomerAccountHistory> fetchSubscriberAccountDetails(String bankId, String customerId, String customerMsisdn) throws Exception 
	{
		LOGGER.debug("****************** fetchSubscriberAccountDetails() starts executing ***************");
		List<CustomerAccountHistory> list=null;
		TypedQuery<CustomerAccountHistory> query= null;
		try{
			if(customerId != null && !customerId.isEmpty())
			{
				query=entityManager.createNamedQuery("CustomerAccountHistory.findByCustIdandBankId",CustomerAccountHistory.class);
				query.setParameter("customerId",customerId);
				query.setParameter("bankId",bankId);
			}else if(customerMsisdn != null && !customerMsisdn.isEmpty())
			{
				query=entityManager.createNamedQuery("CustomerAccountHistory.findByCustMsisdnandBankId",CustomerAccountHistory.class);
				query.setParameter("customerMsisdn",customerMsisdn);
				query.setParameter("bankId",bankId);
			}
			
			list=query.getResultList();
			
			return list;
		}
		catch(Exception e){
			LOGGER.info("Exception occurred : "+e.getLocalizedMessage());
			e.printStackTrace();
			throw e;
		}
	}

	@Override
	public boolean isValidIfscCodeBankMapping(String ifscCode, String bankId) throws Exception 
	{ 
		List<CustomerDetails> customerData = null;
		TypedQuery<CustomerDetails> query= null;
		
		boolean isValid = true; 
			try{
				
				query=entityManager.createNamedQuery("CustomerDetails.findByIfscCode",CustomerDetails.class);
				query.setParameter("ifscCode", ifscCode);
				
				customerData = query.getResultList();
				
				for(CustomerDetails customerDetails : customerData)
				{
					if(customerDetails.getBankId() != null && !customerDetails.getBankId().isEmpty() && !customerDetails.getBankId().equalsIgnoreCase(bankId))
					{
						isValid = false;
						break;
					}
				}
				
			}catch(Exception e)
			{
				e.printStackTrace();
			}
		
		return isValid;
	}

	@Override
	public List<CustomerDetails> fetchCustomerDetailsByMsisdn(String msisdn) throws Exception 
	{
		List<CustomerDetails> customerData = null;
		TypedQuery<CustomerDetails> query= null;
		
			try{
				
				query=entityManager.createNamedQuery("CustomerDetails.findByMsisdn",CustomerDetails.class);
				query.setParameter("msisdn", msisdn);
				
				customerData = query.getResultList();
				
			}catch(Exception e)
			{
				e.printStackTrace();
			}
		
		return customerData;
	}

	@Override
	public boolean removeObject(Object objectEntity) throws Exception 
	{
		boolean processStatus = false;
		
			try{
				
				entityManager.remove(objectEntity);
				processStatus = true;
			}catch(Exception e)
			{
				e.printStackTrace();
			}
		
		return processStatus;
	}

	@Override
	public List<InventoryMgmt> fetchInventoryDetailsByMsisdn(String msisdn) throws Exception 
	{
		LOGGER.debug("****************** fetchInventoryDetailsByMsisdn() starts executing ***************");
		List<InventoryMgmt> inventory = null;
		try{
			TypedQuery<InventoryMgmt> query=entityManager.createNamedQuery("InventoryMgmt.findByCustomerMSISDN", InventoryMgmt.class);
			
			query.setParameter("customerMSISDN", msisdn);
			
			inventory = query.getResultList();
			
			return inventory;
		}
		catch(Exception e){
			LOGGER.info("Exception occurred : "+e.getLocalizedMessage());
			e.printStackTrace();
		}
		return null;
	}
	
}
