/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "TransactionInfo")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "TransactionInfo.findAll", query = "SELECT t FROM TransactionInfo t"),
    @NamedQuery(name = "TransactionInfo.findById", query = "SELECT t FROM TransactionInfo t WHERE t.id = :id"),
    @NamedQuery(name = "TransactionInfo.findByTxnId", query = "SELECT t FROM TransactionInfo t WHERE t.txnId = :txnId"),
    @NamedQuery(name = "TransactionInfo.findByMsisdn", query = "SELECT t FROM TransactionInfo t WHERE t.msisdn = :msisdn"),
    @NamedQuery(name = "TransactionInfo.findByServiceDefnitioon", query = "SELECT t FROM TransactionInfo t WHERE t.serviceDefnitioon = :serviceDefnitioon"),
    @NamedQuery(name = "TransactionInfo.findByShortCode", query = "SELECT t FROM TransactionInfo t WHERE t.shortCode = :shortCode"),
    @NamedQuery(name = "TransactionInfo.findByRemoteIp", query = "SELECT t FROM TransactionInfo t WHERE t.remoteIp = :remoteIp"),
    @NamedQuery(name = "TransactionInfo.findByProductCode", query = "SELECT t FROM TransactionInfo t WHERE t.productCode = :productCode"),
    @NamedQuery(name = "TransactionInfo.findBySkuInternalNumber", query = "SELECT t FROM TransactionInfo t WHERE t.skuInternalNumber = :skuInternalNumber"),
    @NamedQuery(name = "TransactionInfo.findByRequestMsg", query = "SELECT t FROM TransactionInfo t WHERE t.requestMsg = :requestMsg"),
    @NamedQuery(name = "TransactionInfo.findByResponseMsg", query = "SELECT t FROM TransactionInfo t WHERE t.responseMsg = :responseMsg"),
    @NamedQuery(name = "TransactionInfo.findByResponseStatus", query = "SELECT t FROM TransactionInfo t WHERE t.responseStatus = :responseStatus"),
    @NamedQuery(name = "TransactionInfo.findByDate", query = "SELECT t FROM TransactionInfo t WHERE t.date = :date")})
public class TransactionInfo implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
    
    @Column(name = "msisdn", length = 25)
    private String msisdn;
    @Column(name = "serviceDefnitioon", length = 50)
    private String serviceDefnitioon;
    @Column(name = "txnId", length = 30)
    private String txnId;
    
    @Column(name = "shortCode")
    private Integer shortCode;
    @Column(name = "remoteIp", length = 50)
    private String remoteIp;
    @Column(name = "productCode")
    private Integer productCode;
    @Column(name = "skuInternalNumber", length = 16)
    private String skuInternalNumber;
    @Column(name = "skuExternalNumber", length = 16)
    private String skuExternalNumber;
    @Column(name = "requestData", length = 250)
    private String requestPlainMessage;
    @Column(name = "requestMsg", length = 250)
    private String requestMsg;
    @Column(name = "responseMsg", length = 1000)
    private String responseMsg;
    @Column(name = "processTime")
    private Long processTime;
    @Column(name = "responseStatus")
    private Boolean responseStatus;
    @Basic(optional = false)
    @Column(name = "date", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date date;
    @JoinColumn(name = "mvId", referencedColumnName = "id")
    @ManyToOne
    private MasterVersion mvId;
    @JoinColumn(name = "hostId", referencedColumnName = "id")
    @ManyToOne
    private AccountInfo hostId;
    @JoinColumn(name = "hsvId", referencedColumnName = "id")
    @ManyToOne
    private HostSubVersion hsvId;

    public TransactionInfo() {
    	//empty
    }

    public TransactionInfo(Integer id) {
        this.id = id;
    }

    public TransactionInfo(Integer id, Date date) {
        this.id = id;
        this.date = date;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    

    public String getMsisdn() {
        return msisdn;
    }

    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }

    public String getServiceDefnitioon() {
        return serviceDefnitioon;
    }

    public void setServiceDefnitioon(String serviceDefnitioon) {
        this.serviceDefnitioon = serviceDefnitioon;
    }

    public Integer getShortCode() {
        return shortCode;
    }

    public void setShortCode(Integer shortCode) {
        this.shortCode = shortCode;
    }

    public String getRemoteIp() {
        return remoteIp;
    }

    public void setRemoteIp(String remoteIp) {
        this.remoteIp = remoteIp;
    }

    public Integer getProductCode() {
        return productCode;
    }

    public void setProductCode(Integer productCode) {
        this.productCode = productCode;
    }

    public String getSkuInternalNumber() {
        return skuInternalNumber;
    }

    public void setSkuInternalNumber(String skuInternalNumber) {
        this.skuInternalNumber = skuInternalNumber;
    }

    public String getRequestMsg() {
        return requestMsg;
    }

    public void setRequestMsg(String requestMsg) {
        this.requestMsg = requestMsg;
    }

    public String getTxnId() {
        return txnId;
    }

    public void setTxnId(String txnId) {
        this.txnId = txnId;
    }
    
    public String getResponseMsg() {
        return responseMsg;
    }

    public void setResponseMsg(String responseMsg) {
        this.responseMsg = responseMsg;
    }

    public Boolean getResponseStatus() {
        return responseStatus;
    }

    public void setResponseStatus(Boolean responseStatus) {
        this.responseStatus = responseStatus;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public MasterVersion getMvId() {
        return mvId;
    }

    public void setMvId(MasterVersion mvId) {
        this.mvId = mvId;
    }

    public AccountInfo getHostId() {
        return hostId;
    }

    public void setHostId(AccountInfo hostId) {
        this.hostId = hostId;
    }

    public HostSubVersion getHsvId() {
        return hsvId;
    }

    public void setHsvId(HostSubVersion hsvId) {
        this.hsvId = hsvId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    } 

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof TransactionInfo)) {
            return false;
        }
        TransactionInfo other = (TransactionInfo) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.TransactionInfo[ id=" + id + " ]";
    }

	public String getSkuExternalNumber() {
		return skuExternalNumber;
	}

	public void setSkuExternalNumber(String skuExternalNumber) {
		this.skuExternalNumber = skuExternalNumber;
	}

	public String getRequestPlainMessage() {
		return requestPlainMessage;
	}

	public void setRequestPlainMessage(String requestPlainMessage) {
		this.requestPlainMessage = requestPlainMessage;
	}

	public Long getProcessTime() {
		return processTime;
	}

	public void setProcessTime(Long processTime) {
		this.processTime = processTime;
	}
   
    
}
