package com.ng.sb.common.dataobject;

public class IConstants {
	
	public  static final String B_T_B = "B_T_B";
	public  static final String B_T_CC = "B_T_CC";
	public  static final String B_T_IMPS = "B_T_IMPS";
	public  static final String B_T_W = "B_T_W";
	public  static final String IMPS_T_B = "IMPS_T_B";
	public  static final String IMPS_T_CC = "IMPS_T_CC";
	public  static final String IMPS_T_IMPS = "IMPS_T_IMPS";
	public  static final String IMPS_T_W = "IMPS_T_W";
	public  static final String CC_T_B = "CC_T_B";
	public  static final String CC_T_CC = "CC_T_CC";
	public  static final String CC_T_IMPS = "CC_T_IMPS";
	public  static final String CC_T_W = "CC_T_W";
	public  static final String W_T_B = "W_T_B";
	public  static final String W_T_CC = "W_T_CC";
	public  static final String W_T_IMPS = "W_T_IMPS";
	public  static final String W_T_W = "W_T_W";
	public  static final String CHANGE_PIN = "CHANGE_PIN";
	public  static final String BANK = "BANK";
	public  static final String CREDITCARD = "CREDITCARD";
	public  static final String WALLET = "WALLET";
	public  static final String IMPS = "IMPS";
	public  static final String RI_T_B = "RI_T_B";
	public  static final String RI_T_RI = "RI_T_RI";
	public  static final String RI_T_CC = "RI_T_CC";
	public  static final String RI_T_IMPS = "RI_T_IMPS";
	public  static final String RI_T_W = "RI_T_W";
	
	public  static final String GENERATE_MPIN = "GENERATE_MPIN";
	public  static final String CHEQUE_STATUS = "CHEQUE_STATUS";
	public  static final String CHECK_BALANCE = "CHECK_BALANCE";
	public  static final String ADD_BANK_ACCOUNT = "ADD_BANK_ACCOUNT";
	public  static final String ADD_MY_PAYEE = "ADD_PAYEE";
	public  static final String ADD_MY_MERCHANT = "ADD_MERCHANT";
	public  static final String EDIT_MY_PAYEE = "EDIT_PAYEE";
	public  static final String EDIT_MY_MERCHANT = "EDIT_MERCHANT";
	public  static final String DELETE_MY_PAYEE = "DELETE_PAYEE";
	public  static final String DELETE_MY_MERCHANT = "DELETE_MERCHANT";
	public  static final String CREATE_PIN = "CREATE_PIN";
	public  static final String WALLET_CASH_OUT_TO_WALLET = "WALLET_CASH_OUT_TO_WALLET";
	public  static final String CREATE_WALLET_PIN = "CREATE_WALLET_PIN";
	public  static final String CHANGE_WALLET_PIN = "CHANGE_WALLET_PIN";
	public  static final String MWALLET_CHECK_BALANCE = "MWALLET_CHECK_BALANCE";
	public  static final String STOP_CHEQUE = "STOP_CHEQUE";
	public  static final String BANKING_LAST_5_TRANS = "BANKING_LAST_5_TRANS";
	public  static final String CHQ_BOOK_REQUEST = "CHQ_BOOK_REQUEST";
	public  static final String MONEY_TRANSFER = "MONEY_TRANSFER";
	
	public  static final String SERVICE_PARAM_FROM = "from";
	public  static final String SERVICE_PARAM_MESSAGE = "message";
	public  static final String SERVICE_PARAM_TIMESTAMP = "ts";
	
	public  static final String SERVICE_PARAM1 = "param1";
	 public  static final String SERVICE_PARAM2 = "param2";
	 public  static final String SERVICE_PARAM3 = "param3";
	 public  static final String SERVICE_SMSCID = "smscid";
	 public  static final String SERVICE_CHARSET = "charset";
	 public  static final String SERVICE_BMSG = "bmsg";
	 
	 
	 public  static final String CATEGORY_DTH = "DTH";
	 public  static final String CATEGORY_TELEPHONE = "Telephones";
	 public  static final String CATEGORY_GAS = "Gas";
	 public  static final String CATEGORY_DTH_RECHARGE = "DTH Recharge";
	 public  static final String CATEGORY_PREPAID_MOBILE = "Prepaid Mobile";
	 public  static final String CATEGORY_CELLULAR_PHONES = "Cellular Phones";
	 
	 public  static final String SUVIDHA_MOBILERECHARGE_BILL_PAYMENT_URL = "SUVIDHA_MOBILERECHARGE_BILL_PAYMENT_URL";
	 
	 public  static final String CATEGORY_GAS_BILLENQUIRYREQ = "Gas";
	 public  static final String CATEGORY_TELEPHONE_BILLENQUIRYREQ = "Telephones";
	 public  static final String CATEGORY_DTH_BILLENQUIRYREQ = "DTH";
	 public  static final String CATEGORY_ELECTRICITY = "Electricity";

	 public  static final String METHOD_FSP = "METHOD_FSP";
	 public  static final String METHOD_RI_FSP = "METHOD_RI_FSP";
	 public  static final String METHOD_FIRST_CALL = "METHOD_FIRST_CALL";
	 public  static final String METHOD_SECOND_CALL = "METHOD_SECOND_CALL";
	 public  static final String TIMEOUT = "TIMEOUT";
	 
	 public  static final String STATUS = "STATUS";
	 public  static final String TRUE = "TRUE";
	 public  static final String FALSE = "FALSE";
	 public  static final String FIRST_NAME = "FIRST_NAME";
	 public  static final String LAST_NAME = "LAST_NAME";
	 public  static final String AVAILABLE_BALANCE = "AVAILABLE_BALANCE";
	 public  static final String MSG = "MESSAGE";
	 public  static final String NO_WALLET = "NO_WALLET";
	 public  static final String NO_BALANCE = "NO_BALANCE";
	 public  static final String SUCCESS = "SUCCESS";
	 
	 public  static final String TELCO = "TELCO";
	 public  static final String W_W ="W_W";
	 public  static final String BILL_PAY ="BILL_PAY";
	 public  static final String TOP_UP ="TOP_UP";
	 public  static final String HOST ="host";
	 
	 public  static final String PENDING ="PENDING";
	 public  static final String COMPLETE ="COMPLETE";
	 public  static final String OPEN ="OPEN";
	 
	 public  static final String CANCEL ="CANCEL";
	 public  static final String PP ="PP";
	 public  static final String PARTIAL_COMPLETE ="PARTIAL_COMPLETE";
	 public  static final String SHIPPED ="SHIPPED";
	 public  static final Integer ONE =1;     
	 public  static final String PARTIAL_SHIPPED ="PARTIAL_SHIPPED";
	 public  static final String INSTOCK ="INSTOCK";
	 public  static final String PARSED ="PARSED";
	 public  static final String CANCELLED ="CANCELLED";
	 
	 public  static final String TRADING_WALLET ="TRADING_WALLET";
	 
	 public  static final String COMMISSION_WALLET ="COMMISSION_WALLET";
	 private IConstants(){}
}
