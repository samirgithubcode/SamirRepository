/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "sys_mis_menu")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "SysMisMenu.findAll", query = "SELECT s FROM SysMisMenu s"),
    @NamedQuery(name = "SysMisMenu.findById", query = "SELECT s FROM SysMisMenu s WHERE s.id = :id"),
    @NamedQuery(name = "SysMisMenu.findByIndex", query = "SELECT s FROM SysMisMenu s WHERE s.index = :index"),
    @NamedQuery(name = "SysMisMenu.findByMenuName", query = "SELECT s FROM SysMisMenu s WHERE s.menuName = :menuName"),
    @NamedQuery(name = "SysMisMenu.findByDescription", query = "SELECT s FROM SysMisMenu s WHERE s.description = :description"),
    @NamedQuery(name = "SysMisMenu.findByAddDate", query = "SELECT s FROM SysMisMenu s WHERE s.addDate = :addDate"),
    @NamedQuery(name = "SysMisMenu.findByEditDate", query = "SELECT s FROM SysMisMenu s WHERE s.editDate = :editDate")})
public class SysMisMenu implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
    @Basic(optional = false)
    @Column(name = "index", nullable = false)
    private int index;
    @Basic(optional = false)
    @Column(name = "menu_name", nullable = false, length = 20)
    private String menuName;
    @Column(name = "description", length = 100)
    private String description;
    @Basic(optional = false)
    @Column(name = "add_date", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date addDate;
    @Column(name = "edit_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date editDate;
    @JoinColumn(name = "sys_account_type_id", referencedColumnName = "id", nullable = false)
    @ManyToOne(optional = false)
    private SysAccountType sysAccountTypeId;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "sysMisMenuId")
    private Collection<SysMisSubMenu> sysMisSubMenuCollection;

    public SysMisMenu() {
    	//default constructor
    }

    public SysMisMenu(Integer id) {
        this.id = id;
    }

    public SysMisMenu(Integer id, int index, String menuName, Date addDate) {
        this.id = id;
        this.index = index;
        this.menuName = menuName;
        this.addDate = addDate;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public String getMenuName() {
        return menuName;
    }

    public void setMenuName(String menuName) {
        this.menuName = menuName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getAddDate() {
        return addDate;
    }

    public void setAddDate(Date addDate) {
        this.addDate = addDate;
    }

    public Date getEditDate() {
        return editDate;
    }

    public void setEditDate(Date editDate) {
        this.editDate = editDate;
    }

    public SysAccountType getSysAccountTypeId() {
        return sysAccountTypeId;
    }

    public void setSysAccountTypeId(SysAccountType sysAccountTypeId) {
        this.sysAccountTypeId = sysAccountTypeId;
    }

    @XmlTransient
    public Collection<SysMisSubMenu> getSysMisSubMenuCollection() {
        return sysMisSubMenuCollection;
    }

    public void setSysMisSubMenuCollection(Collection<SysMisSubMenu> sysMisSubMenuCollection) {
        this.sysMisSubMenuCollection = sysMisSubMenuCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof SysMisMenu)) {
            return false;
        }
        SysMisMenu other = (SysMisMenu) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.SysMisMenu[ id=" + id + " ]";
    }
    
}
