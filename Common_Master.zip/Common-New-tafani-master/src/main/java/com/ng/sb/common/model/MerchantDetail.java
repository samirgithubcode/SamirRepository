/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "MerchantDetail")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "MerchantDetail.findAll", query = "SELECT m FROM MerchantDetail m"),
    @NamedQuery(name = "MerchantDetail.findById", query = "SELECT m FROM MerchantDetail m WHERE m.id = :id"),
    @NamedQuery(name = "MerchantDetail.findByMsisdn", query = "SELECT m FROM MerchantDetail m WHERE m.msisdn = :msisdn"),
    @NamedQuery(name = "MerchantDetail.findByMerchantId", query = "SELECT m FROM MerchantDetail m WHERE m.merchantId = :merchantId"),
    @NamedQuery(name = "MerchantDetail.findByMmid", query = "SELECT m FROM MerchantDetail m WHERE m.mmid = :mmid"),
    @NamedQuery(name = "MerchantDetail.findByBankAccountNo", query = "SELECT m FROM MerchantDetail m WHERE m.bankAccountNo = :bankAccountNo"),
    @NamedQuery(name = "MerchantDetail.findByIfscCode", query = "SELECT m FROM MerchantDetail m WHERE m.ifscCode = :ifscCode"),
    @NamedQuery(name = "MerchantDetail.findByCardHolderName", query = "SELECT m FROM MerchantDetail m WHERE m.cardHolderName = :cardHolderName"),
    @NamedQuery(name = "MerchantDetail.findByCardNo", query = "SELECT m FROM MerchantDetail m WHERE m.cardNo = :cardNo"),
    @NamedQuery(name = "MerchantDetail.findByExpiryDate", query = "SELECT m FROM MerchantDetail m WHERE m.expiryDate = :expiryDate")})
public class MerchantDetail implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
    
    @Column(name = "merchantId", length = 30)
    private String merchantId;
    @Column(name = "mmid")
    private Integer mmid;
    @Basic(optional = false)
    @Column(name = "msisdn", nullable = false, length = 10)
    private String msisdn;
    @Column(name = "bankAccountNo", length = 20)
    private String bankAccountNo;
    @Column(name = "ifscCode", length = 20)
    private String ifscCode;
    @Column(name = "cardHolderName", length = 50)
    private String cardHolderName;
    @Column(name = "cardNo", length = 30)
    private String cardNo;
    @Column(name = "expiryDate")
    private String expiryDate;
    @JoinColumn(name = "accountLoginId", referencedColumnName = "id", nullable = false)
    @ManyToOne(optional = false)
    private AccountLoginInfo accountLoginId;
    @JoinColumn(name = "accountInfoId", referencedColumnName = "id")
    @ManyToOne
    private AccountInfo accountInfoId;
    @JoinColumn(name = "instrumentId", referencedColumnName = "id")
    @ManyToOne
    private FinancialInstrument instrumentId;
    @JoinColumn(name = "walletId", referencedColumnName = "id")
    @ManyToOne
    private Partner walletId;

    public MerchantDetail() {
    	//empty
    }

    public MerchantDetail(Integer id) {
        this.id = id;
    }

    public MerchantDetail(Integer id, String msisdn) {
        this.id = id;
        this.msisdn = msisdn;
    }

   
    public String getMsisdn() {
        return msisdn;
    }

    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(String merchantId) {
        this.merchantId = merchantId;
    }

    public Integer getMmid() {
        return mmid;
    }

    public void setMmid(Integer mmid) {
        this.mmid = mmid;
    }

    public String getBankAccountNo() {
        return bankAccountNo;
    }

    public void setBankAccountNo(String bankAccountNo) {
        this.bankAccountNo = bankAccountNo;
    }

    public String getIfscCode() {
        return ifscCode;
    }

    public void setIfscCode(String ifscCode) {
        this.ifscCode = ifscCode;
    }

    public String getCardHolderName() {
        return cardHolderName;
    }

    public void setCardHolderName(String cardHolderName) {
        this.cardHolderName = cardHolderName;
    }

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    public String getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }

    public AccountLoginInfo getAccountLoginId() {
        return accountLoginId;
    }

    public void setAccountLoginId(AccountLoginInfo accountLoginId) {
        this.accountLoginId = accountLoginId;
    }

    public AccountInfo getAccountInfoId() {
        return accountInfoId;
    }

    public void setAccountInfoId(AccountInfo accountInfoId) {
        this.accountInfoId = accountInfoId;
    }

    public FinancialInstrument getInstrumentId() {
        return instrumentId;
    }
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }
    public void setInstrumentId(FinancialInstrument instrumentId) {
        this.instrumentId = instrumentId;
    }

    public Partner getWalletId() {
        return walletId;
    }

    public void setWalletId(Partner walletId) {
        this.walletId = walletId;
    }

   

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof MerchantDetail)) {
            return false;
        }
        MerchantDetail other = (MerchantDetail) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }


    @Override
    public String toString() {
        return "com.ng.sb.common.model.MerchantDetail[ id=" + id + " ]";
    }
    
}
