package com.ng.sb.common.dataobject;

import java.util.List;
import java.util.Map;

public class InventoryMgmtData<T> extends BaseObjectData {
	private static final long serialVersionUID = 1L;
	private Integer orderId;
	private String productCode;
	private String readerId;
	private String qtyreader;
	private String group;
	private String packageids;
	private String invoiceno;
    private String invoicedate;
    private String mainseriesfrom;
    private String mainseriesto;
    private Integer small;
    private Integer smallPackSize;
	private Integer medium;
	private Integer mediumPackSize;
    private Integer large;
    private Integer largePackSize;
    private Integer extraLarge;
    private Integer extraLargePackSize;
    private Integer xxl;
    private Integer xxlPackSize;
    private String shipTo;
    private Integer shippedItemCount;
    private String shippingStatus;
    private T dataObj;
    private List<T> dataObjList;
    
    
	public String getShipTo() {
		return shipTo;
	}

	public void setShipTo(String shipTo) {
		this.shipTo = shipTo;
	}

    public Integer getSmallPackSize() {
		return smallPackSize;
	}

	public void setSmallPackSize(Integer smallPackSize) {
		this.smallPackSize = smallPackSize;
	}

	public Integer getMediumPackSize() {
		return mediumPackSize;
	}

	public void setMediumPackSize(Integer mediumPackSize) {
		this.mediumPackSize = mediumPackSize;
	}

	public Integer getLargePackSize() {
		return largePackSize;
	}

	public void setLargePackSize(Integer largePackSize) {
		this.largePackSize = largePackSize;
	}

	public Integer getExtraLargePackSize() {
		return extraLargePackSize;
	}

	public void setExtraLargePackSize(Integer extraLargePackSize) {
		this.extraLargePackSize = extraLargePackSize;
	}

	public Integer getXxlPackSize() {
		return xxlPackSize;
	}

	public void setXxlPackSize(Integer xxlPackSize) {
		this.xxlPackSize = xxlPackSize;
	}

    public Integer getSmall() {
		return small;
	}

	public void setSmall(Integer small) {
		this.small = small;
	}

    public Integer getMedium() {
		return medium;
	}

	public void setMedium(Integer medium) {
		this.medium = medium;
	}

	public Integer getLarge() {
		return large;
	}

	public void setLarge(Integer large) {
		this.large = large;
	}

	public Integer getExtraLarge() {
		return extraLarge;
	}

	public void setExtraLarge(Integer extraLarge) {
		this.extraLarge = extraLarge;
	}

	public Integer getXxl() {
		return xxl;
	}

	public void setXxl(Integer xxl) {
		this.xxl = xxl;
	}

	public Integer getXxxl() {
		return xxxl;
	}

	public void setXxxl(Integer xxxl) {
		this.xxxl = xxxl;
	}

	private Integer xxxl;
	
 
	public String getMainseriesfrom() {
		return mainseriesfrom;
	}

	public void setMainseriesfrom(String mainseriesfrom) {
		this.mainseriesfrom = mainseriesfrom;
	}

	public String getMainseriesto() {
		return mainseriesto;
	}

	public void setMainseriesto(String mainseriesto) {
		this.mainseriesto = mainseriesto;
	}

	public String getInvoicedate() {
		return invoicedate;
	}

	public void setInvoicedate(String invoicedate) {
		this.invoicedate = invoicedate;
	}

	public String getInvoiceno() {
		return invoiceno;
	}

	public void setInvoiceno(String invoiceno) {
		this.invoiceno = invoiceno;
	}

	public String getPackageids() {
		return packageids;
	}

	public void setPackageids(String packageids) {
		this.packageids = packageids;
	}

	public String getGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	}

	public String getReaderId() {
		return readerId;
	}

	public void setReaderId(String readerId) {
		this.readerId = readerId;
	}

	public String getQtyreader() {
		return qtyreader;
	}

	public void setQtyreader(String qtyreader) {
		this.qtyreader = qtyreader;
	}

	private Integer mvCode;
	private Integer mvId;
	private String mvName;
	private Integer mvProductStock;
	private Integer hsvProductStock;
	private Integer availableStock;
	private Integer productOrderQty;
	private Integer hostId;
	private String unitName;
	private List<OrderShipData> availableStockList;
	private List<CommonInfoData> masterVersionList;
	private List<CommonInfoData> hostSubVersionList;
	private String onBehalfAccount;
	private String selectOnbehalf;
	private Integer totalboxes;
	private String agentName;
	private List<CommonInfoData> childAccountList;
	private List<CommonInfoData> groupAccountList;
	private String seInternalNumber;
	private String seExternalNumber;
	private String productStatus;
	private Integer unitsOrdered;
	private Integer unitsReceived;
	private Integer unitsPending;
	private Integer scanId;
	private Integer numberofrow;
	private Integer gotopage;
	private String cardType;
	private String[] hidorderno;
	private Map<Integer, String> orderMap;
	private String orderDoneBy;
	private String orderDoneFor;
	private String orderDoneTo;
	private String imageLocation;
	private transient Map masterVersionMap;
	private transient Map hostVersionMap;
	private transient Map productTypeMap;
	private String successMessage;
	private String errorMessage;
	private String selectTypeId;
	private Integer entityId;
	private String statusId;
	private List<InventoryMgmtData<?>> orderReceivedlist;
	private String orderfor;
	private String orderBy;
	private Integer unitordered;
	private Integer orderType;
	private String statusType;
	private String orderDate;
	private String fromDate;
	private String toDate;
	private Integer orderShippedQty;
	private Integer orderPendingQty;
	private String orderTypeVal;
	private String onBehalfType;
	private String groupCode;
	private String hostName;
	private Integer distId;
	private String distName;
	private Integer subDistId;
	private String subDistName;
	private Integer agentId;
	private List<InventoryMgmtData<?>> filterorderlist;
	private List<InventoryMgmtData<?>> shippinghistorylist;
	private Integer productunitspending;
	private String[] ordertoshipped;
	private List<InventoryMgmtData<?>> tobeshipped;
	private Integer[] shippedunit;
	private String[] mversion;
	private String[] products;
	private String qrCodeValue;
	private String boxSeriesFrom;
	private String boxSeriesTo;
	private String boxNumber;
	private Integer boxSize;
	private Integer sno;
	private Integer qty;
	private Integer qtyPayCard;
	private String[] orderforlist;
	private Long externalno;
	private String customerphone;
	private String dateofIssuence;
	private List<InventoryMgmtData<?>> soldunsoldlist;
	private List<InventoryMgmtData<?>> shippinglist;

	private String orderTypeVl;

	private Integer availableUnits;
	private List<InventoryMgmtData<?>> inventoryMgmtList;
	private String inventoryFor;

	private Integer boxTypeId;
	private String productType;
	private Integer noOfBoxes;
	private Integer boxType;
	private List<InventoryMgmtData<?>> shipdataList;
	private Map<Integer, String> productmap;
	private List<InventoryMgmtData<?>> inventoryMgmtDataList;
	private List<List<InventoryMgmtData<?>>> orderReceivedlistoflist;
	private String vendorName;
	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}
	public String getGroupCode() {
		return groupCode;
	}

	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}






	public String getCardType() {
		return cardType;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	public Integer getNumberofrow() {
		return numberofrow;
	}

	public void setNumberofrow(Integer numberofrow) {
		this.numberofrow = numberofrow;
	}

	public Integer getGotopage() {
		return gotopage;
	}

	public void setGotopage(Integer gotopage) {
		this.gotopage = gotopage;
	}

	public Map<Integer, String> getOrderMap() {
		return orderMap;
	}

	public void setOrderMap(Map<Integer, String> orderMap) {
		this.orderMap = orderMap;
	}

	public String[] getHidorderno() {
		return hidorderno;
	}

	public void setHidorderno(String[] hidorderno) {
		this.hidorderno = hidorderno;
	}

	public Integer getScanId() {
		return scanId;
	}

	public void setScanId(Integer scanId) {
		this.scanId = scanId;
	}

	public String[] getOrdertoshipped() {
		return ordertoshipped;
	}

	public void setOrdertoshipped(String[] ordertoshipped) {
		this.ordertoshipped = ordertoshipped;
	}

	public String getQrCodeValue() {
		return qrCodeValue;
	}

	public void setQrCodeValue(String qrCodeValue) {
		this.qrCodeValue = qrCodeValue;
	}

	public Integer getQtyPayCard() {
		return qtyPayCard;
	}

	public void setQtyPayCard(Integer qtyPayCard) {
		this.qtyPayCard = qtyPayCard;
	}

	public List<InventoryMgmtData<?>> getSoldunsoldlist() {
		return soldunsoldlist;
	}

	public void setSoldunsoldlist(List<InventoryMgmtData<?>> soldunsoldlist) {
		this.soldunsoldlist = soldunsoldlist;
	}

	public Integer getSno() {
		return sno;
	}

	public void setSno(Integer sno) {
		this.sno = sno;
	}

	public Long getExternalno() {
		return externalno;
	}

	public void setExternalno(Long externalno) {
		this.externalno = externalno;
	}

	public String getCustomerphone() {
		return customerphone;
	}

	public void setCustomerphone(String customerphone) {
		this.customerphone = customerphone;
	}

	public String getDateofIssuence() {
		return dateofIssuence;
	}

	public void setDateofIssuence(String dateofIssuence) {
		this.dateofIssuence = dateofIssuence;
	}

	
	public void setOrderReceivedlistoflist(List<List<InventoryMgmtData<?>>> orderReceivedlistoflist) {
		this.orderReceivedlistoflist = orderReceivedlistoflist;
	}

	public List<List<InventoryMgmtData<?>>> getOrderReceivedlistoflist() {
		return orderReceivedlistoflist;
	}

	public String[] getOrderforlist() {
		return orderforlist;
	}

	public void setOrderforlist(String[] orderforlist) {
		this.orderforlist = orderforlist;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public List<InventoryMgmtData<?>> getShippinglist() {
		return shippinglist;
	}

	public void setShippinglist(List<InventoryMgmtData<?>> shippinglist) {
		this.shippinglist = shippinglist;
	}

	public String[] getProducts() {
		return products;
	}

	public void setProducts(String[] products) {
		this.products = products;
	}

	public String[] getMversion() {
		return mversion;
	}

	public void setMversion(String[] mversion) {
		this.mversion = mversion;
	}

	public Integer getAvailableUnits() {
		return availableUnits;
	}

	public void setInventoryMgmtList(List<InventoryMgmtData<?>> inventoryMgmtList) {
		this.inventoryMgmtList = inventoryMgmtList;
	}

	public List<InventoryMgmtData<?>> getInventoryMgmtList() {
		return inventoryMgmtList;
	}

	public Integer[] getShippedunit() {
		return shippedunit;
	}

	public void setShippedunit(Integer[] shippedunit) {
		this.shippedunit = shippedunit;
	}

	public List<InventoryMgmtData<?>> getTobeshipped() {
		return tobeshipped;
	}

	public void setTobeshipped(List<InventoryMgmtData<?>> tobeshipped) {
		this.tobeshipped = tobeshipped;
	}

	public String getOrderDoneBy() {
		return orderDoneBy;
	}

	public List<InventoryMgmtData<?>> getShippinghistorylist() {
		return shippinghistorylist;
	}

	public void setShippinghistorylist(List<InventoryMgmtData<?>> shippinghistorylist) {
		this.shippinghistorylist = shippinghistorylist;
	}

	public void setOrderDoneBy(String orderDoneBy) {
		this.orderDoneBy = orderDoneBy;
	}

	public String getOrderDoneFor() {
		return orderDoneFor;
	}

	public void setOrderDoneFor(String orderDoneFor) {
		this.orderDoneFor = orderDoneFor;
	}

	public String getOrderDoneTo() {
		return orderDoneTo;
	}

	public void setOrderDoneTo(String orderDoneTo) {
		this.orderDoneTo = orderDoneTo;
	}

	public Integer getUnitsPending() {
		return unitsPending;
	}

	public void setUnitsPending(Integer unitsPending) {
		this.unitsPending = unitsPending;
	}

	public Integer getUnitsOrdered() {
		return unitsOrdered;
	}

	public void setUnitsOrdered(Integer unitsOrdered) {
		this.unitsOrdered = unitsOrdered;
	}

	public Integer getUnitsReceived() {
		return unitsReceived;
	}

	public void setUnitsReceived(Integer unitsReceived) {
		this.unitsReceived = unitsReceived;
	}


	public void setInventoryFor(String inventoryFor) {
		this.inventoryFor = inventoryFor;
	}

	public void setOnBehalfAccount(String onBehalfAccount) {
		this.onBehalfAccount = onBehalfAccount;
	}

	public String getOnBehalfAccount() {
		return onBehalfAccount;
	}

	public void setSelectOnbehalf(String selectOnbehalf) {
		this.selectOnbehalf = selectOnbehalf;
	}

	public String getSelectOnbehalf() {
		return selectOnbehalf;
	}

	public void setTotalboxes(Integer totalboxes) {
		this.totalboxes = totalboxes;
	}

	public Integer getTotalboxes() {
		return totalboxes;
	}

	public Integer getBoxTypeId() {
		return boxTypeId;
	}

	public void setBoxTypeId(Integer boxTypeId) {
		this.boxTypeId = boxTypeId;
	}

	public void setStatusId(String statusId) {
		this.statusId = statusId;
	}

	public String getStatusId() {
		return statusId;
	}

	public List<InventoryMgmtData<?>> getOrderReceivedlist() {
		return orderReceivedlist;
	}

	public void setOrderReceivedlist(List<InventoryMgmtData<?>> orderReceivedlist) {
		this.orderReceivedlist = orderReceivedlist;
	}

	public Integer getUnitordered() {
		return unitordered;
	}

	public void setUnitordered(Integer unitordered) {
		this.unitordered = unitordered;
	}

	public String getOrderBy() {
		return orderBy;
	}

	public void setOrderBy(String orderBy) {
		this.orderBy = orderBy;
	}

	public String getOrderfor() {
		return orderfor;
	}

	public void setOrderfor(String orderfor) {
		this.orderfor = orderfor;
	}

	public Integer getEntityId() {
		return entityId;
	}

	public void setEntityId(Integer entityId) {
		this.entityId = entityId;
	}

	public void setSelectTypeId(String selectTypeId) {
		this.selectTypeId = selectTypeId;
	}

	public String getSelectTypeId() {
		return selectTypeId;
	}

	public void setNoOfBoxes(Integer noOfBoxes) {
		this.noOfBoxes = noOfBoxes;
	}

	public Integer getNoOfBoxes() {
		return noOfBoxes;
	}

	public void setBoxType(Integer boxType) {
		this.boxType = boxType;
	}

	public Integer getBoxType() {
		return boxType;
	}

	public enum OrderStatus {
		PENDING, PARTIAL_CANCELLED, CANCELLED, PARTIAL_SHIPPED, SHIPPED, PARTIAL_REJECTED, REJECTED
	}

	public enum ShippingStatus {
		PARTIAL_CANCELLED, CANCELLED, PARTIAL_SHIPPED, SHIPPED, PARTIAL_REJECTED, REJECTED
	}

	public void setProductunitspending(Integer productunitspending) {
		this.productunitspending = productunitspending;
	}

	public Integer getProductunitspending() {
		return productunitspending;
	}

	public List<InventoryMgmtData<?>> getShipdataList() {
		return shipdataList;
	}

	public void setShipdataList(List<InventoryMgmtData<?>> shipdataList) {
		this.shipdataList = shipdataList;
	}

	public String getInventoryFor() {
		return inventoryFor;
	}

	public List<InventoryMgmtData<?>> getFilterorderlist() {
		return filterorderlist;
	}

	public void setFilterorderlist(List<InventoryMgmtData<?>> filterorderlist) {
		this.filterorderlist = filterorderlist;
	}

	public List<InventoryMgmtData<?>> getInventoryMgmtDataList() {
		return inventoryMgmtDataList;
	}

	public void setProductmap(Map<Integer, String> productmap) {
		this.productmap = productmap;
	}

	public Map<Integer, String> getProductmap() {
		return productmap;
	}

	public String getSeInternalNumber() {
		return seInternalNumber;
	}

	public void setSeInternalNumber(String seInternalNumber) {
		this.seInternalNumber = seInternalNumber;
	}

	public String getSeExternalNumber() {
		return seExternalNumber;
	}

	public void setSeExternalNumber(String seExternalNumber) {
		this.seExternalNumber = seExternalNumber;
	}

	public String getProductStatus() {
		return productStatus;
	}

	public void setProductStatus(String productStatus) {
		this.productStatus = productStatus;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getOnBehalfType() {
		return onBehalfType;
	}

	public void setOnBehalfType(String onBehalfType) {
		this.onBehalfType = onBehalfType;
	}

	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public Integer getDistId() {
		return distId;
	}

	public void setDistId(Integer distId) {
		this.distId = distId;
	}

	public Integer getSubDistId() {
		return subDistId;
	}

	public void setSubDistId(Integer subDistId) {
		this.subDistId = subDistId;
	}

	public Integer getAgentId() {
		return agentId;
	}

	public void setAgentId(Integer agentId) {
		this.agentId = agentId;
	}



	public List<CommonInfoData> getGroupAccountList() {
		return groupAccountList;
	}

	public void setGroupAccountList(List<CommonInfoData> groupAccountList) {
		this.groupAccountList = groupAccountList;
	}

	public List<CommonInfoData> getChildAccountList() {
		return childAccountList;
	}

	public void setChildAccountList(List<CommonInfoData> childAccountList) {
		this.childAccountList = childAccountList;
	}

	public String getOrderTypeVal() {
		return orderTypeVal;
	}

	public void setOrderTypeVal(String orderTypeVal) {
		this.orderTypeVal = orderTypeVal;
	}

	public String getAgentName() {
		return agentName;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}

	public String getDistName() {
		return distName;
	}

	public void setDistName(String distName) {
		this.distName = distName;
	}

	public String getHostName() {
		return hostName;
	}

	public void setHostName(String hostName) {
		this.hostName = hostName;
	}

	public String getSubDistName() {
		return subDistName;
	}

	public void setSubDistName(String subDistName) {
		this.subDistName = subDistName;
	}

	public Integer getOrderShippedQty() {
		return orderShippedQty;
	}

	public void setOrderShippedQty(Integer orderShippedQty) {
		this.orderShippedQty = orderShippedQty;
	}

	public Integer getOrderPendingQty() {
		return orderPendingQty;
	}

	public void setOrderPendingQty(Integer orderPendingQty) {
		this.orderPendingQty = orderPendingQty;
	}

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	public Integer getOrderType() {
		return orderType;
	}

	public void setOrderType(Integer orderType) {
		this.orderType = orderType;
	}

	public String getStatusType() {
		return statusType;
	}

	public void setStatusType(String statusType) {
		this.statusType = statusType;
	}

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}


	public String getMvName() {
		return mvName;
	}

	public void setMvName(String mvName) {
		this.mvName = mvName;
	}

	public Integer getAvailableStock() {
		return availableStock;
	}

	public void setAvailableStock(Integer availableStock) {
		this.availableStock = availableStock;
	}

	public List<OrderShipData> getAvailableStockList() {
		return availableStockList;
	}

	public void setAvailableStockList(List<OrderShipData> availableStockList) {
		this.availableStockList = availableStockList;
	}

	public Integer getMvId() {
		return mvId;
	}

	public void setMvId(Integer mvId) {
		this.mvId = mvId;
	}



	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public Integer getMvCode() {
		return mvCode;
	}

	public void setMvCode(Integer mvCode) {
		this.mvCode = mvCode;
	}

	public Integer getMvProductStock() {
		return mvProductStock;
	}

	public void setMvProductStock(Integer mvProductStock) {
		this.mvProductStock = mvProductStock;
	}

	public Integer getHsvProductStock() {
		return hsvProductStock;
	}

	public void setHsvProductStock(Integer hsvProductStock) {
		this.hsvProductStock = hsvProductStock;
	}

	public Integer getProductOrderQty() {
		return productOrderQty;
	}

	public void setProductOrderQty(Integer productOrderQty) {
		this.productOrderQty = productOrderQty;
	}

	public String getUnitName() {
		return unitName;
	}

	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	public List<CommonInfoData> getMasterVersionList() {
		return masterVersionList;
	}

	public void setMasterVersionList(List<CommonInfoData> masterVersionList) {
		this.masterVersionList = masterVersionList;
	}

	public List<CommonInfoData> getHostSubVersionList() {
		return hostSubVersionList;
	}

	public void setHostSubVersionList(List<CommonInfoData> hostSubVersionList) {
		this.hostSubVersionList = hostSubVersionList;
	}

	public String getImageLocation() {
		return imageLocation;
	}

	public void setImageLocation(String imageLocation) {
		this.imageLocation = imageLocation;
	}

	public Map getMasterVersionMap() {
		return masterVersionMap;
	}

	public void setMasterVersionMap(Map masterVersionMap) {
		this.masterVersionMap = masterVersionMap;
	}

	public Map getHostVersionMap() {
		return hostVersionMap;
	}

	public void setHostVersionMap(Map hostVersionMap) {
		this.hostVersionMap = hostVersionMap;
	}

	public Map getProductTypeMap() {
		return productTypeMap;
	}

	public void setProductTypeMap(Map productTypeMap) {
		this.productTypeMap = productTypeMap;
	}

	public String getSuccessMessage() {
		return successMessage;
	}

	public void setSuccessMessage(String successMessage) {
		this.successMessage = successMessage;
	}

	public Integer getHostId() {
		return hostId;
	}

	public void setHostId(Integer hostId) {
		this.hostId = hostId;
	}

	public void setAvailableUnits(Integer availableUnits) {
		this.availableUnits = availableUnits;
	}

	public String getOrderTypeVl() {
		return orderTypeVl;
	}

	public void setOrderTypeVl(String orderTypeVl) {
		this.orderTypeVl = orderTypeVl;
	}

	
	public Integer getQty() {
		return qty;
	}

	public void setQty(Integer qty) {
		this.qty = qty;
	}

	public String getBoxSeriesFrom() {
		return boxSeriesFrom;
	}

	public void setBoxSeriesFrom(String boxSeriesFrom) {
		this.boxSeriesFrom = boxSeriesFrom;
	}

	public String getBoxSeriesTo() {
		return boxSeriesTo;
	}

	public void setBoxSeriesTo(String boxSeriesTo) {
		this.boxSeriesTo = boxSeriesTo;
	}

	public String getBoxNumber() {
		return boxNumber;
	}

	public void setBoxNumber(String boxNumber) {
		this.boxNumber = boxNumber;
	}

	public Integer getBoxSize() {
		return boxSize;
	}

	public void setBoxSize(Integer boxSize) {
		this.boxSize = boxSize;
	}

	public void setInventoryMgmtDataList(List<InventoryMgmtData<?>> inventoryMgmtDataList) {
		this.inventoryMgmtDataList = inventoryMgmtDataList;
	}

	/**
	 * @return the shippedItemCount
	 */
	public Integer getShippedItemCount() {
		return shippedItemCount;
	}

	/**
	 * @param shippedItemCount the shippedItemCount to set
	 */
	public void setShippedItemCount(Integer shippedItemCount) {
		this.shippedItemCount = shippedItemCount;
	}

	/**
	 * @return the dataObjList
	 */
	public List<T> getDataObjList() {
		return dataObjList;
	}

	/**
	 * @param dataObjList the dataObjList to set
	 */
	public void setDataObjList(List<T> dataObjList) {
		this.dataObjList = dataObjList;
	}

	/**
	 * @return the dataObj
	 */
	public T getDataObj() {
		return dataObj;
	}

	/**
	 * @param dataObj the dataObj to set
	 */
	public void setDataObj(T dataObj) {
		this.dataObj = dataObj;
	}

	/**
	 * @return the shippingStatus
	 */
	public String getShippingStatus() {
		return shippingStatus;
	}

	/**
	 * @param shippingStatus the shippingStatus to set
	 */
	public void setShippingStatus(String shippingStatus) {
		this.shippingStatus = shippingStatus;
	}
}
