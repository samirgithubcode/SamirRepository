package com.ng.sb.common.dataobject;


import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.format.annotation.DateTimeFormat;

public class PhysicalRecieptData extends BaseObjectData{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer scanId;
	private String qrCodeValue;
	private String ordernumber;
	private String cardType;
	private Integer boxReceived;
	private List<PhysicalRecieptData> physicalRecieptDataList;
	private String product;
	private String masterVersion;
	private Integer unitQuantity;
	private Integer unitReceived;
	private Integer pendingQuantity;
	private Integer orderId;
	private Map<Integer,String> orderDetails;
	private String invoiceNumber;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date invoiceDate;
	private Integer vendorId;
	private Integer shortBoxes;
	private Integer shortOverlays;
	private Integer productss;
	private String productCode;
	private String masterVersionCode;
	private Integer entityId;
	
	
	
	public Integer getEntityId() {
		return entityId;
	}
	public void setEntityId(Integer entityId) {
		this.entityId = entityId;
	}
	public Integer getProductss() {
		return productss;
	}
	public void setProductss(Integer productss) {
		this.productss = productss;
	}
	public String getCardType() {
		return cardType;
	}
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getMasterVersionCode() {
		return masterVersionCode;
	}
	public void setMasterVersionCode(String masterVersionCode) {
		this.masterVersionCode = masterVersionCode;
	}

	public Integer getShortBoxes() {
		return shortBoxes;
	}
	public void setShortBoxes(Integer shortBoxes) {
		this.shortBoxes = shortBoxes;
	}
	public Integer getShortOverlays() {
		return shortOverlays;
	}
	public void setShortOverlays(Integer shortOverlays) {
		this.shortOverlays = shortOverlays;
	}
	public Integer getVendorId() {
		return vendorId;
	}
	public void setVendorId(Integer vendorId) {
		this.vendorId = vendorId;
	}
	public Integer getOrderId() {
		return orderId;
	}
	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}
	public Map<Integer, String> getOrderDetails() {
		return orderDetails;
	}
	public void setOrderDetails(Map<Integer, String> orderDetails) {
		this.orderDetails = orderDetails;
	}
	public String getInvoiceNumber() {
		return invoiceNumber;
	}
	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}
	public Date getInvoiceDate() {
		return invoiceDate;
	}
	public void setInvoiceDate(Date invoiceDate) {
		this.invoiceDate = invoiceDate;
	}
	public List<PhysicalRecieptData> getPhysicalRecieptDataList() {
		return physicalRecieptDataList;
	}
	public void setPhysicalRecieptDataList(List<PhysicalRecieptData> physicalRecieptDataList) {
		this.physicalRecieptDataList = physicalRecieptDataList;
	}
	public Integer getUnitQuantity() {
		return unitQuantity;
	}
	public void setUnitQuantity(Integer unitQuantity) {
		this.unitQuantity = unitQuantity;
	}
	public Integer getUnitReceived() {
		return unitReceived;
	}
	public void setUnitReceived(Integer unitReceived) {
		this.unitReceived = unitReceived;
	}
	public Integer getPendingQuantity() {
		return pendingQuantity;
	}
	public void setPendingQuantity(Integer pendingQuantity) {
		this.pendingQuantity = pendingQuantity;
	}
	public String getOrdernumber() {
		return ordernumber;
	}
	public void setOrdernumber(String ordernumber) {
		this.ordernumber = ordernumber;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public String getMasterVersion() {
		return masterVersion;
	}
	public void setMasterVersion(String masterVersion) {
		this.masterVersion = masterVersion;
	}
	
	public Integer getBoxReceived() {
		return boxReceived;
	}
	public void setBoxReceived(Integer boxReceived) {
		this.boxReceived = boxReceived;
	}
	public Integer getScanId() {
		return scanId;
	}
	public void setScanId(Integer scanId) {
		this.scanId = scanId;
	}
	public String getQrCodeValue() {
		return qrCodeValue;
	}
	public void setQrCodeValue(String qrCodeValue) {
		this.qrCodeValue = qrCodeValue;
	}
}
