package com.ng.sb.common.dataobject;

import java.io.Serializable;

/**
 * @author amardeep
 *
 */
public class ServicePartnerData implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int servicePartnerId;
	private String servicePartnerName;
	private String url;
	private int priority;
	
	public int getServicePartnerId() {
		return servicePartnerId;
	}
	public void setServicePartnerId(int servicePartnerId) {
		this.servicePartnerId = servicePartnerId;
	}
	public String getServicePartnerName() {
		return servicePartnerName;
	}
	public void setServicePartnerName(String servicePartnerName) {
		this.servicePartnerName = servicePartnerName;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public int getPriority() {
		return priority;
	}
	public void setPriority(int priority) {
		this.priority = priority;
	}
}
