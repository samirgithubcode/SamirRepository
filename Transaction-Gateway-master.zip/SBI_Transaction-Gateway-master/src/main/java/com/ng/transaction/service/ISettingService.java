/**
 * 
 */
package com.ng.transaction.service;

import com.ng.sb.common.dataobject.BridgeDataObject;

/**
 * @author gaurav
 * Service for Settings
 */
public interface ISettingService extends ITransactionService 
{
	public BridgeDataObject changePin(BridgeDataObject bridgeDataObject);
	public BridgeDataObject createPin(BridgeDataObject bridgeDataObject);
	
	public BridgeDataObject changeWalletPin(BridgeDataObject bridgeDataObject);
	public BridgeDataObject createWalletPin(BridgeDataObject bridgeDataObject);
	
	public BridgeDataObject saveMyBankAccount(BridgeDataObject bridgeDataObject);
	public BridgeDataObject editMyBankAccount(BridgeDataObject bridgeDataObject);
	public BridgeDataObject deleteMyBankAccount(BridgeDataObject bridgeDataObject);
	
	public BridgeDataObject saveMyCreditCard(BridgeDataObject bridgeDataObject);
	public BridgeDataObject editMyCreditCard(BridgeDataObject bridgeDataObject);
	public BridgeDataObject deleteMyCreditCard(BridgeDataObject bridgeDataObject);
	
	public BridgeDataObject saveMyIMPS(BridgeDataObject bridgeDataObject);
	
	public BridgeDataObject saveMyIndividual(BridgeDataObject bridgeDataObject);
	public BridgeDataObject editMyIndividual(BridgeDataObject bridgeDataObject);
	public BridgeDataObject deleteMyIndividual(BridgeDataObject bridgeDataObject);
	
	public BridgeDataObject saveMyMerchant(BridgeDataObject bridgeDataObject);
	public BridgeDataObject editMyMerchant(BridgeDataObject bridgeDataObject);
	public BridgeDataObject deleteMyMerchant(BridgeDataObject bridgeDataObject);
	
	public BridgeDataObject saveMyForex(BridgeDataObject bridgeDataObject);
	public BridgeDataObject editMyForex(BridgeDataObject bridgeDataObject);
	public BridgeDataObject deleteMyForex(BridgeDataObject bridgeDataObject);
	
	public BridgeDataObject saveMyBiller(BridgeDataObject bridgeDataObject);
	public BridgeDataObject editMyBiller(BridgeDataObject bridgeDataObject);
	public BridgeDataObject deleteMyBiller(BridgeDataObject bridgeDataObject);
	
	public BridgeDataObject last5Transactions(BridgeDataObject bridgeDataObject);
	
	public BridgeDataObject autoTopUp(BridgeDataObject bridgeDataObject);
	
	public BridgeDataObject recoverMySettings(BridgeDataObject bridgeDataObject);
	
	public BridgeDataObject configOTP(BridgeDataObject bridgeDataObject);
	

}
