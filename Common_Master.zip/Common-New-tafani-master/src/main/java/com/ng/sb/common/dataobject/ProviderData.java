package com.ng.sb.common.dataobject;

import java.util.Set;


/**
 * @author abhishek
 *
 */
public class ProviderData extends BaseObjectData implements Comparable<ProviderData>{

	private static final long serialVersionUID = 1L;
	private CategoryData category;
	private String styleValue;
	private String fspStyleValue;
	private String riFspStyleValue;
	private String thirdPartyCode;
	private String fspThirdPartyCode;
	private String riFspThirdPartyCode;
	private String directDisableValue;
	private String fspDisableValue;
	private String riFspDisableValue;
	private Set<PartnerData> partners;
	
	public ProviderData() {
		//default constructor
	}

	public ProviderData(Integer code,Integer catCode) {
		super.setCode(code);
		if(this.category==null){
			this.category=new CategoryData();
		}
		this.category.setCode(catCode);
	}
	
	public ProviderData(String style,String disableValue)
	{
		setStyleValue(style);
		setFspStyleValue(style);
		setRiFspStyleValue(style);
		setDirectDisableValue(disableValue);
		setFspDisableValue(disableValue);
		setRiFspDisableValue(disableValue);
	}

	public String getFspThirdPartyCode() {
		return fspThirdPartyCode;
	}

	public void setFspThirdPartyCode(String fspThirdPartyCode) {
		this.fspThirdPartyCode = fspThirdPartyCode;
	}

	public String getRiFspThirdPartyCode() {
		return riFspThirdPartyCode;
	}

	public void setRiFspThirdPartyCode(String riFspThirdPartyCode) {
		this.riFspThirdPartyCode = riFspThirdPartyCode;
	}

	public String getFspStyleValue() {
		return fspStyleValue;
	}

	public void setFspStyleValue(String fspStyleValue) {
		this.fspStyleValue = fspStyleValue;
	}

	public String getRiFspStyleValue() {
		return riFspStyleValue;
	}

	public void setRiFspStyleValue(String riFspStyleValue) {
		this.riFspStyleValue = riFspStyleValue;
	}
	
	public String getDirectDisableValue() {
		return directDisableValue;
	}

	public void setDirectDisableValue(String directDisableValue) {
		this.directDisableValue = directDisableValue;
	}

	public String getFspDisableValue() {
		return fspDisableValue;
	}

	public void setFspDisableValue(String fspDisableValue) {
		this.fspDisableValue = fspDisableValue;
	}

	public String getRiFspDisableValue() {
		return riFspDisableValue;
	}

	public void setRiFspDisableValue(String riFspDisableValue) {
		this.riFspDisableValue = riFspDisableValue;
	}

	public String getThirdPartyCode() {
		return thirdPartyCode;
	}

	public void setThirdPartyCode(String thirdPartyCode) {
		this.thirdPartyCode = thirdPartyCode;
	}

	public String getStyleValue() {
		return styleValue;
	}

	public void setStyleValue(String styleValue) {
		this.styleValue = styleValue;
	}

	public Set<PartnerData> getPartners() {
		return partners;
	}

	public void setPartners(Set<PartnerData> partners) {
		this.partners = partners;
	}

	public CategoryData getCategory() {
		return category;
	}

	public void setCategory(CategoryData category) {
		this.category = category;
	}

	@Override
	public int compareTo(ProviderData pData) {
		return this.name.compareTo(pData.name);
	}
	@Override
    public boolean equals(Object object) {
		
	boolean	check= true;
	if(object!=null){
        if (!(object instanceof ProviderData)) {
        	check= false;
        }
        ProviderData other = (ProviderData) object;
        if((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
	}
        return check;
        
    }
	@Override
	   public int hashCode() {
	       int hash = 0;
	       hash += (id != null ? id.hashCode() : 0);
	       return hash;
	   }
}
