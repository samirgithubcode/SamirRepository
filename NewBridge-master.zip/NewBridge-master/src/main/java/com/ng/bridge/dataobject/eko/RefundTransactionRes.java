package com.ng.bridge.dataobject.eko;

public class RefundTransactionRes {

	 private String responseTypeId;

	    private String message;

	    private String responseStatusId;

	    private String status;
	    private InvalidParam invalidParam;
	    private RefundTransactionResData data;
	    
	    
	    public String getMessage ()
	    {
	        return message;
	    }

	    public void setMessage (String message)
	    {
	        this.message = message;
	    }
	    public String getResponseStatusId ()
	    {
	        return responseStatusId;
	    }
	    public String getResponseTypeId ()
	    {
	        return responseTypeId;
	    }

	    public void setResponseTypeId (String responseTypeId)
	    {
	        this.responseTypeId = responseTypeId;
	    }
	    public void setResponseStatusId (String responseStatusId)
	    {
	        this.responseStatusId = responseStatusId;
	    }

	   
		public RefundTransactionResData getData() {
			return data;
		}

		

			public void setInvalidParams(InvalidParam invalidParam) {
				this.invalidParam = invalidParam;
			}

		  public String getStatus ()
		    {
		        return status;
		    }
		  public void setData(RefundTransactionResData data) {
				this.data = data;
			}
			 public InvalidParam getInvalidParams() {
					return invalidParam;
				}
		    public void setStatus (String status)
		    {
		        this.status = status;
		    }
		

	 


}
