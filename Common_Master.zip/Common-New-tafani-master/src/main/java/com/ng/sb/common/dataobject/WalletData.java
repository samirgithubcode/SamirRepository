package com.ng.sb.common.dataobject;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.ng.sb.common.model.WalletType;
@JsonInclude(Include.NON_NULL)
public class WalletData  extends BaseObjectData implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int walletTypeId;
	private String walletTypeName;
	private String walletTypeDesc;
	private String status;
	private Date startDate;
	private Date endDate;
	private Integer amount;
	private List<WalletType> walletTypeDetails;
	private List<WalletData> walletDetails;
	private String walletModeName;
	private Integer partnerCode;
	private Integer host;
	private Integer distributor;
	private Integer subDistributor;
	private Integer agent;
	private String accountType;
	private Double balance;
	private Date modefiedDate;
	private String walletNickName;
	private Map<Integer,String> hostMap;
	private Map<Integer,String> distMap;
	private Map<Integer,String> subDistMap;
	private Map<Integer,String> agentMap;
	private String accountNumber;
	private Double openingBalance;
	private Double closingBalance;
	private String txnNature;
	 private String txnId;
	 private String txnType;
	 private String subscriberId;
	 private String companyId;
	 private String companyUser;
	private Double walletBalance;
	private String comment;
	private String reference;
	public Integer getAmount() {
		return amount;
	}
	public void setAmount(Integer amount) {
		this.amount = amount;
	}
	public Integer getPartnerCode() {
		return partnerCode;
	}
	public void setPartnerCode(Integer partnerCode) {
		this.partnerCode = partnerCode;
	}
	public List<WalletType> getWalletTypeDetails() {
		return walletTypeDetails;
	}
	public void setWalletTypeDetails(List<WalletType> walletTypeDetails) {
		this.walletTypeDetails = walletTypeDetails;
	}
	public String getWalletTypeDesc() {
		return walletTypeDesc;
	}
	public void setWalletTypeDesc(String walletTypeDesc) {
		this.walletTypeDesc = walletTypeDesc;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	
	public int getWalletTypeId() {
		return walletTypeId;
	}
	public void setWalletTypeId(int walletTypeId) {
		this.walletTypeId = walletTypeId;
	}
	public String getWalletTypeName() {
		return walletTypeName;
	}
	public void setWalletTypeName(String walletTypeName) {
		this.walletTypeName = walletTypeName;
	}
	public String getWalletModeName() {
		return walletModeName;
	}
	public void setWalletModeName(String walletModeName) {
		this.walletModeName = walletModeName;
	}
	public String getWalletNickName() {
		return walletNickName;
	}
	public void setWalletNickName(String walletNickName) {
		this.walletNickName = walletNickName;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public Double getBalance() {
		return balance;
	}
	public void setBalance(Double balance) {
		this.balance = balance;
	}
	public Date getModefiedDate() {
		return modefiedDate;
	}
	public void setModefiedDate(Date modefiedDate) {
		this.modefiedDate = modefiedDate;
	}
	public List<WalletData> getWalletDetails() {
		return walletDetails;
	}
	public void setWalletDetails(List<WalletData> walletDetails) {
		this.walletDetails = walletDetails;
	}
	public Integer getHost() {
		return host;
	}
	public void setHost(Integer host) {
		this.host = host;
	}
	public Integer getDistributor() {
		return distributor;
	}
	public void setDistributor(Integer distributor) {
		this.distributor = distributor;
	}
	public Integer getSubDistributor() {
		return subDistributor;
	}
	public void setSubDistributor(Integer subDistributor) {
		this.subDistributor = subDistributor;
	}
	public Integer getAgent() {
		return agent;
	}
	public void setAgent(Integer agent) {
		this.agent = agent;
	}
	public Map<Integer, String> getHostMap() {
		return hostMap;
	}
	public void setHostMap(Map<Integer, String> hostMap) {
		this.hostMap = hostMap;
	}
	public Map<Integer, String> getDistMap() {
		return distMap;
	}
	public void setDistMap(Map<Integer, String> distMap) {
		this.distMap = distMap;
	}
	public Map<Integer, String> getSubDistMap() {
		return subDistMap;
	}
	public void setSubDistMap(Map<Integer, String> subDistMap) {
		this.subDistMap = subDistMap;
	}
	public Map<Integer, String> getAgentMap() {
		return agentMap;
	}
	public void setAgentMap(Map<Integer, String> agentMap) {
		this.agentMap = agentMap;
	}
	public Double getWalletBalance() {
		return walletBalance;
	}
	public void setWalletBalance(Double walletBalance) {
		this.walletBalance = walletBalance;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getReference() {
		return reference;
	}
	public void setReference(String reference) {
		this.reference = reference;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public Double getOpeningBalance() {
		return openingBalance;
	}
	public void setOpeningBalance(Double openingBalance) {
		this.openingBalance = openingBalance;
	}
	public Double getClosingBalance() {
		return closingBalance;
	}
	public void setClosingBalance(Double closingBalance) {
		this.closingBalance = closingBalance;
	}
	public String getTxnNature() {
		return txnNature;
	}
	public void setTxnNature(String txnNature) {
		this.txnNature = txnNature;
	}
	public String getTxnId() {
		return txnId;
	}
	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}
	public String getTxnType() {
		return txnType;
	}
	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}
	public String getSubscriberId() {
		return subscriberId;
	}
	public void setSubscriberId(String subscriberId) {
		this.subscriberId = subscriberId;
	}
	public String getCompanyId() {
		return companyId;
	}
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}
	public String getCompanyUser() {
		return companyUser;
	}
	public void setCompanyUser(String companyUser) {
		this.companyUser = companyUser;
	}
}
