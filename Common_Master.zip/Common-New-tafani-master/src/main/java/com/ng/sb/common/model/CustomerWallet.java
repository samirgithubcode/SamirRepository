package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.*;


/**
 * @author abhishek
 *
 */
@Entity
@Table(name="customerWallet")
@NamedQueries({
	@NamedQuery(name="CustomerWallet.findAll", query="SELECT c FROM CustomerWallet c"),
	@NamedQuery(name="CustomerWallet.findByCustomerId", query="SELECT c FROM CustomerWallet c where c.customerId = :customerId"),
})
public class CustomerWallet implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false)
	private Integer id;

	@Column(name="balance", nullable=false)
	private Integer balance;

	@Column(name="status", nullable=false, length=1)
	private String status;

	//bi-directional many-to-one association to Partner
	@ManyToOne
	@JoinColumn(name="walletId", nullable=false)
	private Partner walletId;

	//bi-directional many-to-one association to Customer
	@ManyToOne
	@JoinColumn(name="customerId", nullable=false)
	private Customer customerId;

	public CustomerWallet() {
		//empty
	}

	public CustomerWallet(Integer id) {
		this.id = id;
	}
	
	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getBalance() {
		return this.balance;
	}

	public void setBalance(Integer balance) {
		this.balance = balance;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Partner getWalletId() {
		return this.walletId;
	}

	public void setWalletId(Partner walletId) {
		this.walletId = walletId;
	}

	public Customer getCustomerId() {
		return this.customerId;
	}

	public void setCustomerId(Customer customerId) {
		this.customerId = customerId;
	}

}