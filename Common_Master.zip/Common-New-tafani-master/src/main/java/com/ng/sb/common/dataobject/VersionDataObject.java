package com.ng.sb.common.dataobject;

import java.io.Serializable;
import java.util.List;
import java.util.Map;


public class VersionDataObject implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int hostVersionId;
	private String hostVersionName;
	private String hostVersionNumber;
	private List<ServiceStkData> serviceStkDatas;
	private Map<String,ServiceData> serviceDatas;
	private int stkMenuId;
	private String stkMenuName;
	private List<WalletData> walletDatas;
	
	public int getHostVersionId() {
		return hostVersionId;
	}
	public void setHostVersionId(int hostVersionId) {
		this.hostVersionId = hostVersionId;
	}
	public String getHostVersionName() {
		return hostVersionName;
	}
	public void setHostVersionName(String hostVersionName) {
		this.hostVersionName = hostVersionName;
	}
	public String getHostVersionNumber() {
		return hostVersionNumber;
	}
	public void setHostVersionNumber(String hostVersionNumber) {
		this.hostVersionNumber = hostVersionNumber;
	}
	public List<ServiceStkData> getServiceStkDatas() {
		return serviceStkDatas;
	}
	public void setServiceStkDatas(List<ServiceStkData> serviceStkDatas) {
		this.serviceStkDatas = serviceStkDatas;
	}
	public Map<String, ServiceData> getServiceDatas() {
		return serviceDatas;
	}
	public void setServiceDatas(Map<String, ServiceData> serviceDatas) {
		this.serviceDatas = serviceDatas;
	}
	public int getStkMenuId() {
		return stkMenuId;
	}
	public void setStkMenuId(int stkMenuId) {
		this.stkMenuId = stkMenuId;
	}
	public String getStkMenuName() {
		return stkMenuName;
	}
	public void setStkMenuName(String stkMenuName) {
		this.stkMenuName = stkMenuName;
	}
	public List<WalletData> getWalletDatas() {
		return walletDatas;
	}
	public void setWalletDatas(List<WalletData> walletDatas) {
		this.walletDatas = walletDatas;
	}
}
