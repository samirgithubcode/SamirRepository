/**
 * 
 */
package com.ng.pnb.bridge.service.impl;

import java.io.IOException;
import java.lang.reflect.Constructor;
import java.net.UnknownHostException;

import org.jpos.iso.ISOChannel;
import org.jpos.iso.ISOMsg;
import org.jpos.iso.ISOPackager;
import org.jpos.iso.channel.XMLChannel;
import org.jpos.iso.packager.XMLPackager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ng.pnb.bridge.service.ISocketService;
import com.ng.pnb.invoker.util.PnbConstants;
import com.ng.pnb.invoker.util.PropertyHolder;
import com.ng.sb.common.dataobject.PlatformLoginData;

/**
 * @author gopal
 *
 */
@Service(value="socketService")
public class SocketService implements ISocketService {

	private static final Logger LOGGER = LoggerFactory.getLogger(SocketService.class);
	
	@Autowired
	PlatformLoginData platformLoginData;
	
	@Autowired
	PropertyHolder propertyHolder;
	
	/*private String openConnectionAndWrite(String txnId,byte[] message) throws IOException,IOException
	{
		LOGGER.info(PnbConstants.TRANSACTIONID+" : "+ txnId + " In SocketService -  openConnectionAndWrite method. ");
		String responseLine=null;
		DataOutputStream os = null;
		DataInputStream is = null;
		try (Socket smtpSocket = new Socket("127.0.0.1", 8000)){
			//LOGGER.info(PnbConstants.TRANSACTIONID +" : "+ txnId + " In SocketService -  openConnectionAndWrite method. Going to call Socket with IP : " +  platformLoginData.getPnbSocketIP() + " and Port : " + platformLoginData.getPnbSocketPort());
			os = new DataOutputStream(smtpSocket.getOutputStream());
			is = new DataInputStream(smtpSocket.getInputStream());
			
			System.out.println("########################Content Length "+message.length);
					os.write(message);
					os.writeBytes("\n");
					os.flush();
					responseLine = is.readLine();
					//LOGGER.info(PnbConstants.TRANSACTIONID +" : "+txnId + " In SocketService -  openConnectionAndWrite method. response from Finacle System is ## "+ responseLine);
					os.close();
					is.close();
					smtpSocket.close();
				}
		 catch (UnknownHostException e) {
			LOGGER.error(PnbConstants.TRANSACTIONID +" : "+ txnId +PnbConstants.ERRORMSG + e);
		} catch (IOException e) {
			LOGGER.error(PnbConstants.TRANSACTIONID +" : "+txnId + PnbConstants.ERRORMSG + e);
		}
		
		
		return responseLine;
	}*/
	
	private ISOMsg openConnectionAndWrite(String txnId,ISOMsg request) throws IOException,IOException{
		LOGGER.info("TransactionId : "+ txnId + " In SocketService -  openConnectionAndWrite method. ");
		
		ISOMsg response = null; 
				
		
		//ISOMsg request = null;
		ISOPackager packager = null;
		ISOChannel channel = null;
		
		try 
		{
			packager = getPackager();
			//packager = new XMLPackager();
			//packager = new GenericPackager("/home/gopal/workspace/Tafani_Workspace/PnbInvoker/src/main/resources/iso8583.xml");
				
				// Create ISO Message
			
			channel = getChannel(packager);
			
			//channel = new XMLChannel(platformLoginData.getPnbSocketIP(), platformLoginData.getPnbSocketPort(), packager);
			//channel = new NACChannel(platformLoginData.getPnbSocketIP(), platformLoginData.getPnbSocketPort(), packager, null);
			request.dump(System.out, "Request :");
			
			channel.connect();
			System.out.println("Connected ");
			if(channel.isConnected())
			{
				channel.send(request);
				channel.send("\n".getBytes());
			}
			response = channel.receive();

			response.dump(System.out, "response:");
			
			channel.disconnect();
			
				//responseLine = new String(response.getBytes());
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		return response;
	}
	
	private ISOChannel getChannel(ISOPackager packager) 
	{
		ISOChannel channel = null;
		try
		{
			
			Class<?> packagerClass = Class.forName(propertyHolder.getIsoChannel());
			
			if(propertyHolder.getDeploymentFor().equalsIgnoreCase(PnbConstants.DEPLOYED_FOR))
			{
				Constructor constructor = packagerClass.getConstructor(new Class[] { String.class, int.class, ISOPackager.class });
				
				channel = (ISOChannel) constructor.newInstance(propertyHolder.getIsoServer(), propertyHolder.getIsoPort(), packager);
			}else{
				Constructor constructor = packagerClass.getConstructor(new Class[] { String.class, int.class, ISOPackager.class, byte[].class });
				
				channel = (ISOChannel) constructor.newInstance(propertyHolder.getIsoServer(), propertyHolder.getIsoPort(), packager, null);
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return channel;
	}

	private ISOPackager getPackager() 
	{
		ISOPackager packager = null;
		try{
			
			Class<?> packagerClass = Class.forName(propertyHolder.getIsoPackager());
			
			if(propertyHolder.isStructureRequired())
			{
				Constructor<?> packagerConstructor = packagerClass.getConstructor(String.class);
				
				if(packagerConstructor != null)
					packager =  (ISOPackager) packagerConstructor.newInstance(propertyHolder.getDefinitionFile());
			}else{
				packager =  (ISOPackager) packagerClass.newInstance();
			}
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return packager;
	}

	@Override
	public ISOMsg writeOnSocket(String txnId,ISOMsg request) throws UnknownHostException,IOException {
		LOGGER.info(PnbConstants.TRANSACTIONID +" : "+txnId + " In SocketService -  writeOnSocket method. ");
		return openConnectionAndWrite(txnId, request);
	}

	/*@Override
	public ISOMsg writeOnSocket(String txnId,String message) throws UnknownHostException,IOException {
		LOGGER.info(PnbConstants.TRANSACTIONID +" : "+txnId + " In SocketService -  writeOnSocket method. ");
		return openConnectionAndWrite(txnId, message.getBytes());
	}*/

	@Override
	public ISOMsg submitNGetResponse(ISOMsg request) throws IOException 
	{
		ISOMsg response = null;
			
			ISOPackager packager = null;
			ISOChannel channel = null;
			
			try {
				
				packager = new XMLPackager();

				channel = new XMLChannel("172.16.16.6", 8000 , packager);
				
				request.setPackager(packager);
				
				request.dump(System.out, "Request :");
				
				channel.connect();
				
				if(channel.isConnected())
				{
				channel.send(request);
				//channel.send("\n".getBytes());

				response = channel.receive();

				response.dump(System.out, "response:");
				
				channel.disconnect();
				}
				
				return response;
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return null;
	}
}