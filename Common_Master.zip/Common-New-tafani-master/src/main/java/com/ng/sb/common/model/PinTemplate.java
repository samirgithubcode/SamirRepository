/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "PinTemplate")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "PinTemplate.findAll", query = "SELECT p FROM PinTemplate p"),
    @NamedQuery(name = "PinTemplate.findById", query = "SELECT p FROM PinTemplate p WHERE p.id = :id"),
    @NamedQuery(name = "PinTemplate.findByName", query = "SELECT p FROM PinTemplate p WHERE p.name = :name"),
    @NamedQuery(name = "PinTemplate.findByDescription", query = "SELECT p FROM PinTemplate p WHERE p.description = :description"),
    @NamedQuery(name = "PinTemplate.findByCreateDate", query = "SELECT p FROM PinTemplate p WHERE p.createDate = :createDate"),
    @NamedQuery(name = "PinTemplate.findCountByName", query = "SELECT count(p) FROM PinTemplate p WHERE p.name = :name"),    
})
public class PinTemplate implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Column(name = "description")
    private String description;
    @Basic(optional = false)
    @Column(name = "name")
    private String name;
    @Basic(optional = false)
    @Column(name = "createDate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createDate;
    @OneToMany(cascade=CascadeType.ALL, mappedBy = "pinTempId")
    private Collection<PinManagement> pinManagementCollection;

    public PinTemplate() {
    	//empty
    }

    public PinTemplate(Integer id) {
        this.id = id;
    }

    public PinTemplate(Integer id, String name, Date createDate) {
        this.id = id;
        this.name = name;
        this.createDate = createDate;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    @XmlTransient
    public Collection<PinManagement> getPinManagementCollection() {
        return pinManagementCollection;
    }

    public void setPinManagementCollection(Collection<PinManagement> pinManagementCollection) {
        this.pinManagementCollection = pinManagementCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof PinTemplate)) {
            return false;
        }
        PinTemplate other = (PinTemplate) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.PinTemplate[ id=" + id + " ]";
    }
    
}
