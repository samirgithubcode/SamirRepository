package com.ng.sb.common.dataobject;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "IssuanceRequestData")
public class IssuanceRequestData extends PlatformRequestData{

	private static final long serialVersionUID = 1L;
	private String key;
	private CustomerInfo customerInfo;
	private IssuerInfo issuerInfo;
	private String externalNumber;
	private String customerType;// It will be having values as A OR C
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public CustomerInfo getCustomerInfo() {
		return customerInfo;
	}
	public void setCustomerInfo(CustomerInfo customerInfo) {
		this.customerInfo = customerInfo;
	}
	public IssuerInfo getIssuerInfo() {
		return issuerInfo;
	}
	public void setIssuerInfo(IssuerInfo issuerInfo) {
		this.issuerInfo = issuerInfo;
	}
	public String getExternalNumber() {
		return externalNumber;
	}
	public void setExternalNumber(String externalNumber) {
		this.externalNumber = externalNumber;
	}
	public String getCustomerType() {
		return customerType;
	}
	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}
	

}
