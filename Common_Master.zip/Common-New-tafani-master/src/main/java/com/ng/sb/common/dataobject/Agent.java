/**
 * 
 */
package com.ng.sb.common.dataobject;

import java.util.Date;

/**
 * @author gaurav
 *
 */
public class Agent extends BaseObjectData {

	private static final long serialVersionUID = 1L;
	private Integer id;
	private String mobileNumber;
	private String tPin;
	private Date fromDate;
	private Date toDate;
	
	public Date getFromDate() {
		return fromDate;
	}
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}
	public Date getToDate() {
		return toDate;
	}
	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String gettPin() {
		return tPin;
	}
	public void settPin(String tPin) {
		this.tPin = tPin;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	
}
