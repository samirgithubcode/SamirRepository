package com.ng.bridge.dataobject.eko;

public class AddRecipientRes {
	 private String responsetypeid;

	    private String message;

	    private String responsestatusid;

	    private String status;

	    private AddRecipientResData data;

	    

	    public String getMessage ()
	    {
	        return message;
	    }
	    public String getResponsetypeid ()
	    {
	        return responsetypeid;
	    }

	    public void setResponsetypeid (String responsetypeid)
	    {
	        this.responsetypeid = responsetypeid;
	    }
	    public void setMessage (String message)
	    {
	        this.message = message;
	    }

	    

	    public String getStatus ()
	    {
	        return status;
	    }

	    public void setStatus (String status)
	    {
	        this.status = status;
	    }
	    public String getResponsestatusid ()
	    {
	        return responsestatusid;
	    }

	    public void setResponsestatusid (String responsestatusid)
	    {
	        this.responsestatusid = responsestatusid;
	    }
		public AddRecipientResData getData() {
			return data;
		}

		public void setData(AddRecipientResData data) {
			this.data = data;
		}

	    
	    
	  

	
}
