package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author abhishek
 *
 */
@Entity
@Table(name="ShippingDetail")
@NamedQueries({
@NamedQuery(name="ShippingDetail.findAll", query="SELECT s FROM ShippingDetail s"),
@NamedQuery(name="ShippingDetail.findByShippingInfo", query="SELECT s FROM ShippingDetail s WHERE s.shippingInfo =:shippinginfo"),
})
public class ShippingDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false)
	private Integer id;
	@Column(name="boxDispatched")
	private Integer boxDispatched;
	@Column(name="createDate")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createDate;
	@Column(name="editDate")
	@Temporal(TemporalType.TIMESTAMP)
	private Date editDate;

	@Column(name="unitsDispatched")
	private Integer unitsDispatched;
	
	@Column(name="unitsOrdered")
	private Integer unitsOrderedId;

	//bi-directional many-to-one association to OrderDetail
	@ManyToOne
	@JoinColumn(name="orderDetailId")
	private OrderDetail orderDetail;

	//bi-directional many-to-one association to ShippingInfo
	@Basic(optional=true)
	@ManyToOne
	@JoinColumn(name="shippingInfoId")
	private ShippingInfo shippingInfo;

	public ShippingDetail() {
		//empty
	}

	public ShippingDetail(Integer id) {
		this.id = id;
	}
	public Date getEditDate() {
		return editDate;
	}

	public void setEditDate(Date editDate) {
		this.editDate = editDate;
	}
	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getBoxDispatched() {
		return this.boxDispatched;
	}

	public void setBoxDispatched(Integer boxDispatched) {
		this.boxDispatched = boxDispatched;
	}

	public Date getCreateDate() {
		return this.createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Integer getUnitsDispatched() {
		return this.unitsDispatched;
	}

	public void setUnitsDispatched(Integer unitsDispatched) {
		this.unitsDispatched = unitsDispatched;
	}

	public Integer getUnitsOrderedId() {
		return this.unitsOrderedId;
	}

	public void setUnitsOrderedId(Integer unitsOrderedId) {
		this.unitsOrderedId = unitsOrderedId;
	}

	public OrderDetail getOrderDetail() {
		return this.orderDetail;
	}

	public void setOrderDetail(OrderDetail orderDetail) {
		this.orderDetail = orderDetail;
	}

	public ShippingInfo getShippingInfo() {
		return this.shippingInfo;
	}

	public void setShippingInfo(ShippingInfo shippingInfo) {
		this.shippingInfo = shippingInfo;
	}

	@Override
	public String toString() {
		return "ShippingDetail [id=" + id + "]";
	}

}