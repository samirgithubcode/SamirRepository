package com.ng.transaction.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.ng.sb.common.dataobject.TransactionData;
import com.ng.transaction.service.ITransactionService;

@Component
@Scope("prototype")
public class MOProcessingThread extends Thread {

	@Autowired
	ITransactionService transactionService;
	
	private TransactionData transactionData;
	
	public MOProcessingThread()
	{
	
	}
	
	@Override
	public void run() 
	{
		try{
			
			transactionService.requestFacade(transactionData);
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public TransactionData getTransactionData() {
		return transactionData;
	}

	public void setTransactionData(TransactionData transactionData) {
		this.transactionData = transactionData;
	}
}
