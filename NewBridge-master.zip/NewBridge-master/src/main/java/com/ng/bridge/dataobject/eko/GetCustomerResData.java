package com.ng.bridge.dataobject.eko;

import java.util.List;

public class GetCustomerResData {
	
		private List<GetCustomerResLimit> limit;

		private String balance;

	    private String name;

	    private String state;

	    private String customerTypeId;

	    private String customerId;

	    private String mobile;

	    private String currency;

	    private String stateDesc;

		
		public List<GetCustomerResLimit> getLimit() {
			return limit;
		}

		public void setLimit(List<GetCustomerResLimit> limit) {
			this.limit = limit;
		}

		public String getBalance() {
			return balance;
		}

		public void setBalance(String balance) {
			this.balance = balance;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getState() {
			return state;
		}

		public void setState(String state) {
			this.state = state;
		}

		public String getCustomerIdType() {
			return customerTypeId;
		}

		public void setCustomerIdType(String customerTypeId) {
			this.customerTypeId = customerTypeId;
		}

		public String getCustomerId() {
			return customerId;
		}

		public void setCustomerId(String customerId) {
			this.customerId = customerId;
		}

		public String getMobile() {
			return mobile;
		}

		public void setMobile(String mobile) {
			this.mobile = mobile;
		}

		public String getCurrency() {
			return currency;
		}

		public void setCurrency(String currency) {
			this.currency = currency;
		}

		public String getStateDesc() {
			return stateDesc;
		}

		public void setStateDesc(String stateDesc) {
			this.stateDesc = stateDesc;
		}
	    

}
