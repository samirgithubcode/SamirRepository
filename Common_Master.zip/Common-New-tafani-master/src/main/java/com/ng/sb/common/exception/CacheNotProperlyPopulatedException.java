package com.ng.sb.common.exception;

public class CacheNotProperlyPopulatedException extends Exception {
	private static final long serialVersionUID = 1L;
	
	public CacheNotProperlyPopulatedException(String message){
		super(message);
	}
}