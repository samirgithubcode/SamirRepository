/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "ThirdPartySubsRecipient")
@XmlRootElement
@NamedQueries({
		@NamedQuery(name = "ThirdPartySubsRecipient.findAll", query = "SELECT t FROM ThirdPartySubsRecipient t"),
		@NamedQuery(name = "ThirdPartySubsRecipient.findById", query = "SELECT t FROM ThirdPartySubsRecipient t WHERE t.id = :id"),
		@NamedQuery(name = "ThirdPartySubsRecipient.findByBankAccount", query = "SELECT t FROM ThirdPartySubsRecipient t WHERE t.bankAccount = :bankAccount"),
		@NamedQuery(name = "ThirdPartySubsRecipient.findByIfscCode", query = "SELECT t FROM ThirdPartySubsRecipient t WHERE t.ifscCode = :ifscCode"),
		@NamedQuery(name = "ThirdPartySubsRecipient.findByBankName", query = "SELECT t FROM ThirdPartySubsRecipient t WHERE t.bankName = :bankName"),
		@NamedQuery(name = "ThirdPartySubsRecipient.findByBankCode", query = "SELECT t FROM ThirdPartySubsRecipient t WHERE t.bankCode = :bankCode"),
		@NamedQuery(name = "ThirdPartySubsRecipient.findByRecipientName", query = "SELECT t FROM ThirdPartySubsRecipient t WHERE t.recipientName = :recipientName"),

		@NamedQuery(name = "ThirdPartySubsRecipient.findByTpsIdBankAndIFSC", query = "SELECT t FROM ThirdPartySubsRecipient t WHERE t.tpsId = :tpsId and t.bankAccount = :bankAccount and t.ifscCode = :ifscCode"),

		@NamedQuery(name = "ThirdPartySubsRecipient.findByRecipientId", query = "SELECT t FROM ThirdPartySubsRecipient t WHERE t.recipientId = :recipientId"),
		@NamedQuery(name = "ThirdPartySubsRecipient.findByChannel", query = "SELECT t FROM ThirdPartySubsRecipient t WHERE t.channel = :channel") })
public class ThirdPartySubsRecipient implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "id")
	private Integer id;
	@Basic(optional = false)
	@Column(name = "bankAccount")
	private String bankAccount;
	@Basic(optional = false)
	@Column(name = "ifscCode")
	private String ifscCode;
	@Basic(optional = false)
	@Column(name = "bankName")
	private String bankName;
	@Basic(optional = false)
	@Column(name = "bankCode")
	private String bankCode;
	@Basic(optional = false)
	@Column(name = "recipientName")
	private String recipientName;
	@Basic(optional = false)
	@Column(name = "recipientId")
	private String recipientId;
	@Basic(optional = false)
	@Column(name = "channel")
	private String channel;
	@JoinColumn(name = "tpsId", referencedColumnName = "id")
	@ManyToOne(optional = false)
	private ThirdPartySubscriber tpsId;

	public ThirdPartySubsRecipient() {
		// empty
	}

	public ThirdPartySubsRecipient(Integer id) {
		this.id = id;
	}

	public ThirdPartySubsRecipient(Integer id, String bankAccount, String ifscCode, String bankName, String bankCode,
			String recipientName, String recipientId) {
		this.id = id;
		this.bankAccount = bankAccount;
		this.ifscCode = ifscCode;
		this.bankName = bankName;
		this.bankCode = bankCode;
		this.recipientName = recipientName;
		this.recipientId = recipientId;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getBankAccount() {
		return bankAccount;
	}

	public void setBankAccount(String bankAccount) {
		this.bankAccount = bankAccount;
	}

	public String getIfscCode() {
		return ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBankCode() {
		return bankCode;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	public String getRecipientName() {
		return recipientName;
	}

	public void setRecipientName(String recipientName) {
		this.recipientName = recipientName;
	}

	public String getRecipientId() {
		return recipientId;
	}

	public void setRecipientId(String recipientId) {
		this.recipientId = recipientId;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public ThirdPartySubscriber getTpsId() {
		return tpsId;
	}

	public void setTpsId(ThirdPartySubscriber tpsId) {
		this.tpsId = tpsId;
	}

	@Override
	public int hashCode() {
		int hash = 0;
		hash += (id != null ? id.hashCode() : 0);
		return hash;
	}

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof ThirdPartySubsRecipient)) {
			return false;
		}
		ThirdPartySubsRecipient other = (ThirdPartySubsRecipient) object;
		   boolean check=true;
	        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
	        	check= false;
	        }
	        return check;
	}

	@Override
	public String toString() {
		return "com.ng.sb.common.model.ThirdPartySubsRecipient[ id=" + id + " ]";
	}

}
