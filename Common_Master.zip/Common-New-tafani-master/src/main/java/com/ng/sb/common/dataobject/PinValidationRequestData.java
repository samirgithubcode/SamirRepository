package com.ng.sb.common.dataobject;

import java.util.Set;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="PinValidationRequestData")
public class PinValidationRequestData extends PlatformRequestData {

	private static final long serialVersionUID = 1L;
	private String key;
	private Set<String> pinSet;
	
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	
	public Set<String> getPinSet() {
		return pinSet;
	}
	public void setPinSet(Set<String> pinSet) {
		this.pinSet = pinSet;
	}
	
}
