package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the CategoryProviderMapping database table.
 * 
 */
/**
 * @author abhishek
 *
 */
@Entity
@Table(name="CategoryProviderMapping")
@NamedQueries({
@NamedQuery(name="CategoryProviderMapping.findAll", query="SELECT c FROM CategoryProviderMapping c"),
@NamedQuery(name="CategoryProviderMapping.findAllByCategoryId", query="SELECT c FROM CategoryProviderMapping c WHERE c.categoryId IN :catId ORDER BY c.categoryId desc"),
@NamedQuery(name="CategoryProviderMapping.findAllOrderByCategoryId", query="SELECT c FROM CategoryProviderMapping c ORDER BY categoryId desc"),
@NamedQuery(name="CategoryProviderMapping.findById", query="SELECT c FROM CategoryProviderMapping c where c.id=:id"),
@NamedQuery(name="CategoryProviderMapping.findByCategoryId", query="SELECT c FROM CategoryProviderMapping c where c.categoryId =:categoryId"),
@NamedQuery(name="CategoryProviderMapping.findByProviderId", query="SELECT c FROM CategoryProviderMapping c where c.providerId =:providerId"),
@NamedQuery(name="CategoryProviderMapping.findByCategoryIdandProviderId", query="SELECT c FROM CategoryProviderMapping c where c.providerId =:providerId AND c.categoryId =:categoryId"),
@NamedQuery(name = "CategoryProviderMapping.findDistinctProviderByINserviceCategoryId", query = "SELECT distinct s.providerId, s.categoryId FROM CategoryProviderMapping s WHERE s.categoryId IN :serviceCategoryIds")
//SysServiceCatProviderMapping.findDistinctProviderByINserviceCategoryId
})
public class CategoryProviderMapping implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false)
	private Integer id;

	//bi-directional many-to-one association to Category
	@ManyToOne
	@JoinColumn(name="catId", nullable=false)
	private Categories categoryId;

	//bi-directional many-to-one association to Provider
	@ManyToOne
	@JoinColumn(name="providerId", nullable=false)
	private Provider providerId;

	public CategoryProviderMapping() {
		//default constructor
	}
	
	public CategoryProviderMapping(Integer id)
	{
		this.id=id;
	}
	
	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Categories getCategory() {
		return this.categoryId;
	}

	public void setCategory(Categories categoryId) {
		this.categoryId = categoryId;
	}

	public Provider getProvider() {
		return this.providerId;
	}

	public void setProvider(Provider providerId) {
		this.providerId = providerId;
	}

}