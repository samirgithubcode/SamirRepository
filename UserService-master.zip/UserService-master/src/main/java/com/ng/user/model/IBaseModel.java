/**
 * 
 */
package com.ng.user.model;

import java.io.Serializable;
import java.util.Date;

/**
 * @author gopal
 *
 */
public interface IBaseModel extends Serializable{

	public Object getPrimaryKey();

	public String getValue();

	public void setCreatedOn(final Date createdDate);

	public void setLastUpdatedOn(final Date updatedOn);

	public void setCreatedBy(final String createdBy);

	public void setLastUpdatedBy(final String lastUpdatedBy);
}
