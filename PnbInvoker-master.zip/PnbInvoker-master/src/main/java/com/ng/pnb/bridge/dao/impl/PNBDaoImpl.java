/**
 * 
 */
package com.ng.pnb.bridge.dao.impl;

import java.io.Serializable;

import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.ng.sb.common.dao.impl.SuperParentDAO;
import com.ng.sb.common.model.CustomerDetails;
import com.ng.sb.common.model.CustomerPreferredBiller;
import com.ng.sb.common.model.CustomerWallets;
import com.ng.sb.common.model.IfscCodes;
import com.ng.sb.common.model.InternalAccountMaster;
import com.ng.sb.common.model.OverlayMerchants;
import com.ng.sb.common.model.PayeeDetails;
import com.ng.sb.common.model.Subscriber;
import com.ng.sb.common.model.WalletCredentials;

/**
 * @author gopal
 *
 */
@Repository("pnbDao")
@Transactional
public class PNBDaoImpl extends SuperParentDAO implements IPNBDao {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public <T extends Serializable> T findById(Integer id, Class<T> modelClass) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public InternalAccountMaster getInternalAccountMaster() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean saveEntity(Object entityObject) 
	{
		try{
			entityManager.persist(entityObject);
			return true;
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean updateEntity(Object entityObject) 
	{	
		try{
			entityManager.merge(entityObject);
			return true;
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public IfscCodes findBankDetailsByIFSC(String ifscCode) 
	{
		IfscCodes ifscCodeDetails = null;
		
		try{
			if(ifscCode != null && !ifscCode.isEmpty())
			{
				TypedQuery<IfscCodes> query = entityManager.createNamedQuery("IfscCodes.findByIfscCode",IfscCodes.class);
				
				query.setParameter("ifscCode", ifscCode);
				
				ifscCodeDetails = query.getSingleResult();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return ifscCodeDetails;
	}

	@Override
	public CustomerDetails getCustomerDetailsByAccount(String accountNumber,String ifscCode) 
	{
		CustomerDetails customerDetails = null;
		
		try{
			if(ifscCode != null && !ifscCode.isEmpty())
			{
				TypedQuery<CustomerDetails> query = entityManager.createNamedQuery("CustomerDetails.findByAccountNumber",CustomerDetails.class);
				
				query.setParameter("accountNumber", accountNumber);
				query.setParameter("ifscCode", ifscCode);
				
				customerDetails = query.getSingleResult();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return customerDetails;
	}

	@Override
	public InternalAccountMaster getAccountMaster(String accountType) 
	{
		InternalAccountMaster accountMaster = null;
		
		try{
			if(accountType != null && !accountType.isEmpty())
			{
				TypedQuery<InternalAccountMaster> query = entityManager.createNamedQuery("InternalAccountMaster.findByAccountType", InternalAccountMaster.class);
				
				query.setParameter("accountType", accountType);
				
				accountMaster = query.getSingleResult();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return accountMaster;
	}

	@Override
	public Subscriber getSubscriberDetails(String msisdn) 
	{
		Subscriber subscriber = null;
		
		try{
			
				TypedQuery<Subscriber> query = entityManager.createNamedQuery("Subscriber.findByMsisdn",Subscriber.class);
				
				query.setParameter("msisdn", msisdn);
								
				subscriber = query.getSingleResult();
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return subscriber;
	}

	@Override
	public WalletCredentials getSubscriberWalletCredential(String msisdn, Integer walletId) 
	{
		WalletCredentials walletCredential = null;
		
		try{
				TypedQuery<WalletCredentials> query = entityManager.createNamedQuery("WalletCredentials.findByMsisdnnWalletCode",WalletCredentials.class);
				
				query.setParameter("userMsisdn", Long.parseLong(msisdn));
				query.setParameter("walletId", walletId);
								
				walletCredential = query.getSingleResult();
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return walletCredential;
	}

	@Override
	public PayeeDetails getPayeeByAccountId(String accountId) {
		PayeeDetails payeeDetails = null;
		
		try{
			if(accountId != null && !accountId.isEmpty())
			{
				TypedQuery<PayeeDetails> query = entityManager.createNamedQuery("PayeeDetails.findByAccountId", PayeeDetails.class);
				
				query.setParameter("accountId", accountId);
				
				payeeDetails = query.getSingleResult();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return payeeDetails;
	}

	@Override
	public OverlayMerchants getMerchantByAccountId(String accountId) 
	{
		OverlayMerchants payeeDetails = null;
		
		try{
			if(accountId != null && !accountId.isEmpty())
			{
				TypedQuery<OverlayMerchants> query = entityManager.createNamedQuery("OverlayMerchants.findByAccountId", OverlayMerchants.class);
				
				query.setParameter("accountId", accountId);
				
				payeeDetails = query.getSingleResult();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return payeeDetails;
	}

	@Override
	public CustomerPreferredBiller getCustomerBillerByAccountId(String accountId, String customerId) 
	{
		CustomerPreferredBiller payeeDetails = null;
		
		try{
			if(accountId != null && !accountId.isEmpty())
			{
				TypedQuery<CustomerPreferredBiller> query = entityManager.createNamedQuery("CustomerPreferredBiller.findByAccountIdAndCustomerId", CustomerPreferredBiller.class);
				
				query.setParameter("accountId", accountId);
				query.setParameter("customerId", customerId);
				
				payeeDetails = query.getSingleResult();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return payeeDetails;
	}
	
	@Override
	public boolean deleteEntity(Object entityObject) 
	{
		try{
			if(entityObject == null)
				return false;
			
			entityManager.remove(entityObject);
		   return true;
		}catch(Exception e)
		{
			
		}
		return false;
	}

	@Override
	public CustomerWallets getSubscriberWallet(String msisdn, Integer walletId) 
	{
		CustomerWallets walletDetails = null;
		
		try{
				TypedQuery<CustomerWallets> query = entityManager.createNamedQuery("CustomerWallets.findByMsisdnnWalletId",CustomerWallets.class);
				
				query.setParameter("customerMsisdn", msisdn);
				query.setParameter("walletId", walletId);
								
				walletDetails = query.getSingleResult();
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return walletDetails;
	}

	@Override
	public Subscriber getSubscriberByCustId(String customerId) 
	{
		Subscriber subscriberDetails = null;
		
		try{
			if(customerId != null && !customerId.isEmpty())
			{
				TypedQuery<Subscriber> query = entityManager.createNamedQuery("Subscriber.findByCustIds",Subscriber.class);
				
				query.setParameter("customerId", customerId);
				
				subscriberDetails = query.getSingleResult();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return subscriberDetails;
	}

}

