package com.ng.sc.dao;

import java.util.List;

import com.ng.sb.common.dao.IDAO;
import com.ng.sb.common.model.Country;
import com.ng.sb.common.model.State;

/**
 * 
 * @author Satyendra
 *
 */
public interface ISelfCareDAO extends IDAO {
	public boolean saveObject(Object obj) throws Exception;
	public boolean deleteObject(Object obj) throws Exception;
	public List<Country> getCountries() throws Exception;
	public List<State> getState(Integer countryId) throws Exception;
}
