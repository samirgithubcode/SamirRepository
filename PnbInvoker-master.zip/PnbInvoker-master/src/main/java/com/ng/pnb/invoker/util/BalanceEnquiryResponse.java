package com.ng.pnb.invoker.util;


public class BalanceEnquiryResponse {

	Header header;
	
	Data data;

	public Header getHeader() {
		return header;
	}

	public void setHeader(Header header) {
		this.header = header;
	}

	public Data getData() {
		return data;
	}

	public void setData(Data data) {
		this.data = data;
	}
	
}



