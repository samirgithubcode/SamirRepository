package com.ng.sb.common.dataobject;


/**
 * @author gaurav
 *
 */
public class ServiceParamsMappingData extends BaseObjectData implements Comparable<ServiceParamsMappingData> {
	private static final long serialVersionUID = 1L;
	private Integer serviceId;
	private String objectMapping;
	private String desc;
	private Integer sequence;
	private Boolean isnumericField;
	private String serviceDef;

	public Boolean getIsnumericField() {
		return isnumericField;
	}

	public void setIsnumericField(Boolean isnumericField) {
		this.isnumericField = isnumericField;
	}

	public Integer getServiceId() {
		return serviceId;
	}

	public void setServiceId(Integer serviceId) {
		this.serviceId = serviceId;
	}

	public String getObjectMapping() {
		return objectMapping;
	}

	public void setObjectMapping(String objectMapping) {
		this.objectMapping = objectMapping;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public Integer getSequence() {
		return sequence;
	}

	public void setSequence(Integer sequence) {
		this.sequence = sequence;
	}

	public String getServiceDef() {
		return serviceDef;
	}

	public void setServiceDef(String serviceDef) {
		this.serviceDef = serviceDef;
	}

	@Override
	public boolean equals(Object obj) {
		if(obj==null){
			return false;
		}
		boolean check=false;
		if(obj instanceof ServiceParamsMappingData){
			ServiceParamsMappingData other = (ServiceParamsMappingData)obj;
			if(this.getObjectMapping().equalsIgnoreCase(other.getObjectMapping()) && this.getSequence()==other.getSequence()){
				check= true;
			}
			return check;
		}
		return super.equals(obj);
	}
	
	@Override
	public int hashCode() {
		if(this.getObjectMapping()!=null && this.getDesc()!=null){
			return this.getObjectMapping().hashCode()*7*this.getDesc().hashCode();	
		}else{
			return 0;
		}
		
	}

	@Override
	public int compareTo(ServiceParamsMappingData other) {
		if( other!=null){
			if(this.getSequence()==other.getSequence()){
				return 0;		
			}
			return this.getSequence()>other.getSequence()?1:-1;
		}
		return 0;	
	}


}
