package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="merchant_users")
@NamedQueries
({
	@NamedQuery(name="MerchantUsers.findByRole", query="SELECT m FROM MerchantUsers m where m.role= :role"),
	@NamedQuery(name="MerchantUsers.findById", query="SELECT m FROM MerchantUsers m where m.id= :id"),
	@NamedQuery(name="MerchantUsers.findByhId", query ="SELECT m FROM MerchantUsers m where m.merchantId.hId = :id AND m.role= :role"),
	@NamedQuery(name="MerchantUsers.findBydId", query ="SELECT m FROM MerchantUsers m where m.merchantId.dId = :id AND m.role= :role"),
	@NamedQuery(name="MerchantUsers.findBysdId", query ="SELECT m FROM MerchantUsers m where m.merchantId.sdId = :id AND m.role= :role"),
	@NamedQuery(name="MerchantUsers.findByaId", query ="SELECT m FROM MerchantUsers m where m.merchantId.aId = :id AND m.role= :role"),
	@NamedQuery(name="MerchantUsers.findByMobileNumber", query="SELECT u FROM MerchantUsers u where u.mobileNumber=:mobileNumber"),
	@NamedQuery(name="MerchantUsers.findByMerchantId", query="SELECT m FROM MerchantUsers m where m.merchantId= :merchantId and m.role= :role"),
	@NamedQuery(name="MerchantUsers.findByMerchantType", query="SELECT m FROM MerchantUsers m where m.merchantId.parentMerchantId= :merchantId and m.role= :role"),

})
public class MerchantUsers implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "id", unique=true, nullable=false)
	private Integer id;

	@Column(name = "name")
	private String name;
  
	@Column(name = "dateOfBirth")
	private Date dateOfBirth;
	
	@ManyToOne
	@JoinColumn(name="merchantId")
	private MerchantInfo merchantId;

	@Column(name = "mobileNumber")
	private String mobileNumber;

	@Column(name = "password")
	private String password;

	@Column(name = "status")
	private boolean status;

	@Column(name = "role")
	private String role;
	
	@Column(name = "invalidLoginCount")
	private Integer invalidLoginCount;
	
	@Column(name = "addedOn")
	private Date addedOn;
	
	@Column(name = "updatedOn")
	private Date modifiedDate;
	


	public MerchantUsers() {
		//empty
	}

	public MerchantUsers(Integer id)
	{
		this.id = id;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public MerchantInfo getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(MerchantInfo merchantId) {
		this.merchantId = merchantId;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public Integer getInvalidLoginCount() {
		return invalidLoginCount;
	}

	public void setInvalidLoginCount(Integer invalidLoginCount) {
		this.invalidLoginCount = invalidLoginCount;
	}

	public Date getAddedOn() {
		return addedOn;
	}

	public void setAddedOn(Date addedOn) {
		this.addedOn = addedOn;
	}



	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	
	
}
