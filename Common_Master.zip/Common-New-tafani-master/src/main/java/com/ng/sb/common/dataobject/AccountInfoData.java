package com.ng.sb.common.dataobject;

public class AccountInfoData extends BaseObjectData
{
	private static final long serialVersionUID = 1L;
	private String companyName;
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
}
