package com.ng.sb.common.dataobject;

import java.util.List;
import java.util.Map;

public class CommissionAssignmentData extends BaseObjectData {
	
	private static final long serialVersionUID = 1L;
	
	private Map<Integer,String> partnerMap;
	private Integer partnerId;
	private String serviceName;
	
	private Map<Integer,String> dataMap;
	private Map<Integer,String> templateMap;
	private List<String> dataList;
	
	
	
	
	
	
	
	public List<String> getDataList() {
		return dataList;
	}
	public void setDataList(List<String> dataList) {
		this.dataList = dataList;
	}
	public Map<Integer, String> getDataMap() {
		return dataMap;
	}
	public void setDataMap(Map<Integer, String> dataMap) {
		this.dataMap = dataMap;
	}
	public Map<Integer, String> getTemplateMap() {
		return templateMap;
	}
	public void setTemplateMap(Map<Integer, String> templateMap) {
		this.templateMap = templateMap;
	}
	public Map<Integer, String> getPartnerMap() {
		return partnerMap;
	}
	public void setPartnerMap(Map<Integer, String> partnerMap) {
		this.partnerMap = partnerMap;
	}
	public Integer getPartnerId() {
		return partnerId;
	}
	public void setPartnerId(Integer partnerId) {
		this.partnerId = partnerId;
	}
	public String getServiceName() {
		return serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	
	
}
