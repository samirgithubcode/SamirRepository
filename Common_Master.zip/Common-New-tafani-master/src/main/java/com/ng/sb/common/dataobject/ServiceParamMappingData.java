package com.ng.sb.common.dataobject;

import java.io.Serializable;

public class ServiceParamMappingData implements Serializable {
	
	private int serviceParamId;
	private String serviceParamName;
	private int paramSequence;
	private String className;
	private String methodName;
	private int length;
	private boolean isNumeric;
	private boolean paramOption;
	
	
	public boolean isParamOption() {
		return paramOption;
	}
	public void setParamOption(boolean paramOption) {
		this.paramOption = paramOption;
	}
	public boolean isNumeric() {
		return isNumeric;
	}
	public void setNumeric(boolean isNumeric) {
		this.isNumeric = isNumeric;
	}
	public int getServiceParamId() {
		return serviceParamId;
	}
	public void setServiceParamId(int serviceParamId) {
		this.serviceParamId = serviceParamId;
	}
	public String getServiceParamName() {
		return serviceParamName;
	}
	public void setServiceParamName(String serviceParamName) {
		this.serviceParamName = serviceParamName;
	}
	public int getParamSequence() {
		return paramSequence;
	}
	public void setParamSequence(int paramSequence) {
		this.paramSequence = paramSequence;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public String getMethodName() {
		return methodName;
	}
	public void setMethodName(String methodName) {
		this.methodName = methodName;
	}
	public int getLength() {
		return length;
	}
	public void setLength(int length) {
		this.length = length;
	}
}
