/**
 * 
 */
package com.ng.transaction.dao.impl;

import org.springframework.stereotype.Repository;

import com.ng.sb.common.util.SystemConstant;
import com.ng.transaction.dao.IOtherBankingDAO;

/**
 * @author gaurav
 *
 */
@Repository(value=SystemConstant.OTHER_BANKING_DAO)
public class OtherBankingDAO extends PaymentInstrumentDAO implements IOtherBankingDAO {
	private static final long serialVersionUID = 1L;

}
