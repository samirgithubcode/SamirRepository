package com.ng.transaction.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ng.sb.common.dataobject.AccountInfoData;
import com.ng.sb.common.dataobject.CategoryData;
import com.ng.sb.common.dataobject.FSPServicesData;
import com.ng.sb.common.dataobject.HostSubVersionData;
import com.ng.sb.common.dataobject.HostSubVersionData.ProviderRelation;
import com.ng.sb.common.dataobject.InstrumentData;
import com.ng.sb.common.dataobject.MasterVersionData;
import com.ng.sb.common.dataobject.PartnerData;
import com.ng.sb.common.dataobject.PartnerPreferenceData;
import com.ng.sb.common.dataobject.ProvidersData;
import com.ng.sb.common.dataobject.ServiceConfigData;
import com.ng.sb.common.dataobject.ServiceParamsMappingData;
import com.ng.sb.common.model.AccountInfo;
import com.ng.sb.common.model.Categories;
import com.ng.sb.common.model.FSPServices;
import com.ng.sb.common.model.FinancialInstrument;
import com.ng.sb.common.model.HostSVFinInstrumentPartnerMapping;
import com.ng.sb.common.model.HostSVFspServicesPartnerMapping;
import com.ng.sb.common.model.HostSVProviderPartnerMapping;
import com.ng.sb.common.model.HostSubVersion;
import com.ng.sb.common.model.MasterVersion;
import com.ng.sb.common.model.Partner;
import com.ng.sb.common.model.PartnerPreference;
import com.ng.sb.common.model.PartnerProviderMapping;
import com.ng.sb.common.model.Provider;
import com.ng.sb.common.model.ServiceConfig;
import com.ng.sb.common.model.ServiceParamMapping;
import com.ng.sb.common.util.SystemConstant;
import com.ng.transaction.dao.ICacheFillDAO;
import com.ng.transaction.service.ICacheFill;

@Transactional
@Service(value=SystemConstant.CACHE_FILL_SERVICE)
public class CacheFillService implements ICacheFill  {
	private static final Logger LOGGER = LoggerFactory.getLogger(CacheFillService.class);
	
	@Autowired
	ICacheFillDAO cacheFillDAO;
	private Map<Integer,MasterVersionData> masterVersionMap;
	private Map<ServiceConfigData,ServiceConfigData> serviceConfigMap;
	
	private void fillMasterVersionMap(){
		if(this.masterVersionMap==null){
			this.masterVersionMap=new HashMap<>();	
		}
		
		try {
			List<MasterVersion> list=cacheFillDAO.getMasterVersion();
			for(MasterVersion mv:list){
				MasterVersionData data=new MasterVersionData();
				data.setMvId(mv.getId());
				data.setmVersionCode(mv.getCode());
				data.setmVersionDecsription(mv.getDescription());
				data.setmVersionName(mv.getName());
				masterVersionMap.put(mv.getId(),data);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private void fillServiceConfigMap(){
		if(this.serviceConfigMap==null){
			this.serviceConfigMap = new HashMap<>();
		}
		try {
			List<ServiceConfig> list=cacheFillDAO.getServiceConfigList();
			for(ServiceConfig config:list){
				/*if(config.getStkCode().equalsIgnoreCase("f")){
					System.err.println("hehehehehehehehehhehehehe");
				}*/
				ServiceConfigData data=new ServiceConfigData();
				data.setId(config.getId());
				data.setMvCode(config.getMvId().getCode());
				data.setName(config.getServiceName());
				data.setMvId(config.getMvId().getId());
			
				//========= service param mapping ==================
				List<ServiceParamsMappingData> serviceParamList=new ArrayList<>();
				List<ServiceParamMapping> paramList=(List<ServiceParamMapping>)config.getServiceParamMappingCollection();
				for(ServiceParamMapping mapping:paramList){
					ServiceParamsMappingData paramData=new ServiceParamsMappingData();
					paramData.setId(mapping.getId());
					paramData.setDesc(mapping.getDescription());
					paramData.setIsnumericField(mapping.getIsNumeric());
					paramData.setObjectMapping(mapping.getObjectMapping());
					paramData.setSequence(mapping.getSequence());
					paramData.setServiceId(mapping.getServiceId().getId());
					serviceParamList.add(paramData);
				}
				data.setParamMappings(serviceParamList);
				//=========== end service param mapping =================
				
				data.setRequiredInputParam(config.getRequieredInputParams());
				data.setServiceCode(config.getStkCode());
				data.setServiceDefinition(config.getServiceDefination());
				data.setServiceDesc(config.getServiceDescription());
				data.setServiceName(config.getServiceName());
				Integer sts = 0;
				if(config.getStatus()!=null){
					sts=config.getStatus()==false?0:1;
				}
				Integer valReq = 0;
				if(config.getValidationReq()!=null){
					valReq=config.getValidationReq()==false?0:1;
				}
				data.setStatus(sts);
				data.setValidationReq(valReq);
				this.serviceConfigMap.put(data, data);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public Map<HostSubVersionData,HostSubVersionData>  getHostSubVersionMap() throws Exception{
		Map<HostSubVersionData,HostSubVersionData> hostSubVersionMap=new HashMap<HostSubVersionData, HostSubVersionData>();
		try {
			
			// Filling MasterVersion Map
			fillMasterVersionMap();
			
			// Filling ServiceCionfig Map
			fillServiceConfigMap();
			
			// Filling HostSubVersion Map
			
			List<HostSubVersion> hostSubVersionList=cacheFillDAO.getHostSubVersionList();
			
			//TODO Commenting for Testing purpose as HostSubVersion is not created properly in Database. So doing Hardcode.
			// Testing Starts
		/*	HostSubVersionData keyData=new HostSubVersionData();
			keyData.setServiceConfigMap(this.serviceConfigMap);
			keyData.setId(1);
			hostSubVersionMap.put(keyData, keyData);*/
			// Testing Ends
			
			for(HostSubVersion version:hostSubVersionList){
				
				if(version.getId() == 92)
					System.out.println("THIS _IS");
				
				HostSubVersionData keyData=new HostSubVersionData();
				keyData.setCategoryMap(getCategoriesMap());
				
				List<HostSVFspServicesPartnerMapping> fspList=(List<HostSVFspServicesPartnerMapping>)version.getHostSVFspServicesPartnerMappingCollection();
				keyData.setFspServiceMap(getFspServiceMap(fspList));
				
				AccountInfoData accountInfoData=new AccountInfoData();
				AccountInfo info=version.getHostId();
				accountInfoData.setCode(info.getAccountCode());
				accountInfoData.setCompanyName(info.getCompanyName());
				accountInfoData.setId(info.getId());
				keyData.setHost(accountInfoData);
			
				keyData.setId(version.getId());
				
				List<HostSVFinInstrumentPartnerMapping> instrumentList=(List<HostSVFinInstrumentPartnerMapping>)version.getHostSVFinInstrumentPartnerMappingCollection();
				keyData.setInstrumentMap(getInstrumentMap(instrumentList));
				
				keyData.setMasterVersionData(this.masterVersionMap.get(version.getMvId()));
				keyData.setName(version.getName());
				
				
				
				List<PartnerPreference> partnerPreferenceList=(List<PartnerPreference>)version.getPartnerPreferenceCollection();
				Set<PartnerPreferenceData> preferenceSet=new TreeSet<>();
				for(PartnerPreference partnerPreference:partnerPreferenceList){
					PartnerPreferenceData partnerPreferenceData=new PartnerPreferenceData();
					partnerPreferenceData.setId(partnerPreference.getId());
					partnerPreferenceData.setType(partnerPreference.getType());
					partnerPreferenceData.setSequence(partnerPreference.getSequence());
					boolean added = preferenceSet.add(partnerPreferenceData);
				}
				keyData.setPartnerPreferences(preferenceSet);
				
				List<HostSVProviderPartnerMapping> list=(List<HostSVProviderPartnerMapping>)version.getHostSVProviderPartnerMappingCollection();
				keyData.setProviderMap(getProviderMap(list));
			
				keyData.setServiceConfigMap(this.serviceConfigMap);
				
				hostSubVersionMap.put(keyData, keyData);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return hostSubVersionMap;
	}
	
	public Map<ProviderRelation,Map<ProvidersData,ProvidersData>> getProviderMap(List<HostSVProviderPartnerMapping> list){
			Map<ProviderRelation,Map<ProvidersData,ProvidersData>> providerMap=new  HashMap<>();
			providerMap.put(ProviderRelation.DIRECT_PROVIDER, getProviderDataMap(SystemConstant.DIRECT_PROVIDER,list));
			providerMap.put(ProviderRelation.FSP_PROVIDER, getProviderDataMap(SystemConstant.FSP_PROVIDER,list));
			providerMap.put(ProviderRelation.REGISTERED_INSTRUMENT_FSP_PROVIDER, getProviderDataMap(SystemConstant.REGISTERED_INSTRUMENT_FSP_PROVIDER,list));
		
		return providerMap;
	}
	
	private void addTPCodeInPartner(PartnerData partnerData,ProvidersData providerData,Partner partner,Provider provider){
		//======= partner provider mapping ==============
		List<PartnerProviderMapping> parnterProviderMappingList=(List<PartnerProviderMapping>)partner.getPartnerProviderMappingCollection();
		String tpCode=null;
		for(PartnerProviderMapping ppMapping:parnterProviderMappingList){
			if(ppMapping.getProviderId().getId()==provider.getId()){
				tpCode = ppMapping.getThirdPartyCode();
				break;
			}
		}
		partnerData.getProviderMap().put(providerData.getCode(), tpCode);
	}
	
	private void addInstrumentsInPartner(PartnerData partnerData,FinancialInstrument instrument){
		if(instrument!=null && instrument.getId()!=null && instrument.getId()>0){
			InstrumentData finData=new InstrumentData();
			finData.setId(instrument.getId());
			finData.setName(instrument.getName());
			partnerData.getInstrumentMap().put(finData, finData);
		}
	}
	
	private void addPartnerInProvider(String providerRelation,ProvidersData providerData,Partner partner,FinancialInstrument instrument,Integer sequence,Provider provider){
		if(!providerData.getPartnerMap().containsKey(new PartnerData(partner.getPartnerCode()))){
			PartnerData partnerData=new PartnerData();
			partnerData.setMode(partner.getMode());
			partnerData.setName(partner.getName());
			partnerData.setCode(partner.getPartnerCode());
			partnerData.setPartnerCode(partner.getPartnerCode());
			partnerData.setNickName(partner.getNickName());
			partnerData.setSequence(sequence);
			partnerData.setMappingName(partner.getMappingName());
			
			//Add Instrument in partnerData
			// only if call is for FSP or RI FSP Provider
			if(providerRelation.equalsIgnoreCase(SystemConstant.FSP_PROVIDER) || providerRelation.equalsIgnoreCase(SystemConstant.REGISTERED_INSTRUMENT_FSP_PROVIDER)){
				addInstrumentsInPartner(partnerData, instrument);
			}
			//Add ThirdPartyCode
			addTPCodeInPartner(partnerData, providerData, partner, provider);
			
			providerData.getPartnerMap().put(partnerData, partnerData);
		}else{
			PartnerData partnerData = providerData.getPartnerMap().get(new PartnerData(partner.getPartnerCode()));
			//Add Instrument in partnerData
			addInstrumentsInPartner(partnerData, instrument);
		}
	}
	
	public Map<ProvidersData,ProvidersData> getProviderDataMap(String providerRelation,List<HostSVProviderPartnerMapping> list){
		Map<ProvidersData,ProvidersData> map=new HashMap<>();
		for(HostSVProviderPartnerMapping mapping:list){
			if(providerRelation.equalsIgnoreCase(mapping.getMappingType())){
				
				FinancialInstrument instrument=mapping.getInstrumentId();
				Provider provider=mapping.getProviderId();
				Categories categories=mapping.getCatId();
				Partner partner=mapping.getPartnerId();
				
				/*if((providerRelation!=null && (providerRelation==SystemConstant.FSP_PROVIDER || providerRelation==SystemConstant.REGISTERED_INSTRUMENT_FSP_PROVIDER)) 
						&& (instrument==null || provider==null || categories==null || partner==null)){
					continue;
				}*/
				ProvidersData providerData= null;
				CategoryData categoryData = null;
				if(map.containsKey(new ProvidersData(mapping.getProviderId().getProviderCode(), mapping.getCatId().getCategoryCode()))){
					providerData = map.get(new ProvidersData(mapping.getProviderId().getProviderCode(), mapping.getCatId().getCategoryCode()));
					categoryData = providerData.getCategory();
					addPartnerInProvider(providerRelation,providerData, partner, instrument, mapping.getSequence(), provider);
				}else{
					providerData=new ProvidersData();
					categoryData = new CategoryData();
					categoryData.setCode(categories.getCategoryCode());
					categoryData.setId(categories.getId());
					categoryData.setName(categories.getCategoryName());
					providerData.setCategory(categoryData);
					providerData.setCode(provider.getProviderCode());
					providerData.setId(provider.getId());
					providerData.setName(provider.getName());
					addPartnerInProvider(providerRelation,providerData, partner, instrument, mapping.getSequence(), provider);
					map.put(providerData, providerData);
				}
			}
		}
		if(map!=null && !map.isEmpty()){
			for(Iterator<ProvidersData> itr=map.keySet().iterator();itr.hasNext();){
				ProvidersData pData = itr.next();
				if(pData!=null && pData.getPartnerMap()!=null && !pData.getPartnerMap().isEmpty()){
					Set<PartnerData> partnerSet = new TreeSet<PartnerData>();
					for(Iterator<PartnerData> itr2=pData.getPartnerMap().keySet().iterator();itr2.hasNext();)
					{
						PartnerData partData = itr2.next()	;
						partnerSet.add(partData);
					}
					pData.setPartners(partnerSet);
				}
			}
		}
		return map;
	}
	
	
	//========= leave it right now ============
	public List<com.ng.sb.common.dataobject.HostSVServiceConfigMapping> getHostSVConfigMapping(List<com.ng.sb.common.model.HostSVServiceConfigMapping> configList){
		 List<com.ng.sb.common.dataobject.HostSVServiceConfigMapping> list=new ArrayList<>();
		 
		 for(com.ng.sb.common.model.HostSVServiceConfigMapping config:configList){
			 com.ng.sb.common.dataobject.HostSVServiceConfigMapping data=new com.ng.sb.common.dataobject.HostSVServiceConfigMapping();
			
		 }
		 return list;
	}
	
	
	
	@Override
	 public Map<CategoryData,CategoryData> getCategoriesMap() throws Exception{
		 Map<CategoryData,CategoryData> map=new HashMap<>();
		 try {
			 List<Categories> list=cacheFillDAO.getCategoriesList();
			 for(Categories cat:list){
				 CategoryData data=new CategoryData();
				 data.setCode(cat.getCategoryCode());
				 data.setId(cat.getId());
				 data.setName(cat.getCategoryName());
				 map.put(data,data);
			 }
			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		 return map;
	 }
	
	private void addPartners(HostSVFspServicesPartnerMapping mapping,FSPServicesData data) {
		Set<PartnerData> partnerSet = data.getPartners();
		if (partnerSet == null) {
			partnerSet = new TreeSet<>();
		}
		PartnerData partnerData = new PartnerData();
		Partner partner = mapping.getPartnerId();
		partnerData.setMode(partner.getMode());
		partnerData.setName(partner.getName());
		partnerData.setCode(partner.getPartnerCode());
		partnerData.setNickName(partner.getNickName());
		partnerData.setSequence(mapping.getSequence());
		partnerData.setMappingName(partner.getMappingName());
		partnerSet.add(partnerData);
		data.setPartners(partnerSet);
	}
		 
	@Override
	public Map<FSPServicesData, FSPServicesData> getFspServiceMap(
			List<HostSVFspServicesPartnerMapping> fspList) throws Exception {
		Map<FSPServicesData, FSPServicesData> fspServiceMap = new HashMap<>();
		try {

			for (HostSVFspServicesPartnerMapping mapping : fspList) {
				FSPServices service = mapping.getFspServicesId();
				
				if(service != null)
				{
					FSPServicesData fspServicesData = fspServiceMap.get(new FSPServicesData(service.getName()));
					if (fspServicesData == null) {
						FSPServicesData data = new FSPServicesData();
						data.setDesc(service.getDesc());
						data.setId(service.getId());
						data.setInstrument(service.getInstrument());
						data.setName(service.getName());
						data.setType(service.getType());
						addPartners(mapping, data);
						fspServiceMap.put(data, data);
					} else {
						addPartners(mapping, fspServicesData);
					}
			     }
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return fspServiceMap;
	}
	
	@Override
	public Set<PartnerData> getPartner() throws Exception{
		Set<PartnerData> set=new TreeSet<>();
		try {
			List<Partner> list=cacheFillDAO.getPartnerList();
			for(Partner partner:list){
				PartnerData data=new PartnerData();
				data.setMode(partner.getMode());
				data.setName(partner.getName());
				data.setCode(partner.getPartnerCode());
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return set;
	}
	
	public Map<InstrumentData,InstrumentData> getInstrumentMap(List<HostSVFinInstrumentPartnerMapping> instrumentList){
		Map<InstrumentData,InstrumentData> map=new HashMap<>();
		try{
			
			Set<PartnerData> partnerSet=null;
			PartnerData partnerData=null;
			for(HostSVFinInstrumentPartnerMapping mapping:instrumentList){
				FinancialInstrument instrument=mapping.getInstrumentId();
				InstrumentData data=new InstrumentData();
				data.setId(instrument.getId());
				data.setName(instrument.getName());
				Partner partner=mapping.getPartnerId();
				if(!map.containsKey(new InstrumentData(data.getName()))){
					partnerData=new PartnerData();
					partnerData.setMode(partner.getMode());
					partnerData.setName(partner.getName());
					partnerData.setCode(partner.getPartnerCode());
					partnerData.setNickName(partner.getNickName());
					partnerData.setSequence(mapping.getSequence());
					partnerData.setMappingName(partner.getMappingName());	
					partnerSet=new TreeSet<>();
					partnerSet.add(partnerData);
				}
				else{
					data=map.get(new InstrumentData(instrument.getName()));
					partnerSet=data.getPartners();
					partnerData=new PartnerData();
					partnerData.setMode(partner.getMode());
					partnerData.setName(partner.getName());
					partnerData.setCode(partner.getPartnerCode());
					partnerData.setNickName(partner.getNickName());
					partnerData.setSequence(mapping.getSequence());
					partnerData.setMappingName(partner.getMappingName());	
					partnerSet.add(partnerData);
				}
				data.setPartners(partnerSet);
				map.put(data, data);
			}
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return map;
	}
	
	@Override
	public Map<ServiceConfigData,ServiceConfigData> getServiceConfigMap() throws Exception{
		Map<ServiceConfigData,ServiceConfigData> map=new HashMap<>();
		try {
			List<ServiceConfig> list=cacheFillDAO.getServiceConfigList();
			for(ServiceConfig config:list){
				ServiceConfigData serviceConfigData=new ServiceConfigData();
				serviceConfigData.setId(config.getId());
				serviceConfigData.setMvCode(config.getMvId().getCode());
				serviceConfigData.setName(config.getServiceName());
				serviceConfigData.setServiceCode(config.getStkCode());
				serviceConfigData.setServiceDefinition(config.getServiceDefination());
				serviceConfigData.setServiceDesc(config.getServiceDescription());
				serviceConfigData.setServiceName(config.getServiceName());
				int status=(config.getStatus()==false)?0:1;
				serviceConfigData.setStatus(status);
				int validationRequired=(config.getValidationReq()==false)?0:1;
				serviceConfigData.setValidationReq(validationRequired);
				
				
				List<ServiceParamMapping> paramList=(List<ServiceParamMapping>)config.getServiceParamMappingCollection();
				List<ServiceParamsMappingData> mappingList=new ArrayList<>();
				for(ServiceParamMapping mapping:paramList){
					ServiceParamsMappingData data=new ServiceParamsMappingData();
					data.setId(mapping.getId());
					data.setIsnumericField(mapping.getIsNumeric());
					data.setObjectMapping(mapping.getObjectMapping());
					data.setSequence(mapping.getSequence());
					data.setDesc(mapping.getDescription());
					data.setServiceId(mapping.getServiceId().getId());
					mappingList.add(data);
				}
				serviceConfigData.setParamMappings(mappingList);
				
				List<ServiceConfig> subServiceList=(List<ServiceConfig>)config.getServiceConfigCollection();
				List<ServiceConfigData> subServiceConfigDataList=new ArrayList<>();
				for(ServiceConfig serviceCofnig:subServiceList){
					ServiceConfigData subServiceConfigData=new ServiceConfigData();
					subServiceConfigData.setId(serviceCofnig.getId());
					subServiceConfigData.setMvCode(serviceCofnig.getMvId().getCode());
					subServiceConfigData.setName(serviceCofnig.getServiceName());
					subServiceConfigData.setServiceCode(serviceCofnig.getStkCode());
					subServiceConfigData.setServiceDefinition(serviceCofnig.getServiceDefination());
					subServiceConfigData.setServiceDesc(serviceCofnig.getServiceDescription());
					subServiceConfigData.setServiceName(serviceCofnig.getServiceName());
					int status1=(config.getStatus()==false)?0:1;
					serviceConfigData.setStatus(status1);
					int validationRequired1=(serviceCofnig.getValidationReq()==false)?0:1;
					subServiceConfigData.setValidationReq(validationRequired1);
					
					
					List<ServiceParamMapping> paramList1=(List<ServiceParamMapping>)config.getServiceParamMappingCollection();
					List<ServiceParamsMappingData> mappingList1=new ArrayList<>();
					for(ServiceParamMapping mapping1:paramList1){
						ServiceParamsMappingData data1=new ServiceParamsMappingData();
						data1.setId(mapping1.getId());
						data1.setIsnumericField(mapping1.getIsNumeric());
						data1.setObjectMapping(mapping1.getObjectMapping());
						data1.setSequence(mapping1.getSequence());
						data1.setDesc(mapping1.getDescription());
						data1.setServiceId(mapping1.getServiceId().getId());
						mappingList1.add(data1);
					}
					subServiceConfigData.setParamMappings(mappingList1);
					subServiceConfigDataList.add(subServiceConfigData);
					
					serviceConfigData.setSubServiceList(subServiceConfigDataList);
					
				}
				map.put(serviceConfigData, serviceConfigData);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return map;
	}
}
