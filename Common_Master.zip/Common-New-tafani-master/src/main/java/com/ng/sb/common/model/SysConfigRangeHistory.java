/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "sys_config_range_history")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "SysConfigRangeHistory.findAll", query = "SELECT s FROM SysConfigRangeHistory s"),
    @NamedQuery(name = "SysConfigRangeHistory.findById", query = "SELECT s FROM SysConfigRangeHistory s WHERE s.id = :id"),
    @NamedQuery(name = "SysConfigRangeHistory.findByMin", query = "SELECT s FROM SysConfigRangeHistory s WHERE s.min = :min"),
    @NamedQuery(name = "SysConfigRangeHistory.findByMax", query = "SELECT s FROM SysConfigRangeHistory s WHERE s.max = :max"),
    @NamedQuery(name = "SysConfigRangeHistory.findByValue", query = "SELECT s FROM SysConfigRangeHistory s WHERE s.value = :value"),
    @NamedQuery(name = "SysConfigRangeHistory.findByType", query = "SELECT s FROM SysConfigRangeHistory s WHERE s.type = :type"),
    @NamedQuery(name = "SysConfigRangeHistory.findByCreateDate", query = "SELECT s FROM SysConfigRangeHistory s WHERE s.createDate = :createDate")})
public class SysConfigRangeHistory implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "min", precision = 12)
    private Float min;
    @Column(name = "max", precision = 12)
    private Float max;
    @Column(name = "value", precision = 12)
    private Float value;
    @Column(name = "type", length = 5)
    private String type;
    @Column(name = "create_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createDate;
    @JoinColumn(name = "sysCommConfigId", referencedColumnName = "id")
    @ManyToOne
    private CommissionTemplate sysCommConfigId;

    public SysConfigRangeHistory() {
    	//default constructor
    }

    public SysConfigRangeHistory(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Float getMin() {
        return min;
    }

    public void setMin(Float min) {
        this.min = min;
    }

    public Float getMax() {
        return max;
    }

    public void setMax(Float max) {
        this.max = max;
    }

    public Float getValue() {
        return value;
    }

    public void setValue(Float value) {
        this.value = value;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public CommissionTemplate getSysCommConfigId() {
        return sysCommConfigId;
    }

    public void setSysCommConfigId(CommissionTemplate sysCommConfigId) {
        this.sysCommConfigId = sysCommConfigId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof SysConfigRangeHistory)) {
            return false;
        }
        SysConfigRangeHistory other = (SysConfigRangeHistory) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.SysConfigRangeHistory[ id=" + id + " ]";
    }
    
}
