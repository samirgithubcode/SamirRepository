function getRaioTextValue(selectedRadioTdId,divId){
    
	$("#newPassword").val('');
	$("#cnfPassword").val('');
	
	$("#lable_cnfPasswordErrorId").html('');
		$("#lable_emailOrUserIdErrorId").html('');
	$('#newPassword').attr("value", "");
	$('#cnfPassword').attr("value", "");
			$("#lable_emailOrUserIdErrorId").html('');
		 $("#lable_newPasswordErrorId").html("");
		$("#lable_cnfPasswordErrorId").html('');

	$("#emailMobileUserTextboxTable").remove();
	$('#notMatchMessage').html('');
	
	//$('#emailMobileUserTextbox').remove();
	var selectedRadioType=$("#"+selectedRadioTdId).text().trim();
	
	
	var errorId="'lable_emailOrUserIdErrorId'";
	//alert(" get RadioTextValue :"+selectedRadioType +" div Id :"+divId);
	if(selectedRadioType==='Mobile Number'){
		$("#tbodyid").empty();
		var html='<table id="emailMobileUserTextboxTable" width="60%">'+
        '<tr id="emailMobileUserTextbox">'+
	      '<td id="selectedRadioTypeId" align="right" width="45%"><font color="red">*&nbsp;</font>'+selectedRadioType+'&nbsp;:&nbsp;&nbsp;</td><td width="55%" align="left"><input type="text" id="emailOrUserId" maxlength="10" name="'+selectedRadioType+'" maxlength="10" onkeypress="onlyNumric(event,'+errorId+');" onclick="emptyerror(event,'+errorId+');" onchange="mobileNumberValidation();" /></td>'+
	      '</tr>'+
	      '<tr><td  width="45%"></td><td width="55%" id="lable_emailOrUserIdErrorId" align="left"></td></tr>'+
	      '</table>';
	}else{
		$("#tbodyid").empty();
 var html='<table id="emailMobileUserTextboxTable" width="60%">'+
           '<tr id="emailMobileUserTextbox">'+
	      '<td id="selectedRadioTypeId" align="right" width="45%"><font color="red">*&nbsp;</font>'+selectedRadioType+'&nbsp;:&nbsp;&nbsp;</td><td width="55%" align="left"><input type="text" id="emailOrUserId" name="'+selectedRadioType+'" onclick="emptyerror(event,'+errorId+');"   /></td>'+
	      '</tr>'+
	      '<tr><td  width="45%"></td><td width="55%" id="lable_emailOrUserIdErrorId" align="left"></td></tr>'+
	      '</table>';
	}
 $(html).appendTo($("#"+divId));
 $("#"+divId).show();
 $('#resetByErrorId').html("");
// $("#"+selectedRadioTdId).attr('checked', 'checked');
 //$('#emailMobileUserTextbox').remove();
	
}

function validateResetPasswordPage(){
		//alert("validationResetPasswordPage ");
	
	var completeCheck = true;
	
	//********************************* Check Radio Button ************************************************
	if(!($('#email').is(":checked")) && (!($('#mobile').is(":checked"))) && (!($('#userName').is(":checked"))))
	{
		$('#resetByErrorId').html("");
		$('#resetByErrorId').html("<b><font color='red'>Kindly check atleast one radio button !</font></b>");
		completeCheck = false;
	}
	else{
		var emailMobileUserId=$("#emailOrUserId").val().trim();
		var selectedRadioType=$("#selectedRadioTypeId").text().trim();
		if(emailMobileUserId.length<=0){
			
			$("#lable_emailOrUserIdErrorId").html('<b><font color=red>Kindly enter  '+selectedRadioType.substring(2,selectedRadioType.length-1)+ '</font></b>');
			 completeCheck = false;
		}
	}
	
	/* if(!($('#email').is(':checked')) && !($('#mobile').is(':checked')) && !($('#userName').is(':checked')))
	 {
		// alert("hyfghgh ");
		 $('#resetByErrorId').html("");
		 $('#resetByErrorId').html("<b><font color='red'>Kindly Choose One Radio  !</font></b>");
		 completeCheck = false;
	 }
	 else{
		 $('#resetByErrorId').html("<b><font color='red'>Kindly Choose One Radio  !</font></b>");
		 completeCheck = false;
	 }*/
	var newPassword=$("#newPassword").val();
	
	
	if(newPassword.length<=0){
		
		 $("#lable_newPasswordErrorId").html("<b><font color='red'>Kindly enter new password</font></b>");
		 completeCheck = false;
	 }
	var cnfPassword =$("#cnfPassword").val();
	
	if(cnfPassword.length<=0){
		$("#lable_cnfPasswordErrorId").html("<b><font color='red'>Kindly enter confirm password</font></b>");
		completeCheck = false;
	}
	if(newPassword!==cnfPassword){
		
		$("#lable_cnfPasswordErrorId").html("<b><font color='red'>Password does not match</font></b>");
		completeCheck = false;
	}
	
	
	if(!completeCheck){
		
		return false;
	}
	
}

function mobileNumberValidation(e,lable_emailOrUserIdErrorId){
	var mobileNumberRegex=/^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[789]\d{9}$/;
	var data=$("#emailOrUserId").val();
	if(!mobileNumberRegex.test(data)){
		$("#lable_emailOrUserIdErrorId").html("<b><font color='red'>Please enter valid mobile number.</font></b>");
		return false;
	}
		else{
			$('#'+errorid).html("");
			return true;
		
	}
}

