package com.ng.sb.common.model;



import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "transaction_commission")
@NamedQueries({
	@NamedQuery(name="TransactionCommission.findAll",  query="SELECT tc FROM TransactionCommission tc"),
	@NamedQuery(name="TransactionCommission.findByTxnId", query="SELECT tc FROM TransactionCommission tc where tc.transactionId=:trxid"),
	@NamedQuery(name="TransactionCommission.findById", query="SELECT tc FROM TransactionCommission tc where tc.id=:id"),
	@NamedQuery(name="TransactionCommission.findAllReverse",  query="SELECT c FROM TransactionCommission c order by c.transactionTime desc"),
	
})
public class TransactionCommission implements Serializable{

	private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    
    @Column(name = "trx_id")   
    private Integer transactionId;
    
    @Column(name = "trx_date")
    @Temporal(TemporalType.TIMESTAMP)
	private Date transactionTime;
    
    @Column(name = "trx_amt", precision = 12)
    private Float trxAmount;
	
	@Column(name = "agent_id")
	private Integer agentId;
	
	@Column(name = "agent_comm_amt", precision = 12)
    private Float agentCommission;
	
	@Column(name = "host_id")
	private Integer hostId;
	
	
	@Column(name = "host_comm_amt", precision = 12)
    private Float hostCommission;
	
	@Column(name = "dist_id")
	private Integer distId;
	
	@Column(name = "dist_comm_amt", precision = 12)
    private Float distCommission;
	
	@Column(name = "subdist_id")
	private Integer subDistId;
	
	@Column(name = "subdist_comm_amt", precision = 12)
    private Float subDistCommission;
	
	@Column(name = "total_comm_amt", precision = 12)
    private Float totalCommission;
	
	@Column(name = "comm_id")
    private Integer commissionId;
	
	@Column(name = "entry_date")
    @Temporal(TemporalType.TIMESTAMP)
	private Date entryDate;
	
	@Column(name = "CR_DR")
    private String entryType;
	
	@Column(name = "issettled")
    private int isSettled;
    
	@Column(name = "settled_on")
	@Temporal(TemporalType.TIMESTAMP)
	private Date settledOn;
	
	@Column(name = "isActive")
    private int isActive;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Integer transactionId) {
		this.transactionId = transactionId;
	}

	public Date getTransactionTime() {
		return transactionTime;
	}

	public void setTransactionTime(Date transactionTime) {
		this.transactionTime = transactionTime;
	}

	public Integer getAgentId() {
		return agentId;
	}

	public void setAgentId(Integer agentId) {
		this.agentId = agentId;
	}

	public Float getAgentCommission() {
		return agentCommission;
	}

	public void setAgentCommission(Float agentCommission) {
		this.agentCommission = agentCommission;
	}

	public Integer getHostId() {
		return hostId;
	}

	public void setHostId(Integer hostId) {
		this.hostId = hostId;
	}

	public Float getHostCommission() {
		return hostCommission;
	}

	public void setHostCommission(Float hostCommission) {
		this.hostCommission = hostCommission;
	}

	public Integer getDistId() {
		return distId;
	}

	public void setDistId(Integer distId) {
		this.distId = distId;
	}

	public Float getDistCommission() {
		return distCommission;
	}

	public void setDistCommission(Float distCommission) {
		this.distCommission = distCommission;
	}

	public Integer getSubDistId() {
		return subDistId;
	}

	public void setSubDistId(Integer subDistId) {
		this.subDistId = subDistId;
	}

	public Float getSubDistCommission() {
		return subDistCommission;
	}

	public void setSubDistCommission(Float subDistCommission) {
		this.subDistCommission = subDistCommission;
	}

	public Integer getCommissionId() {
		return commissionId;
	}

	public void setCommissionId(Integer commissionId) {
		this.commissionId = commissionId;
	}

	public Date getEntryDate() {
		return entryDate;
	}

	public void setEntryDate(Date entryDate) {
		this.entryDate = entryDate;
	}

	public String getEntryType() {
		return entryType;
	}

	public void setEntryType(String entryType) {
		this.entryType = entryType;
	}

	public int getIsSettled() {
		return isSettled;
	}

	public void setIsSettled(int isSettled) {
		this.isSettled = isSettled;
	}

	public Date getSettledOn() {
		return settledOn;
	}

	public void setSettledOn(Date settledOn) {
		this.settledOn = settledOn;
	}

	public int getIsActive() {
		return isActive;
	}

	public void setIsActive(int isActive) {
		this.isActive = isActive;
	}

	public Float getTrxAmount() {
		return trxAmount;
	}

	public void setTrxAmount(Float trxAmount) {
		this.trxAmount = trxAmount;
	}

	public Float getTotalCommission() {
		return totalCommission;
	}

	public void setTotalCommission(Float totalCommission) {
		this.totalCommission = totalCommission;
	}
	
	
	
}
