package com.ng.sb.common.model;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="merchant_device_mapping")
@NamedQueries
({
	/*@NamedQuery(name="merchant_device_mapping.findAll", query="SELECT m FROM merchant_device_mapping m"),*/
})
public class MerchantDeviceMapping implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;

	@Column(name = "merchantId")
	private Integer merchantId;

	@Column(name = "refmerchantInfoId")
	private Integer refmerchantInfoId;

	@Column(name = "deviceType")
	private String deviceType;
	
	@Column(name="externalNo")
    private  String externalNo;
	
	@Column(name="internalNo")
	 private String internalNo;
	
	@Column(name="addedOn")
	private Date addedOn;
	
	@Column(name="addedBy")
	private Date addedBy;
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(Integer merchantId) {
		this.merchantId = merchantId;
	}

	public Integer getRefmerchantInfoId() {
		return refmerchantInfoId;
	}

	public void setRefmerchantInfoId(Integer refmerchantInfoId) {
		this.refmerchantInfoId = refmerchantInfoId;
	}

	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

	public String getExternalNo() {
		return externalNo;
	}

	public void setExternalNo(String externalNo) {
		this.externalNo = externalNo;
	}

	public String getInternalNo() {
		return internalNo;
	}

	public void setInternalNo(String internalNo) {
		this.internalNo = internalNo;
	}

	public Date getAddedOn() {
		return addedOn;
	}

	public void setAddedOn(Date addedOn) {
		this.addedOn = addedOn;
	}

	public Date getAddedBy() {
		return addedBy;
	}

	public void setAddedBy(Date addedBy) {
		this.addedBy = addedBy;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Column(name="status")
	private String status;
	
	
	
}
