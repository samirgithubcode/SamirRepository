package com.ng.sb.common.dataobject;


import java.sql.Date;
import java.util.List;

/**
 * @author abhishek
 *
 */
public class DenominationData extends  BaseObjectData{
	
	private static final long serialVersionUID = 1L;

	private Integer id;
	private Integer denominationValue;
	private String denominationName;
	private Date startDate;
	private Date endDate;
	private List<DenominationData> denominationDataList;
	private List<DenominationData> denominationDataListNotStartList;
	private Integer deactivateid;
	
	private Integer hiddenid;
	
	
	
	public Integer getDeactivateid() {
		return deactivateid;
	}

	public void setDeactivateid(Integer deactivateid) {
		this.deactivateid = deactivateid;
	}

	public void setDenominationDataListNotStartList(List<DenominationData> denominationDataListNotStartList) {
		this.denominationDataListNotStartList = denominationDataListNotStartList;
	}

	public List<DenominationData> getDenominationDataListNotStartList() {
		return denominationDataListNotStartList;
	}

	public Integer getUserId() {
		return id;
	}
	
	public void setUserId(Integer id) {
		this.id = id;
	}
	
	public Integer getDenominationValue() {
		return denominationValue;
	}
	
	public void setDenominationValue(Integer denominationValue) {
		this.denominationValue = denominationValue;
	}
	
	public String getDenominationName() {
		return denominationName;
	}

	public void setDenominationName(String denominationName) {
		this.denominationName = denominationName;
	}


	
	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public List<DenominationData> getDenominationDataList() {
		return denominationDataList;
	}

	public void setDenominationDataList(List<DenominationData> denominationDataList) {
		this.denominationDataList = denominationDataList;
	}

	public Integer getHiddenid() {
		return hiddenid;
	}

	public void setHiddenid(Integer hiddenid) {
		this.hiddenid = hiddenid;
	}

	
}
