/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "complaint_sub_category_types")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "ComplaintSubCategoryTypes.findAll", query = "SELECT c FROM ComplaintSubCategoryTypes c"),
    @NamedQuery(name = "ComplaintSubCategoryTypes.findById", query = "SELECT c FROM ComplaintSubCategoryTypes c WHERE c.id = :id"),
    @NamedQuery(name = "ComplaintSubCategoryTypes.findBySubCategorytype", query = "SELECT c FROM ComplaintSubCategoryTypes c WHERE c.subCategorytype = :subCategorytype"),
    @NamedQuery(name = "ComplaintSubCategoryTypes.findByExsubCategoryid", query = "SELECT c FROM ComplaintSubCategoryTypes c WHERE c.exsubCategoryid = :exsubCategoryid"),
    @NamedQuery(name = "ComplaintSubCategoryTypes.findBySubCategoryName", query = "SELECT c FROM ComplaintSubCategoryTypes c WHERE c.subCategoryName = :subCategoryName"),
    @NamedQuery(name = "ComplaintSubCategoryTypes.findByDescription", query = "SELECT c FROM ComplaintSubCategoryTypes c WHERE c.description = :description"),
    @NamedQuery(name = "ComplaintSubCategoryTypes.findByStatus", query = "SELECT c FROM ComplaintSubCategoryTypes c WHERE c.status = :status"),
    @NamedQuery(name = "ComplaintSubCategoryTypes.findByRemarks", query = "SELECT c FROM ComplaintSubCategoryTypes c WHERE c.remarks = :remarks"),
    @NamedQuery(name = "ComplaintSubCategoryTypes.findByAddDate", query = "SELECT c FROM ComplaintSubCategoryTypes c WHERE c.addDate = :addDate"),
    @NamedQuery(name = "ComplaintSubCategoryTypes.findByEditDate", query = "SELECT c FROM ComplaintSubCategoryTypes c WHERE c.editDate = :editDate"),
    @NamedQuery(name = "ComplaintSubCategoryTypes.findByAddByRoleId", query = "SELECT c FROM ComplaintSubCategoryTypes c WHERE c.addByRoleId = :addByRoleId"),
    @NamedQuery(name = "ComplaintSubCategoryTypes.findByEditByRoleId", query = "SELECT c FROM ComplaintSubCategoryTypes c WHERE c.editByRoleId = :editByRoleId")})
public class ComplaintSubCategoryTypes implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
    @Basic(optional = false)
    @Column(name = "subCategory_type", nullable = false)
    private int subCategorytype;
    @Column(name = "ex_subCategory_id")
    private Integer exsubCategoryid;
    @Basic(optional = false)
    @Column(name = "sub_category_name", nullable = false, length = 50)
    private String subCategoryName;
    @Basic(optional = false)
    @Column(name = "description", nullable = false, length = 200)
    private String description;
  
    @Column(name = "remarks", length = 500)
    private String remarks;
    @Basic(optional = false)
    @Column(name = "status", nullable = false)
    private int status;
    @Basic(optional = false)
    @Column(name = "add_date", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date addDate;
    
    @Basic(optional = false)
    @Column(name = "add_by_role_id", nullable = false)
    private int addByRoleId;
    
    @Column(name = "edit_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date editDate;
    @Column(name = "edit_by_role_id")
    private Integer editByRoleId;
    @OneToMany(mappedBy = "subCategoryId")
    private Collection<FaqDetails> faqDetailsCollection;
    @JoinColumn(name = "category_id", referencedColumnName = "id", nullable = false)
    @ManyToOne(optional = false)
    private ComplaintCategoryTypes categoryId;
    @JoinColumn(name = "group_id", referencedColumnName = "id")
    @ManyToOne
    private SysAccountGroup groupId;
    @JoinColumn(name = "account_id", referencedColumnName = "id")
    @ManyToOne
    private AccountInfo accountId;
    @OneToMany(mappedBy = "subCategoryId")
    private Collection<TicketQueryDetails> ticketQueryDetailsCollection;

    public ComplaintSubCategoryTypes() {
    	//default constructor
    }

    public ComplaintSubCategoryTypes(Integer id) {
        this.id = id;
    }

    public ComplaintSubCategoryTypes(Integer id, int subCategorytype, String subCategoryName, String description, int status, Date addDate, int addByRoleId) {
        this.id = id;
        this.subCategorytype = subCategorytype;
        this.subCategoryName = subCategoryName;
        this.description = description;
        this.status = status;
        this.addDate = addDate;
        this.addByRoleId = addByRoleId;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public int getSubCategorytype() {
        return subCategorytype;
    }

    public void setSubCategorytype(int subCategorytype) {
        this.subCategorytype = subCategorytype;
    }

    public Integer getExsubCategoryid() {
        return exsubCategoryid;
    }

    public void setExsubCategoryid(Integer exsubCategoryid) {
        this.exsubCategoryid = exsubCategoryid;
    }

    public String getSubCategoryName() {
        return subCategoryName;
    }

    public void setSubCategoryName(String subCategoryName) {
        this.subCategoryName = subCategoryName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    
    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getAddByRoleId() {
        return addByRoleId;
    }

    public void setAddByRoleId(int addByRoleId) {
        this.addByRoleId = addByRoleId;
    }

    public Date getEditDate() {
        return editDate;
    }

    public void setEditDate(Date editDate) {
        this.editDate = editDate;
    }
    
    public Date getAddDate() {
        return addDate;
    }

    public void setAddDate(Date addDate) {
        this.addDate = addDate;
    }

    
    public Integer getEditByRoleId() {
        return editByRoleId;
    }

    public void setEditByRoleId(Integer editByRoleId) {
        this.editByRoleId = editByRoleId;
    }

    @XmlTransient
    public Collection<FaqDetails> getFaqDetailsCollection() {
        return faqDetailsCollection;
    }

    public void setFaqDetailsCollection(Collection<FaqDetails> faqDetailsCollection) {
        this.faqDetailsCollection = faqDetailsCollection;
    }

    public ComplaintCategoryTypes getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(ComplaintCategoryTypes categoryId) {
        this.categoryId = categoryId;
    }

    public SysAccountGroup getGroupId() {
        return groupId;
    }

    public void setGroupId(SysAccountGroup groupId) {
        this.groupId = groupId;
    }

    public AccountInfo getAccountId() {
        return accountId;
    }

    public void setAccountId(AccountInfo accountId) {
        this.accountId = accountId;
    }

    @XmlTransient
    public Collection<TicketQueryDetails> getTicketQueryDetailsCollection() {
        return ticketQueryDetailsCollection;
    }

    public void setTicketQueryDetailsCollection(Collection<TicketQueryDetails> ticketQueryDetailsCollection) {
        this.ticketQueryDetailsCollection = ticketQueryDetailsCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof ComplaintSubCategoryTypes)) {
            return false;
        }
        ComplaintSubCategoryTypes other = (ComplaintSubCategoryTypes) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.ComplaintSubCategoryTypes[ id=" + id + " ]";
    }
    
}
