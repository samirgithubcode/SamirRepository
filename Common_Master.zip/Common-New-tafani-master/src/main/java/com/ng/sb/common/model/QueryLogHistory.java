package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;



@Entity
@Table(name = "queryloghistory")
@XmlRootElement

@NamedQueries({
	@NamedQuery(name="QueryLogHistory.findAll", query="SELECT c FROM QueryLogHistory c order by c.ticketno ASC "),
	@NamedQuery(name="QueryLogHistory.findByTicketNumber", query="SELECT c FROM QueryLogHistory c where c.ticketno=:ticketNo order by c.addedon desc ")
	
})

public class QueryLogHistory implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4299862154239595637L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "id")
	private Integer id;
	
	
	@Basic(optional = true)
	@Column(name = "ticketno")
	private String ticketno;
	
	
	@Basic(optional = true)
	@JoinColumn(name = "query_logid", referencedColumnName = "id")
	@ManyToOne
	private CustomerQueryLog customerQueryLog;

	
	
	@Basic(optional = true)
	@Column(name = "comment")
	private String comment;
	
	
	
	@Basic(optional = true)
	@JoinColumn(name = "addedby", referencedColumnName = "id")
	@ManyToOne
	private AccountLoginInfo addedby;
	

	@Basic(optional = true)
	@Column(name = "addedon")
	@Temporal(TemporalType.TIMESTAMP)
	private Date addedon;
	
	
	
	@Basic(optional = true)
	@Column(name = "createdon")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdon;
	
	@Basic(optional = true)
	@Column(name = "status")
	private String status ;
	public QueryLogHistory() {
		/*
		 * 
		 */
	}
	public QueryLogHistory(Integer id) {
		super();
		this.id = id;
	}
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTicketno() {
		return ticketno;
	}

	public void setTicketno(String ticketno) {
		this.ticketno = ticketno;
	}

	public CustomerQueryLog getCustomerQueryLog() {
		return customerQueryLog;
	}

	public void setCustomerQueryLog(CustomerQueryLog customerQueryLog) {
		this.customerQueryLog = customerQueryLog;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public AccountLoginInfo getAddedby() {
		return addedby;
	}
	@Override
	public String toString() {
		return "QueryLogHistory [id=" + id + "]";
	}

	public void setAddedby(AccountLoginInfo addedby) {
		this.addedby = addedby;
	}

	public Date getAddedon() {
		return addedon;
	}

	@Override
	public int hashCode() {
		 int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	public void setAddedon(Date addedon) {
		this.addedon = addedon;
	}

	public Date getCreatedon() {
		return createdon;
	}

	public void setCreatedon(Date createdon) {
		this.createdon = createdon;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		QueryLogHistory other = (QueryLogHistory) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}


	
	

	
	
	
	

}
