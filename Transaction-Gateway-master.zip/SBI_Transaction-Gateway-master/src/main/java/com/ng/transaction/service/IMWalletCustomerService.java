/**
 * 
 */
package com.ng.transaction.service;

import com.ng.sb.common.dataobject.BridgeDataObject;

/**
 * @author gaurav
 *
 */
public interface IMWalletCustomerService extends IWalletService {
	public BridgeDataObject cashOut(BridgeDataObject bridgeDataObject);
	
	public BridgeDataObject custTopUpOnlineWalletToWallet(BridgeDataObject bridgeDataObject);
	public BridgeDataObject custTopUpOnlineBankToWallet(BridgeDataObject bridgeDataObject);
	public BridgeDataObject custTopUpOnlineCCToWallet(BridgeDataObject bridgeDataObject);
	public BridgeDataObject custTopUpOnlineIMPSToWallet(BridgeDataObject bridgeDataObject);
	public BridgeDataObject custwalletCheckBalance(BridgeDataObject bridgeDataObject);
	
	public BridgeDataObject custWalletCashOutToWallet(BridgeDataObject bridgeDataObject);
}
