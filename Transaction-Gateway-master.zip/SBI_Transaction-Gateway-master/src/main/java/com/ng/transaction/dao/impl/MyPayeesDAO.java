/**
 * 
 */
package com.ng.transaction.dao.impl;

import org.springframework.stereotype.Repository;

import com.ng.sb.common.util.SystemConstant;
import com.ng.transaction.dao.IMyPayeesDAO;

/**
 * @author gaurav
 *
 */
@Repository(value=SystemConstant.MY_PAYEES_DAO)
public class MyPayeesDAO extends SettingsDAO implements IMyPayeesDAO {
	private static final long serialVersionUID = 1L;

}
