package com.ng.sb.common.dataobject;

import java.util.List;
import java.util.Map;

public class OTAMessageData extends BaseObjectData {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Map<Integer,String> hostSubVersionMap;
	private String subscriberType;
	private Integer hostSubVersion;
	private String hostSubVersionName;
	private List<SubscriberData> subscriberDatas;
	private List<String> mobileNumber;
	private Map<String,String> userStatus;
	private String status;
	private Integer hostId;
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Map<String, String> getUserStatus() {
		return userStatus;
	}
	public void setUserStatus(Map<String, String> userStatus) {
		this.userStatus = userStatus;
	}
	public List<String> getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(List<String> mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getHostSubVersionName() {
		return hostSubVersionName;
	}
	public void setHostSubVersionName(String hostSubVersionName) {
		this.hostSubVersionName = hostSubVersionName;
	}
	public List<SubscriberData> getSubscriberDatas() {
		return subscriberDatas;
	}
	public void setSubscriberDatas(List<SubscriberData> subscriberDatas) {
		this.subscriberDatas = subscriberDatas;
	}
	public Integer getHostSubVersion() {
		return hostSubVersion;
	}
	public void setHostSubVersion(Integer hostSubVersion) {
		this.hostSubVersion = hostSubVersion;
	}
	
	public Integer getHostId() {
		return hostId;
	}
	public void setHostId(Integer hostId) {
		this.hostId = hostId;
	}
	public Map<Integer, String> getHostSubVersionMap() {
		return hostSubVersionMap;
	}
	public void setHostSubVersionMap(Map<Integer, String> hostSubVersionMap) {
		this.hostSubVersionMap = hostSubVersionMap;
	}
	public String getSubscriberType() {
		return subscriberType;
	}
	public void setSubscriberType(String subscriberType) {
		this.subscriberType = subscriberType;
	}
	
}	
