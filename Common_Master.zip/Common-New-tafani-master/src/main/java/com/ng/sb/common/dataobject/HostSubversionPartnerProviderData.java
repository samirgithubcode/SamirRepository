package com.ng.sb.common.dataobject;

import java.util.Map;

public class HostSubversionPartnerProviderData  extends BaseObjectData{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Map<PartnerData,Map<String,String>> partnerSequenceMap;
	
	public Map<PartnerData, Map<String, String>> getPartnerSequenceMap() {
		return partnerSequenceMap;
	}
	public void setPartnerSequenceMap(Map<PartnerData, Map<String, String>> partnerSequenceMap) {
		this.partnerSequenceMap = partnerSequenceMap;
	}
	private Map<String,String> partnerSequenceCommissionMap;
	
	public Map<String, String> getPartnerSequenceCommissionMap() {
		return partnerSequenceCommissionMap;
	}
	public void setPartnerSequenceCommissionMap(Map<String, String> partnerSequenceCommissionMap) {
		this.partnerSequenceCommissionMap = partnerSequenceCommissionMap;
	}

}
