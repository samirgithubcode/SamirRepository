/**
 * 
 */
package com.ng.transaction.util;

/**
 * @author gopal
 *
 */
public enum InventoryStatus {

	ACTIVATE(1001,"ACTIVATE"),
	DE_ACTIVATE(1002,"DE_ACTIVATE");
	
	private Integer actionCode;
	private String actionName;
	
	InventoryStatus(Integer actionCode, String actionName)
	{
		this.actionCode = actionCode;
		this.actionName = actionName;
	}

	public Integer getActionCode() {
		return actionCode;
	}

	public String getActionName() {
		return actionName;
	}
	
	
}
