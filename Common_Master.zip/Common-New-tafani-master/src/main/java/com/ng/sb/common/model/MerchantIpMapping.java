package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.*;


/**
 * The persistent class for the MerchantIpMapping database table.
 * 
 */
@Entity
@Table(name="MerchantIpMapping")
@NamedQueries({
@NamedQuery(name="MerchantIpMapping.findAll", query="SELECT m FROM MerchantIpMapping m"),
@NamedQuery(name="MerchantIpMapping.findByMerchantId", query="SELECT m FROM MerchantIpMapping m where m.merchantInfo = :merchantInfo"),
@NamedQuery(name="MerchantIpMapping.findByMerchantIp", query="SELECT m FROM MerchantIpMapping m where m.ip = :ip"),
@NamedQuery(name="MerchantIpMapping.findCountByMerchantIp", query="SELECT COUNT(m) FROM MerchantIpMapping m where m.ip = :ip"),

})
public class MerchantIpMapping implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false)
	private Integer id;

	@Column(name="ip", nullable=false, length=25)
	private String ip;

	//bi-directional many-to-one association to MerchantInfo
	@ManyToOne
	@JoinColumn(name="merchantId", nullable=false)
	private MerchantInfo merchantInfo;

	public MerchantIpMapping() {
		//empty
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getIp() {
		return this.ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public MerchantInfo getMerchantInfo() {
		return this.merchantInfo;
	}

	public void setMerchantInfo(MerchantInfo merchantInfo) {
		this.merchantInfo = merchantInfo;
	}

}