package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the MerchantTillMapping database table.
 * 
 */
@Entity
@Table(name="MerchantTillMapping")
@NamedQueries
({
@NamedQuery(name="MerchantTillMapping.findAll", query="SELECT m FROM MerchantTillMapping m"),
@NamedQuery(name="MerchantTillMapping.findMaxTillIdByHostCode", query="SELECT MAX(m.tillId) FROM MerchantTillMapping m where m.hostCode = :hostCode"),
@NamedQuery(name="MerchantTillMapping.findByMerchantId", query="SELECT m FROM MerchantTillMapping m where m.merchantId = :merchantId")
})
public class MerchantTillMapping implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id", unique=true, nullable=false)
	private Integer id;

	@Column(name="tillDescription", nullable=false, length=50)
	private String tillDescription;

	@Column(name="tillId", nullable=false, length=10)
	private String tillId;

	@Column(name="tillName", nullable=false, length=50)
	private String tillName;
	
	@Basic(optional=false)
	@Column(name="hostCode")
	private Integer hostCode;

	//bi-directional many-to-one association to MerchantInfo
	@ManyToOne
	@JoinColumn(name="merchantId", referencedColumnName = "id")
	private MerchantInfo merchantId;

	public MerchantTillMapping() {
		//empty
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTillDescription() {
		return this.tillDescription;
	}

	public void setTillDescription(String tillDescription) {
		this.tillDescription = tillDescription;
	}

	public String getTillId() {
		return this.tillId;
	}

	public void setTillId(String tillId) {
		this.tillId = tillId;
	}

	public String getTillName() {
		return this.tillName;
	}

	public void setTillName(String tillName) {
		this.tillName = tillName;
	}

	public MerchantInfo getMerchantId() {
		return this.merchantId;
	}

	public void setMerchantId(MerchantInfo merchantId) {
		this.merchantId = merchantId;
	}
	
	public Integer getHostCode() {
		return hostCode;
	}

	public void setHostCode(Integer hostCode) {
		this.hostCode = hostCode;
	}

}