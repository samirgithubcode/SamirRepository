/**
 * 
 */
package com.ng.pnb.bridge.invoker;

import java.util.Date;

import org.jpos.iso.ISOMsg;
import org.jpos.iso.ISOPackager;
import org.jpos.iso.packager.XMLPackager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.ng.base.invoker.IThirdPartyInvoker;
import com.ng.base.invoker.impl.ThirdPartyInvoker;
import com.ng.pnb.bridge.service.ISocketService;
import com.ng.pnb.bridge.service.ITransactionService;
import com.ng.pnb.bridge.service.impl.SocketService;
import com.ng.sb.common.dataobject.BridgeDataObject;
import com.ng.sb.common.model.CustomerDetails;
import com.ng.sb.common.util.KeyEncryptionUtils;
import com.ng.sb.common.util.SystemConstant;

/**
 * @author gopal
 *
 */
@Service(value=SystemConstant.OROMIA_INVOKER)
public class OromiaInvoker extends ThirdPartyInvoker implements IThirdPartyInvoker {

	@Qualifier("oromiaService")
	@Autowired
	ITransactionService transactionService;
	
	@Override
	public BridgeDataObject deductAmountThruBankDirect(BridgeDataObject bridgeDataObject) 
	{
		return null;
	}

	@Override
	public BridgeDataObject createPINFSP(BridgeDataObject bridgeDataObject)
	{
		transactionService.processRequest(bridgeDataObject);
		
		return bridgeDataObject;
	}
		
	@Override
	public BridgeDataObject changePINFSP(BridgeDataObject bridgeDataObject)
	{
		transactionService.processRequest(bridgeDataObject);
		
		return bridgeDataObject;
	}
	
	@Override
	public BridgeDataObject createWalletPINFSP(BridgeDataObject bridgeDataObject) 
	{
		transactionService.processRequest(bridgeDataObject);
		
		return bridgeDataObject;
	}

	@Override
	public BridgeDataObject changeWalletPINFSP(BridgeDataObject bridgeDataObject) 
	{
		transactionService.processRequest(bridgeDataObject);
		
		return bridgeDataObject;
	}
	
	@Override
	public BridgeDataObject deductAmountThruCreditCardDirect(BridgeDataObject bridgeDataObject) 
	{
		transactionService.processRequest(bridgeDataObject);
		
		return bridgeDataObject;
	}

	@Override
	public BridgeDataObject deductAmountThruIMPSDirect(BridgeDataObject bridgeDataObject) 
	{
		transactionService.processRequest(bridgeDataObject);
		return bridgeDataObject;
	}

	@Override
	public BridgeDataObject deductAmountThruWalletDirect(BridgeDataObject bridgeDataObject) 
	{
		transactionService.processRequest(bridgeDataObject);
		return bridgeDataObject;
	}

	@Override
	public BridgeDataObject addBankAccount(BridgeDataObject bridgeDataObject) 
	{
		transactionService.processRequest(bridgeDataObject);
		return bridgeDataObject;
	}
	
	@Override
	public BridgeDataObject addAmountInBankDirect(BridgeDataObject bridgeDataObject) 
	{
		transactionService.processRequest(bridgeDataObject);
		return bridgeDataObject;
	}

	@Override
	public BridgeDataObject addAmountInCreditCardDirect(BridgeDataObject bridgeDataObject) 
	{
		transactionService.processRequest(bridgeDataObject);
		return bridgeDataObject;
	}

	@Override
	public BridgeDataObject addAmountInIMPSDirect(BridgeDataObject bridgeDataObject) 
	{
		transactionService.processRequest(bridgeDataObject);
		return bridgeDataObject;
	}

	@Override
	public BridgeDataObject addAmountInWalletDirect(BridgeDataObject bridgeDataObject) 
	{
		transactionService.processRequest(bridgeDataObject);
		return bridgeDataObject;
	}

	@Override
	public BridgeDataObject moneyTransferFSP(BridgeDataObject bridgeDataObject) 
	{
		transactionService.processRequest(bridgeDataObject);
		return bridgeDataObject;
	}

	
	@Override
	public BridgeDataObject bankToBankFundTransferFSP(BridgeDataObject bridgeDataObject) 
	{
		transactionService.processRequest(bridgeDataObject);
		return bridgeDataObject;
	}

	@Override
	public BridgeDataObject bankToWalletFundTransferFSP(BridgeDataObject bridgeDataObject) 
	{
		transactionService.processRequest(bridgeDataObject);
		return bridgeDataObject;
	}

	@Override
	public BridgeDataObject bankToIMPSFundTransferFSP(BridgeDataObject bridgeDataObject) 
	{
		transactionService.processRequest(bridgeDataObject);
		return bridgeDataObject;
	}

	@Override
	public BridgeDataObject bankToCreditCardFundTransferFSP(BridgeDataObject bridgeDataObject) 
	{
		transactionService.processRequest(bridgeDataObject);
		return bridgeDataObject;
	}

	@Override
	public BridgeDataObject walletToBankFundTransferFSP(BridgeDataObject bridgeDataObject) 
	{
		transactionService.processRequest(bridgeDataObject);
		return bridgeDataObject;
	}

	@Override
	public BridgeDataObject walletToWalletFundTransferFSP(BridgeDataObject bridgeDataObject) 
	{
		transactionService.processRequest(bridgeDataObject);
		return bridgeDataObject;
	}

	@Override
	public BridgeDataObject walletToIMPSFundTransferFSP(BridgeDataObject bridgeDataObject) 
	{
		transactionService.processRequest(bridgeDataObject);
		return bridgeDataObject;
	}

	@Override
	public BridgeDataObject walletToCreditCardFundTransferFSP(BridgeDataObject bridgeDataObject) 
	{
		transactionService.processRequest(bridgeDataObject);
		return bridgeDataObject;
	}

	@Override
	public BridgeDataObject impsToBankFundTransferFSP(BridgeDataObject bridgeDataObject) 
	{
		transactionService.processRequest(bridgeDataObject);
		return bridgeDataObject;
	}

	@Override
	public BridgeDataObject impsToWalletFundTransferFSP(BridgeDataObject bridgeDataObject) 
	{
		transactionService.processRequest(bridgeDataObject);
		return bridgeDataObject;
	}

	@Override
	public BridgeDataObject impsToIMPSFundTransferFSP(BridgeDataObject bridgeDataObject) 
	{
		transactionService.processRequest(bridgeDataObject);
		return bridgeDataObject;
	}

	@Override
	public BridgeDataObject impsToCreditCardFundTransferFSP(BridgeDataObject bridgeDataObject) 
	{
		transactionService.processRequest(bridgeDataObject);
		return bridgeDataObject;
	}

	@Override
	public BridgeDataObject creditCardToBankFundTransferFSP(BridgeDataObject bridgeDataObject) {
		transactionService.processRequest(bridgeDataObject);
		return bridgeDataObject;
	}

	@Override
	public BridgeDataObject creditCardToWalletFundTransferFSP(BridgeDataObject bridgeDataObject) {
		transactionService.processRequest(bridgeDataObject);
		return bridgeDataObject;
	}

	@Override
	public BridgeDataObject creditCardToIMPSFundTransferFSP(BridgeDataObject bridgeDataObject) {
		transactionService.processRequest(bridgeDataObject);
		return bridgeDataObject;
	}

	@Override
	public BridgeDataObject creditCardToCreditCardFundTransferFSP(BridgeDataObject bridgeDataObject) {
		transactionService.processRequest(bridgeDataObject);
		return bridgeDataObject;
	}

	@Override
	public BridgeDataObject balanceEnquiryFSP(BridgeDataObject bridgeDataObject) 
	{
		transactionService.processRequest(bridgeDataObject);
		return bridgeDataObject;
	}

	

	@Override
	public BridgeDataObject chequeBookRequestFSP(BridgeDataObject bridgeDataObject) 
	{
		transactionService.processRequest(bridgeDataObject);
		return bridgeDataObject;
		
	}

	@Override
	public BridgeDataObject chequeStatusFSP(BridgeDataObject bridgeDataObject) 
	{
		transactionService.processRequest(bridgeDataObject);
		return bridgeDataObject;
	}
	
	@Override
	public BridgeDataObject cancelChequeFSP(BridgeDataObject bridgeDataObject) 
	{
		transactionService.processRequest(bridgeDataObject);
		return bridgeDataObject;
	}
	
	@Override
	public BridgeDataObject addMyPayee(BridgeDataObject bridgeDataObject) {
		transactionService.processRequest(bridgeDataObject);
		return bridgeDataObject;
	}

	@Override
	public BridgeDataObject addMyMerchant(BridgeDataObject bridgeDataObject) {
		transactionService.processRequest(bridgeDataObject);
		return bridgeDataObject;
	}
	
	@Override
	public BridgeDataObject addMyBiller(BridgeDataObject bridgeDataObject) {
		transactionService.processRequest(bridgeDataObject);
		return bridgeDataObject;
	}
	
	@Override
	public BridgeDataObject last5TransactionFSP(BridgeDataObject bridgeDataObject) {
		transactionService.processRequest(bridgeDataObject);
		return bridgeDataObject;
	}

	@Override
	public BridgeDataObject billPaymentToBillerDirect(BridgeDataObject bridgeDataObject) {
		transactionService.processRequest(bridgeDataObject);
		return bridgeDataObject;
	}

	@Override
	public BridgeDataObject billPaymentByWalletFSP(BridgeDataObject bridgeDataObject) {
		transactionService.processRequest(bridgeDataObject);
		return bridgeDataObject;
	}

	@Override
	public BridgeDataObject billPaymentByBankFSP(BridgeDataObject bridgeDataObject) {
		transactionService.processRequest(bridgeDataObject);
		return null;
	}

	@Override
	public BridgeDataObject billPaymentByIMPSFSP(BridgeDataObject bridgeDataObject) {
		transactionService.processRequest(bridgeDataObject);
		return bridgeDataObject;
	}

	@Override
	public BridgeDataObject billPaymentByCreditCardFSP(BridgeDataObject bridgeDataObject) {
		transactionService.processRequest(bridgeDataObject);
		return bridgeDataObject;
	}

	@Override
	public BridgeDataObject topUpRechargeToBillerDirect(BridgeDataObject bridgeDataObject) {
		transactionService.processRequest(bridgeDataObject);
		return bridgeDataObject;
	}

	@Override
	public BridgeDataObject topUpRechargeByWalletFSP(BridgeDataObject bridgeDataObject) {
		transactionService.processRequest(bridgeDataObject);
		return bridgeDataObject;
	}

	@Override
	public BridgeDataObject topUpRechargeByBankFSP(BridgeDataObject bridgeDataObject) {
		transactionService.processRequest(bridgeDataObject);
		return bridgeDataObject;
		
	}

	@Override
	public BridgeDataObject topUpRechargeByIMPSFSP(BridgeDataObject bridgeDataObject) {
		transactionService.processRequest(bridgeDataObject);
		return bridgeDataObject;
		
	}

	@Override
	public BridgeDataObject topUpRechargeByCreditCardFSP(BridgeDataObject bridgeDataObject) {
		transactionService.processRequest(bridgeDataObject);
		return bridgeDataObject;
	}

	@Override
	public BridgeDataObject walletBalanceEnquiryFSP(BridgeDataObject bridgeDataObject) {
		transactionService.processRequest(bridgeDataObject);
		return bridgeDataObject;
	}
	
	public static void main(String[] args) {
		PNBInvoker pnb = new PNBInvoker();
		
		/*BridgeDataObject request = new BridgeDataObject();
		
		TransactionData td = new TransactionData();
		
		td.setTransactionId("766556575675674");
		
		BankAccount ba = new BankAccount();
		
		ba.setAccountId("123456789987643");
		ba.setAccountNumber("898989897667");
		ba.setbPin("1243");
		
		request.setPayerBankAccount(ba);
		request.setTransactionData(td);
		
		BridgeDataObject resp = pnb.balanceEnquiryFSP(request);
		
		System.out.println(resp);*/
		
		ISOPackager packager = null;
		ISOMsg response = null;
		ISOMsg request = null;
		ISocketService socketService = new SocketService();
		try {

			packager = new XMLPackager();
			
			// Create ISO Message
			request = new ISOMsg();
			request.setPackager(packager);
				
			request.setMTI("1204");
				
			
			
			request.set(0, "1204");
			request.set(3, "820000"); //Processing Code
			request.set(4, "0000000000000000");
			
			request.set(11, "004207320085"); // 8 Length Unique Number
			request.set(12, KeyEncryptionUtils.dateToString(new Date(), "yyyyMMddHHmmss"));
			request.set(17, KeyEncryptionUtils.dateToString(new Date(), "yyyyMMdd"));
			request.set(24, "200");
			
			request.set(32, "504511");
			
			request.set(34, "44232015"); // 8 Length Unique Number
			
			request.set(41, "BANKAWAY"); // 8 Length Unique Number
			request.set(42, "BANKAWAY"); // External Number
			
			request.set(49, "INR");
			
			request.set(102, "44232015");
			request.set(123, "CNN");
			
			response = socketService.submitNGetResponse(request);
			
			if(response != null)
			{
				CustomerDetails customerDetails = new CustomerDetails();
				
			   String field48 = response.getString(48);
			   String field125 = response.getString(125);
			   
			   String field48Data[] = field48.split("\\+");
			   
			   String cardNumber = field48Data[1].split("-")[0];
			   String accountNumber = field48Data[1].split("-")[1];
			   
			   customerDetails.setCardNumber(Long.parseLong(cardNumber));
			   customerDetails.setAccountNumber(accountNumber);
			   
			   if(field125 != null)
			   {
				   String customerId = field125.substring(0, 9);
				   String customerName = field125.substring(9, (9+80));
				   String accountName =  field125.substring((9+80), (9+80+80));
				   String accountOpenDate = field125.substring((9+80+80), (9+80+80+8));
				   String schemeCode = field125.substring((9+80+80+8), (9+80+80+8+5));
				   String accountType = field125.substring((9+80+80+8+5), (9+80+80+8+5+3));
				   String accountStatus = field125.substring((9+80+80+8+5+3), (9+80+80+8+5+3+1));
				   String operationCode = field125.substring((9+80+80+8+5+3+1), (9+80+80+8+5+3+1+5));
				   String jointHolder1 = field125.substring((9+80+80+8+5+3+1+5), (9+80+80+8+5+3+1+5+80));
				   String jointHolder2 = field125.substring((9+80+80+8+5+3+1+5+80), (9+80+80+8+5+3+1+5+80+80));
				   String jointHolder3 = field125.substring((9+80+80+8+5+3+1+5+80+80), (9+80+80+8+5+3+1+5+80+80+80));
				   String subHeadCode = field125.substring((9+80+80+8+5+3+1+5+80+80+80), (9+80+80+8+5+3+1+5+80+80+80+5));
				   String accountSolId = field125.substring((9+80+80+8+5+3+1+5+80+80+80+5), (9+80+80+8+5+3+1+5+80+80+80+5+8));
				   String drawingPower = field125.substring((9+80+80+8+5+3+1+5+80+80+80+5+8), (9+80+80+8+5+3+1+5+80+80+80+5+8+17));
				   String lienAmount = field125.substring((9+80+80+8+5+3+1+5+80+80+80+5+8+17), (9+80+80+8+5+3+1+5+80+80+80+5+8+17+17));
				   
				   customerDetails.setCustomerId(customerId.trim());
				   customerDetails.setCustomerName(customerName.trim());
				   customerDetails.setAccountName(accountName.trim());
				 //  customerDetails.setAccountOpenDate(KeyEncryptionUtils.StringToDate(accountOpenDate, "yyyyMMdd"));
				   customerDetails.setSchemeCode(schemeCode.trim());
				   customerDetails.setAccountType(accountType.trim());
				   customerDetails.setAccountStatus(accountStatus.trim());
				   customerDetails.setOperationCode(operationCode.trim());
				   customerDetails.setJointHolderName1(jointHolder1.trim());
				   customerDetails.setJointHolderName2(jointHolder2.trim());
				   customerDetails.setJointHolderName3(jointHolder3.trim());
				   customerDetails.setSubHeadCode(subHeadCode.trim());
				   customerDetails.setAccountSoleId(accountSolId.trim());
				   customerDetails.setDrawingPower(drawingPower.trim());
				   customerDetails.setLienAmount(lienAmount);
				   
				   //ResponseObject resp = transactionService.addCustomerDetails(customerDetails);
				   
				   System.out.println(customerDetails);
			   }
			}
			
			
	}catch(Exception e)
		{
		 e.printStackTrace();
		}
		
	}
	
}