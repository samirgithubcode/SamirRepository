/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Himanshu
 */
@Entity
@Table(name = "PortalRegistration")
@XmlRootElement
@NamedQueries({
	 @NamedQuery(name = "PortalRegistration.findAll", query = "SELECT p FROM PortalRegistration p"),
	 @NamedQuery(name = "PortalRegistration.findById", query = "SELECT p FROM PortalRegistration p WHERE p.id = :id"),
	 @NamedQuery(name = "PortalRegistration.findByPortalRefId", query = "SELECT p FROM PortalRegistration p WHERE p.portalRefId = :portalrefid"),
	 @NamedQuery(name = "PortalRegistration.findByKey", query = "SELECT p FROM PortalRegistration p WHERE p.desKey = :key"),
	 @NamedQuery(name = "PortalRegistration.findByCompanyName", query = "SELECT p FROM PortalRegistration p WHERE p.companyName = :companyName"),
	 @NamedQuery(name = "PortalRegistration.findCountByKey", query = "SELECT count(p) FROM PortalRegistration p WHERE p.desKey = :key"),
})
public class PortalRegistration implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
   
    
    @Column(name = "portal_ref_id")
    private String portalRefId;
    
    @Basic(optional = false)
    @Column(name = "status")
    private boolean status;
    @Column(name = "houseNo_Street")
    private String houseNoStreet;
    @Column(name = "city")
    private String city;
    @Column(name = "landMark")
    private String landMark;
    @Basic(optional = false)
    @Column(name = "company_name")
    private String companyName;
	@Column(name = "contactName")
    private String contactName;
	@Column(name = "email")
    private String email;
	@Column(name = "contactNumber1")
    private String contactNumber1;
	@Column(name = "contactNumber2")
    private String contactNumber2;
	@Column(name = "contactNumber3")
    private String contactNumber3;
	
	@Column(name="callBackUrl")
	private String callBackUrl;
	
	@Column(name = "3des_key")
    private String desKey;
	
    @Column(name = "pincode")
    private Integer pincode;
    @Basic(optional = false)
    @Column(name = "create_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createDate;
    @Column(name = "edit_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date editDate;
    

	@Column(name = "country")
    private String country;
    @Column(name = "state")
    private String state;
    @Column(name = "createdBy")
    private Integer createdBy;
    @Column(name = "createdBycompanyId")
    private Integer createdByCompanyId;
    
    
    @Column(name = "filePath")
    private String filePath;
    
    
	public String getFilePath() {
		return filePath;
	}


	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}


	public Integer getCreatedBy() {
		return createdBy;
	}

	
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	
	public Integer getCreatedByCompanyId() {
		return createdByCompanyId;
	}

	
	public void setCreatedByCompanyId(Integer createdByCompanyId) {
		this.createdByCompanyId = createdByCompanyId;
	}
	@JoinColumn(name = "commission_product_id", referencedColumnName = "id")
    @ManyToOne
    private CommissionProduct productCommissionId;
   
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "portalId", fetch=FetchType.EAGER)
    private List<PortalUrls> portalUrlsCollection;
	
    
	public PortalRegistration() {
		//empty
    }

    public PortalRegistration(Integer id) {
        this.id = id;
    }

    public PortalRegistration(Integer id, boolean status, String companyName, Date createDate) {
        this.id = id;
        this.status = status;
        this.companyName = companyName;
        this.createDate = createDate;
    }
	
	
	public String getContactName() {
		return contactName;
	}

	public void setContactName(String contactName) {
		this.contactName = contactName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public CommissionProduct getProductCommissionId() {
		return productCommissionId;
	}

	public void setProductCommissionId(CommissionProduct productCommissionId) {
		this.productCommissionId = productCommissionId;
	}

	
	public String getContactNumber1() {
		return contactNumber1;
	}

	public void setContactNumber1(String contactNumber1) {
		this.contactNumber1 = contactNumber1;
	}

	public String getContactNumber2() {
		return contactNumber2;
	}

	public void setContactNumber2(String contactNumber2) {
		this.contactNumber2 = contactNumber2;
	}

	public String getContactNumber3() {
		return contactNumber3;
	}

	public void setContactNumber3(String contactNumber3) {
		this.contactNumber3 = contactNumber3;
	}
	public List<PortalUrls> getPortalUrlsCollection() {
		return portalUrlsCollection;
	}

	public void setPortalUrlsCollection(List<PortalUrls> portalUrlsCollection) {
		this.portalUrlsCollection = portalUrlsCollection;
	}


    public String getPortalRefId() {
		return portalRefId;
	}

	public void setPortalRefId(String portalRefId) {
		this.portalRefId = portalRefId;
	}

	public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public boolean getStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public String getHouseNoStreet() {
        return houseNoStreet;
    }

    public void setHouseNoStreet(String houseNoStreet) {
        this.houseNoStreet = houseNoStreet;
    }

    public String getLandMark() {
        return landMark;
    }

    public void setLandMark(String landMark) {
        this.landMark = landMark;
    }
    
    public Integer getPincode() {
        return pincode;
    }

    public void setPincode(Integer pincode) {
        this.pincode = pincode;
    }
  
    public String getDesKey() {
        return desKey;
    }

    public void setDesKey(String desKey) {
        this.desKey = desKey;
    }
    
    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }
    
    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

 
    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getEditDate() {
        return editDate;
    }

    public void setEditDate(Date editDate) {
        this.editDate = editDate;
    }

    

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }
    
    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCallBackUrl() {
		return callBackUrl;
	}

	public void setCallBackUrl(String callBackUrl) {
		this.callBackUrl = callBackUrl;
	}

	@Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
    	boolean check=true;
    	if(object!=null){
        if (!(object instanceof PortalRegistration)) {
        	check= false;
        }
        PortalRegistration other = (PortalRegistration) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
    	}
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.PortalRegistration[ id=" + id + " ]";
    }
    
}
