/**
 * 
 */
package com.ng.transaction.service.impl;

import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ng.sb.common.dataobject.HostSubVersionData;
import com.ng.transaction.service.ICacheFill;

/**
 * @author gaurav
 * For Loading Cache DS
 */
@Service
public class CacheLoader {
	
	@Autowired
	ICacheFill cacheFill;
	
	private Map<HostSubVersionData,HostSubVersionData> hostSubVersionMap;
	
	

	public Map<HostSubVersionData, HostSubVersionData> getHostSubVersionMap() {
		return hostSubVersionMap;
	}



	@PostConstruct
	public void init(){
		try {
			this.hostSubVersionMap=cacheFill.getHostSubVersionMap();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
