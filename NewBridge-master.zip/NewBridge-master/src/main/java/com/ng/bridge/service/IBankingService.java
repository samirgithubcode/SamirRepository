/**
 * 
 */
package com.ng.bridge.service;

import com.ng.sb.common.dataobject.BridgeDataObject;

/**
 * @author gaurav
 *
 */
public interface IBankingService extends IFundTransferMgtService {
	// Source is Bank
	public BridgeDataObject fundTransferBankToBank(BridgeDataObject bridgeDataObject);
	public BridgeDataObject fundTransferBankToCC(BridgeDataObject bridgeDataObject);
	public BridgeDataObject fundTransferBankToIMPS(BridgeDataObject bridgeDataObject);
	public BridgeDataObject fundTransferBankToWallet(BridgeDataObject bridgeDataObject);
	
	// Source is IMPS
	public BridgeDataObject fundTransferIMPSToBank(BridgeDataObject bridgeDataObject);
	public BridgeDataObject fundTransferIMPSToIMPS(BridgeDataObject bridgeDataObject);
	public BridgeDataObject fundTransferIMPSToCC(BridgeDataObject bridgeDataObject);
	public BridgeDataObject fundTransferIMPSToWallet(BridgeDataObject bridgeDataObject);
	
	// Source is CreditCard
	public BridgeDataObject fundTransferCCToBank(BridgeDataObject bridgeDataObject);
	public BridgeDataObject fundTransferCCToIMPS(BridgeDataObject bridgeDataObject);
	public BridgeDataObject fundTransferCCToCC(BridgeDataObject bridgeDataObject);
	public BridgeDataObject fundTransferCCToWallet(BridgeDataObject bridgeDataObject);
	
	
	
	
	public BridgeDataObject cashWithdraw(BridgeDataObject bridgeDataObject);
	
	// FOR OXIGEN
	public BridgeDataObject moneyTransfer(BridgeDataObject bridgeDataObject);
	
}
