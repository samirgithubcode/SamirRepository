/**
 * 
 */
package com.ng.pnb.bridge.invoker;

import java.util.Map;

import org.jpos.iso.ISOException;
import org.jpos.iso.ISOUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ng.pnb.invoker.util.ChequeStatus;
import com.ng.pnb.invoker.util.PnbConstants;
import com.ng.pnb.invoker.util.PropertyHolder;
import com.ng.sb.common.dataobject.BridgeDataObject;
import com.ng.sb.common.dataobject.BridgeDataResponse;
import com.ng.sb.common.dataobject.BridgeDataResponse.Status;

/**
 * @author gopal
 *
 */
@Service(value="pnbUtility")
public class PNBUtility {

	private static final Logger LOGGER = LoggerFactory.getLogger(PNBUtility.class);
	
	@Autowired
	PropertyHolder propertyHolder;
	
	enum CallType{
		B2BFSP, //Bank to Bank Full Service Partner
		BIFSP, //Balance Enquiry Full Service Partner
		MSFSP //Mini Statement Full Service Partner
	}
	private void createResponse(BridgeDataObject bridgeDataObject,Map<Integer,String> isoMap,CallType callType)
	{
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In PNBUtility -  createResponse method. ");
		BridgeDataResponse response = new BridgeDataResponse();
		response.setMsidnToSendMsg(bridgeDataObject.getTransactionData().getMsisdn());
		bridgeDataObject.setBridgeResponse(response);
		String maskedAccountNum= getMaskedAccountNumber(bridgeDataObject.getPayerBankAccount().getAccountNumber());
		Integer respCode = 0;
		if(!isoMap.get(39).isEmpty()){
			respCode=Integer.parseInt(isoMap.get(39));
		}
		if(callType==CallType.B2BFSP||callType==CallType.MSFSP && respCode==0){
			response.setResponseMsg(PnbConstants.AC + maskedAccountNum + "  has been debited successfully with ETB "+ bridgeDataObject.getAmount());
		}
		else if(callType==CallType.BIFSP && respCode==0)
		{
				//Integer amt=isoMap.get(4)==null?0:Integer.valueOf(isoMap.get(4));
				
				String data = isoMap.get(48);
				
				String[] spillted = data.substring(1).split("\\+");
				
				response.setResponseMsg(PnbConstants.AC + maskedAccountNum + "  has balance of ETB "+ spillted[0]);
		}
		
		setResponseMessage(respCode,response);
		
	}
	
	
	public void createBankToBankFSPResponse(BridgeDataObject bridgeDataObject,Map<Integer,String> isoMap){
		createResponse(bridgeDataObject, isoMap, CallType.B2BFSP);
	}
	
	private void setResponseMessage(Integer respCode,BridgeDataResponse response){
		if(respCode==116)
		{
			response.setResponseMsg("Sorry, insufficient funds in your a/c. Please add funds and retry");
		}
		else if(respCode==121 || respCode==180){
			response.setResponseMsg("Sorry, amount exceeded daily limit for transaction. Please update your daily limits");
		}
		else if(respCode==184){
			response.setResponseMsg("Sorry, a/c is frozen/closed. Please contact your bank branch");
		}
		else if(respCode==185){
			response.setResponseMsg("Sorry, Invalid transaction amount");
		}else if(respCode==913){
			response.setResponseMsg("Sorry, Error at the bank for processing this request. Please contact the bank branch");
		}else{
			if(response.getResponseMsg() == null)
				response.setResponseMsg(PnbConstants.MSG);
		}
	}
	
	
	public void createBalanceEnquiryFSPResponse(BridgeDataObject bridgeDataObject,Map<Integer,String> isoMap)
	{
		if(propertyHolder.getDeploymentFor().equalsIgnoreCase(PnbConstants.DEPLOYED_FOR))
		{
			createResponse(bridgeDataObject, isoMap, CallType.BIFSP);
		}else{
	
			BridgeDataResponse response = new BridgeDataResponse();
			response.setMsidnToSendMsg(bridgeDataObject.getTransactionData().getMsisdn());
			
			String balanceResponse = isoMap.get(54);
			if(balanceResponse != null && balanceResponse.length() > 28)
			{
				String balance = balanceResponse.substring(28);
				
				String maskedAccountNum= getMaskedAccountNumber(bridgeDataObject.getPayerWallet().getAccountNumber());
				
				response.setResponseMsg("Your wallet " + maskedAccountNum + "  has balance of ETB "+ balance);
				
				bridgeDataObject.setBridgeResponse(response);
			}
			
		}
	}
	
	public void createWalletFundTransferFSPResponse(BridgeDataObject bridgeDataObject,Map<Integer,String> isoMap)
	{
			BridgeDataResponse response = new BridgeDataResponse();
			response.setMsidnToSendMsg(bridgeDataObject.getTransactionData().getMsisdn());
			
			String balanceResponse = isoMap.get(54);
			String txnId = isoMap.get(38);
			
			if(balanceResponse != null && balanceResponse.length() > 28)
			{
				String balance = balanceResponse.substring(28);
				
				String maskedAccountNum= getMaskedAccountNumber(bridgeDataObject.getPayeeWallet().getMsisdn());
				
				response.setResponseMsg("Fund transfer to " + maskedAccountNum + " processed suscessfully txn Id "+txnId+", updated balance ETB "+ balance);
				
				bridgeDataObject.setBridgeResponse(response);
			}
		
	}
	
	
	public void createWalletBillPaymentFSPResponse(BridgeDataObject bridgeDataObject,Map<Integer,String> isoMap, String providerName)
	{
			BridgeDataResponse response = new BridgeDataResponse();
			response.setMsidnToSendMsg(bridgeDataObject.getTransactionData().getMsisdn());
			
			String balanceResponse = isoMap.get(54);
			String txnId = isoMap.get(38);
			
			if(balanceResponse != null && balanceResponse.length() > 28)
			{
				String balance = balanceResponse.substring(28);
				
				//String maskedAccountNum= getMaskedAccountNumber(bridgeDataObject.getPayeeWallet().getMsisdn());
				
				response.setResponseMsg("Your " + providerName + " bill payment for "+bridgeDataObject.getProvider().getSubscriberId()+" done successfully,your current balance ETB "+ balance);
				
				bridgeDataObject.setBridgeResponse(response);
			}
		
	}
	
	public void createChequeStatusFSPResponse(BridgeDataObject bridgeDataObject,Map<Integer,String> isoMap)
	{
		BridgeDataResponse response = new BridgeDataResponse();
		response.setMsidnToSendMsg(bridgeDataObject.getTransactionData().getMsisdn());
		bridgeDataObject.setBridgeResponse(response);
		
		Integer respCode = 0;
		
		if(!isoMap.get(39).isEmpty())
		{
			respCode=Integer.parseInt(isoMap.get(39));
		}
		
		
				try {
					//Integer amt=isoMap.get(4)==null?0:Integer.valueOf(isoMap.get(4));
					
					String data = isoMap.get(125);
					
					ChequeStatus chequeStatus = ChequeStatus.getChequeStatusByCode(data);
					response.setResponseMsg("Current status of your cheque number : "+ ISOUtil.padleft(bridgeDataObject.getCheque().getChequeNumber().toString(), 6, '0')+" is - "+chequeStatus.getStatusMessage());
					
				} catch (ISOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		
		setResponseMessage(respCode,response);
	}
	
	public void createMiniStatementFSPResponse(BridgeDataObject bridgeDataObject,Map<Integer,String> isoMap)
	{
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In PNBUtility -  createMiniStatementFSPResponse method. ");
		
		BridgeDataResponse response = new BridgeDataResponse();
		response.setMsidnToSendMsg(bridgeDataObject.getTransactionData().getMsisdn());
		bridgeDataObject.setBridgeResponse(response);
		
		Integer respCode = 0;
		if(!isoMap.get(39).isEmpty()){
			respCode=Integer.parseInt(isoMap.get(39));
		}
		
		String txnData = isoMap.get(125);
		
		 
				String data = isoMap.get(48);
				
				String[] spillted = data.substring(1).split("\\+");
				
				response.setResponseMsg(txnData);
		
				response.setStatus(Status.SUCCESS);
		setResponseMessage(respCode,response);
	}
	
	public void createErrorResponse(BridgeDataObject bridgeDataObject)
	{
		BridgeDataResponse response = new BridgeDataResponse();
		response.setResponseMsg("Sorry, System is under maintenance, please try after some time");
		response.setMsidnToSendMsg(bridgeDataObject.getTransactionData().getMsisdn());
		bridgeDataObject.setBridgeResponse(response);
	}
	
	public void createErrorResponse(BridgeDataObject bridgeDataObject, Integer respCode)
	{
		BridgeDataResponse response = new BridgeDataResponse();
		
		response.setMsidnToSendMsg(bridgeDataObject.getTransactionData().getMsisdn());
		bridgeDataObject.setBridgeResponse(response);
		
		
		if(respCode==116)
		{
			response.setResponseMsg("Sorry, insufficient funds in your a/c. Please add funds and retry");
		}
		else if(respCode==121 || respCode==180){
			response.setResponseMsg("Sorry, amount exceeded daily limit for transaction. Please update your daily limits");
		}
		else if(respCode==184){
			response.setResponseMsg("Sorry, a/c is frozen/closed. Please contact your bank branch");
		}
		else if(respCode==185){
			response.setResponseMsg("Sorry, Invalid transaction amount");
		}else if(respCode==913){
			response.setResponseMsg("Sorry, Error at the bank for processing this request. Please contact the bank branch");
		}else if(respCode==14)
		{
			response.setResponseMsg("Sorry, invalid request data. Please retry with correct data.");
		}else {
			if(response.getResponseMsg() == null)
				response.setResponseMsg(PnbConstants.MSG);
		}
	}
	
	public void createErrorResponse(BridgeDataObject bridgeDataObject, String errorMessage){
		BridgeDataResponse response = new BridgeDataResponse();
		
		response.setStatus(Status.SUCCESS);
		response.setResponseMsg(errorMessage);
		response.setMsidnToSendMsg(bridgeDataObject.getTransactionData().getMsisdn());
		
		bridgeDataObject.setBridgeResponse(response);
	}
	
	public String getMaskedAccountNumber(String acNo){
		String acNoToSend="";
		if(acNo==null){
			LOGGER.info(""+acNo);
		}
		if(acNo!=null && !acNo.isEmpty() && acNo.length()>=4){
			String endAcNo = acNo.substring(acNo.length()-4, acNo.length());
			String initialAcNo="";
			for(int i=0;i<acNo.length()-4;i++){
					initialAcNo=initialAcNo+"X";	
			}
			acNoToSend=initialAcNo+endAcNo;
		}
		
		if(acNo!=null && acNo.length()<4){
			acNoToSend=acNo;
		}
		return acNoToSend;
	}
	
	public String getCurrentBalanceFromDebitCreditResponse(String responseString)
	{
		//+0000000000100000+0000000000100000+0000000000000000+0000000000000000+0000000000000000INR
		String result = null;
		
		try {
			String[] resultData = responseString.split("\\+");
			
			Integer amount = Integer.parseInt(resultData[1]);
			
			result = amount.toString();
			
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
	}
}