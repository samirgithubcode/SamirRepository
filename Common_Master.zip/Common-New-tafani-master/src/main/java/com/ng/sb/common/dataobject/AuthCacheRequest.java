/**
 * 
 */
package com.ng.sb.common.dataobject;

/**
 * @author gopal
 *
 */
public class AuthCacheRequest implements ValidationBean {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8797525218055311487L;

	private String actionUrl ;
	
	private String tokenId;
	
	private String accountTypeIds;
	
	private String actionType;
	
	public String getTokenId() {
		return tokenId;
	}

	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}

	public String getActionUrl() {
		return actionUrl;
	}

	public void setActionUrl(String actionUrl) {
		this.actionUrl = actionUrl;
	}

	public String getAccountTypeIds() {
		return accountTypeIds;
	}

	public void setAccountTypeIds(String accountTypeIds) {
		this.accountTypeIds = accountTypeIds;
	}

	public String getActionType() {
		return actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}
	
	
}
