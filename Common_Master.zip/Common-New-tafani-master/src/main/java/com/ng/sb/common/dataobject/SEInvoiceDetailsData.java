package com.ng.sb.common.dataobject;

import java.util.Map;

public class SEInvoiceDetailsData {

	private Integer productId;
	private Map<Integer,String> productMap;
	
	private Integer mvId;
	private Map<Integer,String> mvMap;
	
	private Integer boxId;
	private Map<Integer,String> boxMap;
	
	private Integer totalBoxes; 
	private Integer totalElements;
	private String extNumFrom;
	private String extNumTo;
	private boolean chk;
	/**
	 * @return the productId
	 */
	public Integer getProductId() {
		return productId;
	}
	/**
	 * @param productId the productId to set
	 */
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	/**
	 * @return the productMap
	 */
	public Map<Integer, String> getProductMap() {
		return productMap;
	}
	/**
	 * @param productMap the productMap to set
	 */
	public void setProductMap(Map<Integer, String> productMap) {
		this.productMap = productMap;
	}
	/**
	 * @return the mvId
	 */
	public Integer getMvId() {
		return mvId;
	}
	/**
	 * @param mvId the mvId to set
	 */
	public void setMvId(Integer mvId) {
		this.mvId = mvId;
	}
	/**
	 * @return the mvMap
	 */
	public Map<Integer, String> getMvMap() {
		return mvMap;
	}
	/**
	 * @param mvMap the mvMap to set
	 */
	public void setMvMap(Map<Integer, String> mvMap) {
		this.mvMap = mvMap;
	}
	/**
	 * @return the boxId
	 */
	public Integer getBoxId() {
		return boxId;
	}
	/**
	 * @param boxId the boxId to set
	 */
	public void setBoxId(Integer boxId) {
		this.boxId = boxId;
	}
	/**
	 * @return the boxMap
	 */
	public Map<Integer, String> getBoxMap() {
		return boxMap;
	}
	/**
	 * @param boxMap the boxMap to set
	 */
	public void setBoxMap(Map<Integer, String> boxMap) {
		this.boxMap = boxMap;
	}
	/**
	 * @return the totalBoxes
	 */
	public Integer getTotalBoxes() {
		return totalBoxes;
	}
	/**
	 * @param totalBoxes the totalBoxes to set
	 */
	public void setTotalBoxes(Integer totalBoxes) {
		this.totalBoxes = totalBoxes;
	}
	/**
	 * @return the totalElements
	 */
	public Integer getTotalElements() {
		return totalElements;
	}
	/**
	 * @param totalElements the totalElements to set
	 */
	public void setTotalElements(Integer totalElements) {
		this.totalElements = totalElements;
	}
	/**
	 * @return the extNumFrom
	 */
	public String getExtNumFrom() {
		return extNumFrom;
	}
	/**
	 * @param extNumFrom the extNumFrom to set
	 */
	public void setExtNumFrom(String extNumFrom) {
		this.extNumFrom = extNumFrom;
	}
	/**
	 * @return the extNumTo
	 */
	public String getExtNumTo() {
		return extNumTo;
	}
	/**
	 * @param extNumTo the extNumTo to set
	 */
	public void setExtNumTo(String extNumTo) {
		this.extNumTo = extNumTo;
	}
	/**
	 * @return the chk
	 */
	public boolean isChk() {
		return chk;
	}
	/**
	 * @param chk the chk to set
	 */
	public void setChk(boolean chk) {
		this.chk = chk;
	}
	
	
}
