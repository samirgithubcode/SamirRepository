package com.ng.sb.common.dataobject;

import java.io.Serializable;

public class SEIssuanceVerificationData implements Serializable{

	private static final long serialVersionUID = 391207483400742171L;
	
	private String msisdn;
	private String externalICCDNumber;
	private String internalICCDNumber;
	private String hostSTKVersion;
	private String customerType;
	private String statusCode;
	
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getCustomerType() {
		return customerType;
	}
	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public String getExternalICCDNumber() {
		return externalICCDNumber;
	}
	public void setExternalICCDNumber(String externalICCDNumber) {
		this.externalICCDNumber = externalICCDNumber;
	}
	public String getInternalICCDNumber() {
		return internalICCDNumber;
	}
	public void setInternalICCDNumber(String internalICCDNumber) {
		this.internalICCDNumber = internalICCDNumber;
	}
	public String getHostSTKVersion() {
		return hostSTKVersion;
	}
	public void setHostSTKVersion(String hostSTKVersion) {
		this.hostSTKVersion = hostSTKVersion;
	}
}
