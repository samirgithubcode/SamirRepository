/**
 * 
 */
package com.ng.sb.common.dataobject;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author gaurav
 *
 */
@XmlRootElement(name = "WalletResponseData")
public class WalletResponseData extends PlatformResponseData{
	private static final long serialVersionUID = 1L;
	private PortalParams portalParams;
	private String transactionId;
	private CustomerData customerData;
	private String testOTP;
	private Integer customerWalletBalance;
	public PortalParams getPortalParams() {
		return portalParams;
	}
	public void setPortalParams(PortalParams portalParams) {
		this.portalParams = portalParams;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public CustomerData getCustomerData() {
		return customerData;
	}
	public void setCustomerData(CustomerData customerData) {
		this.customerData = customerData;
	}
	public String getTestOTP() {
		return testOTP;
	}
	public void setTestOTP(String testOTP) {
		this.testOTP = testOTP;
	}
	public Integer getCustomerWalletBalance() {
		return customerWalletBalance;
	}
	public void setCustomerWalletBalance(Integer customerWalletBalance) {
		this.customerWalletBalance = customerWalletBalance;
	}

}
