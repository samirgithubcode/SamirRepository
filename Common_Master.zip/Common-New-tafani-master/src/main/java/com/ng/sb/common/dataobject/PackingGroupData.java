package com.ng.sb.common.dataobject;

import java.util.Map;

public class PackingGroupData extends BaseObjectData{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String groupName; 
	private Map<Integer,String> parentDataList;
	private Integer parentType;
	private Integer quantity;
	private Integer totalquantity;
	private String status;
	private String parentName;
	private String productType;
	private Integer noOfBox;
	private int levelNumber;
	public int getLevelNumber() {
		return levelNumber;
	}
	public void setLevelNumber(Integer levelNumber) {
		this.levelNumber = levelNumber;
	}
	public Integer getTotalquantity() {
		return totalquantity;
	}
	public void setTotalquantity(Integer totalquantity) {
		this.totalquantity = totalquantity;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Integer getNoOfBox() {
		return noOfBox;
	}
	public void setNoOfBox(Integer noOfBox) {
		this.noOfBox = noOfBox;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public String getParentName() {
		return parentName;
	}
	public void setParentName(String parentName) {
		this.parentName = parentName;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public Map<Integer, String> getParentDataList() {
		return parentDataList;
	}
	public void setParentDataList(Map<Integer, String> parentDataList) {
		this.parentDataList = parentDataList;
	}
	public Integer getParentType() {
		return parentType;
	}
	public void setParentType(Integer parentType) {
		this.parentType = parentType;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
}
