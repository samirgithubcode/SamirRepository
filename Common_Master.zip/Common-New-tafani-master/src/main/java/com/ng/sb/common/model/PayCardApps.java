/**
 * 
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.ng.sb.common.util.CustomJsonDateSerializer;

/**
 * @author gopal
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true, value = {"primaryKey", "value", "productId" })
@Entity
@Table(name = "paycard_app")
@NamedQueries({
				@NamedQuery(name="PayCardApps.findAll", query="SELECT p FROM PayCardApps p"),
				@NamedQuery(name="PayCardApps.findById", query="SELECT p FROM PayCardApps p WHERE p.id = :id"),
				@NamedQuery(name="PayCardApps.findByOrder", query="SELECT p FROM PayCardApps p order by p.appStatus desc, p.payCardAppName"),
				@NamedQuery(name = "PayCardApps.getByProductId", query = "select payCardApps from PayCardApps payCardApps WHERE payCardApps.productId=:productId"),
				@NamedQuery(name = "PayCardApps.getByCardIdAppName", query = "select payCardApps from PayCardApps payCardApps WHERE payCardApps.payCardAppName=:appName"),
				@NamedQuery(name = "PayCardApps.getActiveApps", query = "select payCardApps from PayCardApps payCardApps WHERE CURRENT_DATE between payCardApps.startDate and payCardApps.endDate and payCardApps.appStatus=1 order by payCardApps.primaryApp desc ")
				
})
public class PayCardApps implements Serializable {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4762969190625069108L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "id")
	private Integer id;
	
	@Column(name = "product_id")
	private Integer productId;
	
	@Column(name = "paycard_app_name")	
	private String payCardAppName;
	
	@Column(name = "paycard_app_description")
	private String payCardDescription;
	
	@JsonSerialize(using = CustomJsonDateSerializer.class)
	@Column(name = "start_date")
	private Date startDate;
	
	@JsonSerialize(using = CustomJsonDateSerializer.class)
	@Column(name = "end_date")
	private Date endDate;
	
	@Column(name = "status")
	private Boolean appStatus;
	
	@Column(name = "isDefault")
	private Boolean primaryApp;
	
	@Column(name = "Amount")
	private int amount;
	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL, mappedBy = "payCardAppId")
    private Collection<PayCardAppPartner> partnerCollection;
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "appId")
    private Collection<CardApps> cardApps;
	
	public PayCardApps(){
		//default
	}
	
	public PayCardApps(Integer id) {
	        this.id = id;
	    }
	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}



	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public String getPayCardAppName() {
		return payCardAppName;
	}

	public void setPayCardAppName(String payCardAppName) {
		this.payCardAppName = payCardAppName;
	}

	public String getPayCardDescription() {
		return payCardDescription;
	}

	public void setPayCardDescription(String payCardDescription) {
		this.payCardDescription = payCardDescription;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Boolean getAppStatus() {
		return appStatus;
	}

	public void setAppStatus(Boolean appStatus) {
		this.appStatus = appStatus;
	}

	public Collection<PayCardAppPartner> getPartnerCollection() {
		return partnerCollection;
	}

	public void setPartnerCollection(Collection<PayCardAppPartner> partnerCollection) {
		this.partnerCollection = partnerCollection;
	}

	public Boolean getPrimaryApp() {
		return primaryApp;
	}

	public void setPrimaryApp(Boolean primaryApp) {
		this.primaryApp = primaryApp;
	}

	@Override
	public boolean equals(Object object) {
		boolean checkStatus = true;
		if (object != null) {
			if (!(object instanceof PayCardApps)) {
				checkStatus = false;
			}
			PayCardApps other = (PayCardApps) object;
			if ((this.id == null && other.id != null)
					|| (this.id != null && !this.id.equals(other.id))) {
				checkStatus = false;
			}
		}
		return checkStatus;
	}

	@Override
	public int hashCode() {
		int hash = 0;
		hash += (id != null ? id.hashCode() : 0);
		return hash;
	}
}
