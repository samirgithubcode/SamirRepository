package com.ng.sc.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ng.sb.common.dataobject.LoginData;
import com.ng.sb.common.model.Menu;
import com.ng.sb.common.model.Subscriber;
import com.ng.sc.dao.IScLoginDAO;
import com.ng.sc.dao.IScMenuDAO;

@Repository
public class ScMenuDAO extends SelfCareDAO implements IScMenuDAO {
	@Autowired
	IScLoginDAO loginDAO;
	private static final Logger LOGGER = LoggerFactory.getLogger(ScMenuDAO.class);

	@Transactional
	public Menu enterMenuDetails(Menu mainMenu) throws Exception {
		try {
			LOGGER.debug("insert Country Details");
			entityManager.persist(mainMenu);
			return mainMenu;
		} catch (Exception e) {
			LOGGER.debug(" Exception occured in enterMenuDetails() ===>>>" + e);
			return mainMenu;
		}
	}

	@Transactional
	public List<Menu> getRequiredMenu(LoginData loginData) throws Exception {
		Subscriber subscriber = loginDAO.accountByLoginInfo(loginData.getUsername());
		int accountTypeId = subscriber.getId();
		String accountTypeId1 = String.valueOf(accountTypeId);
		List<Menu> menuDetails = new ArrayList<>();
		TypedQuery<Menu> query = null;
		try {
			LOGGER.debug("<*****************   Execution start for getRequiredMenu() *****************>");
			query = entityManager.createNamedQuery("Menu.findById", Menu.class);
			query.setParameter("id", "%," + accountTypeId1 + ",%");
			menuDetails = query.getResultList();
		} catch (Exception ex) {
			LOGGER.debug(" Exception occured in getRequiredMenu() ===>>>" + ex);
		}
		LOGGER.debug("<*****************   Execution End for getRequiredMenu() *****************>");
		return menuDetails;
	}
}
