package com.ng.sb.common.dataobject;

import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


/**
 * @rajiv
 * 
 *  
 */

@XmlAccessorType(XmlAccessType.NONE)
@XmlRootElement (name="responseContent")
public class ProductAndMasterVersionNGData {

	@XmlElement(name="productMap",namespace="productMap")
	private Map<String,List<String>> productMap;
	@XmlElement(name="masterVersionMap",namespace="masterVersionMap")
	private Map<String,List<String>> masterVersionMap;


public Map<String, List<String>> getProductMap() {
	return productMap;
}
public void setProductMap(Map<String, List<String>> productList) {
	this.productMap = productList;
}
public Map<String, List<String>> getMasterVersionMap() {
	return masterVersionMap;
}
public void setMasterVersionMap(Map<String, List<String>> masterVersionMap) {
	this.masterVersionMap = masterVersionMap;
}



}
