package com.ng.sb.common.dataobject;

public class PaymentGatewayResponseObject {
	
	private String randomKey;
	private String url;
	private String message;
	private String refId;
	private String imgsrc;
	private Integer statusCode;
	
	/**
	 * @return the statusCode
	 */
	public Integer getStatusCode() {
		return statusCode;
	}
	/**
	 * @param statusCode the statusCode to set
	 */
	public void setStatusCode(Integer statusCode) {
		this.statusCode = statusCode;
	}
	public synchronized String getImgsrc() {
		return imgsrc;
	}
	public synchronized void setImgsrc(String imgsrc) {
		this.imgsrc = imgsrc;
	}
	public String getRefId() {
		return refId;
	}
	public void setRefId(String refId) {
		this.refId = refId;
	}
	public String getRandomKey() {
		return randomKey;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public void setRandomKey(String randomKey) {
		this.randomKey = randomKey;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	

	

}
