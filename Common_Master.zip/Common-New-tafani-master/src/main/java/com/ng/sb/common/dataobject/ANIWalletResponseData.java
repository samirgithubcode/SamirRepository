package com.ng.sb.common.dataobject;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize.Inclusion;



@XmlRootElement(name = "WalletResponseData")
@XmlAccessorType (XmlAccessType.FIELD)
@XmlSeeAlso(ArrayList.class)
@JsonSerialize(include=Inclusion.NON_NULL)
public class ANIWalletResponseData extends BaseObjectData {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer otp;
	private String custpassword;
	@XmlElement(name = "payload")
	private Object payload;
	
	
	public Object getPayload() {
		return payload;
	}
	
	public void setPayload(Object payload) {
		this.payload = payload;
	}
	
	public Integer getOtp() {
		return otp;
	}
	public String getCustpassword() {
		return custpassword;
	}
	public void setCustpassword(String custpassword) {
		this.custpassword = custpassword;
	}
	public void setOtp(Integer otp) {
		this.otp = otp;
	} 

}
