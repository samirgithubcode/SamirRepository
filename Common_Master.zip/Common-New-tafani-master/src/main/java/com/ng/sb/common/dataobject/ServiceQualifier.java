package com.ng.sb.common.dataobject;

public class ServiceQualifier extends BaseObjectData {
	private static final long serialVersionUID = 1L;
	private String classIdentifier;
	private String methodName;
	public ServiceQualifier(String classIdentifier, String methodName) {
		this.classIdentifier = classIdentifier;
		this.methodName = methodName;
	}



	public String getClassIdentifier() {
		return classIdentifier;
	}

	public void setClassIdentifier(String classIdentifier) {
		this.classIdentifier = classIdentifier;
	}

	public String getMethodName() {
		return methodName;
	}

	public void setMethodName(String methodName) {
		this.methodName = methodName;
	}

}
