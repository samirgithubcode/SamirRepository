package com.ng.sc.utils;


public class ScSystemConstant {

	
	
	public static final String SIGN_UP_PAGE = "UserLoginCreation";
	public static final String LOGIN_PAGE = "login";
	public static final String GROUP_CODE = "SC";
	public static final int LOGIN_ACCOUNT_WEIGHT = 4500;
	public static final int LOGIN_ACCOUNT_ID = 619;
	public static final String ACCT_GRP_CODE_SC = "SC";
	public static final int SYS_ACCT_TYPE_ID = 35;
	public static final String PROFILE_PAGE = "profile";
	public static final String ADDRESS_PAGE = "address";
	public static final String PRODUCT_PAGE = "products";
	
	public static final String HOME_PAGE = "home";
	public static final Integer TIMEOUT = 60;
	public static final String DEPLOYMENTFOR = "tafani";
	public static final String SIGN_UP_PAGE_OTP = "UserLoginCreationOtp";
	public static final String INDEX_PAGE = "index";
	public static final String LOGINDATA = "loginData";
	public static final String SUBSCRIBERDATA="subscriberData";
	public static final String HOMEPAGE="homepage";
	public static final String TOKENID="tokenId";
	public static final String SUBSCRIBERID="subscriberId";
	public static final String LOGINID="loginId";
	private ScSystemConstant(){}
	
}

