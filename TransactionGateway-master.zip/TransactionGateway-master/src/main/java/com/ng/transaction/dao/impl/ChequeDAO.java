/**
 * 
 */
package com.ng.transaction.dao.impl;

import org.springframework.stereotype.Repository;

import com.ng.sb.common.util.SystemConstant;
import com.ng.transaction.dao.IChequeDAO;

/**
 * @author gaurav
 *
 */
@Repository(value=SystemConstant.CHEQUE_DAO)
public class ChequeDAO extends OtherBankingDAO implements IChequeDAO {
	private static final long serialVersionUID = 1L;

}
