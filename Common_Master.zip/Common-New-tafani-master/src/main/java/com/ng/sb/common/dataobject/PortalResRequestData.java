package com.ng.sb.common.dataobject;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="PortalResRequestData")
public class PortalResRequestData extends PlatformRequestData {

	private static final long serialVersionUID = 1L;
	private String transactionId;
	private String key;
	
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	
	
}
