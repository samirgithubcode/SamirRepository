/**
 * Service1.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ng.bridge.dataobject.euronet.otherservice;

public interface Service1 extends javax.xml.rpc.Service {
    public java.lang.String getBasicHttpBindingIService1Address();

    public com.ng.bridge.dataobject.euronet.otherservice.IService1 getBasicHttpBindingIService1() throws javax.xml.rpc.ServiceException;

    public com.ng.bridge.dataobject.euronet.otherservice.IService1 getBasicHttpBindingIService1(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
