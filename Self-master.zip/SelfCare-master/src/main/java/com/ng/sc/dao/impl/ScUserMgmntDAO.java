package com.ng.sc.dao.impl;

import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TemporalType;
import javax.persistence.TypedQuery;
import javax.servlet.http.HttpSession;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.ng.sb.common.dataobject.SubscriberData;
import com.ng.sb.common.dataobject.TransactionRequestData;
import com.ng.sb.common.model.AccountLoginInfo;
import com.ng.sb.common.model.Address;
import com.ng.sb.common.model.CardDetails;
import com.ng.sb.common.model.CardWallets;
import com.ng.sb.common.model.CountryCode;
import com.ng.sb.common.model.CustomerQueryLog;
import com.ng.sb.common.model.CustomerSubQuery;
import com.ng.sb.common.model.InventoryMgmt;
import com.ng.sb.common.model.Otp;
import com.ng.sb.common.model.PinCodeInfo;
import com.ng.sb.common.model.Products;
import com.ng.sb.common.model.SignUpOtp;
import com.ng.sb.common.model.Subscriber;
import com.ng.sb.common.model.UserWalletDetails;
import com.ng.sb.common.util.KeyEncryptionUtils;
import com.ng.sb.common.util.SystemConstant;
import com.ng.sc.dao.IScUserMgmntDAO;

@Repository
public class ScUserMgmntDAO extends SelfCareDAO implements IScUserMgmntDAO {

	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = LoggerFactory.getLogger(ScUserMgmntDAO.class);
	public static final String MSISDN = "msisdn";
	public static final String MOBILENOSERVICE = "mobilenoservice";
	@PersistenceContext(unitName = "CUG_DS")
	private EntityManager entityManager;

	@Override
	public Integer saveNewPassword(Subscriber subscriber) throws Exception {
		Subscriber subscriberinfo=new Subscriber();
		try {
			LOGGER.info("***** start of saveNewPassword() method in ScUserMgmntDAO *****");
			subscriberinfo = entityManager.merge(subscriber);
		} catch (Exception ex) {
			LOGGER.info("Exception occurred in saveNewPassword() method in ScUserMgmntDAO--->" + ex);
		}
		LOGGER.info("***** End of saveNewPassword() method in ScUserMgmntDAO *****");
		return subscriberinfo.getInvalidLoginCount();
	}
	@Transactional
	public void increaseInvalidCount(int invalidLogincount, AccountLoginInfo accountLoginInfo) {
		int invalidlogin=invalidLogincount+1;
		try {
			accountLoginInfo.setInvalidLoginCount(invalidlogin);
			entityManager.merge(accountLoginInfo);
		} catch (Exception ex) {
			LOGGER.info("---------------" + ex);
		}
	}

	@Override
	@Transactional
	public Map<String, Integer> validateSecurityQuestionCheck(String emailorusername, Date dob, String answer)
			throws Exception {
		TypedQuery<AccountLoginInfo> query = null;
		TypedQuery<AccountLoginInfo> query1 = null;
		Integer invalidLoginCount = 0;
		AccountLoginInfo accountLoginInfo = null;
		Map<String, Integer> accountIdOrInvalidCount = new HashMap<>();
		try {
			LOGGER.info("***** start of validateSecurityQuestionCheck() method in UserMgmntDAO *****");
			query = entityManager.createNamedQuery("AccountLoginInfo.findByEmailIdOrloginNameDobAndSecurityAns",
					AccountLoginInfo.class);
			query.setParameter("loginemailormobile", emailorusername);
			query.setParameter("dateOfBirth", dob);
			query.setParameter("securityAnswer", answer);
			accountLoginInfo = query.getSingleResult();
			if (accountLoginInfo.getInvalidLoginCount() < SystemConstant.INVALIDLOGINCOUNTLIMIT) {
				accountIdOrInvalidCount.put("accountId", accountLoginInfo.getAccountId().getId());
			} else {
				accountIdOrInvalidCount.put("blockId", accountLoginInfo.getInvalidLoginCount());
			}
		} catch (Exception ex) {
			LOGGER.info("Exception occurred in validateSecurityQuestionCheck() method in UserMgmntDAO--->"
					+ ex);
			try {
				query1 = entityManager.createNamedQuery("AccountLoginInfo.findByEmailIdOrloginName",
						AccountLoginInfo.class);
				query1.setParameter("loginemailormobile", emailorusername);
				accountLoginInfo = query1.getSingleResult();
				if (accountLoginInfo != null) {
					invalidLoginCount = accountLoginInfo.getInvalidLoginCount();
					if (invalidLoginCount < SystemConstant.INVALIDLOGINCOUNTLIMIT) {
						increaseInvalidCount(invalidLoginCount, accountLoginInfo);
						accountIdOrInvalidCount.put("invalidLoginCount", accountLoginInfo.getInvalidLoginCount());
					} else {
						accountIdOrInvalidCount.put("invalidLoginCount", invalidLoginCount);
					}

				}
			} catch (Exception exp) {
				LOGGER.info("" + exp);
			}
		}
		LOGGER.info("***** End of validateSecurityQuestionCheck() method in UserMgmntDAO *****");
		return accountIdOrInvalidCount;
	}

	@Override
	public List<CountryCode> getCountryCodeMap() {
		List<CountryCode> codeList = null;
		TypedQuery<CountryCode> query = null;

		try {
			query = entityManager.createNamedQuery("CountryCode.findAll", CountryCode.class);
			codeList = query.getResultList();
			LOGGER.info("*****Method getCountryCodeMap()  Execution done in DAO");
		} catch (Exception e) {
			LOGGER.info("***Exception Ocure in Method getCountryCodeMap()  :"
					+ e);
		}
		return codeList;

	}
	@Override
	public Subscriber getSubscriberById(Integer subscriberid) {
		Subscriber subscriber = null;
		TypedQuery<Subscriber> query = null;
		try {
			LOGGER.info("***** Execution start of getSubscriberById() method in ScUserMgmtDAO *****");
			query = entityManager.createNamedQuery("Subscriber.findById", Subscriber.class);
			query.setParameter("id", subscriberid);
			List<Subscriber> subscriberList = query.getResultList();
			if (subscriberList != null && !subscriberList.isEmpty()) {
				subscriber = subscriberList.get(0);
			}

		} catch (Exception ex) {
			LOGGER.info("Exception occurred in getSubscriberById() method in ScUserMgmtDAO --->" + ex);
		}

		return subscriber;
	}

	@Override
	public Subscriber saveSubscriberDetails(Subscriber subscriber) throws Exception {
		Subscriber subscriberinfo=null;
		try {
			LOGGER.info("***** start of saveSubscriberPersonalInfo() method in ScUserMgmntDAO *****");
			subscriberinfo = entityManager.merge(subscriber);
		} catch (Exception ex) {
			LOGGER.info("Exception occurred in saveSubscriberPersonalInfo() method in ScUserMgmntDAO--->" + ex);
		}
		LOGGER.info("***** End of saveSubscriberPersonalInfo() method in ScUserMgmntDAO *****");
		return subscriberinfo;
	}

	@Override
	public SignUpOtp validateOtp(String mobileNo, String dateOfBirth, Integer otp) throws Exception {
		SignUpOtp signup=new SignUpOtp();
		try{
			signup.setMobileNumber(mobileNo);
			signup.setDob(dateOfBirth);
			signup.setOtpp(otp);
			
			signup=entityManager.merge(signup);
		}
		catch (Exception ex) {
			LOGGER.info("Exception occurred in saveSubscriberPersonalInfo() method in ScUserMgmntDAO--->" + ex);
		}
		return signup;
	}
	@Override
	public Subscriber validateMobile(String userMobile) throws Exception {
		TypedQuery<Subscriber> query = null;
		Subscriber subscriber = null;
		LOGGER.info("***** start of validateMobile() method in ScUserMgmntDAO *****");
		try {
			LOGGER.info("***** start of validateMobile() method in ScUserMgmntDAO *****");
			query = entityManager.createNamedQuery("Subscriber.findByMsisdn", Subscriber.class);
			query.setParameter(MSISDN, userMobile);
			subscriber = query.getSingleResult();

		} catch (Exception ex) {
			LOGGER.info("Exception occurred in validateMobile() method in ScUserMgmntDAO--->" + ex);
		}
		LOGGER.info("***** End of validateMobile() method in ScUserMgmntDAO *****");
		return subscriber;
	}

	@Override
	public Otp getOtp(Otp otp) throws Exception {
		TypedQuery<Otp> query = null;
		List<Otp> otps = null;
		try {
			query = entityManager.createNamedQuery("Otp.findById", Otp.class);
			query.setParameter("id", otp.getId());
			otps = query.getResultList();
			if (!otps.isEmpty()) {
				return otps.get(0);
			}
		} catch (Exception ex) {
			LOGGER.debug("Exception occured in getOtp() method of ScUserMgmntDAO " + ex);
		}
		return otp;
	}

	@Override
	public Subscriber getSubscriber(String mobileNo) throws Exception {
		TypedQuery<Subscriber> query = null;
		List<Subscriber> subscribers = null;
		Subscriber subscriber = null;
		try {
			LOGGER.info("execution start of method getSubscriber() in KYCDAO ");
			query = entityManager.createNamedQuery("Subscriber.findByMsisdn", Subscriber.class);
			query.setParameter(MSISDN, mobileNo);
			if (!query.getResultList().isEmpty()) {
				subscribers = query.getResultList();
				return subscribers.get(0);
			}
		} catch (Exception ex) {
			LOGGER.debug("Exception occurred in getSubscriber() method in ScUserMgmntDAO" + ex);
		}
		LOGGER.info("execution end of method getSubscriber() in ScUserMgmntDAO ");
		return subscriber;
	}

	@Override
	@Transactional
	public Otp addOtp(Otp otp) throws Exception {
		Otp otp1=null;
		try {
			otp1 = entityManager.merge(otp);
		} catch (Exception ex) {

			LOGGER.debug("Exception occured in method addOtp() in ScUserMgmntDAO " + ex);
		}
		return otp1;
	}

	@Override
	public Otp getOtpByVal(Subscriber subscriber, Integer confirmationOtp) throws Exception {
		TypedQuery<Otp> query = null;
		List<Otp> otps = null;
		try {
			query = entityManager.createNamedQuery("Otp.findBySubscriberAndOtp", Otp.class);
			query.setParameter("subscriberId", subscriber);
			query.setParameter("otp", confirmationOtp);
			otps = query.getResultList();
			if (otps.get(0) != null) {
				return otps.get(0);
			}
		} catch (Exception ex) {
			LOGGER.debug("Exception occured in getOtpByVal() method of ScUserMgmntDAO " + ex);
		}
		return null;
	}

	@Override
	public List<Address> fetchAddress(String pinCode) throws Exception {
		List<Address> addressesList = null;
		TypedQuery<Address> query = null;
		try {
			query = entityManager.createNamedQuery("Address.findByPincode", Address.class);
			query.setParameter("pincode", pinCode);
			addressesList = query.getResultList();
		} catch (Exception ex) {
			LOGGER.debug("Exception occured in fetchAddress() method of ScUserMgmntDAO "+ex);
		}
		return addressesList;
	}
	@Override
	public UserWalletDetails getwallet(Integer id) throws Exception {
		LOGGER.info("****Start  method getCustomerDetails() ");
		TypedQuery<UserWalletDetails> query=null;
		List<UserWalletDetails> list= new ArrayList<>();
		      try {
				query= entityManager.createNamedQuery("UserWalletDetails.findByUserId", UserWalletDetails.class);
				
				query.setParameter("userid", new Subscriber(id) );
				list=	query.getResultList();
				if(!list.isEmpty())
				{
				return	list.get(0);
				}
				
			} catch (Exception e) {
				LOGGER.info("****Exception  method getCustomerDetails() "+e);
			}
			return null;
	}
	@Override
	public List<Products> getproducttype() throws Exception {
		
		
		LOGGER.info("****Start  method getCustomerDetails() ");
		TypedQuery<Products> query=null;
		List<Products> list= new ArrayList<>();
		      try {
				query= entityManager.createNamedQuery("Products.findUniqueProductList", Products.class);
				
				list=	query.getResultList();
			
				
			} catch (Exception e) {
				LOGGER.info("****Exception  method getCustomerDetails() "+e);
			}
			return list;
		
		
	}
	
	
	
	@Override
	public List<CustomerSubQuery> getsubquerylist(String productType) throws Exception {
		
		LOGGER.info("****Start  method getsubquerylist() ");
		TypedQuery<CustomerSubQuery> query=null;
		List<CustomerSubQuery> list= new ArrayList<>();
		      try {														
				query= entityManager.createNamedQuery("CustomerSubQuery.findAllProductType", CustomerSubQuery.class);
				query.setParameter("productType",productType);
				list=	query.getResultList();
			
				
			} catch (Exception e) {
				LOGGER.info("****Exception  method getsubquerylist() "+e);
			}
			return list;
	}
	@Override
	public List<Integer> getProductTypeId(String loginId) throws Exception {
		LOGGER.info("****Start  method getProductTypeId()");
		TypedQuery<InventoryMgmt> query=null;
		List<InventoryMgmt> inventoryMgmtData;
		CardDetails cardDetails=null;
		List<Integer> productTypeId=new ArrayList<>();
		      try {
				query= entityManager.createNamedQuery("InventoryMgmt.findbyLoginId", InventoryMgmt.class);
				query.setParameter("loginId",loginId);
				inventoryMgmtData=	query.getResultList();
				for(InventoryMgmt inventryMgmtData:inventoryMgmtData){
				if(	inventryMgmtData.getProductStatus().equalsIgnoreCase("Issued")){
				cardDetails=inventryMgmtData.getProductTypeId();
				if(cardDetails != null)
					productTypeId.add(cardDetails.getId());
				}
				}
				
			} catch (Exception e) {
				LOGGER.info("****Exception  method getProductTypeId() "+e);
			}
			return productTypeId;
	}
	@Override
	public List<CardWallets> getWalletList(List<Integer> productTypeIdList) throws Exception {
		LOGGER.info("****Start  method getWalletList()");
		TypedQuery<CardWallets> query=null;
		List<CardWallets> cardWalletList=new ArrayList<>();
		
		List<CardWallets> cardWallets=new ArrayList<>();
		
		      try {
		    	  for(Integer productTypeId : productTypeIdList)
		    	  {
					query= entityManager.createNamedQuery("CardWallets.getByCardNameId", CardWallets.class);
					query.setParameter("id",new CardDetails(productTypeId));
					cardWallets =	query.getResultList();
					
					cardWalletList.addAll(cardWallets);
		    	  }
				
			} catch (Exception e) {
				LOGGER.info("****Exception  method getWalletList() "+e);
			}
			return cardWalletList;
	}
	@Override
	public CustomerQueryLog saveMyQuery(CustomerQueryLog customerQueryLog) throws Exception {
		try {
			LOGGER.info("***** start of saveMyQuery() method in ScUserMgmntDAO *****");
			entityManager.persist(customerQueryLog);
		} catch (Exception ex) {
			LOGGER.info("Exception occurred in saveMyQuery() method in ScUserMgmntDAO--->" + ex);
		}
		LOGGER.info("***** End of saveMyQuery() method in ScUserMgmntDAO *****");
		return customerQueryLog;
	
		
	}
	
	@Override
	public int checkfiled(String value, String tablename, String field) throws Exception {
			
			List<Object> list= new ArrayList<>();
			
			try {
				//String hql="FROM "+tablename+" t WHERE t."+field+" = :val AND t.userPassword IS NOT NULL AND t.firstTimeLogin IS NOT NULL";
				
				String hql="FROM "+tablename+" t WHERE t."+field+" = :val ";
				
				Query query =entityManager.createQuery(hql);
				query.setParameter("val",value);
				 	list=query.getResultList();
			} catch (Exception e) {
				e.printStackTrace();
				LOGGER.info(""+e);
			}
			
			
			
			if(!list.isEmpty())
			{
				Subscriber subscriber = (Subscriber)list.get(0);
				
				if(subscriber.getUserPassword() != null && !subscriber.getUserPassword().equals(""))
					return 1;
				else
					return 2;
			}else
			return 0;
	
	
	}
	
	@Override
	public int getSubscriberExist(String mobile, String dob, String emailId,String userPassword) throws Exception {
		
		TypedQuery<Subscriber> query = null;
		try {
			LOGGER.info("execution start of method getSubscriberExist() ");
			query = entityManager.createNamedQuery("Subscriber.findByPassword", Subscriber.class);
			query.setParameter(MSISDN, mobile);
			List<Subscriber> list= query.getResultList();
			if (!list.isEmpty()) {
				return 0;
			}
		} catch (Exception ex) {
			LOGGER.debug("Exception occurred in getSubscriberExist() method in ScUserMgmntDAO" + ex);
		}
		
		
		return 1;
	}
	@Override
	public List<CustomerQueryLog> getqueryLog(String mobileNo,TransactionRequestData transactionRequestData) {

		List<CustomerQueryLog> list= new ArrayList<>();
		
		
		try {
			
			LOGGER.info("execution start of method getqueryLog()  ");
			
			list=callQuery(mobileNo,transactionRequestData);
			
			
		} catch (Exception ex) {
			LOGGER.debug("Exception occurred in getqueryLog() method in ScUserMgmntDAO" + ex);
		}
		if(list.isEmpty()){
			transactionRequestData.setMessage("No Data to display");
		}
		
		return list;
		
	}
	private List<CustomerQueryLog> callQuery(String mobileNo,TransactionRequestData transactionRequestData) {
		java.util.Date startDate=null;
		java.util.Date endDate=null;
		if(transactionRequestData.getStartDate()!=null && !transactionRequestData.getStartDate().isEmpty()){
			 startDate=	KeyEncryptionUtils.stringToDate(transactionRequestData.getStartDate(), "yyyy-MM-dd");
			 endDate=KeyEncryptionUtils.stringToDate(transactionRequestData.getEndDate(), "yyyy-MM-dd");
				}
		TypedQuery<CustomerQueryLog> query = null;
		List<CustomerQueryLog> list;
		list=getAllEmptyList(mobileNo,transactionRequestData);
		
			 if((transactionRequestData.getStartDate()==null || transactionRequestData.getStartDate().isEmpty()) &&( transactionRequestData.getEndDate()==null || transactionRequestData.getEndDate().isEmpty()) && (transactionRequestData.getStatus()!=null && !transactionRequestData.getStatus().equals("All"))){
				query = entityManager.createNamedQuery("CustomerQueryLog.findBymobilenumberServiceAndStatus", CustomerQueryLog.class);
				query.setParameter(MOBILENOSERVICE, mobileNo);
				query.setParameter("status", transactionRequestData.getStatus());
				list= query.getResultList();
				}
			
			if((transactionRequestData.getStartDate()!=null && !transactionRequestData.getStartDate().isEmpty()) &&( transactionRequestData.getEndDate()!=null && !transactionRequestData.getEndDate().isEmpty() )&& (transactionRequestData.getStatus()==null||transactionRequestData.getStatus().equals("All"))){
				query = entityManager.createNamedQuery("CustomerQueryLog.findBymobilenumberServiceAndDate", CustomerQueryLog.class);
				query.setParameter(MOBILENOSERVICE, mobileNo);
				query.setParameter("startDate", startDate, TemporalType.DATE);
				query.setParameter("endDate", endDate, TemporalType.DATE);
				list= query.getResultList();
				}
			if((transactionRequestData.getStartDate()!=null&&!transactionRequestData.getStartDate().isEmpty()) &&( transactionRequestData.getEndDate()!=null&&!transactionRequestData.getEndDate().isEmpty()) &&( transactionRequestData.getStatus()!=null ||!transactionRequestData.getStatus().equals("All"))){
				query = entityManager.createNamedQuery("CustomerQueryLog.findBymobilenumberServiceAndDateAndStatus", CustomerQueryLog.class);
				query.setParameter(MOBILENOSERVICE, mobileNo);
				query.setParameter("status", transactionRequestData.getStatus());
				query.setParameter("startDate",startDate);
				query.setParameter("endDate",endDate);
				list= query.getResultList();
				}
			return list;
		
	}
	private List<CustomerQueryLog> getAllEmptyList(String mobileNo, TransactionRequestData transactionRequestData) {
		
		
		TypedQuery<CustomerQueryLog> query = null;
		List<CustomerQueryLog> list= new ArrayList<>();
		if((transactionRequestData.getStartDate()==null||transactionRequestData.getStartDate().isEmpty()) && (transactionRequestData.getEndDate()==null || transactionRequestData.getEndDate().isEmpty()) && (transactionRequestData.getStatus()==null||transactionRequestData.getStatus().isEmpty()||transactionRequestData.getStatus().equals("All"))){
			query = entityManager.createNamedQuery("CustomerQueryLog.findBymobilenumberService", CustomerQueryLog.class);
			query.setParameter(MOBILENOSERVICE, mobileNo);
			list= query.getResultList();
			}
		return list;
	}
	@Override
	public Products getProductId(String instrument) {
		
		TypedQuery<Products> query = null;
		Products list=null;
		try {
			LOGGER.info("execution start of method getProductId() ");
			query = entityManager.createNamedQuery("Products.findByName", Products.class);
			query.setParameter("name", instrument);
			list= query.getSingleResult();
			
		} catch (Exception ex) {
			LOGGER.debug("Exception occurred in getSubscriberExist() method in ScUserMgmntDAO" + ex);
		}
		
		
		return list;
	}
	@Override
	public CustomerSubQuery getListOfLinks(Integer subqueryid) {
		LOGGER.info("****Start  method getListOfLinks() ");
		TypedQuery<CustomerSubQuery> query=null;
		CustomerSubQuery list=null;
		      try {
				query= entityManager.createNamedQuery("CustomerSubQuery.findbyid", CustomerSubQuery.class);
				query.setParameter("id",subqueryid);
				list=	query.getSingleResult();
			
				
			} catch (Exception e) {
				LOGGER.info("****Exception  method getListOfLinks() "+e);
			}
			return list;
	}
	@Override
	public List<UserWalletDetails> getAllwalletList(Integer subscriberid) {
		LOGGER.info("****Start  method getwalletDetails() in CustomerCareDAO");
		TypedQuery<UserWalletDetails> query = null;
		List<UserWalletDetails> list = new ArrayList<>();
		try {
			query = entityManager.createNamedQuery("UserWalletDetails.findByUserId", UserWalletDetails.class);

			query.setParameter("userid", new Subscriber(subscriberid));
			list = query.getResultList();

		} catch (Exception e) {
			LOGGER.info("****Exception  method getwalletDetails() in CustomerCareDAO", e);
		}
		return list;
	}
	@Override
	public List<InventoryMgmt> getProductDetail(String mobile) {

		List<InventoryMgmt> inventoryMgmt = null;
		TypedQuery<InventoryMgmt> query = null;

		try {
			query = entityManager.createNamedQuery("InventoryMgmt.findByCustomerMSISDN", InventoryMgmt.class);
			query.setParameter("customerMSISDN", mobile);
			inventoryMgmt = query.getResultList();
		} catch (Exception e) {
			LOGGER.debug("****Start  method   getCustomerUsertype() in CustomerCareService", e);
		}
		return inventoryMgmt;
	}
	@Transactional
	@Override
	public boolean getProductDetailById(String productId,String comment) {

		List<InventoryMgmt> inventoryMgmt = null;
		InventoryMgmt  inventory= null;
		TypedQuery<InventoryMgmt> query = null;
		boolean status=true;
		try {
			query = entityManager.createNamedQuery("InventoryMgmt.findById", InventoryMgmt.class);
			query.setParameter("id", Integer.parseInt(productId));
			inventoryMgmt = query.getResultList();
			if(inventoryMgmt.get(0)!=null){
			inventory=inventoryMgmt.get(0);
			inventory.setReasonForDeactivation(comment);
			inventory.setProductStatus("BLOCK_BY_CUST");
			entityManager.merge(inventory);
			}
		} catch (Exception e) {
			LOGGER.debug("****Start  method   getCustomerUsertype() in CustomerCareService", e);
			status=false;
		}
		return status;
	}
	@Override
	public void updateWalletStatus(Integer id) {
		
		try{
			LOGGER.debug("***************** updateWalletStatus() starts executing ****************");
			String sql = "Update UserWalletDetails u SET u.status=0 where u.userid=:id";
			Query query1;
			query1 = entityManager.createQuery(sql);
			query1.setParameter("id",new Subscriber(id));
			
			query1.executeUpdate();
			
		}catch(Exception e){
			LOGGER.info("Exception occurs at updateWalletStatus() method " + e);
		}
		
	}
	@Override
	public List<Products> getproductList() {
		LOGGER.info("****Start  method getCustomerDetails() ");
		TypedQuery<Products> query=null;
		List<Products> list= new ArrayList<>();
		      try {
				query= entityManager.createNamedQuery("Products.findAll", Products.class);
				
				list=	query.getResultList();
			
				
			} catch (Exception e) {
				LOGGER.info("****Exception  method getCustomerDetails() "+e);
			}
			return list;
		
	}
	@Override
	public List<CustomerQueryLog> queryStatus(HttpSession session, String subscriberMobNo) {
		
		LOGGER.info("****Start  method getCustomerDetails() ");
		TypedQuery<CustomerQueryLog> query=null;
		List<CustomerQueryLog> list= new ArrayList<>();
		      try {
				query= entityManager.createNamedQuery("CustomerQueryLog.findLimitmobilenumberService", CustomerQueryLog.class);
				query.setParameter(MOBILENOSERVICE, subscriberMobNo);
				query.setMaxResults(5);
				list=	query.getResultList();
			
				
			} catch (Exception e) {
				LOGGER.info("****Exception  method getCustomerDetails() "+e);
			}
			return list;
		
	}
	@Override
	public void saveNewPinCode(PinCodeInfo addressinfo) {
		LOGGER.debug("*********** saveNewPinCode() starts executing in BankDAO *************");
		try
		{
			entityManager.persist(addressinfo);
		}
		catch(Exception ex)
		{
			LOGGER.info("Exception occurred in saveNewPinCode() method in BankDAO --->"+ex);
		}
		
	}
	@Override
	public boolean checkWallet(String userMobile, String walletId) {
		// TODO Auto-generated method stub
		
		TypedQuery<Subscriber> query=null;
		List<Subscriber> list= new ArrayList<>();
		
		TypedQuery<UserWalletDetails> query1=null;
		List<UserWalletDetails> list1= new ArrayList<>();
		      try {
				query= entityManager.createNamedQuery("Subscriber.findByMsisdn", Subscriber.class);
				query.setParameter("msisdn", userMobile);
				list=	query.getResultList();
				if(list!=null && !list.isEmpty())
				{
				Subscriber subs=list.get(0);
				
				query1= entityManager.createNamedQuery("UserWalletDetails.findByUserId", UserWalletDetails.class);
				query1.setParameter("userid", new Subscriber(subs.getId()));
				list1=	query1.getResultList();
				for(UserWalletDetails user:list1)
				{
					if(user.getWalletType().getId()==Integer.parseInt(walletId))
					{
						return true;
					}
				}
				}
				
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		return false;
	}
	
	@Transactional
	@Override
	public boolean updateWalletDetails(UserWalletDetails userWallet) 
	{
		boolean updateStatus = false;
		
		try {
			LOGGER.info("***** start of updateWalletDetails() method in ScUserMgmntDAO *****");
			 entityManager.merge(userWallet);
			 updateStatus = true;
		} catch (Exception ex) {
			LOGGER.info("Exception occurred in updateWalletDetails() method in ScUserMgmntDAO--->" + ex);
		}
		
		LOGGER.info("***** End of updateWalletDetails() method in ScUserMgmntDAO *****");
		
		return updateStatus;
	}

}