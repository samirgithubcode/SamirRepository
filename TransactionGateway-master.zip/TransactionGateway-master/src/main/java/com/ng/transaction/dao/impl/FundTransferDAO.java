/**
 * 
 */
package com.ng.transaction.dao.impl;

import org.springframework.stereotype.Repository;

import com.ng.sb.common.util.SystemConstant;
import com.ng.transaction.dao.IFundTransferDAO;

/**
 * @author gaurav
 *
 */
@Repository(value=SystemConstant.FUND_TRANSFER_DAO)
public class FundTransferDAO extends PaymentInstrumentDAO implements IFundTransferDAO {
	private static final long serialVersionUID = 1L;

}
