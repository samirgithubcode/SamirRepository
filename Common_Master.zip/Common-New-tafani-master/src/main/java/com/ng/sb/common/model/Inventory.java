/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "inventory")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Inventory.findAll", query = "SELECT i FROM Inventory i"),
    @NamedQuery(name = "Inventory.findById", query = "SELECT i FROM Inventory i WHERE i.id = :id"),
    @NamedQuery(name = "Inventory.findByBoxId", query = "SELECT i FROM Inventory i WHERE i.boxId = :boxId"),
    @NamedQuery(name = "Inventory.findByIccd", query = "SELECT i FROM Inventory i WHERE i.iccd = :iccd"),
    @NamedQuery(name = "Inventory.findByExternalIccd", query = "SELECT i FROM Inventory i WHERE i.externalIccd = :externalIccd"),
    @NamedQuery(name = "Inventory.findByDKey", query = "SELECT i FROM Inventory i WHERE i.dKey = :dKey"),
    @NamedQuery(name = "Inventory.findByInventoryStatus", query = "SELECT i FROM Inventory i WHERE i.inventoryStatus = :inventoryStatus"),
    @NamedQuery(name = "Inventory.findByAddDate", query = "SELECT i FROM Inventory i WHERE i.addDate = :addDate"),
    @NamedQuery(name = "Inventory.findBetweenExternalNumber", query = "SELECT i FROM Inventory i WHERE i.externalIccd BETWEEN :boxFrom AND :boxTo"),
    @NamedQuery(name = "Inventory.findByExternalNum", query = "SELECT i FROM Inventory i WHERE i.externalIccd = :externalIccd"),
    
    @NamedQuery(name ="Inventory.countbyProductOrderMasterVersionStatus",query="SELECT count(*) FROM Inventory i WHERE i.productId =:productId AND i.mvId=:mvId AND i.poId=:poId AND i.inventoryStatus= :inventoryStatus"),
    @NamedQuery(name ="Inventory.countbyProductOrderCardStatus",query="SELECT count(*) FROM Inventory i WHERE i.productId =:productId AND i.productTypeId=:productTypeId AND i.poId=:poId AND i.inventoryStatus= :inventoryStatus"),
    @NamedQuery(name ="Inventory.inventoryByProductOrderMasterVersionStatus",query="SELECT i FROM Inventory i WHERE i.productId =:productId AND i.mvId=:mvId AND i.poId=:poId AND i.inventoryStatus= :inventoryStatus"),})

public class Inventory implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "iccd")
    private String iccd;
    @Column(name = "dKey")
    private String dKey;
    @Column(name = "dKey1")
    private String dKey1;
    
    @Basic(optional = false)
    @Column(name = "externalIccd")
    private Long externalIccd;
   
    @Column(name = "dKey2")
    private String dKey2;
    @Column(name = "dKey3")
    private String dKey3;
    @Column(name = "dKey4")
    private String dKey4;
    @Column(name = "dKey5")
    private String dKey5;
   
    @Basic(optional = false)
    @Column(name = "inventory_status")
    private String inventoryStatus;
    @Basic(optional = false)
    @Column(name = "PukCode")
    private String pukCode;
    @Basic(optional = false)
    @Column(name = "addDate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date addDate;
    @Basic(optional = false)
    @Column(name = "transactionId")
    private String transactionId;
    @Column(name = "smsCenter")
    private String smsCenter;
   
	@JoinColumn(name = "productId", referencedColumnName = "id")
    @ManyToOne
    private Products productId;
	@JoinColumn(name = "productTypeId", referencedColumnName = "id")
    @ManyToOne
    private CardDetails productTypeId;
    
    @JoinColumn(name = "mvId", referencedColumnName = "id")
    @ManyToOne
    private MasterVersion mvId;
    
    @JoinColumn(name = "boxId", referencedColumnName = "id")
    @ManyToOne
    private BoxDetails boxId;


	@JoinColumn(name="poId", referencedColumnName="id")
    @ManyToOne
    private Order poId;
    
    public Inventory() {
    	//default constructor
    }

    public Inventory(Integer id) {
        this.id = id;
    }

    public Inventory(Integer id, String iccd, Long externalIccd, String dKey, String inventoryStatus, Date addDate) {
        this.id = id;
        this.iccd = iccd;
        this.externalIccd = externalIccd;
        this.dKey = dKey;
        this.inventoryStatus = inventoryStatus;
        this.addDate = addDate;
    }
    public String getdKey1() {
		return dKey1;
	}

	public void setdKey1(String dKey1) {
		this.dKey1 = dKey1;
	}
	public CardDetails getProductTypeId() {
		return productTypeId;
	}

	public void setProductTypeId(CardDetails productTypeId) {
		this.productTypeId = productTypeId;
	}
	public String getdKey2() {
		return dKey2;
	}
	 public String getSmsCenter() {
			return smsCenter;
		}

		public void setSmsCenter(String smsCenter) {
			this.smsCenter = smsCenter;
		}
	public void setdKey2(String dKey2) {
		this.dKey2 = dKey2;
	}

	public String getdKey3() {
		return dKey3;
	}

	public void setdKey3(String dKey3) {
		this.dKey3 = dKey3;
	}

	public String getdKey4() {
		return dKey4;
	}

	public void setdKey4(String dKey4) {
		this.dKey4 = dKey4;
	}

	public String getdKey5() {
		return dKey5;
	}

	public void setdKey5(String dKey5) {
		this.dKey5 = dKey5;
	}
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

	public String getIccd() {
        return iccd;
    }

    public void setIccd(String iccd) {
        this.iccd = iccd;
    }

    public Long getExternalIccd() {
        return externalIccd;
    }

    public void setExternalIccd(Long externalIccd) {
        this.externalIccd = externalIccd;
    }


	public BoxDetails getBoxId() {
		return boxId;
	}

	public void setBoxId(BoxDetails boxId) {
		this.boxId = boxId;
	}

	public MasterVersion getMvId() {
		return mvId;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public void setMvId(MasterVersion mvId) {
		this.mvId = mvId;
	}

	public String getPukCode() {
		return pukCode;
	}

	public void setPukCode(String pukCode) {
		this.pukCode = pukCode;
	}

	public String getDKey() {
        return dKey;
    }

    public void setDKey(String dKey) {
        this.dKey = dKey;
    }

    public String getInventoryStatus() {
        return inventoryStatus;
    }

    public void setInventoryStatus(String inventoryStatus) {
        this.inventoryStatus = inventoryStatus;
    }

    public Date getAddDate() {
        return addDate;
    }

    public void setAddDate(Date addDate) {
        this.addDate = addDate;
    }

    public Products getProductId() {
        return productId;
    }

    public void setProductId(Products productId) {
        this.productId = productId;
    }
    

  	public Order getPoId() {
  		return poId;
  	}

  	public void setPoId(Order poId) {
  		this.poId = poId;
  	}

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
    	boolean	check= true;
    	if(object!=null){
        if (!(object instanceof Inventory)) {
        	check= false;
        }
        Inventory other = (Inventory) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
    	}
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.Inventory[ id=" + id + " ]";
    }
    
}
