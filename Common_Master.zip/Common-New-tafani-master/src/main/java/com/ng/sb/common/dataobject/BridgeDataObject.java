/**
 * 
 */
package com.ng.sb.common.dataobject;


/**
 * @author gaurav
 *
 */
public class BridgeDataObject extends BaseObjectData {

	private static final long serialVersionUID = 1L;
	
	private HostSubVersionData hostSubVersionData;
	
	public enum ServiceCall {
		TRANSACTION,
		BRIDGE
	}
	public enum ServiceType {
		//BANKING
		BANKING_CHECK_BAL, 
		BANKING_FT_B_TO_B,
		BANKING_FT_B_TO_CC,
		BANKING_FT_B_TO_IMPS,
		BANKING_FT_B_TO_WALLET,
		BANKING_IMPS_IMPS_TO_B,
		BANKING_IMPS_IMPS_TO_CC,
		BANKING_IMPS_IMPS_TO_IMPS,
		BANKING_IMPS_IMPS_TO_WALLET,
		BANKING_CASH_WD_FROM_B,
		BANKING_CASH_WD_FROM_CC,
		BANKING_CHQ_BOOK_REQUEST,
		BANKING_CHQ_STATUS,
		BANKING_STOP_CHEQUE,
		BANKING_LAST_5_TRANS,
		
		// BILLPAY
		BILL_PAY_BY_B,
		BILL_PAY_BY_CC,
		BILL_PAY_BY_IMPS,
		BILL_PAY_BY_WALLET,
		
		// MWALLET
		// MWALLET AGENT
		MWALLET_AG_CHK_BAL,
		MWALLET_AG_TOP_UP_ONLINE_B_T_W,
		MWALLET_AG_TOP_UP_ONLINE_W_T_W,
		MWALLET_AG_TOP_UP_ONLINE_I_T_W,
		MWALLET_AG_TOP_UP_ONLINE_CC_T_W,
		
		// Agent TopUp Account
		MWALLET_AG_TOP_UP_ACCOUNT_B_T_B,
		MWALLET_AG_TOP_UP_ACCOUNT_B_T_W,
		MWALLET_AG_TOP_UP_ACCOUNT_B_T_CC,
		MWALLET_AG_TOP_UP_ACCOUNT_B_T_I,
		
		
		MWALLET_AG_TOP_UP_ACCOUNT_I_T_B,
		MWALLET_AG_TOP_UP_ACCOUNT_I_T_W,
		MWALLET_AG_TOP_UP_ACCOUNT_I_T_CC,
		MWALLET_AG_TOP_UP_ACCOUNT_I_T_I,
		
		MWALLET_AG_TOP_UP_ACCOUNT_CC_T_B,
		MWALLET_AG_TOP_UP_ACCOUNT_CC_T_W,
		MWALLET_AG_TOP_UP_ACCOUNT_CC_T_CC,
		MWALLET_AG_TOP_UP_ACCOUNT_CC_T_I,
		
		// MWALLET CUSTOMER
		MWALLET_CUST_CHK_BAL,
		MWALLET_CUST_TOP_UP_ONLINE_B_T_W,
		MWALLET_CUST_TOP_UP_ONLINE_I_T_W,
		MWALLET_CUST_TOP_UP_ONLINE_CC_T_W,
		MWALLET_CUST_TOP_UP_ONLINE_VIA_SMS_T_W,
		MWALLET_CUST_CASH_OUT_WALLET,
		
		// TOPUP RECHARGE
		TOP_UP_RECH_BY_B,
		TOP_UP_RECH_BY_CC,
		TOP_UP_RECH_BY_IMPS,
		TOP_UP_RECH_BY_WALLET,
		
		
		// SETTINGS
		// SETTINGS BANK ACCOUNT
		SETTINGS_BANK_ACC_ADD,
		SETTINGS_BANK_ACC_EDIT,
		SETTINGS_BANK_ACC_DELETE,
		
		// SETTINGS CC
		SETTINGS_CC_ADD,
		SETTINGS_CC_EDIT,
		SETTINGS_CC_DELETE,
		
		// SETTINGS IMPS
		SETTINGS_IMPS_ADD,
		SETTINGS_IMPS_EDIT,
		SETTINGS_IMPS_DELETE,
		
		// SETTINGS WALLET
		SETTINGS_MY_WALLET,
		
		// SETTINGS MYBILLER
		SETTINGS_MY_BILLER_ADD,
		SETTINGS_MY_BILLER_EDIT,
		SETTINGS_MY_BILLER_DELETE,
		
		// SETTINGS MYPAYEE
		SETTINGS_MY_PAYEE_ADD,
		SETTINGS_MY_PAYEE_EDIT,
		SETTINGS_MY_PAYEE_DELETE,
		
		// SETTINGS MYMERCHANT
		SETTINGS_MY_MERCHANT_ADD,
		SETTINGS_MY_MERCHANT_EDIT,
		SETTINGS_MY_MERCHANT_DELETE,
		
		
		SETTINGS_SYS_MOB_NUM,
		SETTINGS_OTP_CONF,
		SETTINGS_CHANGE_PIN_LOGIN,
		SETTINGS_CHANGE_PIN_TRANSACTION,
		SETTINGS_CREATE_PIN_TRANSACTION,
		SETTINGS_CREATE_PIN_WALLET,
		SETTINGS_CHANGE_PIN_WALLET,
		SETTINGS_SHOW_WALLET,
		SETTINGS_RECOVER_SETTING,
		SETTINGS_LAST_5_TRANS,
		
		SETTINGS_MMID_GENERATE,
		SETTINGS_MMID_RETRIEVE,
		SETTINGS_MMID_CHANGE,
		SETTINGS_MMID_SHOW,
		SETTINGS_FOREX_BENEFICIARY_ADD,
		SETTINGS_FOREX_BENEFICIARY_EDIT,
		SETTINGS_FOREX_BENEFICIARY_DELETE,
		
		// MONEY TRANSFER FOR OXIGEN - DECRYPTION ISSUE
		MONEY_TRANSFER,
		
		// MONEY TRANSFER FOR MOM - DECRYPTION ISSUE
		BALANCE_TRANSFER,
	
		// DECRYPTION ISSUE IN OTHER PAYMENTS 
		OTH_PAY_RET_B_TO_B,
		OTH_PAY_RET_B_TO_CC,
		OTH_PAY_RET_B_TO_IMPS,
		OTH_PAY_RET_B_TO_WALLET,
		OTH_PAY_RET_CC_TO_B,
		OTH_PAY_RET_CC_TO_CC,
		OTH_PAY_RET_CC_TO_IMPS,
		OTH_PAY_RET_CC_TO_WALLET,
		OTH_PAY_RET_IMPS_TO_B,
		OTH_PAY_RET_IMPS_TO_CC,
		OTH_PAY_RET_IMPS_TO_IMPS,
		OTH_PAY_RET_IMPS_TO_WALLET,
		OTH_PAY_RET_WALLET_TO_B,
		OTH_PAY_RET_WALLET_TO_CC,
		OTH_PAY_RET_WALLET_TO_IMPS,
		OTH_PAY_RET_WALLET_TO_WALLET,
		OTH_PAY_INDI_B_TO_B,
		OTH_PAY_INDI_B_TO_CC,
		OTH_PAY_INDI_B_TO_IMPS,
		OTH_PAY_INDI_B_TO_WALLET,
		OTH_PAY_INDI_CC_TO_B,
		OTH_PAY_INDI_CC_TO_CC,
		OTH_PAY_INDI_CC_TO_IMPS,
		OTH_PAY_INDI_CC_TO_WALLET,
		OTH_PAY_INDI_IMPS_TO_B,
		OTH_PAY_INDI_IMPS_TO_CC,
		OTH_PAY_INDI_IMPS_TO_IMPS,
		OTH_PAY_INDI_IMPS_TO_WALLET,
		OTH_PAY_INDI_WALLET_TO_B,
		OTH_PAY_INDI_WALLET_TO_CC,
		OTH_PAY_INDI_WALLET_TO_IMPS,
		OTH_PAY_INDI_WALLET_TO_WALLET,
		WALLET_BALANCE_TRANSFER
}
	
	private String simVersion;
	private String transactionId;
	private ServiceType serviceType;
	private BankAccount payerBankAccount;
	private BankAccount payeeBankAccount;
	private IMPS payerIMPS;
	private IMPS payeeIMPS;                                                                                                                                                                          
	private Wallet payerWallet;
	private Wallet payeeWallet;
	private CreditCard payerCC;
	private CreditCard payeeCC;
	private ProvidersData provider;
	private Cheque cheque;
	private Settings settings;
	private Agent agent;
	private Integer amount;
	private TransactionData transactionData; 
	private ServiceCall serviceCall; 
	private String msisdn;
	private BridgeDataResponse bridgeResponse;
	private PartnerData callablePartner;
	private Integer masterVersionId;
	private Integer hostSubVersionId;
	
	public PartnerData getCallablePartner() {
		return callablePartner;
	}

	public void setCallablePartner(PartnerData callablePartner) {
		this.callablePartner = callablePartner;
	}

	public BridgeDataResponse getBridgeResponse() {
		return bridgeResponse;
	}

	public void setBridgeResponse(BridgeDataResponse bridgeResponse) {
		this.bridgeResponse = bridgeResponse;
	}

	public Agent getAgent() {
		return agent;
	}

	public void setAgent(Agent agent) {
		this.agent = agent;
	}
	public ServiceCall getServiceCall() {
		return serviceCall;
	}

	public void setServiceCall(ServiceCall serviceCall) {
		this.serviceCall = serviceCall;
	}

	public TransactionData getTransactionData() {
		return transactionData;
	}

	public void setTransactionData(TransactionData transactionData) {
		this.transactionData = transactionData;
	}

	public Integer getAmount() {
		return amount;
	}

	public void setAmount(Integer amount) {
		this.amount = amount;
	}

	public ServiceType getServiceType() {
		return serviceType;
	}

	public void setServiceType(ServiceType serviceType) {
		this.serviceType = serviceType;
	}

	public BankAccount getPayerBankAccount() {
		return payerBankAccount;
	}

	public void setPayerBankAccount(BankAccount payerBankAccount) {
		this.payerBankAccount = payerBankAccount;
	}

	public BankAccount getPayeeBankAccount() {
		return payeeBankAccount;
	}

	public void setPayeeBankAccount(BankAccount payeeBankAccount) {
		this.payeeBankAccount = payeeBankAccount;
	}

	public IMPS getPayeeIMPS() {
		return payeeIMPS;
	}

	public void setPayeeIMPS(IMPS payeeIMPS) {
		this.payeeIMPS = payeeIMPS;
	}

	public IMPS getPayerIMPS() {
		return payerIMPS;
	}

	public void setPayerIMPS(IMPS payerIMPS) {
		this.payerIMPS = payerIMPS;
	}

	public Wallet getPayerWallet() {
		return payerWallet;
	}

	public void setPayerWallet(Wallet payerWallet) {
		this.payerWallet = payerWallet;
	}

	public Wallet getPayeeWallet() {
		return payeeWallet;
	}

	public void setPayeeWallet(Wallet payeeWallet) {
		this.payeeWallet = payeeWallet;
	}

	public CreditCard getPayerCC() {
		return payerCC;
	}

	public void setPayerCC(CreditCard payerCC) {
		this.payerCC = payerCC;
	}

	public CreditCard getPayeeCC() {
		return payeeCC;
	}

	public void setPayeeCC(CreditCard payeeCC) {
		this.payeeCC = payeeCC;
	}

	public ProvidersData getProvider() {
		return provider;
	}

	public void setProvider(ProvidersData provider) {
		this.provider = provider;
	}

	public Cheque getCheque() {
		return cheque;
	}

	public void setCheque(Cheque cheque) {
		this.cheque = cheque;
	}

	public Settings getSettings() {
		return settings;
	}

	public void setSettings(Settings settings) {
		this.settings = settings;
	}
	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getSimVersion() {
		return simVersion;
	}

	public void setSimVersion(String simVersion) {
		this.simVersion = simVersion;
	}
	public String getMsisdn() {
		return msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	public HostSubVersionData getHostSubVersionData() {
		return hostSubVersionData;
	}

	public void setHostSubVersionData(HostSubVersionData hostSubVersionData) {
		this.hostSubVersionData = hostSubVersionData;
	}

	public Integer getMasterVersionId() {
		return masterVersionId;
	}

	public void setMasterVersionId(Integer masterVersionId) {
		this.masterVersionId = masterVersionId;
	}

	public Integer getHostSubVersionId() {
		return hostSubVersionId;
	}

	public void setHostSubVersionId(Integer hostSubVersionId) {
		this.hostSubVersionId = hostSubVersionId;
	}


}
