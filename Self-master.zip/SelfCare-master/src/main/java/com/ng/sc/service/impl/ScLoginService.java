package com.ng.sc.service.impl;

import java.math.BigInteger;
import java.net.InetAddress;
import java.security.SecureRandom;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;

import com.ng.sb.common.dataobject.LoginData;
import com.ng.sb.common.dataobject.LogoutData;
import com.ng.sb.common.dataobject.RequestObject;
import com.ng.sb.common.dataobject.ResponseObject;
import com.ng.sb.common.dataobject.SubscriberData;
import com.ng.sb.common.dataobject.UserAccountData;
import com.ng.sb.common.model.AccountLoginInfo;
import com.ng.sb.common.model.AccountSessionInfoSelfCare;
import com.ng.sb.common.model.CountryCode;
import com.ng.sb.common.model.SecurityQuestion;
import com.ng.sb.common.model.SignUpOtp;
import com.ng.sb.common.model.Subscriber;
import com.ng.sb.common.model.SysAccountGroup;
import com.ng.sb.common.model.SysAccountType;
import com.ng.sb.common.util.ISMSUtility;
import com.ng.sb.common.util.SystemConstant;
import com.ng.sb.common.util.ThreeDESEncryption;
import com.ng.sc.dao.IScLoginDAO;
import com.ng.sc.dao.IScMenuDAO;
import com.ng.sc.dto.LoginRequest;
import com.ng.sc.dto.LoginResponse;
import com.ng.sc.service.IScLoginService;
import com.ng.sc.service.ISchedulerService;
import com.ng.sc.utils.ScSystemConstant;

/**
 * 
 * @author 
 *
 */
@Service
public class ScLoginService extends SelfCareService implements IScLoginService {

	private static final Logger LOGGER = LoggerFactory.getLogger(ScLoginService.class);
	@Autowired
	IScLoginDAO loginDAO;
	@Autowired
	IScMenuDAO menuDao;
	@Autowired
	ISchedulerService iSchedulerService;
	@Autowired
	ISMSUtility smsUtility;
	@Autowired
	@Qualifier("disabledlable")
	private MessageSource disabledlableSource;
	private  SecureRandom random = new SecureRandom();
	private static final String FAIL_VIEW ="login";
	private static final String SUCESS_VIEW ="homepage";
	private static final String LOGOUT_VIEW ="transferToLoginPage";
	
	@Transactional
	@Override
	public SubscriberData submitUserCreationData(SubscriberData subscriberData)  {
		LOGGER.info("******Start Method submitUserCreationData() in ScLoginService ");
		SubscriberData subscriberData1=new SubscriberData();
		String errorMsg="";
		Subscriber subscriber = new Subscriber();
		try{
		Subscriber subscriberInfo = loginDAO.accountByLoginInfo(subscriberData.getMobile());
		Date dob=convertStringToSqlDate(subscriberData.getDob());
		if(subscriberInfo!=null){
		if(subscriberInfo.getUserPassword()==null && subscriberInfo.getFirstTimeLogin()==null) {
			subscriber.setName(subscriberData.getName());
			if(!StringUtils.isEmpty(subscriberData.getLastName())){
			subscriber.setSurname(subscriberData.getLastName());
			}else{
				subscriber.setSurname("");
			}
			subscriber.setEmailId(subscriberData.getEmailId());
			subscriber.setUserPassword(ThreeDESEncryption.getHashedString(subscriberData.getUserPassword()));
			subscriber.setDateOfBirth(dob);
			subscriber.setHsvId(null);
			subscriber.setMsisdn(subscriberData.getMobile());
			subscriber.setStatus(SystemConstant.ACTIVE);
			subscriber.setInvalidLoginCount(0);
			subscriber.setFirstTimeLogin(true);
			subscriber.setPasswordDate(new java.util.Date());
			subscriber.setAddDate(new java.util.Date());
			subscriber.setSubscriberType(SystemConstant.CUST_O);
			loginDAO.updateSubscriberInfo(subscriber);
			subscriberData1.setMsg(SystemConstant.USER_CREATE_SUCCESS);
		}	
		}
		else{
			
		
		subscriber.setName(subscriberData.getName());
		if(!StringUtils.isEmpty(subscriberData.getLastName())){
		subscriber.setSurname(subscriberData.getLastName());
		}else{
			subscriber.setSurname("");
		}
		subscriber.setEmailId(subscriberData.getEmailId());
		subscriber.setUserPassword(ThreeDESEncryption.getHashedString(subscriberData.getUserPassword()));
		subscriber.setDateOfBirth(dob);
		subscriber.setMsisdn(subscriberData.getMobile());
		subscriber.setStatus(SystemConstant.ACTIVE);
		subscriber.setInvalidLoginCount(0);
		subscriber.setFirstTimeLogin(true);
		subscriber.setPasswordDate(new java.util.Date());
		subscriber.setAddDate(new java.util.Date());
		subscriber.setHsvId(null);
		subscriber.setSubscriberType(SystemConstant.CUST_O);
		subscriber = loginDAO.saveUserCreation(subscriber);
		if (subscriber.getId() != null) {
			subscriberData1.setMsg(SystemConstant.USER_CREATE_SUCCESS);
			subscriberData1.setErrorMsg("");
		} else {
			subscriberData1.setErrorMsg(errorMsg);
			subscriberData1.setMsg("");
		}
	}
		}catch(Exception e){
			LOGGER.info(""+e);
		}
		LOGGER.info("******Successfully executed submitUserCreationData() in ScLoginService ");
		return subscriberData1;
	}
	
	@Override
	public String generateEncryptedPassword(String userPassword)  {
		LOGGER.info("******Start Method generateEncryprPassword() in ScLoginService ");
		ThreeDESEncryption threeDESEncryption = new ThreeDESEncryption();
		String encryptPassword = threeDESEncryption.encrypt(userPassword,getPlatformLoginData().getSysPass3desKey());
		
		LOGGER.info("******Successfully executed generateEncryprPassword() in ScLoginService ");
		return encryptPassword;
	}

	@Override
	public Map getCountryCodeMap() {
		
		Map<Integer, String> countryCodeMap = new HashMap<>();
		List<CountryCode> codeList=null;
		try {
			codeList = loginDAO.getCountryCodeMap();
		} catch (Exception e) {
			LOGGER.info("******exception in executed getCountryCodeMap() in LoginService "+e);
		}
		for (CountryCode codList : codeList) {
			countryCodeMap.put(codList.getId(), codList.getCode());
		}
		LOGGER.info("******Successfully executed getCountryCodeMap() in LoginService ");
		return countryCodeMap;
	}
	
	@Override
	@Transactional
	public LoginData validateAccount(LoginData loginData) 
	{
		LOGGER.debug("validate Account");
		int groupId = 0;
		try
		{
			String fooResourceUrl  = getPlatformLoginData().getSelfCareloginUrl();
		   RestTemplate restTemplate = new RestTemplate();
		   LoginRequest  loginRequst = new LoginRequest();
		   String accountpassword = ThreeDESEncryption.getHashedString(loginData.getPassword());
		   
		   
		   loginRequst.setChannelId(1);	
		   loginRequst.setUserTypeId(1);
		   loginRequst.setUserId(loginData.getUsername());
		   loginData.setSubscriberMobNo(loginData.getUsername());
		   loginRequst.setPasswd(accountpassword);
		   ResponseEntity<LoginResponse> response = restTemplate.postForEntity(fooResourceUrl, loginRequst, LoginResponse.class);
		   LoginResponse loginResponse = response.getBody();
		   loginResponse.getStatus();
			
		if(loginResponse.getStatus()==200)
		{	
			loginData.setAccountTypeId(loginResponse.getUserId());
			loginData.setUsername(loginResponse.getUserName());
			loginData.setKey(loginResponse.getKey());
			loginData.setTokenId(loginResponse.getTokenId());
			loginData.setMessage(loginResponse.getMessage());
			
			/**
			 * checking the user is locked or not
			 */
		
					LOGGER.info("******Valid User *******");
					
					if(setAcountSessionInfo(loginResponse.getUserId(),loginData))   
					{	
						
						loginData.setUsername(loginData.getUsername());
						loginData.setMessage(loginResponse.getMessage());
						loginData.setView(SUCESS_VIEW);
					
					}
				  else
				  {
					  loginData.setView(FAIL_VIEW);
					  loginData.setMessage(loginResponse.getMessage());
					  LOGGER.debug("loginData view::"+loginData.getView()+"login Data message::"+loginData.getStatusMessage());
				  }
				}
				
				
			
		
		else
		{	
			loginData.setView(FAIL_VIEW);
			if(loginResponse.getStatus()==401){
			loginData.setMessage("Mobile Number or Password is incorrect");
			}
			else{
				loginData.setMessage(loginResponse.getMessage());
			}
			LOGGER.debug("loginData view::"+loginData.getView()+"login Data message::"+loginData.getStatusMessage());
		}
		}
		catch(Exception exception){
			LOGGER.debug("Exception in catch of try block::"+exception);
			
		}
		
		loginData.setGroupId(groupId);
		return loginData;
	}

	
	@Override
	public List accountGroup()
	{
		LOGGER.debug("Account Type List");
		List passedMap = new ArrayList();
		List<SysAccountGroup> sysAccountTypes = loginDAO.accountGroupList();
		for(SysAccountGroup sysAccountType : sysAccountTypes)
		{
			passedMap.add(sysAccountType.getGroupName());
		}
				return passedMap;
	}
	
	
	@Override
	public Map<Integer, String> accountTypeMap(String accountType) {
		LOGGER.debug("Account Type List");
		Map<Integer, String> passedMap = new TreeMap<>();
		List<SysAccountGroup> sysAccountGroups = loginDAO.SysAccountGroupByName(accountType);
		List<SysAccountType> sysAccountTypes =  loginDAO.accountById(sysAccountGroups.get(0).getId());
		for(SysAccountType sysAccountType : sysAccountTypes){
			passedMap.put(sysAccountType.getId(), sysAccountType.getAccountType());
		}
		return passedMap;
	}
	
	@Override
	public LoginData setViewMessage(LoginData loginData,String view,String message){
		LOGGER.debug("LoginServiceImpl setView_Message");
		loginData.setView(view);
		loginData.setStatusMessage(message);
		LOGGER.debug("LoginData  getView value::====>>>>"+loginData.getView()+"loginData getStatusMessage value::"+loginData.getStatusMessage());
		return loginData;
	}
	
	/**
	 * setting the account session info value
	 * @param accountInfo
	 * @return boolean
	 */
	public boolean  setAcountSessionInfo(Integer accountInfo,LoginData loginData)
	{	
		boolean ststus = false;
			List<AccountSessionInfoSelfCare> sessionInfos;
			AccountSessionInfoSelfCare sessionInfo;
			String userIp=null;
			Date date = new Date();
			long time=date.getTime();
			Date afterAddingTenMins=new Date(time + (SystemConstant.SESSION_TIME * SystemConstant.ONE_MINUTE_IN_MILLIS));
			try{
				userIp = InetAddress.getLocalHost().getHostAddress();
			}catch(Exception e){
				LOGGER.info(""+e);
			}
			sessionInfos=loginDAO.sessionInfo(accountInfo);
				if(sessionInfos.size()<SystemConstant.SESSION_COUNT){
					sessionInfo = new AccountSessionInfoSelfCare();
					sessionInfo.setAccountId(new Subscriber(accountInfo));
					sessionInfo.setIntime(CurrentDate());
					sessionInfo.setOuttime(afterAddingTenMins);
					sessionInfo.setRandSessionKey(nextSessionId());
					sessionInfo.setIpAddress(userIp);
					loginData.setSessionId(sessionInfo.getRandSessionKey());
					ststus = loginDAO.insertAccountSessionInfo(sessionInfo);
				}
			else{
				for(AccountSessionInfoSelfCare info : sessionInfos){
					Date outTime = info.getOuttime();
					if(outTime.compareTo(new Date())<0){
						sessionInfo = info;
						sessionInfo.setAccountId(new Subscriber(accountInfo));
						sessionInfo.setIntime(CurrentDate());
						sessionInfo.setOuttime(afterAddingTenMins);
						sessionInfo.setRandSessionKey(nextSessionId());
						sessionInfo.setIpAddress(userIp);
						loginData.setSessionId(sessionInfo.getRandSessionKey());
						ststus = loginDAO.insertAccountSessionInfo(sessionInfo);
						break;
					}
					
				}
				
			}
		
		
		LOGGER.debug("insertAcountSessionInfo id::====>>>>");
		return ststus;
	}
	
     /**
      * generating the random alphanumeric session key
      * @return String
      */
	 public String nextSessionId() 
	 {
	     return new BigInteger(130, random).toString(32);
	 }
	 
	/**
	 * generating the CurrentDate
	 * @return Date
	 */
	 public Date CurrentDate()
	 {
		 return new Date();
	 }
	 
	 /**
	  * get the key value from message.properties file
	  * @param key
	  * @return String
	  */
	@Override
	public LogoutData logout(LoginData loginData, HttpSession session)  {
		LOGGER.debug("******** Logout() starts executing in ScLoginServiceImpl ***********");
		LogoutData logoutData = new LogoutData();		
		try{
			LOGGER.debug("********** getting AccountSessionInfo ***********");
			
			String logoutUrl  = getPlatformLoginData().getLogoutUrl();
			   RestTemplate restTemplate = new RestTemplate();
			   RequestObject  loginRequst = new RequestObject();
			   
			   String tokenId=(String)session.getAttribute(ScSystemConstant.TOKENID);
			   
			   loginRequst.setChannelId(3);	
			   loginRequst.setTokenId(tokenId);
			   ResponseEntity<ResponseObject> response = restTemplate.postForEntity(logoutUrl, loginRequst, ResponseObject.class);
			   ResponseObject transactionResponse = response.getBody();
			
			   if(transactionResponse.getStatus()==200){
				   logoutData.setView(LOGOUT_VIEW);
					logoutData.setStatusMessage("Logout Successfully");
			   }
			
		}
		catch(Exception e){
			logoutData=null;
			LOGGER.info("Exception occured in Logout() in ScLoginServiceImpl :  "+e);
		
		}
		return logoutData;
	}
	
	
public LoginData getSessionInfo(HttpSession session) {
		
		LoginData loginData = (LoginData) session.getAttribute("loginData");
		AccountSessionInfoSelfCare accountSessionInfo;
		try{
			accountSessionInfo = loginDAO.accountSessionInfo(loginData);
		
			if(accountSessionInfo.getOuttime().compareTo(new Date())>0){
				Date date = new Date();
				long time=date.getTime();
				Date afterAddingTenMins=new Date(time + (SystemConstant.SESSION_TIME * SystemConstant.ONE_MINUTE_IN_MILLIS));
				accountSessionInfo.setOuttime(afterAddingTenMins);
				loginData.setSessionInfo(true);
				loginDAO.insertAccountSessionInfo(accountSessionInfo);
			}
			
			else{
				loginData.setSessionInfo(false);
				loginData.setStatusMessage("session not");
				loginData.setView(SystemConstant.LOGIN_TRANSFER_PAGE);
			}
		}
		catch(Exception e){
			LOGGER.info(""+e);
		}
		return loginData;
	}


@Override
public Map<?,?> getSecurityQuestion() {
		LOGGER.info("******Start Method getSecurityQuestion() ");
		Map<Integer, String> questionMap = new HashMap<>();
		try{
		List<SecurityQuestion> question= loginDAO.getSecurityQuestion();
		for (SecurityQuestion securityQuestion : question) {
			questionMap.put(securityQuestion.getId(), securityQuestion.getSecuritQuestion());
		}
		}
		catch(Exception e){
			LOGGER.info(""+e);
		}
		LOGGER.info("******Successfully executed getSecurityQuestion() in Service ");
		return questionMap;
	
}


@Override
public Integer validatePassExp(String username, Date date)  {
	AccountLoginInfo dayscount=null;
	 long datediff=0;
	try {
		 dayscount= loginDAO.validatePassExp(username);
		 datediff=Math.abs(date.getTime()-dayscount.getPasswordDate().getTime());
		 datediff=datediff/(1000 * 60 * 60 * 24);
		
		
	} catch (Exception e) {
		LOGGER.info(""+e);
	}
		
	return (int)datediff;
}
private Integer generateOTP()
{
	Random ran = new Random();
	return 100000 + ran.nextInt(899999);
}

@Override
@Transactional
public Integer getOtpOnSignUp(String mobileNo)  {
	Integer otp = null;
	try{
		otp = generateOTP();
		//smsUtility.sendHttpResponse(mobileNo,"Enter One Time Password(OTP) "+otp+" sent to your mobile number "+mobileNo+".");
		smsUtility.sendMessageToTafaniUsers(mobileNo,"Enter One Time Password(OTP) "+otp+" sent to your mobile number "+mobileNo+".");
		iSchedulerService.schedule(SystemConstant.TIMEOUT,otp);
	}catch(Exception ex){
		LOGGER.debug("Exception caught in getSignUpOtp() method of ScLoginService "+ex);
	}
	return otp;
}

@Override
public List getAllRoleAccountList(Integer loginWeightage) {
	LOGGER.info("******Start Method getAllRoleAccountList() in ScLoginService ");
	List<UserAccountData> accountTypeList= new ArrayList<>();
	try{
	List<SysAccountType> sysAccountTypeList = loginDAO.getRoleAccountistByWeightage(loginWeightage);
	for (SysAccountType sysAccountType : sysAccountTypeList) {
		UserAccountData userAccountData = new UserAccountData();
		if(sysAccountType.getGroupId().getId()!=7 && sysAccountType.getGroupId().getId()!=8){
			userAccountData.setAccountTypeId(sysAccountType.getId() + "," + sysAccountType.getGroupId().getGroupCode());
			userAccountData.setName(sysAccountType.getAccountType());
			accountTypeList.add(userAccountData);
		}
	}
	}
	catch(Exception e){
		LOGGER.info(""+e);
	}
	LOGGER.info("******Successfully executed getAllRoleAccountList() in ScLoginService ");
	return accountTypeList;
}

@Override
public void saveSignupDetails(SubscriberData subscriberData, Integer otp) {
	LOGGER.info("*****Start Method saveSignupDetails() in ScLoginService ");
	SignUpOtp signupDetails=null;
	try{
		signupDetails=new SignUpOtp();	
		signupDetails.setMobileNumber(subscriberData.getMobile());
		signupDetails.setOtpp(otp);
		signupDetails.setCurrentTime(new Date());
		signupDetails.setStatus(1);
		signupDetails.setPassword(ThreeDESEncryption.getHashedString(subscriberData.getUserPassword()));
		signupDetails.setEmail(subscriberData.getEmailId());
		loginDAO.saveSignupDetails(signupDetails);
	}catch(Exception e){
		LOGGER.info("Start Method saveSignupDetails() in ScLoginService "+e);
	}
	
}

@Override
public Integer getActiveOtp(String mobile) {
	Integer otp=null;
	try{
	SignUpOtp signUpInfo=loginDAO.getSignUpinfo(mobile);
	otp=signUpInfo.getOtpp();
	}catch(Exception e){
		LOGGER.info(""+e);
	}
	return otp;
}

@Override
@Transactional
public void updateSignUpDetails(String mobile){
	try{
		loginDAO.updateSignUpDetails(mobile);
	}catch(Exception e){
		LOGGER.info(""+e);
	}

	
}

@Override
@Transactional
public void updateTimeoutOtp(int otp) {
	try{
		loginDAO.updateTimeoutOtp(otp);
	}catch(Exception e){
		LOGGER.info(""+e);
	}
	
}
public Date convertStringToSqlDate(String dob) throws Exception {
	java.sql.Date sqlDate = null;
	try {
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		java.util.Date utilDate = df.parse(dob);
		sqlDate = new java.sql.Date(utilDate.getTime());

	} catch (Exception e) {
		LOGGER.info("Exception occurred in convertStringToSqlDate() method in UserMgmntService--->" + e);
	}
	return sqlDate;

}



}
