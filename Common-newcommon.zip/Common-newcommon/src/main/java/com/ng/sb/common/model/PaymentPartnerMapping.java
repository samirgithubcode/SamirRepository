package com.ng.sb.common.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
*
* @author rishi
*/
@Entity
@Table(name = "PaymentPartnerMapping")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "PaymentPartnerMapping.findAll", query = "SELECT p FROM PaymentPartnerMapping p"),
    @NamedQuery(name = "PaymentPartnerMapping.findByHsvId", query = "SELECT p FROM PaymentPartnerMapping p WHERE p.hsvId = :hsvId")
})
public class PaymentPartnerMapping {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;   
    
    @Column(name = "providerid", nullable = false)
    private Integer providerId;   
    
    @Column(name = "paymentpartnercode", nullable = false)
    private Integer paymentPartnerCode;   
    
    @Column(name = "hsvid", nullable = false)
    private Integer hsvId;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getProviderId() {
		return providerId;
	}

	public void setProviderId(Integer providerId) {
		this.providerId = providerId;
	}

	public Integer getPaymentPartnerCode() {
		return paymentPartnerCode;
	}

	public void setPaymentPartnerCode(Integer paymentPartnerCode) {
		this.paymentPartnerCode = paymentPartnerCode;
	}

	public Integer getHsvId() {
		return hsvId;
	}

	public void setHsvId(Integer hsvId) {
		this.hsvId = hsvId;
	}   
}