package com.ng.pnb.invoker.util;

import java.util.List;

public class Status {

	List<Message> message;

	public List<Message> getMessage() {
		return message;
	}

	public void setMessage(List<Message> message) {
		this.message = message;
	}
}
