/**
 * 
 */
package com.ng.sb.common.exception;

/**
 * @author gaurav
 *
 */
public class BridgeObjectDataException extends Exception {
	private static final long serialVersionUID = 1L;
	
	public BridgeObjectDataException(String message){
		super(message);
	}
}