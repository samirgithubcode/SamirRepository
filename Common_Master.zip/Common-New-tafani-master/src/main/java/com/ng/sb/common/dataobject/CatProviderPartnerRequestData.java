package com.ng.sb.common.dataobject;

public class CatProviderPartnerRequestData extends BaseObjectData {

	private static final long serialVersionUID = 1L;
	
	private Integer hostSubVersionId;
	private String mappingType;
	private String relationShipType;
	

	public Integer getHostSubVersionId() {
		return hostSubVersionId;
	}

	public void setHostSubVersionId(Integer hostSubVersionId) {
		this.hostSubVersionId = hostSubVersionId;
	}

	

	public String getMappingType() {
		return mappingType;
	}

	public void setMappingType(String mappingType) {
		this.mappingType = mappingType;
	}

	public String getRelationShipType() {
		return relationShipType;
	}

	public void setRelationShipType(String relationShipType) {
		this.relationShipType = relationShipType;
	}
	
	
	
	
	
	
	
	
}
