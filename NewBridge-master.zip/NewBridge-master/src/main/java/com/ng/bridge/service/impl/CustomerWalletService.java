/**
 * 
 */
package com.ng.bridge.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ng.bridge.service.ICustomerWalletService;
import com.ng.bridge.service.IPartnerManagementService;
import com.ng.bridge.util.NewConstants;
import com.ng.sb.common.dataobject.BridgeDataObject;
import com.ng.sb.common.exception.BridgeObjectDataException;
import com.ng.sb.common.util.SystemConstant;

/**
 * @author gaurav
 *
 */
@Service(value=SystemConstant.BRIDGE_CUST_SERVICE)
public class CustomerWalletService extends WalletService implements	ICustomerWalletService {

	private static final Logger LOGGER = LoggerFactory.getLogger(CustomerWalletService.class);
	@Autowired
	IPartnerManagementService ipartnerManagementService;
	



	@Override
	public BridgeDataObject fundTransferBankToWallet(BridgeDataObject bridgeDataObject) {
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge CustomerWalletService -  fundTransferBankToWallet method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in fundTransferBankToWallet in CustomerWalletService:"+ e);
		}
		return null;
	}
	

	/* (non-Javadoc)
	 * @see com.ng.transaction.service.ICustomerWalletService#checkBalance(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject fundTransferWalletToWallet(BridgeDataObject bridgeDataObject) {
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge CustomerWalletService -  fundTransferWalletToWallet method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in fundTransferWalletToWallet in CustomerWalletService:"+ e);
		}
		return null;
	}
	/* (non-Javadoc)
	 * @see com.ng.transaction.service.ICustomerWalletService#cashOut(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject cashOut(BridgeDataObject bridgeDataObject) {
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge CustomerWalletService -  cashOut method. ",NewConstants.TRANSACTIONID);
		try {
			return ipartnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in cashOut in CustomerWalletService:"+ e);
		}
		return null;
	}
	@Override
	public BridgeDataObject checkBalance(BridgeDataObject bridgeDataObject) {
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge CustomerWalletService -  checkBalance method. ",NewConstants.TRANSACTIONID);
		try {
			return ipartnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in checkBalance in CustomerWalletService:"+ e);
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ng.transaction.service.ICustomerWalletService#topUpOnline(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject topUpOnline(BridgeDataObject bridgeDataObject) {
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge CustomerWalletService -  topUpOnline method. ",NewConstants.TRANSACTIONID);
		try {
			return ipartnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in topUpOnline in CustomerWalletService:"+ e);
		}
		return null;
	}



}
