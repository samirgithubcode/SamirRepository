package com.ng.sb.common.dataobject;


public class PinStatusData {
	private String serialNo;
	private String pinStatus;
	private Integer denomination;
	private String portal;
	private String ip;
	private String usedDate;
	private String creationDate;
	private String expiryDate;
	private String portalTxnStatus;
	
	public String getSerialNo() {
		return serialNo;
	}
	public void setSerialNo(String serialNo) {
		this.serialNo = serialNo;
	}
	public String getPinStatus() {
		return pinStatus;
	}
	public void setPinStatus(String pinStatus) {
		this.pinStatus = pinStatus;
	}
	public Integer getDenomination() {
		return denomination;
	}
	public void setDenomination(Integer denomination) {
		this.denomination = denomination;
	}
	public String getPortal() {
		return portal;
	}
	public void setPortal(String portal) {
		this.portal = portal;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public String getUsedDate() {
		return usedDate;
	}
	public void setUsedDate(String usedDate) {
		this.usedDate = usedDate;
	}
	public String getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(String date) {
		this.creationDate = date;
	}
	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	public String getPortalTxnStatus() {
		return portalTxnStatus;
	}
	public void setPortalTxnStatus(String portalTxnStatus) {
		this.portalTxnStatus = portalTxnStatus;
	}
}
