/**
 * 
 */
package com.ng.transaction.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ng.sb.common.cache.MemCacheManager;
import com.ng.sb.common.cache.MemCacheUtils;
import com.ng.sb.common.dataobject.BridgeDataObject;
import com.ng.sb.common.dataobject.BridgeDataObject.ServiceType;
import com.ng.sb.common.dataobject.HostSubVersionData;
import com.ng.sb.common.dataobject.RequestObject;
import com.ng.sb.common.dataobject.ResponseObject;
import com.ng.sb.common.dataobject.TransactionData;
import com.ng.sb.common.dataobject.UserAccountData;
import com.ng.sb.common.dataobject.WalletData;
import com.ng.sb.common.model.CustomerWallets;
import com.ng.sb.common.model.Partner;
import com.ng.sb.common.util.BaseSystemConstant;
import com.ng.sb.common.util.ErrorCodes;
import com.ng.sb.common.util.ExceptionUtils;
import com.ng.sb.common.util.KeyEncryptionUtils;
import com.ng.sb.common.util.SystemConstant;
import com.ng.transaction.dao.ITransactionDAO;
import com.ng.transaction.data.WalletRequest;
import com.ng.transaction.service.ITransactionService;
import com.ng.transaction.service.impl.CacheLoader;
import com.ng.transaction.util.CommonUtils;

/**
 * @author gopal
 *
 */
@RestController
@RequestMapping("Transaction/services/wallet/")
public class WalletController {

	private static final Logger LOGGER = LoggerFactory.getLogger(WalletController.class);
	
	@Autowired
    private MemCacheManager cacheManager;
	
	@Autowired
	ITransactionService transactionService;
	
	@Autowired
	CacheLoader cacheLoader;
	
	@Autowired
	ITransactionDAO transactionDAO;
	
	 @RequestMapping(value = "/balanceEnquiry", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	 public @ResponseBody ResponseObject balanceEnquiry(@RequestBody RequestObject requestObject, HttpServletRequest request) 
	 {
		 LOGGER.info("************* balanceEnquiry() starts executing in WalletController **************");
		 ResponseObject responseObject = new ResponseObject();
		 
		 BridgeDataObject bridgeData = new BridgeDataObject();
			/* 
			 * Get Agent details from tokenId
			 * requestObject.getTokenId()
			 * 
			 */
		 	WalletRequest walletRequest = null;
			Object payload =  requestObject.getPayload();
			UserAccountData accountData = null;
			try
			{
				//Check token Validity
				accountData = cacheManager.getFromCache(requestObject.getTokenId(), UserAccountData.class, MemCacheUtils.AUTHTOKENCACHE);
				
				responseObject = CommonUtils.validateRequest(accountData, requestObject, request);
				
				if(responseObject.getStatus() != null)
					return responseObject;
				
				walletRequest = KeyEncryptionUtils.jsonStringToObject(KeyEncryptionUtils.decryptUsingKey(accountData.getSecretKey(), payload), WalletRequest.class);
				
				responseObject = CommonUtils.validateRequestData(walletRequest, requestObject, request);
				  
				if(responseObject.getStatus() != null)
					return responseObject;
				  
				Map<HostSubVersionData, HostSubVersionData>  hostSubVersionMap = cacheLoader.getHostSubVersionMap();
				HostSubVersionData hostSubVersionData = hostSubVersionMap.get(new HostSubVersionData(1));

				
				TransactionData transactionData = CommonUtils.getTransactionData(accountData);
				
				bridgeData.setServiceType(ServiceType.MWALLET_CUST_CHK_BAL);
				
				bridgeData = CommonUtils.setWalletDetails(bridgeData, walletRequest);
				
				bridgeData.getPayerWallet().setMsisdn(accountData.getMobileNo());
				
				bridgeData.setHostSubVersionData(hostSubVersionData);
				
				bridgeData.setTransactionData(transactionData);
				
				bridgeData = transactionService.callService(bridgeData);
				
				String responseMsg = null;
				
				if(bridgeData.getBridgeResponse() != null)
					responseMsg = bridgeData.getBridgeResponse().getResponseMsg();
				
				responseObject = CommonUtils.setStatusCode(bridgeData.getBridgeResponse(),responseObject);
				
				responseObject.setMessage(responseMsg);
				
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), "com.ng");
			
			//UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			responseObject.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseObject.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e.getMessage());
		}
		return responseObject;
	 }
	 
	 
	 @RequestMapping(value = "/merchantBalanceEnquiry", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	 public @ResponseBody ResponseObject merchantBalanceEnquiry(@RequestBody RequestObject requestObject, HttpServletRequest request) 
	 {
		 LOGGER.info("************* balanceEnquiry() starts executing in WalletController **************");
		 ResponseObject responseObject = new ResponseObject();
		 
		 BridgeDataObject bridgeData = new BridgeDataObject();
			/* 
			 * Get Agent details from tokenId
			 * requestObject.getTokenId()
			 * 
			 */
		 	WalletRequest walletRequest = null;
			Object payload =  requestObject.getPayload();
			UserAccountData accountData = null;
			try
			{
				//Check token Validity
				accountData = cacheManager.getFromCache(requestObject.getTokenId(), UserAccountData.class, MemCacheUtils.AUTHTOKENCACHE);
				
				responseObject = CommonUtils.validateRequest(accountData, requestObject, request);
				
				if(responseObject.getStatus() != null)
					return responseObject;
				
				walletRequest = KeyEncryptionUtils.jsonStringToObject(KeyEncryptionUtils.decryptUsingKey(accountData.getSecretKey(), payload), WalletRequest.class);
				
				responseObject = CommonUtils.validateRequestData(walletRequest, requestObject, request);
				  
				if(responseObject.getStatus() != null)
					return responseObject;
				  
				Map<HostSubVersionData, HostSubVersionData>  hostSubVersionMap = cacheLoader.getHostSubVersionMap();
				HostSubVersionData hostSubVersionData = hostSubVersionMap.get(new HostSubVersionData(1));

				
				TransactionData transactionData = CommonUtils.getTransactionData(accountData);
				
				bridgeData.setServiceType(ServiceType.MWALLET_CUST_CHK_BAL);
				
				bridgeData = CommonUtils.setWalletDetails(bridgeData, walletRequest);
				
				//bridgeData.getPayerWallet().setMsisdn(accountData.getMobileNo());
				
				bridgeData.setHostSubVersionData(hostSubVersionData);
				
				bridgeData.setTransactionData(transactionData);
				
				bridgeData = transactionService.callService(bridgeData);
				
				String responseMsg = null;
				
				if(bridgeData.getBridgeResponse() != null)
					responseMsg = bridgeData.getBridgeResponse().getResponseMsg();
				
				responseObject = CommonUtils.setStatusCode(bridgeData.getBridgeResponse(),responseObject);
				
				responseObject.setMessage(responseMsg);
				
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), "com.ng");
			
			//UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			responseObject.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseObject.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e.getMessage());
		}
		return responseObject;
	 }
	 
	 @RequestMapping(value = "/selfTopUpByBank", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	 public @ResponseBody ResponseObject selfWalletTopUp(@RequestBody RequestObject requestObject, HttpServletRequest request) 
	 {
		 LOGGER.info("************* balanceEnquiry() starts executing in WalletController **************");
		 ResponseObject responseObject = new ResponseObject();
		 
		 BridgeDataObject bridgeData = new BridgeDataObject();
			/* 
			 * Get Agent details from tokenId
			 * requestObject.getTokenId()
			 * 
			 */
		 	WalletRequest walletRequest = null;
			Object payload =  requestObject.getPayload();
			UserAccountData accountData = null;
			try
			{
				//Check token Validity
				accountData = cacheManager.getFromCache(requestObject.getTokenId(), UserAccountData.class, MemCacheUtils.AUTHTOKENCACHE);
				
				responseObject = CommonUtils.validateRequest(accountData, requestObject, request);
				
				if(responseObject.getStatus() != null)
					return responseObject;
				
				walletRequest = KeyEncryptionUtils.jsonStringToObject(KeyEncryptionUtils.decryptUsingKey(accountData.getSecretKey(), payload), WalletRequest.class);
				
				responseObject = CommonUtils.validateRequestData(walletRequest, requestObject, request);
				  
				if(responseObject.getStatus() != null)
					return responseObject;
				  
				Map<HostSubVersionData, HostSubVersionData>  hostSubVersionMap = cacheLoader.getHostSubVersionMap();
				HostSubVersionData hostSubVersionData = hostSubVersionMap.get(new HostSubVersionData(1));

				
				TransactionData transactionData = CommonUtils.getTransactionData(accountData);
				
				bridgeData.setServiceType(ServiceType.MWALLET_CUST_TOP_UP_ONLINE_B_T_W);
				
				bridgeData = CommonUtils.setWalletDetails(bridgeData, walletRequest);
				
				bridgeData.setMsisdn(accountData.getMobileNo());
				
				bridgeData.getPayeeWallet().setMsisdn(accountData.getMobileNo());
				
				bridgeData.setHostSubVersionData(hostSubVersionData);
				
				bridgeData.setTransactionData(transactionData);
				
				bridgeData = transactionService.callService(bridgeData);
				
				String responseMsg = null;
				
				if(bridgeData.getBridgeResponse() != null)
					responseMsg = bridgeData.getBridgeResponse().getResponseMsg();
				
				responseObject = CommonUtils.setStatusCode(bridgeData.getBridgeResponse(),responseObject);
				
				responseObject.setMessage(responseMsg);
				
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), "com.ng");
			
			//UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			responseObject.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseObject.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e.getMessage());
		}
		return responseObject;
	 }
	 
	 
	 @RequestMapping(value = "/fundTransferWtB", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	 public @ResponseBody ResponseObject fundTransferWalletToBank(@RequestBody RequestObject requestObject, HttpServletRequest request) 
	 {
		 LOGGER.info("************* fundTransferWalletToBank() starts executing in WalletController **************");
		 ResponseObject responseObject = new ResponseObject();
		 
		 BridgeDataObject bridgeData = new BridgeDataObject();
			/* 
			 * Get Agent details from tokenId
			 * requestObject.getTokenId()
			 * 
			 */
		 	WalletRequest walletRequest = null;
			Object payload =  requestObject.getPayload();
			UserAccountData accountData = null;
			try
			{
				//Check token Validity
				accountData = cacheManager.getFromCache(requestObject.getTokenId(), UserAccountData.class, MemCacheUtils.AUTHTOKENCACHE);
				
				responseObject = CommonUtils.validateRequest(accountData, requestObject, request);
				
				if(responseObject.getStatus() != null)
					return responseObject;
				
				walletRequest = KeyEncryptionUtils.jsonStringToObject(KeyEncryptionUtils.decryptUsingKey(accountData.getSecretKey(), payload), WalletRequest.class);
				
				responseObject = CommonUtils.validateRequestData(walletRequest, requestObject, request);
				  
				if(responseObject.getStatus() != null)
					return responseObject;
				  
				Map<HostSubVersionData, HostSubVersionData>  hostSubVersionMap = cacheLoader.getHostSubVersionMap();
				HostSubVersionData hostSubVersionData = hostSubVersionMap.get(new HostSubVersionData(1));

				
				TransactionData transactionData = CommonUtils.getTransactionData(accountData);
				
				bridgeData.setServiceType(ServiceType.OTH_PAY_INDI_WALLET_TO_B);
				
				bridgeData = CommonUtils.setWalletDetails(bridgeData, walletRequest);
				bridgeData.setMsisdn(accountData.getMobileNo());
				
				bridgeData.getPayerWallet().setMsisdn(bridgeData.getMsisdn());
				
				bridgeData.setHostSubVersionData(hostSubVersionData);
				
				bridgeData.setTransactionData(transactionData);
				
				bridgeData = transactionService.callService(bridgeData);
				
				String responseMsg = null;
				
				if(bridgeData.getBridgeResponse() != null)
					responseMsg = bridgeData.getBridgeResponse().getResponseMsg();
				
				responseObject = CommonUtils.setStatusCode(bridgeData.getBridgeResponse(),responseObject);
				
				responseObject.setMessage(responseMsg);
				
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), "com.ng");
			
			//UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			responseObject.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseObject.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e.getMessage());
		}
		return responseObject;
	 }
	 
	 @RequestMapping(value = "/fundTransferWtW", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	 public @ResponseBody ResponseObject fundTransferWalletToWallet(@RequestBody RequestObject requestObject, HttpServletRequest request) 
	 {
		 LOGGER.info("************* fundTransferWalletToWallet() starts executing in WalletController **************");
		 ResponseObject responseObject = new ResponseObject();
		 
		 BridgeDataObject bridgeData = new BridgeDataObject();
			/* 
			 * Get Agent details from tokenId
			 * requestObject.getTokenId()
			 * 
			 */
		 	WalletRequest walletRequest = null;
			Object payload =  requestObject.getPayload();
			UserAccountData accountData = null;
			try
			{
				//Check token Validity
				accountData = cacheManager.getFromCache(requestObject.getTokenId(), UserAccountData.class, MemCacheUtils.AUTHTOKENCACHE);
				
				responseObject = CommonUtils.validateRequest(accountData, requestObject, request);
				
				if(responseObject.getStatus() != null)
					return responseObject;
				
				walletRequest = KeyEncryptionUtils.jsonStringToObject(KeyEncryptionUtils.decryptUsingKey(accountData.getSecretKey(), payload), WalletRequest.class);
				
				responseObject = CommonUtils.validateRequestData(walletRequest, requestObject, request);
				  
				if(responseObject.getStatus() != null)
					return responseObject;
				  
				Map<HostSubVersionData, HostSubVersionData>  hostSubVersionMap = cacheLoader.getHostSubVersionMap();
				HostSubVersionData hostSubVersionData = hostSubVersionMap.get(new HostSubVersionData(1));

				
				TransactionData transactionData = CommonUtils.getTransactionData(accountData);
				
				bridgeData.setServiceType(ServiceType.OTH_PAY_INDI_WALLET_TO_WALLET);
				
				bridgeData = CommonUtils.setWalletDetails(bridgeData, walletRequest);
				bridgeData.setMsisdn(accountData.getMobileNo());
				
				bridgeData.getPayerWallet().setMsisdn(bridgeData.getMsisdn());
				
				bridgeData.setHostSubVersionData(hostSubVersionData);
				
				bridgeData.setTransactionData(transactionData);
				
				bridgeData = transactionService.callService(bridgeData);
				
				String responseMsg = null;
				
				if(bridgeData.getBridgeResponse() != null)
					responseMsg = bridgeData.getBridgeResponse().getResponseMsg();
				
				responseObject = CommonUtils.setStatusCode(bridgeData.getBridgeResponse(),responseObject);
				
				responseObject.setMessage(responseMsg);
				
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), "com.ng");
			
			//UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			responseObject.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseObject.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e.getMessage());
		}
		return responseObject;
	 }
	 
	 @RequestMapping(value = "/createWalletPin", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	 public @ResponseBody ResponseObject createWalletPin(@RequestBody RequestObject requestObject, HttpServletRequest request) 
	 {
		 LOGGER.info("************* balanceEnquiry() starts executing in WalletController **************");
		 ResponseObject responseObject = new ResponseObject();
		 
		 BridgeDataObject bridgeData = new BridgeDataObject();
			/* 
			 * Get Agent details from tokenId
			 * requestObject.getTokenId()
			 * 
			 */
		 	WalletRequest walletRequest = null;
			Object payload =  requestObject.getPayload();
			UserAccountData accountData = null;
			try
			{
				//Check token Validity
				accountData = cacheManager.getFromCache(requestObject.getTokenId(), UserAccountData.class, MemCacheUtils.AUTHTOKENCACHE);
				
				responseObject = CommonUtils.validateRequest(accountData, requestObject, request);
				
				if(responseObject.getStatus() != null)
					return responseObject;
				
				walletRequest = KeyEncryptionUtils.jsonStringToObject(KeyEncryptionUtils.decryptUsingKey(accountData.getSecretKey(), payload), WalletRequest.class);
				
				responseObject = CommonUtils.validateRequestData(walletRequest, requestObject, request);
				  
				if(responseObject.getStatus() != null)
					return responseObject;
				  
				Map<HostSubVersionData, HostSubVersionData>  hostSubVersionMap = cacheLoader.getHostSubVersionMap();
				HostSubVersionData hostSubVersionData = hostSubVersionMap.get(new HostSubVersionData(1));

				
				TransactionData transactionData = CommonUtils.getTransactionData(accountData);
				
				bridgeData.setServiceType(ServiceType.SETTINGS_CREATE_PIN_WALLET);
				
				bridgeData = CommonUtils.setWalletDetails(bridgeData, walletRequest);
				
				bridgeData.getPayerWallet().setMsisdn(accountData.getMobileNo());
				
				bridgeData.setHostSubVersionData(hostSubVersionData);
				
				bridgeData.setTransactionData(transactionData);
				
				bridgeData = transactionService.callService(bridgeData);
				
				String responseMsg = null;
				
				if(bridgeData.getBridgeResponse() != null)
					responseMsg = bridgeData.getBridgeResponse().getResponseMsg();
				
				responseObject = CommonUtils.setStatusCode(bridgeData.getBridgeResponse(),responseObject);
				
				responseObject.setMessage(responseMsg);
				
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), "com.ng");
			
			//UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			responseObject.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseObject.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e.getMessage());
		}
		return responseObject;
	 }
	 
	 @RequestMapping(value = "/changeWalletPin", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	 public @ResponseBody ResponseObject changeWalletPin(@RequestBody RequestObject requestObject, HttpServletRequest request) 
	 {
		 LOGGER.info("************* changeWalletPin() starts executing in WalletController **************");
		 ResponseObject responseObject = new ResponseObject();
		 
		 BridgeDataObject bridgeData = new BridgeDataObject();
			/* 
			 * Get Agent details from tokenId
			 * requestObject.getTokenId()
			 * 
			 */
		 	WalletRequest walletRequest = null;
			Object payload =  requestObject.getPayload();
			UserAccountData accountData = null;
			try
			{
				//Check token Validity
				accountData = cacheManager.getFromCache(requestObject.getTokenId(), UserAccountData.class, MemCacheUtils.AUTHTOKENCACHE);
				
				responseObject = CommonUtils.validateRequest(accountData, requestObject, request);
				
				if(responseObject.getStatus() != null)
					return responseObject;
				
				walletRequest = KeyEncryptionUtils.jsonStringToObject(KeyEncryptionUtils.decryptUsingKey(accountData.getSecretKey(), payload), WalletRequest.class);
				
				responseObject = CommonUtils.validateRequestData(walletRequest, requestObject, request);
				  
				if(responseObject.getStatus() != null)
					return responseObject;
				  
				Map<HostSubVersionData, HostSubVersionData>  hostSubVersionMap = cacheLoader.getHostSubVersionMap();
				HostSubVersionData hostSubVersionData = hostSubVersionMap.get(new HostSubVersionData(1));

				
				TransactionData transactionData = CommonUtils.getTransactionData(accountData);
				
				bridgeData.setServiceType(ServiceType.SETTINGS_CHANGE_PIN_WALLET);
				
				bridgeData = CommonUtils.setWalletDetails(bridgeData, walletRequest);
				
				bridgeData.getPayerWallet().setMsisdn(accountData.getMobileNo());
				
				bridgeData.setHostSubVersionData(hostSubVersionData);
				
				bridgeData.setTransactionData(transactionData);
				
				bridgeData = transactionService.callService(bridgeData);
				
				String responseMsg = null;
				
				if(bridgeData.getBridgeResponse() != null)
					responseMsg = bridgeData.getBridgeResponse().getResponseMsg();
				
				responseObject = CommonUtils.setStatusCode(bridgeData.getBridgeResponse(),responseObject);
				
				responseObject.setMessage(responseMsg);
				
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), "com.ng");
			
			//UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			responseObject.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseObject.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e.getMessage());
		}
		return responseObject;
	 }
	 
	 
	 @RequestMapping(value = "/walletList", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	 public @ResponseBody ResponseObject walletList(@RequestBody RequestObject requestObject, HttpServletRequest request) 
	 {
		 LOGGER.info("************* walletList() starts executing in WalletController **************");
		 ResponseObject responseObject = new ResponseObject();
		 
		 BridgeDataObject bridgeData = new BridgeDataObject();
			/* 
			 * Get Agent details from tokenId
			 * requestObject.getTokenId()
			 * 
			 */
		 	Object payload =  requestObject.getPayload();
			UserAccountData accountData = null;
			try
			{
				//Check token Validity
				accountData = cacheManager.getFromCache(requestObject.getTokenId(), UserAccountData.class, MemCacheUtils.AUTHTOKENCACHE);
				
				responseObject = CommonUtils.validateRequest(accountData, requestObject, request);
				
				if(responseObject.getStatus() != null)
					return responseObject;
				
				String responseMsg = null;
				
				List<Partner> partnerData = transactionDAO.getPartners(BaseSystemConstant.WALLETS);
				
				if(partnerData != null && !partnerData.isEmpty())
				{
					responseObject.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
					responseObject.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
					
					List<WalletData> walletData = new ArrayList<WalletData>();
					for(Partner partner : partnerData)
					{
						WalletData wallet = new WalletData();
						
						wallet.setWalletTypeName(partner.getName());
						wallet.setWalletTypeId(partner.getPartnerCode());
						
						walletData.add(wallet);
					}
					
					String encryptedData = KeyEncryptionUtils.encryptUsingKey(accountData.getSecretKey(), walletData);
					 
					 responseObject.setPayload(encryptedData);
					
				}else
				{
					responseObject.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
					responseObject.setMessage(ErrorCodes.NO_RECORDS_FOUND.getMessage());
				}
				
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), "com.ng");
			
			//UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			responseObject.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseObject.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e.getMessage());
		}
		return responseObject;
	 }
	 
	 @RequestMapping(value = "/topUpByWallet", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	 public @ResponseBody ResponseObject topUpByWallet(@RequestBody RequestObject requestObject, HttpServletRequest request) 
	 {
		 LOGGER.info("************* topUpByWallet() starts executing in WalletController **************");
		 ResponseObject responseObject = new ResponseObject();
		 
		 BridgeDataObject bridgeData = new BridgeDataObject();
			/* 
			 * Get Agent details from tokenId
			 * requestObject.getTokenId()
			 * 
			 */
		 	WalletRequest topUpRequest = null;
			Object payload =  requestObject.getPayload();
			UserAccountData accountData = null;
			try
			{
				//Check token Validity
				accountData = cacheManager.getFromCache(requestObject.getTokenId(), UserAccountData.class, MemCacheUtils.AUTHTOKENCACHE);
				
				responseObject = CommonUtils.validateRequest(accountData, requestObject, request);
				
				if(responseObject.getStatus() != null)
					return responseObject;
				
				topUpRequest = KeyEncryptionUtils.jsonStringToObject(KeyEncryptionUtils.decryptUsingKey(accountData.getSecretKey(), payload), WalletRequest.class);
				
				responseObject = CommonUtils.validateRequestData(topUpRequest, requestObject, request);
				  
				if(responseObject.getStatus() != null)
					return responseObject;
				  
				Map<HostSubVersionData, HostSubVersionData>  hostSubVersionMap = cacheLoader.getHostSubVersionMap();
				HostSubVersionData hostSubVersionData = hostSubVersionMap.get(new HostSubVersionData(1));

				
				TransactionData transactionData = CommonUtils.getTransactionData(accountData);
				
				bridgeData.setServiceType(ServiceType.TOP_UP_RECH_BY_WALLET);
				
				bridgeData = CommonUtils.setWalletDetails(bridgeData, topUpRequest);
				
				bridgeData.getPayerWallet().setMsisdn(accountData.getMobileNo());
				
				bridgeData.setHostSubVersionData(hostSubVersionData);
				
				bridgeData.setTransactionData(transactionData);
				
				bridgeData = transactionService.callService(bridgeData);
				
				String responseMsg = null;
				
				if(bridgeData.getBridgeResponse() != null)
					responseMsg = bridgeData.getBridgeResponse().getResponseMsg();
				
				responseObject = CommonUtils.setStatusCode(bridgeData.getBridgeResponse(),responseObject);
				
				responseObject.setMessage(responseMsg);
				
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), "com.ng");
			
			//UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			responseObject.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseObject.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e.getMessage());
		}
		return responseObject;
	 }
	 
	 @RequestMapping(value = "/billPayByWallet", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	 public @ResponseBody ResponseObject billPayByWallet(@RequestBody RequestObject requestObject, HttpServletRequest request) 
	 {
		 LOGGER.info("************* billPayByWallet() starts executing in WalletController **************");
		 ResponseObject responseObject = new ResponseObject();
		 
		 BridgeDataObject bridgeData = new BridgeDataObject();
			/* 
			 * Get Agent details from tokenId
			 * requestObject.getTokenId()
			 * 
			 */
		 	WalletRequest topUpRequest = null;
			Object payload =  requestObject.getPayload();
			UserAccountData accountData = null;
			try
			{
				//Check token Validity
				accountData = cacheManager.getFromCache(requestObject.getTokenId(), UserAccountData.class, MemCacheUtils.AUTHTOKENCACHE);
				
				responseObject = CommonUtils.validateRequest(accountData, requestObject, request);
				
				if(responseObject.getStatus() != null)
					return responseObject;
				
				topUpRequest = KeyEncryptionUtils.jsonStringToObject(KeyEncryptionUtils.decryptUsingKey(accountData.getSecretKey(), payload), WalletRequest.class);
				
				responseObject = CommonUtils.validateRequestData(topUpRequest, requestObject, request);
				  
				if(responseObject.getStatus() != null)
					return responseObject;
				  
				Map<HostSubVersionData, HostSubVersionData>  hostSubVersionMap = cacheLoader.getHostSubVersionMap();
				HostSubVersionData hostSubVersionData = hostSubVersionMap.get(new HostSubVersionData(1));

				
				TransactionData transactionData = CommonUtils.getTransactionData(accountData);
				
				bridgeData.setServiceType(ServiceType.BILL_PAY_BY_WALLET);
				
				bridgeData = CommonUtils.setWalletDetails(bridgeData, topUpRequest);
				
				bridgeData.getPayerWallet().setMsisdn(accountData.getMobileNo());
				
				bridgeData.setHostSubVersionData(hostSubVersionData);
				
				bridgeData.setTransactionData(transactionData);
				
				bridgeData = transactionService.callService(bridgeData);
				
				String responseMsg = null;
				
				if(bridgeData.getBridgeResponse() != null)
					responseMsg = bridgeData.getBridgeResponse().getResponseMsg();
				
				responseObject = CommonUtils.setStatusCode(bridgeData.getBridgeResponse(),responseObject);
				
				responseObject.setMessage(responseMsg);
				
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), "com.ng");
			
			//UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			responseObject.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseObject.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e.getMessage());
		}
		return responseObject;
	 }
	 
	 
	 @RequestMapping(value = "/myWallets", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	 public @ResponseBody ResponseObject myWallets(@RequestBody RequestObject requestObject, HttpServletRequest request) 
	 {
		 LOGGER.info("************* myWallets() starts executing in WalletController **************");
		 ResponseObject responseObject = new ResponseObject();
		 
		 UserAccountData accountData = null;
			try
			{
				//Check token Validity
				accountData = cacheManager.getFromCache(requestObject.getTokenId(), UserAccountData.class, MemCacheUtils.AUTHTOKENCACHE);
				
				responseObject = CommonUtils.validateRequest(accountData, requestObject, request);
				
				if(responseObject.getStatus() != null)
					return responseObject;
				
				List<CustomerWallets> customerWallets = transactionDAO.getMyWallets(accountData.getMobileNo());
				
				if(customerWallets != null && !customerWallets.isEmpty())
				{
					responseObject.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
					responseObject.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
					
					List<WalletData> walletData = new ArrayList<WalletData>();
					for(CustomerWallets partner : customerWallets)
					{
						WalletData wallet = new WalletData();
						
						wallet.setWalletTypeName(partner.getWalletName());
						wallet.setWalletTypeId(partner.getWalletId());
						
						walletData.add(wallet);
					}
					
					String encryptedData = KeyEncryptionUtils.encryptUsingKey(accountData.getSecretKey(), walletData);
					 
					responseObject.setPayload(encryptedData);
					
				}else
				{
					responseObject.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
					responseObject.setMessage(ErrorCodes.NO_RECORDS_FOUND.getMessage());
				}
				
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), "com.ng");
			
			//UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			responseObject.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseObject.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e.getMessage());
		}
		return responseObject;
	 }
}
