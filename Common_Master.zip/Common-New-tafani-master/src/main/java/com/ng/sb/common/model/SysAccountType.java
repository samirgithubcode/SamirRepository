/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "sys_account_type")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "SysAccountType.findAll", query = "SELECT s FROM SysAccountType s where s.status=1"),
    @NamedQuery(name = "SysAccountType.findById", query = "SELECT s FROM SysAccountType s WHERE s.id = :id"),
    @NamedQuery(name = "SysAccountType.findByAccountType", query = "SELECT s FROM SysAccountType s WHERE s.accountType = :accountType"),
    @NamedQuery(name = "SysAccountType.findByCreateDate", query = "SELECT s FROM SysAccountType s WHERE s.createDate = :createDate"),
    @NamedQuery(name = "SysAccountType.findByDescription", query = "SELECT s FROM SysAccountType s WHERE s.description = :description"),
    @NamedQuery(name = "SysAccountType.findByIndex", query = "SELECT s FROM SysAccountType s WHERE s.index = :index"),
    @NamedQuery(name = "SysAccountType.findByWeight", query = "SELECT s FROM SysAccountType s WHERE s.weight = :weight"),
    @NamedQuery(name = "SysAccountType.findByGroupId", query = "SELECT s FROM SysAccountType s WHERE s.groupId = :groupId"),
    @NamedQuery(name = "SysAccountType.findByStatus", query = "SELECT s FROM SysAccountType s WHERE s.status = :status"),
    @NamedQuery(name = "SysAccountType.findByWeightage", query = "SELECT s FROM SysAccountType s WHERE s.weight > :lWeight and s.weight < :hWeight order by weight desc"),
    @NamedQuery(name = "SysAccountType.findByWeightagenStatus", query = "SELECT s FROM SysAccountType s WHERE s.weight > :lWeight and s.weight < :hWeight and s.status=1 order by weight desc"),
    @NamedQuery(name = "SysAccountType.findByDefaultStatus", query = "SELECT s FROM SysAccountType s WHERE s.defaultStatus = :defaultStatus")})
public class SysAccountType implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
    @Basic(optional = false)
    @Column(name = "account_type", nullable = false, length = 30)
    private String accountType;
    @Basic(optional = false)
    @Column(name = "create_date", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date createDate;
    @Column(name = "description", length = 100)
    private String description;
    @Basic(optional = false)
    @Column(name = "index", nullable = false)
    private int index;
    @Basic(optional = false)
    @Column(name = "weight", nullable = false)
    private int weight;
    @Basic(optional = false)
    @Column(name = "status", nullable = false)
    private short status;
    @Basic(optional = false)
    @Column(name = "default_status", nullable = false)
    private boolean defaultStatus;
    @Basic(optional = false)
    @Column(name = "type_code")
    private String typeCode;
	@JoinColumn(name = "group_id", referencedColumnName = "id")
    @ManyToOne
    private SysAccountGroup groupId;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "sysAccountTypeId")
    private Collection<SysMisMenu> sysMisMenuCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "accountTypeId")
    private Collection<AccountLoginInfo> accountLoginInfoCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "sysAccountTypeId")
    private Collection<SysCustomerCareMenu> sysCustomerCareMenuCollection;

    public SysAccountType() {
    	//default constructor
    }

    public SysAccountType(Integer id) {
        this.id = id;
    }

    public SysAccountType(Integer id, String accountType, Date createDate, int index, int weight, short status, boolean defaultStatus) {
        this.id = id;
        this.accountType = accountType;
        this.createDate = createDate;
        this.index = index;
        this.weight = weight;
        this.status = status;
        this.defaultStatus = defaultStatus;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public short getStatus() {
        return status;
    }

    public void setStatus(short status) {
        this.status = status;
    }

    public boolean getDefaultStatus() {
        return defaultStatus;
    }

    public void setDefaultStatus(boolean defaultStatus) {
        this.defaultStatus = defaultStatus;
    }

    public String getTypeCode() {
		return typeCode;
	}

	public void setTypeCode(String typeCode) {
		this.typeCode = typeCode;
	}
	
    public SysAccountGroup getGroupId() {
        return groupId;
    }

    public void setGroupId(SysAccountGroup groupId) {
        this.groupId = groupId;
    }

    @XmlTransient
    public Collection<SysMisMenu> getSysMisMenuCollection() {
        return sysMisMenuCollection;
    }

    public void setSysMisMenuCollection(Collection<SysMisMenu> sysMisMenuCollection) {
        this.sysMisMenuCollection = sysMisMenuCollection;
    }

    @XmlTransient
    public Collection<AccountLoginInfo> getAccountLoginInfoCollection() {
        return accountLoginInfoCollection;
    }

    public void setAccountLoginInfoCollection(Collection<AccountLoginInfo> accountLoginInfoCollection) {
        this.accountLoginInfoCollection = accountLoginInfoCollection;
    }

    @XmlTransient
    public Collection<SysCustomerCareMenu> getSysCustomerCareMenuCollection() {
        return sysCustomerCareMenuCollection;
    }

    public void setSysCustomerCareMenuCollection(Collection<SysCustomerCareMenu> sysCustomerCareMenuCollection) {
        this.sysCustomerCareMenuCollection = sysCustomerCareMenuCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof SysAccountType)) {
            return false;
        }
        SysAccountType other = (SysAccountType) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.SysAccountType[ id=" + id + " ]";
    }
    
}
