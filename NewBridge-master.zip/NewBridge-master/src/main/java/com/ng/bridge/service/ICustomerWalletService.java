/**
 * 
 */
package com.ng.bridge.service;

import com.ng.sb.common.dataobject.BridgeDataObject;

/**
 * @author gaurav
 *
 */
public interface ICustomerWalletService extends IWalletService {
	public BridgeDataObject checkBalance(BridgeDataObject bridgeDataObject);
	public BridgeDataObject topUpOnline(BridgeDataObject bridgeDataObject);
	public BridgeDataObject cashOut(BridgeDataObject bridgeDataObject);
	
	public BridgeDataObject fundTransferBankToWallet(BridgeDataObject bridgeDataObject);
	public BridgeDataObject fundTransferWalletToWallet(BridgeDataObject bridgeDataObject);
	
	
}
