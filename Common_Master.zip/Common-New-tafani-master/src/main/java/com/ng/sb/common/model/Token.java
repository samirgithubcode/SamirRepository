


package com.ng.sb.common.model;


import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;



	@Entity
	@Table(name = "token")
	@XmlRootElement
	@NamedQueries({
		@NamedQuery(name="Token.findAll", query="SELECT t FROM Token t where status=1"),
		
	})
	public class Token implements Serializable {
		private static final long serialVersionUID = 1L;
		
		
		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		@Basic(optional = false)
		@Column(name = "id")
		private Integer id;
		
		@Column(name = "token_name")
		private String tokenName;
		
	   
		@Column(name = "status")
	    private Integer status;
		
		@Column(name = "added_on")
	    private Date addedOn;
		@Column(name = "added_by")
	    private String addedBy;
		@Column(name = "modified_by")
	    private String modifiedBy;
		@Column(name = "modified_on")
	    private Date modifiedOn;
		@Column(name = "startDate")
	    private Date startDate;
		@Column(name = "endDate")
	    private Date endDate;
		
		public String getTokenName() {
			return tokenName;
		}

		
		public void setTokenName(String tokenName) {
			this.tokenName = tokenName;
		}

		
		public Date getStartDate() {
			return startDate;
		}

		
		public void setStartDate(Date startDate) {
			this.startDate = startDate;
		}

		
		public Date getEndDate() {
			return endDate;
		}

		
		public void setEndDate(Date endDate) {
			this.endDate = endDate;
		}


		public Date getAddedOn() {
			return addedOn;
		}

		public void setAddedOn(Date addedOn) {
			this.addedOn = addedOn;
		}

		public String getAddedBy() {
			return addedBy;
		}

		public void setAddedBy(String addedBy) {
			this.addedBy = addedBy;
		}

		public String getModifiedBy() {
			return modifiedBy;
		}

		public void setModifiedBy(String modifiedBy) {
			this.modifiedBy = modifiedBy;
		}

		public Date getModifiedOn() {
			return modifiedOn;
		}

		public void setModifiedOn(Date modifiedOn) {
			this.modifiedOn = modifiedOn;
		}

		public Token() {
	    	//empty
	    }

	    public Token(Integer id) {
	        this.id = id;
	    }
		

	    

		public Integer getStatus() {
			return status;
		}

		public void setStatus(Integer status) {
			this.status = status;
		}
		
	    

	    
		
		public Integer getId() {
			return id;
		}

		public void setId(Integer id) {
			this.id = id;
		}


		@Override
		public boolean equals(Object object) {
			boolean checkStatus = true;
			if (object != null) {
				if (!(object instanceof TokenParameter)) {
					checkStatus = false;
				}
				Token other = (Token) object;
				if ((this.id == null && other.id != null)
						|| (this.id != null && !this.id.equals(other.id))) {
					checkStatus = false;
				}
			}
			return checkStatus;
		}

		@Override
		public int hashCode() {
			int hash = 0;
			hash += (id != null ? id.hashCode() : 0);
			return hash;
		}

		

	}
	
	
	
	
	
