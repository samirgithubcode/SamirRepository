/**
 * 
 */
package com.ng.user.service.impl;

import java.io.File;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.ResourceBundle;
import java.util.Set;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import com.ng.sb.common.cache.MemCacheManager;
import com.ng.sb.common.cache.MemCacheUtils;
import com.ng.sb.common.dataobject.BankAccount;
import com.ng.sb.common.dataobject.CommissionInfosPayload;
import com.ng.sb.common.dataobject.CommissionInfosResponse;
import com.ng.sb.common.dataobject.PlatformLoginData;
import com.ng.sb.common.dataobject.RequestObject;
import com.ng.sb.common.dataobject.ResponseObject;
import com.ng.sb.common.dataobject.UserAccountData;
import com.ng.sb.common.model.AccountLoginInfo;
import com.ng.sb.common.model.AgentApiMapping;
import com.ng.sb.common.model.CustomerDetails;
import com.ng.sb.common.model.CustomerWallets;
import com.ng.sb.common.model.InternalAccountMaster;
import com.ng.sb.common.model.MerchantInfo;
import com.ng.sb.common.model.MerchantUsers;
import com.ng.sb.common.model.Subscriber;
import com.ng.sb.common.util.BaseSystemConstant;
import com.ng.sb.common.util.Channels;
import com.ng.sb.common.util.ErrorCodes;
import com.ng.sb.common.util.ExceptionUtils;
import com.ng.sb.common.util.HttpUtils;
import com.ng.sb.common.util.KeyEncryptionUtils;
import com.ng.sb.common.util.KeyManager;
import com.ng.sb.common.util.SystemConstant;
import com.ng.sb.common.util.UserType;
import com.ng.user.db.IAccountDao;
import com.ng.user.db.IUserDao;
import com.ng.user.dto.ActivationCodeRequest;
import com.ng.user.dto.ChangePasswordRequest;
import com.ng.user.dto.CommissionData;
import com.ng.user.dto.ForgotPasswordRequest;
import com.ng.user.dto.ForgotPasswordResponse;
import com.ng.user.dto.LoginRequset;
import com.ng.user.dto.LoginResponse;
import com.ng.user.dto.OtpRequest;
import com.ng.user.dto.ServiceDeails;
import com.ng.user.dto.SignUpRequest;
import com.ng.user.dto.UserAddress;
import com.ng.user.dto.UserProfile;
import com.ng.user.logger.UserServiceLogger;
import com.ng.user.service.IUserService;
import com.ng.user.utils.CommonUtils;
import com.ng.user.utils.UserServiceConstants;

/**
 * @author gopal
 *
 */
@Service("userService")
public class UserService implements IUserService {

	@Autowired
	IUserDao userDao;
	
	@Autowired
	MemCacheManager cacheManager;
	
	@Autowired
	IAccountDao accountDao;
	
	@Autowired
	CommonUtils commonUtils;
	
	@Autowired
	PlatformLoginData platformLoginData;
	
	ResourceBundle resourceBundle = ResourceBundle.getBundle("UserProperties");
	
	@Transactional
	public LoginResponse authenticateUser(LoginRequset loginRequset) 
	{
		LoginResponse response = new LoginResponse();
		UserAccountData accountData = new UserAccountData();
		KeyManager keyManager = null;
		String authToken = null; 
				
		try{
			Object resultObject = userDao.getLoginInfo(loginRequset.getUserId(), loginRequset.getUserTypeId());
			
			accountData.setChannelId(Integer.parseInt(loginRequset.getChannelId()));
			accountData.setUserType(loginRequset.getUserTypeId());
						
			if(resultObject != null && loginRequset.getUserTypeId() == UserType.SUBSCRIBER.getUserTypeId())
			{
				Subscriber loginInfo = (Subscriber)resultObject;

					response = manageLoginStatus(loginInfo, loginRequset);
					
					if(response.getStatus() != null)
						return response;
					
					loginInfo.setInvalidLoginCount(0);
					userDao.update(loginInfo);
					
					keyManager = new KeyManager();
					
					String name = loginInfo.getName() + " " + (loginInfo.getSurname() == null?"":loginInfo.getSurname().trim());
					
				accountData.setName(name.trim());
				accountData.setUserLoginName(loginInfo.getMsisdn());
				accountData.setEmailId(loginInfo.getEmailId());
				accountData.setId(loginInfo.getId());
				
				accountData.setLoginId(loginInfo.getId());
				accountData.setMobileNo(loginInfo.getMsisdn());
				
				if(loginInfo.getDateOfBirth() != null){
					accountData.setDateOfBirth(KeyEncryptionUtils.dateToString(loginInfo.getDateOfBirth(), UserServiceConstants.FORGET_PASS_DATE_PATTERN));	
				}
				
				accountData.setState(loginInfo.getState());
				accountData.setCountry(loginInfo.getCountry());
				accountData.setPinCode(loginInfo.getPinCode());
				accountData.setDistrict(loginInfo.getDistrict());
				accountData.setRegion(loginInfo.getRegion());
				accountData.setLocality(loginInfo.getLocality());
				
				accountData.setSecretKey(keyManager.getEncodedKey());
				
				
				
				authToken = commonUtils.getValidToken(); 
			
				String cacheKey = loginInfo.getMsisdn() + "" + loginRequset.getChannelId();
				
				response = manageTokens(cacheKey, authToken, accountData, response, keyManager);
				
				if(loginInfo.getSubscriberType() != null && loginInfo.getSubscriberType().equals(SystemConstant.USER_TYPE_MERCHAT))
				{
					manageMerchantData(loginInfo, response);
					response.setUserTypeId(UserType.MERCHANT.getUserTypeId());
				}else
					response.setUserTypeId(UserType.SUBSCRIBER.getUserTypeId());
				
					if(loginInfo.getProfileImage() != null && !loginInfo.getProfileImage().isEmpty())
						response.setUserProfileImage(platformLoginData.getDownloadKycUrl() + File.separator +  loginInfo.getProfileImage());
					
					boolean isFLogin = (loginInfo.getFirstTimeLogin() == null) ? false : loginInfo.getFirstTimeLogin();
					
					response.setFirstLogin(isFLogin);
					
					response.setLastPasswordDate(loginInfo.getPasswordDate());
					response.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
					response.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
					
				
			    }else if(resultObject != null && loginRequset.getUserTypeId() == UserType.AGENT.getUserTypeId())
				{
			    	AccountLoginInfo loginInfo = (AccountLoginInfo)resultObject;


			    	response = manageAccountStatus(loginInfo, loginRequset);
					
			    	if(response.getStatus() != null)
						return response;
			    	
					loginInfo.setInvalidLoginCount(0);
					userDao.update(loginInfo);
					
					keyManager = new KeyManager();
					
					accountData.setAccountTypeId(loginInfo.getAccountTypeId().getId().toString());
					accountData.setName(loginInfo.getNickName());
					accountData.setUserLoginName(loginInfo.getLoginName());
					accountData.setEmailId(loginInfo.getEmailId());
				
					accountData.setId(loginInfo.getId());
					accountData.setCompanyId(loginInfo.getAccountId().getId());
					accountData.setAccountId(loginInfo.getAccountId().getId());
					accountData.setDeviceId(loginRequset.getDeviceId());
					
					if(loginInfo.getAccountId().getParentId() != null)
					{	
						accountData.setParentId(loginInfo.getAccountId().getParentId().getId());
					}
					
					accountData.setLoginId(loginInfo.getId());
					
					accountData.setMobileNo(loginInfo.getMobileNumber());
					accountData.setEstelDestination(loginInfo.getAccountId().getMobileNumber());
					accountData.setEstelPin("1234");
					
					if(loginInfo.getDateOfBirth() != null){
						accountData.setDateOfBirth(KeyEncryptionUtils.dateToString(loginInfo.getDateOfBirth(), UserServiceConstants.FORGET_PASS_DATE_PATTERN));	
					}
					
					accountData.setState(loginInfo.getState());
					accountData.setCountry(loginInfo.getCountry());
					accountData.setPinCode(loginInfo.getPincode());
					accountData.setDistrict(loginInfo.getDistrict());
					accountData.setRegion(loginInfo.getRegion());
					accountData.setLocality(loginInfo.getLocation());
					
					accountData.setSecretKey(keyManager.getEncodedKey());
					
					
					authToken = commonUtils.getValidToken();
					
					String cacheKey = loginInfo.getMobileNumber() + "" + loginRequset.getChannelId();
					
					
					
					response.setUserTypeId(UserType.AGENT.getUserTypeId());
					response.setFirstLogin(loginInfo.getFirstTimeLogin());
					
					response.setAccountId(loginInfo.getAccountId().getId());
					
					if(loginInfo.getAccountId().getParentId() != null)
					{
					response.setParentId(loginInfo.getAccountId().getParentId().getId());
					}
					
					String cardSubscriptionAmount = resourceBundle.getString(UserServiceConstants.CARD_SUBSCRIPTION_AMOUNT);
					
					if(Integer.parseInt(loginRequset.getChannelId()) == Channels.WEBCLIENT.getChannelId())
						response.setCardSubscriptionAmount(cardSubscriptionAmount);
					
					response.setUserName(loginInfo.getLoginName());
					response.setTxnNature(loginInfo.getAccountId().getTxnNature());
					response.setAccountTypeId(Integer.parseInt(accountData.getAccountTypeId()));
					response.setLastPasswordDate(loginInfo.getPasswordDate());
					response.setUserCompanyId(accountData.getCompanyId().toString());
					response.setAccountTypeWeight("" + loginInfo.getAccountTypeId().getWeight());
					response.setGroupWeight("" + loginInfo.getAccountTypeId().getGroupId().getWeight());
					response.setGroupId(loginInfo.getAccountTypeId().getGroupId().getId().toString());
					response.setGroupCode(loginInfo.getAccountTypeId().getGroupId().getGroupCode());
					response.setContactPersonName(loginInfo.getContactPersonName());
					
					response.setAccountTypeCode(loginInfo.getAccountTypeId().getTypeCode());
					
					InternalAccountMaster accountMaster = accountDao.getInternalAccountMaster(loginInfo.getAccountId().getMobileNumber(), UserServiceConstants.TRADING_ACCOUNT_TYPE);
					
					if(accountMaster != null)
					{
						response.setCurrentBalance(accountMaster.getAccountBalance().toString());
					}
					
					Object[] mappedServicesDetails = fetchMappedServices(loginInfo);
					
					if(mappedServicesDetails != null && mappedServicesDetails.length == 2)
					{
						if(mappedServicesDetails[0] != null)
						{	
							List<ServiceDeails> mappedServices = (List<ServiceDeails>) mappedServicesDetails[0];
							response.setMappedServices(mappedServices);
						}
						
						if(mappedServicesDetails[1] != null)
						{	
							Set<String> serviceUri = (Set<String>) mappedServicesDetails[1];
						
							accountData.setMappedServices(serviceUri);
						}
					}
					
					response = manageTokens(cacheKey, authToken, accountData, response, keyManager);
					
					//List<CommissionData> commInfoList = fetchCommissionDetails(response, accountData.getChannelId());
					
					//response.setCommInfoList(commInfoList);
					response.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
					response.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
					
				}if(resultObject != null && loginRequset.getUserTypeId() == UserType.MERCHANT.getUserTypeId())
				{
					MerchantUsers loginInfo = (MerchantUsers)resultObject;

					response = manageMerchantStatus(loginInfo, loginRequset);
					
					if(response.getStatus() != null)
						return response;
					
					loginInfo.setInvalidLoginCount(0);
					userDao.update(loginInfo);
					
					keyManager = new KeyManager();
					
					String name = loginInfo.getName();
					
				accountData.setName(name.trim());
				accountData.setUserLoginName(loginInfo.getMobileNumber());
				accountData.setId(loginInfo.getId());
				
				accountData.setLoginId(loginInfo.getId());
				accountData.setMobileNo(loginInfo.getMobileNumber());
				
				if(loginInfo.getDateOfBirth() != null){
					accountData.setDateOfBirth(KeyEncryptionUtils.dateToString(loginInfo.getDateOfBirth(), UserServiceConstants.FORGET_PASS_DATE_PATTERN));	
				}
				
				accountData.setSecretKey(keyManager.getEncodedKey());
				
				
				
				authToken = commonUtils.getValidToken(); 
			
				String cacheKey = loginInfo.getMobileNumber() + "" + loginRequset.getChannelId();
				
				response = manageTokens(cacheKey, authToken, accountData, response, keyManager);
				
					
					response.setUserTypeId(UserType.MERCHANT.getUserTypeId());
					response.setUserRole(loginInfo.getRole());
					response.setFirstLogin(true);
					setAccountTypeIdForMerchant(loginInfo, response);
					response.setMerchantId(loginInfo.getMerchantId().getId().toString());
					response.setMerchantName(loginInfo.getMerchantId().getCompanyName());
					response.setMerchantType(loginInfo.getMerchantId().getType());
					//response.setFirstLogin(loginInfo.getFirstTimeLogin());
					//response.setLastPasswordDate(loginInfo.getPasswordDate());
					response.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
					response.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
					
				}else{
					
					 if(resultObject == null)
					 {
						 response.setStatus(ErrorCodes.INVALID_LOGIN_CREDENTIALS.getCode());
						 response.setMessage(ErrorCodes.INVALID_LOGIN_CREDENTIALS.getMessage());
					 }
				}
			
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), UserServiceConstants.PACKAGE_FOR_EXCEPTION);
			
			UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			response.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			response.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() +" : "+e);
			
		}
		
	  return response;
	}

	
	
	private void setAccountTypeIdForMerchant(MerchantUsers loginInfo,LoginResponse response) 
	{
		try {
			MerchantInfo merchantInfo = loginInfo.getMerchantId();
			
			switch(merchantInfo.getType())
			{
			case BaseSystemConstant.CORPORATE_MERCHANT:
				response.setAccountTypeId(Integer.parseInt(platformLoginData.getCorporateAccountId()));
				break;
			case BaseSystemConstant.FRANCHISE_OWNED_STORE:
				response.setAccountTypeId(Integer.parseInt(platformLoginData.getFranchiseAccountId()));
							break;
			case BaseSystemConstant.COMPANY_OWNED_STORE:
				response.setAccountTypeId(Integer.parseInt(platformLoginData.getCompanyAccountId()));
				break;
			case BaseSystemConstant.INDIVIDUAL_MERCHANT:
				response.setAccountTypeId(Integer.parseInt(platformLoginData.getIndividualaccountId()));
				break;
			case BaseSystemConstant.COOPERATIVE_MERCHANT:
				response.setAccountTypeId(Integer.parseInt(platformLoginData.getCooperativeAccountId()));
				break;
	
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}



	private void manageMerchantData(Subscriber loginInfo, LoginResponse response) 
	{
		try{
			MerchantInfo merchantData = userDao.getMerchantDetailsByMsisdn(loginInfo.getMsisdn());
			
			response.setMerchantId(merchantData.getMerchantId());
			response.setMerchantCategoryCode(merchantData.getMerchantCategoryId().toString());
			response.setMerchantCity(merchantData.getAddressId().getLocation());
			response.setMerchantName(merchantData.getCompanyName());
			response.setMerchantType(merchantData.getType());
			response.setCountryCode(merchantData.getAddressId().getCountryCode());
			response.setMerchantCurrencyCode(platformLoginData.getCurrencyCode());
			
			BankAccount account = new BankAccount();
			
			account.setIfscCode(merchantData.getIFSCCode());
			account.setAccountNumber(merchantData.getAccountNumber());
			
			response.setAccountDetails(account);
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}



	private Object[] fetchMappedServices(AccountLoginInfo loginInfo) 
	{
		Object[] serviceData = null;
		
		List<ServiceDeails> services = null;
		Set<String> serviceUris = null;
		
		List<AgentApiMapping> agentMapping = accountDao.getServiceMappings(loginInfo);
		
		if(agentMapping != null)
		{
			services = new ArrayList<ServiceDeails>();
			serviceUris = new HashSet<String>();
			
			for(AgentApiMapping mapping : agentMapping)
			{
				ServiceDeails serviceDetail = new ServiceDeails();
				
				serviceDetail.setServiceCategory(mapping.getApiServiceId().getServiceCategory());
				serviceDetail.setServiceName(mapping.getApiServiceId().getServiceName());
				serviceDetail.setServiceUri(mapping.getApiServiceId().getServiceURI());
				
				serviceUris.add(mapping.getApiServiceId().getServiceURI().toLowerCase());
				
				services.add(serviceDetail);
			}
			
			serviceData = new Object[2];
			
			serviceData[0] = services;
			
			serviceData[1] = serviceUris;
		}
		return serviceData;
	}



	private List<CommissionData> fetchCommissionDetails(LoginResponse response, int channelId) 
	{
		List<CommissionData> commissionDataList = new ArrayList<CommissionData>();
		
		try{
			String commissionListingApi  = platformLoginData.getCommissionListingUrl();
			
			   RestTemplate restTemplate = new RestTemplate();
			   RequestObject  requestObject = new RequestObject();
			   
			   requestObject.setChannelId(channelId);	
			   requestObject.setTokenId(response.getTokenId());
			   
			   
			   ResponseEntity<ResponseObject> apiResponse = restTemplate.postForEntity(commissionListingApi, requestObject, ResponseObject.class);
			   ResponseObject responseObject = apiResponse.getBody();
			   
			  if(responseObject != null && responseObject.getStatus().intValue() == ErrorCodes.REQUEST_SUCCESSFUL.getCode().intValue())
			  {
				  CommissionInfosPayload commissionList =  KeyEncryptionUtils.jsonStringToObject(KeyEncryptionUtils.decryptUsingKey(response.getKey(), responseObject.getPayload()), CommissionInfosPayload.class);
			   
				  if(commissionList != null && commissionList.getCommInfoList() != null && !commissionList.getCommInfoList().isEmpty())
				  {
				 	 for(CommissionInfosResponse commissionInfosResponse :  commissionList.getCommInfoList())
				 	 {
				 		CommissionData commData = new CommissionData();
				 		
				 		commData.setCommission(Double.parseDouble(commissionInfosResponse.getTotalCommission()));
				 		commData.setCommissiontype(commissionInfosResponse.getCommissionType());
				 		commData.setSource(commissionInfosResponse.getCommissionDeductedFrom());
				 		commData.setTxntype(commissionInfosResponse.getTxnType());
				 		
				 		commissionDataList.add(commData);
				 	 }
				  }
					  
				
			  }
			   
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
		return commissionDataList;
	}



	private LoginResponse manageAccountStatus(AccountLoginInfo loginInfo,LoginRequset loginRequset) 
	{
		LoginResponse response = new LoginResponse();
		
		if(!loginInfo.getStatus() || !loginInfo.getAccountId().getStatus())
		{
			response.setStatus(ErrorCodes.ACCOUNT_INACTIVE.getCode());
			response.setMessage(ErrorCodes.ACCOUNT_INACTIVE.getMessage());
			
			return response;
		}

	
		if(loginInfo.getInvalidLoginCount() >= UserServiceConstants.MAX_INVALID_LOGIN_COUNT)
		{	
			response.setStatus(ErrorCodes.ACCOUNT_INACTIVE.getCode());
			response.setMessage(ErrorCodes.ACCOUNT_INACTIVE.getMessage());
			
			return response;
		}
		
		if(loginInfo.getUserPassword() == null || !loginInfo.getUserPassword().equalsIgnoreCase(loginRequset.getPasswd()))
		{	
			response.setStatus(ErrorCodes.INVALID_LOGIN_CREDENTIALS.getCode());
			response.setMessage(ErrorCodes.INVALID_LOGIN_CREDENTIALS.getMessage());
			
			loginInfo.setInvalidLoginCount(loginInfo.getInvalidLoginCount() + 1);
			
			if(loginInfo.getInvalidLoginCount() >= UserServiceConstants.MAX_INVALID_LOGIN_COUNT)
			{
				loginInfo.setStatus(false);
				response.setStatus(ErrorCodes.ACCOUNT_INACTIVE.getCode());
				response.setMessage(ErrorCodes.ACCOUNT_INACTIVE.getMessage());
			}
			
			userDao.update(loginInfo);
			
			return response;
		}
		
		return response;
	}

	private LoginResponse manageMerchantStatus(MerchantUsers loginInfo,LoginRequset loginRequset) 
	{
		LoginResponse response = new LoginResponse();
		
		if(!loginInfo.isStatus())
		{
			response.setStatus(ErrorCodes.ACCOUNT_INACTIVE.getCode());
			response.setMessage(ErrorCodes.ACCOUNT_INACTIVE.getMessage());
			
			return response;
		}

	
		if(loginInfo.getInvalidLoginCount() >= UserServiceConstants.MAX_INVALID_LOGIN_COUNT)
		{	
			response.setStatus(ErrorCodes.ACCOUNT_INACTIVE.getCode());
			response.setMessage(ErrorCodes.ACCOUNT_INACTIVE.getMessage());
			
			return response;
		}
		
		if(loginInfo.getPassword() == null || !loginInfo.getPassword().equalsIgnoreCase(loginRequset.getPasswd()))
		{	
			response.setStatus(ErrorCodes.INVALID_LOGIN_CREDENTIALS.getCode());
			response.setMessage(ErrorCodes.INVALID_LOGIN_CREDENTIALS.getMessage());
			
			loginInfo.setInvalidLoginCount(loginInfo.getInvalidLoginCount() + 1);
			
			if(loginInfo.getInvalidLoginCount() >= UserServiceConstants.MAX_INVALID_LOGIN_COUNT)
			{
				loginInfo.setStatus(false);
				response.setStatus(ErrorCodes.ACCOUNT_INACTIVE.getCode());
				response.setMessage(ErrorCodes.ACCOUNT_INACTIVE.getMessage());
			}
			
			userDao.update(loginInfo);
			
			return response;
		}
		
		return response;
	}

	private LoginResponse manageLoginStatus(Subscriber loginInfo,LoginRequset loginRequset) 
	{
		LoginResponse response = new LoginResponse();
		
		if(loginInfo.getStatus() == null  || loginInfo.getStatus().isEmpty() || !loginInfo.getStatus().equalsIgnoreCase(SystemConstant.ACTIVE))
		{
			response.setStatus(ErrorCodes.ACCOUNT_INACTIVE.getCode());
			response.setMessage(ErrorCodes.ACCOUNT_INACTIVE.getMessage());
			
			return response;
		}
	
		if(loginInfo.getInvalidLoginCount() == null || loginInfo.getInvalidLoginCount() >= UserServiceConstants.MAX_INVALID_LOGIN_COUNT)
		{	
			response.setStatus(ErrorCodes.ACCOUNT_INACTIVE.getCode());
			response.setMessage(ErrorCodes.ACCOUNT_INACTIVE.getMessage());
			
			return response;
		}
		
		if(loginInfo.getUserPassword() == null || !loginInfo.getUserPassword().equals(loginRequset.getPasswd()))
		{	
			response.setStatus(ErrorCodes.INVALID_LOGIN_CREDENTIALS.getCode());
			response.setMessage(ErrorCodes.INVALID_LOGIN_CREDENTIALS.getMessage());
			
			loginInfo.setInvalidLoginCount(((loginInfo.getInvalidLoginCount() == null)?0:loginInfo.getInvalidLoginCount()) + 1);
			
			if(loginInfo.getInvalidLoginCount() >= UserServiceConstants.MAX_INVALID_LOGIN_COUNT)
			{
				loginInfo.setStatus(SystemConstant.INACTIVE);
				
				response.setStatus(ErrorCodes.ACCOUNT_INACTIVE.getCode());
				response.setMessage(ErrorCodes.ACCOUNT_INACTIVE.getMessage());
				
			}
			
			userDao.update(loginInfo);
			
			return response;
		}
		
		if(loginRequset.getSkuId() != null && !loginRequset.getSkuId().isEmpty() && loginRequset.getDeviceId() != null && !loginRequset.getDeviceId().isEmpty())
		{	
			//Fetch Inventory Mapping
			
			if(!loginRequset.getSkuId().equalsIgnoreCase("ffffff4c474d46327002e60003011525") || !loginRequset.getDeviceId().equalsIgnoreCase("354147042083353"))
			{
				response.setStatus(ErrorCodes.INVALID_LOGIN_CREDENTIALS.getCode());
				response.setMessage(ErrorCodes.INVALID_LOGIN_CREDENTIALS.getMessage());
				
				return response;
			}
			
			
		}
		
		
		return response;
	}



	private LoginResponse manageTokens(String cacheKey, String authToken,UserAccountData accountData, LoginResponse response, KeyManager keyManager) 
	{
		//Remove Previous Login
		if(cacheManager.isKeyAvailable(cacheKey, MemCacheUtils.USERCACHE))
		{
			String previousToken = (String)cacheManager.getFromCache(cacheKey, MemCacheUtils.USERCACHE);
			
			cacheManager.removeFromCache(cacheKey, MemCacheUtils.USERCACHE);
			cacheManager.removeFromCache(previousToken, MemCacheUtils.AUTHTOKENCACHE);
			
		}
		
		cacheManager.addToCache(cacheKey, authToken, MemCacheUtils.USERCACHE);
		cacheManager.addToCache(authToken, accountData, MemCacheUtils.AUTHTOKENCACHE);
		
		cacheManager.addToCache(accountData.getMobileNo(), response, MemCacheUtils.USERCACHE);
		
		response.setTokenId(authToken);
		response.setKey(keyManager.getEncodedKey());
		response.setUserId("" + accountData.getId());
		response.setUserName(accountData.getUserLoginName());
		
		return response;
	}



	@Override
	public ResponseObject sendOtp(OtpRequest otpRequest) 
	{
		
		ResponseObject response = new ResponseObject();
		try
		{
			String otpValue = commonUtils.getRandomNumber(UserServiceConstants.OTP_LENGTH);
			
			String otpTemplate = resourceBundle.getString(UserServiceConstants.OTP_TEMPLATE);
			
			otpTemplate = KeyEncryptionUtils.replaceArgumentParameters(otpTemplate, new String[]{ otpValue });
					
			String pushUrl = resourceBundle.getString(UserServiceConstants.SMS_PUSH_URL);
			
			String msisdn = otpRequest.getCustomerMsisdn();
			
			if(msisdn != null && msisdn.length() > platformLoginData.getMobileNumberLength())
				msisdn = msisdn.substring((msisdn.length()-platformLoginData.getMobileNumberLength()));
			
			pushUrl = KeyEncryptionUtils.replaceArgumentParameters(pushUrl, new String[]{ msisdn, URLEncoder.encode(otpTemplate, System.getProperty("file.encoding")) });
			
			String pushResponse = HttpUtils.makeGetRequestToURL(pushUrl, 60000);
			
			//String pushResponse = "Success";
			
			System.out.println("OTP : "+otpValue);
			cacheManager.addToCache(otpRequest.getCustomerMsisdn(), otpValue, MemCacheUtils.OTPCACHE);
			
			response.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
			response.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
			
			UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.INFO, " [OTP] "+otpValue +" [MSG] "+otpTemplate +" [PUSH_URL] "+pushUrl+" [PUSH_RESPONSE] "+pushResponse );
			
		}catch(Exception e){
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), UserServiceConstants.PACKAGE_FOR_EXCEPTION);
			
			UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			response.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			response.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() +" : "+e);
		}
		
		return response;
	}

	@Override
	public ResponseObject resetPassword(RequestObject requestObject) {
		return null;
	}

	@Override
	@Transactional
	public ResponseObject changePassword(ChangePasswordRequest changePasswordRequest) 
	{
		ResponseObject response = new ResponseObject();
		
		try{
			
			if(changePasswordRequest.getUserTypeId() == UserType.SUBSCRIBER.getUserTypeId())
			{
				Subscriber accountDetails = userDao.getSubscriberDetailsById(changePasswordRequest.getUserId());
				
					if(accountDetails == null || accountDetails.getUserPassword() == null || !accountDetails.getUserPassword().equals(changePasswordRequest.getCurrentPasswd()))
					{	
						response.setStatus(ErrorCodes.INVALID_LOGIN_CREDENTIALS.getCode());
						response.setMessage(ErrorCodes.INVALID_LOGIN_CREDENTIALS.getMessage());
						
						return response;
					}
					
					if(accountDetails.getStatus() == null || accountDetails.getStatus().isEmpty() || !accountDetails.getStatus().equalsIgnoreCase(SystemConstant.ACTIVE))
					{
						response.setStatus(ErrorCodes.ACCOUNT_INACTIVE.getCode());
						response.setMessage(ErrorCodes.ACCOUNT_INACTIVE.getMessage());
						
						return response;
					}
					
					accountDetails.setUserPassword(changePasswordRequest.getNewPasswd());
					accountDetails.setPasswordDate(new Date());
					
					userDao.update(accountDetails);
					
					response.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
					response.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
					
			}else if(changePasswordRequest.getUserTypeId() == UserType.AGENT.getUserTypeId())
			{
				AccountLoginInfo accountLoginDetails = userDao.getAccountDetailsById(changePasswordRequest.getUserId()) ;
				
				if(accountLoginDetails == null || accountLoginDetails.getUserPassword() == null || !accountLoginDetails.getUserPassword().equals(changePasswordRequest.getCurrentPasswd()))
				{	
					response.setStatus(ErrorCodes.INVALID_LOGIN_CREDENTIALS.getCode());
					response.setMessage(ErrorCodes.INVALID_LOGIN_CREDENTIALS.getMessage());
					
					return response;
				}
				
				if(!accountLoginDetails.getStatus() || !accountLoginDetails.getAccountId().getStatus())
				{
					response.setStatus(ErrorCodes.ACCOUNT_INACTIVE.getCode());
					response.setMessage(ErrorCodes.ACCOUNT_INACTIVE.getMessage());
					
					return response;
				}
				
				accountLoginDetails.setUserPassword(changePasswordRequest.getNewPasswd());
				accountLoginDetails.setPasswordDate(new Date());
				
				userDao.update(accountLoginDetails);
				
				response.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
				response.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
				
			}
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), UserServiceConstants.PACKAGE_FOR_EXCEPTION);
			
			UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			response.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			response.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() +" : "+e);
		}
		
	  return response;
	}

	@Override
	@Transactional
	public ForgotPasswordResponse forgotPassword(ForgotPasswordRequest forgotPasswordRequest) 
	{
		ForgotPasswordResponse response = new ForgotPasswordResponse();
		
		try{
					
			if(forgotPasswordRequest.getUserTypeId() == UserType.SUBSCRIBER.getUserTypeId())
			{
				Subscriber accountDetails = (Subscriber) userDao.getLoginInfo(forgotPasswordRequest.getUserId(), forgotPasswordRequest.getUserTypeId());
				
				if(forgotPasswordRequest.getStepNo() == UserServiceConstants.REQUEST_STEP_NO_1)
				{
					response = forgetRequestStep1(accountDetails,forgotPasswordRequest.getDateOfBirth());
					
				}else if(forgotPasswordRequest.getStepNo() == UserServiceConstants.REQUEST_STEP_NO_2)
				{
					response = forgetRequestStep2(accountDetails, forgotPasswordRequest);
				}
					
			}else if(forgotPasswordRequest.getUserTypeId() == UserType.AGENT.getUserTypeId())
			{
				AccountLoginInfo accountLoginDetails = (AccountLoginInfo) userDao.getLoginInfo(forgotPasswordRequest.getUserId(), forgotPasswordRequest.getUserTypeId());
				
				if(forgotPasswordRequest.getStepNo() == UserServiceConstants.REQUEST_STEP_NO_1)
				{
					response = forgetRequestStep1(accountLoginDetails, forgotPasswordRequest.getDateOfBirth());
				} else if(forgotPasswordRequest.getStepNo() == UserServiceConstants.REQUEST_STEP_NO_2)
				{
					response = forgetRequestStep2(accountLoginDetails, forgotPasswordRequest);
				}
			}
			
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), UserServiceConstants.PACKAGE_FOR_EXCEPTION);
			
			UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			response.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			response.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() +" : "+e);
		}
		
	  return response;
	}

	public ForgotPasswordResponse forgetRequestStep2(AccountLoginInfo accountLoginDetails,ForgotPasswordRequest forgotPasswordRequest) 
	{
		ForgotPasswordResponse response = new ForgotPasswordResponse();
		
		try{
			if(accountLoginDetails == null || accountLoginDetails.getSecurityAnswer() == null || forgotPasswordRequest.getAnswerString() == null || !forgotPasswordRequest.getAnswerString().equalsIgnoreCase(accountLoginDetails.getSecurityAnswer()))
			{	
				response.setStatus(ErrorCodes.INVALID_SECURITY_ANSWER.getCode());
				response.setMessage(ErrorCodes.INVALID_SECURITY_ANSWER.getMessage());
				
				return response;
			}
			
			
			if(forgotPasswordRequest.getNewPassword() == null || forgotPasswordRequest.getNewPassword().isEmpty() || forgotPasswordRequest.getNewPassword().length() < UserServiceConstants.NEW_PASSWORD_LENGTH)
			{	
				response.setStatus(ErrorCodes.INVALID_REQUEST.getCode());
				response.setMessage(ErrorCodes.INVALID_REQUEST.getMessage());
				
				return response;
			}
			
			accountLoginDetails.setUserPassword(forgotPasswordRequest.getNewPassword());
			
			userDao.update(accountLoginDetails);
			
			response.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
			response.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
			
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), UserServiceConstants.PACKAGE_FOR_EXCEPTION);
			
			UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			response.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			response.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e);
		}
		
		return response;
	}

	public ForgotPasswordResponse forgetRequestStep1(AccountLoginInfo accountLoginDetails, String dateOfBirth) 
	{
		ForgotPasswordResponse response = new ForgotPasswordResponse();
		
		try{
			if(accountLoginDetails == null || accountLoginDetails.getDateOfBirth() == null || !KeyEncryptionUtils.dateToString(accountLoginDetails.getDateOfBirth(), UserServiceConstants.FORGET_PASS_DATE_PATTERN).equals(dateOfBirth))
			{	
				response.setStatus(ErrorCodes.INVALID_DATE_OF_BIRTH.getCode());
				response.setMessage(ErrorCodes.INVALID_DATE_OF_BIRTH.getMessage());
				
				return response;
			}
			
			if(!accountLoginDetails.getStatus() || !accountLoginDetails.getAccountId().getStatus())
			{
				response.setStatus(ErrorCodes.ACCOUNT_INACTIVE.getCode());
				response.setMessage(ErrorCodes.ACCOUNT_INACTIVE.getMessage());
				
				return response;
			}
			
			response.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
			response.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
			
			response.setSecretQuestion(accountLoginDetails.getSecurityQuestionId().getSecuritQuestion());
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), UserServiceConstants.PACKAGE_FOR_EXCEPTION);
			
			UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			response.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			response.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e);
		}
		
		return response;
	}

	public ForgotPasswordResponse forgetRequestStep2(Subscriber accountDetails, ForgotPasswordRequest forgotPasswordRequest) 
	{
		ForgotPasswordResponse response = new ForgotPasswordResponse();
		
		try {
			String otpValue = (String)cacheManager.getFromCache(accountDetails.getMsisdn()+"_"+UserServiceConstants.FORGET_PASS_KEY, MemCacheUtils.OTPCACHE);
			
			
			if(forgotPasswordRequest.getNewPassword() == null || forgotPasswordRequest.getNewPassword().length() < UserServiceConstants.NEW_PASSWORD_LENGTH)
			{	
				response.setStatus(ErrorCodes.INVALID_REQUEST.getCode());
				response.setMessage(ErrorCodes.INVALID_REQUEST.getMessage());
				
				return response;
			}
			
			if(otpValue == null || otpValue.isEmpty())
			{	
				response.setStatus(ErrorCodes.OTP_EXPIRED.getCode());
				response.setMessage(ErrorCodes.OTP_EXPIRED.getMessage());
				
				return response;
			}
			
			if(forgotPasswordRequest.getOtpValue() == null || !forgotPasswordRequest.getOtpValue().equals(otpValue))
			{	
				response.setStatus(ErrorCodes.OTP_INVALID.getCode());
				response.setMessage(ErrorCodes.OTP_INVALID.getMessage());
				
				return response;
			}
			
			accountDetails.setUserPassword(forgotPasswordRequest.getNewPassword());
			accountDetails.setPasswordDate(new Date());
			accountDetails.setInvalidLoginCount(0);
			accountDetails.setStatus(SystemConstant.ACTIVE);
			
			userDao.saveOrUpdate(accountDetails);
			
			response.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
			response.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
		} catch (Exception e) 
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), UserServiceConstants.PACKAGE_FOR_EXCEPTION);
			
			UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			response.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			response.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e);
		}
		
		return response;
	}

	public ForgotPasswordResponse forgetRequestStep1(Subscriber accountDetails,String dateOfBirth ) 
	{
		ForgotPasswordResponse response = new ForgotPasswordResponse();
		
		try {
			if(accountDetails == null || accountDetails.getUserPassword() == null || !KeyEncryptionUtils.dateToString(accountDetails.getDateOfBirth(), UserServiceConstants.FORGET_PASS_DATE_PATTERN).equals(dateOfBirth))
			{	
				response.setStatus(ErrorCodes.INVALID_MOBILE_OR_DOB.getCode());
				response.setMessage(ErrorCodes.INVALID_MOBILE_OR_DOB.getMessage());
				
				return response;
			}
			
			if(accountDetails.getStatus() == null || accountDetails.getStatus().isEmpty() || (!accountDetails.getStatus().equalsIgnoreCase(SystemConstant.ACTIVE) && !(accountDetails.getInvalidLoginCount() >= UserServiceConstants.MAX_INVALID_LOGIN_COUNT)))
			{
				response.setStatus(ErrorCodes.ACCOUNT_INACTIVE.getCode());
				response.setMessage(ErrorCodes.ACCOUNT_INACTIVE.getMessage());
				
				return response;
			}
			
			String otpValue = commonUtils.getRandomNumber(UserServiceConstants.OTP_LENGTH);
			
			cacheManager.addToCache(accountDetails.getMsisdn()+"_"+UserServiceConstants.FORGET_PASS_KEY, otpValue, MemCacheUtils.OTPCACHE);
			
			response.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
			response.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
			
			
			String otpTemplate = resourceBundle.getString(UserServiceConstants.OTP_TEMPLATE);
			
			otpTemplate = KeyEncryptionUtils.replaceArgumentParameters(otpTemplate, new String[]{ otpValue });
					
			String pushUrl = resourceBundle.getString(UserServiceConstants.SMS_PUSH_URL);
			
			String msisdn = accountDetails.getMsisdn();
			
			pushUrl = KeyEncryptionUtils.replaceArgumentParameters(pushUrl, new String[]{ accountDetails.getMsisdn(), URLEncoder.encode(otpTemplate, System.getProperty("file.encoding")) });
			
			//String pushResponse = HttpUtils.makeGetRequestToURL(pushUrl, 60000);
			
			//String pushResponse = "Success";
			
			//UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.INFO, " [FORGET_PASSWORD_OTP] "+otpValue +" [MSG] "+otpTemplate +" [PUSH_URL] "+pushUrl+" [PUSH_RESPONSE] "+pushResponse );
			
			response.setSecretQuestion(null);
		} catch (Exception e) 
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), UserServiceConstants.PACKAGE_FOR_EXCEPTION);
			
			UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			response.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			response.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e);
		}
		
		return response;
	}


	@Transactional
	@Override
	public ResponseObject signUpUserOnDevice(SignUpRequest signUpRequest) 
	{
		ResponseObject response = new ResponseObject();
		
		try{
			
			String codeMsisdn = (String) cacheManager.getFromCache(signUpRequest.getCustId(), MemCacheUtils.ACTIVATION_CACHE);
			String sendActivationCode = null;
			String customerMSISDN = null;
			String receivedActivationCode = signUpRequest.getActivationCode();
			
			if(codeMsisdn == null){
				response.setStatus(ErrorCodes.ACTIVATION_CODE_EXPIRED.getCode());
				response.setMessage(ErrorCodes.ACTIVATION_CODE_EXPIRED.getMessage());
				
				return response;
			}
			
			String[] codeMsisdnArr = codeMsisdn.split("#");
			
			sendActivationCode = codeMsisdnArr[0];
			customerMSISDN = codeMsisdnArr[1];
			
			if(!sendActivationCode.equals(receivedActivationCode)){
				response.setStatus(ErrorCodes.INVALID_ACTIVATION_CODE.getCode());
				response.setMessage(ErrorCodes.INVALID_ACTIVATION_CODE.getMessage());
				
				return response;
			}
			
			/*InventoryMgmt inventoryMgmt = userDao.getInventoryDetails(signUpRequest.getSkuId());
			
			if(inventoryMgmt == null)
			{
				response.setStatus(ErrorCodes.INVALID_PAYCARD_ID.getCode());
				response.setMessage(ErrorCodes.INVALID_PAYCARD_ID.getMessage());
				
				return response;
			}
			
			if(inventoryMgmt.getCustomerMSISDN() == null || !inventoryMgmt.getCustomerMSISDN().equals(customerMSISDN))
			{
				response.setStatus(ErrorCodes.INVALID_PAYCARD_ID.getCode());
				response.setMessage(ErrorCodes.INVALID_PAYCARD_ID.getMessage());
				
				return response;
			}*/
			
			//update deviceSerialNumber also
			
			Subscriber subscriber = (Subscriber) userDao.getLoginInfo(customerMSISDN, UserType.SUBSCRIBER.getUserTypeId());
			
			subscriber.setLoginPin(signUpRequest.getPasswd());
			subscriber.setUserPassword(signUpRequest.getPasswd());
			subscriber.setStatus(SystemConstant.ACTIVE);
			subscriber.setFirstTimeLogin(false);
			subscriber.setInvalidLoginCount(0);
			
			userDao.update(subscriber);
			
			int noOfWallets = new Random().nextInt(4);
			
			noOfWallets = (noOfWallets == 0?1:noOfWallets);
			
			String availableWallets = resourceBundle.getString(UserServiceConstants.AVAILABLE_WALLETS);
			
			String walletData[] = availableWallets.split(",");
			
			for(int counter=0; counter < noOfWallets; counter++)
			{
				String walletInfo[] = walletData[counter].trim().split("#");
				
				CustomerWallets walletDetails = new CustomerWallets();
				
				walletDetails.setCustomerId(signUpRequest.getCustId());
				walletDetails.setCustomerMsisdn(customerMSISDN);
				walletDetails.setWalletNumber(customerMSISDN);
				walletDetails.setWalletName(walletInfo[1]);
				walletDetails.setCurrentBalance(5000.00d);
				walletDetails.setWalletId(Integer.parseInt(walletInfo[0]));
				walletDetails.setWalletStatus("ACTIVE");
				walletDetails.setCreatedOn(new Date());
				
				userDao.saveObject(walletDetails);
				
			}

			
			response.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
			response.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
			
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), UserServiceConstants.PACKAGE_FOR_EXCEPTION);
			
			UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			response.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			response.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e);
		}
		
		return response;
	}



	@Transactional
	@Override
	public ResponseObject getActivationCode(ActivationCodeRequest activationCodeRequest) 
	{
		ResponseObject response = new ResponseObject();
		
		try{
			
			String msisdn = activationCodeRequest.getUserMsisdn();
			
			int mobileNumberLength = platformLoginData.getMobileNumberLength();
			
			if(msisdn.length() < mobileNumberLength){
				response.setStatus(ErrorCodes.INVALID_MOBILE.getCode());
				response.setMessage(ErrorCodes.INVALID_MOBILE.getMessage());
				
				return response;
			}
			
			int subStringStartIndex = (msisdn.length() - mobileNumberLength);
			
			activationCodeRequest.setUserMsisdn(msisdn.substring(subStringStartIndex));
			
			msisdn = activationCodeRequest.getUserMsisdn();
			
			CustomerDetails customerIdData = userDao.getAccountDeails(activationCodeRequest.getCustId());
			
			if(customerIdData == null)
			{
				response.setStatus(ErrorCodes.INVALID_SUBSCRIBER_ID.getCode());
				response.setMessage(ErrorCodes.INVALID_SUBSCRIBER_ID.getMessage());
				
				return response;
			}
			
			/*//Fetch Inventory Details
			InventoryMgmt inventoryMgmt = userDao.getInventoryDetails(activationCodeRequest.getSkuId());
			
			if(inventoryMgmt == null)
			{
				response.setStatus(ErrorCodes.INVALID_REQUEST.getCode());
				response.setMessage(ErrorCodes.INVALID_REQUEST.getMessage());
				
				return response;
			}
			
			if(inventoryMgmt.getCustomerMSISDN() == null || !inventoryMgmt.getCustomerMSISDN().equals(msisdn))
			{
				response.setStatus(ErrorCodes.INVALID_PAYCARD_ID.getCode());
				response.setMessage(ErrorCodes.INVALID_PAYCARD_ID.getMessage());
				
				return response;
			}
			*/

			Subscriber subscriberData = userDao.getSubscriberByCustomerId(activationCodeRequest.getCustId());
			
			if(subscriberData != null)
			{
				response.setStatus(ErrorCodes.ALREADYACTIVATED.getCode());
				response.setMessage(ErrorCodes.ALREADYACTIVATED.getMessage());
				
				return response;
			}
			
			Object resultObject = userDao.getLoginInfo(msisdn, UserType.SUBSCRIBER.getUserTypeId());
			
			if(resultObject == null)
			{
				Subscriber subscriber = new Subscriber();
				
				subscriber.setMobileCode(Integer.parseInt(platformLoginData.getCountryCode()));
				subscriber.setMsisdn(msisdn);
				subscriber.setName(customerIdData.getCustomerName());
				subscriber.setAddDate(new Date());
				subscriber.setStatus(SystemConstant.ACTIVE);
				subscriber.setCustId(customerIdData.getCustomerId());
				
				subscriber.setDateOfBirth(customerIdData.getDateOfBirth());
				subscriber.setEmailId(customerIdData.getEmailId());
				
				
				
				userDao.saveObject(subscriber);
				
				
			}else{
				
				response.setStatus(ErrorCodes.ALREADYEXIST.getCode());
				response.setMessage(ErrorCodes.ALREADYEXIST.getMessage());
				
				return response;
			}
			
			/*Subscriber subscriber = (Subscriber) userDao.getLoginInfo(msisdn, UserType.SUBSCRIBER.getUserTypeId());
			
			if(null != subscriber.getLoginPin()){
				response.setStatus(ErrorCodes.ALREADYACTIVATED.getCode());
				response.setMessage(ErrorCodes.ALREADYACTIVATED.getMessage());
				
				return response;
			}*/
			//Fetch Mapping for user name
			
			String activationCode = commonUtils.getRandomNumber(UserServiceConstants.ACTIVATION_CODE_LENGTH);
			
			String activationTemplate = resourceBundle.getString(UserServiceConstants.ACTIVATION_TEMPLATE);
			
			activationTemplate = KeyEncryptionUtils.replaceArgumentParameters(activationTemplate, new String[]{ "NAME" ,activationCode });
					
			String pushUrl = resourceBundle.getString(UserServiceConstants.SMS_PUSH_URL);
			
			pushUrl = KeyEncryptionUtils.replaceArgumentParameters(pushUrl, new String[]{ msisdn, URLEncoder.encode(activationTemplate, System.getProperty("file.encoding")) });
			
			//String pushResponse = HttpUtils.makeGetRequestToURL(pushUrl, 60000);
			
			String pushResponse = "Success";
			
			cacheManager.addToCache(activationCodeRequest.getCustId(), activationCode+"#"+msisdn, MemCacheUtils.ACTIVATION_CACHE);
			
			response.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
			response.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
			
			response.setActivationCode(activationCode);
			
			UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.INFO, UserServiceConstants.LOGGING_REQUEST + UserServiceConstants.LOGGING_METHOD_NAME +Thread.currentThread().getStackTrace()[1].getMethodName() + " [USER_MSISDN] " + msisdn + " [SKU_ID] " + activationCodeRequest.getSkuId() +  " [ACTIVATION_CODE] " + activationCode);
			
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), UserServiceConstants.PACKAGE_FOR_EXCEPTION);
			
			UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			response.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			response.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e);
		}
		
		return response;
	}



	@Override
	public ResponseObject getUserProfile(UserAccountData accountData)
	{
		ResponseObject response = new ResponseObject();
		
		try{
			UserAddress userAddress = new UserAddress();
			userAddress.setCountry(accountData.getCountry());
			userAddress.setDistrict(accountData.getDistrict());
			userAddress.setLocality(accountData.getLocality());
			userAddress.setPinCode(accountData.getPinCode());
			userAddress.setRegion(accountData.getRegion());
			userAddress.setState(accountData.getState());
			
			UserProfile userProfile = new UserProfile();
			userProfile.setAddress(userAddress);
			userProfile.setDateOfBirth(accountData.getDateOfBirth());
			userProfile.setEmailId(accountData.getEmailId());
			userProfile.setFullName(accountData.getName());
			userProfile.setMobileNo(accountData.getMobileNo());
			
			response.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
			response.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());			
			response.setPayload(KeyEncryptionUtils.encryptUsingKey(accountData.getSecretKey(), userProfile));
			
		}
		catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), UserServiceConstants.PACKAGE_FOR_EXCEPTION);
			
			UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			response.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			response.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e);
		}
	
		return response;
	}



	@Transactional
	@Override
	public ResponseObject saveUpdateProfileImage(MultipartFile userProfile, UserAccountData userAccountData) 
	{
		ResponseObject response = new ResponseObject();
		
		try{
			
			String imageFileName = userAccountData.getName() + "_" + userAccountData.getLoginId() + commonUtils.getDateTime("dd_MM_yyyy_HH_mm_ss", new Date()) + "_" + userProfile.getOriginalFilename();
			
			imageFileName = imageFileName.replace(" ", "_");
			
			File outputfile = new File(platformLoginData.getKycImagePath() + File.separator +imageFileName);
		    
			userProfile.transferTo(outputfile);
		    
			Subscriber subscriber = userDao.getSubscriberDetailsByMsisdn(userAccountData.getMobileNo());
			
			if(subscriber != null)
			{
				subscriber.setProfileImage(imageFileName);
				userDao.update(subscriber);
				
				response.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
				response.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
				
			}else
			{
			response.setStatus(ErrorCodes.INVALID_REQUEST.getCode());
			response.setMessage(ErrorCodes.INVALID_REQUEST.getMessage());			
			}
		}
		catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), UserServiceConstants.PACKAGE_FOR_EXCEPTION);
			
			UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			response.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			response.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e);
		}
	
		return response;
	}

}
