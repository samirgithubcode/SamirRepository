package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;
/**
*
* @author Simran
* 
* The persistent class for the HostSubversion Services database table for OTA.
*/
@Entity
@Table(name = "hostsubversion_services")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "HostSubVersionServices.findByHsvId", query = "SELECT h FROM HostSubVersionServices h where h.hsvId = :hsvId"),
    @NamedQuery(name="HostSubVersionServices.findByHsvIdAndServiceconfigId",query="SELECT h FROM HostSubVersionServices h where h.hsvId = :hsvId AND h.serviceConfigId=:serviceconfigId"), 
    
    
})
public class HostSubVersionServices implements Serializable {
	private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Column(name = "serviceConfigId")
    private Integer serviceConfigId;
    @Basic(optional = false)
    @Column(name = "serviceName")
    private String serviceName;
    @JoinColumn(name = "parentId", referencedColumnName = "id")
    @ManyToOne
    private HostSubVersionServices pId;
    @Column(name = "menuId")
    private String menuId;
	@Column(name = "status")
    private String status;
    @Basic(optional = false)
    @Column(name = "hsvid")
    private Integer hsvId;
    @Column(name = "last_modified")
    @Temporal(TemporalType.TIMESTAMP)
    private Date modifiedDate;
    @Column(name = "scheduledDate") 
    @Temporal(TemporalType.DATE)
    private Date scheduledDate;
    @Column(name = "last_OTA_modified")
    @Temporal(TemporalType.TIMESTAMP)
    private Date otaModifiedDate;
    @Column(name = "addedBy")
    private Integer addedBy;
    @Column(name = "createDate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createDate;
    @Column(name = "modifiedBy") 
    private Integer modifiedBy;
  
   

	public HostSubVersionServices() {
    	//default constructor
    }

    public HostSubVersionServices(Integer id) {
        this.id = id;
    }

    public HostSubVersionServices(Integer id, String serviceName, Date createDate, Date modifiedDate, Date otaModifiedDate) {
        this.id = id;
        this.serviceName = serviceName;
        this.createDate = createDate;
        this.modifiedDate = modifiedDate;
        this.otaModifiedDate = otaModifiedDate;
    } 
    public Integer getAddedBy() {
		return addedBy;
	}
    public Date getScheduledDate() {
		return scheduledDate;
	}

	public void setScheduledDate(Date scheduledDate) {
		this.scheduledDate = scheduledDate;
	}
	public void setAddedBy(Integer addedBy) {
		this.addedBy = addedBy;
	}
    public String getMenuId() {
		return menuId;
	}

	public void setMenuId(String menuId) {
		this.menuId = menuId;
	}

	public Integer getServiceConfigId() {
		return serviceConfigId;
	}

	public void setServiceConfigId(Integer serviceConfigId) {
		this.serviceConfigId = serviceConfigId;
	}

	public Integer getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public HostSubVersionServices getpId() {
		return pId;
	}

	public void setpId(HostSubVersionServices pId) {
		this.pId = pId;
	}


	public Integer getHsvId() {
		return hsvId;
	}

	public void setHsvId(Integer hsvId) {
		this.hsvId = hsvId;
	}
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getOtaModifiedDate() {
		return otaModifiedDate;
	}

	public void setOtaModifiedDate(Date otaModifiedDate) {
		this.otaModifiedDate = otaModifiedDate;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	@Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof HostSubVersionServices)) {
            return false;
        }
        HostSubVersionServices other = (HostSubVersionServices) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.HostSubVersionServices[ id=" + id + " ]";
    }
}
