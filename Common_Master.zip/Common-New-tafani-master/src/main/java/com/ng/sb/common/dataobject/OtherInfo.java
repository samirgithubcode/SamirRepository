/**
 * 
 */
package com.ng.sb.common.dataobject;

/**
 * @author gaurav
 * This class will hold customer's Other Info
 */
public class OtherInfo extends BaseObjectData {
	private static final long serialVersionUID = 1L;
	private String firstName;
	private String lastName;
	private String email;
	private AddressInfo addressInfo;
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public AddressInfo getAddressInfo() {
		return addressInfo;
	}
	public void setAddressInfo(AddressInfo addressInfo) {
		this.addressInfo = addressInfo;
	}
	
}
