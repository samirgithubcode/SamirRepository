package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="VoucherDenomination")
@NamedQueries
({
	@NamedQuery(name="VoucherDenomination.findById", query="SELECT d FROM VoucherDenomination d WHERE d.id = :id"),
	@NamedQuery(name="VoucherDenomination.findByName", query="SELECT d FROM VoucherDenomination d WHERE d.name = :name  AND d.status=1"),
	@NamedQuery(name="VoucherDenomination.findAll", query="SELECT d FROM VoucherDenomination d order by d.startDate"),
	@NamedQuery(name="VoucherDenomination.findAllActive", query="SELECT d FROM VoucherDenomination d WHERE d.status=1 AND d.startDate <= :dd AND d.endDate >= :dd  ORDER BY d.denominationValue"),
	@NamedQuery(name="VoucherDenomination.findAllActiveByCurrency", query="SELECT d FROM VoucherDenomination d where d.currency = :currency order by d.denominationValue"),	
	@NamedQuery(name = "VoucherDenomination.findCountByName", query = "SELECT count(v) FROM VoucherDenomination v WHERE v.name = :name AND v.status=1"),
})
public class VoucherDenomination implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Basic(optional = false)
	private Integer id;
	
	@Column(name = "name")
	private String name;
	
	@Basic(optional = false)
	@Column(name="value")
	private Integer denominationValue;

	@Column(name="currency")
	private String currency;
	
	@Column(name="status")
	private Integer status;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "start_date")
	private Date startDate;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "end_date")
	private Date endDate;

	@Temporal(TemporalType.DATE)
	@Column(name = "addedOn")
	private Date addedOn;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "modifiedOn")
	private Date modifiedOn;
	
	@Column(name = "Remarks")
	private String remarks;
	@Column(name = "addedBy")
	private Integer addedBy;
	@Column(name = "modifiedBy")
	private Integer modifiedBy;
	public VoucherDenomination() {
		//empty
	}
	
	public VoucherDenomination(Integer id)
	{
		this.id = id;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Date getAddedOn() {
		return addedOn;
	}

	public void setAddedOn(Date addedOn) {
		this.addedOn = addedOn;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public String getRemarks() {
		return remarks;
	}

	public Integer getAddedBy() {
		return addedBy;
	}

	public void setAddedBy(Integer addedBy) {
		this.addedBy = addedBy;
	}

	public Integer getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	
	
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}


	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getDenominationValue() {
		return this.denominationValue;
	}

	public void setDenominationValue(Integer denominationValue) {
		this.denominationValue = denominationValue;
	}
	
	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}


	
	

}