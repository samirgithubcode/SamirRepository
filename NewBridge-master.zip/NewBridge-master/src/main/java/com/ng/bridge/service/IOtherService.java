/**
 * 
 */
package com.ng.bridge.service;

/**
 * @author gaurav
 * For other Extra service
 */
public interface IOtherService extends IBridgeService {

}
