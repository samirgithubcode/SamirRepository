package com.ng.sb.common.dao;

public interface IMisDAO extends IDAO {

}
