package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name = "packaging")
@XmlRootElement
@NamedQueries({
	@NamedQuery(name = "Packaging.findAll", query="Select p from Packaging p"),
	@NamedQuery(name = "Packaging.findByPackagingGroup", query="SELECT p FROM Packaging p WHERE p.groupId =:packagingGroup"),
	@NamedQuery(name = "Packaging.findByPackagingGroupProductAndMv", query="SELECT p FROM Packaging p WHERE p.groupId =:packagingGroup AND p.productId =:product AND p.mvId =:mvId AND p.parentPackagingId IS NULL"),
	//@NamedQuery(name = "Packaging.findByPackagingGroupProductAndMv", query="SELECT p FROM Packaging p WHERE p.groupId =:packagingGroup AND p.productId =:product"),
	//@NamedQuery(name = "Packaging.findByPackagingGroupCardAndProduct", query="SELECT p FROM Packaging p WHERE p.groupId =:packagingGroup AND p.productId =:productId AND p.cardDetailsId =:cardDetailsId"),
	@NamedQuery(name = "Packaging.findByPackagingGroupCardAndProduct", query="SELECT p FROM Packaging p WHERE p.groupId =:packagingGroup AND p.productId =:productId"),
	@NamedQuery(name = "Packaging.findById", query="SELECT p FROM Packaging p WHERE p.id =:id"),
	@NamedQuery(name = "Packaging.getByMvProductGroup", query="SELECT p FROM Packaging p WHERE p.groupId.id IN :groupId AND p.productId =:productId AND p.accountId =:accountId AND p.possesionStatus=:possesionStatus AND p.eligibleForShipping=:eligibleForShipping AND p.parentPackagingId IS NULL "),
  //@NamedQuery(name = "Packaging.getByMvProductGroup", query="SELECT p FROM Packaging p WHERE p.groupId.id IN :groupId AND p.productId =:productId AND p.mvId =:mvId AND p.possesionStatus=:possesionStatus  AND parentPackagingId IS NULL"),
	@NamedQuery(name = "Packaging.findPackagesByAccountIdAndPossesionStatus", query="Select p from Packaging p WHERE p.accountId=:accountId  AND p.possesionStatus=:possesionStatus "),
	//@NamedQuery(name = "Packaging.findPackagesDist", query="Select p from Packaging p WHERE p.dId=:dId AND p.sdId is null AND p.possesionStatus=:possesionStatus "),
//	@NamedQuery(name = "Packaging.findPackagesSubDist", query="Select p from Packaging p WHERE p.sdId=:sdId AND p.dId is null AND p.possesionStatus=:possesionStatus "),
//	@NamedQuery(name = "Packaging.findPackagesPlatform", query="Select p from Packaging p WHERE p.pId=:pId AND p.hId is null AND p.possesionStatus=:possesionStatus "),
	@NamedQuery(name = "Packaging.findByPackagingGroupAndProduct", query="SELECT p FROM Packaging p WHERE p.groupId =:packagingGroup AND p.productId =:productId"),
	@NamedQuery(name = "Packaging.getByProductGroup", query="SELECT p FROM Packaging p WHERE p.groupId =:groupId AND p.productId =:productId  AND p.possesionStatus=:possesionStatus"),
	@NamedQuery(name = "Packaging.findPackageByIds", query="SELECT p FROM Packaging p WHERE p.id IN :id"),
	@NamedQuery(name = "Packaging.findPackageByAddedByAndLevel", query="SELECT p FROM Packaging p WHERE p.addById=:addById AND p.packagingLevel=0 "),
//	@NamedQuery(name = "Packaging.findPackageByShippingInfo", query="SELECT p FROM Packaging p WHERE p.shippingInfoId=:shippingInfoId"),
	@NamedQuery(name = "Packaging.findPackageByProductTypeAndAccountDetails", query="SELECT p FROM Packaging p WHERE  p.groupId =:packagingGroup AND p.productId =:product AND p.accountId=:accountId AND p.possesionStatus=:possesionStatus AND p.parentPackagingId IS NULL"),
	@NamedQuery(name = "Packaging.findPackageByParentPackageId", query="SELECT p FROM Packaging p WHERE p.parentPackagingId IN :parentPackagingIds"),
	
	
	
})
public class Packaging implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    
    @Column(name = "product")
    private String product;
    
    @Column(name = "netQuantity")
    private Long netQuantity;
   
	@Column(name = "packagingName")
    private String packagingName;
    
    @Column(name = "productSeriesFrom")
    private String productSeriesFrom;
    
    @Column(name = "productSeriesTo")
    private String productSeriesTo;
    
    @JoinColumn(name = "parentPackagingId", referencedColumnName = "id")
    @ManyToOne
    private Packaging parentPackagingId;
    
    @Column(name = "possesionStatus")
    private String possesionStatus;
    



	@JoinColumn(name = "accountId", referencedColumnName = "id")
    @ManyToOne
    private AccountInfo accountId;
	@Column(name="eligibleForShipping")
	private boolean eligibleForShipping;
	


	public boolean isEligibleForShipping() {
		return eligibleForShipping;
	}

	public void setEligibleForShipping(boolean eligibleForShipping) {
		this.eligibleForShipping = eligibleForShipping;
	}

	/*@JoinColumn(name = "hId", referencedColumnName = "id")
    @ManyToOne
    private AccountInfo hId;
    @JoinColumn(name = "dId", referencedColumnName = "id")
    @ManyToOne
    private AccountInfo dId;
    @JoinColumn(name = "sdId", referencedColumnName = "id")
    @ManyToOne
    private AccountInfo sdId;
    @JoinColumn(name = "rId", referencedColumnName = "id")
    @ManyToOne
    private AccountInfo rId;
    */
    @JoinColumn(name = "addById", referencedColumnName = "id")
    @ManyToOne
    private AccountLoginInfo addById;
    @JoinColumn(name = "editById", referencedColumnName = "id")
    @ManyToOne
    private AccountLoginInfo editById;
    @Column(name = "createDate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createDate;
    public Integer getPackagingLevel() {
		return packagingLevel;
	}

	public void setPackagingLevel(Integer packagingLevel) {
		this.packagingLevel = packagingLevel;
	}

	@Column(name = "editDate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date editDate;
    @JoinColumn(name = "productId", referencedColumnName = "id")
    @ManyToOne
    private Products productId;
    @JoinColumn(name = "mvId", referencedColumnName = "id")
    @ManyToOne
    private MasterVersion mvId;
    @JoinColumn(name = "groupId", referencedColumnName = "id")
    @ManyToOne
    private PackingGroup groupId;
    
    @JoinColumn(name = "cardDetailsId", referencedColumnName = "id")
    @ManyToOne
    private CardDetails cardDetailsId;
    @Column(name="packagingLevel")
    private Integer packagingLevel;
   /* @JoinColumn(name = "shippingInfoId", referencedColumnName = "id")
    @ManyToOne
    private ShippingInfo shippingInfoId;*/
    
    
    
    public Packaging(){
    	//default
    }
    
    public Packaging(Integer id){
    	this.id = id;
    }

    public Long getNetQuantity() {
		return netQuantity;
	}

	public void setNetQuantity(Long netQuantity) {
		this.netQuantity = netQuantity;
	}
	public CardDetails getCardDetailsId() {
		return cardDetailsId;
	}

	public void setCardDetailsId(CardDetails cardDetailsId) {
		this.cardDetailsId = cardDetailsId;
	}
   
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public String getPackagingName() {
		return packagingName;
	}

	public void setPackagingName(String packagingName) {
		this.packagingName = packagingName;
	}

	public String getProductSeriesFrom() {
		return productSeriesFrom;
	}

	public void setProductSeriesFrom(String productSeriesFrom) {
		this.productSeriesFrom = productSeriesFrom;
	}

	public String getProductSeriesTo() {
		return productSeriesTo;
	}

	public void setProductSeriesTo(String productSeriesTo) {
		this.productSeriesTo = productSeriesTo;
	}

	public Packaging getParentPackagingId() {
		return parentPackagingId;
	}

	public void setParentPackagingId(Packaging parentPackagingId) {
		this.parentPackagingId = parentPackagingId;
	}

	public String getPossesionStatus() {
		return possesionStatus;
	}

	public void setPossesionStatus(String possesionStatus) {
		this.possesionStatus = possesionStatus;
	}

/*	public AccountInfo getpId() {
		return pId;
	}

	public void setpId(AccountInfo pId) {
		this.pId = pId;
	}

	public AccountInfo gethId() {
		return hId;
	}

	public void sethId(AccountInfo hId) {
		this.hId = hId;
	}

	public AccountInfo getdId() {
		return dId;
	}

	public void setdId(AccountInfo dId) {
		this.dId = dId;
	}

	public AccountInfo getSdId() {
		return sdId;
	}

	public void setSdId(AccountInfo sdId) {
		this.sdId = sdId;
	}

	public AccountInfo getrId() {
		return rId;
	}

	public void setrId(AccountInfo rId) {
		this.rId = rId;
	}
*/
	public AccountLoginInfo getAddById() {
		return addById;
	}

	/*public ShippingInfo getShippingInfoId() {
		return shippingInfoId;
	}

	public void setShippingInfoId(ShippingInfo shippingInfoId) {
		this.shippingInfoId = shippingInfoId;
	}*/

	public void setAddById(AccountLoginInfo addById) {
		this.addById = addById;
	}

	public AccountLoginInfo getEditById() {
		return editById;
	}

	public void setEditById(AccountLoginInfo editById) {
		this.editById = editById;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getEditDate() {
		return editDate;
	}

	public void setEditDate(Date editDate) {
		this.editDate = editDate;
	}

	public Products getProductId() {
		return productId;
	}

	public void setProductId(Products productId) {
		this.productId = productId;
	}

	public MasterVersion getMvId() {
		return mvId;
	}

	public void setMvId(MasterVersion mvId) {
		this.mvId = mvId;
	}

	public PackingGroup getGroupId() {
		return groupId;
	}

	public void setGroupId(PackingGroup groupId) {
		this.groupId = groupId;
	}
	@Override
	   public int hashCode() {
	       int hash = 0;
	       hash += (id != null ? id.hashCode() : 0);
	       return hash;
	   }
	 
	@Override
    public boolean equals(Object object) {
		
	boolean	check= true;
	if(object!=null){
        if (!(object instanceof Packaging)) {
        	check= false;
        }
        Packaging other = (Packaging) object;
        if((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
	}
        return check;
        
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.Packaging[ id=" + id + " ]";
    }

	

	public AccountInfo getAccountId() {
		return accountId;
	}

	public void setAccountId(AccountInfo accountId) {
		this.accountId = accountId;
	}



}