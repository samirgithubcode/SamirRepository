/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.ColumnTransformer;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

@Entity
@Table(name = "accountInfo")
@XmlRootElement
@NamedQueries({
	@NamedQuery(name = "AccountInfo.startByCompanyName", query = "SELECT a1 FROM AccountInfo a1 where a1.companyName LIKE :companyName" ),
	@NamedQuery(name = "AccountInfo.findByIdandAccountGroupId", query = "SELECT a FROM AccountInfo a where a.id=:id and a.accountGroupId = :accountGroupId"),
    @NamedQuery(name = "AccountInfo.findAll", query = "SELECT a FROM AccountInfo a"),
    @NamedQuery(name = "AccountInfo.findAllVendor", query = "SELECT a FROM AccountInfo a where a.accountGroupId=:vid"),
    @NamedQuery(name = "AccountInfo.findByParentId", query = "SELECT a FROM AccountInfo a where a.parentId=:parentId AND a.status=1 ORDER BY a.companyName ASC"),
    @NamedQuery(name = "AccountInfo.findById", query = "SELECT a FROM AccountInfo a WHERE a.id = :id"),
    @NamedQuery(name = "AccountInfo.findByStatus", query = "SELECT a FROM AccountInfo a WHERE a.status = :status"),
    @NamedQuery(name = "AccountInfo.findByLandMark", query = "SELECT a FROM AccountInfo a WHERE a.landMark = :landMark"),
    @NamedQuery(name = "AccountInfo.findByaddress1", query = "SELECT a FROM AccountInfo a WHERE a.address1 = :address1"),
    @NamedQuery(name = "AccountInfo.findByCity", query = "SELECT a FROM AccountInfo a WHERE a.city = :city"),
    @NamedQuery(name = "AccountInfo.findByDescription", query = "SELECT a FROM AccountInfo a WHERE a.description = :description"),
    @NamedQuery(name = "AccountInfo.findByCompanyName", query = "SELECT a FROM AccountInfo a WHERE a.companyName = :companyName"),
    @NamedQuery(name = "AccountInfo.findByCompanyNameAndParentId", query = "SELECT a FROM AccountInfo a WHERE a.companyName = :companyName and a.parentId=:parentId"),
    @NamedQuery(name = "AccountInfo.findByCountry", query = "SELECT a FROM AccountInfo a WHERE a.country = :country"),
    @NamedQuery(name = "AccountInfo.findByState", query = "SELECT a FROM AccountInfo a WHERE a.state = :state"),
    @NamedQuery(name = "AccountInfo.findByDesKey", query = "SELECT a FROM AccountInfo a WHERE a.desKey = :desKey"),
    @NamedQuery(name = "AccountInfo.findByPincode", query = "SELECT a FROM AccountInfo a WHERE a.pincode = :pincode"),
    @NamedQuery(name = "AccountInfo.findByCompanyLogo", query = "SELECT a FROM AccountInfo a WHERE a.companyLogo = :companyLogo"),
    @NamedQuery(name = "AccountInfo.findByCreateDate", query = "SELECT a FROM AccountInfo a WHERE a.createDate = :createDate"),
    @NamedQuery(name = "AccountInfo.findByEditDate", query = "SELECT a FROM AccountInfo a WHERE a.editDate = :editDate"),
    @NamedQuery(name = "AccountInfo.findByAccountCode", query = "SELECT a FROM AccountInfo a WHERE a.accountCode = :accountCode"),
    @NamedQuery(name = "AccountInfo.accountGroupCode", query = "SELECT a FROM AccountInfo a WHERE a.accountGroupId.groupCode = :groupCode ORDER BY a.companyName ASC"),
    @NamedQuery(name = "AccountInfo.findByGroupId", query = "SELECT a FROM AccountInfo a WHERE a.accountGroupId = :accountGroupId AND a.status=1"),
    @NamedQuery(name ="AccountInfo.findByGroupIds", query = "SELECT a FROM AccountInfo a WHERE a.accountGroupId IN :accountGroupCodeNames"),
	@NamedQuery(name = "AccountInfo.findMaxAccountCode", query = "SELECT MAX(a.accountCode) FROM AccountInfo a"),
	@NamedQuery(name = "AccountInfo.findByGroupCodes", query = "SELECT a FROM AccountInfo a WHERE a.accountGroupId.groupCode in  :groupCodeList"),
	@NamedQuery(name = "AccountInfo.findByHostId", query = "SELECT a FROM AccountInfo a WHERE a.hId=:hId ORDER BY a.companyName DESC"),
	@NamedQuery(name = "AccountInfo.findByDistributorId", query = "SELECT a FROM AccountInfo a WHERE a.dId=:dId ORDER BY a.companyName ASC"),
	@NamedQuery(name = "AccountInfo.findBysubDistributorId", query = "SELECT a FROM AccountInfo a WHERE a.sdId=:sdId"),
	@NamedQuery(name = "AccountInfo.findByRetailerId", query = "SELECT a FROM AccountInfo a WHERE a.rtId=:rtId"),
	@NamedQuery(name = "AccountInfo.findByAccountGroupId", query = "SELECT a FROM AccountInfo a WHERE a.accountGroupId = :accountGroupId ORDER BY a.companyName ASC"),
	@NamedQuery(name = "AccountInfo.findByEkey", query = "SELECT a FROM AccountInfo a WHERE a.desKey = :encryptionKey"),
	@NamedQuery(name = "AccountInfo.searchbyCompanyName", query = "SELECT a FROM AccountInfo a WHERE a.companyName = :companyName"),
	@NamedQuery(name = "AccountInfo.findByParentIds", query = "SELECT a FROM AccountInfo a WHERE a.parentId in :parentId ORDER BY a.companyName ASC"),
	@NamedQuery(name = "AccountInfo.countbyEmail", query = "SELECT count(*) FROM AccountInfo a WHERE a.emailId =:emailId"),
	@NamedQuery(name = "AccountInfo.AccountInfo.countbyEmailandId", query ="SELECT count(*) FROM AccountInfo a WHERE a.emailId =:emailId and a.id=:id"),
    @NamedQuery(name = "AccountInfo.countbyMobno", query = "SELECT count(*) FROM AccountInfo a WHERE a.aamobileNumber =:mobileNumber"),
    @NamedQuery(name = "AccountInfo.countbyMobnoandId", query = "SELECT count(*) FROM AccountInfo a WHERE a.aamobileNumber =:mobileNumber and a.id =:id"),
    @NamedQuery(name = "AccountInfo.findallEmail", query = "SELECT a.emailId FROM AccountInfo a where a.emailId LIKE :emailId"),
    @NamedQuery(name = "AccountInfo.findallMobileNumber", query = "SELECT a.aamobileNumber FROM AccountInfo a where a.aamobileNumber LIKE :mobileNumber"),
    @NamedQuery(name = "AccountInfo.findByPersonName", query = "SELECT a FROM AccountInfo a WHERE a.companyName =:companyName"),
    @NamedQuery(name = "AccountInfo.findByNameOrMobileOrEmail", query = "SELECT a FROM AccountInfo a WHERE a.companyName =:companyName OR a.aamobileNumber =:companyName OR a.emailId =:companyName"),
    @NamedQuery(name = "AccountInfo.findByEmailId", query = "SELECT a FROM AccountInfo a WHERE a.emailId =:emailid"),
    @NamedQuery(name = "AccountInfo.setstatusbyid", query = "UPDATE  AccountInfo a SET a.status=:status  WHERE a.id =:id"),  
    @NamedQuery(name = "AccountInfo.findAgentCompany", query = "SELECT a FROM AccountInfo a WHERE a.accountGroupId=:accountGroupId "),  
    @NamedQuery(name = "AccountInfo.findhostdetailsBystatus", query = "SELECT a FROM AccountInfo a WHERE a.accountGroupId=:accountGroupId and a.hId=:hId AND a.status=1"),
    @NamedQuery(name = "AccountInfo.findDistdetailsBystatus", query = "SELECT a FROM AccountInfo a WHERE a.accountGroupId=:accountGroupId and a.dId=:dId AND a.status=1"),
    @NamedQuery(name = "AccountInfo.findSubDistdetailsBystatus", query = "SELECT a FROM AccountInfo a WHERE a.accountGroupId=:accountGroupId and a.sdId=:sdId AND a.status=1"),
    @NamedQuery(name = "AccountInfo.findhostdetails", query = "SELECT a FROM AccountInfo a WHERE a.accountGroupId=:accountGroupId and a.hId=:hId"),
    @NamedQuery(name = "AccountInfo.findDistdetails", query = "SELECT a FROM AccountInfo a WHERE a.accountGroupId=:accountGroupId and a.dId=:dId"),
    @NamedQuery(name = "AccountInfo.findSubDistdetails", query = "SELECT a FROM AccountInfo a WHERE a.accountGroupId=:accountGroupId and a.sdId=:sdId"),
   // @NamedQuery(name = "AccountInfo.vendorDetails", query = "SELECT a FROM AccountInfo a WHERE a.accountGroupId.groupCode=:groupCode AND a. "),
    @NamedQuery(name = "AccountInfo.findByMobile", query = "SELECT a FROM AccountInfo a WHERE a.aamobileNumber =:mobileNumber"),
    @NamedQuery(name = "AccountInfo.findByMobileByDate", query = "SELECT a FROM AccountInfo a WHERE a.aamobileNumber =:mobileNumber"),
    @NamedQuery(name = "AccountInfo.findImageNameByAccountId", query = "SELECT a FROM AccountInfo a WHERE a.id = :id"),
    
    @NamedQuery(name = "AccountInfo.findDistList", query = "SELECT a FROM AccountInfo a Where a.hId=:hId AND a.dId IS NULL"),
})
public class AccountInfo implements Serializable {
   
	private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Column(name = "landMark")
    private String landMark;
    @Basic(optional = false)
    @Column(name = "status" ,columnDefinition = "tinyint default true")
    private boolean status=true;
    @Column(name = "address1")
    private String address1;
    @Column(name = "address2")
    private String address2;
    @Column(name="locality")
    private String location;
    @Column(name="region")
    private String region;
    @Column(name="district")
    private String district;
    @Column(name = "description")
    private String description;
    @Column(name = "city" ,nullable =true)
    private String city;
    @Basic(optional = false)
    @Column(name = "company_name")
    private String companyName;
    @Column(name = "pincode")
    private Integer pincode;
    @Column(name = "3des_key")
    private String desKey;
    @Column(name = "company_logo")
    private String companyLogo;
    @Column(name = "edit_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date editDate;
    @Basic(optional = false)
    @Column(name = "account_code")
    private Integer accountCode;
    @Basic(optional = false)
    @Column(name = "create_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createDate;
    @Column(name = "longitude")
    private String longitude;
    @Column(name = "hostDeploymentType")
    private String hostDeploymentType;
    @Column(name = "latitude")
    private String latitude;
    @Column(name = "marchantType")
    private String marchantType;
    @Column(name = "under")
    private String under;
      @Column(name = "reasonForBlockUnblock")
    private String reasonForBlockUnblock;
    @Column(name = "emailId")
    @ColumnTransformer(write="AES_ENCRYPT(?, mobileNumber)",read="AES_DECRYPT(emailId, mobileNumber)")
    private String emailId;
    
    @Column(name = "mobileNumber")
    private String aamobileNumber;
    @Column(name = "altMobileNumber")
    private String altMobileNumber;
    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name="countryCodeId", referencedColumnName="id")
    private CountryCode countryCodeId;
    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name="altCountryCodeId", referencedColumnName="id")
    private CountryCode altCountryCodeId;
    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name="addressId", referencedColumnName="id")
    private Address addressId;
    @OneToMany(cascade = CascadeType.ALL,mappedBy = "hostId")
    private Collection<HostSVFspServicesPartnerMapping> hostSVFspServicesPartnerMappingCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "accountId")
    private Collection<InventorySummary> inventorySummaryCollection;
    @OneToMany(cascade = CascadeType.ALL,mappedBy = "hCode")
    private Collection<HostAccountInfo> hostAccountInfoCollection;
    
    
    @OneToMany(cascade = CascadeType.ALL,mappedBy = "editById")
    private Collection<InventoryMgmt> inventoryMgmtCollection3;
    
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "accountId")
    private Collection<InventoryMgmt> inventoryMgmtCollection;
    
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "accountId")
    private Collection<ProductInventorySummary> productInventorySummaryCollection;
    
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "hostId")
    private Collection<PartnerPreference> partnerPreferenceCollection;
    
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "hostId")  
    private Collection<OTAManagement> oTAManagementCollection;
    
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "cashInFor")
    private Collection<CashInDetail> cashInDetailCollection;
    
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "cashInBy")
    private Collection<CashInDetail> cashInDetailCollection1;
    
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "accountId")
    private Collection<AccountSessionInfo> accountSessionInfoCollection;
    
    @LazyCollection(LazyCollectionOption.FALSE)
    @OneToMany(cascade = CascadeType.ALL,mappedBy = "hostId")
    private Collection<HostSubVersion> hostSubVersionCollection;
    @OneToMany(cascade = CascadeType.ALL,mappedBy = "hostId")
    private Collection<HostSVProviderPartnerMapping> hostSVProviderPartnerMappingCollection;
    @OneToMany(cascade = CascadeType.ALL,mappedBy = "accountId")
    private Collection<ComplaintSubCategoryTypes> complaintSubCategoryTypesCollection;
    @OneToMany(cascade = CascadeType.ALL,mappedBy = "accountInfoId")
    private Collection<MerchantDetail> merchantDetailCollection;
    @OneToMany(cascade = CascadeType.ALL,mappedBy = "toId")
    private Collection<InventoryOrder> inventoryOrderCollection;
    @OneToMany(cascade = CascadeType.ALL,mappedBy = "fromId")
    private Collection<InventoryOrder> inventoryOrderCollection1;
    @OneToMany(cascade = CascadeType.ALL,mappedBy = "hostId")
    private Collection<InventoryOrder> inventoryOrderCollection2;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "destinationId")
    private Collection<AccountInfoMapping> accountInfoMappingCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "sourceId")
    private Collection<AccountInfoMapping> accountInfoMappingCollection1;
    @OneToMany(cascade = CascadeType.ALL,mappedBy = "bcId")
    private Collection<AccountLoginInfo> accountLoginInfoCollection;
    @OneToMany(cascade = CascadeType.ALL,mappedBy = "rtId")
    private Collection<AccountLoginInfo> accountLoginInfoCollection1;
    @OneToMany(cascade = CascadeType.ALL,mappedBy = "sdId")
    private Collection<AccountLoginInfo> accountLoginInfoCollection2;
    @OneToMany(cascade = CascadeType.ALL,mappedBy = "dId")
    private Collection<AccountLoginInfo> accountLoginInfoCollection3;
    @OneToMany(cascade = CascadeType.ALL,mappedBy = "hId")
    private Collection<AccountLoginInfo> accountLoginInfoCollection4;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "accountId")
    private Collection<AccountLoginInfo> accountLoginInfoCollection5;
    @OneToMany(cascade = CascadeType.ALL,mappedBy = "hostId")
    private Collection<HostSVServiceConfigMapping> hostSVServiceConfigMappingCollection;
    @OneToMany(cascade = CascadeType.ALL,mappedBy = "hostId")
    private Collection<TransactionInfo> transactionInfoCollection;
    @OneToMany(cascade = CascadeType.ALL,mappedBy = "parentId")
    private Collection<MerchantAccountInfoHistory> merchantAccountInfoHistoryCollection;
    @OneToMany(cascade = CascadeType.ALL,mappedBy = "editbyId")
    private Collection<MerchantAccountInfoHistory> merchantAccountInfoHistoryCollection1;
    @OneToMany(cascade = CascadeType.ALL,mappedBy = "rtId")
    private Collection<MerchantAccountInfoHistory> merchantAccountInfoHistoryCollection3;
    @OneToMany(cascade = CascadeType.ALL,mappedBy = "sdId")
    private Collection<MerchantAccountInfoHistory> merchantAccountInfoHistoryCollection4;
    @OneToMany(cascade = CascadeType.ALL,mappedBy = "parentMerchantId")
    private Collection<MerchantAccountInfoHistory> merchantAccountInfoHistoryCollection5;
    @OneToMany(cascade = CascadeType.ALL,mappedBy = "dId")
    private Collection<MerchantAccountInfoHistory> merchantAccountInfoHistoryCollection6;
    @OneToMany(cascade = CascadeType.ALL,mappedBy = "hId")
    private Collection<MerchantAccountInfoHistory> merchantAccountInfoHistoryCollection7;
    @OneToMany(cascade = CascadeType.ALL,mappedBy = "hostId")
    private Collection<HostSVFinInstrumentPartnerMapping> hostSVFinInstrumentPartnerMappingCollection;
    @OneToMany(cascade = CascadeType.ALL,mappedBy = "hostId")
    private Collection<Partner> partnerCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "hostId")
    private Collection<HostIdProofMapping> hostIdProofMappingCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "fromId")
    private Collection<InventoryOrderHistory> inventoryOrderHistoryCollection;
    @OneToMany(cascade = CascadeType.ALL,mappedBy = "hostId")
    private Collection<InventoryOrderHistory> inventoryOrderHistoryCollection1;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "toId")
    private Collection<InventoryOrderHistory> inventoryOrderHistoryCollection2;
    @OneToMany(cascade = CascadeType.ALL,mappedBy = "parentId")
    private Collection<AccountInfo> accountInfoCollection;
    @JoinColumn(name = "parent_id", referencedColumnName = "id")
    @ManyToOne(fetch=FetchType.LAZY)
    private AccountInfo parentId;
    @OneToMany(cascade = CascadeType.ALL,mappedBy = "editbyId")
    private Collection<AccountInfo> accountInfoCollection1;
    @JoinColumn(name = "editby_id", referencedColumnName = "id")
    @ManyToOne(fetch=FetchType.LAZY)
    private AccountInfo editbyId;
    @OneToMany(cascade = CascadeType.ALL,mappedBy = "addbyId")
    private Collection<AccountInfo> accountInfoCollection2;
    @JoinColumn(name = "addby_id", referencedColumnName = "id")
    @ManyToOne(fetch=FetchType.LAZY)
    private AccountLoginInfo addbyId;
    @JoinColumn(name = "account_group_id", referencedColumnName = "id")
    @ManyToOne(fetch=FetchType.LAZY)
    private SysAccountGroup accountGroupId;
    @OneToMany(mappedBy = "parentMerchantId")
    private Collection<AccountInfo> accountInfoCollection3;
    @JoinColumn(name = "parentMerchantId", referencedColumnName = "id")
    @ManyToOne(fetch=FetchType.LAZY)
    private AccountInfo parentMerchantId;
    @OneToMany(mappedBy = "rtId")
    private Collection<AccountInfo> accountInfoCollection4;
    @JoinColumn(name = "rtId", referencedColumnName = "id")
    @ManyToOne(fetch=FetchType.LAZY)
    private AccountInfo rtId;
    @OneToMany(mappedBy = "sdId")
    private Collection<AccountInfo> accountInfoCollection5;
    @JoinColumn(name = "sdId", referencedColumnName = "id")
    @ManyToOne(fetch=FetchType.LAZY)
    private AccountInfo sdId;
    @OneToMany(cascade = CascadeType.ALL , mappedBy = "dId")
    private Collection<AccountInfo> accountInfoCollection6;
    @JoinColumn(name = "dId", referencedColumnName = "id")
    @ManyToOne(fetch=FetchType.LAZY)
    private AccountInfo dId;
    @OneToMany(cascade = CascadeType.ALL,mappedBy = "hId")
    private Collection<AccountInfo> accountInfoCollection7;
    @JoinColumn(name = "hId", referencedColumnName = "id")
    @ManyToOne(fetch=FetchType.LAZY)
    private AccountInfo hId;
    @Column(name = "country")
    private String country;
    @Column(name = "state")
    private String state;
    @OneToMany(cascade = CascadeType.ALL,mappedBy = "hostId")
    private Collection<HostSVWalletMapping> hostSVWalletMappingCollection;
    @OneToMany(cascade = CascadeType.ALL,mappedBy = "accountId")
    private Collection<ComplaintCategoryTypes> complaintCategoryTypesCollection;
    public String getTxnNature() {
		return txnNature;
	}
    public void setTxnNature(String txnNature) {
		this.txnNature = txnNature;
	}
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "toId")
    private Collection<ShippingDetails> shippingDetailsCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "fromId")
    private Collection<ShippingDetails> shippingDetailsCollection1;
    @Column(name = "txnNature")
    private String txnNature;
    @Column(name = "profileImageName")
    private String profileImageName;
    
    
    
    
    public String getProfileImageName() {
		return profileImageName;
	}
	public void setProfileImageName(String profileImageName) {
		this.profileImageName = profileImageName;
	}
	public AccountInfo() {
   	 // Do nothing because its a default constructor..
   }
   public AccountInfo(Integer id) {
       this.id = id;
   }
   public AccountInfo(Integer id, boolean status, String companyName, Date createDate, int accountCode) {
       this.id = id;
       this.status = status;
       this.companyName = companyName;
       this.createDate = createDate;
       this.accountCode = accountCode;
   }
	public CountryCode getAltCountryCodeId() {
		return altCountryCodeId;
	}
	public void setAltCountryCodeId(CountryCode altCountryCodeId) {
		this.altCountryCodeId = altCountryCodeId;
	}
	public CountryCode getCountryCodeId() {
		return countryCodeId;
	}
	public void setCountryCodeId(CountryCode countryCodeId) {
		this.countryCodeId = countryCodeId;
	}
	
    public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getMobileNumber() {
		return aamobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.aamobileNumber = mobileNumber;
	}
	public String getAltMobileNumber() {
		return altMobileNumber;
	}
	public void setAltMobileNumber(String altMobileNumber) {
		this.altMobileNumber = altMobileNumber;
	}
	
	 public Integer getId() {
	        return id;
	    }
	    public void setId(Integer id) {
	        this.id = id;
	    }
	
    public Address getAddressId() {
		return addressId;
	}
	public void setAddressId(Address addressId) {
		this.addressId = addressId;
	}
	   
   
   
    public String getLandMark() {
        return landMark;
    }
    public void setLandMark(String landMark) {
        this.landMark = landMark;
    }
    

    public boolean getStatus() {
        return status;
    }
    public void setStatus(boolean status) {
        this.status = status;
    }
    
    public String getAddress1() {
        return address1;
    }
    public void setAddress1(String address1) {
        this.address1 = address1;
    }
    public String getAddress2() {
        return address2;
    }
    public void setAddress2(String address2) {
        this.address2 = address2;
    }
       
    public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public AccountInfo getdIdn() {
		return dId;
	}

	public void setdIdn(AccountInfo dId) {
		this.dId = dId;
	}

	public AccountInfo gethIdn() {
		return hId;
	}

	public void sethIdn(AccountInfo hId) {
		this.hId = hId;
	}

	public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public String getCity() {
        return city;
    }
    public void setCity(String city) {
        this.city = city;
    }
    public String getDesKey() {
        return desKey;
    }
    public void setDesKey(String desKey) {
        this.desKey = desKey;
    }
    public String getCompanyName() {
        return companyName;
    }
    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }
    public Integer getPincode() {
        return pincode;
    }
    public void setPincode(Integer pincode) {
        this.pincode = pincode;
    }
    public Date getCreateDate() {
        return createDate;
    }
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }
    public String getCompanyLogo() {
        return companyLogo;
    }
    public void setCompanyLogo(String companyLogo) {
        this.companyLogo = companyLogo;
    }
    public Date getEditDate() {
        return editDate;
    }
    public void setEditDate(Date editDate) {
        this.editDate = editDate;
    }
    public String getHostDeploymentType() {
        return hostDeploymentType;
    }
    public void setHostDeploymentType(String hostDeploymentType) {
        this.hostDeploymentType = hostDeploymentType;
    }
    public int getAccountCode() {
        return accountCode;
    }
    public void setAccountCode(int accountCode) {
        this.accountCode = accountCode;
    }
    public String getMarchantType() {
        return marchantType;
    }
    public void setMarchantType(String marchantType) {
        this.marchantType = marchantType;
    }
    public String getLatitude() {
        return latitude;
    }
    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }
    public String getLongitude() {
        return longitude;
    }
    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }
    public String getRegion() {
        return region;
    }
    public void setRegion(String region) {
        this.region = region;
    }
    public String getUnder() {
        return under;
    }
    public void setUnder(String under) {
        this.under = under;
    }
    @XmlTransient
    public Collection<HostSVFspServicesPartnerMapping> getHostSVFspServicesPartnerMappingCollection() {
        return hostSVFspServicesPartnerMappingCollection;
    }
    public void setHostSVFspServicesPartnerMappingCollection(Collection<HostSVFspServicesPartnerMapping> hostSVFspServicesPartnerMappingCollection) {
        this.hostSVFspServicesPartnerMappingCollection = hostSVFspServicesPartnerMappingCollection;
    }
    @XmlTransient
    public Collection<InventorySummary> getInventorySummaryCollection() {
        return inventorySummaryCollection;
    }
    public void setInventorySummaryCollection(Collection<InventorySummary> inventorySummaryCollection) {
        this.inventorySummaryCollection = inventorySummaryCollection;
    }
    @XmlTransient
    public Collection<HostAccountInfo> getHostAccountInfoCollection() {
        return hostAccountInfoCollection;
    }
    public void setHostAccountInfoCollection(Collection<HostAccountInfo> hostAccountInfoCollection) {
        this.hostAccountInfoCollection = hostAccountInfoCollection;
    }
    @XmlTransient
    public Collection<InventoryMgmt> getInventoryMgmtCollection() {
        return inventoryMgmtCollection;
    }
    public void setInventoryMgmtCollection(Collection<InventoryMgmt> inventoryMgmtCollection) {
        this.inventoryMgmtCollection = inventoryMgmtCollection;
    }
    
    @XmlTransient
    public Collection<InventoryMgmt> getInventoryMgmtCollection3() {
        return inventoryMgmtCollection3;
    }
    public void setInventoryMgmtCollection3(Collection<InventoryMgmt> inventoryMgmtCollection3) {
        this.inventoryMgmtCollection3 = inventoryMgmtCollection3;
    }
    @XmlTransient
    public Collection<ProductInventorySummary> getProductInventorySummaryCollection() {
        return productInventorySummaryCollection;
    }
    public void setProductInventorySummaryCollection(Collection<ProductInventorySummary> productInventorySummaryCollection) {
        this.productInventorySummaryCollection = productInventorySummaryCollection;
    }
    @XmlTransient
    public Collection<PartnerPreference> getPartnerPreferenceCollection() {
        return partnerPreferenceCollection;
    }
    public void setPartnerPreferenceCollection(Collection<PartnerPreference> partnerPreferenceCollection) {
        this.partnerPreferenceCollection = partnerPreferenceCollection;
    }
    @XmlTransient
    public Collection<OTAManagement> getOTAManagementCollection() {
        return oTAManagementCollection;
    }
    public void setOTAManagementCollection(Collection<OTAManagement> oTAManagementCollection) {
        this.oTAManagementCollection = oTAManagementCollection;
    }
    @XmlTransient
    public Collection<CashInDetail> getCashInDetailCollection() {
        return cashInDetailCollection;
    }
    public void setCashInDetailCollection(Collection<CashInDetail> cashInDetailCollection) {
        this.cashInDetailCollection = cashInDetailCollection;
    }
    @XmlTransient
    public Collection<CashInDetail> getCashInDetailCollection1() {
        return cashInDetailCollection1;
    }
    public void setCashInDetailCollection1(Collection<CashInDetail> cashInDetailCollection1) {
        this.cashInDetailCollection1 = cashInDetailCollection1;
    }
    @XmlTransient
    public Collection<AccountSessionInfo> getAccountSessionInfoCollection() {
        return accountSessionInfoCollection;
    }
    public void setAccountSessionInfoCollection(Collection<AccountSessionInfo> accountSessionInfoCollection) {
        this.accountSessionInfoCollection = accountSessionInfoCollection;
    }
    @XmlTransient
    public Collection<HostSubVersion> getHostSubVersionCollection() {
        return hostSubVersionCollection;
    }
    public void setHostSubVersionCollection(Collection<HostSubVersion> hostSubVersionCollection) {
        this.hostSubVersionCollection = hostSubVersionCollection;
    }
    @XmlTransient
    public Collection<HostSVProviderPartnerMapping> getHostSVProviderPartnerMappingCollection() {
        return hostSVProviderPartnerMappingCollection;
    }
    public void setHostSVProviderPartnerMappingCollection(Collection<HostSVProviderPartnerMapping> hostSVProviderPartnerMappingCollection) {
        this.hostSVProviderPartnerMappingCollection = hostSVProviderPartnerMappingCollection;
    }
    @XmlTransient
    public Collection<ComplaintSubCategoryTypes> getComplaintSubCategoryTypesCollection() {
        return complaintSubCategoryTypesCollection;
    }
    public void setComplaintSubCategoryTypesCollection(Collection<ComplaintSubCategoryTypes> complaintSubCategoryTypesCollection) {
        this.complaintSubCategoryTypesCollection = complaintSubCategoryTypesCollection;
    }
    @XmlTransient
    public Collection<MerchantDetail> getMerchantDetailCollection() {
        return merchantDetailCollection;
    }
    public void setMerchantDetailCollection(Collection<MerchantDetail> merchantDetailCollection) {
        this.merchantDetailCollection = merchantDetailCollection;
    }
    @XmlTransient
    public Collection<InventoryOrder> getInventoryOrderCollection() {
        return inventoryOrderCollection;
    }
    public void setInventoryOrderCollection(Collection<InventoryOrder> inventoryOrderCollection) {
        this.inventoryOrderCollection = inventoryOrderCollection;
    }
    @XmlTransient
    public Collection<InventoryOrder> getInventoryOrderCollection1() {
        return inventoryOrderCollection1;
    }
    public void setInventoryOrderCollection1(Collection<InventoryOrder> inventoryOrderCollection1) {
        this.inventoryOrderCollection1 = inventoryOrderCollection1;
    }
    @XmlTransient
    public Collection<InventoryOrder> getInventoryOrderCollection2() {
        return inventoryOrderCollection2;
    }
    public void setInventoryOrderCollection2(Collection<InventoryOrder> inventoryOrderCollection2) {
        this.inventoryOrderCollection2 = inventoryOrderCollection2;
    }

    @XmlTransient
    public Collection<AccountInfoMapping> getAccountInfoMappingCollection() {
        return accountInfoMappingCollection;
    }
    public void setAccountInfoMappingCollection(Collection<AccountInfoMapping> accountInfoMappingCollection) {
        this.accountInfoMappingCollection = accountInfoMappingCollection;
    }
    @XmlTransient
    public Collection<AccountInfoMapping> getAccountInfoMappingCollection1() {
        return accountInfoMappingCollection1;
    }
    public void setAccountInfoMappingCollection1(Collection<AccountInfoMapping> accountInfoMappingCollection1) {
        this.accountInfoMappingCollection1 = accountInfoMappingCollection1;
    }
    @XmlTransient
    public Collection<AccountLoginInfo> getAccountLoginInfoCollection() {
        return accountLoginInfoCollection;
    }
    public void setAccountLoginInfoCollection(Collection<AccountLoginInfo> accountLoginInfoCollection) {
        this.accountLoginInfoCollection = accountLoginInfoCollection;
    }
    @XmlTransient
    public Collection<AccountLoginInfo> getAccountLoginInfoCollection1() {
        return accountLoginInfoCollection1;
    }
    public void setAccountLoginInfoCollection1(Collection<AccountLoginInfo> accountLoginInfoCollection1) {
        this.accountLoginInfoCollection1 = accountLoginInfoCollection1;
    }
    @XmlTransient
    public Collection<AccountLoginInfo> getAccountLoginInfoCollection2() {
        return accountLoginInfoCollection2;
    }
    public void setAccountLoginInfoCollection2(Collection<AccountLoginInfo> accountLoginInfoCollection2) {
        this.accountLoginInfoCollection2 = accountLoginInfoCollection2;
    }
    @XmlTransient
    public Collection<AccountLoginInfo> getAccountLoginInfoCollection3() {
        return accountLoginInfoCollection3;
    }
    public void setAccountLoginInfoCollection3(Collection<AccountLoginInfo> accountLoginInfoCollection3) {
        this.accountLoginInfoCollection3 = accountLoginInfoCollection3;
    }
    @XmlTransient
    public Collection<AccountLoginInfo> getAccountLoginInfoCollection4() {
        return accountLoginInfoCollection4;
    }
    public void setAccountLoginInfoCollection4(Collection<AccountLoginInfo> accountLoginInfoCollection4) {
        this.accountLoginInfoCollection4 = accountLoginInfoCollection4;
    }
    @XmlTransient
    public Collection<AccountLoginInfo> getAccountLoginInfoCollection5() {
        return accountLoginInfoCollection5;
    }
    public void setAccountLoginInfoCollection5(Collection<AccountLoginInfo> accountLoginInfoCollection5) {
        this.accountLoginInfoCollection5 = accountLoginInfoCollection5;
    }
    @XmlTransient
    public Collection<HostSVServiceConfigMapping> getHostSVServiceConfigMappingCollection() {
        return hostSVServiceConfigMappingCollection;
    }
    public void setHostSVServiceConfigMappingCollection(Collection<HostSVServiceConfigMapping> hostSVServiceConfigMappingCollection) {
        this.hostSVServiceConfigMappingCollection = hostSVServiceConfigMappingCollection;
    }
    @XmlTransient
    public Collection<TransactionInfo> getTransactionInfoCollection() {
        return transactionInfoCollection;
    }
    public void setTransactionInfoCollection(Collection<TransactionInfo> transactionInfoCollection) {
        this.transactionInfoCollection = transactionInfoCollection;
    }
    @XmlTransient
    public Collection<MerchantAccountInfoHistory> getMerchantAccountInfoHistoryCollection() {
        return merchantAccountInfoHistoryCollection;
    }
    public void setMerchantAccountInfoHistoryCollection(Collection<MerchantAccountInfoHistory> merchantAccountInfoHistoryCollection) {
        this.merchantAccountInfoHistoryCollection = merchantAccountInfoHistoryCollection;
    }
    @XmlTransient
    public Collection<MerchantAccountInfoHistory> getMerchantAccountInfoHistoryCollection1() {
        return merchantAccountInfoHistoryCollection1;
    }
    public void setMerchantAccountInfoHistoryCollection1(Collection<MerchantAccountInfoHistory> merchantAccountInfoHistoryCollection1) {
        this.merchantAccountInfoHistoryCollection1 = merchantAccountInfoHistoryCollection1;
    }
       @XmlTransient
    public Collection<MerchantAccountInfoHistory> getMerchantAccountInfoHistoryCollection3() {
        return merchantAccountInfoHistoryCollection3;
    }
    public void setMerchantAccountInfoHistoryCollection3(Collection<MerchantAccountInfoHistory> merchantAccountInfoHistoryCollection3) {
        this.merchantAccountInfoHistoryCollection3 = merchantAccountInfoHistoryCollection3;
    }
    @XmlTransient
    public Collection<MerchantAccountInfoHistory> getMerchantAccountInfoHistoryCollection4() {
        return merchantAccountInfoHistoryCollection4;
    }
    public void setMerchantAccountInfoHistoryCollection4(Collection<MerchantAccountInfoHistory> merchantAccountInfoHistoryCollection4) {
        this.merchantAccountInfoHistoryCollection4 = merchantAccountInfoHistoryCollection4;
    }
    @XmlTransient
    public Collection<MerchantAccountInfoHistory> getMerchantAccountInfoHistoryCollection5() {
        return merchantAccountInfoHistoryCollection5;
    }
    public void setMerchantAccountInfoHistoryCollection5(Collection<MerchantAccountInfoHistory> merchantAccountInfoHistoryCollection5) {
        this.merchantAccountInfoHistoryCollection5 = merchantAccountInfoHistoryCollection5;
    }
    @XmlTransient
    public Collection<MerchantAccountInfoHistory> getMerchantAccountInfoHistoryCollection6() {
        return merchantAccountInfoHistoryCollection6;
    }
    public void setMerchantAccountInfoHistoryCollection6(Collection<MerchantAccountInfoHistory> merchantAccountInfoHistoryCollection6) {
        this.merchantAccountInfoHistoryCollection6 = merchantAccountInfoHistoryCollection6;
    }
    @XmlTransient
    public Collection<MerchantAccountInfoHistory> getMerchantAccountInfoHistoryCollection7() {
        return merchantAccountInfoHistoryCollection7;
    }
    public void setMerchantAccountInfoHistoryCollection7(Collection<MerchantAccountInfoHistory> merchantAccountInfoHistoryCollection7) {
        this.merchantAccountInfoHistoryCollection7 = merchantAccountInfoHistoryCollection7;
    }
    @XmlTransient
    public Collection<HostSVFinInstrumentPartnerMapping> getHostSVFinInstrumentPartnerMappingCollection() {
        return hostSVFinInstrumentPartnerMappingCollection;
    }
    public void setHostSVFinInstrumentPartnerMappingCollection(Collection<HostSVFinInstrumentPartnerMapping> hostSVFinInstrumentPartnerMappingCollection) {
        this.hostSVFinInstrumentPartnerMappingCollection = hostSVFinInstrumentPartnerMappingCollection;
    }
    @XmlTransient
    public Collection<Partner> getPartnerCollection() {
        return partnerCollection;
    }
    public void setPartnerCollection(Collection<Partner> partnerCollection) {
        this.partnerCollection = partnerCollection;
    }
    @XmlTransient
    public Collection<HostIdProofMapping> getHostIdProofMappingCollection() {
        return hostIdProofMappingCollection;
    }
    public void setHostIdProofMappingCollection(Collection<HostIdProofMapping> hostIdProofMappingCollection) {
        this.hostIdProofMappingCollection = hostIdProofMappingCollection;
    }
    @XmlTransient
    public Collection<InventoryOrderHistory> getInventoryOrderHistoryCollection() {
        return inventoryOrderHistoryCollection;
    }
    public void setInventoryOrderHistoryCollection(Collection<InventoryOrderHistory> inventoryOrderHistoryCollection) {
        this.inventoryOrderHistoryCollection = inventoryOrderHistoryCollection;
    }
    @XmlTransient
    public Collection<InventoryOrderHistory> getInventoryOrderHistoryCollection1() {
        return inventoryOrderHistoryCollection1;
    }
    public void setInventoryOrderHistoryCollection1(Collection<InventoryOrderHistory> inventoryOrderHistoryCollection1) {
        this.inventoryOrderHistoryCollection1 = inventoryOrderHistoryCollection1;
    }
    @XmlTransient
    public Collection<InventoryOrderHistory> getInventoryOrderHistoryCollection2() {
        return inventoryOrderHistoryCollection2;
    }
    public void setInventoryOrderHistoryCollection2(Collection<InventoryOrderHistory> inventoryOrderHistoryCollection2) {
        this.inventoryOrderHistoryCollection2 = inventoryOrderHistoryCollection2;
    }
    @XmlTransient
    public Collection<AccountInfo> getAccountInfoCollection() {
        return accountInfoCollection;
    }
    public void setAccountInfoCollection(Collection<AccountInfo> accountInfoCollection) {
        this.accountInfoCollection = accountInfoCollection;
    }
    public AccountInfo getParentId() {
        return parentId;
    }
    public void setParentId(AccountInfo parentId) {
        this.parentId = parentId;
    }
    @XmlTransient
    public Collection<AccountInfo> getAccountInfoCollection1() {
        return accountInfoCollection1;
    }
    public void setAccountInfoCollection1(Collection<AccountInfo> accountInfoCollection1) {
        this.accountInfoCollection1 = accountInfoCollection1;
    }
    public AccountInfo getEditbyId() {
        return editbyId;
    }
    public void setEditbyId(AccountInfo editbyId) {
        this.editbyId = editbyId;
    }
    @XmlTransient
    public Collection<AccountInfo> getAccountInfoCollection2() {
        return accountInfoCollection2;
    }
    public void setAccountInfoCollection2(Collection<AccountInfo> accountInfoCollection2) {
        this.accountInfoCollection2 = accountInfoCollection2;
    }
    public AccountLoginInfo getAddbyId() {
		return addbyId;
	}
	public void setAddbyId(AccountLoginInfo addbyId) {
		this.addbyId = addbyId;
	}
	public SysAccountGroup getAccountGroupId() {
        return accountGroupId;
    }
    public void setAccountGroupId(SysAccountGroup accountGroupId) {
        this.accountGroupId = accountGroupId;
    }
    @XmlTransient
    public Collection<AccountInfo> getAccountInfoCollection3() {
        return accountInfoCollection3;
    }
    public void setAccountInfoCollection3(Collection<AccountInfo> accountInfoCollection3) {
        this.accountInfoCollection3 = accountInfoCollection3;
    }
    public AccountInfo getParentMerchantId() {
        return parentMerchantId;
    }
    public void setParentMerchantId(AccountInfo parentMerchantId) {
        this.parentMerchantId = parentMerchantId;
    }
    @XmlTransient
    public Collection<AccountInfo> getAccountInfoCollection4() {
        return accountInfoCollection4;
    }
    public void setAccountInfoCollection4(Collection<AccountInfo> accountInfoCollection4) {
        this.accountInfoCollection4 = accountInfoCollection4;
    }
    public AccountInfo getRtId() {
        return rtId;
    }
    public void setRtId(AccountInfo rtId) {
        this.rtId = rtId;
    }
    @XmlTransient
    public Collection<AccountInfo> getAccountInfoCollection5() {
        return accountInfoCollection5;
    }
    public void setAccountInfoCollection5(Collection<AccountInfo> accountInfoCollection5) {
        this.accountInfoCollection5 = accountInfoCollection5;
    }
    public AccountInfo getSdId() {
        return sdId;
    }
    public void setSdId(AccountInfo sdId) {
        this.sdId = sdId;
    }
    @XmlTransient
    public Collection<AccountInfo> getAccountInfoCollection6() {
        return accountInfoCollection6;
    }
    public void setAccountInfoCollection6(Collection<AccountInfo> accountInfoCollection6) {
        this.accountInfoCollection6 = accountInfoCollection6;
    }
    public AccountInfo getDId() {
        return dId;
    }
    public void setDId(AccountInfo dId) {
        this.dId = dId;
    }
    @XmlTransient
    public Collection<AccountInfo> getAccountInfoCollection7() {
        return accountInfoCollection7;
    }
    public void setAccountInfoCollection7(Collection<AccountInfo> accountInfoCollection7) {
        this.accountInfoCollection7 = accountInfoCollection7;
    }
    public String getCountry() {
        return country;
    }
    public void setCountry(String country) {
        this.country = country;
    }
    public AccountInfo getHId() {
        return hId;
    }
    public void setHId(AccountInfo hId) {
        this.hId = hId;
    }
    public String getState() {
        return state;
    }
    public void setState(String state) {
        this.state = state;
    }
    @XmlTransient
    public Collection<HostSVWalletMapping> getHostSVWalletMappingCollection() {
        return hostSVWalletMappingCollection;
    }
    public void setHostSVWalletMappingCollection(Collection<HostSVWalletMapping> hostSVWalletMappingCollection) {
        this.hostSVWalletMappingCollection = hostSVWalletMappingCollection;
    }
    @XmlTransient
    public Collection<ComplaintCategoryTypes> getComplaintCategoryTypesCollection() {
        return complaintCategoryTypesCollection;
    }
    public void setComplaintCategoryTypesCollection(Collection<ComplaintCategoryTypes> complaintCategoryTypesCollection) {
        this.complaintCategoryTypesCollection = complaintCategoryTypesCollection;
    }
    @XmlTransient
    public Collection<ShippingDetails> getShippingDetailsCollection() {
        return shippingDetailsCollection;
    }
    public void setShippingDetailsCollection(Collection<ShippingDetails> shippingDetailsCollection) {
        this.shippingDetailsCollection = shippingDetailsCollection;
    }
    @XmlTransient
    public Collection<ShippingDetails> getShippingDetailsCollection1() {
        return shippingDetailsCollection1;
    }
    public void setShippingDetailsCollection1(Collection<ShippingDetails> shippingDetailsCollection1) {
        this.shippingDetailsCollection1 = shippingDetailsCollection1;
    }
    public String getReasonForBlockUnblock() {
		return reasonForBlockUnblock;
	}
	public void setReasonForBlockUnblock(String reasonForBlockUnblock) {
		this.reasonForBlockUnblock = reasonForBlockUnblock;
	}
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }
    @Override
    public boolean equals(Object object) {
    	boolean check=true;
    	if(object!=null){
        if (!(object instanceof AccountInfo)) {
        	check= false;
        }
        AccountInfo other = (AccountInfo) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
    	}
        return check;
    }
    @Override
    public String toString() {
        return "com.ng.sb.common.model.AccountInfo[ id=" + id + " ]";
    }
}
