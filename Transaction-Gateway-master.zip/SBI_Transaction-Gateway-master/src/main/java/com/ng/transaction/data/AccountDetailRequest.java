/**
 * 
 */
package com.ng.transaction.data;

import com.ng.sb.common.dataobject.ValidationBean;

/**
 * @author gopal
 *
 */
public class AccountDetailRequest implements ValidationBean {
	
	private String customerId;
	
	private int detailRequired;

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public int getDetailRequired() {
		return detailRequired;
	}

	public void setDetailRequired(int detailRequired) {
		this.detailRequired = detailRequired;
	} 

}
