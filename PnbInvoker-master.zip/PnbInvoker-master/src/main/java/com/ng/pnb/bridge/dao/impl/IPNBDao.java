/**
 * 
 */
package com.ng.pnb.bridge.dao.impl;

import java.io.Serializable;

import com.ng.sb.common.dao.IDAO;
import com.ng.sb.common.model.CustomerDetails;
import com.ng.sb.common.model.CustomerPreferredBiller;
import com.ng.sb.common.model.CustomerWallets;
import com.ng.sb.common.model.IfscCodes;
import com.ng.sb.common.model.InternalAccountMaster;
import com.ng.sb.common.model.OverlayMerchants;
import com.ng.sb.common.model.PayeeDetails;
import com.ng.sb.common.model.Subscriber;
import com.ng.sb.common.model.WalletCredentials;

/**
 * @author gopal
 *
 */
public interface IPNBDao extends IDAO
{
	public <T extends Serializable> T findById(final Integer id, final Class<T> modelClass);
	
	public InternalAccountMaster getInternalAccountMaster();
	
	public boolean saveEntity(Object entityObject);
	
	public boolean updateEntity(Object entityObject);
	
	public IfscCodes findBankDetailsByIFSC(String ifscCode);
	
	public CustomerDetails getCustomerDetailsByAccount(String accountNumber, String ifscCode);
	
	public InternalAccountMaster getAccountMaster(String accountType);
	
	public Subscriber getSubscriberDetails(String msisdn);
	
	public WalletCredentials getSubscriberWalletCredential(String msisdn,Integer walletId);
	
	public CustomerWallets getSubscriberWallet(String msisdn,Integer walletId);
	
	public PayeeDetails getPayeeByAccountId(String accountId);
	
	public OverlayMerchants getMerchantByAccountId(String accountId);
	
	public CustomerPreferredBiller getCustomerBillerByAccountId(String accountId, String customerId);
	
	public boolean deleteEntity(Object entityObject);
	
	public Subscriber getSubscriberByCustId(String customerId);
}

