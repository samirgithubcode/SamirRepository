package com.ng.sb.common.dataobject;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;


public class OTPConfigurationData {


	 
    private static OTPConfigurationData instance;
    
    private ConcurrentMap<String,Integer> transactionOtpCache = new ConcurrentHashMap<>();
    private ConcurrentMap<String,Integer> nonTransactionOtpCache = new ConcurrentHashMap<>();
	private OTPConfigurationData(){}
    
    public static OTPConfigurationData getInstance()
    {
        if(instance == null)
        {
        	synchronized(OTPConfigurationData.class)
        	{
        		
        			instance = new OTPConfigurationData();		
        	}
        }
        return instance;
    }
    
    public boolean addToTransactionCache(String msisdn, int otpValue)
    {
    	boolean addStatus = false;
    	
    	if(msisdn != null && otpValue > 0 && transactionOtpCache != null)
    	{
    		transactionOtpCache.put(msisdn, otpValue);
    		addStatus = true;
    	}
    	
    	return addStatus;
    }
    
    public Integer getFromTransactionCache(String msisdn)
    {
    	if(msisdn != null && transactionOtpCache != null)
    	{
    		return transactionOtpCache.get(msisdn);
    	}else
    		return null;
    }
    
    public boolean addToNonTransactionCache(String msisdn, int otpValue)
    {
    	boolean addStatus = false;
    	
    	if(msisdn != null && otpValue > 0 && nonTransactionOtpCache != null)
    	{
    		nonTransactionOtpCache.put(msisdn, otpValue);
    		addStatus = true;
    	}
    	
    	return addStatus;
    }
    
    public Integer getFromNonTransactionCache(String msisdn)
    {
    	if(msisdn != null && nonTransactionOtpCache != null)
    	{
    		return nonTransactionOtpCache.get(msisdn);
    	}else
    		return null;
    }
    
    public void removeFromNonTransactionCache(String msisdn)
    {
    	if(msisdn != null && nonTransactionOtpCache != null)
    	{
    		nonTransactionOtpCache.remove(msisdn);
    	}
    }


    
}