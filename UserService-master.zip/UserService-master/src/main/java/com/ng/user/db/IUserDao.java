/**
 * 
 */
package com.ng.user.db;

import java.util.List;

import com.ng.sb.common.model.AccountLoginInfo;
import com.ng.sb.common.model.Address;
import com.ng.sb.common.model.CustomerDetails;
import com.ng.sb.common.model.InventoryMgmt;
import com.ng.sb.common.model.Menu;
import com.ng.sb.common.model.MerchantInfo;
import com.ng.sb.common.model.Subscriber;



/**
 * @author gopal
 *
 */
public interface IUserDao extends IBaseDao 
{
	public Object getLoginInfo(String loginId, int userTypeId);
	
	public Subscriber getSubscriberDetailsById(String subscriberId);
	
	public AccountLoginInfo getAccountDetailsById(String accountId);
	
	public InventoryMgmt getInventoryDetails(String externalNo);
	
	public List<Menu> getAllActiveMenus() throws Exception;
	
	public CustomerDetails getAccountDeails(String customerId) throws Exception;
	
	public Subscriber getSubscriberByCustomerId(String customerId);
	
	public Address getAddressDetailsByPin(String pincode);
	
	public Subscriber getSubscriberDetailsByMsisdn(String msisdn);
	
	public MerchantInfo getMerchantDetailsByMsisdn(String msisdn);
}
