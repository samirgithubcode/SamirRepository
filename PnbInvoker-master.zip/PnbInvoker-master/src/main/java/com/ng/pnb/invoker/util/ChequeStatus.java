/**
 * 
 */
package com.ng.pnb.invoker.util;

/**
 * @author gopal
 *
 */
public enum ChequeStatus 
{

	PAID("P","Paid"),
	CAUTIONED("C","Cautioned"),
	DESTROYED("D","Destroyed"),
	STOPPED("s","Stopped"),
	PAID_CHEQUE_RETURNED("R","Paid Cheque Returned"),
	UNUSED("U","Unused"),
	SENT_TO_USER_BUT_NOT_ACKNOWLEDGED("I","Sent to user but not acknowledged by user");
	
	
	private String statusCode;
	private String statusMessage;
	
	ChequeStatus(String statusCode, String statusMessage)
	{
		this.statusCode = statusCode;
		this.statusMessage = statusMessage;
	}
	
	public static ChequeStatus getChequeStatusByCode(String statusMsg)
	{
		for(ChequeStatus chequeStaus : ChequeStatus.values())
		{
			if(chequeStaus.getStatusCode().equalsIgnoreCase(statusMsg))
				return chequeStaus;
		}
		
		return null;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public String getStatusMessage() 
	{
		return statusMessage;
	}
	
	
}
