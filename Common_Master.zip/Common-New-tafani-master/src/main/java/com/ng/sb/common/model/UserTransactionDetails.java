package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the Threshold_Master database table.
 * 
 */
@Entity
@Table(name="User_Transaction_details")
@NamedQueries({

})
public class UserTransactionDetails implements Serializable {/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false)
	private Integer id;
	
	@Column(name="transaction_id")
	private String transactionId;

	@ManyToOne
	@JoinColumn(name="walletType", referencedColumnName="id")
	private WalletType walletType;

	@Column(name = "txn_time_stamp")
	@Temporal(TemporalType.TIMESTAMP)
	private Date txnTimeStamp;
	
	@Basic(optional = false)
    @Column(name = "trx_status")
    private boolean trxStatus;
	
	@Column(name="trx_type")
	private String trxType;
	
	@Column(name="trx_amount")
	private Float trxAmount;
	
	@Column(name="net_trx_amont")
	private Float netTrxAmont;
	
	@Column(name="opening_balance")
	private Float openingBalance;
	
	@Column(name="closing_balance")
	private Float closingBalance;
	
	@Basic(optional = false)
    @Column(name = "settle_status")
    private boolean settleStatus;
	@Column(name = "settle_on")
	@Temporal(TemporalType.TIMESTAMP)
	private Date settleOn;
	
	@Basic(optional = false)
	@Column(name="from_user")
	private Integer fromUser;
	
	@Basic(optional = false)
	@Column(name="to_user")
	private Integer toUser;

	@Column(name="settle_id")
	private String settleId;
	public Integer getFromUser() {
		return fromUser;
	}

	public void setFromUser(Integer fromUser) {
		this.fromUser = fromUser;
	}

	public Integer getToUser() {
		return toUser;
	}

	public void setToUser(Integer toUser) {
		this.toUser = toUser;
	}


	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public WalletType getWalletType() {
		return walletType;
	}

	public void setWalletType(WalletType walletType) {
		this.walletType = walletType;
	}

	public Date getTxnTimeStamp() {
		return txnTimeStamp;
	}

	public void setTxnTimeStamp(Date txnTimeStamp) {
		this.txnTimeStamp = txnTimeStamp;
	}

	public boolean isTrxStatus() {
		return trxStatus;
	}

	public void setTrxStatus(boolean trxStatus) {
		this.trxStatus = trxStatus;
	}

	public String getTrxType() {
		return trxType;
	}

	public void setTrxType(String trxType) {
		this.trxType = trxType;
	}

	public Float getTrxAmount() {
		return trxAmount;
	}

	public void setTrxAmount(Float trxAmount) {
		this.trxAmount = trxAmount;
	}

	public Float getNetTrxAmont() {
		return netTrxAmont;
	}

	public void setNetTrxAmont(Float netTrxAmont) {
		this.netTrxAmont = netTrxAmont;
	}

	public Float getOpeningBalance() {
		return openingBalance;
	}

	public void setOpeningBalance(Float openingBalance) {
		this.openingBalance = openingBalance;
	}

	public Float getClosingBalance() {
		return closingBalance;
	}

	public void setClosingBalance(Float closingBalance) {
		this.closingBalance = closingBalance;
	}

	public boolean isSettleStatus() {
		return settleStatus;
	}

	public void setSettleStatus(boolean settleStatus) {
		this.settleStatus = settleStatus;
	}

	public Date getSettleOn() {
		return settleOn;
	}

	public void setSettleOn(Date settleOn) {
		this.settleOn = settleOn;
	}

	public String getSettleId() {
		return settleId;
	}

	public void setSettleId(String settleId) {
		this.settleId = settleId;
	}

		
	@Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof UserWalletDetails)) {
            return false;
        }
        UserTransactionDetails other = (UserTransactionDetails) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.UserTransactionDetails[ id=" + id + " ]";
    }
}
