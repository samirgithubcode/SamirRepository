package com.ng.sb.common.dataobject;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

public class CommissionData implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private List<HostRangeFeeConfigurationData> custRangeDatas;
	private List<HostRangeFeeConfigurationData> partRangeDatas;
	private int id;

	private int addedById;

	private Timestamp createdDate;

	private String senderCommDesc;

	private float senderCommFixedValue;

	private float senderCommMax;

	private float senderCommMin;

	private String senderCommType;

	private String description;

	private Timestamp editDate;

	private String name;

	private String recipientCommDesc;

	private float recipientCommFixedValue;

	private float recipientCommMax;

	private float recipientCommMin;

	private String recipientCommType;

	private byte status;

	private float surcharge;

	private float tax;
	private float hostCommission;
	private float distCommission;
	private float subDistCommission;
	private float agentCommission;
	private float totalCommission;
	private String templateCommType;


	public float getHostCommission() {
		return hostCommission;
	}

	public void setHostCommission(float hostCommission) {
		this.hostCommission = hostCommission;
	}

	public float getDistCommission() {
		return distCommission;
	}

	public void setDistCommission(float distCommission) {
		this.distCommission = distCommission;
	}

	public float getSubDistCommission() {
		return subDistCommission;
	}

	public void setSubDistCommission(float subDistCommission) {
		this.subDistCommission = subDistCommission;
	}

	public float getAgentCommission() {
		return agentCommission;
	}

	public void setAgentCommission(float agentCommission) {
		this.agentCommission = agentCommission;
	}

	public float getTotalCommission() {
		return totalCommission;
	}

	public void setTotalCommission(float totalCommission) {
		this.totalCommission = totalCommission;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getAddedById() {
		return addedById;
	}

	public void setAddedById(int addedById) {
		this.addedById = addedById;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Timestamp getEditDate() {
		return editDate;
	}

	public void setEditDate(Timestamp editDate) {
		this.editDate = editDate;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	

	public String getSenderCommDesc() {
		return senderCommDesc;
	}

	public void setSenderCommDesc(String senderCommDesc) {
		this.senderCommDesc = senderCommDesc;
	}

	public float getSenderCommFixedValue() {
		return senderCommFixedValue;
	}

	public void setSenderCommFixedValue(float senderCommFixedValue) {
		this.senderCommFixedValue = senderCommFixedValue;
	}

	public float getSenderCommMax() {
		return senderCommMax;
	}

	public void setSenderCommMax(float senderCommMax) {
		this.senderCommMax = senderCommMax;
	}

	public float getSenderCommMin() {
		return senderCommMin;
	}

	public void setSenderCommMin(float senderCommMin) {
		this.senderCommMin = senderCommMin;
	}

	public String getSenderCommType() {
		return senderCommType;
	}

	public void setSenderCommType(String senderCommType) {
		this.senderCommType = senderCommType;
	}

	public String getRecipientCommDesc() {
		return recipientCommDesc;
	}

	public void setRecipientCommDesc(String recipientCommDesc) {
		this.recipientCommDesc = recipientCommDesc;
	}

	public float getRecipientCommFixedValue() {
		return recipientCommFixedValue;
	}

	public void setRecipientCommFixedValue(float recipientCommFixedValue) {
		this.recipientCommFixedValue = recipientCommFixedValue;
	}

	public float getRecipientCommMax() {
		return recipientCommMax;
	}

	public void setRecipientCommMax(float recipientCommMax) {
		this.recipientCommMax = recipientCommMax;
	}

	public float getRecipientCommMin() {
		return recipientCommMin;
	}

	public void setRecipientCommMin(float recipientCommMin) {
		this.recipientCommMin = recipientCommMin;
	}

	public String getRecipientCommType() {
		return recipientCommType;
	}

	public void setRecipientCommType(String recipientCommType) {
		this.recipientCommType = recipientCommType;
	}

	public byte getStatus() {
		return status;
	}

	public void setStatus(byte status) {
		this.status = status;
	}

	public float getSurcharge() {
		return surcharge;
	}

	public void setSurcharge(float surcharge) {
		this.surcharge = surcharge;
	}

	public float getTax() {
		return tax;
	}

	public void setTax(float tax) {
		this.tax = tax;
	}

	public String getTemplateCommType() {
		return templateCommType;
	}

	public void setTemplateCommType(String templateCommType) {
		this.templateCommType = templateCommType;
	}

	public List<HostRangeFeeConfigurationData> getCustRangeDatas() {
		return custRangeDatas;
	}

	public void setCustRangeDatas(List<HostRangeFeeConfigurationData> custRangeDatas) {
		this.custRangeDatas = custRangeDatas;
	}

	public List<HostRangeFeeConfigurationData> getPartRangeDatas() {
		return partRangeDatas;
	}

	public void setPartRangeDatas(List<HostRangeFeeConfigurationData> partRangeDatas) {
		this.partRangeDatas = partRangeDatas;
	}
}
