/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "inventory_order")
@XmlRootElement
@NamedQueries({
		@NamedQuery(name = "InventoryOrder.findAll", query = "SELECT i FROM InventoryOrder i"),
		@NamedQuery(name = "InventoryOrder.findById", query = "SELECT i FROM InventoryOrder i WHERE i.id = :id"),
		@NamedQuery(name = "InventoryOrder.findByOrderNumber", query = "SELECT i FROM InventoryOrder i WHERE i.orderNumber = :orderNumber"),
		@NamedQuery(name = "InventoryOrder.findByNumberofSKUordered", query = "SELECT i FROM InventoryOrder i WHERE i.numberofSKUordered = :numberofSKUordered"),
		@NamedQuery(name = "InventoryOrder.findByNumberofSKUshipped", query = "SELECT i FROM InventoryOrder i WHERE i.numberofSKUshipped = :numberofSKUshipped"),
		@NamedQuery(name = "InventoryOrder.findByNumberofpendingSKU", query = "SELECT i FROM InventoryOrder i WHERE i.numberofpendingSKU = :numberofpendingSKU"),
		@NamedQuery(name = "InventoryOrder.findByDate", query = "SELECT i FROM InventoryOrder i WHERE i.date = :date"),
		@NamedQuery(name = "InventoryOrder.findByToIdBwDates", query = "SELECT i FROM InventoryOrder i WHERE i.toId = :toId and i.date between :fromDate and :toDate order by i.date desc"),
		@NamedQuery(name = "InventoryOrder.findByToIdStatusBwDates", query = "SELECT i FROM InventoryOrder i WHERE i.toId = :toId and orderStatus = :orderStatus and i.date between :fromDate and :toDate order by i.date desc"),
		/*@NamedQuery(name = "InventoryOrder.findByFromIdBwDates", query = "SELECT i FROM InventoryOrder i WHERE i.fromId = :fromId and i.date between :fromDate and :toDate order by i.date desc"),*/
		@NamedQuery(name = "InventoryOrder.findByFromIdStatusBwDates", query = "SELECT i FROM InventoryOrder i WHERE i.fromId = :fromId and orderStatus = :orderStatus and i.date between :fromDate and :toDate order by i.date desc"),
		@NamedQuery(name = "InventoryOrder.findByBehalfIdBwDates", query = "SELECT i FROM InventoryOrder i WHERE i.onBehalfId = :onBehalfId and i.date between :fromDate and :toDate order by i.date desc"),
		@NamedQuery(name = "InventoryOrder.findByBehalfIdStatusBwDates", query = "SELECT i FROM InventoryOrder i WHERE i.onBehalfId = :onBehalfId and orderStatus = :orderStatus and i.date between :fromDate and :toDate order by i.date desc"),
		@NamedQuery(name = "InventoryOrder.findByOrderByFromToIdStatus", query = "SELECT i FROM InventoryOrder i WHERE i.fromId = :fromId and i.toId = :toId and (i.orderStatus = :orderStatus1 or i.orderStatus = :orderStatus2)"),
		@NamedQuery(name = "InventoryOrder.findByOrderStatus", query = "SELECT i FROM InventoryOrder i WHERE i.orderStatus = :orderStatus"),
@NamedQuery(name = "InventoryOrder.findByFromIdBwDates", query = "SELECT i FROM InventoryOrder i WHERE i.fromId = :fromId and i.date >= :fromDate AND i.date <=:toDate order by i.date desc")})
public class InventoryOrder implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "id")
	private Integer id;
	@Column(name = "orderNumber")
	private String orderNumber;
	@Column(name = "number_of_SKU_ordered")
	private Integer numberofSKUordered;
	@Column(name = "number_of_SKU_shipped")
	private Integer numberofSKUshipped;
	@Column(name = "number_of_pending_SKU")
	private Integer numberofpendingSKU;
	@Column(name = "date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date date;
	@Column(name = "order_status")
	private String orderStatus;
	@Column(name = "orderBy")
	private String orderBy;
	@JoinColumn(name = "onBehalfId", referencedColumnName = "id")
	@ManyToOne
	private AccountInfo onBehalfId;
	@JoinColumn(name = "toId", referencedColumnName = "id")
	@ManyToOne
	private AccountInfo toId;
	@JoinColumn(name = "fromId", referencedColumnName = "id")
	@ManyToOne
	private AccountInfo fromId;
	@JoinColumn(name = "productId", referencedColumnName = "id")
	@ManyToOne
	private Products productId;
	@JoinColumn(name = "mvId", referencedColumnName = "id")
	@ManyToOne
	private MasterVersion mvId;
	@JoinColumn(name = "hostId", referencedColumnName = "id")
	@ManyToOne
	private AccountInfo hostId;
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "orderNumber")
	private Collection<InventoryOrderHistory> inventoryOrderHistoryCollection;

	public InventoryOrder() {
		//default constructor
	}

	public InventoryOrder(Integer id) {
		this.id = id;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public Integer getNumberofSKUordered() {
		return numberofSKUordered;
	}

	public void setNumberofSKUordered(Integer numberofSKUordered) {
		this.numberofSKUordered = numberofSKUordered;
	}

	public Integer getNumberofSKUshipped() {
		return numberofSKUshipped;
	}

	public void setNumberofSKUshipped(Integer numberofSKUshipped) {
		this.numberofSKUshipped = numberofSKUshipped;
	}

	public Integer getNumberofpendingSKU() {
		return numberofpendingSKU;
	}

	public void setNumberofpendingSKU(Integer numberofpendingSKU) {
		this.numberofpendingSKU = numberofpendingSKU;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

	public String getOrderBy() {
		return orderBy;
	}

	public void setOrderBy(String orderBy) {
		this.orderBy = orderBy;
	}

	public AccountInfo getOnBehalfId() {
		return onBehalfId;
	}

	public void setOnBehalfId(AccountInfo onBehalfId) {
		this.onBehalfId = onBehalfId;
	}

	public AccountInfo getToId() {
		return toId;
	}

	public void setToId(AccountInfo toId) {
		this.toId = toId;
	}

	public AccountInfo getFromId() {
		return fromId;
	}

	public void setFromId(AccountInfo fromId) {
		this.fromId = fromId;
	}

	public Products getProductId() {
		return productId;
	}

	public void setProductId(Products productId) {
		this.productId = productId;
	}

	public MasterVersion getMvId() {
		return mvId;
	}

	public void setMvId(MasterVersion mvId) {
		this.mvId = mvId;
	}

	public AccountInfo getHostId() {
		return hostId;
	}

	public void setHostId(AccountInfo hostId) {
		this.hostId = hostId;
	}

	@XmlTransient
	public Collection<InventoryOrderHistory> getInventoryOrderHistoryCollection() {
		return inventoryOrderHistoryCollection;
	}

	public void setInventoryOrderHistoryCollection(Collection<InventoryOrderHistory> inventoryOrderHistoryCollection) {
		this.inventoryOrderHistoryCollection = inventoryOrderHistoryCollection;
	}

	@Override
	public int hashCode() {
		int hash = 0;
		hash += (id != null ? id.hashCode() : 0);
		return hash;
	}

	@Override
	public boolean equals(Object object) {
		// not set
		if (!(object instanceof InventoryOrder)) {
			return false;
		}
		InventoryOrder other = (InventoryOrder) object;
	     boolean check=true;
	        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
	        	check= false;
	        }
	        return check;
	}

	@Override
	public String toString() {
		return "com.ng.sb.common.model.InventoryOrder[ id=" + id + " ]";
	}

}
