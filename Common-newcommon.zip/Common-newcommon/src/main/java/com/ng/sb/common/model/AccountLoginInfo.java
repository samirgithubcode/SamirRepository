/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.ColumnTransformer;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

@Entity
@Table(name = "account_login_info")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "AccountLoginInfo.findAll", query = "SELECT a FROM AccountLoginInfo a"),
    @NamedQuery(name = "AccountLoginInfo.findById", query = "SELECT a FROM AccountLoginInfo a WHERE a.id = :id"),
    @NamedQuery(name = "AccountLoginInfo.findByIdTest", query = "SELECT a FROM AccountLoginInfo a WHERE a.id = :id And  a.loginName = :loginName And a.accountTypeId.id = :accountTypeId"),
    
    @NamedQuery(name = "AccountLoginInfo.findByMobileNumber", query = "SELECT a FROM AccountLoginInfo a WHERE a.aamobileNumber = :mobileNumber"),
    @NamedQuery(name = "AccountLoginInfo.findByDateOfBirth", query = "SELECT a FROM AccountLoginInfo a WHERE a.dbDateOfBirth = :dateOfBirth"),
    @NamedQuery(name = "AccountLoginInfo.findBySecurityQuestion", query = "SELECT a FROM AccountLoginInfo a WHERE a.securityQuestion = :securityQuestion"),
    @NamedQuery(name = "AccountLoginInfo.findBySecurityAnswer", query = "SELECT a FROM AccountLoginInfo a WHERE a.securityAnswer = :securityAnswer"),
    @NamedQuery(name = "AccountLoginInfo.findByEmailId", query = "SELECT a FROM AccountLoginInfo a WHERE a.emailId = :emailId"),
    @NamedQuery(name = "AccountLoginInfo.findByLoginName", query = "SELECT a FROM AccountLoginInfo a WHERE a.loginName = :loginName"),
    @NamedQuery(name = "AccountLoginInfo.findByUserPassword", query = "SELECT a FROM AccountLoginInfo a WHERE a.userPassword = :userPassword"),
    @NamedQuery(name = "AccountLoginInfo.findByInvalidLoginCount", query = "SELECT a FROM AccountLoginInfo a WHERE a.invalidLoginCount = :invalidLoginCount"),
    @NamedQuery(name = "AccountLoginInfo.findByStatus", query = "SELECT a FROM AccountLoginInfo a WHERE a.status = :status"),
    @NamedQuery(name = "AccountLoginInfo.findByFirstTimeLogin", query = "SELECT a FROM AccountLoginInfo a WHERE a.firstTimeLogin = :firstTimeLogin"),
    @NamedQuery(name = "AccountLoginInfo.findCountByEmailOrMobileOrLoginName", query = "SELECT count(*) FROM AccountLoginInfo a WHERE a.emailId = :emailId or a.aamobileNumber=:mobileNumber or a.loginName=:loginName"),    
    @NamedQuery(name = "AccountLoginInfo.findByEmailOrMobileOrLoginName", query = "SELECT a FROM AccountLoginInfo a WHERE a.emailId = :emailId or a.aamobileNumber=:mobileNumber or a.loginName=:loginName"),
    @NamedQuery(name = "AccountLoginInfo.findCountByLoginNameAndDob", query = "SELECT count(*) FROM AccountLoginInfo a WHERE  a.loginName=:loginName and a.dbDateOfBirth =:dateOfBirth"),
    @NamedQuery(name = "AccountLoginInfo.findByNameMobileEmail", query = "SELECT a FROM AccountLoginInfo a WHERE (a.emailId = :loginoremail OR a.loginName =:loginoremail OR mobileNumber=:loginoremail)"),
    
    //shiv
    @NamedQuery(name = "AccountLoginInfo.findAllByOrder", query = "SELECT a FROM AccountLoginInfo a order by accountTypeId.weight desc"),
    @NamedQuery(name = "AccountLoginInfo.findByHostId", query = "SELECT a FROM AccountLoginInfo a WHERE a.hId = :hId"),
    @NamedQuery(name = "AccountLoginInfo.findByDistId", query = "SELECT a FROM AccountLoginInfo a WHERE a.dId = :dId"),
    @NamedQuery(name = "AccountLoginInfo.findBySubDistId", query = "SELECT a FROM AccountLoginInfo a WHERE a.sdId = :sdId"),
    @NamedQuery(name = "AccountLoginInfo.findByRetailerId", query = "SELECT a FROM AccountLoginInfo a WHERE a.rtId = :rtId"),
    @NamedQuery(name = "AccountLoginInfo.findByBcId", query = "SELECT a FROM AccountLoginInfo a WHERE a.bcId = :bcId"),
    
   // @NamedQuery(name = "AccountLoginInfo.findByFirstTimeLogin", query = "SELECT a FROM AccountLoginInfo a WHERE a.firstTimeLogin = :firstTimeLogin"),
    @NamedQuery(name = "AccountLoginInfo.findByAccountId",query = "SELECT a FROM AccountLoginInfo a where a.accountId=:accountId"),
    @NamedQuery(name = "AccountLoginInfo.findByEmailIdOrloginName", query = "SELECT a FROM AccountLoginInfo a WHERE a.emailId = :loginemailormobile OR a.loginName =:loginemailormobile OR a.aamobileNumber =:loginemailormobile"),
    @NamedQuery(name = "AccountLoginInfo.findByEmailIdOrloginNameAndDob", query = "SELECT a FROM AccountLoginInfo a WHERE (a.emailId = :loginemailormobile OR a.loginName =:loginemailormobile OR a.aamobileNumber =:loginemailormobile) AND a.dbDateOfBirth =:dateOfBirth"),
    @NamedQuery(name = "AccountLoginInfo.findByEmailIdOrloginNameDobAndSecurityAns", query = "SELECT a FROM AccountLoginInfo a WHERE (a.dbDateOfBirth =:dateOfBirth AND a.securityAnswer =:securityAnswer) AND (a.emailId = :loginemailormobile OR a.loginName=:loginemailormobile OR a.aamobileNumber=:loginemailormobile)"),
    @NamedQuery(name = "AccountLoginInfo.findAgentbyHostId", query = "SELECT a FROM AccountLoginInfo a WHERE a.aamobileNumber not IN (select  i.customerMSISDN from InventoryMgmt i where i.customerMSISDN is not null) and a.hId= :hId and a.accountTypeId IN :accountTypeId"),
    @NamedQuery(name = "AccountLoginInfo.findAgentbyDistributerId", query = "SELECT a FROM AccountLoginInfo a WHERE a.aamobileNumber not IN (select  i.customerMSISDN from InventoryMgmt i where i.customerMSISDN is not null) and a.dId = :distributerId and a.accountTypeId IN :accountTypeId"),
    @NamedQuery(name = "AccountLoginInfo.findAgentbySubDistributerId", query = "SELECT a FROM AccountLoginInfo a WHERE a.aamobileNumber not IN (select  i.customerMSISDN from InventoryMgmt i where i.customerMSISDN is not null) and a.sdId = :subDistributerId and a.accountTypeId IN :accountTypeId"),
    @NamedQuery(name = "AccountLoginInfo.findByRetailerIdandAccTypeId", query = "SELECT a FROM AccountLoginInfo a WHERE a.aamobileNumber not IN (select  i.customerMSISDN from InventoryMgmt i where i.customerMSISDN is not null) and a.rtId = :rtId and a.accountTypeId IN :accountTypeId"),
    @NamedQuery(name = "AccountLoginInfo.findMSISDNById", query = "SELECT a FROM AccountLoginInfo a WHERE a.id= :msisdn"),
    @NamedQuery(name = "AccountLoginInfo.countbyMobno", query = "SELECT count(*) FROM AccountLoginInfo a WHERE a.aamobileNumber =:mobileNumber"),
    @NamedQuery(name = "AccountLoginInfo.countbyMobnoandId", query = "SELECT count(*) FROM AccountLoginInfo a WHERE a.aamobileNumber =:mobileNumber and a.id =:id"),
    @NamedQuery(name ="AccountLoginInfo.countbyEmail",query="SELECT count(*) FROM AccountLoginInfo a WHERE a.emailId =:emailId"),
    @NamedQuery(name ="AccountLoginInfo.countbyEmailandId",query="SELECT count(*) FROM AccountLoginInfo a WHERE a.emailId =:emailId and a.id=:id"),
    @NamedQuery(name = "AccountLoginInfo.findByEmail",query = "SELECT a FROM AccountLoginInfo a where a.emailId=:email"),
    @NamedQuery(name = "AccountLoginInfo.findByName",query = "SELECT a FROM AccountLoginInfo a where a.contactPersonName=:name"),
    @NamedQuery(name = "AccountLoginInfo.findByloginName",query = "SELECT a FROM AccountLoginInfo a where a.loginName=:name"),
    @NamedQuery(name = "AccountLoginInfo.findByAnyId",query = "SELECT a FROM AccountLoginInfo a where a.loginName=:userId or a.emailId=:userId or a.aamobileNumber=:userId "),
    @NamedQuery(name="AccountLoginInfo.findAllAgents",query="SELECT a FROM AccountLoginInfo a where a.rtId !=NULL"),
    @NamedQuery(name="AccountLoginInfo.findAllAgentByCompany",query="SELECT a FROM AccountLoginInfo a where a.rtId =:agentCompany"),
    @NamedQuery(name="AccountLoginInfo.findAllAgentsBySys",query="SELECT  a FROM AccountLoginInfo a where a.rtId IS NOT NULL"),
    //@NamedQuery(name="AccountLoginInfo.findAgentDataForCommission",query="SELECT  a.id, a.rtId.id,a.rtId.companyName,a.contactPersonName,a.hId.companyName,a.dId.companyName,a.sdId.companyName FROM AccountLoginInfo a where a.rtId IS NOT NULL")
    
    @NamedQuery(name="AccountLoginInfo.findAgentDataForCommission",query="SELECT   a.id,al.id as loginIs,a.companyName as CompanyName,al.contactPersonName,a.hId.companyName as HostCompany,a.dId.companyName as DistriCompany,a.sdId.companyName  as SubDistriCompany FROM AccountInfo a LEFT JOIN a.accountLoginInfoCollection1 al where a.accountGroupId=:accountGroupId "),
    
    //@NamedQuery(name="AccountLoginInfo.updateStatus", query="Update AccountLoginInfo a SET a.status=:status,a.comment=:comment where a.id=:id")
})
public class AccountLoginInfo implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "contactPersonName")
    @ColumnTransformer(write="AES_ENCRYPT(?, mobileNumber)",read="AES_DECRYPT(contactPersonName, mobileNumber)")
    private String contactPersonName;
    @Column(name = "altMobileNumber")
    private String altMobileNumber;
    @Basic(optional = false)
    @Column(name = "mobileNumber")
    private String aamobileNumber;
	@Column(name = "nickName")
	private String nickName;
	@Column(name = "dateOfBirth")
	@ColumnTransformer(write="AES_ENCRYPT(?, mobileNumber)",read="AES_DECRYPT(dateOfBirth, mobileNumber)")
    @Temporal(TemporalType.DATE)
    private Date dbDateOfBirth;
	
	private transient Date dateOfBirth;
	@Column(name = "createDate")
    @Temporal(TemporalType.DATE)
    private Date createDate;
	@Column(name = "passwordDate")
    @Temporal(TemporalType.DATE)
    private Date passwordDate;	
    @Column(name = "emailId")
    @ColumnTransformer(write="AES_ENCRYPT(?, mobileNumber)",read="AES_DECRYPT(emailId, mobileNumber)")
    private String emailId;
    @Basic(optional = false)
    @Column(name = "login_name")
    @ColumnTransformer(write="AES_ENCRYPT(?, mobileNumber)",read="AES_DECRYPT(login_name, mobileNumber)")
    private String loginName;
    @Column(name = "securityQuestion")
    private String securityQuestion;
    @Column(name = "securityAnswer")
    @ColumnTransformer(write="AES_ENCRYPT(?, mobileNumber)",read="AES_DECRYPT(securityAnswer, mobileNumber)")
    private String securityAnswer;
    @Basic(optional = false)
    @Column(name = "invalid_login_count")
    private int invalidLoginCount=0;
    @Basic(optional = false)
    @Column(name = "user_password")
    private String userPassword;
    @Basic(optional = false)
    @Column(name = "status",columnDefinition = "tinyint default true")
    private boolean status=true;
    @Column(name = "first_time_login")
    private Boolean firstTimeLogin=true;
    @Column(name="source")
    private String source;
    @Column(name="settlementType")
    private Integer settlementType;
    @OneToMany(mappedBy = "accountLoginId",fetch=FetchType.LAZY)
    private Collection<Subscriber> subscriberCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "accountLoginId")
    private Collection<MerchantDetail> merchantDetailCollection;
 
    @JoinColumn(name = "sdId", referencedColumnName = "id")
    @ManyToOne(fetch=FetchType.LAZY)
    private AccountInfo sdId;
    @JoinColumn(name = "bcId", referencedColumnName = "id")
    @ManyToOne(fetch=FetchType.LAZY)
    private AccountInfo bcId;
    @JoinColumn(name = "dId", referencedColumnName = "id")
    @ManyToOne(fetch=FetchType.LAZY)
    private AccountInfo dId;
    @JoinColumn(name = "rtId", referencedColumnName = "id")
    @ManyToOne(fetch=FetchType.LAZY)
    private AccountInfo rtId;
    @JoinColumn(name = "hId", referencedColumnName = "id")
    @ManyToOne(fetch=FetchType.LAZY)
    private AccountInfo hId;
    @JoinColumn(name = "accountTypeId", referencedColumnName = "id")
    @ManyToOne(fetch=FetchType.LAZY)
    private SysAccountType accountTypeId;
    @JoinColumn(name = "account_id", referencedColumnName = "id")
    @ManyToOne(fetch=FetchType.LAZY)
    private AccountInfo accountId;
    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name="securityQuestionId", referencedColumnName="id")
    private SecurityQuestion securityQuestionId;
    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name="countryCodeId", referencedColumnName="id")
    private CountryCode countryCodeId;
    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name="altCountryCodeId", referencedColumnName="id")
    private CountryCode altCountryCodeId;
    @Column(name = "address")
    @ColumnTransformer(write="AES_ENCRYPT(?, mobileNumber)",read="AES_DECRYPT(address, mobileNumber)")
    private String address;
    
    @Column(name="locality")
    @ColumnTransformer(write="AES_ENCRYPT(?, mobileNumber)",read="AES_DECRYPT(locality, mobileNumber)")
    private String location;
    @Column(name="region")
    @ColumnTransformer(write="AES_ENCRYPT(?, mobileNumber)",read="AES_DECRYPT(region, mobileNumber)")
    private String region;
    @Column(name="district")
    @ColumnTransformer(write="AES_ENCRYPT(?, mobileNumber)",read="AES_DECRYPT(district, mobileNumber)")
    private String district;
   
    @Column(name = "pincode")
    private Integer pincode;
    
//    @Column(name = "comment")
//    private String comment;
//    
    
    @Column(name = "country")
    private String country;
    @Column(name = "state")
    @ColumnTransformer(write="AES_ENCRYPT(?, mobileNumber)",read="AES_DECRYPT(state, mobileNumber)")
    private String state;
    
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "createdBy", fetch = FetchType.LAZY)
    @Fetch(FetchMode.SELECT)
    private Collection<SubscriberIdProofs> subscriberIdProofsCollection;
    
    public AccountLoginInfo() {
    	//default constructor
    }

    public AccountLoginInfo(Integer id) {
        this.id = id;
    }
    public AccountLoginInfo(Integer id, String contactPersonName, String mobileNumber, String emailId, String loginName, String userPassword, int invalidLoginCount) {
        this.id = id;
        this.contactPersonName = contactPersonName;
        this.aamobileNumber = mobileNumber;
        this.emailId = emailId;
        this.loginName = loginName;
        this.userPassword = userPassword;
        this.invalidLoginCount = invalidLoginCount;
    }
    public Date getCreateDate() {
  		return createDate;
  	}
    public String getAltMobileNumber() {
  		return altMobileNumber;
  	}
  	public void setCreateDate(Date createDate) {
  		this.createDate = createDate;
  	}

  	public Date getPasswordDate() {
  		return passwordDate;
  	}

  	public void setPasswordDate(Date passwordDate) {
  		this.passwordDate = passwordDate;
  	}
   
	public void setAltMobileNumber(String altMobileNumber) {
		this.altMobileNumber = altMobileNumber;
	}

//	public String getComment() {
//		return comment;
//	}
//
//	public void setComment(String comment) {
//		this.comment = comment;
//	}

	public String getNickName() {
		return nickName;
	}
   
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
    public CountryCode getCountryCodeId() {
		return countryCodeId;
	}

	public void setCountryCodeId(CountryCode countryCodeId) {
		this.countryCodeId = countryCodeId;
	}

	public CountryCode getAltCountryCodeId() {
		return altCountryCodeId;
	}

	public void setAltCountryCodeId(CountryCode altCountryCodeId) {
		this.altCountryCodeId = altCountryCodeId;
	}
	
  
    
    
    public SecurityQuestion getSecurityQuestionId() {
		return securityQuestionId;
	}    

	public void setSecurityQuestionId(SecurityQuestion securityQuestionId) {
		this.securityQuestionId = securityQuestionId;
	}

	

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

   

    public String getMobileNumber() {
        return aamobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.aamobileNumber = mobileNumber;
    }
    
    public String getContactPersonName() {
        return contactPersonName;
    }

    public void setContactPersonName(String contactPersonName) {
        this.contactPersonName = contactPersonName;
    }

    

    public String getSecurityQuestion() {
        return securityQuestion;
    }

    public void setSecurityQuestion(String securityQuestion) {
        this.securityQuestion = securityQuestion;
    }
    
    public Date getDateOfBirth() 
    {
    	//return KeyEncryptionUtils.stringToDate(this.dbDateOfBirth, "yyyy-MM-dd");
    	return this.dbDateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) 
    {
        this.dbDateOfBirth = dateOfBirth;
        //this.dbDateOfBirth = KeyEncryptionUtils.dateToString(dateOfBirth, "yyyy-MM-dd");
    }

    public String getSecurityAnswer() {
        return securityAnswer;
    }

    public void setSecurityAnswer(String securityAnswer) {
        this.securityAnswer = securityAnswer;
    }

    

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }
    
    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }

   
    public boolean getStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }
    
    public int getInvalidLoginCount() {
        return invalidLoginCount;
    }

    public void setInvalidLoginCount(int invalidLoginCount) {
        this.invalidLoginCount = invalidLoginCount;
    }


    public Boolean getFirstTimeLogin() {
        return firstTimeLogin;
    }

    public void setFirstTimeLogin(Boolean firstTimeLogin) {
        this.firstTimeLogin = firstTimeLogin;
    }

    @XmlTransient
    public Collection<Subscriber> getSubscriberCollection() {
        return subscriberCollection;
    }

    public void setSubscriberCollection(Collection<Subscriber> subscriberCollection) {
        this.subscriberCollection = subscriberCollection;
    }

    @XmlTransient
    public Collection<MerchantDetail> getMerchantDetailCollection() {
        return merchantDetailCollection;
    }

    public void setMerchantDetailCollection(Collection<MerchantDetail> merchantDetailCollection) {
        this.merchantDetailCollection = merchantDetailCollection;
    }

    public AccountInfo getBcId() {
        return bcId;
    }

    public void setBcId(AccountInfo bcId) {
        this.bcId = bcId;
    }

    public AccountInfo getRtId() {
        return rtId;
    }

    public void setRtId(AccountInfo rtId) {
        this.rtId = rtId;
    }

    public AccountInfo getSdId() {
        return sdId;
    }

    public void setSdId(AccountInfo sdId) {
        this.sdId = sdId;
    }

    

    public AccountInfo getHId() {
        return hId;
    }

    public void setHId(AccountInfo hId) {
        this.hId = hId;
    }

    public SysAccountType getAccountTypeId() {
        return accountTypeId;
    }

    public void setAccountTypeId(SysAccountType accountTypeId) {
        this.accountTypeId = accountTypeId;
    }
    
    public AccountInfo getDId() {
        return dId;
    }

    public void setDId(AccountInfo dId) {
        this.dId = dId;
    }

    public AccountInfo getAccountId() {
        return accountId;
    }

    public void setAccountId(AccountInfo accountId) {
        this.accountId = accountId;
    }

    public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public Integer getSettlementType() {
		return settlementType;
	}

	public void setSettlementType(Integer settlementType) {
		this.settlementType = settlementType;
	}
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
    	boolean check=true;
    	if(object!=null){
        if (!(object instanceof AccountLoginInfo)) {
        	check=false;
        }
        AccountLoginInfo other = (AccountLoginInfo) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check=false;
        }
    	}
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.AccountLoginInfo[ id=" + id + " ]";
    }

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public Integer getPincode() {
		return pincode;
	}

	public void setPincode(Integer pincode) {
		this.pincode = pincode;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Collection<SubscriberIdProofs> getSubscriberIdProofsCollection() {
		return subscriberIdProofsCollection;
	}
	public void setSubscriberIdProofsCollection(
			Collection<SubscriberIdProofs> subscriberIdProofsCollection) {
		this.subscriberIdProofsCollection = subscriberIdProofsCollection;
	}
}
