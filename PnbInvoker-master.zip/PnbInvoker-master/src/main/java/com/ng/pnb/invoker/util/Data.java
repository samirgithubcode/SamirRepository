package com.ng.pnb.invoker.util;

public class Data {

private String accountId;
	
	private String accountName;
	
	private String accountNickName;

	private Balance availableBalance;

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getAccountNickName() {
		return accountNickName;
	}

	public void setAccountNickName(String accountNickName) {
		this.accountNickName = accountNickName;
	}

	public Balance getAvailableBalance() {
		return availableBalance;
	}

	public void setAvailableBalance(Balance availableBalance) {
		this.availableBalance = availableBalance;
	}
}
