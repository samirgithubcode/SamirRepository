package com.ng.sb.common.dataobject;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.multipart.MultipartFile;

import com.ng.sb.common.model.Address;
import com.ng.sb.common.model.KYCDescriptor;

public class KYCUpgradeData extends BaseObjectData implements ValidationBean {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String phoneNo;
	private String productName;
	private String masterVersion;
	private String hostSubVersion;
	private String walletName;
	private String kycUpgradeName;
	private String lastName;
	private String address;
	private String houseNo;
	private String locality;
	private String region;
	private String district;
	private String state;
	private String country;
	private String email;
	private String city;
	private String landMark;
	private String countryId;
	private String stateId;
	private Integer pinCode;
	private List<SEissuanceResponseData> lists;
	private Integer mobileCode;
	private String msisdn;
	private String parentMSISDN;
	private String surname;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date dateOfBirth;
	private Address addressId;
	private String emailId;
	private Date addDate;
	private Date editDate;
	private String validFrom;
	private Integer invalidLPinCount;
	private Integer invalidTPinCount;
	private short kycGiven;
	private short kycValidated;
	private KYCDescriptor kycDescriptorId;
	private Integer pinAddressId;
	private Integer mgmtId;
	private Long externalNo;
	private String custId;
	private List<String> actionDoc;

	private Map<Integer, String> documentsMap;
	private java.util.List<KYCUpgradeData> dataList;
	private Map<Integer, String> idproofs;
	private Map<Integer, String> idProofData;
	private Integer[] valueCheck;
	private String[] idNo;
	private KYCUpgradeData subscriberIdProofs;
	private Integer maxBalance;
	private Integer perTxnLimit;
	private Integer dailyTxnLimit;
	private Integer monthlyTxnLimit;
	private List<KYCDescriptorData> kycData;
	private String[] status;
	private transient MultipartFile[] file;
	private String[] fileName;
	private String[] fileType;
	private Integer[] idProofCheck;
	private String[] userIdNo;
	private String[] addedOn ;
	private String[] addedBy ;
	private String[] verifiedByArray;
	private String[] verifiedOnArray;
	private String[] commentsArray;
	private List<Integer> docList;
	private String singleAddedBy;
	private List<Integer> mandatoryIds;
	
	private Integer pinaddresId;
	private Integer[] documents;
	private String docName;
	private String userId;
	private String statuss;
	private List<KYCUpgradeData> data;
	private Integer subscriberId;
	private Integer createdBy;
	private Date createdOn;
	private List<String> comment;
	private String idType;
	private String date;
	private String comments;
	private String downloadUrl;
	private String verifiedBy;
	private String verifiedOn;
	private String url;
	private String isMandatory;
	private int validityRequired;
	
	public int getValidityRequired() {
		return validityRequired;
	}

	public void setValidityRequired(int validityRequired) {
		this.validityRequired = validityRequired;
	}

	public List<Integer> getMandatoryIds() {
		return mandatoryIds;
	}

	public void setMandatoryIds(List<Integer> mandatoryIds) {
		this.mandatoryIds = mandatoryIds;
	}

	public List<Integer> getDocList() {
		return docList;
	}

	public void setDocList(List<Integer> docList) {
		this.docList = docList;
	}

	public String getSingleAddedBy() {
		return singleAddedBy;
	}

	public void setSingleAddedBy(String singleAddedBy) {
		this.singleAddedBy = singleAddedBy;
	}

	public String[] getAddedOn() {
		return addedOn;
	}

	public String getIsMandatory() {
		return isMandatory;
	}

	public void setIsMandatory(String isMandatory) {
		this.isMandatory = isMandatory;
	}

	public void setAddedOn(String[] addedOn) {
		this.addedOn = addedOn;
	}

	public String[] getAddedBy() {
		return addedBy;
	}

	public void setAddedBy(String[] addedBy) {
		this.addedBy = addedBy;
	}

	public String[] getVerifiedByArray() {
		return verifiedByArray;
	}

	public void setVerifiedByArray(String[] verifiedByArray) {
		this.verifiedByArray = verifiedByArray;
	}

	public String[] getVerifiedOnArray() {
		return verifiedOnArray;
	}

	public void setVerifiedOnArray(String[] verifiedOnArray) {
		this.verifiedOnArray = verifiedOnArray;
	}

	public String[] getCommentsArray() {
		return commentsArray;
	}

	public void setCommentsArray(String[] commentsArray) {
		this.commentsArray = commentsArray;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String[] getFileType() {
		return fileType;
	}

	public void setFileType(String[] fileType) {
		this.fileType = fileType;
	}

	public String getVerifiedBy() {
		return verifiedBy;
	}

	public void setVerifiedBy(String verifiedBy) {
		this.verifiedBy = verifiedBy;
	}

	public String getVerifiedOn() {
		return verifiedOn;
	}

	public void setVerifiedOn(String verifiedOn) {
		this.verifiedOn = verifiedOn;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	
	public Long getExternalNo() {
		return externalNo;
	}

	public void setExternalNo(Long externalNo) {
		this.externalNo = externalNo;
	}

	public String getCustId() {
		return custId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}

	public List<SEissuanceResponseData> getLists() {
		return lists;
	}

	public void setLists(List<SEissuanceResponseData> lists) {
		this.lists = lists;
	}
	public Integer getMobileCode() {
		return mobileCode;
	}

	public void setMobileCode(Integer mobileCode) {
		this.mobileCode = mobileCode;
	}
	
	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getMsisdn() {
		return msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	
	public String getParentMSISDN() {
		return parentMSISDN;
	}

	

	public void setAddressId(Address addressId) {
		this.addressId = addressId;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setParentMSISDN(String parentMSISDN) {
		this.parentMSISDN = parentMSISDN;
	}
	public Address getAddressId() {
		return addressId;
	}
	


	public void setSurname(String surname) {
		this.surname = surname;
	}
	
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
	public Date getAddDate() {
		return addDate;
	}
	public Integer getInvalidLPinCount() {
		return invalidLPinCount;
	}

	public void setInvalidLPinCount(Integer invalidLPinCount) {
		this.invalidLPinCount = invalidLPinCount;
	}
	
	public Integer getInvalidTPinCount() {
		return invalidTPinCount;
	}

	public void setAddDate(Date addDate) {
		this.addDate = addDate;
	}
	public String getSurname() {
		return surname;
	}
	public void setInvalidTPinCount(Integer invalidTPinCount) {
		this.invalidTPinCount = invalidTPinCount;
	}
	public Date getEditDate() {
		return editDate;
	}

	public void setEditDate(Date editDate) {
		this.editDate = editDate;
	}
	public short getKycValidated() {
		return kycValidated;
	}

	public void setKycValidated(short kycValidated) {
		this.kycValidated = kycValidated;
	}
	
	

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Integer getPinaddresId() {
		return pinaddresId;
	}
	public short getKycGiven() {
		return kycGiven;
	}

	public void setKycGiven(short kycGiven) {
		this.kycGiven = kycGiven;
	}
	public void setPinaddresId(Integer pinaddresId) {
		this.pinaddresId = pinaddresId;
	}
	public KYCDescriptor getKycDescriptorId() {
		return kycDescriptorId;
	}

	

	public void setMgmtId(Integer mgmtId) {
		this.mgmtId = mgmtId;
	}
	public void setKycDescriptorId(KYCDescriptor kycDescriptorId) {
		this.kycDescriptorId = kycDescriptorId;
	}
	public Integer getMgmtId() {
		return mgmtId;
	}
	
	public Integer getPinAddressId() {
		return pinAddressId;
	}

	public void setPinAddressId(Integer pinAddressId) {
		this.pinAddressId = pinAddressId;
	}

	public String[] getFileName() {
		return fileName;
	}

	public void setFileName(String[] fileName) {
		this.fileName = fileName;
	}

	public Integer[] getIdProofCheck() {
		return idProofCheck;
	}

	public void setIdProofCheck(Integer[] idProofCheck) {
		this.idProofCheck = idProofCheck;
	}

	public String[] getUserIdNo() {
		return userIdNo;
	}

	public void setUserIdNo(String[] userIdNo) {
		this.userIdNo = userIdNo;
	}

	public MultipartFile[] getFile() {
		return file;
	}

	public void setFile(MultipartFile[] file) {
		this.file = file;
	}

	public List<KYCDescriptorData> getKycData() {
		return kycData;
	}

	public void setKycData(List<KYCDescriptorData> kycData) {
		this.kycData = kycData;
	}

	public Integer getMaxBalance() {
		return maxBalance;
	}

	public void setMaxBalance(Integer maxBalance) {
		this.maxBalance = maxBalance;
	}

	public Integer getPerTxnLimit() {
		return perTxnLimit;
	}

	public void setPerTxnLimit(Integer perTxnLimit) {
		this.perTxnLimit = perTxnLimit;
	}

	public Integer getDailyTxnLimit() {
		return dailyTxnLimit;
	}

	public void setDailyTxnLimit(Integer dailyTxnLimit) {
		this.dailyTxnLimit = dailyTxnLimit;
	}

	public Integer getMonthlyTxnLimit() {
		return monthlyTxnLimit;
	}

	public void setMonthlyTxnLimit(Integer monthlyTxnLimit) {
		this.monthlyTxnLimit = monthlyTxnLimit;
	}

	public KYCUpgradeData getSubscriberIdProofs() {
		return subscriberIdProofs;
	}

	public void setSubscriberIdProofs(KYCUpgradeData subscriberIdProofs) {
		this.subscriberIdProofs = subscriberIdProofs;
	}

	public String[] getIdNo() {
		return idNo;
	}

	public void setIdNo(String[] idNo) {
		this.idNo = idNo;
	}

	public String[] getStatus() {
		return status;
	}

	public void setStatus(String[] status) {
		this.status = status;
	}

	public Map<Integer, String> getIdproofs() {
		return idproofs;
	}

	public void setIdproofs(Map<Integer, String> idproofs) {
		this.idproofs = idproofs;
	}

	public java.util.List<KYCUpgradeData> getDataList() {
		return dataList;
	}

	public void setDataList(java.util.List<KYCUpgradeData> dataList) {
		this.dataList = dataList;
	}
	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Map<Integer, String> getDocumentsMap() {
		return documentsMap;
	}

	public void setDocumentsMap(Map<Integer, String> documentsMap) {
		this.documentsMap = documentsMap;
	}

	

	public Integer[] getDocuments() {
		return documents;
	}

	public void setDocuments(Integer[] documents) {
		this.documents = documents;
	}

	public String getMasterVersion() {
		return masterVersion;
	}

	public void setMasterVersion(String masterVersion) {
		this.masterVersion = masterVersion;
	}

	public String getHouseNo() {
		return houseNo;
	}

	public void setHouseNo(String houseNo) {
		this.houseNo = houseNo;
	}

	public String getCity() {
		return city;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public void setLandMark(String landMark) {
		this.landMark = landMark;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getLandMark() {
		return landMark;
	}

	public String getCountryId() {
		return countryId;
	}

	public void setCountryId(String countryId) {
		this.countryId = countryId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getStateId() {
		return stateId;
	}

	public void setStateId(String stateId) {
		this.stateId = stateId;
	}

	public String getHostSubVersion() {
		return hostSubVersion;
	}

	public void setHostSubVersion(String hostSubVersion) {
		this.hostSubVersion = hostSubVersion;
	}

	public String getWalletName() {
		return walletName;
	}

	public void setWalletName(String walletName) {
		this.walletName = walletName;
	}

	public String getKycUpgradeName() {
		return kycUpgradeName;
	}

	public void setKycUpgradeName(String kycUpgradeName) {
		this.kycUpgradeName = kycUpgradeName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Integer getPinCode() {
		return pinCode;
	}

	public void setPinCode(Integer pinCode) {
		this.pinCode = pinCode;
	}

	public Map<Integer, String> getIdProofData() {
		return idProofData;
	}

	public void setIdProofData(Map<Integer, String> idProofData) {
		this.idProofData = idProofData;
	}

	public String getLocality() {
		return locality;
	}

	public void setLocality(String locality) {
		this.locality = locality;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public Integer[] getValueCheck() {
		return valueCheck;
	}

	public void setValueCheck(Integer[] valueCheck) {
		this.valueCheck = valueCheck;
	}

	public String getDocName() {
		return docName;
	}

	public void setDocName(String docName) {
		this.docName = docName;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getStatuss() {
		return statuss;
	}

	public void setStatuss(String statuss) {
		this.statuss = statuss;
	}

	public List<KYCUpgradeData> getData() {
		return data;
	}

	public void setData(List<KYCUpgradeData> data) {
		this.data = data;
	}

	public List<String> getActionDoc() {
		return actionDoc;
	}

	public void setActionDoc(List<String> actionDoc) {
		this.actionDoc = actionDoc;
	}

	public Integer getSubscriberId() {
		return subscriberId;
	}

	public void setSubscriberId(Integer subscriberId) {
		this.subscriberId = subscriberId;
	}

	public List<String> getComment() {
		return comment;
	}

	public void setComment(List<String> comment) {
		this.comment = comment;
	}

	public String getIdType() {
		return idType;
	}

	public void setIdType(String idType) {
		this.idType = idType;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getDownloadUrl() {
		return downloadUrl;
	}

	public void setDownloadUrl(String downloadUrl) {
		this.downloadUrl = downloadUrl;
	}

	public String getValidFrom() {
		return validFrom;
	}

	public void setValidFrom(String validFrom) {
		this.validFrom = validFrom;
	}
	

}
