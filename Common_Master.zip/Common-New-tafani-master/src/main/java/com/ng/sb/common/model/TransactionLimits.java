/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "TransactionLimits")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "TransactionLimits.findAll", query = "SELECT t FROM TransactionLimits t"),
    @NamedQuery(name = "TransactionLimits.findById", query = "SELECT t FROM TransactionLimits t WHERE t.id = :id"),
    @NamedQuery(name = "TransactionLimits.findByInstrumentId", query = "SELECT t FROM TransactionLimits t WHERE t.instrumentId = :instrumentId"),
    @NamedQuery(name = "TransactionLimits.findByWithKYCLimit", query = "SELECT t FROM TransactionLimits t WHERE t.withKYCLimit = :withKYCLimit"),
    @NamedQuery(name = "TransactionLimits.findByWithoutKYCLimit", query = "SELECT t FROM TransactionLimits t WHERE t.withoutKYCLimit = :withoutKYCLimit")})
public class TransactionLimits implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
    @Column(name = "instrumentId")
    private Integer instrumentId;
    @Column(name = "withKYCLimit")
    private Integer withKYCLimit;
    @Column(name = "withoutKYCLimit")
    private Integer withoutKYCLimit;

    public TransactionLimits() {
    	//default constructor
    }

    public TransactionLimits(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getInstrumentId() {
        return instrumentId;
    }

    public void setInstrumentId(Integer instrumentId) {
        this.instrumentId = instrumentId;
    }

    public Integer getWithKYCLimit() {
        return withKYCLimit;
    }

    public void setWithKYCLimit(Integer withKYCLimit) {
        this.withKYCLimit = withKYCLimit;
    }

    public Integer getWithoutKYCLimit() {
        return withoutKYCLimit;
    }

    public void setWithoutKYCLimit(Integer withoutKYCLimit) {
        this.withoutKYCLimit = withoutKYCLimit;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof TransactionLimits)) {
            return false;
        }
        TransactionLimits other = (TransactionLimits) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.TransactionLimits[ id=" + id + " ]";
    }
    
}
