/**
 * 
 */
package com.ng.sb.common.dataobject;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author gaurav
 *
 */
@XmlRootElement(name = "CustomerVerificationRequestData")
public class CustomerVerificationResponseData extends PlatformResponseData {
	private static final long serialVersionUID = 1L;

}
