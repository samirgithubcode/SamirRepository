package com.ng.sb.common.dataobject;

import com.ng.sb.common.model.Categories;
import com.ng.sb.common.model.OTAManagement;
import com.ng.sb.common.model.Provider;

public class OTACatProviderData extends BaseObjectData {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int otaCatProviderMappingId;
    private String categoryName;
    private String providerName;
    private OTAManagement otaMgmtId;
    private Categories categoryId;
    private Provider providerId;
    
	public int getOtaCatProviderMappingId() {
		return otaCatProviderMappingId;
	}
	public void setOtaCatProviderMappingId(int otaCatProviderMappingId) {
		this.otaCatProviderMappingId = otaCatProviderMappingId;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public String getProviderName() {
		return providerName;
	}
	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}
	public OTAManagement getOtaMgmtId() {
		return otaMgmtId;
	}
	public void setOtaMgmtId(OTAManagement otaMgmtId) {
		this.otaMgmtId = otaMgmtId;
	}
	public Categories getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(Categories categoryId) {
		this.categoryId = categoryId;
	}
	public Provider getProviderId() {
		return providerId;
	}
	public void setProviderId(Provider providerId) {
		this.providerId = providerId;
	}
}	
