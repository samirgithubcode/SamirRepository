/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Collection;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "FinancialInstrument")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "FinancialInstrument.findAll", query = "SELECT f FROM FinancialInstrument f where status=1"),
    @NamedQuery(name = "FinancialInstrument.findById", query = "SELECT f FROM FinancialInstrument f WHERE f.id = :id"),
    @NamedQuery(name = "FinancialInstrument.findByName", query = "SELECT f FROM FinancialInstrument f WHERE f.name = :name"),
    @NamedQuery(name = "FinancialInstrument.findByNameandId", query = "SELECT b FROM FinancialInstrument b WHERE b.name = :name  AND b.id=:id"),
    @NamedQuery(name = "FinancialInstrument.findByType", query = "SELECT f FROM FinancialInstrument f WHERE f.type = :type")})
public class FinancialInstrument implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
    @Basic(optional = false)
    @Column(name = "name", nullable = false, length = 20)
    private String name;
    @Column(name="type")
    private String type;
    @Column(name="status")
    private Integer status;
	@OneToMany(mappedBy = "instrumentId")
    private Collection<CommFinInstrumentMapping> commConfFinInstrumentMappingCollection;
    @OneToMany(mappedBy = "instrumentId")
    private Collection<HostSVFinInstrumentPartnerMapping> hostSVFinInstrumentPartnerMappingCollection;
    @OneToMany(mappedBy = "instrumentId")
    private Collection<MerchantDetail> merchantDetailCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "instrumentId")
    private Collection<PartnerFinInstrumentMapping> partnerFinInstrumentMappingCollection;

    public FinancialInstrument() {
    	//default constructor
    }

    public FinancialInstrument(Integer id) {
        this.id = id;
    }

    public FinancialInstrument(Integer id, String name) {
        this.id = id;
        this.name = name;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
    @XmlTransient
    public Collection<CommFinInstrumentMapping> getCommConfFinInstrumentMappingCollection() {
        return commConfFinInstrumentMappingCollection;
    }

    public void setCommConfFinInstrumentMappingCollection(Collection<CommFinInstrumentMapping> commConfFinInstrumentMappingCollection) {
        this.commConfFinInstrumentMappingCollection = commConfFinInstrumentMappingCollection;
    }

    @XmlTransient
    public Collection<HostSVFinInstrumentPartnerMapping> getHostSVFinInstrumentPartnerMappingCollection() {
        return hostSVFinInstrumentPartnerMappingCollection;
    }

    public void setHostSVFinInstrumentPartnerMappingCollection(Collection<HostSVFinInstrumentPartnerMapping> hostSVFinInstrumentPartnerMappingCollection) {
        this.hostSVFinInstrumentPartnerMappingCollection = hostSVFinInstrumentPartnerMappingCollection;
    }

    @XmlTransient
    public Collection<MerchantDetail> getMerchantDetailCollection() {
        return merchantDetailCollection;
    }

    public void setMerchantDetailCollection(Collection<MerchantDetail> merchantDetailCollection) {
        this.merchantDetailCollection = merchantDetailCollection;
    }

    @XmlTransient
    public Collection<PartnerFinInstrumentMapping> getPartnerFinInstrumentMappingCollection() {
        return partnerFinInstrumentMappingCollection;
    }

    public void setPartnerFinInstrumentMappingCollection(Collection<PartnerFinInstrumentMapping> partnerFinInstrumentMappingCollection) {
        this.partnerFinInstrumentMappingCollection = partnerFinInstrumentMappingCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof FinancialInstrument)) {
            return false;
        }
        FinancialInstrument other = (FinancialInstrument) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.FinancialInstrument[ id=" + id + " ]";
    }
    
}
