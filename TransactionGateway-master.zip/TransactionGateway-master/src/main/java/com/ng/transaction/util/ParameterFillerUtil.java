package com.ng.transaction.util;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import com.ng.sb.common.dataobject.BridgeDataObject;
import com.ng.sb.common.dataobject.BridgeDataObject.ServiceType;
import com.ng.sb.common.dataobject.ServiceParamsMappingData;
import com.ng.sb.common.dataobject.TransactionData;
import com.ng.sb.common.util.BCDConvert;
import com.ng.sb.common.util.SystemConstant;

/*
 * @author gaurav 
 * This Utility will fill all the parameters according to the sequence coming in the argument string.
 */
public class ParameterFillerUtil extends CommonUtils{

	/*
	 * Method which creates BridgeDataObject by serviceDef and paramString
	 * @param serviceCode
	 * @param paramString
	 * @return
	 * @throws Exception
	 */
	public BridgeDataObject fillParams(String serviceDef,Integer serviceId,String paramString,TransactionData transactionData) throws Exception {
		//if(serviceCode!=null && !serviceCode.isEmpty() && paramString!=null && !paramString.isEmpty() && paramString.contains(SystemConstant.HYPHEN)){
		if(serviceDef!=null && !serviceDef.isEmpty() && paramString!=null && !paramString.isEmpty()){
			// get ServiceParamMappings
			List<ServiceParamsMappingData> paramList = getServiceParams(serviceId);
			try {
				BridgeDataObject bridgeObjData =  getBridgeObject(paramString, paramList,transactionData);
				bridgeObjData.setServiceType(ServiceType.valueOf(serviceDef));
				return bridgeObjData;
			} catch (NoSuchFieldException | SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException | NoSuchMethodException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new Exception(e.getMessage());
			}
			
		}
		throw new Exception(SystemConstant.PARAM_FILLER_UTIL_MSG1);
	}
	
	public BridgeDataObject fillParams(String serviceDef,Integer serviceId,String paramString,List<ServiceParamsMappingData> serviceParamsMappingDataList,TransactionData transactionData) throws Exception {
		//if(serviceCode!=null && !serviceCode.isEmpty() && paramString!=null && !paramString.isEmpty() && paramString.contains(SystemConstant.HYPHEN)){
		if(serviceDef!=null && !serviceDef.isEmpty() && paramString!=null && !paramString.isEmpty()){
			// get ServiceParamMappings
			List<ServiceParamsMappingData> paramList = serviceParamsMappingDataList;
			try {
				BridgeDataObject bridgeObjData =  getBridgeObject(paramString, paramList,transactionData);
				bridgeObjData.setServiceType(ServiceType.valueOf(serviceDef));
				return bridgeObjData;
			} catch (NoSuchFieldException | SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException | NoSuchMethodException  e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new Exception(e.getMessage());
			}
			
		}
		throw new Exception(SystemConstant.PARAM_FILLER_UTIL_MSG1);
	}	
	
	
	
	
	private BridgeDataObject getBridgeObject(String paramString,List<ServiceParamsMappingData> paramList,TransactionData transactionData) throws NumberFormatException, NoSuchFieldException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, InstantiationException, ClassNotFoundException{
		BridgeDataObject bridgeObject = null;
		Collections.sort(paramList);
		if(paramString!=null && !paramString.isEmpty() && paramList!=null && !paramList.isEmpty()){
			bridgeObject = new BridgeDataObject();
			Map<Integer,String> paramMapFromReq = getParamList(paramString,SystemConstant.PLUS);
			if(paramMapFromReq!=null && !paramMapFromReq.isEmpty() && paramMapFromReq.size()==paramList.size()){
				Integer index= 1;
				for(ServiceParamsMappingData serviceParamsMappingData : paramList){
					fillData(paramMapFromReq.get(index++), serviceParamsMappingData, bridgeObject,transactionData);
				}
			}
		}
		return bridgeObject;
	}
	
	private List<String> getParams(String paramsString,String splitter){
		List<String> objList = new ArrayList<>();
		StringTokenizer st = new StringTokenizer(paramsString, splitter);
		while (st.hasMoreElements()) {
			objList.add((String)st.nextElement());
		}
		return objList;
	}
	private void fillData(String reqParam,ServiceParamsMappingData serviceParamsMappingData,BridgeDataObject bridgeObject,TransactionData transactionData) throws NumberFormatException, NoSuchFieldException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, InstantiationException, ClassNotFoundException{
		if(serviceParamsMappingData.getObjectMapping()!=null && !serviceParamsMappingData.getObjectMapping().isEmpty()){
			if(serviceParamsMappingData.getObjectMapping().contains(SystemConstant.DOT)){
				List<String> objList = getParams(serviceParamsMappingData.getObjectMapping(), SystemConstant.DOT);
				Map<Integer,Object> objectMap = new HashMap<>();
				if(objList!=null && !objList.isEmpty()){
					int size = objList.size();
					for(int i=0;i<size;i++){
						if(i==0){
							objectMap.put(0,checkAndInitializeObject(reqParam, bridgeObject, objList.get(0)));
						}else if(i<size-1 && i!=size-1){
							objectMap.put(i,checkAndInitializeObject(reqParam, objectMap.get(i-1), objList.get(i)));
						}
						else if(i==size-1){
							// Means going to set Primitive
							fillPrimitive(reqParam, objectMap.get(i-1), objList.get(i),serviceParamsMappingData.getIsnumericField(),transactionData);
						}
					}
				}
			}else{
				if(reqParam!=null && !reqParam.isEmpty()){
					fillPrimitive(reqParam, bridgeObject, serviceParamsMappingData.getObjectMapping(),serviceParamsMappingData.getIsnumericField(),transactionData);
				}
				
			}
		}
	}
	
	private Object checkAndInitializeObject(String reqParam,Object object,String fieldName) throws NoSuchFieldException, SecurityException, NumberFormatException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, InstantiationException, ClassNotFoundException{
		Method[] methods= object.getClass().getDeclaredMethods();
		Map<String,Method> methodMap = new HashMap<>();
		for(Method method : methods){
			if(method!=null){
				methodMap.put(method.getName().toLowerCase(), method);
			}
		}
		Method getMethod = methodMap.get(SystemConstant.GET.toLowerCase()+fieldName.toLowerCase());
		Object returnType = getMethod.invoke(object, null);
		if(getMethod!=null && returnType!=null) {
			return returnType;
		}
		Field field = object.getClass().getDeclaredField(fieldName);
		Method setMethod = methodMap.get(SystemConstant.SET.toLowerCase()+fieldName.toLowerCase());
		if(field!=null){
			Class<?> classType = field.getType();
			Object obj= Class.forName(classType.getCanonicalName()).newInstance();
			setMethod.invoke(object, obj);
			return obj;
		}
		return null;
	}
	
	private void fillPrimitive(String reqParam,Object object,String fieldName,Boolean isNumeric,TransactionData transactionData) throws NumberFormatException, IllegalAccessException, NoSuchFieldException, SecurityException, NoSuchMethodException, InvocationTargetException{
		fieldName = fieldName.trim();
		Field field = object.getClass().getDeclaredField(fieldName);
		Method[] methods= object.getClass().getDeclaredMethods();
		Map<String,Method> methodMap = new HashMap<>();
		for(Method method : methods){
			if(method!=null && method.getName().toLowerCase().startsWith(SystemConstant.SET.toLowerCase())){
				methodMap.put(method.getName().toLowerCase(), method);
			}
			
		}
		Method myMethod = methodMap.get(SystemConstant.SET.toLowerCase()+fieldName.toLowerCase());
		boolean skip=false;
		if(transactionData!=null){
			skip=transactionData.isSkipNumeric();
		}
		isNumeric = isNumeric==null?false:isNumeric;
		if(isNumeric && !skip){
			reqParam = bcdConversion(reqParam);
		}
		
		if(field!=null){
			Class<?> classType = field.getType();
			if (classType.getCanonicalName().equalsIgnoreCase(SystemConstant.LONG_W_TYPE) || classType.getCanonicalName().equalsIgnoreCase(SystemConstant.LONG_TYPE)) {
				myMethod.invoke(object, Long.valueOf(reqParam));
			}else if(classType.getCanonicalName().equalsIgnoreCase(SystemConstant.INTEGER_TYPE) || classType.getCanonicalName().equalsIgnoreCase(SystemConstant.INT_TYPE)){
				myMethod.invoke(object, Integer.valueOf(reqParam));
			}else if(classType.getCanonicalName().equalsIgnoreCase(SystemConstant.FLOAT_W_TYPE) || classType.getCanonicalName().equalsIgnoreCase(SystemConstant.FLOAT_TYPE)){
				myMethod.invoke(object, Float.valueOf(reqParam));
			}else if(classType.getCanonicalName().equalsIgnoreCase(SystemConstant.DOUBLE_W_TYPE) || classType.getCanonicalName().equalsIgnoreCase(SystemConstant.DOUBLE_TYPE)){
				myMethod.invoke(object, Double.valueOf(reqParam));
			}else if(classType.getCanonicalName().equalsIgnoreCase(SystemConstant.SHORT_W_TYPE) || classType.getCanonicalName().equalsIgnoreCase(SystemConstant.SHORT_TYPE)){
				myMethod.invoke(object, Short.valueOf(reqParam));
			}else if(classType.getCanonicalName().equalsIgnoreCase(SystemConstant.STRING_TYPE)){
				myMethod.invoke(object, reqParam);
			}else if(classType.getCanonicalName().equalsIgnoreCase(SystemConstant.BYTE_W_TYPE) || classType.getCanonicalName().equalsIgnoreCase(SystemConstant.BYTE_TYPE)){
				myMethod.invoke(object, Byte.valueOf(reqParam));
			}
		}
		
	}
	
	private String bcdConversion(String reqParam){
		//String hexToString=BCDConvert.GetBCDToString(reqParam);
		String hexToString = BCDConvert.BCDtoString(reqParam.getBytes());
		 // System.out.println(GetByteArrayToHex(buff));
		 // String hexToString=BCDConvert.GetBCDToString(tmp);
		
		return hexToString;
	}
	
	private Map<Integer,String> getParamList(String paramString,String splitter){
		Map<Integer,String> map = null;
		String[] strArr = paramString.split(splitter);
		if(strArr!=null && strArr.length>0){
			map = new HashMap<>();
			Integer index= 1;
			for(String str : strArr){
				map.put(index++, str);
			}
		}
		return map;
	}
	
	private ServiceType getServiceType(String servDef){
		return ServiceType.valueOf(servDef);
		
	}
	
	private String getServiceTypeFrmCache(String serviceCode){
		//TODO get it from cache.
		return ServiceType.BANKING_CHECK_BAL.name();
	}
	
	private List<ServiceParamsMappingData> getServiceParams(Integer serviceId){
		if(serviceId!=0){
			return getServiceParamsFromCache(serviceId);
		}
		return null;
	}
	
	
	
	private List<ServiceParamsMappingData> getServiceParamsFromCache(Integer serviceId){
		//TODO get it from cache.
		
		// Taking Banking_FT_B_T_B case
		//adc-act+IFSC+pact+IFSC+amt+bpin
		//zic-accid+billcat+billnm+billid+subs_id+tpin
		
		List<ServiceParamsMappingData> list = new ArrayList<>();
		ServiceParamsMappingData data = new ServiceParamsMappingData();
		data = new ServiceParamsMappingData();
		data.setName("code");
		data.setObjectMapping("settings.myBiller.category.code");
		data.setSequence(2);
		/*data.setIsnumericField(true);*/
		list.add(data);
		
		data = new ServiceParamsMappingData();
		data.setName("msisdn");
		data.setObjectMapping("settings.myWallet.msisdn");
		data.setSequence(1);
		/*data.setIsnumericField(true);*/
		list.add(data);
			
		return list;
	}
	
	/*public static void main(String[] args) {
		ParameterFillerUtil util = new ParameterFillerUtil();
		try {
			//BridgeDataObject bridgeObject = util.fillParams(ServiceType.BANKING_CHECK_BAL.name(),23, "payerKaact000000+payerKaIFSC00000+pact000000+payeeKaIFSC000000+12222322+121234");
			BridgeDataObject bridgeObject = util.fillParams("BANKING_CHECK_BAL",23, "MyPhone+CatCode");
			System.out.println(bridgeObject);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}*/
	
}
 //Code commented for Refactoring(16.02.2016)