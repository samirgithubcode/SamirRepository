package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author abhishek
 *
 */
@Entity
@Table(name = "KYCDescriptor")
@XmlRootElement
@NamedQueries({
//	  @NamedQuery(name = "KYCDescriptor.findAll", query = "SELECT kd FROM KYCDescriptor kd"),
//	    @NamedQuery(name = "KYCDescriptor.findAllbyname", query = "SELECT k FROM KYCDescriptor k"),

    @NamedQuery(name = "KYCDescriptor.findAll", query = "SELECT kd FROM KYCDescriptor kd"),
    @NamedQuery(name = "KYCDescriptor.countByName", query = "SELECT count(*) FROM KYCDescriptor kd where kd.name=:name"),
    @NamedQuery(name = "KYCDescriptor.findByHostId", query = "SELECT kd FROM KYCDescriptor kd where kd.hostId = :hostId"),
    @NamedQuery(name = "KYCDescriptor.findByName", query = "SELECT kd FROM KYCDescriptor kd where kd.name = :name"),
    @NamedQuery(name = "KYCDescriptor.findByNameHostId", query = "SELECT kd FROM KYCDescriptor kd where kd.name = :name and kd.hostId = :hostId "),
    @NamedQuery(name = "KYCDescriptor.findByNameandid", query = "SELECT kd FROM KYCDescriptor kd where kd.name = :name AND kd.id=:id"),
   //@NamedQuery(name = "KYCDescriptor.findByhostIdAndLevel", query = "SELECT kd FROM KYCDescriptor kd where kd.hostId = :hostId AND kd.levelId = :levelId"),
    @NamedQuery(name = "KYCDescriptor.findByid", query = "SELECT kd FROM KYCDescriptor kd where kd.id=:id"),
    @NamedQuery(name = "KYCDescriptor.findByIdandHostId", query = "SELECT kd FROM KYCDescriptor kd where kd.id=:id and kd.hostId = :hostId"),
    @NamedQuery(name = "KYCDescriptor.findByInfo", query = "SELECT kd FROM KYCDescriptor kd where kd.hostId=:hostId and weightage=:weightage and subscriberType=:subscriberType"),
    @NamedQuery(name = "KYCDescriptor.findDefaultKycDescriptor", query = "SELECT kd FROM KYCDescriptor kd where kd.hostId=:hostId AND kd.weightage=:weightage AND kd.subscriberType=:subscriberType AND kd.status='ACTIVE'"),
    @NamedQuery(name = "KYCDescriptor.findKycDescriptorByWeightAndUserType", query = "SELECT kd FROM KYCDescriptor kd where kd.hostId=:hostId AND kd.weightage<=:weightage AND kd.weightage>0 AND kd.subscriberType=:userType AND kd.status='ACTIVE' "),
   
})
public class KYCDescriptor implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
   
    @Column(name = "description")
    private String description;
    
    @Column(name = "name")
    private String name;
    @ManyToOne
	@JoinColumn(name = "hostId",nullable=false)
    private AccountInfo hostId;
    
	@Column(name = "weightage")
    private Integer weightage;
    
    
    @Column(name = "dailyDebitLimit")
    private Integer dailyDebitLimit;
    
    @Column(name = "dailyCreditLimit")
    private Integer dailyCreditLimit;
    
    @Column(name = "dailyTxnCount")
    private Integer dailyTxnCount;
    
    @Column(name = "monthlyDebitLimit")
    private Integer monthlyDebitLimit;
    
    @Column(name = "monthlyCreditLimit")
    private Integer monthlyCreditLimit;
    
    @Column(name = "monthlyTxnCount")
    private Integer monthlyTxnCount;
    
    @Column(name = "yearlyDebitLimit")
    private Integer yearlyDebitLimit;
    
    @Column(name = "yearlyCreditLimit")
    private Integer yearlyCreditLimit;
    
    @Column(name = "yearlyTxnCount")
    private Integer yearlyTxnCount;
    
    @Column(name = "status")
    private String status; 
    
    @Column(name = "createdBy")
    private Integer createdBy;
    @Column(name = "createdOn")
    private Date createdOn;
    
    @Column(name = "subscriberType")
    private String subscriberType;
    
    
   

	public KYCDescriptor(){
    	//empty
    }
    
    public KYCDescriptor(Integer id){
    	this.id = id;
    }
    
    public String getSubscriberType() {
		return subscriberType;
	}

	public void setSubscriberType(String subscriberType) {
		this.subscriberType = subscriberType;
	}
	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public Integer getWeightage() {
		return weightage;
	}

	public void setWeightage(Integer weightage) {
		this.weightage = weightage;
	}

	public Integer getDailyDebitLimit() {
		return dailyDebitLimit;
	}

	public void setDailyDebitLimit(Integer dailyDebitLimit) {
		this.dailyDebitLimit = dailyDebitLimit;
	}

	public Integer getDailyCreditLimit() {
		return dailyCreditLimit;
	}

	public void setDailyCreditLimit(Integer dailyCreditLimit) {
		this.dailyCreditLimit = dailyCreditLimit;
	}

	public Integer getDailyTxnCount() {
		return dailyTxnCount;
	}

	public void setDailyTxnCount(Integer dailyTxnCount) {
		this.dailyTxnCount = dailyTxnCount;
	}

	public Integer getMonthlyDebitLimit() {
		return monthlyDebitLimit;
	}

	public void setMonthlyDebitLimit(Integer monthlyDebitLimit) {
		this.monthlyDebitLimit = monthlyDebitLimit;
	}

	public Integer getMonthlyCreditLimit() {
		return monthlyCreditLimit;
	}

	public void setMonthlyCreditLimit(Integer monthlyCreditLimit) {
		this.monthlyCreditLimit = monthlyCreditLimit;
	}

	public Integer getMonthlyTxnCount() {
		return monthlyTxnCount;
	}

	public void setMonthlyTxnCount(Integer monthlyTxnCount) {
		this.monthlyTxnCount = monthlyTxnCount;
	}

	public Integer getYearlyDebitLimit() {
		return yearlyDebitLimit;
	}

	public void setYearlyDebitLimit(Integer yearlyDebitLimit) {
		this.yearlyDebitLimit = yearlyDebitLimit;
	}

	public Integer getYearlyCreditLimit() {
		return yearlyCreditLimit;
	}

	public void setYearlyCreditLimit(Integer yearlyCreditLimit) {
		this.yearlyCreditLimit = yearlyCreditLimit;
	}

	public Integer getYearlyTxnCount() {
		return yearlyTxnCount;
	}

	public void setYearlyTxnCount(Integer yearlyTxnCount) {
		this.yearlyTxnCount = yearlyTxnCount;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public AccountInfo getHostId() {
		return hostId;
	}
	public void setHostId(AccountInfo hostId) {
		this.hostId = hostId;
	}
	
	
	
	@Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
    	boolean check=true;
    	if(object!=null){
        if (!(object instanceof KYCDescriptor)) {
        	check= false;
        }
        KYCDescriptor other = (KYCDescriptor) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check=false;
        }
    	}
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.KYCDescriptor[ id=" + id + " ]";
    }
}
