package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.*;

import java.sql.Timestamp;


/**
 * @author abhishek
 *
 */
@Entity
@Table(name="customerTransaction")
@NamedQuery(name="CustomerTransaction.findAll", query="SELECT c FROM CustomerTransaction c")
public class CustomerTransaction implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false)
	private Integer id;

	@Column(name="amountAfterTxn", nullable=false)
	private Integer amountAfterTxn;

	@Column(name="amountBeforTxn", nullable=false)
	private Integer amountBeforTxn;

	@Column(name="clientBusinessDate", nullable=false)
	private Timestamp clientBusinessDate;

	@Column(name="clientCounterNo", nullable=false, length=30)
	private String clientCounterNo;

	@Column(name="clientOperatorId", nullable=false, length=30)
	private String clientOperatorId;

	@Column(name="clientStoreId", nullable=false, length=30)
	private String clientStoreId;

	@Column(name="clientTransactionId", nullable=false, length=30)
	private String clientTransactionId;

	@Column(name="contactNumber", nullable=false, length=25)
	private String contactNumber;

	@Column(name="ip", nullable=false, length=25)
	private String ip;

	@Column(name="otp")
	private Integer otp;

	@Column(name="status", nullable=false, length=1)
	private String status;

	@Column(name="transactionAmount", nullable=false)
	private Integer transactionAmount;

	@Column(name="transactionId", nullable=false, length=25)
	private String transactionId;

	@Column(name="type", nullable=false, length=1)
	private String type;

	//bi-directional many-to-one association to Partner
	@ManyToOne
	@JoinColumn(name="walletId", nullable=false)
	private Partner partner;

	//bi-directional many-to-one association to Customer
	@ManyToOne
	@JoinColumn(name="customerId")
	private Customer customer;

	//bi-directional many-to-one association to PortalRegistration
	@ManyToOne
	@JoinColumn(name="portalId")
	private PortalRegistration portalRegistration;

	public CustomerTransaction() {
		//empty
	}
	
	public CustomerTransaction(Integer id) {
		this.id=id;
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getAmountAfterTxn() {
		return this.amountAfterTxn;
	}

	public void setAmountAfterTxn(Integer amountAfterTxn) {
		this.amountAfterTxn = amountAfterTxn;
	}

	public Integer getAmountBeforTxn() {
		return this.amountBeforTxn;
	}

	public void setAmountBeforTxn(Integer amountBeforTxn) {
		this.amountBeforTxn = amountBeforTxn;
	}

	public Timestamp getClientBusinessDate() {
		return this.clientBusinessDate;
	}

	public void setClientBusinessDate(Timestamp clientBusinessDate) {
		this.clientBusinessDate = clientBusinessDate;
	}

	public String getClientCounterNo() {
		return this.clientCounterNo;
	}

	public void setClientCounterNo(String clientCounterNo) {
		this.clientCounterNo = clientCounterNo;
	}

	public String getClientOperatorId() {
		return this.clientOperatorId;
	}

	public void setClientOperatorId(String clientOperatorId) {
		this.clientOperatorId = clientOperatorId;
	}

	public String getClientStoreId() {
		return this.clientStoreId;
	}

	public void setClientStoreId(String clientStoreId) {
		this.clientStoreId = clientStoreId;
	}

	public String getClientTransactionId() {
		return this.clientTransactionId;
	}

	public void setClientTransactionId(String clientTransactionId) {
		this.clientTransactionId = clientTransactionId;
	}

	public String getContactNumber() {
		return this.contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getIp() {
		return this.ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public Integer getOtp() {
		return this.otp;
	}

	public void setOtp(Integer otp) {
		this.otp = otp;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Integer getTransactionAmount() {
		return this.transactionAmount;
	}

	public void setTransactionAmount(Integer transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	public String getTransactionId() {
		return this.transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Partner getPartner() {
		return this.partner;
	}

	public void setPartner(Partner partner) {
		this.partner = partner;
	}

	public Customer getCustomer() {
		return this.customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public PortalRegistration getPortalRegistration() {
		return this.portalRegistration;
	}

	public void setPortalRegistration(PortalRegistration portalRegistration) {
		this.portalRegistration = portalRegistration;
	}

}