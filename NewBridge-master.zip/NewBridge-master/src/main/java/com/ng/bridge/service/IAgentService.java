/**
 * 
 */
package com.ng.bridge.service;

import com.ng.sb.common.dataobject.BridgeDataObject;

/**
 * @author gaurav
 *
 */
public interface IAgentService extends IWalletService {
	public BridgeDataObject checkBalance(BridgeDataObject bridgeDataObject);
	public BridgeDataObject topOnline(BridgeDataObject bridgeDataObject);
	public BridgeDataObject topUpAccount(BridgeDataObject bridgeDataObject);
}
