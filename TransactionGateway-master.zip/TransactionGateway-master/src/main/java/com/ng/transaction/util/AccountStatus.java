/**
 * 
 */
package com.ng.transaction.util;

/**
 * @author gopal
 *
 */
public enum AccountStatus {

	ADD(2001,"ADD"),
	REMOVE(2002,"REMOVE"),
	ACTIVATE(2003,"ACTIVATE"),
	DE_ACTIVATE(2004,"DE_ACTIVATE");
	
	private Integer actionCode;
	private String actionName;
	
	AccountStatus(Integer actionCode, String actionName)
	{
		this.actionCode = actionCode;
		this.actionName = actionName;
	}

	public Integer getActionCode() {
		return actionCode;
	}

	public String getActionName() {
		return actionName;
	}
}
