package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;


@Entity
@Table(name="OrderDetailHistory")
@XmlRootElement
@NamedQueries
({
	@NamedQuery(name="OrderDetailHistory.findAll",query="SELECT o FROM OrderDetailHistory o"),
})
public class OrderDetailHistory implements Serializable{

	
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name="id")
	private Integer id;
	
	@Basic(optional = false)
	@JoinColumn(name="orderDetailId")
	@ManyToOne
	private OrderDetail orderDetailId;
	
	@Basic(optional = false)
	@Column(name="unitsOrdered")
	private Integer unitsOrdered;
	
	@Basic(optional = false)
	@Column(name="unitsDispatched")
	private Integer unitsDispatched;
	
	@Basic(optional = false)
	@Column(name="action")
	private String action;
	
	@Basic(optional = false)
	@Column(name="date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date date;

	public OrderDetailHistory(){
		//empty
	}
	
	public OrderDetailHistory(Integer id){
		this.id = id;
	}
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public OrderDetail getOrderDetailId() {
		return orderDetailId;
	}

	public void setOrderDetailId(OrderDetail orderDetailId) {
		this.orderDetailId = orderDetailId;
	}

	public Integer getUnitsOrdered() {
		return unitsOrdered;
	}

	public void setUnitsOrdered(Integer unitsOrdered) {
		this.unitsOrdered = unitsOrdered;
	}

	public Integer getUnitsDispatched() {
		return unitsDispatched;
	}

	public void setUnitsDispatched(Integer unitsDispatched) {
		this.unitsDispatched = unitsDispatched;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "OrderDetailHistory [id=" + id + "]";
	}
	
	@Override
	public int hashCode() {
	    int hash = 0;
	    hash += (id != null ? id.hashCode() : 0);
	    return hash;
	}

	@Override
	public boolean equals(Object object) {
	    if (!(object instanceof OrderDetailHistory)) {
	        return false;
	    }
	    OrderDetailHistory other = (OrderDetailHistory) object;
	    boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
	}
}
