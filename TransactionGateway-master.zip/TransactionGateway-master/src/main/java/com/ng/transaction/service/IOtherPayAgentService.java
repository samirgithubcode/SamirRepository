/**
 * 
 */
package com.ng.transaction.service;

import com.ng.sb.common.dataobject.BridgeDataObject;

/**
 * @author gaurav
 *
 */
public interface IOtherPayAgentService  extends IWalletService {

	public BridgeDataObject payAgentBankToBank(BridgeDataObject bridgeDataObject);
	public BridgeDataObject payAgentBankToWallet(BridgeDataObject bridgeDataObject);
	public BridgeDataObject payAgentBankToCC(BridgeDataObject bridgeDataObject);
	public BridgeDataObject payAgentBankToIMPS(BridgeDataObject bridgeDataObject);
	
	public BridgeDataObject payAgentIMPSToBank(BridgeDataObject bridgeDataObject);
	public BridgeDataObject payAgentIMPSToWallet(BridgeDataObject bridgeDataObject);
	public BridgeDataObject payAgentIMPSToCC(BridgeDataObject bridgeDataObject);
	public BridgeDataObject payAgentIMPSToIMPS(BridgeDataObject bridgeDataObject);
	
	public BridgeDataObject payAgentCCToBank(BridgeDataObject bridgeDataObject);
	public BridgeDataObject payAgentCCToWallet(BridgeDataObject bridgeDataObject);
	public BridgeDataObject payAgentCCToCC(BridgeDataObject bridgeDataObject);
	public BridgeDataObject payAgentCCToIMPS(BridgeDataObject bridgeDataObject);
	
	public BridgeDataObject payAgentWalletToWallet(BridgeDataObject bridgeDataObject);
	public BridgeDataObject payAgentWalletToBank(BridgeDataObject bridgeDataObject);
}
