/**
 * 
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
@Entity
@Table(name="product_orders")
@XmlRootElement
@NamedQueries
({
@NamedQuery(name = "ProductOrders.findForOrder", query = "SELECT p FROM ProductOrders p ORDER BY p.orderId DESC "),	
@NamedQuery(name = "ProductOrders.findByPayCardId", query = "SELECT p FROM ProductOrders p where p.payCardId=:payCardId "),
@NamedQuery(name = "ProductOrders.findByTxnId", query = "SELECT p FROM ProductOrders p where p.transactionId.id=:transactionId "),
@NamedQuery(name = "ProductOrders.findByPayCardIdForRefund", query = "SELECT p FROM ProductOrders p where p.payCardId=:payCardId and p.statusDesc=:statusDesc")
})
public class ProductOrders implements Serializable
{
	private static final long serialVersionUID = -2867194360518006657L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional=false)
	@Column(name="orderid")
	private Integer orderId;
	
	@Column(name="agent_id")
	private Integer agentId;
	
	@Column(name = "agent_company_id")
	private Integer agentCompanyId;
	
	@ManyToOne
	@JoinColumn(name="product_id", referencedColumnName="id")
	private Products productId;
	
	/*@ManyToOne(optional=true)
	@JoinColumn(name="subcriber_id", referencedColumnName="id")
	*/
	@Column(name="subcriber_id")
	private Integer subscriberId;
	
	
	@Column(name="order_type")
	private String orderType;
	
	@Column(name="voucherDenomination_id")
	private Integer voucherDenominationId;
	
	@ManyToOne
	@JoinColumn(name="payCardId", referencedColumnName="id")
	//@Column(name="payCardId")
	private InventoryMgmt payCardId;
	
	@Column(name="payCardWalletId")
	private Integer payCardWalletId;
	
	@Column(name="payCardAppId")
	private Integer payCardAppId;
	
	@Column(name="quantity")
	private Integer quantity;
	
	@Column(name="total_amount")
	private String totalAmount;
	
	@Column(name="order_date")
	private Date orderDate;
	
	@ManyToOne
	@JoinColumn(name="txn_id", referencedColumnName="id")
	private ProductTransactions transactionId ;
	
	@Column(name="status_des")
	private String statusDesc;
	
	@Column(name="status")
	private Integer orderStatus;
	
	@Column(name = "access_channel")
	private Integer accessChannel;
	
	@Column(name = "device_id")
	private String deviceId;
	
	public Products getProductId() {
		return productId;
	}

	public void setProductId(Products productId) {
		this.productId = productId;
	}

	public Integer getSubscriberId() {
		return subscriberId;
	}

	public void setSubscriberId(Integer subscriberId) {
		this.subscriberId = subscriberId;
	}


	
	public ProductTransactions getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(ProductTransactions transactionId) {
		this.transactionId = transactionId;
	}

	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public Integer getAgentId() {
		return agentId;
	}

	public void setAgentId(Integer agentId) {
		this.agentId = agentId;
	}

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	public Integer getVoucherDenominationId() {
		return voucherDenominationId;
	}

	public void setVoucherDenominationId(Integer voucherDenominationId) {
		this.voucherDenominationId = voucherDenominationId;
	}

	public InventoryMgmt getPayCardId() {
		return payCardId;
	}

	public void setPayCardId(InventoryMgmt payCardId) {
		this.payCardId = payCardId;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public String getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(String totalAmount) {
		this.totalAmount = totalAmount;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public String getStatusDesc() {
		return statusDesc;
	}

	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	public Integer getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(Integer orderStatus) {
		this.orderStatus = orderStatus;
	}

	public Integer getPayCardWalletId() {
		return payCardWalletId;
	}

	public void setPayCardWalletId(Integer payCardWalletId) {
		this.payCardWalletId = payCardWalletId;
	}

	@Override
	public boolean equals(Object object) {
		boolean checkStatus = true;
		if (object != null) {
			if (!(object instanceof ProductOrders)) {
				checkStatus = false;
			}
			ProductOrders other = (ProductOrders) object;
			if ((this.orderId == null && other.orderId != null)
					|| (this.orderId != null && !this.orderId.equals(other.orderId))) {
				checkStatus = false;
			}
		}
		return checkStatus;
	}
	
	public Integer getPayCardAppId() {
		return payCardAppId;
	}

	public void setPayCardAppId(Integer payCardAppId) {
		this.payCardAppId = payCardAppId;
	}
	


	@Override
	public int hashCode() {
		int hash = 0;
		hash += (orderId != null ? orderId.hashCode() : 0);
		return hash;
	}

	public Integer getAccessChannel() {
		return accessChannel;
	}

	public void setAccessChannel(Integer accessChannel) {
		this.accessChannel = accessChannel;
	}

	public Integer getAgentCompanyId() {
		return agentCompanyId;
	}

	public void setAgentCompanyId(Integer agentCompanyId) {
		this.agentCompanyId = agentCompanyId;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	
}
