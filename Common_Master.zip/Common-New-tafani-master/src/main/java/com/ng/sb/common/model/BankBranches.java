/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "BankBranches")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "BankBranches.findAll", query = "SELECT b FROM BankBranches b"),
    @NamedQuery(name = "BankBranches.findById", query = "SELECT b FROM BankBranches b WHERE b.id = :id"),
    @NamedQuery(name = "BankBranches.findByIfscSwiftCode", query = "SELECT b FROM BankBranches b WHERE b.ifscSwiftCode = :ifscSwiftCode"),
    @NamedQuery(name = "BankBranches.findByCreateDate", query = "SELECT b FROM BankBranches b WHERE b.createDate = :createDate")})
public class BankBranches implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "ifscSwiftCode")
    private String ifscSwiftCode;
    @Column(name = "createDate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createDate;
    @JoinColumn(name = "bankId", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Banks bankId;

    public BankBranches() {
    	//default constructor
    }

    public BankBranches(Integer id) {
        this.id = id;
    }

    public BankBranches(Integer id, String ifscSwiftCode) {
        this.id = id;
        this.ifscSwiftCode = ifscSwiftCode;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getIfscSwiftCode() {
        return ifscSwiftCode;
    }

    public void setIfscSwiftCode(String ifscSwiftCode) {
        this.ifscSwiftCode = ifscSwiftCode;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Banks getBankId() {
        return bankId;
    }

    public void setBankId(Banks bankId) {
        this.bankId = bankId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof BankBranches)) {
            return false;
        }
        boolean check=true;
        BankBranches other = (BankBranches) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.BankBranches[ id=" + id + " ]";
    }
    
}
