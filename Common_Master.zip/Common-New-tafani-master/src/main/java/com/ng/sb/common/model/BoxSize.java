/**
 * 
 */
package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author rajiv
 *
 */
@Entity
@Table(name = "BoxSize")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "BoxSize.findAll", query = "SELECT b FROM BoxSize b"),
    @NamedQuery(name = "BoxSize.findById", query = "SELECT b FROM BoxSize b WHERE b.id = :id"),
    @NamedQuery(name = "BoxSize.findByboxSize", query = "SELECT b FROM BoxSize b WHERE b.boxSizeNo = :boxSize"),
    /*@NamedQuery(name = "BoxSize.findBySize", query = "SELECT b FROM BoxSize b WHERE b.name = :name"),*/
  })
public class BoxSize implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 189329494573755288L;

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
    
	@Basic(optional = false)
    @Column(name = "boxSize", nullable = false, length = 50)
    private Integer boxSizeNo;
   
    @Column(name = "description")
    private String description;

    public BoxSize()
    {
    	//default constructor
    }
    
    public BoxSize(Integer id) {
		super();
		this.id = id;
	}
	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the boxSize
	 */
	public Integer getBoxSize() {
		return boxSizeNo;
	}

	/**
	 * @param boxSize the boxSize to set
	 */
	public void setBoxSize(Integer boxSize) {
		this.boxSizeNo = boxSize;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
   
    
}
