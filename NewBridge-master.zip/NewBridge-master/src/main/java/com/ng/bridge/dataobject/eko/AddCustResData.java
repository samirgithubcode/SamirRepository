package com.ng.bridge.dataobject.eko;

public class AddCustResData {
	private String otp;

    private String customeridtype;

    private String customerid;
    
    private String name;
    
    
    public String getCustomeridtype ()
    {
        return customeridtype;
    }

    public void setCustomeridtype (String customeridtype)
    {
        this.customeridtype = customeridtype;
    }

    public String getCustomerid ()
    {
        return customerid;
    }

    public void setCustomerid (String customerid)
    {
        this.customerid = customerid;
    }

    
    public String getOtp() {
		return otp;
	}

	public void setOtp(String otp) {
		this.otp = otp;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	
}
