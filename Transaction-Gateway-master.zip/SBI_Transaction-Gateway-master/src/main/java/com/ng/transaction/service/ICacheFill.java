package com.ng.transaction.service;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.ng.sb.common.dataobject.CategoryData;
import com.ng.sb.common.dataobject.FSPServicesData;
import com.ng.sb.common.dataobject.HostSubVersionData;
import com.ng.sb.common.dataobject.PartnerData;
import com.ng.sb.common.dataobject.ServiceConfigData;
import com.ng.sb.common.model.HostSVFspServicesPartnerMapping;



public interface ICacheFill {
	public Map<HostSubVersionData,HostSubVersionData> getHostSubVersionMap() throws Exception;
	 public Map<CategoryData,CategoryData> getCategoriesMap() throws Exception;
	 public Map<FSPServicesData,FSPServicesData> getFspServiceMap(List<HostSVFspServicesPartnerMapping> fspList) throws Exception;
	 public Set<PartnerData> getPartner() throws Exception;
	 public Map<ServiceConfigData,ServiceConfigData> getServiceConfigMap() throws Exception;
}
