/**
 * 
 */
package com.ng.user.conf;

import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ng.sb.common.cache.MemCacheManager;
import com.ng.sb.common.cache.MemCacheUtils;
import com.ng.sb.common.model.Menu;
import com.ng.user.db.IUserDao;

/**
 * @author gopal
 *
 */
@Component
public class Initializer 
{

	@Autowired
	IUserDao userDao;
	
	@Autowired
    private MemCacheManager cacheManager;
	
	@PostConstruct
	public void init(){
		try {
	
			loadAuthorizationCache();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private void loadAuthorizationCache() 
	{
		try{
			List<Menu> activeMenus = userDao.getAllActiveMenus();
			
			if(activeMenus != null && !activeMenus.isEmpty())
			{
			    cacheManager.clearCache(MemCacheUtils.AUTHORIZATIONCACHE);
				
				for(Menu menu : activeMenus)
				{
					String actionUrl = menu.getAction();
					String accountTypeId = menu.getAccountTypeId();
					
					if(menu.getAction() != null)
						cacheManager.addToCache(actionUrl.toLowerCase(), accountTypeId, MemCacheUtils.AUTHORIZATIONCACHE);
				}
			}
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public boolean updateAuthorizationCache(String actionUrl, String accountTypeId) 
	{
		try{
			
			if(actionUrl == null || accountTypeId == null)
			return false;
			
			cacheManager.removeFromCache(actionUrl.toLowerCase(), MemCacheUtils.AUTHORIZATIONCACHE);
			
			cacheManager.addToCache(actionUrl.toLowerCase(), accountTypeId, MemCacheUtils.AUTHORIZATIONCACHE);
			
			return true;
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;
	}
	
}
