package com.ng.sb.common.dataobject;

public class LogoutData  extends BaseObjectData{

	private static final long serialVersionUID = 1L;
	private String view;
	private String statusMessage;
	public String getView() {
		return view;
	}
	public void setView(String view) {
		this.view = view;
	}
	public String getStatusMessage() {
		return statusMessage;
	}
	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}
	
	
}
