package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name = "securityQuestion")
@XmlRootElement
@NamedQueries({
	 @NamedQuery(name = "SecurityQuestion.findAllQuestion", query = "SELECT a FROM SecurityQuestion a"),
	 @NamedQuery(name = "SecurityQuestion.findById", query = "SELECT a FROM SecurityQuestion a where a.id=:id"),
})
public class SecurityQuestion implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
		@Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Basic(optional = false)
	    @Column(name = "id")
	    private Integer id;
		@Column(name = "securityQuestion")
	    private String securitQuestion;
		
		@Column(name = "status")
	    private Integer status;
	
		public Integer getStatus() {
			return status;
		}

		public void setStatus(Integer status) {
			this.status = status;
		}
		@Basic(optional = false)
	    @Column(name = "createDate")
	    @Temporal(TemporalType.TIMESTAMP)
	    private Date createDate;
		
		public SecurityQuestion()
		{
			//empty
		}
		
		public SecurityQuestion(Integer id)
		{
			this.id=id;
		}
		public String getSecuritQuestion() {
			return securitQuestion;
		}

		public void setSecuritQuestion(String securitQuestion) {
			this.securitQuestion = securitQuestion;
		}
		public Integer getId() {
			return id;
		}
		public void setId(Integer id) {
			this.id = id;
		}
		
		public Date getCreateDate() {
			return createDate;
		}
		public void setCreateDate(Date createDate) {
			this.createDate = createDate;
		}
		

}
