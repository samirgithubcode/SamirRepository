/**
 * 
 */
package com.ng.transaction.data;

import java.io.Serializable;

/**
 * @author gaurav
 *
 */
public class BaseObject implements Serializable{
	private static final long serialVersionUID = 1L;

}
