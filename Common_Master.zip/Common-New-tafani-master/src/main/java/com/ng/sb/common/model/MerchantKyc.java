package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name="merchantKyc")
@NamedQueries({
	@NamedQuery(name="MerchantKyc.findByMerchantId", query ="SELECT m FROM MerchantKyc m where m.merchantId = :id"),
	@NamedQuery(name="MerchantKyc.findByID", query ="SELECT m FROM MerchantKyc m where m.id = :id"),
	@NamedQuery(name="MerchantKyc.removeByMerchantID", query ="DELETE  FROM MerchantKyc m where m.merchantId = :id"),
	@NamedQuery(name="MerchantKyc.removeByMerchantIDAndIdProof", query ="DELETE  FROM MerchantKyc m where m.merchantId = :id AND m.idProofId=:idProofId"),
})
public class MerchantKyc implements Serializable {
	   private static final long serialVersionUID = 1L;
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Basic(optional = false)
	    @Column(name = "id", nullable = false)
	    private Integer id;
	    
	    @Column(name = "idProofId")
		private int idProofId;
	    
		@Column(name = "userIdProofId")
		private String userIdProofId;
	    
	    @Column(name = "documentName")
		private String documentName;
	    
	 
	    @Column(name="validFrom")
	    private Date validFrom;
	    
	    @Temporal(TemporalType.TIMESTAMP)
	    @Column(name="validTo")
	    private Date validTo;
	    
	
	    @Temporal(TemporalType.TIMESTAMP)
	    @Column(name = "createdOn")
  		private Date createdOn;
	    
	    @Column(name = "createdBy")
  		private String createdBy;
	    public Integer getId() {
			return id;
		}

		public void setId(Integer id) {
			this.id = id;
		}

		public int getIdProofId() {
			return idProofId;
		}

		public void setIdProofId(int idProofId) {
			this.idProofId = idProofId;
		}

		public String getUserIdProofId() {
			return userIdProofId;
		}

		public void setUserIdProofId(String userIdProofId) {
			this.userIdProofId = userIdProofId;
		}

		public String getDocumentName() {
			return documentName;
		}

		public void setDocumentName(String documentName) {
			this.documentName = documentName;
		}

		
		public Date getCreatedOn() {
			return createdOn;
		}

		public void setCreatedOn(Date createdOn) {
			this.createdOn = createdOn;
		}

		public String getCreatedBy() {
			return createdBy;
		}

		public void setCreatedBy(String createdBy) {
			this.createdBy = createdBy;
		}

		public Integer getMerchantId() {
			return merchantId;
		}

		public void setMerchantId(Integer merchantId) {
			this.merchantId = merchantId;
		}

		public Date getModifiedOn() {
			return modifiedOn;
		}

		public void setModifiedOn(Date modifiedOn) {
			this.modifiedOn = modifiedOn;
		}

		@Column(name = "merchantId")
  		private Integer merchantId;
	    
	    @Column(name = "modifiedOn")
  		private Date modifiedOn;
		public Date getValidFrom() {
			return validFrom;
		}

		public void setValidFrom(Date validFrom) {
			this.validFrom = validFrom;
		}

		public Date getValidTo() {
			return validTo;
		}

		public void setValidTo(Date validTo) {
			this.validTo = validTo;
		}

	
}
