package com.ng.sc.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.ServletContextAware;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.ng.sb.common.controller.ASelfCareController;
import com.ng.sb.common.dataobject.AddressInfo;
import com.ng.sb.common.dataobject.LoginData;
import com.ng.sb.common.dataobject.PlatformLoginData;
import com.ng.sb.common.dataobject.SubscriberData;
import com.ng.sb.common.dataobject.TransactionRequestData;
import com.ng.sb.common.dataobject.UserAccountData;
import com.ng.sb.common.dataobject.WalletRequest;
import com.ng.sb.common.util.ErrorCodes;
import com.ng.sb.common.util.MailSenderUtil;
import com.ng.sb.common.util.SystemConstant;
import com.ng.sc.service.IScLoginService;
import com.ng.sc.service.IScSessionService;
import com.ng.sc.service.IScUserMgmntService;
import com.ng.sc.utils.ArabicProperties;
import com.ng.sc.utils.ScSystemConstant;

@Controller
@RequestMapping(value = "/UserMgmt")
public class ScUserMgmntController extends ASelfCareController implements ServletContextAware {

	private static final Logger LOGGER = LoggerFactory.getLogger(ScUserMgmntController.class);
	public static final String WALLETDETAILS = "walletDetails";
	public static final String WALLETLISTINFO = "walletListInfo";
	@Autowired
	IScLoginService loginService;
	@Autowired
	private MessageSource messageSource;
	ServletContext context;
	@Autowired
	IScSessionService managemetImpl;
	@Autowired
	IScUserMgmntService iUserMgmntService;
	@Autowired
	ApplicationContext applicationContext;
	@Autowired
	private MailSenderUtil mailSender;
	
	@Autowired
	@Qualifier(value="platformLoginData")
	PlatformLoginData platformLoginData;
	
	@Autowired
	private ArabicProperties arabicProperties;
	
	
	private ModelMap map = new ModelMap();

	@Override
	public void setServletContext(ServletContext context) {
		this.context = context;
	}

	@RequestMapping(value = "/getIndexPage", method = RequestMethod.GET)
	public ModelAndView getIndexPage(HttpSession session) {

		String view = "";
		try {

			LOGGER.info("*******Execution start of method getIndexPage() in controller ScUserMgmntController ");
			LoginData loginData = managemetImpl.getSessionInfo(session);
			if (loginData.isSessionInfo()) {
				SubscriberData subscriberData = iUserMgmntService.getProfilesById(loginData.getAccountTypeId());
				SubscriberData walletDetails = iUserMgmntService.getWalletDetailList(loginData, session);
				map.addAttribute(WALLETDETAILS, walletDetails);
				map.addAttribute(ScSystemConstant.SUBSCRIBERDATA, subscriberData);
				map.addAttribute(SystemConstant.STATUS_MESSAGE, "");
				map.addAttribute(SystemConstant.ERRORSTATUSMESSAGE, "");
				map.addAttribute(SystemConstant.MENU_ID, "185");
				map.addAttribute(SystemConstant.SUBMENU_ID, "186");
				map.addAttribute("props", arabicProperties);
				view = ScSystemConstant.INDEX_PAGE;

			} else {
				LOGGER.info("Session Expired on Execution of Method getIndexPage() in controller ScUserMgmntController. ");
				session.setAttribute(SystemConstant.STATUS_MESSAGE, loginData.getStatusMessage());
				return new ModelAndView(loginData.getView(), map);
			}
		} catch (Exception e) {
			LOGGER.info(" EXCEPTION OCCURE ON Method getIndexPage() in controller ScUserMgmntController :", e);
			map.addAttribute(SystemConstant.STATUS_MESSAGE, getProperty(SystemConstant.NETWORK_ERROR_MESSAGE));
			view = ScSystemConstant.LOGIN_PAGE;
		}

		return new ModelAndView(view, map);

	}

	@RequestMapping(value = "/userProfileCreationPage", method = RequestMethod.GET)
	public ModelAndView userProfileCreationPage(HttpSession session) {
		SubscriberData subscriberData = new SubscriberData();
		String view = "";
		try {
			LOGGER.info("*******Execution start of method UserProfileCreationPage() in controller ScUserMgmntController  ");
			LoginData loginData = managemetImpl.getSessionInfo(session);
			if (loginData.isSessionInfo()) {
				subscriberData = iUserMgmntService.getProfilesById(loginData.getAccountTypeId());
				SubscriberData allDetails = iUserMgmntService.getAllDetails(subscriberData);
				map.addAttribute(WALLETLISTINFO, allDetails.getWalletList());
				session.setAttribute(ScSystemConstant.SUBSCRIBERID, subscriberData.getSubscriberid());
				map.addAttribute(ScSystemConstant.SUBSCRIBERDATA, subscriberData);
				map.addAttribute(SystemConstant.STATUS_MESSAGE, "");
				map.addAttribute(SystemConstant.ERRORSTATUSMESSAGE, "");
				map.addAttribute(SystemConstant.MENU_ID, "185");
				map.addAttribute(SystemConstant.SUBMENU_ID, "186");
				view = ScSystemConstant.PROFILE_PAGE;

			} else {
				LOGGER.info("Session  Expired on Execution of Method UserProfileCreationPage() in controller ScUserMgmntController ");
				session.setAttribute(SystemConstant.STATUS_MESSAGE, loginData.getStatusMessage());
				return new ModelAndView(loginData.getView(), map);
			}
		} catch (Exception e) {
			LOGGER.info("EXCEPTION OCCUR  IN Method UserProfileCreationPage() in controller ScUserMgmntController :", e);
			map.addAttribute(SystemConstant.STATUS_MESSAGE, getProperty(SystemConstant.NETWORK_ERROR_MESSAGE));
			view = ScSystemConstant.LOGIN_PAGE;
		}

		return new ModelAndView(view, map);
	}

	@RequestMapping(value = "/address", method = RequestMethod.GET)
	public ModelAndView userAddressPage(HttpSession session){
		SubscriberData subscriberData = new SubscriberData();
		String view = "";
		try {
			LOGGER.info("******Execution start of method UserProfileCreationPage() in controller ScUserMgmntController  ");
			LoginData loginData = managemetImpl.getSessionInfo(session);
			
			if (loginData.isSessionInfo()) {
				subscriberData = iUserMgmntService.getProfilesById(loginData.getAccountTypeId());
				SubscriberData allDetails = iUserMgmntService.getAllDetails(subscriberData);
				map.addAttribute(WALLETLISTINFO, allDetails.getWalletList());

				session.setAttribute(ScSystemConstant.SUBSCRIBERID, subscriberData.getSubscriberid());
				String deployedFor =  iUserMgmntService.getTypeOfDeployment();
				map.addAttribute("deployedFor", deployedFor);
				map.addAttribute(ScSystemConstant.SUBSCRIBERDATA, subscriberData);
				map.addAttribute(SystemConstant.STATUS_MESSAGE, "");
				map.addAttribute(SystemConstant.ERRORSTATUSMESSAGE, "");
				map.addAttribute(SystemConstant.MENU_ID, "185");
				map.addAttribute(SystemConstant.SUBMENU_ID, "186");
				view = ScSystemConstant.ADDRESS_PAGE;

			} else {
				LOGGER.info(" **Session  Expired on Execution of Method UserProfileCreationPage() in controller ScUserMgmntController ");
				session.setAttribute(SystemConstant.STATUS_MESSAGE, loginData.getStatusMessage());
				return new ModelAndView(loginData.getView(), map);
			}
		
		}
		catch (Exception e) {
			LOGGER.info("EXCEPTION OCCUR  IN Method UserProfileCreationPage() in controller ScUserMgmntController :", e);
			map.addAttribute(SystemConstant.STATUS_MESSAGE, getProperty(SystemConstant.NETWORK_ERROR_MESSAGE));
			view = ScSystemConstant.LOGIN_PAGE;
		}

		return new ModelAndView(view, map);
	}

	@RequestMapping(value = "/wtwMoneyTransfer", method = RequestMethod.GET)
	public ModelAndView wtwMoneyTransfer(@ModelAttribute(value = "walletRequestData") WalletRequest walletRequestData,
			HttpSession session) {
		String view = "";
		try {
			LOGGER.info("******Execution start of method wtwMoneyTransfer() in controller ScUserMgmntController ");

			LoginData loginData = managemetImpl.getSessionInfo(session);

			if (loginData.isSessionInfo()) {
				session.setAttribute("key", loginData.getKey());
				session.setAttribute(ScSystemConstant.TOKENID, loginData.getTokenId());
				Map walletMap=iUserMgmntService.getWalletList(loginData.getSubscriberMobNo());
				
				map.addAttribute("walletMap", walletMap);
				map.addAttribute("loginMobileNumber", loginData.getSubscriberMobNo());
				
				map.addAttribute(SystemConstant.ERRORSTATUSMESSAGE, "");
				map.addAttribute(SystemConstant.STATUS_MESSAGE, "");
				if(walletMap.size()==0){
					map.addAttribute(SystemConstant.ERRORSTATUSMESSAGE, "No Active Wallet");
				}
				view = "walletToWallet";
				/*map.addAttribute("walletMap", iUserMgmntService.getWalletList(loginData.getSubscriberMobNo()));
				map.addAttribute("loginMobileNumber", loginData.getSubscriberMobNo());
				map.addAttribute(SystemConstant.STATUS_MESSAGE, "");
				map.addAttribute(SystemConstant.ERRORSTATUSMESSAGE, "");*/

				view = "walletToWallet";

			} else {
				LOGGER.info("****Session Expired on Execution of Method wtwMoneyTransfer() in controller ScUserMgmntController ");
				session.setAttribute(SystemConstant.STATUS_MESSAGE, loginData.getStatusMessage());
				return new ModelAndView(loginData.getView(), map);
			}
		} catch (Exception e) {
			LOGGER.info("EXCEPTION OCCURE ON Method wtwMoneyTransfer() in controller ScUserMgmntController :", e);
			map.addAttribute(SystemConstant.STATUS_MESSAGE, getProperty(SystemConstant.NETWORK_ERROR_MESSAGE));
			view = ScSystemConstant.LOGIN_PAGE;
		}

		return new ModelAndView(view, map);
	}

	@RequestMapping(value = "/wtwMoneyTransfer", method = RequestMethod.POST)
	public ModelAndView getWtwMoneyTransfer(
			@ModelAttribute(value = "walletRequestData") WalletRequest walletRequestData, HttpSession session
			) {
		String view = "";
		try {
			LOGGER.info("*****Execution start of method wtwMoneyTransfer() in controller ScUserMgmntController ");

			LoginData loginData = managemetImpl.getSessionInfo(session);
			if (loginData.isSessionInfo()) {

				session.setAttribute("key", loginData.getKey());
				session.setAttribute(ScSystemConstant.TOKENID, loginData.getTokenId());

				WalletRequest walletRequestDatanew = iUserMgmntService.walletToWalletView(walletRequestData, session,null);

				map.addAttribute("walletMap", iUserMgmntService.getWalletList(loginData.getSubscriberMobNo()));
				SubscriberData walletDetails = iUserMgmntService.getWalletDetailList(loginData, session);
				map.addAttribute(WALLETDETAILS, walletDetails);

				if ("Request Processed Successfully.".equals(walletRequestDatanew.getMessage())) {
					map.addAttribute(SystemConstant.STATUS_MESSAGE, "Money Transferred Successfully");
					map.remove(SystemConstant.ERRORSTATUSMESSAGE);
				}

				else {
					map.addAttribute(SystemConstant.ERRORSTATUSMESSAGE, walletRequestDatanew.getMessage());
					map.remove(SystemConstant.STATUS_MESSAGE);
				}

				view = "walletToWallet";
			} else {
				LOGGER.info("Session Expired on Execution of Method wtwMoneyTransfer() in controller ScUserMgmntController ");
				session.setAttribute(SystemConstant.STATUS_MESSAGE, loginData.getStatusMessage());
				return new ModelAndView(loginData.getView(), map);
			}
		} catch (Exception e) {
			LOGGER.info("EXCEPTION OCCURE ON Method wtwMoneyTransfer() in controller ScUserMgmntController :", e);
			map.addAttribute(SystemConstant.STATUS_MESSAGE, getProperty(SystemConstant.NETWORK_ERROR_MESSAGE));
			view = ScSystemConstant.LOGIN_PAGE;
		}

		return new ModelAndView(view, map);
	}
	
	@ResponseBody
	@RequestMapping(value = "ajax/sendOtpforWallet", method = RequestMethod.POST)
	public String  getsendOtpforWallet(
			@ModelAttribute(value = "walletRequestData") WalletRequest walletRequestData, HttpSession session,
			@RequestParam(value="userMobile")String userMobile,@RequestParam(value="senderMobile")String senderMobile,HttpServletRequest req,
			@RequestParam(value="walletId",required=false)String walletId) {
		String view = "";
		boolean result=false;
		boolean resultWallet=false;
		try {
			LOGGER.info("*****Execution start of method wtwMoneyTransfer() in controller ScUserMgmntController ");

			LoginData loginData = managemetImpl.getSessionInfo(session);
			if (loginData.isSessionInfo()) {
				
				if(!StringUtils.isEmpty(walletId))
				{
					resultWallet=iUserMgmntService.checkWallet(userMobile,walletId);
					if(resultWallet==false)
					{
						return "Wallet Doesn't Exists For : "+userMobile;
					}
				}
				result=iUserMgmntService.sendOtpforWallet(loginData,senderMobile);
				
				} else {
				LOGGER.info("Session Expired on Execution of Method wtwMoneyTransfer() in controller ScUserMgmntController ");
				session.setAttribute(SystemConstant.STATUS_MESSAGE, loginData.getStatusMessage());
			//	return new ModelAndView(loginData.getView(), map);
			}
		} catch (Exception e) {
			LOGGER.info("EXCEPTION OCCURE ON public boolean getsendOtpforWallet( in controller ScUserMgmntController :", e);
		}

		return result+"";
	}
	
	@ResponseBody
	@RequestMapping(value = "ajax/validateWalletOtp", method = RequestMethod.POST)
	public boolean validateWalletOtp(
			@ModelAttribute(value = "walletRequestData") WalletRequest walletRequestData, HttpSession session,
			@RequestParam(value="userMobile")String userMobile,	@RequestParam(value="ConfirmOtp")String ConfirmOtp) {
		String view = "";
		boolean result=false;
		try {
			LOGGER.info("*****Execution start of method wtwMoneyTransfer() in controller ScUserMgmntController ");

			LoginData loginData = managemetImpl.getSessionInfo(session);
			if (loginData.isSessionInfo()) {

				result=iUserMgmntService.validateOtpPassword(loginData,ConfirmOtp,userMobile);
				
				} else {
				LOGGER.info("Session Expired on Execution of Method wtwMoneyTransfer() in controller ScUserMgmntController ");
				session.setAttribute(SystemConstant.STATUS_MESSAGE, loginData.getStatusMessage());
			//	return new ModelAndView(loginData.getView(), map);
			}
		} catch (Exception e) {
			LOGGER.info("EXCEPTION OCCURE ON Method wtwMoneyTransfer() in controller ScUserMgmntController :", e);
			map.addAttribute(SystemConstant.STATUS_MESSAGE, getProperty(SystemConstant.NETWORK_ERROR_MESSAGE));
			view = ScSystemConstant.LOGIN_PAGE;
		}

		return result;
	}
	@RequestMapping(value = "/mytransaction", method = RequestMethod.GET)
	public ModelAndView mytransaction(
			@ModelAttribute(value = "transactionRequestData") TransactionRequestData transactionRequestData,
			HttpSession session) {
		String view = "";

		try {
			LOGGER.info("*Execution start of method mytransaction() in controller ScUserMgmntController ");

			LoginData loginData = managemetImpl.getSessionInfo(session);
			if (loginData.isSessionInfo()) {
				session.setAttribute(ScSystemConstant.LOGINID, loginData.getUserLoginId());
				session.setAttribute("key", loginData.getKey());
				session.setAttribute(ScSystemConstant.TOKENID, loginData.getTokenId());

				iUserMgmntService.transactionView(transactionRequestData, session);
				SubscriberData walletDetails = iUserMgmntService.getWalletDetailList(loginData, session);
				map.addAttribute(WALLETDETAILS, walletDetails);
				map.addAttribute(SystemConstant.STATUS_MESSAGE, "");
				map.addAttribute(SystemConstant.ERRORSTATUSMESSAGE, "");

				view = "transaction";
			} else {
				LOGGER.info("Session Expired on Execution of Method mytransaction() in controller ScUserMgmntController ");
				session.setAttribute(SystemConstant.STATUS_MESSAGE, loginData.getStatusMessage());
				return new ModelAndView(loginData.getView(), map);
			}
		} catch (Exception e) {
			LOGGER.info("EXCEPTION OCCURE ON Method mytransaction() in controller ScUserMgmntController :", e);
			map.addAttribute(SystemConstant.STATUS_MESSAGE, getProperty(SystemConstant.NETWORK_ERROR_MESSAGE));
			view = ScSystemConstant.LOGIN_PAGE;
		}

		return new ModelAndView(view, map);
	}
	
	@RequestMapping(value = "/mytransaction", method = RequestMethod.POST)
	public ModelAndView getmytransaction(
			@ModelAttribute(value = "transactionRequestData") TransactionRequestData transactionRequestData,
			HttpSession session) {
		String view = "";

		try {
			LOGGER.info("*************Execution start of method getmytransaction() in controller ScUserMgmntController ");

			LoginData loginData = managemetImpl.getSessionInfo(session);
			if (loginData.isSessionInfo()) {

				session.setAttribute(ScSystemConstant.LOGINID, loginData.getUserLoginId());
				session.setAttribute("key", loginData.getKey());
				session.setAttribute(ScSystemConstant.TOKENID, loginData.getTokenId());

				iUserMgmntService.transactionView(transactionRequestData, session);

				map.addAttribute(SystemConstant.STATUS_MESSAGE, "");
				map.addAttribute(SystemConstant.ERRORSTATUSMESSAGE, "");

				view = "transaction";

			} else {
				LOGGER.info("Session Expired on Execution of Method mytransaction() in controller ScUserMgmntController... ");
				session.setAttribute(SystemConstant.STATUS_MESSAGE, loginData.getStatusMessage());
				return new ModelAndView(loginData.getView(), map);
			}
		} catch (Exception e) {
			LOGGER.info("EXCEPTION OCCURE ON Method mytransaction() in controller ScUserMgmntController :", e);
			map.addAttribute(SystemConstant.STATUS_MESSAGE, getProperty(SystemConstant.NETWORK_ERROR_MESSAGE));
			view = ScSystemConstant.LOGIN_PAGE;
		}

		return new ModelAndView(view, map);
	}
	

	@RequestMapping(value = "/myquery", method = RequestMethod.GET)
	public ModelAndView myquery(HttpSession session) {
		SubscriberData subscriberData = new SubscriberData();
		String view = "";
		try {
			LOGGER.info("**************Execution start of method myquery() in controller ScUserMgmntController ");

			LoginData loginData = managemetImpl.getSessionInfo(session);
			if (loginData.isSessionInfo()) {
				subscriberData = iUserMgmntService.getProfilesById(loginData.getAccountTypeId());
				subscriberData = iUserMgmntService.getproductList(subscriberData);
				subscriberData = iUserMgmntService.getproducttype(subscriberData);
				Map<Integer,String> productType=iUserMgmntService.getproducttype(loginData.getSubscriberMobNo()) ;
				map.addAttribute("productTypes",productType);
				map.addAttribute(ScSystemConstant.SUBSCRIBERDATA, subscriberData);
			//	map.addAttribute(SystemConstant.STATUS_MESSAGE, "");
				map.addAttribute(SystemConstant.ERRORSTATUSMESSAGE, "");
				
				List<SubscriberData> queryList = iUserMgmntService.queryStatus(session, loginData.getSubscriberMobNo());
				map.addAttribute("queryList", queryList);
				
				

				view = "MyQuery";

			} else {
				LOGGER.info("Session Expired on Execution of Method myquery() in controller ScUserMgmntController..... ");
				session.setAttribute(SystemConstant.STATUS_MESSAGE, loginData.getStatusMessage());
				return new ModelAndView(loginData.getView(), map);
			}
		} catch (Exception e) {
			LOGGER.info("EXCEPTION OCCUR ON Method myquery() in controller ScUserMgmntController :", e);
			map.addAttribute(SystemConstant.STATUS_MESSAGE, getProperty(SystemConstant.NETWORK_ERROR_MESSAGE));
			view = ScSystemConstant.LOGIN_PAGE;
		}

		return new ModelAndView(view, map);
	}
	
	

	@RequestMapping(value = "/myquery", method = RequestMethod.POST)
	public ModelAndView savemyquery(@ModelAttribute(value = "subscriberData") SubscriberData subscriberData,RedirectAttributes redirectAttribute,
			HttpSession session, HttpServletRequest request) {

		String view = "";
		String[] sms = null;
		try {
			LOGGER.info("*******Execution start of method myquery() in controller ScUserMgmntController ");

			LoginData loginData = managemetImpl.getSessionInfo(session);
			if (loginData.isSessionInfo()) {

				Integer ticketId = iUserMgmntService.saveMyQuery(subscriberData, loginData.getSubscriberMobNo());

				SubscriberData subscriberDataNew = iUserMgmntService.getProfilesById(loginData.getAccountTypeId());

				SubscriberData subscriberDta = iUserMgmntService.getproducttype(subscriberDataNew);
				if (subscriberData.getCheckBox() != null) {
					sms = subscriberData.getCheckBox().split(",");
				}
				sendMail(sms, subscriberDta, ticketId, "self", subscriberData.getCheckedLinks());
				map.addAttribute(ScSystemConstant.SUBSCRIBERDATA, subscriberDta);
				//map.addAttribute(SystemConstant.STATUS_MESSAGE, "Request Processed Successfully");
				redirectAttribute.addFlashAttribute("statusMsg", "Query Raised Successfully");
				map.addAttribute(SystemConstant.ERRORSTATUSMESSAGE, "");

				view = "MyQuery";

			} else {
				LOGGER.info("Session Expired on Execution of Method myquery() in controller ScUserMgmntController....... ");
				session.setAttribute(SystemConstant.STATUS_MESSAGE, loginData.getStatusMessage());
				return new ModelAndView(loginData.getView(), map);
			}
		} catch (Exception e) {
			LOGGER.info("EXCEPTION OCCURE ON Method myquery() in controller ScUserMgmntController :", e);
			map.addAttribute(SystemConstant.STATUS_MESSAGE, getProperty(SystemConstant.NETWORK_ERROR_MESSAGE));
			view = ScSystemConstant.LOGIN_PAGE;
		}
		return new ModelAndView("redirect:myquery");
	}
	
	
	@RequestMapping(value = "/getPUK", method = RequestMethod.GET)
	public ModelAndView getqueryPUK(@RequestParam(value = "productId") String productId,
			 HttpSession session) {
		String message="";
		try {
			LOGGER.info("*******Execution start of method myquery() in controller ScUserMgmntController ");

			LoginData loginData = managemetImpl.getSessionInfo(session);
			if (loginData.isSessionInfo()) {
				
				message=iUserMgmntService.getqueryPUK(productId,loginData);
			} 
			if(StringUtils.isEmpty(message)){
				message="Try Again";
			}
		} catch (Exception e) {
			LOGGER.info("EXCEPTION OCCURE ON Method myquery() in controller ScUserMgmntController :", e);
		}
		map.addAttribute("message",message) ;
		return new ModelAndView("redirect:productsInfo?status="+message);
	}

	public void sendMail(String[] sms, SubscriberData careData1, Integer result, String type, String[] attachment) {
		if (sms != null) {
			if (sms.length > 1) {
				mailSender.sendSMS(careData1.getMobilenumber(), attachment);
				mailSender.sendMail(type, careData1.getName(), careData1.getEmailId(), result.toString(), attachment);
			} else {
				if (("SMS").equals(careData1.getCheckBox())) {
					mailSender.sendSMS(careData1.getMobilenumber(), attachment);
				} else {
					mailSender.sendMail(type, careData1.getName(), careData1.getEmailId(), result.toString(),
							attachment);
				}
			}
		} else if (careData1.getEmailId() != null) {
			mailSender.sendMail(type, careData1.getName(), careData1.getEmailId(), result.toString(), attachment);
		}

	}

	@RequestMapping(value = "/getProfilePersonalInfo", method = RequestMethod.GET)
	public ModelAndView userProfileCreationPage1(HttpSession session) {
		SubscriberData subscriberData = new SubscriberData();
		String view = "";
		try {
			LOGGER.info("**********Execution start of method UserProfileCreationPage() in controller ScUserMgmntController.. ");
			LoginData loginData = managemetImpl.getSessionInfo(session);
			if (loginData.isSessionInfo()) {
				subscriberData = iUserMgmntService.getProfilesById(loginData.getUserLoginId());
				map.addAttribute(ScSystemConstant.SUBSCRIBERDATA, subscriberData);
				map.addAttribute(SystemConstant.STATUS_MESSAGE, "Personal Info is successfully updated");
				map.addAttribute(SystemConstant.ERRORSTATUSMESSAGE, subscriberData.getErrorMsg());
				map.addAttribute(SystemConstant.MENU_ID, "185");
				map.addAttribute(SystemConstant.SUBMENU_ID, "186");
				view = ScSystemConstant.PROFILE_PAGE;

			} else {
				LOGGER.info("*****************Session Expired on Execution of Method UserProfileCreationPage() in controller ScUserMgmntController ");
				session.setAttribute(SystemConstant.STATUS_MESSAGE, loginData.getStatusMessage());
				return new ModelAndView(loginData.getView(), map);
			}
		} catch (Exception e) {
			LOGGER.info("EXCEPTION OCCURE ON Method UserProfileCreationPage() in controller ScUserMgmntController :", e);
			map.addAttribute(SystemConstant.STATUS_MESSAGE, getProperty(SystemConstant.NETWORK_ERROR_MESSAGE));
			view = ScSystemConstant.LOGIN_PAGE;
		}

		return new ModelAndView(view, map);
	}
	

	
	@RequestMapping(value = "/productsInfo", method = RequestMethod.GET)
	public ModelAndView productsInfo(HttpSession session,@RequestParam(value="status",required = false)String status) {
		String view = ScSystemConstant.PRODUCT_PAGE;
		LoginData loginData;
		try {
			loginData = managemetImpl.getSessionInfo(session);
	
		if (loginData.isSessionInfo()) {
			SubscriberData subscriberData = iUserMgmntService.getProfilesById(loginData.getAccountTypeId());
			SubscriberData allDetails = iUserMgmntService.getProductDetails(subscriberData);
			map.addAttribute("productList", allDetails.getProductList());
			map.addAttribute("message", status);
		}
		} 
		catch (Exception e) {
		
			e.printStackTrace();
		}
		
		return new ModelAndView(view, map);
	}
	
	
	@RequestMapping(value = "/productsInfoAjax", method = RequestMethod.POST)
	@ResponseBody
	public String productsInfoAjax(HttpSession session,
			@RequestParam(value="productId")String productId,@RequestParam(value="comment")String comment){
		String view = ScSystemConstant.PRODUCT_PAGE;
		LoginData loginData;
		try {
			loginData = managemetImpl.getSessionInfo(session);
	
		if (loginData.isSessionInfo()) {
			boolean result=iUserMgmntService.productsInfo( productId,loginData.getUsername(),comment);
			if(result)
			{
				return "BLOCK_BY_CUST";
			}
		}
		} 
		catch (Exception e) {
			
			e.printStackTrace();
		}
		
		return "";
	}	
	
	
	
	
	
	
	
	
	
	

	@RequestMapping(value = "/userProfileCreationPage", method = RequestMethod.POST)
	public ModelAndView userProfilePersonalInfo(HttpSession session,
			@ModelAttribute("subscriberData") SubscriberData subscriberData) {
		String view = "";
		try {
			LOGGER.info("**********Execution start of method UserProfilePersonalInfo() in controller ScUserMgmntController. ");
			LoginData loginData = managemetImpl.getSessionInfo(session);

			Integer subscriberid = (Integer) session.getAttribute(ScSystemConstant.SUBSCRIBERID);
			if (loginData.isSessionInfo()) {
				SubscriberData subscriberDatainfo = iUserMgmntService.submitSubscriberPersonalInfo(subscriberData,
						subscriberid);
				map.addAttribute(ScSystemConstant.SUBSCRIBERDATA, subscriberDatainfo);
				map.addAttribute(SystemConstant.STATUS_MESSAGE, "Personal info has been updated Successfully");
				map.addAttribute(SystemConstant.ERRORSTATUSMESSAGE, subscriberDatainfo.getErrorMsg());
				map.addAttribute(SystemConstant.MENU_ID, "185");
				map.addAttribute(SystemConstant.SUBMENU_ID, "186");
				view = ScSystemConstant.PROFILE_PAGE;

			} else {
				LOGGER.info("Session Expired on Execution of Method UserProfileCreationPage() in controller ScUserMgmntController** ");
				session.setAttribute(SystemConstant.STATUS_MESSAGE, loginData.getStatusMessage());
				return new ModelAndView(loginData.getView(), map);
			}
		} catch (Exception e) {
			LOGGER.info("EXCEPTION OCCURE ON Method UserProfileCreationPage() in controller ScUserMgmntController :", e);
			map.addAttribute(SystemConstant.STATUS_MESSAGE, getProperty(SystemConstant.NETWORK_ERROR_MESSAGE));
			view = ScSystemConstant.LOGIN_PAGE;
		}
		return new ModelAndView(view, map);
	}

	@RequestMapping(value = "/address", method = RequestMethod.POST)
	public ModelAndView userProfileAddress(HttpSession session,@RequestParam(value="pinCodeFlag",required=false)Integer pinCodeFlag,
			@ModelAttribute("subscriberData") SubscriberData subscriberData){
		LoginData loginData = new LoginData();
		try {
			LOGGER.info("Execution start of method UserProfileAddress() in controller ScUserMgmntController "
					+ subscriberData.getUserName() + subscriberData.getLastName());
			loginData = managemetImpl.getSessionInfo(session);
           if(pinCodeFlag==null){
				
			}
			else if(pinCodeFlag==1){
				iUserMgmntService.saveNewPinCode(subscriberData);
			}
			if (loginData.isSessionInfo()) {
				SubscriberData subscriberDatainfo = iUserMgmntService.submitUserProfileAddress(subscriberData,
						loginData.getAccountTypeId());

				map.addAttribute(ScSystemConstant.SUBSCRIBERDATA, subscriberDatainfo);
				map.addAttribute(SystemConstant.STATUS_MESSAGE, " Address has been updated successfully");
				map.addAttribute(SystemConstant.ERRORSTATUSMESSAGE, subscriberDatainfo.getErrorMsg());
				map.addAttribute(SystemConstant.MENU_ID, "185");
				map.addAttribute(SystemConstant.SUBMENU_ID, "186");
				loginData.setView(ScSystemConstant.ADDRESS_PAGE);
			} else {
				LOGGER.info("Session Expired on Execution of Method UserProfileAddress() in controller ScUserMgmntController ");
				session.setAttribute(SystemConstant.STATUS_MESSAGE, loginData.getStatusMessage());
				loginData.setView(ScSystemConstant.LOGIN_PAGE);
			}
		} catch (Exception e) {
			LOGGER.info("EXCEPTION OCCURE ON Method UserProfileAddress() in controller ScUserMgmntController :", e);
			map.addAttribute(SystemConstant.STATUS_MESSAGE, getProperty(SystemConstant.NETWORK_ERROR_MESSAGE));
			loginData.setView(ScSystemConstant.LOGIN_PAGE);
		}

		return new ModelAndView(loginData.getView(), map);
	}

	@RequestMapping(value = "/userProfileChangePasswordPage", method = RequestMethod.POST)
	public ModelAndView setChangePassword(@ModelAttribute("subscriberData") SubscriberData subscriberData,
			HttpSession session) {
		String view = "";
		try {

			LOGGER.info(" start of setChangePassword() method in ScUserMgmntController");
			LoginData loginData = managemetImpl.getSessionInfo(session);
			Integer subscriberid = (Integer) session.getAttribute(ScSystemConstant.SUBSCRIBERID);
			if (loginData.isSessionInfo()) {
				SubscriberData subscriberData1 = new SubscriberData();
				iUserMgmntService.checkAndChangePassword(subscriberData, subscriberid, session);
				view = ScSystemConstant.LOGIN_PAGE;

				String s = subscriberData.getMessage();
				if ("Request Processed Successfully.".equals(s)) {
					map.addAttribute(SystemConstant.STATUS_MESSAGE, "Password Changed Successfully");
				} else {

					map.addAttribute(SystemConstant.STATUS_MESSAGE, subscriberData.getMessage());
				}
				session.invalidate();
				map.addAttribute(ScSystemConstant.SUBSCRIBERDATA, subscriberData);
				map.addAttribute("loginData", new LoginData());

				map.addAttribute(SystemConstant.MENU_ID, 185);
				map.addAttribute(SystemConstant.SUBMENU_ID, 188);
				map.addAttribute(ScSystemConstant.SUBSCRIBERDATA, subscriberData1);
			} else {
				LOGGER.info("Session Expire On execution of Method setForgetPassword() in ScUserMgmntController");
				view = ScSystemConstant.LOGIN_PAGE;
				map.addAttribute(SystemConstant.STATUS_MESSAGE, getProperty(SystemConstant.SESSION_NOT_VALID));
			}
		} catch (Exception ex) {
			LOGGER.info("Exception occured in setChangePassword() method in ScUserMgmntController --->" + ex);
			map.addAttribute(SystemConstant.STATUS_MESSAGE, getProperty(SystemConstant.NETWORK_ERROR_MESSAGE));
			view = ScSystemConstant.HOMEPAGE;
		}
		LOGGER.info("**** end of setChangePassword() method in ScUserMgmntController ****");
		return new ModelAndView(view, map);
	}
	
	@RequestMapping(value="/forgetWalletPin", method=RequestMethod.GET)
	public ModelAndView forgetWalletPin(HttpSession session) {
		
		String view = null;
		try {
			LOGGER.info("**** start of forgetWalletPIN() method in UserMgmntController ****");
			LoginData loginData = managemetImpl.getSessionInfo(session);
			if (loginData.isSessionInfo()) {
				UserAccountData userAccountData = new UserAccountData();
				SubscriberData subscriberData = iUserMgmntService.getProfilesById(loginData.getAccountTypeId());
				SubscriberData allDetails = iUserMgmntService.getAllDetails(subscriberData);
				map.addAttribute(WALLETLISTINFO, allDetails.getWalletList());
				view = "forgetWalletPin";
				map.addAttribute("successMessage", "");
				map.addAttribute("errorMessage", "");
				map.addAttribute(SystemConstant.STATUS_MESSAGE, "");
				map.addAttribute(SystemConstant.MENU_ID, 185);
				map.addAttribute(SystemConstant.SUBMENU_ID, 188);
				map.addAttribute("userAccountData", userAccountData);
			} else {
				LOGGER.info("Session Expire On execution of Method setforgetWalletPIN in UserMgmntController");
				view = ScSystemConstant.LOGIN_PAGE;
				map.addAttribute(SystemConstant.STATUS_MESSAGE, getProperty(SystemConstant.SESSION_NOT_VALID));
			}
		} catch (Exception ex) {
			LOGGER.info("Exception occured in forgetWalletPIN() method in UserMgmntController --->" + ex);
			map.addAttribute(SystemConstant.STATUS_MESSAGE, getProperty(SystemConstant.NETWORK_ERROR_MESSAGE));
			view = ScSystemConstant.HOMEPAGE;
		}
		return new ModelAndView(view, map);
	}
	
	
	@RequestMapping(value = "/userProfileChangeWalletPin", method = RequestMethod.POST)
	public ModelAndView setChangeWalletPin(@ModelAttribute("subscriberData") SubscriberData subscriberData,
			HttpSession session) {
		String view = "";
		try {

			LOGGER.info(" start of setChangeWalletPin() method in ScUserMgmntController");
			LoginData loginData = managemetImpl.getSessionInfo(session);
			Integer subscriberid = (Integer) session.getAttribute(ScSystemConstant.SUBSCRIBERID);
			if (loginData.isSessionInfo()) {
				
				map.addAttribute(SystemConstant.ERRORSTATUSMESSAGE, "");
				map.addAttribute(SystemConstant.STATUS_MESSAGE, "");
				
				
				iUserMgmntService.checkAndChangeWalletPin(subscriberData, subscriberid, session);
				view = "changeWalletPin";

				String msg = subscriberData.getMessage();
				
				
				
				if(msg != null && msg.startsWith("SUC"))
					map.addAttribute(SystemConstant.STATUS_MESSAGE, msg.substring(4));
				else if(msg != null && msg.startsWith("FAL"))
					map.addAttribute(SystemConstant.ERRORSTATUSMESSAGE, msg.substring(4));
				
				map.addAttribute(ScSystemConstant.SUBSCRIBERDATA, new SubscriberData());
				
			} else {
				LOGGER.info("Session Expire On execution of Method setChangeWalletPin() in ScUserMgmntController");
				view = ScSystemConstant.LOGIN_PAGE;
				map.addAttribute(SystemConstant.STATUS_MESSAGE, getProperty(SystemConstant.SESSION_NOT_VALID));
			}
		} catch (Exception ex) {
			LOGGER.info("Exception occured in setChangeWalletPin() method in ScUserMgmntController --->" + ex);
			map.addAttribute(SystemConstant.STATUS_MESSAGE, getProperty(SystemConstant.NETWORK_ERROR_MESSAGE));
			view = ScSystemConstant.PROFILE_PAGE;
		}
		LOGGER.info("**** end of setChangeWalletPin() method in ScUserMgmntController ****");
		return new ModelAndView(view, map);
	}

	
	@RequestMapping(value = "ajax/verifyAndUpdateWalletPin", method = RequestMethod.POST)
	@ResponseBody
	public SubscriberData verifyAndUpdateWalletPin(@RequestBody SubscriberData subscriberData ,
			 HttpSession session) {
	
		SubscriberData message =null;
		try {
			LOGGER.info("Execution start of verifyAndUpdateWalletPin() method in ScUserMgmntController");
			Integer subscriberid = (Integer) session.getAttribute(ScSystemConstant.SUBSCRIBERID);
			if(subscriberData.getOtpOnForgotPass()!=null) {
				message=	iUserMgmntService.ChangeWalletPin(subscriberData, subscriberid);
			}
			
		} catch (Exception ex) {
			LOGGER.debug("Exception caught in getOtpOnForgotPass() method of ScUserMgmntController" + ex);
			
		}
		LOGGER.info("Execution end of getOtpOnForgotPass() method in ScUserMgmntController");

		return message;
	}
	
	
	@RequestMapping(value = "ajax/verifyAndUpdatePassword", method = RequestMethod.POST)
	@ResponseBody
	public SubscriberData verifyAndUpdatePassword(@RequestBody SubscriberData subscriberData ,
			 HttpSession session) {
		SubscriberData message =null;
		try {
			LOGGER.info("Execution start of verifyAndUpdateWalletPin() method in ScUserMgmntController");
			Integer subscriberid = (Integer) session.getAttribute(ScSystemConstant.SUBSCRIBERID);
			if(subscriberData.getOtpOnForgotPass()!=null) {
				message=	iUserMgmntService.forgetedPassword(subscriberData);
			}
			
		} catch (Exception ex) {
			LOGGER.debug("Exception caught in getOtpOnForgotPass() method of ScUserMgmntController" + ex);
			
		}
		LOGGER.info("Execution end of getOtpOnForgotPass() method in ScUserMgmntController");

		return message;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	@RequestMapping(value = "getOtpOnForgotPass", method = RequestMethod.POST)
	@ResponseBody
	public String getOtpOnForgotPass(@RequestParam(value = "mobile") String mobile,
			@RequestParam(value = "dateOfBirth") String dateOfBirth, HttpSession session) {
		Integer otp = 0;
		String[] splitOtp;
		String result = "";
		String abc;
		SubscriberData message = new SubscriberData();
		try {
			LOGGER.info("Execution start of getOtpOnForgotPass() method in ScUserMgmntController");
			message = iUserMgmntService.getOtpOnForgotPass(mobile, dateOfBirth);
			
			if (message.getRequestStatus() == 200) 
			{
				result = "Enter One Time Password(OTP) sent to your mobile number *******" + mobile.substring(9) + ".";
				
			} else {
					result = message.getMessage();
			}

		} catch (Exception ex) {
			LOGGER.debug("Exception caught in getOtpOnForgotPass() method of ScUserMgmntController" + ex);
			result = "Invalid Credentials";
		}
		LOGGER.info("Execution end of getOtpOnForgotPass() method in ScUserMgmntController");

		return result;
	}

	@RequestMapping(value = "resendOtpOnForgotPass", method = RequestMethod.GET)
	@ResponseBody
	public String resendOtpOnForgotPass(@RequestParam(value = "mobile") String mobile,
			@RequestParam(value = "dateOfBirth") String dateOfBirth, HttpSession session) {
		String result = "";

		try {
			LOGGER.info("Execution start of getOtpOnForgotPass() method in ScUserMgmntController");
			iUserMgmntService.getOtpOnForgotPass(mobile, dateOfBirth);
			result = "Enter One Time Password(OTP) resent to your mobile number *******" + mobile.substring(3) + ".";
			//iUserMgmntService.validateOtp(mobile, dateOfBirth, otp);
		} catch (Exception ex) {
			LOGGER.debug("Exception caught in getOtpOnForgotPass() method of ScUserMgmntController" + ex);
			result = "Invalid Mobile Number";
		}
		LOGGER.info("Execution end of getOtpOnForgotPass() method in ScUserMgmntController");
		return result;
	}

	@RequestMapping(value = "/forgetPassword", method = RequestMethod.GET)
	public ModelAndView getForgetPassword(@ModelAttribute("subscriberData") SubscriberData subscriberData,
			@RequestParam(value = "username", required = false) String username, HttpServletRequest request,
			HttpSession session) {
		try {
			LOGGER.info("**** start of getForgetPassword() method ****");
			String s = request.getParameter("username");
			map.addAttribute("username", s);
			map.addAttribute(ScSystemConstant.SUBSCRIBERDATA, subscriberData);
			map.addAttribute(SystemConstant.STATUS_MESSAGE, "");
			map.addAttribute(SystemConstant.ERRORSTATUSMESSAGE, "");
		} catch (Exception ex) {
			LOGGER.info("Exception occured in getForgetPassword() method in ScUserMgmntController --->" + ex);
		}
		return new ModelAndView("UserForgetPassword", map);
	}

	@RequestMapping(value = "/forgetPassword", method = RequestMethod.POST)
	public ModelAndView setForgetPassword(@ModelAttribute("subscriberData") SubscriberData subscriberData,
			@RequestParam("mobile") String mobile, @RequestParam("newPassword") String newPassword,
			@RequestParam("otpOnForgotPass") String otpOnForgotPass, HttpSession session) {
		LoginData loginData = new LoginData();

		try {
			LOGGER.info("**** start of getForgetPassword() method ****");

			SubscriberData subscriberDatainfo = iUserMgmntService.setForgetedPassword(subscriberData);
			map.addAttribute(ScSystemConstant.SUBSCRIBERDATA, subscriberDatainfo);
			map.addAttribute(SystemConstant.STATUS_MESSAGE, subscriberDatainfo.getMessage());
			session.setAttribute(SystemConstant.STATUS_MESSAGE, subscriberDatainfo.getMessage());

			map.addAttribute("logindata", loginData);

			map.addAttribute(SystemConstant.ERRORSTATUSMESSAGE, "");

			loginData.setView("transferToLoginPage");

		} catch (Exception ex) {
			LOGGER.info("Exception occured in setForgetPassword() method in ScUserMgmntController --->" + ex);
			loginData.setView("UserForgetPassword");
		}
		return new ModelAndView(loginData.getView(), map);
	}
	
	
	//========================================
	
	@RequestMapping(value = "/forgetPassword1", method = RequestMethod.POST)
	@ResponseBody public int setForgetPassword1(
			@RequestParam("mobile") String mobile, @RequestParam("newPassword") String newPassword,
			@RequestParam("otpOnForgotPass") String otpOnForgotPass, HttpSession session) {
		LoginData loginData = new LoginData();
		SubscriberData subscriberData=new SubscriberData();
		String result="";
		int flag=0;
		try {
			LOGGER.info("**** start of getForgetPassword() method ****");
			subscriberData.setMobile(mobile);  
			subscriberData.setOtpOnForgotPass(otpOnForgotPass);
			subscriberData.setNewPassword(newPassword);
			SubscriberData subscriberDatainfo = iUserMgmntService.setForgetedPassword(subscriberData);
		
			result= subscriberDatainfo.getMessage();
			if(subscriberDatainfo.getCode().intValue() == ErrorCodes.OTP_INVALID.getCode().intValue())
			{
				flag= 1;
			}
			else
			{
				flag= 0;
			}
			subscriberData.setDateOfBirth(null);

		} catch (Exception ex) {
			LOGGER.info("Exception occured in setForgetPassword() method in ScUserMgmntController --->" + ex);
			
		}
		return flag;
	}
	

	@RequestMapping(value = "fetchAddress", method = RequestMethod.POST)
	@ResponseBody
	public List<AddressInfo> fetchAddress(@RequestParam(value = "pinCode") String pinCode, HttpSession session) {
		List<AddressInfo> addressInfos = null;
		try {
			addressInfos = iUserMgmntService.fetchAddress(pinCode);
		} catch (Exception ex) {
			LOGGER.debug("Exception caught in fetchAddress() method of ScUserMgmntController" + ex);
		}
		return addressInfos;
	}

	/* Old Method Start */
	@RequestMapping(value = "/resetPassword", method = RequestMethod.GET)
	public ModelAndView getResetPasswordPage(Model model, HttpSession session) throws Exception {
		ModelMap map1 = new ModelMap();
		String view = "";
		try {
			LOGGER.info("******Start Method getResetPasswordPage() in UserMgmntController .");
			LoginData loginData = managemetImpl.getSessionInfo(session);
			if (loginData.isSessionInfo()) {
				map1.addAttribute(SystemConstant.MENU_ID, "185");
				map1.addAttribute(SystemConstant.SUBMENU_ID, "189");
				map1.addAttribute("resetPasswordData", new UserAccountData());
				view = "resetPassword";
			} else {
				LOGGER.debug("Session Expired On Execution OF Method getResetPasswordPage() in UserMgmntController .");
				session.setAttribute(SystemConstant.STATUS_MESSAGE, loginData.getStatusMessage());
				return new ModelAndView(loginData.getView(), map1);
			}
		} catch (Exception e) {
			LOGGER.info("" + e);
			map.addAttribute(SystemConstant.STATUS_MESSAGE, getProperty(SystemConstant.NETWORK_ERROR_MESSAGE));
			view = ScSystemConstant.HOMEPAGE;
		}
		return new ModelAndView(view, map1);
	}

	/**
	 * @param userLoginCreationData
	 * @param session
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/getSelectedUserAccount")
	@ResponseBody
	public String getSelectedUserAccount(
			@ModelAttribute(value = "userLoginCreationData") UserAccountData userLoginCreationData,
			@RequestParam("accountType") String accountType, HttpSession session, HttpServletRequest request) {
		LOGGER.info("******Start Execution of method  getSelectedUserAccount() in UserMgmntController ");
		String msg = ",";
		try {
			LoginData loginData = managemetImpl.getSessionInfo(session);
			if (loginData.isSessionInfo()) {
				if (accountType.indexOf(SystemConstant.ACCT_GRP_CODE_HO) > -1) {
					msg = "1," + loginData.getGroupCode();
				} else if (accountType.indexOf(SystemConstant.ACCT_GRP_CODE_DI) > -1) {
					msg = "2," + loginData.getGroupCode();
				} else if (accountType.indexOf(SystemConstant.ACCT_GRP_CODE_SD) > -1) {
					msg = "3," + loginData.getGroupCode();
				} else if (accountType.indexOf(SystemConstant.ACCT_GRP_CODE_RE) > -1) {
					msg = "4," + loginData.getGroupCode();
				} else if (accountType.indexOf(SystemConstant.ACCT_GRP_CODE_BC) > -1) {
					msg = "5," + loginData.getGroupCode();
				}
				LOGGER.info("method getSelectedUserAccount() executed succefully in UserMgmntController");
			} else {
				LOGGER.info("Session Expire in getSelectedUserAccount() in UserMgmntController");
			}
		} catch (Exception ex) {
			LOGGER.info("******Exception occurs at Method getSelectedUserAccount() done UserMgmntController " + ex);
		}
		LOGGER.info("******Execution Of Method getSelectedUserAccount() done successfully in UserMgmntController ");
		return msg;
	}

	/**
	 * To Change Password
	 * 
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/changePassword", method = RequestMethod.GET)
	public ModelAndView getChangePassword(HttpSession session) {
		String view = null;
		try {
			LOGGER.info("**** start of getChangePassword() method in UserMgmntController ****");
			LoginData loginData = managemetImpl.getSessionInfo(session);
			if (loginData.isSessionInfo()) {
				UserAccountData userAccountData = new UserAccountData();
				SubscriberData subscriberData = iUserMgmntService.getProfilesById(loginData.getAccountTypeId());
				SubscriberData allDetails = iUserMgmntService.getAllDetails(subscriberData);
				map.addAttribute(WALLETLISTINFO, allDetails.getWalletList());
				view = "ChnagePassword";
				map.addAttribute("successMessage", "");
				map.addAttribute("errorMessage", "");
				map.addAttribute(SystemConstant.STATUS_MESSAGE, "");
				map.addAttribute(SystemConstant.MENU_ID, 185);
				map.addAttribute(SystemConstant.SUBMENU_ID, 188);
				map.addAttribute("userAccountData", userAccountData);
			} else {
				LOGGER.info("Session Expire On execution of Method setForgetPassword() in UserMgmntController");
				view = ScSystemConstant.LOGIN_PAGE;
				map.addAttribute(SystemConstant.STATUS_MESSAGE, getProperty(SystemConstant.SESSION_NOT_VALID));
			}
		} catch (Exception ex) {
			LOGGER.info("Exception occured in getChangePassword() method in UserMgmntController --->" + ex);
			map.addAttribute(SystemConstant.STATUS_MESSAGE, getProperty(SystemConstant.NETWORK_ERROR_MESSAGE));
			view = ScSystemConstant.HOMEPAGE;
		}
		return new ModelAndView(view, map);
	}
	
	
	/**
	 * To Change Wallet PIN
	 * 
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/changeWalletPIN", method = RequestMethod.GET)
	public ModelAndView getChangeWalletPIN(HttpSession session) {
		String view = null;
		try {
			LOGGER.info("**** start of getChangeWalletPIN() method in UserMgmntController ****");
			LoginData loginData = managemetImpl.getSessionInfo(session);
			if (loginData.isSessionInfo()) {
				UserAccountData userAccountData = new UserAccountData();
				SubscriberData subscriberData = iUserMgmntService.getProfilesById(loginData.getAccountTypeId());
				SubscriberData allDetails = iUserMgmntService.getAllDetails(subscriberData);
				map.addAttribute(WALLETLISTINFO, allDetails.getWalletList());
				view = "changeWalletPin";
				map.addAttribute("successMessage", "");
				map.addAttribute("errorMessage", "");
				map.addAttribute(SystemConstant.STATUS_MESSAGE, "");
				map.addAttribute(SystemConstant.MENU_ID, 185);
				map.addAttribute(SystemConstant.SUBMENU_ID, 188);
				map.addAttribute("userAccountData", userAccountData);
			} else {
				LOGGER.info("Session Expire On execution of Method setForgetPassword() in UserMgmntController");
				view = ScSystemConstant.LOGIN_PAGE;
				map.addAttribute(SystemConstant.STATUS_MESSAGE, getProperty(SystemConstant.SESSION_NOT_VALID));
			}
		} catch (Exception ex) {
			LOGGER.info("Exception occured in getChangePassword() method in UserMgmntController --->" + ex);
			map.addAttribute(SystemConstant.STATUS_MESSAGE, getProperty(SystemConstant.NETWORK_ERROR_MESSAGE));
			view = ScSystemConstant.HOMEPAGE;
		}
		return new ModelAndView(view, map);
	}

	@RequestMapping(value = "/validateEmailDobAns", method = RequestMethod.POST)
	@ResponseBody
	public Map<String, Integer> getValidateEmailDobAns(@RequestParam(value = "emailorusername") String emailorusername,
			@RequestParam(value = "dob") String dob, @RequestParam(value = "answer") String answer) {
		Map<String, Integer> accountIdOrInvalidCount = null;
		try {
			accountIdOrInvalidCount = iUserMgmntService.checkEmailDobAns(emailorusername, dob, answer);
		} catch (Exception ex) {
			LOGGER.info("Exception occured in getValidateEmailDobAns() method in UserMgmntController--->" + ex);
		}
		return accountIdOrInvalidCount;
	}

	@RequestMapping(value = "/checkPassword1", method = RequestMethod.POST)
	@ResponseBody
	public String checkPassword(@RequestParam(value = "userPassword") String userPassword, HttpSession session) {
		String flag = "0";
		String password = null;
		String userPassword1 = userPassword;
		try {
			LOGGER.info("**** start of checkPassword() method in UserMgmntController ****");
			LoginData loginData = managemetImpl.getSessionInfo(session);

			if (loginData.isSessionInfo()) {

				password = loginData.getPassword();

				if (userPassword1.equals(password)) {
					flag = "0";
				} else {
					flag = "1";
				}

			}
		} catch (Exception ex) {
			LOGGER.info("Exception occured in checkPassword() method in UserMgmntController --->" + ex);

		}
		return flag;
	}

	@RequestMapping(value = "/changePassword1", method = RequestMethod.GET)
	public ModelAndView getChangePassword1(HttpSession session) {
		String view = null;
		try {
			LOGGER.info("**** start of getChangePassword() method in UserMgmntController ****");
			LoginData loginData = managemetImpl.getSessionInfo(session);
			if (loginData.isSessionInfo()) {
				UserAccountData userAccountData = new UserAccountData();
				view = "ChangePassword1";
				map.addAttribute("successMessage", "");
				map.addAttribute("errorMessage", "");

				map.addAttribute("userAccountData", userAccountData);
			} else {
				LOGGER.info("Session Expire On execution of Method setForgetPassword() in UserMgmntController");
				view = ScSystemConstant.LOGIN_PAGE;
				map.addAttribute(SystemConstant.STATUS_MESSAGE, getProperty(SystemConstant.SESSION_NOT_VALID));
			}
		} catch (Exception ex) {
			LOGGER.info("Exception occured in getChangePassword() method in UserMgmntController --->" + ex);
			map.addAttribute(SystemConstant.STATUS_MESSAGE, getProperty(SystemConstant.NETWORK_ERROR_MESSAGE));
			view = ScSystemConstant.HOMEPAGE;
		}
		return new ModelAndView(view, map);
	}

	@RequestMapping(value = "/findsubquery", method = RequestMethod.POST)
	@ResponseBody
	public Map<Integer, String> getsubquerylist(@RequestParam(value = "products", required = false) String productType,
			HttpSession session) {

		Map<Integer, String> maplist = new HashMap<>();

		try {
			LOGGER.debug("***********getsubquerylist *************");
			LoginData loginData;
			loginData = managemetImpl.getSessionInfo(session);
			if (loginData.isSessionInfo()) {
				maplist = iUserMgmntService.getsubquerylist(productType);

			} else {
				map.addAttribute(SystemConstant.STATUS_MESSAGE, getProperty(SystemConstant.SESSION_NOT_VALID));
			}

		} catch (Exception e) {
			LOGGER.info("Exceptions occured in : controller" + e);
		}
		return maplist;

	}

	@RequestMapping(value = "/findUrlList", method = RequestMethod.POST)
	@ResponseBody
	public String findUrlList(@RequestParam(value = "subqueryid", required = false) Integer subqueryid,
			HttpSession session) {

		String list ="";

		try {
			LOGGER.debug("***********boxDetailsController *************");
			LoginData loginData;
			loginData = managemetImpl.getSessionInfo(session);
			if (loginData.isSessionInfo()) {
				list = iUserMgmntService.getfindUrlList(subqueryid);

			} else {
				map.addAttribute(SystemConstant.STATUS_MESSAGE, getProperty(SystemConstant.SESSION_NOT_VALID));
			}

		} catch (Exception e) {
			LOGGER.info("Exceptions occured in : controller" + e);
		}
		return list;

	}

	@RequestMapping(value = "/getMyQueries", method = RequestMethod.GET)
	public ModelAndView getMyQueries(
			@ModelAttribute(value = "transactionRequestData") TransactionRequestData transactionRequestData,
			HttpSession session,@RequestParam(value="flag",required=false)String flag) {
		String view = "";

		try {
			LOGGER.info("**********Execution start of method getMyQueries() in controller ScUserMgmntController ");

			LoginData loginData = managemetImpl.getSessionInfo(session);
			if (loginData.isSessionInfo()) {
				session.setAttribute(ScSystemConstant.LOGINID, loginData.getSubscriberMobNo());
				session.setAttribute("key", loginData.getKey());
				session.setAttribute(ScSystemConstant.TOKENID, loginData.getTokenId());
				Map<Integer,String> productType=iUserMgmntService.getproducttype(loginData.getSubscriberMobNo()) ;
				map.addAttribute("productType",productType);
				map.remove(SystemConstant.STATUS_MESSAGE);
				List<SubscriberData> queryList = iUserMgmntService.queryStatus(session, loginData.getSubscriberMobNo(),
						transactionRequestData);
				SubscriberData walletDetails = iUserMgmntService.getWalletDetailList(loginData, session);
				map.addAttribute(WALLETDETAILS, walletDetails);
				map.addAttribute("queryList", queryList);
				if(!StringUtils.isEmpty(flag))
				map.addAttribute(SystemConstant.STATUS_MESSAGE, "Query Raised Sucessfully");
				else	
				map.addAttribute(SystemConstant.STATUS_MESSAGE, "");
				map.addAttribute(SystemConstant.ERRORSTATUSMESSAGE, "");

				view = "myQueryStatus";
			} else {
				LOGGER.info("Session Expired on Execution of Method getMyQueries() in controller ScUserMgmntController ");
				session.setAttribute(SystemConstant.STATUS_MESSAGE, loginData.getStatusMessage());
				return new ModelAndView(loginData.getView(), map);
			}
		} catch (Exception e) {
			LOGGER.info("EXCEPTION OCCURE ON Method getMyQueries() in controller ScUserMgmntController :" + e);
			map.addAttribute(SystemConstant.STATUS_MESSAGE, getProperty(SystemConstant.NETWORK_ERROR_MESSAGE));
			view = ScSystemConstant.LOGIN_PAGE;
		}

		return new ModelAndView(view, map);

	}

	@RequestMapping(value = "/getMyQueries", method = RequestMethod.POST)
	public ModelAndView myQueries(
			@ModelAttribute(value = "transactionRequestData") TransactionRequestData transactionRequestData,
			HttpSession session) {
		String view = "";

		try {
			LOGGER.info("**********Execution start of method myQueries() in controller ScUserMgmntController ");

			LoginData loginData = managemetImpl.getSessionInfo(session);
			if (loginData.isSessionInfo()) {
				session.setAttribute(ScSystemConstant.LOGINID, loginData.getSubscriberMobNo());
				session.setAttribute("key", loginData.getKey());
				session.setAttribute(ScSystemConstant.TOKENID, loginData.getTokenId());

				List<SubscriberData> queryList = iUserMgmntService.queryStatus(session, loginData.getSubscriberMobNo(),
						transactionRequestData);
				SubscriberData walletDetails = iUserMgmntService.getWalletDetailList(loginData, session);
				map.addAttribute(WALLETDETAILS, walletDetails);
				map.addAttribute("queryList", queryList);
				map.addAttribute(SystemConstant.STATUS_MESSAGE, transactionRequestData.getMessage());
				map.addAttribute(SystemConstant.ERRORSTATUSMESSAGE, "");

				view = "myQueryStatus";
			} else {
				LOGGER.info("Session Expired on Execution of Method myQueries() in controller ScUserMgmntController ");
				session.setAttribute(SystemConstant.STATUS_MESSAGE, loginData.getStatusMessage());
				return new ModelAndView(loginData.getView(), map);
			}
		} catch (Exception e) {
			LOGGER.info("EXCEPTION OCCUR in Method myQueries() in controller ScUserMgmntController :" + e);
			map.addAttribute(SystemConstant.STATUS_MESSAGE, getProperty(SystemConstant.NETWORK_ERROR_MESSAGE));
			view = ScSystemConstant.LOGIN_PAGE;
		}

		return new ModelAndView(view, map);

	}

	@RequestMapping(value = "/saveTransactionIssue", method = RequestMethod.POST)
	@ResponseBody
	public String saveTransactionIssue(@RequestParam(value = "instrument") String instrument,
			@RequestParam(value = "id") String id, @RequestParam(value = "remarks") String remarks,@RequestParam(value = "subqueryid") String subqueryid,HttpSession session,@RequestParam(value = "sms") String[] sms) {
		String flag = "";
		
		try {
			LOGGER.info("**** start of checkPassword() method in UserMgmntController ****");
			LoginData loginData = managemetImpl.getSessionInfo(session);

			if (loginData.isSessionInfo()) {
				Integer ticketId = iUserMgmntService.saveTransactionIssue(instrument, id, remarks, loginData,subqueryid);
				flag = "true";
				
				SubscriberData subscriberDataNew = iUserMgmntService.getProfilesById(loginData.getAccountTypeId());

				SubscriberData subscriberDta = iUserMgmntService.getproducttype(subscriberDataNew);
				
			//String[] smsArray=sms.split(",");
				sendMail(sms, subscriberDta, ticketId, "self",null);
			}
		} catch (Exception ex) {
			LOGGER.info("Exception occured in checkPassword() method in UserMgmntController --->" + ex);

		}
		
		return flag;
	}
	
	/*@RequestMapping(value = "getOtpOnForgotPass1", method = RequestMethod.POST)
	@ResponseBody
	public String getOtpOnForgotPass1(@RequestParam(value = "mobile") String mobile,
			@RequestParam(value = "dateOfBirth") String dateOfBirth, HttpSession session) {
		Integer otp = 0;
		String[] splitOtp;
		String result = "";
		String abc;
		SubscriberData message = new SubscriberData();
		try {
			LOGGER.info("Execution start of getOtpOnForgotPass() method in ScUserMgmntController");
			message = iUserMgmntService.getOtpOnForgotPass(mobile, dateOfBirth);
			abc = message.getMessage();
		String messg = "UserName or Password is incorrect";
			if (abc.equals(messg)) {
				result = "Invalid Credentials";
			} else {
				result = "Enter One Time Password(OTP) sent to your mobile number *******" + mobile.substring(7) + ".";
				splitOtp = abc.split("#");
				otp = Integer.parseInt(splitOtp[2].trim());
				iUserMgmntService.validateOtp(mobile, dateOfBirth, otp);
			}

		} catch (Exception ex) {
			LOGGER.debug("Exception caught in getOtpOnForgotPass() method of ScUserMgmntController" + ex);
			result = "Invalid Credentials";
		}
		LOGGER.info("Execution end of getOtpOnForgotPass() method in ScUserMgmntController");

		return result;
	}*/

}
