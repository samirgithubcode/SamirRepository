/**
 * 
 */
package com.ng.sb.common.dataobject;

/**
 * @author gaurav
 *
 */
public class PlatformRequestData extends BaseObjectData {
	private static final long serialVersionUID = 1L;
	private String key;
	private Integer hostCode;
	public Integer getHostCode() {
		return hostCode;
	}
	public void setHostCode(Integer hostCode) {
		this.hostCode = hostCode;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	

}
