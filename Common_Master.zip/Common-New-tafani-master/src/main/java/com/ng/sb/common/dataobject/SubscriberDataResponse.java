package com.ng.sb.common.dataobject;


public class SubscriberDataResponse implements ValidationBean {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String secretQuestion;

	public String getSecretQuestion() {
		return secretQuestion;
	}

	public void setSecretQuestion(String secretQuestion) {
		this.secretQuestion = secretQuestion;
	}
	
	
}
