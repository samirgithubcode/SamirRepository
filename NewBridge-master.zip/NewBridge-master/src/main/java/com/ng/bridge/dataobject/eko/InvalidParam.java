package com.ng.bridge.dataobject.eko;

public class InvalidParam {
	
	 private String customerId;
	 private String pintwin;
	 private String otp;
	 private String initiatorId;
	 

	    public String getInitiatorId() {
		return initiatorId;
	}

	public void setInitiatorId(String initiatorId) {
		this.initiatorId = initiatorId;
	}

		public String getCustomerId ()
	    {
	        return customerId;
	    }

	    public void setCustomerId (String customerId)
	    {
	        this.customerId = customerId;
	    }

	    
	    public String getPintwin() {
			return pintwin;
		}

		public void setPintwin(String pintwin) {
			this.pintwin = pintwin;
		}

		
		public String getOtp() {
			return otp;
		}

		public void setOtp(String otp) {
			this.otp = otp;
		}

		@Override
	    public String toString()
	    {
	        return "ClassPojo [customer_id = "+customerId+"]";
	    }
}
