package com.ng.sb.common.dataobject;

import java.util.Map;

public class CustomerRegistrationData  extends BaseObjectData {
	private static final long serialVersionUID = 1L;
	private String customerFirstName;
	private String customerLastName;
	private String customerMobileNumber;
	private String houseNo;
	private String city;
	private String landMark;
	private Integer countryId;
	private Map<Integer,String> countryMap;
	private Integer stateId;
	private Map<Integer,String> stateMap;
	private String region;
	private Integer pinCode;
	private Integer status;
	private Integer[] walletList;
	private Map<Integer,String> walletInfo;
	private String address;
	private String locality;
	private String district;
	private String state;
	private String country;
	private String firstName;
	private String lastName;
	private java.sql.Date dob;
	private String email;
	
	public String getLocality() {
		return locality;
	}
	public void setLocality(String locality) {
		this.locality = locality;
	}
	 public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
	
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public java.sql.Date getDob() {
		return dob;
	}
	public void setDob(java.sql.Date dob) {
		this.dob = dob;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public Map<Integer, String> getWalletInfo() {
		return walletInfo;
	}
	public void setWalletInfo(Map<Integer, String> walletInfo) {
		this.walletInfo = walletInfo;
	}
	public Integer[] getWalletList() {
		return walletList;
	}
	public void setWalletList(Integer[] walletList) {
		this.walletList = walletList;
	}
	public String getCustomerFirstName() {
		return customerFirstName;
	}
	public void setCustomerFirstName(String customerFirstName) {
		this.customerFirstName = customerFirstName;
	}
	public String getCustomerLastName() {
		return customerLastName;
	}
	public void setCustomerLastName(String customerLastName) {
		this.customerLastName = customerLastName;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public String getCustomerMobileNumber() {
		return customerMobileNumber;
	}
	public void setCustomerMobileNumber(String customerMobileNumber) {
		this.customerMobileNumber = customerMobileNumber;
	}
	
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	public String getLandMark() {
		return landMark;
	}
	public void setLandMark(String landMark) {
		this.landMark = landMark;
	}
	public String getHouseNo() {
		return houseNo;
	}
	public void setHouseNo(String houseNo) {
		this.houseNo = houseNo;
	}
	
	public Map<Integer, String> getCountryMap() {
		return countryMap;
	}
	public void setCountryMap(Map<Integer, String> countryMap) {
		this.countryMap = countryMap;
	}
	public Integer getCountryId() {
		return countryId;
	}
	public void setCountryId(Integer countryId) {
		this.countryId = countryId;
	}
	public Integer getStateId() {
		return stateId;
	}
	public void setStateId(Integer stateId) {
		this.stateId = stateId;
	}
	
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public Integer getPinCode() {
		return pinCode;
	}
	public void setPinCode(Integer pinCode) {
		this.pinCode = pinCode;
	}
	public Map<Integer, String> getStateMap() {
		return stateMap;
	}
	public void setStateMap(Map<Integer, String> stateMap) {
		this.stateMap = stateMap;
	}
}
