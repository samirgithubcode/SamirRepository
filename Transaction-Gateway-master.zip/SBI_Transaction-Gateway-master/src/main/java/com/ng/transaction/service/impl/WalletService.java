package com.ng.transaction.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ng.bridge.service.IPartnerManagementService;
import com.ng.sb.common.dataobject.BridgeDataObject;
import com.ng.sb.common.exception.BridgeObjectDataException;
import com.ng.sb.common.util.SystemConstant;
import com.ng.transaction.service.IWalletService;

/**
 * @author gaurav
 *
 */
@Service(value=SystemConstant.WALLET_SERVICE)
public class WalletService extends BankingService implements IWalletService {

	private static final Logger LOGGER = LoggerFactory.getLogger(WalletService.class);
	
	@Autowired
	IPartnerManagementService partnerManagementService;
	
	
	@Override
	public BridgeDataObject fundTransferWalletToBank(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction BankingService -  fundTransferWalletToBank method. ");
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in checkBalance:"+ e);
		}
		return null;
	}

	@Override
	public BridgeDataObject fundTransferWalletToIMPS(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction BankingService -  fundTransferWalletToIMPS method. ");
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in checkBalance:"+ e);
		}
		return null;
	}

	@Override
	public BridgeDataObject fundTransferWalletToCC(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction BankingService -  fundTransferWalletToCC method. ");
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in checkBalance:"+ e);
		}
		return null;
	}

	@Override
	public BridgeDataObject fundTransferWalletToWallet(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction BankingService -  fundTransferWalletToWallet method. ");
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in checkBalance:"+ e);
		}
		return null;
	}

	@Override
	public BridgeDataObject walletCheckBalance(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction BankingService -  walletCheckBalance method. ");
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in checkBalance:"+ e);
		}
		return null;
	}

	
}
