/**
 * 
 */
package com.ng.bridge.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.ng.bridge.service.IWalletService;
import com.ng.bridge.util.NewConstants;
import com.ng.sb.common.dataobject.BridgeDataObject;
import com.ng.sb.common.exception.BridgeObjectDataException;
import com.ng.sb.common.util.SystemConstant;

/**
 * @author gaurav
 *
 */
@Service(value=SystemConstant.BRIDGE_WALLET_SERVICE)
public class WalletService extends BankingService implements IWalletService {

	private static final Logger LOGGER = LoggerFactory.getLogger(WalletService.class);
	@Override
	public BridgeDataObject fundTransferWalletToCC(BridgeDataObject bridgeDataObject) {
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge WalletService -  fundTransferWalletToCC method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in fundTransferWalletToCC in walletService:"+ e);
		}
		return null;
	}
	@Override
	public BridgeDataObject fundTransferWalletToWallet(BridgeDataObject bridgeDataObject) {
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge WalletService -  fundTransferWalletToWallet method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in fundTransferWalletToWalletin walletService:"+ e);
		}
		return null;
	}
	@Override
	public BridgeDataObject fundTransferWalletToBank(BridgeDataObject bridgeDataObject) {
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge WalletService -  fundTransferWalletToBank method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in fundTransferWalletToBank in walletService:"+ e);
		}
		return null;
	}

	@Override
	public BridgeDataObject fundTransferWalletToIMPS(BridgeDataObject bridgeDataObject) {
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge WalletService -  fundTransferWalletToIMPS method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in fundTransferWalletToIMPS in walletService:"+ e);
		}
		return null;
	}





}
