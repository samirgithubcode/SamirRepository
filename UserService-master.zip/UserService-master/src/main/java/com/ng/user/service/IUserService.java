/**
 * 
 */
package com.ng.user.service;

import org.springframework.web.multipart.MultipartFile;

import com.ng.sb.common.dataobject.RequestObject;
import com.ng.sb.common.dataobject.ResponseObject;
import com.ng.sb.common.dataobject.UserAccountData;
import com.ng.user.dto.ActivationCodeRequest;
import com.ng.user.dto.ChangePasswordRequest;
import com.ng.user.dto.ForgotPasswordRequest;
import com.ng.user.dto.ForgotPasswordResponse;
import com.ng.user.dto.LoginRequset;
import com.ng.user.dto.LoginResponse;
import com.ng.user.dto.OtpRequest;
import com.ng.user.dto.SignUpRequest;

/**
 * @author gopal
 *
 */
public interface IUserService {

	public LoginResponse authenticateUser(LoginRequset loginRequset);
	
	public ResponseObject sendOtp(OtpRequest otpRequest);
	
	public ResponseObject resetPassword(RequestObject requestObject);
	
	public ResponseObject changePassword(ChangePasswordRequest changePasswordRequest);
	
	public ResponseObject signUpUserOnDevice(SignUpRequest signUpRequest);
	
	public ForgotPasswordResponse forgotPassword(ForgotPasswordRequest forgotPasswordRequest);
	
	public ResponseObject getActivationCode(ActivationCodeRequest activationCodeRequest);

	public ResponseObject getUserProfile(UserAccountData accountData);
	
	public ResponseObject saveUpdateProfileImage(MultipartFile userProfile, UserAccountData userAccountData);
}


