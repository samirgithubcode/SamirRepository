package com.ng.user.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class UserAddress implements Serializable{


	private static final long serialVersionUID = 5651962559019054592L;
	
	@JsonProperty("locality")
	private String locality;
	
	@JsonProperty("district")
	private String district;
	
	@JsonProperty("state")
	private String state;
	
	@JsonProperty("country")
	private String country;
	
	@JsonProperty("region")
	private String region;
	
	@JsonProperty("pincode")
	private Integer pinCode;
	
	public String getLocality() {
		return locality;
	}
	
	public void setLocality(String locality) {
		this.locality = locality;
	}
	
	public String getDistrict() {
		return district;
	}
	
	public void setDistrict(String district) {
		this.district = district;
	}
	
	public String getState() {
		return state;
	}
	
	public void setState(String state) {
		this.state = state;
	}
	
	public String getCountry() {
		return country;
	}
	
	public void setCountry(String country) {
		this.country = country;
	}
	
	public String getRegion() {
		return region;
	}
	
	public void setRegion(String region) {
		this.region = region;
	}
	
	public Integer getPinCode() {
		return pinCode;
	}
	
	public void setPinCode(Integer pinCode) {
		this.pinCode = pinCode;
	}
	
}
