package com.ng.transaction.service;

import org.springframework.http.ResponseEntity;

import com.ng.sb.common.dataobject.TransactionData;

public interface ISBITransactionService {

	ResponseEntity<String> registerCustomerToSBI(TransactionData data) throws Exception;

}
