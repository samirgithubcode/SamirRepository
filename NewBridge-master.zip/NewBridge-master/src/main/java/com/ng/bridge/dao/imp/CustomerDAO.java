/**
 * 
 */
package com.ng.bridge.dao.imp;

import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.ng.bridge.dao.ICustomerDAO;
import com.ng.bridge.exception.GenericException;
import com.ng.sb.common.dao.impl.SuperParentDAO;
import com.ng.sb.common.model.Partner;
import com.ng.sb.common.model.ThirdPartySubsRecipient;
import com.ng.sb.common.model.ThirdPartySubscriber;
import com.ng.sb.common.util.SystemConstant;

/**
 * @author ram
 *
 */
@Repository(value=SystemConstant.CUSTOMER_DAO)
public class CustomerDAO extends SuperParentDAO implements ICustomerDAO {
	private static final long serialVersionUID = 1L;
	public ThirdPartySubscriber checkMobileNumber(String mobile,Integer walletId) throws GenericException{
		ThirdPartySubscriber tps=null;
		try {
			TypedQuery<ThirdPartySubscriber> query=entityManager.createNamedQuery("ThirdPartySubscriber.findByMobileAndWalletId", ThirdPartySubscriber.class);
			query.setParameter("mobile",mobile);
			query.setParameter("walletId",new Partner(walletId));
			tps=query.getSingleResult();
		} catch (Exception e) {
			throw e;
		}
		return tps;
	}
	
	@Override
	public ThirdPartySubsRecipient getRecipient(int tpsId,String bankAccount,String ifscCode) throws GenericException{
		ThirdPartySubsRecipient recipient=null;
		try {
			TypedQuery<ThirdPartySubsRecipient> query=entityManager.createNamedQuery("ThirdPartySubsRecipient.findByTpsIdBankAndIFSC", ThirdPartySubsRecipient.class);
			query.setParameter("tpsId",new ThirdPartySubscriber(tpsId));
			query.setParameter("bankAccount",bankAccount);
			query.setParameter("ifscCode", ifscCode);
			recipient=query.getSingleResult();
		} catch (Exception e) {
			throw e;
		}
		return recipient;
	}
	
	@Override
	public Object saveObject(Object object) throws GenericException{
		try {
			entityManager.persist(object);
		} catch (Exception e) {
			throw e;
		}
		return object;
	}
}
