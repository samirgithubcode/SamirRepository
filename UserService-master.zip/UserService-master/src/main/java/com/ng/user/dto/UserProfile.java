package com.ng.user.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class UserProfile implements Serializable{

	private static final long serialVersionUID = 8690728138279535762L;

	@JsonProperty("name")
	private String fullName;
	
	@JsonProperty("msisdn")
	private String mobileNo;
	
	@JsonProperty("email")
	private String emailId;
	
	@JsonProperty("dob")
	private String dateOfBirth;
	
	@JsonProperty("activationdate")
	private String activationDate;
	
	@JsonProperty("address")
	private UserAddress address;
	
	public String getFullName() {
		return fullName;
	}
	
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	
	public String getMobileNo() {
		return mobileNo;
	}
	
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	
	public String getEmailId() {
		return emailId;
	}
	
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	
	public String getActivationDate() {
		return activationDate;
	}
	
	public void setActivationDate(String activationDate) {
		this.activationDate = activationDate;
	}
	
	public UserAddress getAddress() {
		return address;
	}
	
	public void setAddress(UserAddress address) {
		this.address = address;
	}
	
}
