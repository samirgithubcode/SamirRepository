package com.ng.sb.common.dataobject;

public class UserComplaintData {
	private String serialNo;
	private String totalTicket;
	private String totalOwnedTicket;
	private String versionNumber;
	private String complaintDate;
	
	
	public String getSerialNo() {
		return serialNo;
	}
	public void setSerialNo(String serialNo) {
		this.serialNo = serialNo;
	}
	public String getTotalTicket() {
		return totalTicket;
	}
	public void setTotalTicket(String totalTicket) {
		this.totalTicket = totalTicket;
	}
	public String getTotalOwnedTicket() {
		return totalOwnedTicket;
	}
	public void setTotalOwnedTicket(String totalOwnedTicket) {
		this.totalOwnedTicket = totalOwnedTicket;
	}
	public String getVersionNumber() {
		return versionNumber;
	}
	public void setVersionNumber(String versionNumber) {
		this.versionNumber = versionNumber;
	}
	public String getComplaintDate() {
		return complaintDate;
	}
	public void setComplaintDate(String complaintDate) {
		this.complaintDate = complaintDate;
	}
}
