/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;


@Entity
@Table(name = "RangeDetails")
@XmlRootElement
@NamedQueries({
    
	@NamedQuery(name = "RangeDetails.findAll", query = "SELECT i FROM RangeDetails i"),
    @NamedQuery(name = "RangeDetails.findById", query = "SELECT i FROM RangeDetails i WHERE i.id = :id"),
    @NamedQuery(name = "RangeDetails.findBySeRangeFrom", query = "SELECT i FROM RangeDetails i WHERE i.seRangeFrom = :seRangeFrom"),
    @NamedQuery(name = "RangeDetails.findByPidAndMvId", query = "SELECT i FROM RangeDetails i WHERE i.productId = :productId and mvId = :mvId and availableBoxes <> :availableBoxes"),
 })
public class RangeDetails implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "seRangeFrom")
    private String seRangeFrom;
    @Basic(optional = false)
    @Column(name = "seRangeTo")
    private String seRangeTo;
    @Basic(optional = false)
    @Column(name = "boxQtyTypeId")
    private int boxQtyTypeId;
    @Basic(optional = false)
    @Column(name = "totalBoxes")
    private int totalBoxes;
    @Basic(optional = false)
    @Column(name = "availableBoxes")
    private int availableBoxes;
    @Basic(optional = false)
    @Column(name = "totalElements")
    private Long totalElements;
    @Basic(optional = false)
    @Column(name = "addDate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date addDate;
    @Column(name = "editDate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date editDate;
    @Basic(optional = false)
    @Column(name = "transactionId")
    private String transactionId;
    @JoinColumn(name = "pId", referencedColumnName = "id")
    @ManyToOne
    private Products productId;
    @JoinColumn(name = "mvId", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private MasterVersion mvId;
    @JoinColumn(name = "addById", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private AccountLoginInfo addById;
    @JoinColumn(name = "editById", referencedColumnName = "id")
    @ManyToOne
    private AccountLoginInfo editById;

    public RangeDetails() {
    	//empty
    }

    public RangeDetails(Integer id) {
        this.id = id;
    }


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
    
    public String getSeRangeFrom() {
		return seRangeFrom;
	}

	public void setSeRangeFrom(String seRangeFrom) {
		this.seRangeFrom = seRangeFrom;
	}

	public String getSeRangeTo() {
		return seRangeTo;
	}

	public void setSeRangeTo(String seRangeTo) {
		this.seRangeTo = seRangeTo;
	}

	public int getBoxQtyTypeId() {
		return boxQtyTypeId;
	}

	public void setBoxQtyTypeId(int boxQtyTypeId) {
		this.boxQtyTypeId = boxQtyTypeId;
	}

	public int getTotalBoxes() {
		return totalBoxes;
	}

	public void setTotalBoxes(int totalBoxes) {
		this.totalBoxes = totalBoxes;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public int getAvailableBoxes() {
		return availableBoxes;
	}

	public void setAvailableBoxes(int availableBoxes) {
		this.availableBoxes = availableBoxes;
	}

	public Long getTotalElements() {
		return totalElements;
	}

	public void setTotalElements(Long totalElements) {
		this.totalElements = totalElements;
	}

	public Date getAddDate() {
		return addDate;
	}

	public void setAddDate(Date addDate) {
		this.addDate = addDate;
	}

	public Date getEditDate() {
		return editDate;
	}

	public void setEditDate(Date editDate) {
		this.editDate = editDate;
	}

	
	public MasterVersion getMvId() {
		return mvId;
	}

	public void setMvId(MasterVersion mvId) {
		this.mvId = mvId;
	}

	public Products getProductId() {
		return productId;
	}

	public void setProductId(Products productId) {
		this.productId = productId;
	}

	
	public AccountLoginInfo getAddById() {
		return addById;
	}

	public void setAddById(AccountLoginInfo addById) {
		this.addById = addById;
	}

	public AccountLoginInfo getEditById() {
		return editById;
	}

	public void setEditById(AccountLoginInfo editById) {
		this.editById = editById;
	}

	@Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof RangeDetails)) {
            return false;
        }
        RangeDetails other = (RangeDetails) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.RangeDetails[ id=" + id + " ]";
    }
    
}
