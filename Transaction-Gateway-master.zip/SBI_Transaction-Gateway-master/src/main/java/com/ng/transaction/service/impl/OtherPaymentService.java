/**
 * 
 */
package com.ng.transaction.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.ng.sb.common.dataobject.BridgeDataObject;
import com.ng.sb.common.util.SystemConstant;
import com.ng.transaction.service.IOtherPayAgentService;
import com.ng.transaction.service.IOtherPayCustomerService;

/**
 * @author gaurav
 *
 */
@Service(value=SystemConstant.OTHER_PAYMENT_SERVICE)
public class OtherPaymentService extends WalletService implements IOtherPayCustomerService,IOtherPayAgentService{

	private static final Logger LOGGER = LoggerFactory.getLogger(OtherPaymentService.class);

	@Override
	public BridgeDataObject payAgentBankToBank(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction OtherPaymentService -  payAgentBankToBank method. ");
		return super.fundTransferBankToBank(bridgeDataObject);
	}

	@Override
	public BridgeDataObject payAgentBankToWallet(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction OtherPaymentService -  payAgentBankToWallet method. ");
		return super.fundTransferBankToWallet(bridgeDataObject);
	}

	@Override
	public BridgeDataObject payAgentBankToCC(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction OtherPaymentService -  payAgentBankToCC method. ");
		return super.fundTransferBankToCC(bridgeDataObject);
	}

	@Override
	public BridgeDataObject payAgentBankToIMPS(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction OtherPaymentService -  payAgentBankToIMPS method. ");
		return super.fundTransferBankToIMPS(bridgeDataObject);
	}

	@Override
	public BridgeDataObject payAgentIMPSToBank(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction OtherPaymentService -  payAgentIMPSToBank method. ");
		return super.fundTransferIMPSToBank(bridgeDataObject);
	}

	@Override
	public BridgeDataObject payAgentIMPSToWallet(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction OtherPaymentService -  payAgentIMPSToWallet method. ");
		return super.fundTransferIMPSToWallet(bridgeDataObject);
	}

	@Override
	public BridgeDataObject payAgentIMPSToCC(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction OtherPaymentService -  payAgentIMPSToCC method. ");
		return super.fundTransferIMPSToCC(bridgeDataObject);
	}

	@Override
	public BridgeDataObject payAgentIMPSToIMPS(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction OtherPaymentService -  payAgentIMPSToCC method. ");
		return super.fundTransferIMPSToIMPS(bridgeDataObject);
	}

	@Override
	public BridgeDataObject payAgentCCToBank(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction OtherPaymentService -  payAgentCCToBank method. ");
		return super.fundTransferCCToBank(bridgeDataObject);
	}

	@Override
	public BridgeDataObject payAgentCCToWallet(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction OtherPaymentService -  payAgentCCToWallet method. ");
		return super.fundTransferCCToWallet(bridgeDataObject);
	}

	@Override
	public BridgeDataObject payAgentCCToCC(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction OtherPaymentService -  payAgentCCToCC method. ");
		return super.fundTransferCCToCC(bridgeDataObject);
	}

	@Override
	public BridgeDataObject payAgentCCToIMPS(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction OtherPaymentService -  payAgentCCToIMPS method. ");
		return super.fundTransferCCToIMPS(bridgeDataObject);
	}

	@Override
	public BridgeDataObject payAgentWalletToWallet(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction OtherPaymentService -  payAgentWalletToWallet method. ");
		return super.fundTransferWalletToWallet(bridgeDataObject);
	}

	@Override
	public BridgeDataObject payIndividualBankToBank(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction OtherPaymentService -  payIndividualBankToBank method. ");
		return super.fundTransferBankToBank(bridgeDataObject);
	}

	@Override
	public BridgeDataObject payIndividualBankToWallet(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction OtherPaymentService -  payIndividualBankToWallet method. ");
		return super.fundTransferBankToWallet(bridgeDataObject);
	}

	@Override
	public BridgeDataObject payIndividualBankToCC(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction OtherPaymentService -  payIndividualBankToCC method. ");
		return super.fundTransferBankToCC(bridgeDataObject);
	}

	@Override
	public BridgeDataObject payIndividualBankToIMPS(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction OtherPaymentService -  payIndividualBankToIMPS method. ");
		return super.fundTransferBankToIMPS(bridgeDataObject);
	}

	@Override
	public BridgeDataObject payIndividualIMPSToBank(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction OtherPaymentService -  payIndividualIMPSToBank method. ");
		return super.fundTransferIMPSToBank(bridgeDataObject);
	}

	@Override
	public BridgeDataObject payIndividualIMPSToWallet(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction OtherPaymentService -  payIndividualIMPSToWallet method. ");
		return super.fundTransferIMPSToWallet(bridgeDataObject);
	}

	@Override
	public BridgeDataObject payIndividualIMPSToCC(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction OtherPaymentService -  payIndividualIMPSToCC method. ");
		return super.fundTransferIMPSToCC(bridgeDataObject);
	}

	@Override
	public BridgeDataObject payIndividualIMPSToIMPS(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction OtherPaymentService -  payIndividualIMPSToIMPS method. ");
		return super.fundTransferIMPSToIMPS(bridgeDataObject);
	}

	@Override
	public BridgeDataObject payIndividualCCToBank(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction OtherPaymentService -  payIndividualCCToBank method. ");
		return super.fundTransferCCToBank(bridgeDataObject);
	}

	@Override
	public BridgeDataObject payIndividualCCToWallet(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction OtherPaymentService -  payIndividualCCToWallet method. ");
		return super.fundTransferCCToWallet(bridgeDataObject);
	}

	@Override
	public BridgeDataObject payIndividualCCToCC(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction OtherPaymentService -  payIndividualCCToCC method. ");
		return super.fundTransferCCToCC(bridgeDataObject);
	}

	@Override
	public BridgeDataObject payIndividualCCToIMPS(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction OtherPaymentService -  payIndividualCCToIMPS method. ");
		return super.fundTransferCCToIMPS(bridgeDataObject);
	}

	@Override
	public BridgeDataObject payIndividualWalletToWallet(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction OtherPaymentService -  payIndividualWalletToWallet method. ");
		return super.fundTransferWalletToWallet(bridgeDataObject);
	}

	@Override
	public BridgeDataObject payIndividualWalletToBank(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction OtherPaymentService -  payIndividualWalletToBank method. ");
		return super.fundTransferWalletToBank(bridgeDataObject);
	}

	@Override
	public BridgeDataObject payAgentWalletToBank(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction OtherPaymentService -  payAgentWalletToBank method. ");
		return super.fundTransferWalletToWallet(bridgeDataObject);
	}

	

	
}
