package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;


@Entity
@Table(name="financial_service")

@XmlRootElement
@NamedQueries({
	
	  @NamedQuery(name = "FinancialServices.findAll", query = "SELECT p FROM FinancialServices p"),
	  @NamedQuery(name = "FinancialServices.findAllById", query = "SELECT p FROM FinancialServices p where p.addedBy=:addedBy"),
	  @NamedQuery(name = "FinancialServices.findAllByfinancialId", query = "SELECT p FROM FinancialServices p where p.id=:id"),
	
	
})
public class FinancialServices implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true,nullable=false)
	private int id;
	
	@Column(name="service_name",length=25)
	private String serviceName;
	
	@Column(name="service_description",length=200)
	private String serviceDescription;
	

	@ManyToOne
	@JoinColumn(name="instrument_id",referencedColumnName="id")
	private FinancialInstruments instrumentId;
	
	@Column(name="start_date")
	@Temporal(TemporalType.DATE)
	private Date startDate;
	
	@Column(name="end_date")
	@Temporal(TemporalType.DATE)
	private Date endDate;
	
	@Column(name="addedBy",length=8)
	private int addedBy;
	
	@Column(name="addedOn")
	@Temporal(TemporalType.DATE)
	private Date addedOn;
	
	@Column(name="modifiedBy",length=8)
    private int modifiedBy;
	
	
	@Column(name="modifiedOn")
	@Temporal(TemporalType.DATE)
	private Date modifiedOn;
	
	@Column(name="status")
	private boolean status;
	
	public FinancialServices() {
		//empty
	}

	public FinancialServices(int id) {
		super();
		this.id = id;
	}

	@Override
	public int hashCode() {
		 int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}

	

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getServiceDescription() {
		return serviceDescription;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FinancialServices other = (FinancialServices) obj;
		boolean check=true;
		if (id != other.id)
			check= false;
		return check;
	}	
	public void setServiceDescription(String serviceDescription) {
		this.serviceDescription = serviceDescription;
	}

	public FinancialInstruments getInstrumentId() {
		return instrumentId;
	}

	public void setInstrumentId(FinancialInstruments instrumentId) {
		this.instrumentId = instrumentId;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	

	public Date getAddedOn() {
		return addedOn;
	}

	public void setAddedOn(Date addedOn) {
		this.addedOn = addedOn;
	}
	public int getAddedBy() {
		return addedBy;
	}

	public void setAddedBy(int addedBy) {
		this.addedBy = addedBy;
	}
	

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	public int getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(int modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}
}
