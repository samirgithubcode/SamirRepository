package com.ng.sb.common.dataobject;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

import com.ng.sb.common.model.BusinessKyc;
/**
*
* @author simran
*/

@Entity
@Table(name = "merchantbusinesskyc")
@XmlRootElement
@NamedQueries({
	 @NamedQuery(name="MerchantBusinessKyc.findAll", query = "SELECT a FROM MerchantBusinessKyc a"),
	 @NamedQuery(name="MerchantBusinessKyc.findByID", query ="SELECT m FROM MerchantBusinessKyc m where m.id = :id"),
	 @NamedQuery(name="MerchantBusinessKyc.findByMerchantId", query = "SELECT a FROM MerchantBusinessKyc a where  a.merchantId = :id"),
	 @NamedQuery(name="MerchantBusinessKyc.removeByMerchantID", query ="DELETE  FROM MerchantBusinessKyc m where m.merchantId = :id"),
	 @NamedQuery(name="MerchantBusinessKyc.removeByMerchantIDAndIdProof", query ="DELETE  FROM MerchantBusinessKyc m where m.merchantId = :id AND m.businessKycId.id=:idProofId"),	
})
public class MerchantBusinessKyc implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "id", unique=true, nullable=false)
	private Integer id;
	
	@JoinColumn(name = "businessKycId", referencedColumnName = "id")
	@ManyToOne
	private BusinessKyc businessKycId;
	@Column(name = "merchantId")
	private Integer merchantId;
	
	@Column(name = "kycNumber")
	private String kycNumber;

	@Column(name = "documentName")
	private String documentName;
	@Column(name = "validfrom")
	private Date validfrom;
	
	@Column(name = "validto")
	private Date validto;
	@Column(name = "addedOn")
	private Date addedOn;
	@Column(name = "addedBy")
	private String addedBy;

	@Column(name = "modifiedOn")
	private Date modifiedOn;
	public MerchantBusinessKyc() {
		//empty
	}
	public MerchantBusinessKyc(int id) {
		this.id=id;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public BusinessKyc getBusinessKycId() {
		return businessKycId;
	}
	public void setBusinessKycId(BusinessKyc businessKycId) {
		this.businessKycId = businessKycId;
	}
	public Integer getMerchantId() {
		return merchantId;
	}
	public void setMerchantId(Integer merchantId) {
		this.merchantId = merchantId;
	}
	public String getKycNumber() {
		return kycNumber;
	}
	public void setKycNumber(String kycNumber) {
		this.kycNumber = kycNumber;
	}
	public String getDocumentName() {
		return documentName;
	}
	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}
	public Date getValidfrom() {
		return validfrom;
	}
	public void setValidfrom(Date validfrom) {
		this.validfrom = validfrom;
	}
	public Date getValidto() {
		return validto;
	}
	public void setValidto(Date validto) {
		this.validto = validto;
	}

	public Date getAddedOn() {
		return addedOn;
	}
	public void setAddedOn(Date addedOn) {
		this.addedOn = addedOn;
	}
	public String getAddedBy() {
		return addedBy;
	}
	public void setAddedBy(String addedBy) {
		this.addedBy = addedBy;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	
	



	
}
