/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "sim_replacement_details")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "SimReplacementDetails.findAll", query = "SELECT s FROM SimReplacementDetails s"),
    @NamedQuery(name = "SimReplacementDetails.findById", query = "SELECT s FROM SimReplacementDetails s WHERE s.id = :id"),
    @NamedQuery(name = "SimReplacementDetails.findByOldSimSerialNumber", query = "SELECT s FROM SimReplacementDetails s WHERE s.oldSimSerialNumber = :oldSimSerialNumber"),
    @NamedQuery(name = "SimReplacementDetails.findByNewSimSerialNumber", query = "SELECT s FROM SimReplacementDetails s WHERE s.newSimSerialNumber = :newSimSerialNumber"),
    @NamedQuery(name = "SimReplacementDetails.findByHostSimVersionId", query = "SELECT s FROM SimReplacementDetails s WHERE s.hostSimVersionId = :hostSimVersionId"),
    @NamedQuery(name = "SimReplacementDetails.findByRequestDate", query = "SELECT s FROM SimReplacementDetails s WHERE s.requestDate = :requestDate"),
    @NamedQuery(name = "SimReplacementDetails.findByIssueDate", query = "SELECT s FROM SimReplacementDetails s WHERE s.issueDate = :issueDate"),
    @NamedQuery(name = "SimReplacementDetails.findBySimStatus", query = "SELECT s FROM SimReplacementDetails s WHERE s.simStatus = :simStatus")})
public class SimReplacementDetails implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Column(name = "old_sim_serial_number")
    private String oldSimSerialNumber;
    @Column(name = "new_sim_serial_number")
    private String newSimSerialNumber;
    @Column(name = "host_sim_version_id")
    private Integer hostSimVersionId;
    @Basic(optional = false)
    @Column(name = "request_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date requestDate;
    @Basic(optional = false)
    @Column(name = "issue_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date issueDate;
    @Column(name = "sim_status")
    private Short simStatus;
    @JoinColumn(name = "user_id", referencedColumnName = "id")
    @ManyToOne
    private Subscriber userId;
    @JoinColumn(name = "sim_permanent_block_history_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private SimPermanentBlockHistory simPermanentBlockHistoryId;
    @JoinColumn(name = "replace_by_accountInfo_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private AccountInfo replacebyaccountInfoid;

    public SimReplacementDetails() {
    	//empty
    }

    public SimReplacementDetails(Integer id) {
        this.id = id;
    }

    public SimReplacementDetails(Integer id, Date requestDate, Date issueDate) {
        this.id = id;
        this.requestDate = requestDate;
        this.issueDate = issueDate;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getOldSimSerialNumber() {
        return oldSimSerialNumber;
    }

    public void setOldSimSerialNumber(String oldSimSerialNumber) {
        this.oldSimSerialNumber = oldSimSerialNumber;
    }

    public String getNewSimSerialNumber() {
        return newSimSerialNumber;
    }

    public void setNewSimSerialNumber(String newSimSerialNumber) {
        this.newSimSerialNumber = newSimSerialNumber;
    }

    public Integer getHostSimVersionId() {
        return hostSimVersionId;
    }

    public void setHostSimVersionId(Integer hostSimVersionId) {
        this.hostSimVersionId = hostSimVersionId;
    }

    public Date getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(Date requestDate) {
        this.requestDate = requestDate;
    }

    public Date getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(Date issueDate) {
        this.issueDate = issueDate;
    }

    public Short getSimStatus() {
        return simStatus;
    }

    public void setSimStatus(Short simStatus) {
        this.simStatus = simStatus;
    }

    public Subscriber getUserId() {
        return userId;
    }

    public void setUserId(Subscriber userId) {
        this.userId = userId;
    }

    public SimPermanentBlockHistory getSimPermanentBlockHistoryId() {
        return simPermanentBlockHistoryId;
    }

    public void setSimPermanentBlockHistoryId(SimPermanentBlockHistory simPermanentBlockHistoryId) {
        this.simPermanentBlockHistoryId = simPermanentBlockHistoryId;
    }

    public AccountInfo getReplacebyaccountInfoid() {
        return replacebyaccountInfoid;
    }

    public void setReplacebyaccountInfoid(AccountInfo replacebyaccountInfoid) {
        this.replacebyaccountInfoid = replacebyaccountInfoid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof SimReplacementDetails)) {
            return false;
        }
        SimReplacementDetails other = (SimReplacementDetails) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.SimReplacementDetails[ id=" + id + " ]";
    }
    
}
