/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "sim_permanent_block_history")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "SimPermanentBlockHistory.findAll", query = "SELECT s FROM SimPermanentBlockHistory s"),
    @NamedQuery(name = "SimPermanentBlockHistory.findById", query = "SELECT s FROM SimPermanentBlockHistory s WHERE s.id = :id"),
    @NamedQuery(name = "SimPermanentBlockHistory.findBySimSerialNumber", query = "SELECT s FROM SimPermanentBlockHistory s WHERE s.simSerialNumber = :simSerialNumber"),
    @NamedQuery(name = "SimPermanentBlockHistory.findByBlockBy", query = "SELECT s FROM SimPermanentBlockHistory s WHERE s.blockBy = :blockBy"),
    @NamedQuery(name = "SimPermanentBlockHistory.findByCallId", query = "SELECT s FROM SimPermanentBlockHistory s WHERE s.callId = :callId"),
    @NamedQuery(name = "SimPermanentBlockHistory.findByTransactiondetailsid", query = "SELECT s FROM SimPermanentBlockHistory s WHERE s.transactiondetailsid = :transactiondetailsid"),
    @NamedQuery(name = "SimPermanentBlockHistory.findByReasionId", query = "SELECT s FROM SimPermanentBlockHistory s WHERE s.reasionId = :reasionId"),
    @NamedQuery(name = "SimPermanentBlockHistory.findByReasionForBlock", query = "SELECT s FROM SimPermanentBlockHistory s WHERE s.reasionForBlock = :reasionForBlock"),
    @NamedQuery(name = "SimPermanentBlockHistory.findByReplacementStatus", query = "SELECT s FROM SimPermanentBlockHistory s WHERE s.replacementStatus = :replacementStatus"),
    @NamedQuery(name = "SimPermanentBlockHistory.findByBlockDate", query = "SELECT s FROM SimPermanentBlockHistory s WHERE s.blockDate = :blockDate")})
public class SimPermanentBlockHistory implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
    @Basic(optional = false)
    @Column(name = "sim_serial_number", nullable = false, length = 12)
    private String simSerialNumber;
    @Basic(optional = false)
    @Column(name = "block_by", nullable = false)
    private boolean blockBy;
    @Column(name = "call_id")
    private Integer callId;
    @Column(name = "Transaction_details_id")
    private Integer transactiondetailsid;
    @Basic(optional = false)
    @Column(name = "reasion_id", nullable = false)
    private int reasionId;
    @Basic(optional = false)
    @Column(name = "reasion_for_block", nullable = false, length = 50)
    private String reasionForBlock;
    @Basic(optional = false)
    @Column(name = "replacement_status", nullable = false)
    private boolean replacementStatus;
    @Basic(optional = false)
    @Column(name = "block_date", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date blockDate;
    @JoinColumn(name = "user_id", referencedColumnName = "id", nullable = false)
    @ManyToOne(optional = false)
    private Subscriber userId;

    public SimPermanentBlockHistory() {
    	//default constructor
    }

    public SimPermanentBlockHistory(Integer id) {
        this.id = id;
    }

    public SimPermanentBlockHistory(Integer id, String simSerialNumber, boolean blockBy, int reasionId, String reasionForBlock, boolean replacementStatus, Date blockDate) {
        this.id = id;
        this.simSerialNumber = simSerialNumber;
        this.blockBy = blockBy;
        this.reasionId = reasionId;
        this.reasionForBlock = reasionForBlock;
        this.replacementStatus = replacementStatus;
        this.blockDate = blockDate;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSimSerialNumber() {
        return simSerialNumber;
    }

    public void setSimSerialNumber(String simSerialNumber) {
        this.simSerialNumber = simSerialNumber;
    }

    public boolean getBlockBy() {
        return blockBy;
    }

    public void setBlockBy(boolean blockBy) {
        this.blockBy = blockBy;
    }

    public Integer getCallId() {
        return callId;
    }

    public void setCallId(Integer callId) {
        this.callId = callId;
    }

    public Integer getTransactiondetailsid() {
        return transactiondetailsid;
    }

    public void setTransactiondetailsid(Integer transactiondetailsid) {
        this.transactiondetailsid = transactiondetailsid;
    }

    public int getReasionId() {
        return reasionId;
    }

    public void setReasionId(int reasionId) {
        this.reasionId = reasionId;
    }

    public String getReasionForBlock() {
        return reasionForBlock;
    }

    public void setReasionForBlock(String reasionForBlock) {
        this.reasionForBlock = reasionForBlock;
    }

    public boolean getReplacementStatus() {
        return replacementStatus;
    }

    public void setReplacementStatus(boolean replacementStatus) {
        this.replacementStatus = replacementStatus;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }
    
    
    public Date getBlockDate() {
        return blockDate;
    }

    public void setBlockDate(Date blockDate) {
        this.blockDate = blockDate;
    }

   
    public Subscriber getUserId() {
        return userId;
    }

    public void setUserId(Subscriber userId) {
        this.userId = userId;
    }

    

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof SimPermanentBlockHistory)) {
            return false;
        }
        SimPermanentBlockHistory other = (SimPermanentBlockHistory) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.SimPermanentBlockHistory[ id=" + id + " ]";
    }
    
}
