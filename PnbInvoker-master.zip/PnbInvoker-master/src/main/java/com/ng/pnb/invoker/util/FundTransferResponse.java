package com.ng.pnb.invoker.util;


public class FundTransferResponse {

	private Header header;
	
	private FundTransferResponseData data;

	public Header getHeader() {
		return header;
	}

	public void setHeader(Header header) {
		this.header = header;
	}

	public FundTransferResponseData getData() {
		return data;
	}

	public void setData(FundTransferResponseData data) {
		this.data = data;
	}
	
	
}



