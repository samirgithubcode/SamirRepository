package com.ng.sb.common.dataobject;

import org.springframework.beans.factory.annotation.Value;

public class BasePlatformLogin {
	@Value("${sys_pass_3des_key}")
	public String sysPass3desKey;
	@Value("${login.fail.count}")
	public String loginFailCount;
	@Value("${login.success}")
	public String loginSuccess;
	@Value("${network.error.message}")
	public String networkErrorMessage;
	@Value("${session.invalid}")
	public String sessionErrorMessage;
	@Value("${login.fail}")
	public String loginFail;
	@Value("${login.fail.count.message}")
	public String loginFailCountMessage;
	@Value("${SUVIDHA_TELEPHONE_BILL_PAYMENT_URL}")
	public String suvidhaTelepBillPaymentURL;
	
	@Value("${SUVIDHA_MOB_RECHARGE_URL}")
	public String suvidhaMobileRechURL;
	
	@Value("${SUVIDHA_GAS_BILL_PAYMENT_URL}")
	public String suvidhaGasPayURL;
	
	@Value("${SUVIDHA_DTH_RECH_RECHARGE_URL}")
	public String suvidhaDthRechURL;
	
	@Value("${SUVIDHA_TOKEN_KEY}")
	public String suvidhaTokenKey;
	
	@Value("${SUVIDHA_USER_ID}")
	public String suvidhaUserId;
	
	@Value("${SMS_URL}")
	public String smsURL;
	@Value("${PLATFORM_GATEWAY_IP}")
	public String platformGatewayIp;


	@Value("${MOM_ACCESS_ID}")
	public String momAccessId;
	
	
	@Value("${SUVIDHA_SERVER_IP}")
	public String suvidhaServerIp;
	
	
	@Value("${SUVIDHA_TELEPHONE_BILL_ENQUIRY_URL}")
	public String suvidhaTelephoneBillEnqURL;
	
	@Value("${SUVIDHA_GAS_BILL_ENQUIRY_URL}")
	public String suvidhaGasEnqURL;

	
	@Value("${SUVIDHA_USER_NAME}")
	public String suvidhaUserName;
	

	@Value("${SUVIDHA_ELECTRICITY_BILL_PAYMENT_URL}")
	public String suvidhaElectricityPayURL;
	
	@Value("${SUVIDHA_ELECTRICITY_BILL_ENQUIRY_URL}")
	public String suvidhaElectricityEnqURL;
	
	@Value("${HOST_WALLET}")
	public String hostWallet;
	
	
	@Value("${developer_key}")
	public String developerKey;
		
	@Value("${EKO_HOLD_COMMIT_TRNX}")
	public String ekoHoldCommitTrnxUrl;

	@Value("${EKO_BANK_DETAIL_URL}")
	public String ekoBankDetailUrl;
	
	@Value("${EKO_ACCOUNT_INFO_URL}")
	public String ekoAccountInfoUrl;
	
	
	@Value("${EKO_ADD_RECIPIENT_URL}")
	private String ekoAddRecipientUrl;
	
	
	@Value("${EKO_GET_CUSTOMER_URL}")
	public String ekoGetCustomerUrl;
	public String getEkoGetCustomerUrl() {
		return ekoGetCustomerUrl;
	}
	public void setEkoGetCustomerUrl(String ekoGetCustomerUrl) {
		this.ekoGetCustomerUrl = ekoGetCustomerUrl;
	}
	public String getEkoAddRecipientUrl() {
		return ekoAddRecipientUrl;
	}
	public void setEkoAddRecipientUrl(String ekoAddRecipientUrl) {
		this.ekoAddRecipientUrl = ekoAddRecipientUrl;
	}
	public String getEkoAccountInfoUrl() {
		return ekoAccountInfoUrl;
	}
	public void setEkoAccountInfoUrl(String ekoAccountInfoUrl) {
		this.ekoAccountInfoUrl = ekoAccountInfoUrl;
	}
	public String getEkoBankDetailUrl() {
		return ekoBankDetailUrl;
	}
	public void setEkoBankDetailUrl(String ekoBankDetailUrl) {
		this.ekoBankDetailUrl = ekoBankDetailUrl;
	}
	public String getEkoHoldCommitTrnxUrl() {
		return ekoHoldCommitTrnxUrl;
	}
	public void setEkoHoldCommitTrnxUrl(String ekoHoldCommitTrnxUrl) {
		this.ekoHoldCommitTrnxUrl = ekoHoldCommitTrnxUrl;
	}
	public String getDeveloperKey() {
		return developerKey;
	}
	public void setDeveloperKey(String developerKey) {
		this.developerKey = developerKey;
	}
	public String getSuvidhaElectricityPayURL() {
		return suvidhaElectricityPayURL;
	}
	public void setSuvidhaElectricityPayURL(String suvidhaElectricityPayURL) {
		this.suvidhaElectricityPayURL = suvidhaElectricityPayURL;
	}
	public String getSuvidhaElectricityEnqURL() {
		return suvidhaElectricityEnqURL;
	}
	public void setSuvidhaElectricityEnqURL(String suvidhaElectricityEnqURL) {
		this.suvidhaElectricityEnqURL = suvidhaElectricityEnqURL;
	}
	public String getSuvidhaUserName() {
		return suvidhaUserName;
	}
	public void setSuvidhaUserName(String suvidhaUserName) {
		this.suvidhaUserName = suvidhaUserName;
	}
	
	public String getSuvidhaTelephoneBillEnqURL() {
		return suvidhaTelephoneBillEnqURL;
	}
	public void setSuvidhaTelephoneBillEnqURL(String suvidhaTelephoneBillEnqURL) {
		this.suvidhaTelephoneBillEnqURL = suvidhaTelephoneBillEnqURL;
	}
	public String getSuvidhaGasEnqURL() {
		return suvidhaGasEnqURL;
	}
	public void setSuvidhaGasEnqURL(String suvidhaGasEnqURL) {
		this.suvidhaGasEnqURL = suvidhaGasEnqURL;
	}
	
	public String getSuvidhaServerIp() {
		return suvidhaServerIp;
	}
	public void setSuvidhaServerIp(String suvidhaServerIp) {
		this.suvidhaServerIp = suvidhaServerIp;
	}
	public String getSysPass3desKey() {
		return sysPass3desKey;
	}
	public void setSysPass3desKey(String sysPass3desKey) {
		this.sysPass3desKey = sysPass3desKey;
	}
	public String getLoginFailCount() {
		return loginFailCount;
	}
	public void setLoginFailCount(String loginFailCount) {
		this.loginFailCount = loginFailCount;
	}
	public String getLoginSuccess() {
		return loginSuccess;
	}
	public void setLoginSuccess(String loginSuccess) {
		this.loginSuccess = loginSuccess;
	}
	public String getNetworkErrorMessage() {
		return networkErrorMessage;
	}
	public void setNetworkErrorMessage(String networkErrorMessage) {
		this.networkErrorMessage = networkErrorMessage;
	}
	public String getSessionErrorMessage() {
		return sessionErrorMessage;
	}
	public void setSessionErrorMessage(String sessionErrorMessage) {
		this.sessionErrorMessage = sessionErrorMessage;
	}
	public String getLoginFail() {
		return loginFail;
	}
	public void setLoginFail(String loginFail) {
		this.loginFail = loginFail;
	}
	public String getLoginFailCountMessage() {
		return loginFailCountMessage;
	}
	public void setLoginFailCountMessage(String loginFailCountMessage) {
		this.loginFailCountMessage = loginFailCountMessage;
	}
	public String getSuvidhaTelepBillPaymentURL() {
		return suvidhaTelepBillPaymentURL;
	}
	public void setSuvidhaTelepBillPaymentURL(String suvidhaTelepBillPaymentURL) {
		this.suvidhaTelepBillPaymentURL = suvidhaTelepBillPaymentURL;
	}
	public String getSmsURL() {
		return smsURL;
	}
	public void setSmsURL(String smsURL) {
		this.smsURL = smsURL;
	}
	
	
	 	public String getMomAccessId() {
		return momAccessId;
	}
	public void setMomAccessId(String momAccessId) {
		this.momAccessId = momAccessId;
	}
		public String getSuvidhaMobileRechURL() {
		return suvidhaMobileRechURL;
	}
	public void setSuvidhaMobileRechURL(String suvidhaMobileRechURL) {
		this.suvidhaMobileRechURL = suvidhaMobileRechURL;
	}
	public String getSuvidhaGasPayURL() {
		return suvidhaGasPayURL;
	}
	public void setSuvidhaGasPayURL(String suvidhaGasPayURL) {
		this.suvidhaGasPayURL = suvidhaGasPayURL;
	}
	public String getSuvidhaDthRechURL() {
		return suvidhaDthRechURL;
	}
	public void setSuvidhaDthRechURL(String suvidhaDthRechURL) {
		this.suvidhaDthRechURL = suvidhaDthRechURL;
	}
	public String getSuvidhaTokenKey() {
		return suvidhaTokenKey;
	}
	public void setSuvidhaTokenKey(String suvidhaTokenKey) {
		this.suvidhaTokenKey = suvidhaTokenKey;
	}
	
	public String getSuvidhaUserId() {
		return suvidhaUserId;
	}
	public void setSuvidhaUserId(String suvidhaUserId) {
		this.suvidhaUserId = suvidhaUserId;
	}
	public String getPlatformGatewayIp() {
		return platformGatewayIp;
	}

	public void setPlatformGatewayIp(String platformGatewayIp) {
		this.platformGatewayIp = platformGatewayIp;
	}
	public String getHostWallet() {
	return hostWallet;
}
public void setHostWallet(String hostWallet) {
	this.hostWallet = hostWallet;
}

}
