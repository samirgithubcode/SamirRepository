package com.ng.sb.common.dataobject;


public class ProviderInfo extends BaseObjectData{
	private static final long serialVersionUID = 1L;
	
	//below the provider name
	private Integer providerCode;
	private String categoryName;
	private Integer categoryCode;
	
	
	
	
	
	
	public Integer getProviderCode() {
		return providerCode;
	}

	public void setProviderCode(Integer providerCode) {
		this.providerCode = providerCode;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public Integer getCategoryCode() {
		return categoryCode;
	}
	public void setCategoryCode(Integer categoryCode) {
		this.categoryCode = categoryCode;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
}
