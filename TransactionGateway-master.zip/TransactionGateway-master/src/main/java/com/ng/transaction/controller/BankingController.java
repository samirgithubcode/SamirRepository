/**
 * 
 */
package com.ng.transaction.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ng.sb.common.cache.MemCacheManager;
import com.ng.sb.common.cache.MemCacheUtils;
import com.ng.sb.common.dataobject.BridgeDataObject;
import com.ng.sb.common.dataobject.BridgeDataObject.ServiceType;
import com.ng.sb.common.dataobject.CustomerAccountData;
import com.ng.sb.common.dataobject.HostSubVersionData;
import com.ng.sb.common.dataobject.RequestObject;
import com.ng.sb.common.dataobject.ResponseObject;
import com.ng.sb.common.dataobject.TransactionData;
import com.ng.sb.common.dataobject.UserAccountData;
import com.ng.sb.common.model.CategoryProviderMapping;
import com.ng.sb.common.model.CustomerPreferredBiller;
import com.ng.sb.common.model.OverlayMerchants;
import com.ng.sb.common.model.PayeeDetails;
import com.ng.sb.common.util.ErrorCodes;
import com.ng.sb.common.util.ExceptionUtils;
import com.ng.sb.common.util.KeyEncryptionUtils;
import com.ng.transaction.dao.ITransactionDAO;
import com.ng.transaction.data.BankingRequest;
import com.ng.transaction.data.ProviderDetails;
import com.ng.transaction.data.TxnHistoryData;
import com.ng.transaction.service.ITransactionService;
import com.ng.transaction.service.impl.CacheLoader;
import com.ng.transaction.util.CommonUtils;

/**
 * @author gopal
 *
 */
@RestController
@RequestMapping("Transaction/services/banking/")
public class BankingController 
{
	private static final Logger LOGGER = LoggerFactory.getLogger(BankingController.class);
	
	@Autowired
    private MemCacheManager cacheManager;
	
	@Autowired
	ITransactionService transactionService;
	
	@Autowired
	CacheLoader cacheLoader;
	
	@Autowired
	ITransactionDAO transactionDAO;
	
	@RequestMapping(value = "/balanceEnquiry", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	 public @ResponseBody ResponseObject balanceEnquiry(@RequestBody RequestObject requestObject, HttpServletRequest request) 
	 {
		 LOGGER.info("************* balanceEnquiry() starts executing in BankingController **************");
		 ResponseObject responseObject = new ResponseObject();
		 
		 BridgeDataObject bridgeData = new BridgeDataObject();
			/* 
			 * Get Agent details from tokenId
			 * requestObject.getTokenId()
			 * 
			 */
		 	BankingRequest bankingRequest = null;
			Object payload =  requestObject.getPayload();
			UserAccountData accountData = null;
			try
			{
				//Check token Validity
				accountData = cacheManager.getFromCache(requestObject.getTokenId(), UserAccountData.class, MemCacheUtils.AUTHTOKENCACHE);
				
				responseObject = CommonUtils.validateRequest(accountData, requestObject, request);
				
				if(responseObject.getStatus() != null)
					return responseObject;
				
				bankingRequest = KeyEncryptionUtils.jsonStringToObject(KeyEncryptionUtils.decryptUsingKey(accountData.getSecretKey(), payload), BankingRequest.class);
				
				responseObject = CommonUtils.validateRequestData(bankingRequest, requestObject, request);
				  
				if(responseObject.getStatus() != null)
					return responseObject;
				  
				Map<HostSubVersionData, HostSubVersionData>  hostSubVersionMap = cacheLoader.getHostSubVersionMap();
				HostSubVersionData hostSubVersionData = hostSubVersionMap.get(new HostSubVersionData(1));

				
				TransactionData transactionData = CommonUtils.getTransactionData(accountData);
				
				bridgeData.setServiceType(ServiceType.BANKING_CHECK_BAL);
				
				bridgeData = CommonUtils.setBankDetails(bridgeData, bankingRequest);
				
				bridgeData.setHostSubVersionData(hostSubVersionData);
				
				bridgeData.setTransactionData(transactionData);
				
				bridgeData = transactionService.callService(bridgeData);
				
				String responseMsg = null;
				
				if(bridgeData.getBridgeResponse() != null)
					responseMsg = bridgeData.getBridgeResponse().getResponseMsg();
				
				responseObject = CommonUtils.setStatusCode(bridgeData.getBridgeResponse(),responseObject);
				
				responseObject.setMessage(responseMsg);
				
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), "com.ng");
			
			//UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			responseObject.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseObject.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e.getMessage());
		}
		return responseObject;
	 }

	
	@RequestMapping(value = "/fundTransferBtB", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	 public @ResponseBody ResponseObject fundTransferBankToBank(@RequestBody RequestObject requestObject, HttpServletRequest request) 
	 {
		 LOGGER.info("************* fundTransferBankToBank() starts executing in BankingController **************");
		 ResponseObject responseObject = new ResponseObject();
		 
		 BridgeDataObject bridgeData = new BridgeDataObject();
			/* 
			 * Get Agent details from tokenId
			 * requestObject.getTokenId()
			 * 
			 */
		 	BankingRequest bankingRequest = null;
			Object payload =  requestObject.getPayload();
			UserAccountData accountData = null;
			try
			{
				//Check token Validity
				accountData = cacheManager.getFromCache(requestObject.getTokenId(), UserAccountData.class, MemCacheUtils.AUTHTOKENCACHE);
				
				responseObject = CommonUtils.validateRequest(accountData, requestObject, request);
				
				if(responseObject.getStatus() != null)
					return responseObject;
				
				bankingRequest = KeyEncryptionUtils.jsonStringToObject(KeyEncryptionUtils.decryptUsingKey(accountData.getSecretKey(), payload), BankingRequest.class);
				
				responseObject = CommonUtils.validateRequestData(bankingRequest, requestObject, request);
				  
				if(responseObject.getStatus() != null)
					return responseObject;
				  
				Map<HostSubVersionData, HostSubVersionData>  hostSubVersionMap = cacheLoader.getHostSubVersionMap();
				HostSubVersionData hostSubVersionData = hostSubVersionMap.get(new HostSubVersionData(1));

				
				TransactionData transactionData = CommonUtils.getTransactionData(accountData);
				
				bridgeData.setServiceType(ServiceType.BANKING_FT_B_TO_B);
				
				bridgeData = CommonUtils.setBankDetails(bridgeData, bankingRequest);
				
				bridgeData.setHostSubVersionData(hostSubVersionData);
				
				bridgeData.setTransactionData(transactionData);
				
				bridgeData = transactionService.callService(bridgeData);
				
				String responseMsg = null;
				
				if(bridgeData.getBridgeResponse() != null)
					responseMsg = bridgeData.getBridgeResponse().getResponseMsg();
				
				responseObject = CommonUtils.setStatusCode(bridgeData.getBridgeResponse(),responseObject);
				
				responseObject.setMessage(responseMsg);
				
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), "com.ng");
			
			//UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			responseObject.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseObject.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e.getMessage());
		}
		return responseObject;
	 }
	
	@RequestMapping(value = "/fundTransferBtW", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	 public @ResponseBody ResponseObject fundTransferBankToWallet(@RequestBody RequestObject requestObject, HttpServletRequest request) 
	 {
		 LOGGER.info("************* balanceEnquiry() starts executing in BankingController **************");
		 ResponseObject responseObject = new ResponseObject();
		 
		 BridgeDataObject bridgeData = new BridgeDataObject();
			/* 
			 * Get Agent details from tokenId
			 * requestObject.getTokenId()
			 * 
			 */
		 	BankingRequest bankingRequest = null;
			Object payload =  requestObject.getPayload();
			UserAccountData accountData = null;
			try
			{
				//Check token Validity
				accountData = cacheManager.getFromCache(requestObject.getTokenId(), UserAccountData.class, MemCacheUtils.AUTHTOKENCACHE);
				
				responseObject = CommonUtils.validateRequest(accountData, requestObject, request);
				
				if(responseObject.getStatus() != null)
					return responseObject;
				
				bankingRequest = KeyEncryptionUtils.jsonStringToObject(KeyEncryptionUtils.decryptUsingKey(accountData.getSecretKey(), payload), BankingRequest.class);
				
				responseObject = CommonUtils.validateRequestData(bankingRequest, requestObject, request);
				  
				if(responseObject.getStatus() != null)
					return responseObject;
				  
				Map<HostSubVersionData, HostSubVersionData>  hostSubVersionMap = cacheLoader.getHostSubVersionMap();
				HostSubVersionData hostSubVersionData = hostSubVersionMap.get(new HostSubVersionData(1));

				
				TransactionData transactionData = CommonUtils.getTransactionData(accountData);
				
				bridgeData.setServiceType(ServiceType.BANKING_FT_B_TO_WALLET);
				
				bridgeData = CommonUtils.setBankDetails(bridgeData, bankingRequest);
				
				bridgeData.setHostSubVersionData(hostSubVersionData);
				
				bridgeData.setTransactionData(transactionData);
				
				bridgeData = transactionService.callService(bridgeData);
				
				String responseMsg = null;
				
				if(bridgeData.getBridgeResponse() != null)
					responseMsg = bridgeData.getBridgeResponse().getResponseMsg();
				
				responseObject = CommonUtils.setStatusCode(bridgeData.getBridgeResponse(),responseObject);
				
				responseObject.setMessage(responseMsg);
				
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), "com.ng");
			
			//UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			responseObject.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseObject.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e.getMessage());
		}
		return responseObject;
	 }
	
	 @RequestMapping(value = "/chequeBookRequest", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	 public @ResponseBody ResponseObject chequeBookRequest(@RequestBody RequestObject requestObject, HttpServletRequest request) 
	 {
		 LOGGER.info("************* chequeBookRequest() starts executing in BankingController **************");
		 ResponseObject responseObject = new ResponseObject();
		 
		 BridgeDataObject bridgeData = new BridgeDataObject();
			/* 
			 * Get Agent details from tokenId
			 * requestObject.getTokenId()
			 * 
			 */
		 	BankingRequest bankingRequest = null;
			Object payload =  requestObject.getPayload();
			UserAccountData accountData = null;
			try
			{
				//Check token Validity
				accountData = cacheManager.getFromCache(requestObject.getTokenId(), UserAccountData.class, MemCacheUtils.AUTHTOKENCACHE);
				
				responseObject = CommonUtils.validateRequest(accountData, requestObject, request);
				
				if(responseObject.getStatus() != null)
					return responseObject;
				
				bankingRequest = KeyEncryptionUtils.jsonStringToObject(KeyEncryptionUtils.decryptUsingKey(accountData.getSecretKey(), payload), BankingRequest.class);
				
				responseObject = CommonUtils.validateRequestData(bankingRequest, requestObject, request);
				  
				if(responseObject.getStatus() != null)
					return responseObject;
				  
				Map<HostSubVersionData, HostSubVersionData>  hostSubVersionMap = cacheLoader.getHostSubVersionMap();
				HostSubVersionData hostSubVersionData = hostSubVersionMap.get(new HostSubVersionData(1));

				
				TransactionData transactionData = CommonUtils.getTransactionData(accountData);
				
				bridgeData.setServiceType(ServiceType.BANKING_CHQ_BOOK_REQUEST);
				
				bridgeData = CommonUtils.setBankDetails(bridgeData, bankingRequest);
				
				bridgeData.setHostSubVersionData(hostSubVersionData);
				
				bridgeData.setTransactionData(transactionData);
				
				bridgeData = transactionService.callService(bridgeData);
				
				String responseMsg = null;
				
				if(bridgeData.getBridgeResponse() != null)
					responseMsg = bridgeData.getBridgeResponse().getResponseMsg();
				
				responseObject = CommonUtils.setStatusCode(bridgeData.getBridgeResponse(),responseObject);
				
				responseObject.setMessage(responseMsg);
				
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), "com.ng");
			
			//UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			responseObject.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseObject.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e.getMessage());
		}
		return responseObject;
	 }
	
	 @RequestMapping(value = "/chequeStatus", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	 public @ResponseBody ResponseObject chequeStatus(@RequestBody RequestObject requestObject, HttpServletRequest request) 
	 {
		 LOGGER.info("************* chequeStatus() starts executing in BankingController **************");
		 ResponseObject responseObject = new ResponseObject();
		 
		 BridgeDataObject bridgeData = new BridgeDataObject();
			/* 
			 * Get Agent details from tokenId
			 * requestObject.getTokenId()
			 * 
			 */
		 	BankingRequest bankingRequest = null;
			Object payload =  requestObject.getPayload();
			UserAccountData accountData = null;
			try
			{
				//Check token Validity
				accountData = cacheManager.getFromCache(requestObject.getTokenId(), UserAccountData.class, MemCacheUtils.AUTHTOKENCACHE);
				
				responseObject = CommonUtils.validateRequest(accountData, requestObject, request);
				
				if(responseObject.getStatus() != null)
					return responseObject;
				
				bankingRequest = KeyEncryptionUtils.jsonStringToObject(KeyEncryptionUtils.decryptUsingKey(accountData.getSecretKey(), payload), BankingRequest.class);
				
				responseObject = CommonUtils.validateRequestData(bankingRequest, requestObject, request);
				  
				if(responseObject.getStatus() != null)
					return responseObject;
				  
				Map<HostSubVersionData, HostSubVersionData>  hostSubVersionMap = cacheLoader.getHostSubVersionMap();
				HostSubVersionData hostSubVersionData = hostSubVersionMap.get(new HostSubVersionData(1));

				
				TransactionData transactionData = CommonUtils.getTransactionData(accountData);
				
				bridgeData.setServiceType(ServiceType.BANKING_CHQ_STATUS);
				
				bridgeData = CommonUtils.setBankDetails(bridgeData, bankingRequest);
				
				bridgeData.setHostSubVersionData(hostSubVersionData);
				
				bridgeData.setTransactionData(transactionData);
				
				bridgeData = transactionService.callService(bridgeData);
				
				String responseMsg = null;
				
				if(bridgeData.getBridgeResponse() != null)
					responseMsg = bridgeData.getBridgeResponse().getResponseMsg();
				
				responseObject = CommonUtils.setStatusCode(bridgeData.getBridgeResponse(),responseObject);
				
				responseObject.setMessage(responseMsg);
				
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), "com.ng");
			
			//UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			responseObject.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseObject.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e.getMessage());
		}
		return responseObject;
	 }
	 
	 @RequestMapping(value = "/stopCheque", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	 public @ResponseBody ResponseObject stopCheque(@RequestBody RequestObject requestObject, HttpServletRequest request) 
	 {
		 LOGGER.info("************* chequeStatus() starts executing in BankingController **************");
		 ResponseObject responseObject = new ResponseObject();
		 
		 BridgeDataObject bridgeData = new BridgeDataObject();
			/* 
			 * Get Agent details from tokenId
			 * requestObject.getTokenId()
			 * 
			 */
		 	BankingRequest bankingRequest = null;
			Object payload =  requestObject.getPayload();
			UserAccountData accountData = null;
			try
			{
				//Check token Validity
				accountData = cacheManager.getFromCache(requestObject.getTokenId(), UserAccountData.class, MemCacheUtils.AUTHTOKENCACHE);
				
				responseObject = CommonUtils.validateRequest(accountData, requestObject, request);
				
				if(responseObject.getStatus() != null)
					return responseObject;
				
				bankingRequest = KeyEncryptionUtils.jsonStringToObject(KeyEncryptionUtils.decryptUsingKey(accountData.getSecretKey(), payload), BankingRequest.class);
				
				responseObject = CommonUtils.validateRequestData(bankingRequest, requestObject, request);
				  
				if(responseObject.getStatus() != null)
					return responseObject;
				  
				Map<HostSubVersionData, HostSubVersionData>  hostSubVersionMap = cacheLoader.getHostSubVersionMap();
				HostSubVersionData hostSubVersionData = hostSubVersionMap.get(new HostSubVersionData(1));

				
				TransactionData transactionData = CommonUtils.getTransactionData(accountData);
				
				bridgeData.setServiceType(ServiceType.BANKING_STOP_CHEQUE);
				
				bridgeData = CommonUtils.setBankDetails(bridgeData, bankingRequest);
				
				bridgeData.setHostSubVersionData(hostSubVersionData);
				
				bridgeData.setTransactionData(transactionData);
				
				bridgeData = transactionService.callService(bridgeData);
				
				String responseMsg = null;
				
				if(bridgeData.getBridgeResponse() != null)
					responseMsg = bridgeData.getBridgeResponse().getResponseMsg();
				
				responseObject = CommonUtils.setStatusCode(bridgeData.getBridgeResponse(),responseObject);
				
				responseObject.setMessage(responseMsg);
				
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), "com.ng");
			
			//UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			responseObject.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseObject.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e.getMessage());
		}
		return responseObject;
	 }
	 
	 @RequestMapping(value = "/miniStatement", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	 public @ResponseBody ResponseObject miniStatement(@RequestBody RequestObject requestObject, HttpServletRequest request) 
	 {
		 LOGGER.info("************* miniStatement() starts executing in BankingController **************");
		 ResponseObject responseObject = new ResponseObject();
		 
		 BridgeDataObject bridgeData = new BridgeDataObject();
			/* 
			 * Get Agent details from tokenId
			 * requestObject.getTokenId()
			 * 
			 */
		 	BankingRequest bankingRequest = null;
			Object payload =  requestObject.getPayload();
			UserAccountData accountData = null;
			try
			{
				//Check token Validity
				accountData = cacheManager.getFromCache(requestObject.getTokenId(), UserAccountData.class, MemCacheUtils.AUTHTOKENCACHE);
				
				responseObject = CommonUtils.validateRequest(accountData, requestObject, request);
				
				if(responseObject.getStatus() != null)
					return responseObject;
				
				bankingRequest = KeyEncryptionUtils.jsonStringToObject(KeyEncryptionUtils.decryptUsingKey(accountData.getSecretKey(), payload), BankingRequest.class);
				
				responseObject = CommonUtils.validateRequestData(bankingRequest, requestObject, request);
				  
				if(responseObject.getStatus() != null)
					return responseObject;
				  
				Map<HostSubVersionData, HostSubVersionData>  hostSubVersionMap = cacheLoader.getHostSubVersionMap();
				HostSubVersionData hostSubVersionData = hostSubVersionMap.get(new HostSubVersionData(1));

				
				TransactionData transactionData = CommonUtils.getTransactionData(accountData);
				
				bridgeData.setServiceType(ServiceType.BANKING_LAST_5_TRANS);
				
				bridgeData = CommonUtils.setBankDetails(bridgeData, bankingRequest);
				
				bridgeData.setHostSubVersionData(hostSubVersionData);
				
				bridgeData.setTransactionData(transactionData);
				
				bridgeData = transactionService.callService(bridgeData);
				
				String responseMsg = null;
				
				if(bridgeData.getBridgeResponse() != null)
					responseMsg = bridgeData.getBridgeResponse().getResponseMsg();
				
				responseObject = CommonUtils.setStatusCode(bridgeData.getBridgeResponse(),responseObject);
				
				List<TxnHistoryData> txnHistory = getTxnHistoryData(responseMsg);
				
				if(txnHistory != null && responseObject.getStatus().intValue() == ErrorCodes.REQUEST_SUCCESSFUL.getCode().intValue())
				{
					String encryptedData = KeyEncryptionUtils.encryptUsingKey(accountData.getSecretKey(), txnHistory);
				 	responseObject.setPayload(encryptedData);
				}
				
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), "com.ng");
			
			//UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			responseObject.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseObject.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e.getMessage());
		}
		return responseObject;
	 }
	 
	 private List<TxnHistoryData> getTxnHistoryData(String responseMsg) 
	 {
		if(responseMsg == null || responseMsg.isEmpty())
			return null;
		
		List<TxnHistoryData>  historyData = new ArrayList<TxnHistoryData>();
		
		String[] lineData = responseMsg.split("\\n");
		
		
		
		for(int counter = 0;counter < 10 ; counter++)
		{
			
			String[] fieldData = lineData[counter].split("\\t");
		
			TxnHistoryData txnData = new TxnHistoryData();
			
			txnData.setTxnTime(fieldData[0]);
			txnData.setTxnNature(fieldData[1]);
			txnData.setOpeningBalance(fieldData[2]);
			txnData.setTxnAmount(fieldData[3]);
			txnData.setClosingBalance(fieldData[4]);
			txnData.setTxnDescription(fieldData[5]);
			
			historyData.add(txnData);
		}
		
		return historyData;
		
	}


	@RequestMapping(value = "/createBankingPin", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	 public @ResponseBody ResponseObject createBankingPin(@RequestBody RequestObject requestObject, HttpServletRequest request) 
	 {
		 LOGGER.info("************* createBankingPin() starts executing in BankingController **************");
		 ResponseObject responseObject = new ResponseObject();
		 
		 BridgeDataObject bridgeData = new BridgeDataObject();
			/* 
			 * Get Agent details from tokenId
			 * requestObject.getTokenId()
			 * 
			 */
		 	BankingRequest bankingRequest = null;
			Object payload =  requestObject.getPayload();
			UserAccountData accountData = null;
			try
			{
				//Check token Validity
				accountData = cacheManager.getFromCache(requestObject.getTokenId(), UserAccountData.class, MemCacheUtils.AUTHTOKENCACHE);
				
				responseObject = CommonUtils.validateRequest(accountData, requestObject, request);
				
				if(responseObject.getStatus() != null)
					return responseObject;
				
				bankingRequest = KeyEncryptionUtils.jsonStringToObject(KeyEncryptionUtils.decryptUsingKey(accountData.getSecretKey(), payload), BankingRequest.class);
				
				responseObject = CommonUtils.validateRequestData(bankingRequest, requestObject, request);
				  
				if(responseObject.getStatus() != null)
					return responseObject;
				  
				Map<HostSubVersionData, HostSubVersionData>  hostSubVersionMap = cacheLoader.getHostSubVersionMap();
				HostSubVersionData hostSubVersionData = hostSubVersionMap.get(new HostSubVersionData(1));

				
				TransactionData transactionData = CommonUtils.getTransactionData(accountData);
				
				bridgeData.setServiceType(ServiceType.SETTINGS_CREATE_PIN_TRANSACTION);
				
				bridgeData = CommonUtils.setBankDetails(bridgeData, bankingRequest);
				
				bridgeData.setHostSubVersionData(hostSubVersionData);
				
				bridgeData.setTransactionData(transactionData);
				
				bridgeData = transactionService.callService(bridgeData);
				
				String responseMsg = null;
				
				if(bridgeData.getBridgeResponse() != null)
					responseMsg = bridgeData.getBridgeResponse().getResponseMsg();
				
				responseObject = CommonUtils.setStatusCode(bridgeData.getBridgeResponse(),responseObject);
				
				responseObject.setMessage(responseMsg);
				
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), "com.ng");
			
			//UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			responseObject.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseObject.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e.getMessage());
		}
		return responseObject;
	 }
	 
	 @RequestMapping(value = "/changeBankingPin", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	 public @ResponseBody ResponseObject changeBankingPin(@RequestBody RequestObject requestObject, HttpServletRequest request) 
	 {
		 LOGGER.info("************* changeBankingPin() starts executing in BankingController **************");
		 ResponseObject responseObject = new ResponseObject();
		 
		 BridgeDataObject bridgeData = new BridgeDataObject();
			/* 
			 * Get Agent details from tokenId
			 * requestObject.getTokenId()
			 * 
			 */
		 	BankingRequest bankingRequest = null;
			Object payload =  requestObject.getPayload();
			UserAccountData accountData = null;
			try
			{
				//Check token Validity
				accountData = cacheManager.getFromCache(requestObject.getTokenId(), UserAccountData.class, MemCacheUtils.AUTHTOKENCACHE);
				
				responseObject = CommonUtils.validateRequest(accountData, requestObject, request);
				
				if(responseObject.getStatus() != null)
					return responseObject;
				
				bankingRequest = KeyEncryptionUtils.jsonStringToObject(KeyEncryptionUtils.decryptUsingKey(accountData.getSecretKey(), payload), BankingRequest.class);
				
				responseObject = CommonUtils.validateRequestData(bankingRequest, requestObject, request);
				  
				if(responseObject.getStatus() != null)
					return responseObject;
				  
				Map<HostSubVersionData, HostSubVersionData>  hostSubVersionMap = cacheLoader.getHostSubVersionMap();
				HostSubVersionData hostSubVersionData = hostSubVersionMap.get(new HostSubVersionData(1));

				
				TransactionData transactionData = CommonUtils.getTransactionData(accountData);
				
				bridgeData.setServiceType(ServiceType.SETTINGS_CHANGE_PIN_TRANSACTION);
				
				bridgeData = CommonUtils.setBankDetails(bridgeData, bankingRequest);
				
				bridgeData.setHostSubVersionData(hostSubVersionData);
				
				bridgeData.setTransactionData(transactionData);
				
				bridgeData = transactionService.callService(bridgeData);
				
				String responseMsg = null;
				
				if(bridgeData.getBridgeResponse() != null)
					responseMsg = bridgeData.getBridgeResponse().getResponseMsg();
				
				responseObject = CommonUtils.setStatusCode(bridgeData.getBridgeResponse(),responseObject);
				
				responseObject.setMessage(responseMsg);
				
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), "com.ng");
			
			//UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			responseObject.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseObject.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e.getMessage());
		}
		return responseObject;
	 }
	 
	 
	 
	 @RequestMapping(value = "/topUpByBank", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	 public @ResponseBody ResponseObject topUpByBank(@RequestBody RequestObject requestObject, HttpServletRequest request) 
	 {
		 LOGGER.info("************* changeBankingPin() starts executing in BankingController **************");
		 ResponseObject responseObject = new ResponseObject();
		 
		 BridgeDataObject bridgeData = new BridgeDataObject();
			/* 
			 * Get Agent details from tokenId
			 * requestObject.getTokenId()
			 * 
			 */
		 	BankingRequest topUpRequest = null;
			Object payload =  requestObject.getPayload();
			UserAccountData accountData = null;
			try
			{
				//Check token Validity
				accountData = cacheManager.getFromCache(requestObject.getTokenId(), UserAccountData.class, MemCacheUtils.AUTHTOKENCACHE);
				
				responseObject = CommonUtils.validateRequest(accountData, requestObject, request);
				
				if(responseObject.getStatus() != null)
					return responseObject;
				
				topUpRequest = KeyEncryptionUtils.jsonStringToObject(KeyEncryptionUtils.decryptUsingKey(accountData.getSecretKey(), payload), BankingRequest.class);
				
				responseObject = CommonUtils.validateRequestData(topUpRequest, requestObject, request);
				  
				if(responseObject.getStatus() != null)
					return responseObject;
				  
				Map<HostSubVersionData, HostSubVersionData>  hostSubVersionMap = cacheLoader.getHostSubVersionMap();
				HostSubVersionData hostSubVersionData = hostSubVersionMap.get(new HostSubVersionData(1));

				
				TransactionData transactionData = CommonUtils.getTransactionData(accountData);
				
				bridgeData.setServiceType(ServiceType.TOP_UP_RECH_BY_B);
				
				bridgeData = CommonUtils.setBankDetails(bridgeData, topUpRequest);
				
				bridgeData.setHostSubVersionData(hostSubVersionData);
				
				bridgeData.setTransactionData(transactionData);
				
				bridgeData = transactionService.callService(bridgeData);
				
				String responseMsg = null;
				
				if(bridgeData.getBridgeResponse() != null)
					responseMsg = bridgeData.getBridgeResponse().getResponseMsg();
				
				responseObject = CommonUtils.setStatusCode(bridgeData.getBridgeResponse(),responseObject);
				
				responseObject.setMessage(responseMsg);
				
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), "com.ng");
			
			//UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			responseObject.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseObject.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e.getMessage());
		}
		return responseObject;
	 }
	 
	 @RequestMapping(value = "/billPayByBank", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	 public @ResponseBody ResponseObject billPayByBank(@RequestBody RequestObject requestObject, HttpServletRequest request) 
	 {
		 LOGGER.info("************* changeBankingPin() starts executing in BankingController **************");
		 ResponseObject responseObject = new ResponseObject();
		 
		 BridgeDataObject bridgeData = new BridgeDataObject();
			/* 
			 * Get Agent details from tokenId
			 * requestObject.getTokenId()
			 * 
			 */
		 	BankingRequest topUpRequest = null;
			Object payload =  requestObject.getPayload();
			UserAccountData accountData = null;
			try
			{
				//Check token Validity
				accountData = cacheManager.getFromCache(requestObject.getTokenId(), UserAccountData.class, MemCacheUtils.AUTHTOKENCACHE);
				
				responseObject = CommonUtils.validateRequest(accountData, requestObject, request);
				
				if(responseObject.getStatus() != null)
					return responseObject;
				
				topUpRequest = KeyEncryptionUtils.jsonStringToObject(KeyEncryptionUtils.decryptUsingKey(accountData.getSecretKey(), payload), BankingRequest.class);
				
				responseObject = CommonUtils.validateRequestData(topUpRequest, requestObject, request);
				  
				if(responseObject.getStatus() != null)
					return responseObject;
				  
				Map<HostSubVersionData, HostSubVersionData>  hostSubVersionMap = cacheLoader.getHostSubVersionMap();
				HostSubVersionData hostSubVersionData = hostSubVersionMap.get(new HostSubVersionData(1));

				
				TransactionData transactionData = CommonUtils.getTransactionData(accountData);
				
				bridgeData.setServiceType(ServiceType.BILL_PAY_BY_B);
				
				bridgeData = CommonUtils.setBankDetails(bridgeData, topUpRequest);
				
				bridgeData.setHostSubVersionData(hostSubVersionData);
				
				bridgeData.setTransactionData(transactionData);
				
				bridgeData = transactionService.callService(bridgeData);
				
				String responseMsg = null;
				
				if(bridgeData.getBridgeResponse() != null)
					responseMsg = bridgeData.getBridgeResponse().getResponseMsg();
				
				responseObject = CommonUtils.setStatusCode(bridgeData.getBridgeResponse(),responseObject);
				
				responseObject.setMessage(responseMsg);
				
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), "com.ng");
			
			//UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			responseObject.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseObject.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e.getMessage());
		}
		return responseObject;
	 }
	 
	 @RequestMapping(value = "/addPayee", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	 public @ResponseBody ResponseObject addPayee(@RequestBody RequestObject requestObject, HttpServletRequest request) 
	 {
		 LOGGER.info("************* addPayee() starts executing in BankingController **************");
		 ResponseObject responseObject = new ResponseObject();
		 
		 BridgeDataObject bridgeData = new BridgeDataObject();
			/* 
			 * Get Agent details from tokenId
			 * requestObject.getTokenId()
			 * 
			 */
		 	PayeeDetails payeeRequest = null;
			Object payload =  requestObject.getPayload();
			UserAccountData accountData = null;
			try
			{
				//Check token Validity
				accountData = cacheManager.getFromCache(requestObject.getTokenId(), UserAccountData.class, MemCacheUtils.AUTHTOKENCACHE);
				
				responseObject = CommonUtils.validateRequest(accountData, requestObject, request);
				
				if(responseObject.getStatus() != null)
					return responseObject;
				
				payeeRequest = KeyEncryptionUtils.jsonStringToObject(KeyEncryptionUtils.decryptUsingKey(accountData.getSecretKey(), payload), PayeeDetails.class);
				
				responseObject = CommonUtils.validateRequestData(payeeRequest, requestObject, request);
				  
				if(responseObject.getStatus() != null)
					return responseObject;
				  
				Map<HostSubVersionData, HostSubVersionData>  hostSubVersionMap = cacheLoader.getHostSubVersionMap();
				HostSubVersionData hostSubVersionData = hostSubVersionMap.get(new HostSubVersionData(1));

				
				TransactionData transactionData = CommonUtils.getTransactionData(accountData);
				
				bridgeData.setServiceType(ServiceType.SETTINGS_MY_PAYEE_ADD);
				
				bridgeData = CommonUtils.setPayeeDetails(bridgeData, payeeRequest);
				
				bridgeData.setHostSubVersionData(hostSubVersionData);
				
				bridgeData.setTransactionData(transactionData);
				
				bridgeData = transactionService.callService(bridgeData);
				
				String responseMsg = null;
				
				if(bridgeData.getBridgeResponse() != null)
					responseMsg = bridgeData.getBridgeResponse().getResponseMsg();
				
				responseObject = CommonUtils.setStatusCode(bridgeData.getBridgeResponse(),responseObject);
				
				responseObject.setMessage(responseMsg);
				
				if(responseObject.getStatus().intValue() == ErrorCodes.REQUEST_SUCCESSFUL.getCode().intValue())
				{
					List<PayeeDetails> payees = transactionDAO.getPayeeList(accountData.getMobileNo());
					
					if(payees != null && !payees.isEmpty())
					{
						CustomerAccountData customerData = new CustomerAccountData();
						
						customerData.setPayeeData(payees);
						
						 String encryptedData = KeyEncryptionUtils.encryptUsingKey(accountData.getSecretKey(), customerData);
						 
						 responseObject.setPayload(encryptedData);
						
					}
				}
				
				
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), "com.ng");
			
			//UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			responseObject.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseObject.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e.getMessage());
		}
		return responseObject;
	 }
	 
	 @RequestMapping(value = "/editPayee", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	 public @ResponseBody ResponseObject editPayee(@RequestBody RequestObject requestObject, HttpServletRequest request) 
	 {
		 LOGGER.info("************* editPayee() starts executing in BankingController **************");
		 ResponseObject responseObject = new ResponseObject();
		 
		 BridgeDataObject bridgeData = new BridgeDataObject();
			/* 
			 * Get Agent details from tokenId
			 * requestObject.getTokenId()
			 * 
			 */
		 	PayeeDetails payeeRequest = null;
			Object payload =  requestObject.getPayload();
			UserAccountData accountData = null;
			try
			{
				//Check token Validity
				accountData = cacheManager.getFromCache(requestObject.getTokenId(), UserAccountData.class, MemCacheUtils.AUTHTOKENCACHE);
				
				responseObject = CommonUtils.validateRequest(accountData, requestObject, request);
				
				if(responseObject.getStatus() != null)
					return responseObject;
				
				payeeRequest = KeyEncryptionUtils.jsonStringToObject(KeyEncryptionUtils.decryptUsingKey(accountData.getSecretKey(), payload), PayeeDetails.class);
				
				responseObject = CommonUtils.validateRequestData(payeeRequest, requestObject, request);
				  
				if(responseObject.getStatus() != null)
					return responseObject;
				  
				Map<HostSubVersionData, HostSubVersionData>  hostSubVersionMap = cacheLoader.getHostSubVersionMap();
				HostSubVersionData hostSubVersionData = hostSubVersionMap.get(new HostSubVersionData(1));

				
				TransactionData transactionData = CommonUtils.getTransactionData(accountData);
				
				bridgeData.setServiceType(ServiceType.SETTINGS_MY_PAYEE_EDIT);
				
				bridgeData = CommonUtils.setPayeeDetails(bridgeData, payeeRequest);
				
				bridgeData.setHostSubVersionData(hostSubVersionData);
				
				bridgeData.setTransactionData(transactionData);
				
				bridgeData = transactionService.callService(bridgeData);
				
				String responseMsg = null;
				
				if(bridgeData.getBridgeResponse() != null)
					responseMsg = bridgeData.getBridgeResponse().getResponseMsg();
				
				responseObject = CommonUtils.setStatusCode(bridgeData.getBridgeResponse(),responseObject);
				
				responseObject.setMessage(responseMsg);
				
				if(responseObject.getStatus().intValue() == ErrorCodes.REQUEST_SUCCESSFUL.getCode().intValue())
				{
					List<PayeeDetails> payees = transactionDAO.getPayeeList(accountData.getMobileNo());
					
					if(payees != null && !payees.isEmpty())
					{
						CustomerAccountData customerData = new CustomerAccountData();
						
						customerData.setPayeeData(payees);
						
						 String encryptedData = KeyEncryptionUtils.encryptUsingKey(accountData.getSecretKey(), customerData);
						 
						 responseObject.setPayload(encryptedData);
						
					}
				}
				
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), "com.ng");
			
			//UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			responseObject.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseObject.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e.getMessage());
		}
		return responseObject;
	 }
	 
	 
	 @RequestMapping(value = "/deletePayee", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	 public @ResponseBody ResponseObject deletePayee(@RequestBody RequestObject requestObject, HttpServletRequest request) 
	 {
		 LOGGER.info("************* deletePayee() starts executing in BankingController **************");
		 ResponseObject responseObject = new ResponseObject();
		 
		 BridgeDataObject bridgeData = new BridgeDataObject();
			/* 
			 * Get Agent details from tokenId
			 * requestObject.getTokenId()
			 * 
			 */
		 	PayeeDetails payeeRequest = null;
			Object payload =  requestObject.getPayload();
			UserAccountData accountData = null;
			try
			{
				//Check token Validity
				accountData = cacheManager.getFromCache(requestObject.getTokenId(), UserAccountData.class, MemCacheUtils.AUTHTOKENCACHE);
				
				responseObject = CommonUtils.validateRequest(accountData, requestObject, request);
				
				if(responseObject.getStatus() != null)
					return responseObject;
				
				payeeRequest = KeyEncryptionUtils.jsonStringToObject(KeyEncryptionUtils.decryptUsingKey(accountData.getSecretKey(), payload), PayeeDetails.class);
				
				responseObject = CommonUtils.validateRequestData(payeeRequest, requestObject, request);
				  
				if(responseObject.getStatus() != null)
					return responseObject;
				  
				Map<HostSubVersionData, HostSubVersionData>  hostSubVersionMap = cacheLoader.getHostSubVersionMap();
				HostSubVersionData hostSubVersionData = hostSubVersionMap.get(new HostSubVersionData(1));

				
				TransactionData transactionData = CommonUtils.getTransactionData(accountData);
				
				bridgeData.setServiceType(ServiceType.SETTINGS_MY_PAYEE_DELETE);
				
				bridgeData = CommonUtils.setPayeeDetails(bridgeData, payeeRequest);
				
				bridgeData.setHostSubVersionData(hostSubVersionData);
				
				bridgeData.setTransactionData(transactionData);
				
				bridgeData = transactionService.callService(bridgeData);
				
				String responseMsg = null;
				
				if(bridgeData.getBridgeResponse() != null)
					responseMsg = bridgeData.getBridgeResponse().getResponseMsg();
				
				responseObject = CommonUtils.setStatusCode(bridgeData.getBridgeResponse(),responseObject);
				
				responseObject.setMessage(responseMsg);
				
				if(responseObject.getStatus().intValue() == ErrorCodes.REQUEST_SUCCESSFUL.getCode().intValue())
				{
					List<PayeeDetails> payees = transactionDAO.getPayeeList(accountData.getMobileNo());
					
					if(payees != null && !payees.isEmpty())
					{
						CustomerAccountData customerData = new CustomerAccountData();
						
						customerData.setPayeeData(payees);
						
						 String encryptedData = KeyEncryptionUtils.encryptUsingKey(accountData.getSecretKey(), customerData);
						 
						 responseObject.setPayload(encryptedData);
						
					}
				}
				
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), "com.ng");
			
			//UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			responseObject.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseObject.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e.getMessage());
		}
		return responseObject;
	 }
	 
	 
	 @RequestMapping(value = "/getPayees", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	 public @ResponseBody ResponseObject getPayees(@RequestBody RequestObject requestObject, HttpServletRequest request) 
	 {
		 LOGGER.info("************* addPayee() starts executing in BankingController **************");
		 ResponseObject responseObject = new ResponseObject();
		 
		 BridgeDataObject bridgeData = new BridgeDataObject();
			/* 
			 * Get Agent details from tokenId
			 * requestObject.getTokenId()
			 * 
			 */
		 	
			UserAccountData accountData = null;
			try
			{
				//Check token Validity
				accountData = cacheManager.getFromCache(requestObject.getTokenId(), UserAccountData.class, MemCacheUtils.AUTHTOKENCACHE);
				
				responseObject = CommonUtils.validateRequest(accountData, requestObject, request);
				
				if(responseObject.getStatus() != null)
					return responseObject;
				
				List<PayeeDetails> payees = transactionDAO.getPayeeList(accountData.getMobileNo());
				
				if(payees != null && !payees.isEmpty())
				{
					responseObject.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
					responseObject.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
					
					CustomerAccountData customerData = new CustomerAccountData();
					
					customerData.setPayeeData(payees);
					
					 String encryptedData = KeyEncryptionUtils.encryptUsingKey(accountData.getSecretKey(), customerData);
					 
					 responseObject.setPayload(encryptedData);
					
				}else{
					responseObject.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
					responseObject.setMessage(ErrorCodes.NO_RECORDS_FOUND.getMessage());
				}
				
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), "com.ng");
			
			//UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			responseObject.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseObject.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e.getMessage());
		}
		return responseObject;
	 }
	 
	 @RequestMapping(value = "/addBiller", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	 public @ResponseBody ResponseObject addBiller(@RequestBody RequestObject requestObject, HttpServletRequest request) 
	 {
		 LOGGER.info("************* addBiller() starts executing in BankingController **************");
		 ResponseObject responseObject = new ResponseObject();
		 
		 BridgeDataObject bridgeData = new BridgeDataObject();
			/* 
			 * Get Agent details from tokenId
			 * requestObject.getTokenId()
			 * 
			 */
		 CustomerPreferredBiller  custPrefBiller = null;
		 Object payload =  requestObject.getPayload();
		 UserAccountData accountData = null;
		
		 try
			{
			 
			//Check token Validity
				accountData = cacheManager.getFromCache(requestObject.getTokenId(), UserAccountData.class, MemCacheUtils.AUTHTOKENCACHE);
				
				responseObject = CommonUtils.validateRequest(accountData, requestObject, request);
				
				if(responseObject.getStatus() != null)
					return responseObject;
				
				custPrefBiller = KeyEncryptionUtils.jsonStringToObject(KeyEncryptionUtils.decryptUsingKey(accountData.getSecretKey(), payload), CustomerPreferredBiller.class);
				
				responseObject = CommonUtils.validateRequestData(custPrefBiller, requestObject, request);
				  
				if(responseObject.getStatus() != null)
					return responseObject;
				  
				Map<HostSubVersionData, HostSubVersionData>  hostSubVersionMap = cacheLoader.getHostSubVersionMap();
				HostSubVersionData hostSubVersionData = hostSubVersionMap.get(new HostSubVersionData(1));

				CategoryProviderMapping catgProviderInfo = transactionDAO.getCategoryProviderInfo(custPrefBiller.getBillerId());
				
				custPrefBiller.setBillerCategoryId(catgProviderInfo.getCategory().getCategoryCode());
				
				
				TransactionData transactionData = CommonUtils.getTransactionData(accountData);
				
				bridgeData.setServiceType(ServiceType.SETTINGS_MY_BILLER_ADD);
				
				bridgeData = CommonUtils.setBillerDetails(bridgeData, custPrefBiller);
				
				bridgeData.setHostSubVersionData(hostSubVersionData);
				
				bridgeData.setTransactionData(transactionData);
				
				bridgeData = transactionService.callService(bridgeData);
				
				String responseMsg = null;
				
				if(bridgeData.getBridgeResponse() != null)
					responseMsg = bridgeData.getBridgeResponse().getResponseMsg();
				
				responseObject = CommonUtils.setStatusCode(bridgeData.getBridgeResponse(),responseObject);
				
				responseObject.setMessage(responseMsg);
			 
				if(responseObject.getStatus().intValue() == ErrorCodes.REQUEST_SUCCESSFUL.getCode().intValue())
				{
					List<CustomerPreferredBiller> billers = transactionDAO.getBillerList(accountData.getMobileNo());
					
					if(billers != null && !billers.isEmpty())
					{
						CustomerAccountData customerData = new CustomerAccountData();
						
						customerData.setBillerData(billers);
						
						 String encryptedData = KeyEncryptionUtils.encryptUsingKey(accountData.getSecretKey(), customerData);
						 
						 responseObject.setPayload(encryptedData);
						
					}
				}
			}catch(Exception e)
			{
				String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), "com.ng");
				
				//UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
				
				responseObject.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
				responseObject.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e.getMessage());
			}
			return responseObject;
	 }
	 
	 @RequestMapping(value = "/editBiller", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	 public @ResponseBody ResponseObject editBiller(@RequestBody RequestObject requestObject, HttpServletRequest request) 
	 {
		 LOGGER.info("************* editBiller() starts executing in BankingController **************");
		 ResponseObject responseObject = new ResponseObject();
		 
		 BridgeDataObject bridgeData = new BridgeDataObject();
			/* 
			 * Get Agent details from tokenId
			 * requestObject.getTokenId()
			 * 
			 */
		    CustomerPreferredBiller  custPrefBiller = null;
			Object payload =  requestObject.getPayload();
			UserAccountData accountData = null;
			try
			{
				//Check token Validity
				accountData = cacheManager.getFromCache(requestObject.getTokenId(), UserAccountData.class, MemCacheUtils.AUTHTOKENCACHE);
				
				responseObject = CommonUtils.validateRequest(accountData, requestObject, request);
				
				if(responseObject.getStatus() != null)
					return responseObject;
				
				custPrefBiller = KeyEncryptionUtils.jsonStringToObject(KeyEncryptionUtils.decryptUsingKey(accountData.getSecretKey(), payload), CustomerPreferredBiller.class);
				
				responseObject = CommonUtils.validateRequestData(custPrefBiller, requestObject, request);
				  
				if(responseObject.getStatus() != null)
					return responseObject;
				  
				Map<HostSubVersionData, HostSubVersionData>  hostSubVersionMap = cacheLoader.getHostSubVersionMap();
				HostSubVersionData hostSubVersionData = hostSubVersionMap.get(new HostSubVersionData(1));

				CategoryProviderMapping catgProviderInfo = transactionDAO.getCategoryProviderInfo(custPrefBiller.getBillerId());
				
				custPrefBiller.setBillerCategoryId(catgProviderInfo.getCategory().getCategoryCode());
				
				
				TransactionData transactionData = CommonUtils.getTransactionData(accountData);
				
				bridgeData.setServiceType(ServiceType.SETTINGS_MY_BILLER_EDIT);
				
				bridgeData = CommonUtils.setBillerDetails(bridgeData, custPrefBiller);
				
				bridgeData.setHostSubVersionData(hostSubVersionData);
				
				bridgeData.setTransactionData(transactionData);
				
				bridgeData = transactionService.callService(bridgeData);
				
				String responseMsg = null;
				
				if(bridgeData.getBridgeResponse() != null)
					responseMsg = bridgeData.getBridgeResponse().getResponseMsg();
				
				responseObject = CommonUtils.setStatusCode(bridgeData.getBridgeResponse(),responseObject);
				
				responseObject.setMessage(responseMsg);
				
				if(responseObject.getStatus().intValue() == ErrorCodes.REQUEST_SUCCESSFUL.getCode().intValue())
				{
					List<CustomerPreferredBiller> billers = transactionDAO.getBillerList(accountData.getMobileNo());
					
					if(billers != null && !billers.isEmpty())
					{
						CustomerAccountData customerData = new CustomerAccountData();
						
						customerData.setBillerData(billers);
						
						 String encryptedData = KeyEncryptionUtils.encryptUsingKey(accountData.getSecretKey(), customerData);
						 
						 responseObject.setPayload(encryptedData);
						
					}
				}
				
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), "com.ng");
			
			//UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			responseObject.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseObject.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e.getMessage());
		}
		return responseObject;
	 }
	 
	 @RequestMapping(value = "/deleteBiller", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	 public @ResponseBody ResponseObject deleteBiller(@RequestBody RequestObject requestObject, HttpServletRequest request) 
	 {
		 LOGGER.info("************* deleteBiller() starts executing in BankingController **************");
		 ResponseObject responseObject = new ResponseObject();
		 
		 BridgeDataObject bridgeData = new BridgeDataObject();
			/* 
			 * Get Agent details from tokenId
			 * requestObject.getTokenId()
			 * 
			 */
		    CustomerPreferredBiller  custPrefBiller = null;
			Object payload =  requestObject.getPayload();
			UserAccountData accountData = null;
			try
			{
				//Check token Validity
				accountData = cacheManager.getFromCache(requestObject.getTokenId(), UserAccountData.class, MemCacheUtils.AUTHTOKENCACHE);
				
				responseObject = CommonUtils.validateRequest(accountData, requestObject, request);
				
				if(responseObject.getStatus() != null)
					return responseObject;
				
				custPrefBiller = KeyEncryptionUtils.jsonStringToObject(KeyEncryptionUtils.decryptUsingKey(accountData.getSecretKey(), payload), CustomerPreferredBiller.class);
				
				responseObject = CommonUtils.validateRequestData(custPrefBiller, requestObject, request);
				  
				if(responseObject.getStatus() != null)
					return responseObject;
				  
				Map<HostSubVersionData, HostSubVersionData>  hostSubVersionMap = cacheLoader.getHostSubVersionMap();
				HostSubVersionData hostSubVersionData = hostSubVersionMap.get(new HostSubVersionData(1));

				
				TransactionData transactionData = CommonUtils.getTransactionData(accountData);
				
				bridgeData.setServiceType(ServiceType.SETTINGS_MY_BILLER_DELETE);
				
				bridgeData = CommonUtils.setBillerDetails(bridgeData, custPrefBiller);
				
				bridgeData.setHostSubVersionData(hostSubVersionData);
				
				bridgeData.setTransactionData(transactionData);
				
				bridgeData = transactionService.callService(bridgeData);
				
				String responseMsg = null;
				
				if(bridgeData.getBridgeResponse() != null)
					responseMsg = bridgeData.getBridgeResponse().getResponseMsg();
				
				responseObject = CommonUtils.setStatusCode(bridgeData.getBridgeResponse(),responseObject);
				
				responseObject.setMessage(responseMsg);
				
				if(responseObject.getStatus().intValue() == ErrorCodes.REQUEST_SUCCESSFUL.getCode().intValue())
				{
					List<CustomerPreferredBiller> billers = transactionDAO.getBillerList(accountData.getMobileNo());
					
					if(billers != null && !billers.isEmpty())
					{
						CustomerAccountData customerData = new CustomerAccountData();
						
						customerData.setBillerData(billers);
						
						 String encryptedData = KeyEncryptionUtils.encryptUsingKey(accountData.getSecretKey(), customerData);
						 
						 responseObject.setPayload(encryptedData);
						
					}
				}
				
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), "com.ng");
			
			//UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			responseObject.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseObject.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e.getMessage());
		}
		return responseObject;
	 }
	 
	 @RequestMapping(value = "/getBillers", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	 public @ResponseBody ResponseObject getBillers(@RequestBody RequestObject requestObject, HttpServletRequest request) 
	 {
		 LOGGER.info("************* getBillers() starts executing in BankingController **************");
		 ResponseObject responseObject = new ResponseObject();
		 
		 BridgeDataObject bridgeData = new BridgeDataObject();
			/* 
			 * Get Agent details from tokenId
			 * requestObject.getTokenId()
			 * 
			 */
		 	
			UserAccountData accountData = null;
			try
			{
				//Check token Validity
				accountData = cacheManager.getFromCache(requestObject.getTokenId(), UserAccountData.class, MemCacheUtils.AUTHTOKENCACHE);
				
				responseObject = CommonUtils.validateRequest(accountData, requestObject, request);
				
				if(responseObject.getStatus() != null)
					return responseObject;
				
				List<CustomerPreferredBiller> billers = transactionDAO.getBillerList(accountData.getMobileNo());
				
				if(billers != null && !billers.isEmpty())
				{
					responseObject.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
					responseObject.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
					
					CustomerAccountData customerData = new CustomerAccountData();
					
					customerData.setBillerData(billers);
					
					 String encryptedData = KeyEncryptionUtils.encryptUsingKey(accountData.getSecretKey(), customerData);
					 
					 responseObject.setPayload(encryptedData);
					
				}else{
					responseObject.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
					responseObject.setMessage(ErrorCodes.NO_RECORDS_FOUND.getMessage());
				}
				
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), "com.ng");
			
			//UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			responseObject.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseObject.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e.getMessage());
		}
		return responseObject;
	 }
	 
	 @RequestMapping(value = "/addMerchant", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	 public @ResponseBody ResponseObject addMerchant(@RequestBody RequestObject requestObject, HttpServletRequest request) 
	 {
		 LOGGER.info("************* addMerchant() starts executing in BankingController **************");
		 ResponseObject responseObject = new ResponseObject();
		 
		 BridgeDataObject bridgeData = new BridgeDataObject();
			/* 
			 * Get Agent details from tokenId
			 * requestObject.getTokenId()
			 * 
			 */
		    OverlayMerchants overlayMerchant = null;
			Object payload =  requestObject.getPayload();
			UserAccountData accountData = null;
			try
			{
				//Check token Validity
				accountData = cacheManager.getFromCache(requestObject.getTokenId(), UserAccountData.class, MemCacheUtils.AUTHTOKENCACHE);
				
				responseObject = CommonUtils.validateRequest(accountData, requestObject, request);
				
				if(responseObject.getStatus() != null)
					return responseObject;
				
				overlayMerchant = KeyEncryptionUtils.jsonStringToObject(KeyEncryptionUtils.decryptUsingKey(accountData.getSecretKey(), payload), OverlayMerchants.class);
				
				responseObject = CommonUtils.validateRequestData(overlayMerchant, requestObject, request);
				  
				if(responseObject.getStatus() != null)
					return responseObject;
				  
				Map<HostSubVersionData, HostSubVersionData>  hostSubVersionMap = cacheLoader.getHostSubVersionMap();
				HostSubVersionData hostSubVersionData = hostSubVersionMap.get(new HostSubVersionData(1));

				
				TransactionData transactionData = CommonUtils.getTransactionData(accountData);
				
				bridgeData.setServiceType(ServiceType.SETTINGS_MY_MERCHANT_ADD);
				
				bridgeData = CommonUtils.setMerchantDetails(bridgeData, overlayMerchant);
				
				bridgeData.setHostSubVersionData(hostSubVersionData);
				
				bridgeData.setTransactionData(transactionData);
				
				bridgeData = transactionService.callService(bridgeData);
				
				String responseMsg = null;
				
				if(bridgeData.getBridgeResponse() != null)
					responseMsg = bridgeData.getBridgeResponse().getResponseMsg();
				
				responseObject = CommonUtils.setStatusCode(bridgeData.getBridgeResponse(),responseObject);
				
				responseObject.setMessage(responseMsg);
				
				if(responseObject.getStatus().intValue() == ErrorCodes.REQUEST_SUCCESSFUL.getCode().intValue())
				{
					List<OverlayMerchants> merchants = transactionDAO.getMerchantList(accountData.getMobileNo());
					
					if(merchants != null && !merchants.isEmpty())
					{
						CustomerAccountData customerData = new CustomerAccountData();
						
						customerData.setMerchantData(merchants);
						
						 String encryptedData = KeyEncryptionUtils.encryptUsingKey(accountData.getSecretKey(), customerData);
						 
						 responseObject.setPayload(encryptedData);
						
					}
				}
				
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), "com.ng");
			
			//UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			responseObject.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseObject.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e.getMessage());
		}
		return responseObject;
	 }
	 
	 
	 @RequestMapping(value = "/editMerchant", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	 public @ResponseBody ResponseObject editMerchant(@RequestBody RequestObject requestObject, HttpServletRequest request) 
	 {
		 LOGGER.info("************* editMerchant() starts executing in BankingController **************");
		 ResponseObject responseObject = new ResponseObject();
		 
		 BridgeDataObject bridgeData = new BridgeDataObject();
			/* 
			 * Get Agent details from tokenId
			 * requestObject.getTokenId()
			 * 
			 */
		    OverlayMerchants overlayMerchant = null;
			Object payload =  requestObject.getPayload();
			UserAccountData accountData = null;
			try
			{
				//Check token Validity
				accountData = cacheManager.getFromCache(requestObject.getTokenId(), UserAccountData.class, MemCacheUtils.AUTHTOKENCACHE);
				
				responseObject = CommonUtils.validateRequest(accountData, requestObject, request);
				
				if(responseObject.getStatus() != null)
					return responseObject;
				
				overlayMerchant = KeyEncryptionUtils.jsonStringToObject(KeyEncryptionUtils.decryptUsingKey(accountData.getSecretKey(), payload), OverlayMerchants.class);
				
				responseObject = CommonUtils.validateRequestData(overlayMerchant, requestObject, request);
				  
				if(responseObject.getStatus() != null)
					return responseObject;
				  
				Map<HostSubVersionData, HostSubVersionData>  hostSubVersionMap = cacheLoader.getHostSubVersionMap();
				HostSubVersionData hostSubVersionData = hostSubVersionMap.get(new HostSubVersionData(1));

				
				TransactionData transactionData = CommonUtils.getTransactionData(accountData);
				
				bridgeData.setServiceType(ServiceType.SETTINGS_MY_MERCHANT_EDIT);
				
				bridgeData = CommonUtils.setMerchantDetails(bridgeData, overlayMerchant);
				
				bridgeData.setHostSubVersionData(hostSubVersionData);
				
				bridgeData.setTransactionData(transactionData);
				
				bridgeData = transactionService.callService(bridgeData);
				
				String responseMsg = null;
				
				if(bridgeData.getBridgeResponse() != null)
					responseMsg = bridgeData.getBridgeResponse().getResponseMsg();
				
				responseObject = CommonUtils.setStatusCode(bridgeData.getBridgeResponse(),responseObject);
				
				responseObject.setMessage(responseMsg);
				
				if(responseObject.getStatus().intValue() == ErrorCodes.REQUEST_SUCCESSFUL.getCode().intValue())
				{
					List<OverlayMerchants> merchants = transactionDAO.getMerchantList(accountData.getMobileNo());
					
					if(merchants != null && !merchants.isEmpty())
					{
						CustomerAccountData customerData = new CustomerAccountData();
						
						customerData.setMerchantData(merchants);
						
						 String encryptedData = KeyEncryptionUtils.encryptUsingKey(accountData.getSecretKey(), customerData);
						 
						 responseObject.setPayload(encryptedData);
						
					}
				}
				
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), "com.ng");
			
			//UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			responseObject.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseObject.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e.getMessage());
		}
		return responseObject;
	 }
	 
	 @RequestMapping(value = "/deleteMerchant", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	 public @ResponseBody ResponseObject deleteMerchant(@RequestBody RequestObject requestObject, HttpServletRequest request) 
	 {
		 LOGGER.info("************* deleteMerchant() starts executing in BankingController **************");
		 ResponseObject responseObject = new ResponseObject();
		 
		 BridgeDataObject bridgeData = new BridgeDataObject();
			/* 
			 * Get Agent details from tokenId
			 * requestObject.getTokenId()
			 * 
			 */
		    OverlayMerchants overlayMerchant = null;
			Object payload =  requestObject.getPayload();
			UserAccountData accountData = null;
			try
			{
				//Check token Validity
				accountData = cacheManager.getFromCache(requestObject.getTokenId(), UserAccountData.class, MemCacheUtils.AUTHTOKENCACHE);
				
				responseObject = CommonUtils.validateRequest(accountData, requestObject, request);
				
				if(responseObject.getStatus() != null)
					return responseObject;
				
				overlayMerchant = KeyEncryptionUtils.jsonStringToObject(KeyEncryptionUtils.decryptUsingKey(accountData.getSecretKey(), payload), OverlayMerchants.class);
				
				responseObject = CommonUtils.validateRequestData(overlayMerchant, requestObject, request);
				  
				if(responseObject.getStatus() != null)
					return responseObject;
				  
				Map<HostSubVersionData, HostSubVersionData>  hostSubVersionMap = cacheLoader.getHostSubVersionMap();
				HostSubVersionData hostSubVersionData = hostSubVersionMap.get(new HostSubVersionData(1));

				
				TransactionData transactionData = CommonUtils.getTransactionData(accountData);
				
				bridgeData.setServiceType(ServiceType.SETTINGS_MY_MERCHANT_DELETE);
				
				bridgeData = CommonUtils.setMerchantDetails(bridgeData, overlayMerchant);
				
				bridgeData.setHostSubVersionData(hostSubVersionData);
				
				bridgeData.setTransactionData(transactionData);
				
				bridgeData = transactionService.callService(bridgeData);
				
				String responseMsg = null;
				
				if(bridgeData.getBridgeResponse() != null)
					responseMsg = bridgeData.getBridgeResponse().getResponseMsg();
				
				responseObject = CommonUtils.setStatusCode(bridgeData.getBridgeResponse(),responseObject);
				
				responseObject.setMessage(responseMsg);
				
				if(responseObject.getStatus().intValue() == ErrorCodes.REQUEST_SUCCESSFUL.getCode().intValue())
				{
					List<OverlayMerchants> merchants = transactionDAO.getMerchantList(accountData.getMobileNo());
					
					if(merchants != null && !merchants.isEmpty())
					{
						CustomerAccountData customerData = new CustomerAccountData();
						
						customerData.setMerchantData(merchants);
						
						 String encryptedData = KeyEncryptionUtils.encryptUsingKey(accountData.getSecretKey(), customerData);
						 
						 responseObject.setPayload(encryptedData);
						
					}
				}
				
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), "com.ng");
			
			//UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			responseObject.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseObject.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e.getMessage());
		}
		return responseObject;
	 }
	 
	 @RequestMapping(value = "/getMerchants", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	 public @ResponseBody ResponseObject getMerchants(@RequestBody RequestObject requestObject, HttpServletRequest request) 
	 {
		 LOGGER.info("************* getMerchants() starts executing in BankingController **************");
		 ResponseObject responseObject = new ResponseObject();
		 
		 BridgeDataObject bridgeData = new BridgeDataObject();
			/* 
			 * Get Agent details from tokenId
			 * requestObject.getTokenId()
			 * 
			 */
		 	
			UserAccountData accountData = null;
			try
			{
				//Check token Validity
				accountData = cacheManager.getFromCache(requestObject.getTokenId(), UserAccountData.class, MemCacheUtils.AUTHTOKENCACHE);
				
				responseObject = CommonUtils.validateRequest(accountData, requestObject, request);
				
				if(responseObject.getStatus() != null)
					return responseObject;
				
				List<OverlayMerchants> merchants = transactionDAO.getMerchantList(accountData.getMobileNo());
				
				if(merchants != null && !merchants.isEmpty())
				{
					responseObject.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
					responseObject.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
					
					CustomerAccountData customerData = new CustomerAccountData();
					
					customerData.setMerchantData(merchants);
					
					 String encryptedData = KeyEncryptionUtils.encryptUsingKey(accountData.getSecretKey(), customerData);
					 
					 responseObject.setPayload(encryptedData);
					
				}else{
					responseObject.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
					responseObject.setMessage(ErrorCodes.NO_RECORDS_FOUND.getMessage());
				}
				
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), "com.ng");
			
			//UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			responseObject.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseObject.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e.getMessage());
		}
		return responseObject;
	 }
	 
	 @RequestMapping(value = "/getCategories", method = RequestMethod.POST, consumes="application/json",produces="application/json")
	 public @ResponseBody ResponseObject getCategories(@RequestBody RequestObject requestObject, HttpServletRequest request) 
	 {
		 LOGGER.info("************* getCategories() starts executing in BankingController **************");
		 ResponseObject responseObject = new ResponseObject();
		 
		 BridgeDataObject bridgeData = new BridgeDataObject();
			/* 
			 * Get Agent details from tokenId
			 * requestObject.getTokenId()
			 * 
			 */
		 	
			UserAccountData accountData = null;
			try
			{
				//Check token Validity
				accountData = cacheManager.getFromCache(requestObject.getTokenId(), UserAccountData.class, MemCacheUtils.AUTHTOKENCACHE);
				
				responseObject = CommonUtils.validateRequest(accountData, requestObject, request);
				
				if(responseObject.getStatus() != null)
					return responseObject;
				
				List<CategoryProviderMapping> categoriesData = transactionDAO.getCategoryProviders();
				
				if(categoriesData != null && !categoriesData.isEmpty())
				{
					responseObject.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
					responseObject.setMessage(ErrorCodes.REQUEST_SUCCESSFUL.getMessage());
					
					Map<String, List<ProviderDetails>> categoriesMap = new ConcurrentHashMap<String, List<ProviderDetails>>();
					
					for(CategoryProviderMapping categoryMapping : categoriesData)
					{
						if(categoriesMap.containsKey(categoryMapping.getCategory().getCategoryName()))
						{
							List<ProviderDetails> providers = categoriesMap.get(categoryMapping.getCategory().getCategoryName());
							
							ProviderDetails provider = new ProviderDetails();
							
							provider.setProviderCode(categoryMapping.getProvider().getProviderCode());
							provider.setProviderName(categoryMapping.getProvider().getName());
							
							providers.add(provider);
							
							categoriesMap.put(categoryMapping.getCategory().getCategoryName(), providers);
						}else{
							List<ProviderDetails> providers = new ArrayList<ProviderDetails>();
							
							ProviderDetails provider = new ProviderDetails();
							
							provider.setProviderCode(categoryMapping.getProvider().getProviderCode());
							provider.setProviderName(categoryMapping.getProvider().getName());
							
							providers.add(provider);
							
							categoriesMap.put(categoryMapping.getCategory().getCategoryName(), providers);
						}
					}
					
					String encryptedData = KeyEncryptionUtils.encryptUsingKey(accountData.getSecretKey(), categoriesMap);
					 
					 responseObject.setPayload(encryptedData);
					
				}else{
					responseObject.setStatus(ErrorCodes.REQUEST_SUCCESSFUL.getCode());
					responseObject.setMessage(ErrorCodes.NO_RECORDS_FOUND.getMessage());
				}
				
		}catch(Exception e)
		{
			String[] exceptionData = ExceptionUtils.getExceptionGeneratedClassDetails(e.getStackTrace(), "com.ng");
			
			//UserServiceLogger.log(this.getClass().getSimpleName(), UserServiceLogger.ERROR, UserServiceConstants.LOGGING_METHOD_NAME+Thread.currentThread().getStackTrace()[1].getMethodName()+UserServiceConstants.LOGGING_ERROR_MESSAGE+e+UserServiceConstants.LOGGGING_CLASS_NAME+exceptionData[0]+ UserServiceConstants.LOGGING_FILE_NAME+exceptionData[1]+ UserServiceConstants.LOGGING_METHOD_NAME+exceptionData[2]+UserServiceConstants.LOGGING_LINE_NUMBER+exceptionData[3]);
			
			responseObject.setStatus(ErrorCodes.REQUEST_FAILED.getCode());
			responseObject.setMessage(ErrorCodes.REQUEST_FAILED.getMessage() + e.getMessage());
		}
		return responseObject;
	 }
}
