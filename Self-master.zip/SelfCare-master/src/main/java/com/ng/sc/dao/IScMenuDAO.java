package com.ng.sc.dao;

import java.util.List;

import com.ng.sb.common.dataobject.LoginData;
import com.ng.sb.common.model.Menu;

public interface IScMenuDAO extends ISelfCareDAO{
	public List<Menu> getRequiredMenu(LoginData loginData) throws Exception;

}
