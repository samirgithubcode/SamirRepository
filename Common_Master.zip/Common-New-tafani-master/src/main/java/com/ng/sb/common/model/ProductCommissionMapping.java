package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
*
* @author Simran
* 
* The persistent class for the commission Product Mapping database table.
*/
@Entity
@Table(name = "productcommissionmapping")
@XmlRootElement
@NamedQueries({
	@NamedQuery(name="ProductCommissionMapping.findByCommissionCode", query="SELECT  c FROM ProductCommissionMapping c where c.commissionTempId=:commissionTempId"),
	@NamedQuery(name="ProductCommissionMapping.findBySubscriptionCode", query="SELECT  c FROM ProductCommissionMapping c where c.subscriptionTempId=:subscriptionTempId"),
	@NamedQuery(name="ProductCommissionMapping.commissionProductId", query="SELECT  c FROM ProductCommissionMapping c where c.commissionProductId=:commissionProductId"),
	@NamedQuery(name="ProductCommissionMapping.findByCommisionProductId", query="SELECT c FROM ProductCommissionMapping c where c.commissionProductId=:commissionProductId"),
	@NamedQuery(name="ProductCommissionMapping.findByCommProdIdTxnType", query="SELECT pcm FROM ProductCommissionMapping pcm where pcm.commissionProductId=:commissionProductId AND pcm.txnType = :txnType"),
	@NamedQuery(name = "ProductCommissionMapping.findCommCode", query = "SELECT pcm.commissionTempId FROM ProductCommissionMapping pcm where pcm.commissionProductId=:commProdId AND pcm.productId=:pId AND pcm.txnType=:txnType")

})
public class ProductCommissionMapping implements Serializable {
	private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @JoinColumn(name = "commission_product_id", referencedColumnName = "id")
    @ManyToOne
    private CommissionProduct commissionProductId;
    @JoinColumn(name = "product_id", referencedColumnName = "id")
    @ManyToOne
    private Products productId;
    @Column(name = "txn_type")
    private String txnType; 
    @Column(name = "commission_code")
    private String commissionTempId;
    @Column(name = "subscription_code")
    private String subscriptionTempId;
    @Column(name = "deducted_from")
    private String deductedFrom;
    public ProductCommissionMapping() {
 		//default
 	}
    public ProductCommissionMapping(Integer id) {
        this.id = id;
    }
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public CommissionProduct getCommissionProductId() {
		return commissionProductId;
	}
	public void setCommissionProductId(CommissionProduct commissionProductId) {
		this.commissionProductId = commissionProductId;
	}
	public Products getProductId() {
		return productId;
	}
	public void setProductId(Products productId) {
		this.productId = productId;
	}
	public String getTxnType() {
		return txnType;
	}
	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}
	@Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
    	boolean check=true;
    	if(object!=null){
        if (!(object instanceof ProductCommissionMapping)) {
        	check= false;
        }
        ProductCommissionMapping other = (ProductCommissionMapping) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
    	}
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.ProductCommissionMapping[ id=" + id + " ]";
    }
	public String getCommissionTempId() {
		return commissionTempId;
	}
	public void setCommissionTempId(String commissionTempId) {
		this.commissionTempId = commissionTempId;
	}
	public String getDeductedFrom() {
		return deductedFrom;
	}
	public void setDeductedFrom(String deductedFrom) {
		this.deductedFrom = deductedFrom;
	}
	public String getSubscriptionTempId() {
		return subscriptionTempId;
	}
	public void setSubscriptionTempId(String subscriptionTempId) {
		this.subscriptionTempId = subscriptionTempId;
	}   
}
