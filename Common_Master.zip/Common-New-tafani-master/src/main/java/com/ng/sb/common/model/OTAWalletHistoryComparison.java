package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.*;

import java.util.List;

/**
 * @author abhishek
 *
 */
@Entity
@Table(name="OTAWalletHistoryComparison")
@NamedQueries({
@NamedQuery(name="OTAWalletHistoryComparison.findAll", query="SELECT o FROM OTAWalletHistoryComparison o"),
@NamedQuery(name="OTAWalletHistoryComparison.findByotaMgmtId", query="SELECT h FROM OTAWalletHistoryComparison h WHERE h.otaMgmtId = :otaMgmtId")
})
public class OTAWalletHistoryComparison implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false)
	private Integer id;

	//bi-directional many-to-one association to OTAManagement
	@ManyToOne
	@JoinColumn(name="otaMgmtId")
	private OTAManagement otaMgmtId;

	//bi-directional many-to-one association to HostSVWalletHistory
	@ManyToOne
	@JoinColumn(name="preWalletHId")
	private HostSVWalletHistory preWalletHId;

	//bi-directional many-to-one association to HostSVWalletHistory
	@ManyToOne
	@JoinColumn(name="curWalletHId")
	private HostSVWalletHistory curWalletHId;

	//bi-directional many-to-one association to OTAWalletMapping
	@OneToMany(mappedBy="otaWHCId")
	private List<OTAWalletMapping> otawalletMappings;

	public OTAWalletHistoryComparison() {
		//default constructor
	}

	public OTAWalletHistoryComparison(Integer id) {
		this.id = id;
	}
	
	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public OTAManagement getOtaMgmtId() {
		return this.otaMgmtId;
	}

	public void setOtaMgmtId(OTAManagement otaMgmtId) {
		this.otaMgmtId = otaMgmtId;
	}

	public HostSVWalletHistory getPreWalletHId() {
		return this.preWalletHId;
	}

	public void setPreWalletHId(HostSVWalletHistory preWalletHId) {
		this.preWalletHId = preWalletHId;
	}

	public HostSVWalletHistory getCurWalletHId() {
		return this.curWalletHId;
	}

	public void setCurWalletHId(HostSVWalletHistory curWalletHId) {
		this.curWalletHId = curWalletHId;
	}

	/**
	 * @return
	 */
	public List<OTAWalletMapping> getOtawalletMappings() {
		return this.otawalletMappings;
	}

	public void setOtawalletMappings(List<OTAWalletMapping> otawalletMappings) {
		this.otawalletMappings = otawalletMappings;
	}

	
	
	@Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }
	
	

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof OTAWalletHistoryComparison)) {
            return false;
        }
        OTAWalletHistoryComparison other = (OTAWalletHistoryComparison) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }
    
    @Override
	public String toString() {
		return "OTAWalletHistoryComparison [id=" + id + "]";
	}

}