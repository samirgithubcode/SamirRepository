/**
 * 
 */
package com.ng.transaction.util;

/**
 * @author gopal
 *
 */
public enum OverlayStatus {

	DAMAGED("DAMAGED", true, "Permanently Deactivated"),
	RETURN("RETURN", true, "Permanently Deactivated"),
	BLOCK_BY_SYS("BLOCK_BY_SYS", false, "Temporarily Deactivated"),
	ISSUED("ISSUED", false, "Active"),
	OK("OK", false, "Active");
	
	private String status;
	private boolean isPermanent;
	private String statusType;
	
	
	OverlayStatus(String status, boolean isPermanent, String statusType)
	{
		this.status = status;
		this.isPermanent = isPermanent;
		this.statusType = statusType;
	}

	public String getStatus() {
		return status;
	}

	public boolean isPermanent() {
		return isPermanent;
	}

	public String getStatusType() {
		return statusType;
	}

	public static OverlayStatus getByStatus(String status)
	{
		OverlayStatus requestedStatus = null;
		
		for(OverlayStatus overlayStatus : OverlayStatus.values())
		{
			if(null != overlayStatus.getStatus() &&  overlayStatus.getStatus().equalsIgnoreCase(status))
			{
				requestedStatus = overlayStatus;
				break;
			}
		}
		
		return requestedStatus;
	}
}
