/**
 * 
 */
package com.ng.transaction.dao.impl;

import org.springframework.stereotype.Repository;

import com.ng.sb.common.util.SystemConstant;
import com.ng.transaction.dao.IPaymentInstrumentDAO;

/**
 * @author gaurav
 *
 */
@Repository(value=SystemConstant.PAYMENT_INSTRUMENT_DAO)
public class PaymentInstrumentDAO extends TransactionDAO implements IPaymentInstrumentDAO {
	private static final long serialVersionUID = 1L;

}
