package com.ng.sb.common.dataobject;

/**
 * @author gaurav
 *
 */
public class CategoryData extends BaseObjectData {
	
	private static final long serialVersionUID = 1L;
	public CategoryData() {
		//default constructor
	}

	public CategoryData(Integer code) {
		super.setCode(code);
	}
	@Override
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		}

		boolean check=false;
		if ( obj instanceof CategoryData) {
			CategoryData other = (CategoryData) obj;
			 if (getCode() == other.getCode()) {
				 check= true;
			}
			return check;
		}
		return super.equals(obj);
	}

	@Override
	public int hashCode() {
		if (getCode() != null && this.getCode() != null) {
			return this.getCode() * 7 ;
		} else {
			return 0;
		}

	}

}
