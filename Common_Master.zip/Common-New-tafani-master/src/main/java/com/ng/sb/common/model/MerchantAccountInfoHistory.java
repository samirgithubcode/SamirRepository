/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author amardeep
 */
@Entity
@Table(name = "MerchantAccountInfoHistory")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "MerchantAccountInfoHistory.findAll", query = "SELECT m FROM MerchantAccountInfoHistory m"),
    @NamedQuery(name = "MerchantAccountInfoHistory.findById", query = "SELECT m FROM MerchantAccountInfoHistory m WHERE m.id = :id"),
    @NamedQuery(name = "MerchantAccountInfoHistory.findByStatus", query = "SELECT m FROM MerchantAccountInfoHistory m WHERE m.status = :status"),
    @NamedQuery(name = "MerchantAccountInfoHistory.findByLandMark", query = "SELECT m FROM MerchantAccountInfoHistory m WHERE m.landMark = :landMark"),
    @NamedQuery(name = "MerchantAccountInfoHistory.findByHouseNoStreet", query = "SELECT m FROM MerchantAccountInfoHistory m WHERE m.houseNoStreet = :houseNoStreet"),
    @NamedQuery(name = "MerchantAccountInfoHistory.findByCity", query = "SELECT m FROM MerchantAccountInfoHistory m WHERE m.city = :city"),
    @NamedQuery(name = "MerchantAccountInfoHistory.findByDescription", query = "SELECT m FROM MerchantAccountInfoHistory m WHERE m.description = :description"),
    @NamedQuery(name = "MerchantAccountInfoHistory.findByCompanyName", query = "SELECT m FROM MerchantAccountInfoHistory m WHERE m.companyName = :companyName"),
    @NamedQuery(name = "MerchantAccountInfoHistory.findByDesKey", query = "SELECT m FROM MerchantAccountInfoHistory m WHERE m.desKey = :desKey"),
    @NamedQuery(name = "MerchantAccountInfoHistory.findByPincode", query = "SELECT m FROM MerchantAccountInfoHistory m WHERE m.pincode = :pincode"),
    @NamedQuery(name = "MerchantAccountInfoHistory.findByCompanyLogo", query = "SELECT m FROM MerchantAccountInfoHistory m WHERE m.companyLogo = :companyLogo"),
    @NamedQuery(name = "MerchantAccountInfoHistory.findByCreateDate", query = "SELECT m FROM MerchantAccountInfoHistory m WHERE m.createDate = :createDate"),
    @NamedQuery(name = "MerchantAccountInfoHistory.findByEditDate", query = "SELECT m FROM MerchantAccountInfoHistory m WHERE m.editDate = :editDate"),
    @NamedQuery(name = "MerchantAccountInfoHistory.findByAccountCode", query = "SELECT m FROM MerchantAccountInfoHistory m WHERE m.accountCode = :accountCode"),
    @NamedQuery(name = "MerchantAccountInfoHistory.findByHostDeploymentType", query = "SELECT m FROM MerchantAccountInfoHistory m WHERE m.hostDeploymentType = :hostDeploymentType"),
    @NamedQuery(name = "MerchantAccountInfoHistory.findByMarchantType", query = "SELECT m FROM MerchantAccountInfoHistory m WHERE m.marchantType = :marchantType"),
    @NamedQuery(name = "MerchantAccountInfoHistory.findByLongitude", query = "SELECT m FROM MerchantAccountInfoHistory m WHERE m.longitude = :longitude"),
    @NamedQuery(name = "MerchantAccountInfoHistory.findByLatitude", query = "SELECT m FROM MerchantAccountInfoHistory m WHERE m.latitude = :latitude"),
    @NamedQuery(name = "MerchantAccountInfoHistory.findByUnder", query = "SELECT m FROM MerchantAccountInfoHistory m WHERE m.under = :under"),
    @NamedQuery(name = "MerchantAccountInfoHistory.findByRegion", query = "SELECT m FROM MerchantAccountInfoHistory m WHERE m.region = :region")})
public class MerchantAccountInfoHistory implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
   
  
    @Column(name = "houseNo_Street")
    private String houseNoStreet;
    @Column(name = "city")
    private String city;
    @Column(name = "description")
    private String description;
    @Column(name = "landMark")
    private String landMark;
    @Basic(optional = false)
    @Column(name = "status")
    private boolean status;
    @Basic(optional = false)
    @Column(name = "company_name")
    private String companyName;
    @Column(name = "3des_key")
    private String desKey;
    @Column(name = "pincode")
    private Integer pincode;
    @Column(name = "company_logo")
    private String companyLogo;
    @Basic(optional = false)
    @Column(name = "create_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createDate;
    @Column(name = "edit_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date editDate;
    @Basic(optional = false)
    @Column(name = "account_code")
    private int accountCode;
    @Column(name = "hostDeploymentType")
    private String hostDeploymentType;
    @Column(name = "marchantType")
    private String marchantType;
    @Column(name = "longitude")
    private String longitude;
    @Column(name = "latitude")
    private String latitude;
    @Column(name = "under")
    private String under;
    @Column(name = "region")
    private String region;
    @JoinColumn(name = "parent_id", referencedColumnName = "id")
    @ManyToOne
    private AccountInfo parentId;
    @JoinColumn(name = "editby_id", referencedColumnName = "id")
    @ManyToOne
    private AccountInfo editbyId;
    @JoinColumn(name = "addby_id", referencedColumnName = "id")
    @ManyToOne
    private AccountInfo addbyId;
    @JoinColumn(name = "account_group_id", referencedColumnName = "id")
    @ManyToOne
    private SysAccountGroup accountGroupId;
    @JoinColumn(name = "rtId", referencedColumnName = "id")
    @ManyToOne
    private AccountInfo rtId;
    @JoinColumn(name = "sdId", referencedColumnName = "id")
    @ManyToOne
    private AccountInfo sdId;
    @JoinColumn(name = "parentMerchantId", referencedColumnName = "id")
    @ManyToOne
    private AccountInfo parentMerchantId;
    @JoinColumn(name = "dId", referencedColumnName = "id")
    @ManyToOne
    private AccountInfo dId;
    @JoinColumn(name = "hId", referencedColumnName = "id")
    @ManyToOne
    private AccountInfo hId;
    @JoinColumn(name = "country", referencedColumnName = "id")
    @ManyToOne
    private Country country;
    @JoinColumn(name = "state", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private State state;

    public MerchantAccountInfoHistory() {
    	//empty
    }

    public MerchantAccountInfoHistory(Integer id) {
        this.id = id;
    }

    public MerchantAccountInfoHistory(Integer id, boolean status, String companyName, Date createDate, int accountCode) {
        this.id = id;
        this.status = status;
        this.companyName = companyName;
        this.createDate = createDate;
        this.accountCode = accountCode;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public boolean getStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public String getLandMark() {
        return landMark;
    }

    public void setLandMark(String landMark) {
        this.landMark = landMark;
    }

    public String getHouseNoStreet() {
        return houseNoStreet;
    }

    public void setHouseNoStreet(String houseNoStreet) {
        this.houseNoStreet = houseNoStreet;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getDesKey() {
        return desKey;
    }

    public void setDesKey(String desKey) {
        this.desKey = desKey;
    }

    public Integer getPincode() {
        return pincode;
    }

    public void setPincode(Integer pincode) {
        this.pincode = pincode;
    }

    public String getCompanyLogo() {
        return companyLogo;
    }

    public void setCompanyLogo(String companyLogo) {
        this.companyLogo = companyLogo;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getEditDate() {
        return editDate;
    }

    public void setEditDate(Date editDate) {
        this.editDate = editDate;
    }

    public int getAccountCode() {
        return accountCode;
    }

    public void setAccountCode(int accountCode) {
        this.accountCode = accountCode;
    }

    public String getHostDeploymentType() {
        return hostDeploymentType;
    }

    public void setHostDeploymentType(String hostDeploymentType) {
        this.hostDeploymentType = hostDeploymentType;
    }

    public String getMarchantType() {
        return marchantType;
    }

    public void setMarchantType(String marchantType) {
        this.marchantType = marchantType;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getUnder() {
        return under;
    }

    public void setUnder(String under) {
        this.under = under;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public AccountInfo getParentId() {
        return parentId;
    }

    public void setParentId(AccountInfo parentId) {
        this.parentId = parentId;
    }

    public AccountInfo getEditbyId() {
        return editbyId;
    }

    public void setEditbyId(AccountInfo editbyId) {
        this.editbyId = editbyId;
    }

    public AccountInfo getAddbyId() {
        return addbyId;
    }

    public void setAddbyId(AccountInfo addbyId) {
        this.addbyId = addbyId;
    }

    public SysAccountGroup getAccountGroupId() {
        return accountGroupId;
    }

    public void setAccountGroupId(SysAccountGroup accountGroupId) {
        this.accountGroupId = accountGroupId;
    }

    public AccountInfo getRtId() {
        return rtId;
    }

    public void setRtId(AccountInfo rtId) {
        this.rtId = rtId;
    }

    public AccountInfo getSdId() {
        return sdId;
    }

    public void setSdId(AccountInfo sdId) {
        this.sdId = sdId;
    }

    public AccountInfo getParentMerchantId() {
        return parentMerchantId;
    }

    public void setParentMerchantId(AccountInfo parentMerchantId) {
        this.parentMerchantId = parentMerchantId;
    }

    public AccountInfo getDId() {
        return dId;
    }

    public void setDId(AccountInfo dId) {
        this.dId = dId;
    }

    public AccountInfo getHId() {
        return hId;
    }

    public void setHId(AccountInfo hId) {
        this.hId = hId;
    }

    public Country getCountry() {
        return country;
    }

    public void setCountry(Country country) {
        this.country = country;
    }

    public State getState() {
        return state;
    }

    public void setState(State state) {
        this.state = state;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
    	boolean check=true;
    	if(object!=null){
        if (!(object instanceof MerchantAccountInfoHistory)) {
        	check= false;
        }
        MerchantAccountInfoHistory other = (MerchantAccountInfoHistory) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
    	}
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.MerchantAccountInfoHistory[ id=" + id + " ]";
    }
    
}
