/**
 * 
 */
package com.ng.sb.common.dataobject;

/**
 * @author shiv
 *
 */
public class CommonInfoData extends BaseObjectData {
	private static final long serialVersionUID = 1L;
	private String codeVal;
	private String description;

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCodeVal() {
		return codeVal;
	}

	public void setCodeVal(String codeVal) {
		this.codeVal = codeVal;
	}

}
