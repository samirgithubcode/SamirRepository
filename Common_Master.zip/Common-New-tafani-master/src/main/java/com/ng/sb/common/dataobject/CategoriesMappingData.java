/**
 * 
 */
package com.ng.sb.common.dataobject;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * @author gaurav
 *
 */
public class CategoriesMappingData extends BaseObjectData{
	private static final long serialVersionUID = 1L;
	private Map<CategoriesData, CategoriesData> categoryMap = new HashMap<>();
	
	private Set<String> provList=new HashSet<>();
	private Set<String> provPartnerList=new HashSet<>();
	private Set<String> provPartnerSeqList=new HashSet<>();
	private Set<String> provPartnerSeqCommissionList=new HashSet<>();
	private String[] provPartnerSeqCommissionLists;
	public String[] getProvPartnerSeqCommissionLists() {
		return provPartnerSeqCommissionLists;
	}
	public void setProvPartnerSeqCommissionLists(String[] provPartnerSeqCommissionLists) {
		this.provPartnerSeqCommissionLists = provPartnerSeqCommissionLists;
	}
	public Set<String> getProvPartnerSeqCommissionList() {
		return provPartnerSeqCommissionList;
	}
	public void setProvPartnerSeqCommissionList(Set<String> provPartnerSeqCommissionList) {
		this.provPartnerSeqCommissionList = provPartnerSeqCommissionList;
	}
	public Map<CategoriesData, CategoriesData> getCategoryMap() {
		return categoryMap;
	}
	public void setCategoryMap(Map<CategoriesData, CategoriesData> categoryMap) {
		this.categoryMap = categoryMap;
	}
	
	public Set<String> getProvList() {
		return provList;
	}
	public void setProvList(Set<String> provList) {
		this.provList = provList;
	}
	public Set<String> getProvPartnerList() {
		return provPartnerList;
	}
	public void setProvPartnerList(Set<String> provPartnerList) {
		this.provPartnerList = provPartnerList;
	}
	public Set<String> getProvPartnerSeqList() {
		return provPartnerSeqList;
	}
	public void setProvPartnerSeqList(Set<String> provPartnerSeqList) {
		this.provPartnerSeqList = provPartnerSeqList;
	}
	public String[] getProviderArray() {
		return provList.toArray(new String[0]);
	}
	public String[] getProvPartnerArray() {
		return provPartnerList.toArray(new String[0]);
	}
	public String[] getProvPartnerSeqArray() {
		return provPartnerSeqList.toArray(new String[0]);
	}
	

}
