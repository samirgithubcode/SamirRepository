package com.ng.pnb.invoker.util;

public class PnbConstants {
private PnbConstants(){}
	
	public static final String ERRORMESSAGE= " Error in getting Data from PNB Finacle Server.PNBInvoker - PNB - bankToBankFundTransferFSP method ## ";
	public static final String TRANSACTIONID  = "TransactionId ";
	public static final String AC  = "Your a/c# ";
	public static final String AC_NO  = " a/c# ";
	public static final String ACN  ="00000000000000KO";
	public static final String ERRORMSG  ="In openConnectionAndWrite -  writeOnSocket method. error ##";
	public static final String RESULTMSG  =" In ISOMessageCreator -  RESULT : ";
	public static final String MSG  ="Sorry, Invalid a/c #. Please correct and retry";
	
	public static final String INVALID_CUSTOMER_DETAILS  ="Invalid A/c number or IFSC code.Please correct and retry.";
	
	public static final String INVALID_CUSTOMER  ="Invalid Customer Details.Please Correct and Retry.";
	
	public static final String BANKING_PIN_SUCCESSFUL  ="Your banking PIN created successfully.";
	
	public static final String PAYEE_ADDED_SUCCESSFUL  = "Requested Payee Details have been added successfully.";
	
	public static final String MERCHANT_ADDED_SUCCESSFUL  = "Requested Merchant Details have been added successfully.";
	
	public static final String BILLER_ADDED_SUCCESSFUL  = "Requested Biller Details have been added successfully.";
	
	public static final String BILLER_EDITED_SUCCESSFUL  = "Requested Biller Details have been edited successfully.";
	
	public static final String BILLER_DELETED_SUCCESSFUL  = "Requested Biller Details have been deleted successfully.";
	
	public static final String REQUESTED_SERVICE_NOT_AVAILABLE  = "Requested service is not available.";
	
	public static final String INVALID_PAYEE  = "Invalid Payee details.";
	
	public static final String INVALID_MERCHANT  = "Invalid Merchant details.";
	
	public static final String INVALID_BILLER  = "Invalid Biller details.";
	
	public static final String INVALID_OLD_BANKING_PIN  ="Sorry, given old banking PIN is Invalid.Please correct and retry";
	
	public static final String BANKING_PIN_CHANGE_SUCCESSFUL  ="Your banking PIN changed successfully.";
	
	public static final String POOL_ACCOUNT_TYPE  = "POOL_ACCOUNT";
	
	public static final String LIEN_ACCOUNT_TYPE  = "LIEN_ACCOUNT";
	
	public static final String ISO_BANKING  = "ISO";
	
	public static final String API_BANKING  = "API";
	
	public static final String DEPLOYED_FOR  = "NG";
	
}
