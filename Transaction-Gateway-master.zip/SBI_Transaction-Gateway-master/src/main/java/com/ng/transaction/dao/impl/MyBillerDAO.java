/**
 * 
 */
package com.ng.transaction.dao.impl;

import org.springframework.stereotype.Repository;

import com.ng.sb.common.util.SystemConstant;
import com.ng.transaction.dao.IMyBillerDAO;

/**
 * @author gaurav
 *
 */
@Repository(value=SystemConstant.MY_BILLER_DAO)
public class MyBillerDAO extends SettingsDAO implements IMyBillerDAO {
	private static final long serialVersionUID = 1L;

}
