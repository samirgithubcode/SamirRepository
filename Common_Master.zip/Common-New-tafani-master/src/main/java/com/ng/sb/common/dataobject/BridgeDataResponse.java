/**
 * 
 */
package com.ng.sb.common.dataobject;


/**
 * @author gaurav
 *
 */
public class BridgeDataResponse extends BaseObjectData {
	private static final long serialVersionUID = 1L;
	
	public enum Status{
		SUCCESS,
		FAILED,
		FAILED_MOVE_NEXT,
		PENDING
	}
	
	private String responseCode; 
	private Status status; 
	private String msidnToSendMsg;
	private String responseMsg;
	private String actualMsgFromPartner;
	public enum EListOrString{
		L,
		S
	}
	private EListOrString listOrString;
	public EListOrString getListOrString() {
		return listOrString;
	}

	public void setListOrString(EListOrString listOrString) {
		this.listOrString = listOrString;
	}
	public String getResponseMsg() {
		return responseMsg;
	}
	public void setResponseMsg(String responseMsg) {
		this.responseMsg = responseMsg;
	}
	public String getMsidnToSendMsg() {
		return msidnToSendMsg;
	}
	public void setMsidnToSendMsg(String msidnToSendMsg) {
		this.msidnToSendMsg = msidnToSendMsg;
	}
	public Status getStatus() {
		return status;
	}
	public void setStatus(Status status) {
		this.status = status;
	}
	public String getActualMsgFromPartner() {
		return actualMsgFromPartner;
	}
	public void setActualMsgFromPartner(String actualMsgFromPartner) {
		this.actualMsgFromPartner = actualMsgFromPartner;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	

}
