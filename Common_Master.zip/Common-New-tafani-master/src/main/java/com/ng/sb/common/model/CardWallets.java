package com.ng.sb.common.model;


	import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
	
	

		@Entity
		@Table(name = "cardwallets")
		@XmlRootElement
		@NamedQueries({
			@NamedQuery(name="CardWallets.findAll", query="SELECT c FROM CardWallets c"),
			@NamedQuery(name="CardWallets.getByCardNameId", query="select c from CardWallets c WHERE c.cardNameId=:id and c.status=1"),
		})
		public class CardWallets implements Serializable {
			private static final long serialVersionUID = 1L;
			

			@JoinColumn(name = "cardNameId", referencedColumnName = "id")
			@ManyToOne
			private CardDetails cardNameId;
			
			@Id
			@GeneratedValue(strategy = GenerationType.IDENTITY)
			@Basic(optional = false)
			@Column(name = "id")
			private Integer id;
			

			
			
			@JoinColumn(name = "walletId", referencedColumnName = "id")
			@ManyToOne
			private WalletType walletId;
			
			@Column(name = "appConstant")
			private String appConstantId;
			
		   
			@Column(name = "status")
		    private Integer status;
			
			public CardWallets() {
		    	//empty
		    }

		    public CardWallets(Integer id) {
		        this.id = id;
		    }
			 public WalletType getWalletId() {
					return walletId;
				}

				public void setWalletId(WalletType walletId) {
					this.walletId = walletId;
				}

		    public CardDetails getCardNameId() {
				return cardNameId;
			}

			public void setCardNameId(CardDetails cardNameId) {
				this.cardNameId = cardNameId;
			}

			public Integer getStatus() {
				return status;
			}

			public void setStatus(Integer status) {
				this.status = status;
			}
			
		    

		    
			
			public Integer getId() {
				return id;
			}

			public void setId(Integer id) {
				this.id = id;
			}


			@Override
			public boolean equals(Object object) {
				boolean checkStatus = true;
				if (object != null) {
					if (!(object instanceof CardWallets)) {
						checkStatus = false;
					}
					CardWallets other = (CardWallets) object;
					if ((this.id == null && other.id != null)
							|| (this.id != null && !this.id.equals(other.id))) {
						checkStatus = false;
					}
				}
				return checkStatus;
			}

			@Override
			public int hashCode() {
				int hash = 0;
				hash += (id != null ? id.hashCode() : 0);
				return hash;
			}

			public String getAppConstantId() {
				return appConstantId;
			}

			public void setAppConstantId(String appConstantId) {
				this.appConstantId = appConstantId;
			}

		}
		
		
		
		
		
		
		
		
		

