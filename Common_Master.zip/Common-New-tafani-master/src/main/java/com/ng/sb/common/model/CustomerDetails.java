/**
 * 
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Type;

/**
 * @author gopal
 *
 */
@Entity
@Table(name = "subscriber_account_info")
@NamedQueries({
    @NamedQuery(name = "CustomerDetails.findByCustId", query = "SELECT cd FROM CustomerDetails cd WHERE cd.customerId=:customerId "),
    @NamedQuery(name = "CustomerDetails.findByCustMsisdn", query = "SELECT cd FROM CustomerDetails cd,Subscriber s WHERE s.custId=cd.customerId and s.aamsisdn=:msisdn ")
})
public class CustomerDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6089466616241703457L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "id")
	private Integer id;
	
	@Column(name = "customerId")
	private String customerId;
	
	@Column(name = "customerName")
	private String customerName;
	
	@Column(name = "accountNumber")
	private Long accountNumber;

	@Column(name = "ifscCode")
	private String ifscCode;
	
	@Column(name = "cardNumber")
	private Long cardNumber;

	@Column(name = "accountName")
	private String accountName;
	
	@Temporal(TemporalType.DATE)
	@Type(type="date")
	@Column(name = "accountOpenDate")
	private Date accountOpenDate;
	
	@Column(name = "schemeCode")
	private String schemeCode;
	
	/**
	 * Valid Values:
	 *	SBA – Saving Accounts
	 *	CCA– Cash Credit Accounts
	 *	ODA– Overdraft accounts
	 *	CAA– Current Accounts
	 */
	@Column(name = "accountType")
	private String accountType;
	
	/**
	 * Valid Values:
	 *	F – Frozen
	 *	C – Closed
	 *	D – Debit Frozen
	 *	R – Credit Frozen
	 *	M – Dormant
	 *	A – Active
	 *	O – Open
 	 *	I – Inactive
	 */
	@Column(name = "accountStatus")
	private String accountStatus;
	
	@Column(name = "operationCode")
	private String operationCode;
	
	@Column(name = "jointHolderName1")
	private String jointHolderName1;
	
	@Column(name = "jointHolderName2")
	private String jointHolderName2;
	
	@Column(name = "jointHolderName3")
	private String jointHolderName3;
	
	@Column(name = "subHeadCode")
	private String subHeadCode;
	
	@Column(name = "accountSoleId")
	private String accountSoleId;
	
	@Column(name = "drawingPower")
	private String drawingPower;
	
	@Column(name = "lienAmount")
	private String lienAmount;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Type(type="date")
	@Column (name = "addedOn")
	private Date addedOn;

	@Column(name = "email")
	private String emailId;
	
	@Column(name = "dateOfBirth")
	private Date dateOfBirth;
	
	@Column(name = "pinCode")
	private Integer pinCode;
	
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public Long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public Long getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(Long cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public Date getAccountOpenDate() {
		return accountOpenDate;
	}

	public void setAccountOpenDate(Date accountOpenDate) {
		this.accountOpenDate = accountOpenDate;
	}

	public String getSchemeCode() {
		return schemeCode;
	}

	public void setSchemeCode(String schemeCode) {
		this.schemeCode = schemeCode;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getAccountStatus() {
		return accountStatus;
	}

	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}

	public String getOperationCode() {
		return operationCode;
	}

	public void setOperationCode(String operationCode) {
		this.operationCode = operationCode;
	}

	public String getJointHolderName1() {
		return jointHolderName1;
	}

	public void setJointHolderName1(String jointHolderName1) {
		this.jointHolderName1 = jointHolderName1;
	}

	public String getJointHolderName2() {
		return jointHolderName2;
	}

	public void setJointHolderName2(String jointHolderName2) {
		this.jointHolderName2 = jointHolderName2;
	}

	public String getJointHolderName3() {
		return jointHolderName3;
	}

	public void setJointHolderName3(String jointHolderName3) {
		this.jointHolderName3 = jointHolderName3;
	}

	public String getSubHeadCode() {
		return subHeadCode;
	}

	public void setSubHeadCode(String subHeadCode) {
		this.subHeadCode = subHeadCode;
	}

	public String getAccountSoleId() {
		return accountSoleId;
	}

	public void setAccountSoleId(String accountSoleId) {
		this.accountSoleId = accountSoleId;
	}

	public String getDrawingPower() {
		return drawingPower;
	}

	public void setDrawingPower(String drawingPower) {
		this.drawingPower = drawingPower;
	}

	public String getLienAmount() {
		return lienAmount;
	}

	public void setLienAmount(String lienAmount) {
		this.lienAmount = lienAmount;
	}

	public Date getAddedOn() {
		return addedOn;
	}

	public void setAddedOn(Date addedOn) {
		this.addedOn = addedOn;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getIfscCode() {
		return ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public Integer getPinCode() {
		return pinCode;
	}

	public void setPinCode(Integer pinCode) {
		this.pinCode = pinCode;
	}
	
	
}