package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;


@Entity
@Table(name = "customerqueryresolutiontime")
@XmlRootElement
@NamedQueries({
	 @NamedQuery(name = "CustomerQueryResolutionTime.findAll", query = "SELECT qr FROM CustomerQueryResolutionTime qr"),
	 @NamedQuery(name = "CustomerQueryResolutionTime.findAllbypriority", query = "SELECT qr FROM CustomerQueryResolutionTime qr where  qr.customerpriority=:customerpriority"),
	 @NamedQuery(name = "CustomerQueryResolutionTime.findAllbyId", query = "SELECT qr FROM CustomerQueryResolutionTime qr where  qr.id=:id"),
})

public class CustomerQueryResolutionTime implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
	
    @ManyToOne
    @JoinColumn(name="PriorityId", referencedColumnName="id")
    private Customerpriority customerpriority;
	
    @Basic(optional = true)
    @Column(name = "queryresolutiontime")
    private Integer queryresolutiontime;
    
    

	public CustomerQueryResolutionTime() {
		//default
	}
	

	public CustomerQueryResolutionTime(Integer id, Customerpriority customerpriority,Integer queryresolutiontime ) {
		super();
		this.id = id;
		this.customerpriority = customerpriority;
		this.queryresolutiontime = queryresolutiontime;
	}
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
    public Integer getQueryresolutiontime() {
		return queryresolutiontime;
	}

	public void setQueryresolutiontime(Integer queryresolutiontime) {
		this.queryresolutiontime = queryresolutiontime;
	}

	


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CustomerQueryResolutionTime other = (CustomerQueryResolutionTime) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	
	public Customerpriority getCustomerpriority() {
		return customerpriority;
	}

	public void setCustomerpriority(Customerpriority customerpriority) {
		this.customerpriority = customerpriority;
	}


	@Override
	public int hashCode() {
		 int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public String toString() {
		return "CustomerQueryResolutionTime [id=" + id + "]";
	}
	
	
	
	
	

}
