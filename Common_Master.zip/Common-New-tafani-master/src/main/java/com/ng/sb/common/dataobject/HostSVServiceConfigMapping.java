package com.ng.sb.common.dataobject;


public class HostSVServiceConfigMapping extends BaseObjectData {

	private static final long serialVersionUID = 1L;
	
	
}
