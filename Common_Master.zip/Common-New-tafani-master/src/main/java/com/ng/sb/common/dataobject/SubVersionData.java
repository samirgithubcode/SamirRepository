package com.ng.sb.common.dataobject;

public class SubVersionData extends BaseObjectData {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer hostId;
	public Integer getHostId() {
		return hostId;
	}
	public void setHostId(Integer hostId) {
		this.hostId = hostId;
	}

}
