/**
 * 
 */
package com.ng.transaction.service.impl;

import org.springframework.stereotype.Service;

import com.ng.sb.common.util.SystemConstant;
import com.ng.transaction.service.IFundTransferMgtService;

/**
 * @author gaurav
 *
 */
@Service(value=SystemConstant.FUND_TRANSFER_MGT_SERVICE)
public class FundTransferMgtService extends NonFundTransferBankingService implements IFundTransferMgtService {

}
