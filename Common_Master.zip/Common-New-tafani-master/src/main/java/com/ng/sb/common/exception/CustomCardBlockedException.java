package com.ng.sb.common.exception;

public class CustomCardBlockedException extends RuntimeException{
	
	public CustomCardBlockedException(String message){
		super(message);
	}
	

}
