package com.ng.sb.common.dataobject;

import java.util.Set;

public class PinValidationDataObj {

	private String key;
	private String hostName;
	private Set<String> pinSet;
	
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	
	public String getHostName() {
		return hostName;
	}
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}
	public Set<String> getPinSet() {
		return pinSet;
	}
	public void setPinSet(Set<String> pinSet) {
		this.pinSet = pinSet;
	}
	
	
	
}
