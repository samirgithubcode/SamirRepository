/**
 * 
 */
package com.ng.sb.common.dataobject;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author
 *
 */
@JsonIgnoreProperties
public class PaymentRequestObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1399593624627585064L;

	private Integer channelId;
	
	private String  tokenId;
	
	private Object payload;
	private Integer portalId;

	public Integer getChannelId() {
		return channelId;
	}

	public void setChannelId(Integer channelId) {
		this.channelId = channelId;
	}

	public String getTokenId() {
		return tokenId;
	}

	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}

	public Object getPayload() {
		return payload;
	}

	public void setPayload(Object payload) {
		this.payload = payload;
	}

	public Integer getPortalId() {
		return portalId;
	}

	public void setPortalId(Integer portalId) {
		this.portalId = portalId;
	}
	
	
}
