/**
 * 
 */
package com.ng.sb.common.exception;

/**
 * @author gaurav Exceptions for Wallet Services
 */
public class WalletException  extends Exception {
	private static final long serialVersionUID = 1L;

	public WalletException(String message) {
		super(message);
	}
}
