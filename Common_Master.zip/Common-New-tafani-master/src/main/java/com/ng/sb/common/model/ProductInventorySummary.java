/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name = "ProductInventorySummary")
    
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "ProductInventorySummary.findAll", query = "SELECT p FROM ProductInventorySummary p"),
    @NamedQuery(name = "ProductInventorySummary.findById", query = "SELECT p FROM ProductInventorySummary p WHERE p.id = :id"),
    @NamedQuery(name = "ProductInventorySummary.findByAccountId", query = "SELECT p FROM ProductInventorySummary p WHERE p.accountId = :accountId order by p.productId.productName , p.mvId.name"),
    @NamedQuery(name = "ProductInventorySummary.findByMvId", query = "SELECT p FROM ProductInventorySummary p WHERE p.mvId = :mvId")})
public class ProductInventorySummary implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
    @JoinColumn(name = "mvId", referencedColumnName = "id")
    @ManyToOne
    private MasterVersion mvId;
    @JoinColumn(name = "productId", referencedColumnName = "id")
    @ManyToOne
    private Products productId;
    @JoinColumn(name = "accountId", referencedColumnName = "id")
    @ManyToOne
    private AccountInfo accountId;
    @JoinColumn(name = "hsvId", referencedColumnName = "id")
    @ManyToOne
    private HostSubVersion hsvId;
    @Column(name = "availableStock")
    private Integer availableStock;
    
    public ProductInventorySummary() {
    	//empty
    }

	public ProductInventorySummary(Integer id) {
		this.id = id;
	}
	
	public ProductInventorySummary(MasterVersion mvId, Products productId, AccountInfo accountId) {
		this.mvId = mvId;
		this.productId = productId;
		this.accountId = accountId;
	}

	public ProductInventorySummary(MasterVersion mvId, Products productId, AccountInfo accountId, HostSubVersion hsvId) {
		this.mvId = mvId;
		this.productId = productId;
		this.accountId = accountId;
		this.hsvId = hsvId;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	

	public Products getProductId() {
		return productId;
	}

	public void setProductId(Products productId) {
		this.productId = productId;
	}

	public MasterVersion getMvId() {
		return mvId;
	}

	public void setMvId(MasterVersion mvId) {
		this.mvId = mvId;
	}
	public AccountInfo getAccountId() {
		return accountId;
	}

	public void setAccountId(AccountInfo accountId) {
		this.accountId = accountId;
	}

	public HostSubVersion getHsvId() {
		return hsvId;
	}

	public void setHsvId(HostSubVersion hsvId) {
		this.hsvId = hsvId;
	}

	public Integer getAvailableStock() {
		return availableStock;
	}

	public void setAvailableStock(Integer availableStock) {
		this.availableStock = availableStock;
	}

	@Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
    	boolean check=true;
    	if(object!=null){
        if (!(object instanceof ProductInventorySummary)) {
        	check= false;
        }
        ProductInventorySummary other = (ProductInventorySummary) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
    	}
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.ProductInventorySummary[ id=" + id + " ]";
    }
    
}
