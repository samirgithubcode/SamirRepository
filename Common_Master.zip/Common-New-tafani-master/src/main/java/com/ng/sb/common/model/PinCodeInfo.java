package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author abhishek
 *
 */
 @Entity
 @Table(name = "pinCodeInfo")
 @XmlRootElement
 @NamedQueries({
	
 })
public class PinCodeInfo implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
	
	@Basic(optional = false)
    @Column(name = "location")
	private String location;
	
	@Basic(optional = false)
	@Column(name="district")
	private String district;
	
	@Basic(optional = false)
	@Column(name="division")
	private String division;
	
	@Basic(optional = false)
	@Column(name="region")
	private String region;
	
	@Basic(optional = false)
	@Column(name="circle")
	private String circle;
	
	@Basic(optional = false)
	@Column(name="taluk")
	private String taluk;
	
	@Basic(optional = false)
    @Column(name = "state")
	private String state;
	
	@Basic(optional = false)
    @Column(name = "country")
	private String country;
	
	@Basic(optional = false)
    @Column(name = "pincode")
	private String pincode;

	public PinCodeInfo(){
	//empty
	}
	
	public PinCodeInfo(Integer id){
		this.id = id;
	}
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	
	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getDivision() {
		return division;
	}

	public void setDivision(String division) {
		this.division = division;
	}

	

	public String getCircle() {
		return circle;
	}

	public void setCircle(String circle) {
		this.circle = circle;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}
	
	

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}
	public String getTaluk() {
		return taluk;
	}

	public void setTaluk(String taluk) {
		this.taluk = taluk;
	}
	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	
	@Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
    	boolean checkStatus=true;
    	if(object!=null){
        if (!(object instanceof PinCodeInfo)) {
        	checkStatus= false;
        }
        PinCodeInfo other = (PinCodeInfo) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	checkStatus= false;
        }
    	}
        return checkStatus;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.Address[ id=" + id + " ]";
    }
}
