package com.ng.sb.common.dataobject;

/**
 * @author gaurav
 *
 */
public class Settings extends BaseObjectData {

	private static final long serialVersionUID = 1L;
	private BankAccount myBankAccount;
	private CreditCard myCC;
	private IMPS myIMPS;
	private Wallet myWallet;
	private ProvidersData myBiller;
	private Payee myPayee;
	private Merchant myMerchant;
	private String tPin;

	public String gettPin() {
		return tPin;
	}

	public void settPin(String tPin) {
		this.tPin = tPin;
	}

	public BankAccount getMyBankAccount() {
		return myBankAccount;
	}

	public void setMyBankAccount(BankAccount myBankAccount) {
		this.myBankAccount = myBankAccount;
	}

	public CreditCard getMyCC() {
		return myCC;
	}

	public void setMyCC(CreditCard myCC) {
		this.myCC = myCC;
	}

	public IMPS getMyIMPS() {
		return myIMPS;
	}

	public void setMyIMPS(IMPS myIMPS) {
		this.myIMPS = myIMPS;
	}

	public Wallet getMyWallet() {
		return myWallet;
	}

	public void setMyWallet(Wallet myWallet) {
		this.myWallet = myWallet;
	}

	public ProvidersData getMyBiller() {
		return myBiller;
	}

	public void setMyBiller(ProvidersData myBiller) {
		this.myBiller = myBiller;
	}

	public Payee getMyPayee() {
		return myPayee;
	}

	public void setMyPayee(Payee myPayee) {
		this.myPayee = myPayee;
	}

	public Merchant getMyMerchant() {
		return myMerchant;
	}

	public void setMyMerchant(Merchant myMerchant) {
		this.myMerchant = myMerchant;
	}

}
