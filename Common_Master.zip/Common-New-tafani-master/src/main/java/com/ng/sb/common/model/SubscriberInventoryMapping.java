package com.ng.sb.common.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;


@Entity
@Table(name="subscriber_merchant_inventory_mapping")

@XmlRootElement
@NamedQueries({
	 @NamedQuery(name = "SubscriberInventoryMapping.findAll", query = "SELECT subscriberInventoryMapping FROM SubscriberInventoryMapping subscriberInventoryMapping"),
	 @NamedQuery(name = "SubscriberInventoryMapping.findSubscriberPendingPersonalisation", query = "SELECT subscriberInventoryMapping FROM SubscriberInventoryMapping subscriberInventoryMapping where subscriberInventoryMapping.subscriberId=:subscriberId and subscriberInventoryMapping.isPersonalized=0 "),
	 @NamedQuery(name = "SubscriberInventoryMapping.findSubscriberPendingPersonalisationByExternal", query = "SELECT subscriberInventoryMapping FROM SubscriberInventoryMapping subscriberInventoryMapping where subscriberInventoryMapping.subscriberId=:subscriberId and subscriberInventoryMapping.isPersonalized=0 and subscriberInventoryMapping.inventoryId.externalNo=:externalNo "),
	 @NamedQuery(name = "SubscriberInventoryMapping.findById", query = "SELECT subscriberInventoryMapping FROM SubscriberInventoryMapping subscriberInventoryMapping where subscriberInventoryMapping.id=:id"),
	 @NamedQuery(name = "SubscriberInventoryMapping.findBySubscriberIdAndEnable", query = "SELECT subscriberInventoryMapping FROM SubscriberInventoryMapping subscriberInventoryMapping where subscriberInventoryMapping.subscriberId=:subscriberId AND subscriberInventoryMapping.status=true"),
	 @NamedQuery(name = "SubscriberInventoryMapping.findByInventoryMgmntIdAndStatus", query = "SELECT subscriberInventoryMapping FROM SubscriberInventoryMapping subscriberInventoryMapping where subscriberInventoryMapping.inventoryId=:inventoryId AND subscriberInventoryMapping.status=:status"),
	 @NamedQuery(name = "SubscriberInventoryMapping.updateProductStatusByInventoryMgmntId", query = "UPDATE SubscriberInventoryMapping subsInvMngmnt SET subsInvMngmnt.status=:status , subsInvMngmnt.deviceId=:deviceId , subsInvMngmnt.updatedOn=:updatedOn where subsInvMngmnt.inventoryId=:inventoryId"),
	 @NamedQuery(name = "SubscriberInventoryMapping.findAllActiveProducts", query ="SELECT subscriberInventoryMapping FROM SubscriberInventoryMapping subscriberInventoryMapping where subscriberInventoryMapping.subscriberId=:subscriberId AND subscriberInventoryMapping.status=false AND subscriberInventoryMapping.inventoryId.productStatus in ('OK','ISSUED')"),
	 @NamedQuery(name = "SubscriberInventoryMapping.findByExternNo", query ="SELECT subscriberInventoryMapping FROM SubscriberInventoryMapping subscriberInventoryMapping where subscriberInventoryMapping.deviceId=:deviceId"),
	 @NamedQuery(name = "SubscriberInventoryMapping.findBySubscriberIdAndStatus", query = "SELECT subscriberInventoryMapping FROM SubscriberInventoryMapping subscriberInventoryMapping where subscriberInventoryMapping.subscriberId=:subscriberId AND subscriberInventoryMapping.status=:status"),
	 @NamedQuery(name = "SubscriberInventoryMapping.findByProductTypeAndStatus", query = "SELECT subscriberInventoryMapping FROM SubscriberInventoryMapping subscriberInventoryMapping where subscriberInventoryMapping.productType=:productType AND subscriberInventoryMapping.status=:status"),
	 @NamedQuery(name = "SubscriberInventoryMapping.findByExternalNoSubscriberIdAndStatus", query = "SELECT subscriberInventoryMapping FROM SubscriberInventoryMapping subscriberInventoryMapping where subscriberInventoryMapping.deviceId=:deviceId AND subscriberInventoryMapping.subscriberId=:subscriberId AND subscriberInventoryMapping.status=:status"),
	 @NamedQuery(name = "SubscriberInventoryMapping.findBySubscriberInventoryByPtySubsIdAndStatus", query = "SELECT subscriberInventoryMapping FROM SubscriberInventoryMapping subscriberInventoryMapping where  subscriberInventoryMapping.productType=:productType AND subscriberInventoryMapping.subscriberId=:subscriberId AND subscriberInventoryMapping.status=:status"),
})
public class SubscriberInventoryMapping 
{
	@Id
	@GeneratedValue
	private Integer id;
	@Column(name = "userId")
	private String userId;
	@ManyToOne
	@JoinColumn(name="inventoryMgmtId", referencedColumnName="id")
	private InventoryMgmt inventoryId;
	@Column(name = "status")
	private boolean status;
	@Column(name = "deviceId")
	private String deviceId;
	@Column(name = "productType")
	private String productType;
	@Column(name = "createdOn")
	private Date createdOn;
	@Column(name = "updatedOn")
	private Date updatedOn;
	@Column(name="userType")
	private String userType;
	@ManyToOne
	@JoinColumn(name="subscriberId", referencedColumnName="id")
	private Subscriber subscriberId;
	@ManyToOne
	@JoinColumn(name="userLoginId", referencedColumnName="id")
	private AccountLoginInfo userLoginId;
	
	private boolean isPersonalized;
	
	public Integer getId() {
		return id;
	}
	public AccountLoginInfo getUserLoginId() {
		return userLoginId;
	}
	public void setUserLoginId(AccountLoginInfo userLoginId) {
		this.userLoginId = userLoginId;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public InventoryMgmt getInventoryId() {
		return inventoryId;
	}
	public void setInventoryId(InventoryMgmt inventoryId) {
		this.inventoryId = inventoryId;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public String getDeviceId() {
		return deviceId;
	}
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public Date getUpdatedOn() {
		return updatedOn;
	}
	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	public Subscriber getSubscriberId() {
		return subscriberId;
	}
	public void setSubscriberId(Subscriber subscriberId) {
		this.subscriberId = subscriberId;
	}
	public boolean isPersonalized() {
		return isPersonalized;
	}
	public void setPersonalized(boolean isPersonalized) {
		this.isPersonalized = isPersonalized;
	}
	
	

}
