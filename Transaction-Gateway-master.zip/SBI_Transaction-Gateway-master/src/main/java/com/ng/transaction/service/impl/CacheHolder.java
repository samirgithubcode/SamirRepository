/**
 * 
 */
package com.ng.transaction.service.impl;

import java.util.HashMap;
import java.util.Map;

import com.ng.sb.common.dataobject.HostSubVersionData;
import com.ng.sb.common.dataobject.ServiceConfigData;
import com.ng.sb.common.util.SpringContextUtil;
import com.ng.sb.common.util.SystemConstant;
import com.ng.transaction.service.ICacheFill;
import com.ng.transaction.service.ICacheHolder;



/**
 * @author gaurav
 *
 */

public class CacheHolder implements ICacheHolder {

	private Map<ServiceConfigData,ServiceConfigData> serviceConfigMap=new HashMap<ServiceConfigData, ServiceConfigData>();
	private Map<HostSubVersionData,HostSubVersionData> hostSubVersionMap = new HashMap<HostSubVersionData, HostSubVersionData>();
	private static CacheHolder instance = new CacheHolder();
	ICacheFill cacheFill=(ICacheFill)new SpringContextUtil().getBean(SystemConstant.CACHE_FILL_SERVICE);
	private CacheHolder(){
		fillData();
	}
	
	private void fillData(){
		try {
			hostSubVersionMap=cacheFill.getHostSubVersionMap();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	public static CacheHolder getInstance(){
		return instance;
	}
	
	@Override
	public ServiceConfigData getServiceInfo(Integer mvCode,String serviceCode){
		if(mvCode!=null && mvCode!=0){
			return serviceConfigMap.get(new ServiceConfigData(mvCode, serviceCode));
		}
		return null;
	}
	
	@Override
	public HostSubVersionData getHostSubVersion(Integer code){
		if(code!=null && code!=0){
			return hostSubVersionMap.get(new HostSubVersionData(code));
		}
		return null;
	}
}
