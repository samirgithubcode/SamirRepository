/**
 * 
 */
package com.ng.transaction.service.impl;

import java.io.FileWriter;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.ng.sb.common.dataobject.BridgeDataObject;
import com.ng.sb.common.dataobject.BridgeDataObject.ServiceCall;
import com.ng.sb.common.dataobject.BridgeDataObject.ServiceType;
import com.ng.sb.common.dataobject.CustomerAccountData;
import com.ng.sb.common.dataobject.HostSubVersionData;
import com.ng.sb.common.dataobject.PlatformLoginData;
import com.ng.sb.common.dataobject.ServiceConfigData;
import com.ng.sb.common.dataobject.ServiceParamsMappingData;
import com.ng.sb.common.dataobject.SubsAccountDetails;
import com.ng.sb.common.dataobject.TransactionData;
import com.ng.sb.common.dataobject.Wallet;
import com.ng.sb.common.exception.DecryptionException;
import com.ng.sb.common.exception.NoValidCustomerException;
import com.ng.sb.common.exception.ServiceMappingException;
import com.ng.sb.common.model.CustomerDetails;
import com.ng.sb.common.model.HostSubVersion;
import com.ng.sb.common.model.MasterVersion;
import com.ng.sb.common.model.Partner;
import com.ng.sb.common.model.Subscriber;
import com.ng.sb.common.model.TransactionInfo;
import com.ng.sb.common.service.impl.SuperParentService;
import com.ng.sb.common.util.BCDConvert;
import com.ng.sb.common.util.BinarySearcher;
import com.ng.sb.common.util.DataEncription;
import com.ng.sb.common.util.IDataEncription;
import com.ng.sb.common.util.KeyEncryptionUtils;
import com.ng.sb.common.util.OTAUtility;
import com.ng.sb.common.util.SMSUtility;
import com.ng.sb.common.util.SystemConstant;
import com.ng.transaction.dao.ITransactionDAO;
import com.ng.transaction.service.ITransactionService;
import com.ng.transaction.util.ParameterFillerUtil;

/**
 * @author gaurav
 * Common Service for Transaction Service
 */
@Service(value=SystemConstant.TRANSACTION_SERVICE)
public class TransactionService extends SuperParentService implements ITransactionService 
{

	private static final Logger LOGGER = LoggerFactory.getLogger(TransactionService.class);
	private static final String INITIAL="INITIAL-";
	@Autowired
	PlatformLoginData platformLoginData;
	
	@Autowired
	IDataEncription dataEncription;
	
	@Autowired
	SBITransactionService sbiTransactionService;
	
	protected BridgeDataObject invokeBridge(BridgeDataObject bridgeDataObject)
	{
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In ServiceInvoker -  invokeBridge method. ");
		bridgeDataObject.setServiceCall(ServiceCall.BRIDGE);
		try {
			return new ServiceInvoker().invoke(bridgeDataObject);
		} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@Autowired
	CacheLoader cacheLoader;
	
	@Autowired
	SMSUtility smsUtility;
	
	@Autowired
	OTAUtility otaUtility;
	
	@Autowired
	ITransactionDAO transactionDAO;
	
	String uri=null,checkContentType=null,userIp=null,reqStkCode=null,msisdn=null,simSerialNumber=null,decriptionKey=null,decriptedMessage=null,combinedParamString=null,simVersion=null,responseMessage=null,menuVersion=null,transactionId=null;
	DataEncription objDE=null;	
	public TransactionInfo saveTransactionInfo(BridgeDataObject bridgeDataObject)
	{
		TransactionInfo transactionInfo=transactionDAO.saveTransactionInfo(bridgeDataObject);
		return transactionInfo;
	}
	/***
	 *  To be called from Secure Element
	 */
	public void requestFacade(TransactionData transactionData) throws DecryptionException,NoValidCustomerException,ServiceMappingException
	{
		try{
			getCustomerDetails(transactionData); // getting customer detail
			
			if(!decryptString(transactionData,true)){ //decrypting the command string
				reqNormalPathFacade(transactionData); // For the normal routine path for the Transaction.
			}else{
				reqFirstTimeUserPathFacade(transactionData); // For the First Time User authentication and OTA sending.
			}
		} catch (Exception e) 
		{
			e.printStackTrace();
			
			saveTransactionReqeustData(transactionData, true, e.getMessage());
		}
	}
	@Transactional
	private void saveTransactionReqeustData(TransactionData transactionData, boolean isException, String errorMsg) 
	{
	
		try{
			TransactionInfo txnInfo = new TransactionInfo();
			txnInfo.setDate(new Date());
			txnInfo.setMsisdn(transactionData.getMsisdn());
			txnInfo.setTxnId(transactionData.getTransactionId());
			txnInfo.setRequestPlainMessage(transactionData.getRequestMessage());
			
			if(transactionData.getSubsAccountDetails() != null)
			{
				txnInfo.setSkuExternalNumber(transactionData.getSubsAccountDetails().getSimExternalNumber().toString());
				txnInfo.setSkuInternalNumber(transactionData.getSubsAccountDetails().getSimInternalNumber().toPlainString());
				txnInfo.setMvId(new MasterVersion(transactionData.getSubsAccountDetails().getMvId()));
				txnInfo.setHsvId(new HostSubVersion(transactionData.getSubsAccountDetails().getHsvId()));
				
			}
			
			txnInfo.setRequestPlainMessage(transactionData.getOperationalCommand());
			txnInfo.setRequestMsg(transactionData.getDecryptedMessage());
			txnInfo.setServiceDefnitioon(transactionData.getReqStkCode());
			
			txnInfo.setResponseStatus(!isException);
			txnInfo.setShortCode(Integer.parseInt(transactionData.getServiceCode()));
			txnInfo.setResponseMsg(errorMsg);
			
			txnInfo.setProcessTime(System.currentTimeMillis() - transactionData.getRequestTime());
			
			boolean saveStatus = transactionDAO.persistObject(txnInfo);
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	/****
	 * The normal path require for routine transactions.
	 * @param transactionData
	 * @throws NoValidCustomerException
	 * @throws ServiceMappingException
	 */
	private void reqNormalPathFacade(TransactionData transactionData) throws NoValidCustomerException, ServiceMappingException{
		isValidCustomer(transactionData); // validating internal no. from database and from command string
	try{
		BridgeDataObject bridgeDataObject = createBridgeObject(transactionData,true); // get serviceConfig and its parameter mappings and then create BridgeDataObject

		callService(bridgeDataObject); // call appropriate service 	

		sendResponse(bridgeDataObject);
		
		String responseMsg = null;
		
		if(bridgeDataObject.getBridgeResponse() != null)
			responseMsg = bridgeDataObject.getBridgeResponse().getResponseMsg();
			
		saveTransactionReqeustData(transactionData, false, responseMsg);
		}catch(Exception e)
		{
			e.printStackTrace();
			saveTransactionReqeustData(transactionData, true, e.getMessage());
		}
	}
	
	/***
	 * Special Case which gets executed only for the first time for a overlay.
	 * @param transactionData
	 * @throws NoValidCustomerException
	 * @throws ServiceMappingException
	 */
	 private void reqFirstTimeUserPathFacade(TransactionData transactionData) throws NoValidCustomerException, ServiceMappingException
	 {
		 if(isValidCustomer(transactionData)) // validating internal no. from database and from command string
		 {
			smsUtility.sendHttpResponse(transactionData.getMsisdn(), platformLoginData.getOverlayWelcomeMessage());
			 
			// User Registration with SBI
			try {
				ResponseEntity<String> result = sbiTransactionService.registerCustomerToSBI(transactionData);
				if(result.getStatusCode() == HttpStatus.ACCEPTED && result.getBody() != null) {
					
					boolean status = updateCustomerData(transactionData.getMsisdn());
					if(!status) {
						LOGGER.info("Failed to update register to bank flag in db, trying again...");						
					}
				}
				
			} catch(Exception ex) {
				LOGGER.info("Error registering user to sbi: "+ex);
			}
			// Ends Here
			getCustomerAccountInfo(transactionData);
		 }
		 
		 saveTransactionReqeustData(transactionData, false, platformLoginData.getOverlayWelcomeMessage());
	}
	 
	private boolean updateCustomerData(String msisdn) {
		try {
			Subscriber sub = transactionDAO.updateCustomer(msisdn);
			return sub.isRegisteredToBank();
		}catch(Exception ex) {
			LOGGER.info("Error updating registered status to subscriber table: "+ex);
			return false;
		}
	}
	
	public CustomerAccountData getCustomerAccountInfo(TransactionData transactionData) 
	{
		CustomerAccountData customerData = null;
		
		try
		{
			customerData = transactionDAO.getCustomerDetails(transactionData.getMsisdn());
			
			if(customerData != null)
			{
				List<CustomerDetails> customerAccounts =  customerData.getAccountData();
				
				//Un-Comment Below lines to send OTA 
				
				/*int counter = 0;
				
				for(CustomerDetails customerAccount : customerAccounts)
				{
					String accountId = "A"+counter;
					
					String nickName = customerAccount.getAccountName();
					
					String accountName = customerAccount.getAccountName();
					
					String accountNumber = customerAccount.getAccountNumber().toString();
					
					String ifscCode = customerAccount.getIfscCode();
					
					String mmid = "0139012";
					
					StringBuilder builder = new StringBuilder();
					
					builder.append("02" + KeyEncryptionUtils.stringToHex(accountId)); //hexValue of A0
					builder.append(KeyEncryptionUtils.paddedData(Integer.toHexString(nickName.length()), 2)+(KeyEncryptionUtils.stringToHex(nickName)));
					builder.append(KeyEncryptionUtils.paddedData(Integer.toHexString(accountName.length()), 2)+(KeyEncryptionUtils.stringToHex(accountName)));
					builder.append(KeyEncryptionUtils.paddedData(Integer.toHexString(accountNumber.length()), 2)+(KeyEncryptionUtils.stringToHex(accountNumber)));
					builder.append(KeyEncryptionUtils.paddedData(Integer.toHexString(ifscCode.length()), 2)+(KeyEncryptionUtils.stringToHex(ifscCode)));
					builder.append(KeyEncryptionUtils.paddedData(Integer.toHexString(mmid.length()), 2)+(KeyEncryptionUtils.stringToHex(mmid)));
					
					String dataLength =  KeyEncryptionUtils.paddedData(Integer.toHexString((builder.toString().length()/2)), 2);
					
					
					String finalData = "61"+dataLength+builder.toString();
					
					
					otaUtility.sendHttpResponse(transactionData.getMsisdn(), 3, finalData);
					
					counter++;
				}*/
			}
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return customerData;
	}
	/***
	 *  To be called from Tool for testing
	 */
	public void requestFacadeWithoutEncryption(TransactionData transactionData) throws DecryptionException,NoValidCustomerException,ServiceMappingException
	{
		LOGGER.info("Start -  TransactionId : "+ transactionData.getTransactionId() + " In TransactionService -  requestFacadeWithoutEncryption method. ");
		getCustomerDetails(transactionData); // getting customer detail
		//decryptString(transactionData); //decrypting the command string
		
		reqFirstTimeUserPathFacade(transactionData);
		/*isValidCustomer(transactionData); // validating internal no. from database and from command string
		BridgeDataObject bridgeDataObject = createBridgeObject(transactionData,true); // get serviceConfig and its parameter mappings and then create BridgeDataObject
//		TODO - COMMENTING OUT ONLY FOR DEMO PURPOSE
		 callService(bridgeDataObject); // call appropriate service 	
		//String message = demoClass.doBalanceTransfer(bridgeDataObject, transactionData);
		//sendResponseByOTA(message, bridgeDataObject.getPayerWallet().getMsisdn());
		sendResponse(bridgeDataObject);*/
		LOGGER.info("End -  TransactionId : "+ transactionData.getTransactionId() + " In TransactionService -  requestFacadeWithoutEncryption method. ");
	}
	
	private void getCustomerDetails(TransactionData transactionData) throws NoValidCustomerException
	{
		LOGGER.info("Start -  TransactionId : "+ transactionData.getTransactionId() + " In TransactionService -  getCustomerDetails method. ");
		//Object[] subsInfo=transactionDAO.customerDetailsByInventory(transactionData);
		Object[] subsInfo=transactionDAO.customerDetails(transactionData);
		if(subsInfo==null || (subsInfo!=null && subsInfo==null || subsInfo[3]==null || subsInfo[1]==null)){
			throw new NoValidCustomerException("No record found for customer having MSISDN # " + transactionData.getMsisdn());
		}
			
		SubsAccountDetails subsAccountDetails= new SubsAccountDetails();
		subsAccountDetails.setSimInternalNumber((BigDecimal)subsInfo[0]);
		subsAccountDetails.setEncryptionKey((String)subsInfo[3]);
		subsAccountDetails.setHsvId((Integer)subsInfo[2]);
		subsAccountDetails.setMvId((Integer)subsInfo[1]);
		subsAccountDetails.setSimExternalNumber((BigInteger)subsInfo[4]);
		transactionData.setSubsAccountDetails(subsAccountDetails);
		if(subsAccountDetails!=null 
				&& subsAccountDetails.getSimInternalNumber()!=null && !subsAccountDetails.getSimInternalNumber().toString().isEmpty()
				&& subsAccountDetails.getEncryptionKey()!=null && !subsAccountDetails.getEncryptionKey().isEmpty()
				&& subsAccountDetails.getHsvId()!=null && subsAccountDetails.getHsvId()!=0
				&& subsAccountDetails.getMvId()!=null && subsAccountDetails.getMvId()!=0){
			LOGGER.info("TransactionId : "+ transactionData.getTransactionId() + " Customer ## " + transactionData.getMsisdn() 
					+ " has SIMInternalNo ## " + subsAccountDetails.getSimInternalNumber()
					+ "  DecryptionKey ## " + subsAccountDetails.getEncryptionKey()
					+ "  HostSubVersionId ## " + subsAccountDetails.getHsvId()
					+ "  MasterVersionId ## " + subsAccountDetails.getMvId());
		}else{
			throw new NoValidCustomerException("There is issue in finding SIMInternalNo/DecryptionKey/HostSubVersionId/MasterVersionId for customer having MSISDN # " + transactionData.getMsisdn());
		}
		LOGGER.info("End -  TransactionId : "+ transactionData.getTransactionId() + " In TransactionService -  getCustomerDetails method. ");
	}
	
	private boolean isValidCustomer(TransactionData transactionData) throws NoValidCustomerException{
		LOGGER.info("TransactionId : "+ transactionData.getTransactionId() + " In TransactionService -  isValidCustomer method. ");
		if(transactionData.getSubsAccountDetails().getSimInternalNumber().equals(new BigDecimal(transactionData.getInternalNumberRequest()))){
			return true;
		}else{
			throw new NoValidCustomerException("InternalNo. from commandString and database didn't match for customer having MSISDN # " + transactionData.getMsisdn());
		}
	}
	
	public static void main(String[] args) {
		String decryptedString="aaa-8888889999+vvgbbbbbbbb+1-2009-0000000007-";
		
		String mainArr[] = decryptedString.split("-");
		int i=0;
		for(String str : mainArr){
			if(i==0){
				System.out.println("STK Code# " + str);	
			}
			if(i==1){
				System.out.println("Command String# " + str);				
			}
			if(i==2){
				System.out.println("STK Version# " + str);				
			}
			if(i==3){
				System.out.println("Internal No# " + str);				
			}
			if(i==4){
				System.out.println("Token# " + str);				
			}
			++i;
		}
		
	}
	private boolean decryptString(TransactionData transactionData,boolean isNewVersion) throws DecryptionException
	{
		LOGGER.info("Start -  TransactionId : "+ transactionData.getTransactionId() + " In TransactionService -  decryptString method. ");
		//DataEncription objDE = new DataEncription();
		try {
			String decryptedString = dataEncription.decryptString(transactionData.getSubsAccountDetails().getEncryptionKey(), transactionData.getInternalNumberRequest());
			
		/*	decryptedString = decryptedString.replace(".", "2E");
			decryptedString = decryptedString.replace(",", "2C");
			//decryptedString = decryptedString.replace("-", "2D");
			decryptedString = decryptedString.replace("!", "21");
			decryptedString = decryptedString.replace("?", "3F");
			*/
			String fileLocation = "/opt/tafani/logs/overlay_logs.txt";
//			String fileLocation = "Z://overlay_logs/overlay_logs.txt";

			FileWriter writer = new FileWriter(fileLocation, true);
			
			writer.write("("+new java.sql.Timestamp(System.currentTimeMillis())+ ")  ("+transactionData.getMsisdn()+")  ("+decryptedString+")");
			writer.write("\n");
			writer.flush();
			writer.close();
			
			transactionData.setDecryptedMessage(decryptedString);
			if(decryptedString!=null && !decryptedString.isEmpty() && decryptedString.toUpperCase().startsWith(INITIAL)){
				// work done for the initial message received from the overlay
				String mainArr[] = decryptedString.split("-");
				int i=0;
				for(String str : mainArr){
					if(i==0){
						// Just Printing the initial message
						System.out.println("Initial Message # " + str);	
					}
					if(i==1){
						System.out.println("STK Version# " + str);	
						transactionData.setMenuVersionRequest(str);
					}
					if(i==2){
						System.out.println("Internal No# " + str);		
						transactionData.setInternalNumberRequest(str);
					}if(i==3){
						System.out.println("Token# " + str);	
						transactionData.setToken(str);
					}
					++i;
				}
				return Boolean.TRUE;
			}
			else if(decryptedString!=null && !decryptedString.isEmpty() && decryptedString.contains("-") && decryptedString.contains("+")){
				
				String mainArr[] = decryptedString.split("-");
				int i=0;
				for(String str : mainArr){
					if(i==0){
						System.out.println("STK Code# " + str);	
						transactionData.setReqStkCode(str);
					}
					if(i==1){
						System.out.println("Command String# " + str);
						transactionData.setCombinedParamString(str);
					}
					if(i==2){
						System.out.println("STK Version# " + str);	
						transactionData.setMenuVersionRequest(str);
					}
					if(i==3){
						System.out.println("Internal No# " + str);		
						transactionData.setInternalNumberRequest(str);
					}
					if(i==4){
						System.out.println("Token# " + str);	
						transactionData.setToken(str);
					}
					++i;
				}
				return Boolean.FALSE;
			}else{
				throw new DecryptionException("TransactionId : "+ transactionData.getTransactionId() + " Problem in decrypting String.");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new DecryptionException("TransactionId : "+ transactionData.getTransactionId() + e.getMessage());
		}
	}
	
	
	
	private void decryptString(TransactionData transactionData) throws DecryptionException
	{
		LOGGER.info("Start -  TransactionId : "+ transactionData.getTransactionId() + " In TransactionService -  decryptString method. ");
		try
		{
				objDE=new DataEncription(transactionData.getSubsAccountDetails().getEncryptionKey());
				//****************** Code for BCD to String Conversion ***************************
				byte[] srcBytes=objDE.decrypt(transactionData.getOperationalCommand());
			    byte[] searchBytes = "-".getBytes("utf-8");
		        List<Integer> indexList = new BinarySearcher().searchBytes(srcBytes, searchBytes);
		        if(indexList.size()==3)
			    {
		        	LOGGER.info("Request message pattern is correct !");
		        	int opcodeArrLength=0,combinedParamArrLength=0,simVersionArrLength=0,simIdLength=0,
			        combinedParamCounter=0,simVersionCounter=0,simIdCounter=0;
			        for(int i=0;i<srcBytes.length;i++)
			        {
			        	if(i>=0 && i<indexList.get(0))
			        	{
			        		opcodeArrLength++;
			        	}
			        	else if(i>indexList.get(0) && i<indexList.get(1))
			        	{
			        		combinedParamArrLength++;
			        	}
			        	else if(i>indexList.get(1) && i<indexList.get(2))
			        	{
			        		simVersionArrLength++;
			        	}
			        	else if(i>indexList.get(2))
			        	{
			        		simIdLength++;
			        	}
			        }
			        //**************** generate byte array ****************************
			        byte[] opcodebyteArr=new byte[opcodeArrLength],combinedParambyteArr=new byte[combinedParamArrLength],
			        simVersionByteArr=new byte[simVersionArrLength],simIdArr=new byte[simIdLength];
			        for(int i=0;i<srcBytes.length;i++)
			        {
			        	if(i>=0 && i<indexList.get(0))
			        	{
			        		opcodebyteArr[i]=srcBytes[i];
			        	}
			        	else if(i>indexList.get(0) && i<indexList.get(1))
			        	{
			        		combinedParambyteArr[combinedParamCounter]=srcBytes[i];
			        		combinedParamCounter++;
			        	}
			        	else if(i>indexList.get(1) && i<indexList.get(2))
			        	{
			        		simVersionByteArr[simVersionCounter]=srcBytes[i];
			        		simVersionCounter++;
			        	}
			        	else if(i>indexList.get(2))
			        	{
			        		simIdArr[simIdCounter]=srcBytes[i];
			        		simIdCounter++;
			        	}
			        }
			     	reqStkCode=new String(opcodebyteArr);
					transactionData.setReqStkCode(reqStkCode);
					combinedParamString=new String(combinedParambyteArr);
					transactionData.setCombinedParamString(combinedParamString);
					String reqSimMenuVersion=BCDConvert.BCDtoString(simVersionByteArr);
					transactionData.setMenuVersionRequest(reqSimMenuVersion);
					simSerialNumber=BCDConvert.BCDtoString(simIdArr).substring(0, 10);
					transactionData.setInternalNumberRequest(simSerialNumber);
					decriptedMessage=reqStkCode+"-"+combinedParamString+"-"+reqSimMenuVersion+"-"+simSerialNumber;
					LOGGER.info("End -  TransactionId : "+ transactionData.getTransactionId() + " In TransactionService -  decryptString method. ");
			    }
		}	
		catch(Exception ex)
		{
		  	ex.printStackTrace();
		  	throw new DecryptionException("Issue in decrypting input command String for customer having MSISDN # " + transactionData.getMsisdn());
		}
	}	
	private BridgeDataObject createBridgeObject(TransactionData transactionData) throws ServiceMappingException
	{
		BridgeDataObject bridgeObject = null;
		try{
		List<Object[]> serviceParametersList=transactionDAO.serviceInfoDataList(transactionData.getReqStkCode(),transactionData);
		List<ServiceParamsMappingData> serviceParamsMappingDataList=null;
		for(Object[] paramList:serviceParametersList)
		{	
			if(serviceParamsMappingDataList==null){
				serviceParamsMappingDataList=new ArrayList<>();
			}
			 ServiceParamsMappingData serviceParamsMappingData= new ServiceParamsMappingData(); 
			 serviceParamsMappingData.setServiceId((Integer)paramList[0]);
	 		 serviceParamsMappingData.setObjectMapping((String)paramList[2]);
			 serviceParamsMappingData.setSequence((Integer)paramList[3]);
			 serviceParamsMappingData.setIsnumericField((Boolean)paramList[4]);
			 serviceParamsMappingData.setServiceDef((String)paramList[1]);
			 serviceParamsMappingDataList.add(serviceParamsMappingData);
		}
		if(serviceParamsMappingDataList==null || (serviceParamsMappingDataList!=null && serviceParamsMappingDataList.isEmpty())){
			throw new ServiceMappingException("Issue in ServiceMapping for customer having MSISDN # " + transactionData.getMsisdn());
		}
		transactionData.setServiceParamsMappingList(serviceParamsMappingDataList);
		bridgeObject = new ParameterFillerUtil().fillParams(serviceParamsMappingDataList.get(0).getServiceDef(),serviceParamsMappingDataList.get(0).getServiceId(),transactionData.getCombinedParamString(),serviceParamsMappingDataList,transactionData);
		System.out.println(bridgeObject.getName());
		
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			throw new ServiceMappingException("Issue in ServiceMapping for customer having MSISDN # " + transactionData.getMsisdn());
		}
		return bridgeObject;
	 }
	
	
	private BridgeDataObject createBridgeObject(TransactionData transactionData,boolean cache) throws ServiceMappingException
	{
		LOGGER.info("Start - TransactionId : "+ transactionData.getTransactionId() + " In TransactionService -  createBridgeObject method. ");
		BridgeDataObject bridgeObject = null;
		HostSubVersionData hostSubVersionData = null;
		try{
			Map<HostSubVersionData, HostSubVersionData>  hostSubVersionMap = cacheLoader.getHostSubVersionMap();
			hostSubVersionData = hostSubVersionMap.get(new HostSubVersionData(transactionData.getSubsAccountDetails().getHsvId()));
			List<ServiceParamsMappingData> serviceParamsMappingDataList=null;
		
			ServiceConfigData scData = hostSubVersionData.getServiceConfigMap().get(new ServiceConfigData(transactionData.getSubsAccountDetails().getMvId(), transactionData.getReqStkCode()));
			serviceParamsMappingDataList = scData.getParamMappings();
			if(serviceParamsMappingDataList==null || (serviceParamsMappingDataList!=null && serviceParamsMappingDataList.isEmpty())){
				throw new ServiceMappingException("Issue in ServiceMapping for customer having MSISDN # " + transactionData.getMsisdn());
			}
			transactionData.setServiceParamsMappingList(serviceParamsMappingDataList);
			bridgeObject = new ParameterFillerUtil().fillParams(scData.getServiceDefinition(),scData.getId(),transactionData.getCombinedParamString(),serviceParamsMappingDataList,transactionData);
			
				
			System.out.println(bridgeObject.getName());
			
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
				throw new ServiceMappingException("Issue in ServiceMapping for customer having MSISDN # " + transactionData.getMsisdn());
			}
			if(bridgeObject!=null){
				// Add Cache Reference in BridgeDataObject , to be used in Bridge
				bridgeObject.setHostSubVersionData(hostSubVersionData);
				
				// Set PayerWalletId
				if(bridgeObject.getPayerWallet()!=null && bridgeObject.getPayerWallet().getMsisdn()==null){
					bridgeObject.getPayerWallet().setMsisdn(transactionData.getMsisdn());
				}
				
				// Set Transaction Data
				bridgeObject.setTransactionData(transactionData);
			}
			// Setting Payee Wallet Code in case of Wallet To Wallet Transaction , Where we are only setting Payer Wallet Code.
			setPayeeWalletCode(bridgeObject);
			
			// Adding Wallet Code in case of Money Transfer Service
			addWalletCodeForMoneyTransfer(bridgeObject);
			LOGGER.info("End - TransactionId : "+ transactionData.getTransactionId() + " In TransactionService -  createBridgeObject method. ");
			return bridgeObject;
	 }
	
	private void updateBankingPINSpecialCharacters(BridgeDataObject bridgeObject) 
	{
		String decryptedBankingPin = bridgeObject.getPayerBankAccount().getbPin();
		
		decryptedBankingPin = decryptedBankingPin.replace(SystemConstant.HEX_CODE_FOR_AT_SIGN, "40");
		decryptedBankingPin = decryptedBankingPin.replace(SystemConstant.HEX_CODE_FOR_UNDERSCORE_SIGN, "5F");
		//decryptedBankingPin = decryptedBankingPin.replace(SystemConstant.HEX_CODE_FOR_EXCLAMATION_SIGN, "21");
		//decryptedBankingPin = decryptedBankingPin.replace(SystemConstant.HEX_CODE_FOR_COMMA_SIGN, ",");
		//decryptedBankingPin = decryptedBankingPin.replace(SystemConstant.HEX_CODE_FOR_HYPHEN_SIGN, "-");
		//decryptedBankingPin = decryptedBankingPin.replace(SystemConstant.HEX_CODE_FOR_DOT_SIGN, ".");
		//decryptedBankingPin = decryptedBankingPin.replace(SystemConstant.HEX_CODE_FOR_QUESTION_MARK_SIGN, "?");
		
		bridgeObject.getPayerBankAccount().setbPin(decryptedBankingPin);
	}
	private void setPayeeWalletCode(BridgeDataObject bridgeObject){
		if(bridgeObject!=null && bridgeObject.getPayerWallet()!=null && bridgeObject.getPayerWallet().getWalletCode()!=null && bridgeObject.getPayerWallet().getWalletCode()>0
				&& bridgeObject.getPayeeWallet()!=null && bridgeObject.getPayeeWallet().getMsisdn()!=null && !bridgeObject.getPayeeWallet().getMsisdn().isEmpty()){
			bridgeObject.getPayeeWallet().setWalletCode(bridgeObject.getPayerWallet().getWalletCode());
		}
	}

	private void addWalletCodeForMoneyTransfer(BridgeDataObject bridgeObject){
		if(bridgeObject!=null && bridgeObject.getPayerWallet()!=null 
				&& bridgeObject.getPayerWallet().getMsisdn()!=null 
				&& !bridgeObject.getPayerWallet().getMsisdn().isEmpty()
				&& bridgeObject.getServiceType()!=null && bridgeObject.getServiceType()==ServiceType.MONEY_TRANSFER){
			// Testing code - Hardcoding for EKO Wallet
			//bridgeObject.getPayerWallet().setWalletCode(102);
			bridgeObject=getWalletDetail(bridgeObject);
		}
	}
	private BridgeDataObject getWalletDetail(BridgeDataObject bridgeObject){
		Partner partner=transactionDAO.getPartnerByNickName(platformLoginData.getHostWallet());
		Wallet wallet=bridgeObject.getPayerWallet();
		wallet.setCode(partner.getPartnerCode());
		wallet.setId(partner.getId());
		bridgeObject.setPayerWallet(wallet);
		return bridgeObject;
	}
	
	public BridgeDataObject callService(BridgeDataObject bridgeDataObject) throws Exception {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In TransactionService -  createBridgeObject method. ");
		bridgeDataObject.setServiceCall(ServiceCall.TRANSACTION);
		try {
			return new ServiceInvoker().invoke(bridgeDataObject);
		} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
			// TODO Auto-generated catch block
			throw e;
		}
	}
	
	/**
	 * For Testing purpose . To send the SMS message
	 * @param msg
	 * @param msisdn
	 * @returnn	
	 */
	private boolean sendResponseBySMS(String msg,String msisdn){
		LOGGER.info("Sending response to customer ... " + msg);
		smsUtility.sendHttpResponse(msisdn, msg);
		return true;
	}
	
	/***
	 * For Testing purpose . To send the OTA message
	 * @param msg
	 * @param msisdn
	 * @return
	 */
	private boolean sendResponseByOTA(String msg,String msisdn){
		LOGGER.info("Sending response to customer ... " + msg);
		smsUtility.sendHttpResponse(msisdn, msg);
		return true;
	}
	
	private boolean sendResponse(BridgeDataObject bridgeDataObject){
		if(bridgeDataObject!=null && bridgeDataObject.getBridgeResponse()!=null && bridgeDataObject.getBridgeResponse().getMsidnToSendMsg()!=null 
				&& !bridgeDataObject.getBridgeResponse().getMsidnToSendMsg().isEmpty() && bridgeDataObject.getBridgeResponse().getResponseMsg()!=null
				&& !bridgeDataObject.getBridgeResponse().getResponseMsg().isEmpty()){
			LOGGER.info("Sending response to customer ... " + bridgeDataObject.getBridgeResponse().getMsidnToSendMsg());
			// MSISDN is hardcoded
			//smsUtility.sendHttpResponse("918447623227", bridgeDataObject.getBridgeResponse().getResponseMsg());
			smsUtility.sendHttpResponse(bridgeDataObject.getBridgeResponse().getMsidnToSendMsg(), bridgeDataObject.getBridgeResponse().getResponseMsg());
		}
		return true;
	}
}
