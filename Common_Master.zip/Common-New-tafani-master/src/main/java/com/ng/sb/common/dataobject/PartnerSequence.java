/**
 * 
 */
package com.ng.sb.common.dataobject;

import java.util.HashMap;
import java.util.Map;

/**
 * @author gaurav
 *
 */
public class PartnerSequence extends BaseObjectData {
	private static final long serialVersionUID = 1L;
	private Map<Integer, PartnerData> partnerMap = new HashMap<>();

	public Map<Integer, PartnerData> getPartnerMap() {
		return partnerMap;
	}

	public void setPartnerMap(Map<Integer, PartnerData> partnerMap) {
		this.partnerMap = partnerMap;
	}

}
