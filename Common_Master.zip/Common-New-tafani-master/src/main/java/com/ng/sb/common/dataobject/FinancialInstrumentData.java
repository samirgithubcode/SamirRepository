/**
 * 
 */
package com.ng.sb.common.dataobject;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @author abhishek
 *
 */
public class FinancialInstrumentData extends BaseObjectData{

	private static final long serialVersionUID = 1L;
	private String type;
	private Integer showPartner;
	
	private String instrumentname;
	
	private String fromDate;
	private String toDate;
	
	private Integer[] instrumentlist;
	
	private String[] financialnstrumentlist;
	private Integer instrumentId;

	
	private String status;
	private String servicename;
	
	private String servicedesc;
	private Map<Integer,String> maplist;
	private List<FinancialInstrumentData> lists;
	
	private Integer financialinstrumentId;
	
	private Integer financialserviceId;
	
	private String[] productservicemapId;
	
	public String[] getProductservicemapId() {
		return productservicemapId;
	}

	public void setProductservicemapId(String[] productservicemapId) {
		this.productservicemapId = productservicemapId;
	}

	private Map<String,String> productmap;
	public List<String> getProductlist() {
		return productlist;
	}

	public void setProductlist(List<String> productlist) {
		this.productlist = productlist;
	}

	private Set<String> productset;
	private List<String> productlist;
	
	
	
	
	
	
	public Set<String> getProductset() {
		return productset;
	}

	public void setProductset(Set<String> productset) {
		this.productset = productset;
	}

	public Map<String, String> getProductmap() {
		return productmap;
	}

	public void setProductmap(Map<String, String> productmap) {
		this.productmap = productmap;
	}

	public Integer getFinancialserviceId() {
		return financialserviceId;
	}

	public void setFinancialserviceId(Integer financialserviceId) {
		this.financialserviceId = financialserviceId;
	}

	public Integer getFinancialinstrumentId() {
		return financialinstrumentId;
	}

	public void setFinancialinstrumentId(Integer financialinstrumentId) {
		this.financialinstrumentId = financialinstrumentId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}


	public String[] getFinancialnstrumentlist() {
		return financialnstrumentlist;
	}

	public void setFinancialnstrumentlist(String[] financialnstrumentlist) {
		this.financialnstrumentlist = financialnstrumentlist;
	}

	public Integer[] getInstrumentlist() {
		return instrumentlist;
	}

	public void setInstrumentlist(Integer[] instrumentlist) {
		this.instrumentlist = instrumentlist;
	}

	
	
	public Integer getInstrumentId() {
		return instrumentId;
	}

	public void setInstrumentId(Integer instrumentId) {
		this.instrumentId = instrumentId;
	}


	
	public Map<Integer, String> getMaplist() {
		return maplist;
	}

	public void setMaplist(Map<Integer, String> maplist) {
		this.maplist = maplist;
	}

	public String getServicename() {
		return servicename;
	}

	public void setServicename(String servicename) {
		this.servicename = servicename;
	}

	public String getServicedesc() {
		return servicedesc;
	}

	public void setServicedesc(String servicedesc) {
		this.servicedesc = servicedesc;
	}

	

	public List<FinancialInstrumentData> getLists() {
		return lists;
	}

	public void setLists(List<FinancialInstrumentData> lists) {
		this.lists = lists;
	}

	public String getInstrumentname() {
		return instrumentname;
	}

	public void setInstrumentname(String instrumentname) {
		this.instrumentname = instrumentname;
	}

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public Integer getShowPartner() {
		return showPartner;
	}

	public void setShowPartner(Integer showPartner) {
		this.showPartner = showPartner;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
}
