/**
 * 
 */
package com.ng.transaction.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.ng.sb.common.dataobject.BridgeDataObject;
import com.ng.sb.common.util.SystemConstant;
import com.ng.transaction.service.IMWalletAgentService;
import com.ng.transaction.service.IMWalletCustomerService;

/**
 * @author gaurav
 *
 */
@Service(value=SystemConstant.MWALLET_SERVICE)
public class MWalletService extends WalletService implements IMWalletCustomerService, IMWalletAgentService {

	private static final Logger LOGGER = LoggerFactory.getLogger(MWalletService.class);

	@Override
	public BridgeDataObject agentWalletCheckBalance(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction MWalletService -  agentWalletCheckBalance method. ");
		return super.walletCheckBalance(bridgeDataObject);
	}

	@Override
	public BridgeDataObject custwalletCheckBalance(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction MWalletService -  custwalletCheckBalance method. ");
		return super.walletCheckBalance(bridgeDataObject);
	}
	
	
	@Override
	public BridgeDataObject agentTopUpOnlineWalletToWallet(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction MWalletService -  agentTopUpOnlineWalletToWallet method. ");
		return super.fundTransferWalletToWallet(bridgeDataObject);
	}

	@Override
	public BridgeDataObject agentTopUpOnlineBankToWallet(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction MWalletService -  agentTopUpOnlineBankToWallet method. ");
		return super.fundTransferBankToWallet(bridgeDataObject);
	}

	@Override
	public BridgeDataObject agentTopUpOnlineCCToWallet(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction MWalletService -  agentTopUpOnlineCCToWallet method. ");
		return super.fundTransferCCToWallet(bridgeDataObject);
	}

	@Override
	public BridgeDataObject agentTopUpOnlineIMPSToWallet(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction MWalletService -  agentTopUpOnlineIMPSToWallet method. ");
		return super.fundTransferIMPSToWallet(bridgeDataObject);
	}

	@Override
	public BridgeDataObject agentTopUpAccountBankToBank(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction MWalletService -  agentTopUpAccountBankToBank method. ");
		return super.fundTransferBankToBank(bridgeDataObject);
	}

	@Override
	public BridgeDataObject agentTopUpAccountBankToWallet(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction MWalletService -  agentTopUpAccountBankToWallet method. ");
		return super.fundTransferBankToWallet(bridgeDataObject);
	}

	@Override
	public BridgeDataObject agentTopUpAccountBankToCC(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction MWalletService -  agentTopUpAccountBankToCC method. ");
		return super.fundTransferBankToCC(bridgeDataObject);
	}

	@Override
	public BridgeDataObject agentTopUpAccountBankToIMPS(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction MWalletService -  agentTopUpAccountBankToIMPS method. ");
		return super.fundTransferBankToIMPS(bridgeDataObject);
	}

	@Override
	public BridgeDataObject agentTopUpAccountIMPSToBank(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction MWalletService -  agentTopUpAccountIMPSToBank method. ");
		return super.fundTransferIMPSToBank(bridgeDataObject);
	}

	@Override
	public BridgeDataObject agentTopUpAccountIMPSToWallet(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction MWalletService -  agentTopUpAccountIMPSToWallet method. ");
		return super.fundTransferIMPSToWallet(bridgeDataObject);
	}

	@Override
	public BridgeDataObject agentTopUpAccountIMPSToIMPS(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction MWalletService -  agentTopUpAccountIMPSToIMPS method. ");
		return super.fundTransferIMPSToIMPS(bridgeDataObject);
	}

	@Override
	public BridgeDataObject agentTopUpAccountIMPSToCC(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction MWalletService -  agentTopUpAccountIMPSToCC method. ");
		return super.fundTransferIMPSToCC(bridgeDataObject);
	}

	@Override
	public BridgeDataObject agentTopUpAccountCCToBank(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction MWalletService -  agentTopUpAccountCCToBank method. ");
		return super.fundTransferCCToWallet(bridgeDataObject);
	}

	@Override
	public BridgeDataObject agentTopUpAccountCCToWallet(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction MWalletService -  agentTopUpAccountCCToWallet method. ");
		return super.fundTransferCCToWallet(bridgeDataObject);
	}

	@Override
	public BridgeDataObject agentTopUpAccountCCToIMPS(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction MWalletService -  agentTopUpAccountCCToIMPS method. ");
		return super.fundTransferCCToIMPS(bridgeDataObject);
	}

	@Override
	public BridgeDataObject agentTopUpAccountCCToCC(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction MWalletService -  agentTopUpAccountCCToCC method. ");
		return super.fundTransferCCToCC(bridgeDataObject);
	}

	@Override
	public BridgeDataObject cashOut(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction MWalletService -  cashOut method. ");
		return null;
	}

	@Override
	public BridgeDataObject custTopUpOnlineWalletToWallet(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction MWalletService -  custTopUpOnlineWalletToWallet method. ");
		return super.fundTransferWalletToWallet(bridgeDataObject);
	}

	@Override
	public BridgeDataObject custTopUpOnlineBankToWallet(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction MWalletService -  custTopUpOnlineBankToWallet method. ");
		return super.fundTransferBankToWallet(bridgeDataObject);
	}

	@Override
	public BridgeDataObject custTopUpOnlineCCToWallet(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction MWalletService -  custTopUpOnlineCCToWallet method. ");
		return super.fundTransferCCToWallet(bridgeDataObject);
	}

	@Override
	public BridgeDataObject custTopUpOnlineIMPSToWallet(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction MWalletService -  custTopUpOnlineIMPSToWallet method. ");
		return super.fundTransferIMPSToWallet(bridgeDataObject);
	}

	@Override
	public BridgeDataObject custWalletCashOutToWallet(BridgeDataObject bridgeDataObject) 
	{
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction MWalletService -  custWalletCashOut method. ");
		return super.fundTransferWalletToWallet(bridgeDataObject);
	}

	

	
	
}
