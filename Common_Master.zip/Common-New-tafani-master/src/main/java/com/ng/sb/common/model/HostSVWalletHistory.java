package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author abhishek
 *
 */
@Entity
@Table(name = "HostSVWalletHistory")
@NamedQueries({
		@NamedQuery(name = "HostSVWalletHistory.findAll", query = "SELECT h FROM HostSVWalletHistory h"),
		@NamedQuery(name = "HostSVWalletHistory.findMaxWHId", query = "SELECT h FROM HostSVWalletHistory h WHERE id =(SELECT MAX(id) FROM HostSVWalletHistory h WHERE h.otaMgmtId = :otaMgmtId)"),
		@NamedQuery(name = "HostSVWalletHistory.findByotaMgmtId", query = "SELECT h FROM HostSVWalletHistory h WHERE h.otaMgmtId = :otaMgmtId") })
public class HostSVWalletHistory implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(unique = true, nullable = false)
	private Integer id;

	@Column(name = "date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date date;

	// bi-directional many-to-one association to HostSVWalletDetailHistory
	@OneToMany(mappedBy = "hsvWHID")
	private List<HostSVWalletDetailHistory> hostSvwalletDetailHistories;

	// bi-directional many-to-one association to HostSubVersion
	@ManyToOne
	@JoinColumn(name = "otaMgmtId")
	private OTAManagement otaMgmtId;

	public HostSVWalletHistory() {
		//empty
	}

	public HostSVWalletHistory(Integer id) {
		this.id = id;
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Date getDate() {
		return this.date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public List<HostSVWalletDetailHistory> getHostSvwalletDetailHistories() {
		return this.hostSvwalletDetailHistories;
	}

	public void setHostSvwalletDetailHistories(List<HostSVWalletDetailHistory> hostSvwalletDetailHistories) {
		this.hostSvwalletDetailHistories = hostSvwalletDetailHistories;
	}

	public OTAManagement getOtaMgmtId() {
		return this.otaMgmtId;
	}

	public void setOtaMgmtId(OTAManagement otaMgmtId) {
		this.otaMgmtId = otaMgmtId;
	}

	@Override
	public int hashCode() {
		int hash = 0;
		hash += (id != null ? id.hashCode() : 0);
		return hash;
	}

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof HostSVWalletHistory)) {
			return false;
		}
		HostSVWalletHistory other = (HostSVWalletHistory) object;
		boolean check=true;
		if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
			check= false;
		}
		return check;
	}

	@Override
	public String toString() {
		return "com.ng.sb.common.model.HostSVWalletHistory[ id=" + id + " ]";
	}
}