/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "PartnerPreference")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "PartnerPreference.findAll", query = "SELECT p FROM PartnerPreference p"),
    @NamedQuery(name = "PartnerPreference.findByHostVersion", query = "SELECT p FROM PartnerPreference p where p.hsvId=:hsvId"),
    @NamedQuery(name = "PartnerPreference.findById", query = "SELECT p FROM PartnerPreference p WHERE p.id = :id"),
    @NamedQuery(name = "PartnerPreference.findByHostId", query = "SELECT DISTINCT(p.hsvId) FROM PartnerPreference p WHERE p.hostId = :hostId"),
    @NamedQuery(name = "PartnerPreference.findByType", query = "SELECT p FROM PartnerPreference p WHERE p.type = :type"),
    @NamedQuery(name = "PartnerPreference.deleteByHSVId", query = "DELETE FROM PartnerPreference p WHERE hsvId=:hsvId"), })
public class PartnerPreference implements Serializable {
	private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
    @Basic(optional = false)
    @Column(name = "type", nullable = false, length = 11)
    private String type;
    @JoinColumn(name = "hsvId", referencedColumnName = "id", nullable = false)
    @ManyToOne(optional = false)
    private HostSubVersion hsvId;
    @JoinColumn(name = "hostId", referencedColumnName = "id", nullable = false)
    @ManyToOne(optional = false)
    private AccountInfo hostId;
    
    @Column(name = "sequence")
    private Integer sequence;

	public PartnerPreference() {
		//default
    }

    public PartnerPreference(Integer id) {
        this.id = id;
    }

    public PartnerPreference(Integer id, String type) {
        this.id = id;
        this.type = type;
    }
    public Integer getSequence() {
		return sequence;
	}

	public void setSequence(Integer sequence) {
		this.sequence = sequence;
	}


    
    public AccountInfo getHostId() {
        return hostId;
    }

    public void setHostId(AccountInfo hostId) {
        this.hostId = hostId;
    }
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }


    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }
    
    public HostSubVersion getHsvId() {
        return hsvId;
    }

    public void setHsvId(HostSubVersion hsvId) {
        this.hsvId = hsvId;
    }

   


    @Override
    public boolean equals(Object object) {
        if (!(object instanceof PartnerPreference)) {
            return false;
        }
        PartnerPreference other = (PartnerPreference) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.PartnerPreference[ id=" + id + " ]";
    }
    
}
