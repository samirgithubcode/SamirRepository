package com.ng.sb.common.dataobject;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(Include.NON_NULL)
public class PayloadData  extends BaseObjectData implements ValidationBean{
	private static final long serialVersionUID = 1L;
	private String creationDate;
	private String creationTime;
	private String topUpAmount="0";
	private Integer rechargeStatus;
	private String walletTypeId;
	private String 	expiryDate;
	@JsonProperty("walletid")
	private String walletId;
	@JsonProperty("walletbalance")
	private double walletBalance;
	private String userMobile;
	private String msisdn;
	private String wPin;
	private String otp;
	private String transId;
	private String orderId;
	private String customerMsisdn;
	private String otpLength;
	
	
	public String getCustomerMsisdn() {
		return customerMsisdn;
	}
	public void setCustomerMsisdn(String customerMsisdn) {
		this.customerMsisdn = customerMsisdn;
	}
	public String getOtpLength() {
		return otpLength;
	}
	public void setOtpLength(String otpLength) {
		this.otpLength = otpLength;
	}
	
	public String getTransId() {
		return transId;
	}
	public void setTransId(String transId) {
		this.transId = transId;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	private List<SEissuanceResponseData> seresponselist;

	public String getWalletId() {
		return walletId;
	}
	public void setWalletId(String walletId) {
		this.walletId = walletId;
	}
	public double getWalletBalance() {
		return walletBalance;
	}
	public void setWalletBalance(double walletBalance) {
		this.walletBalance = walletBalance;
	}
	public List<SEissuanceResponseData> getSeresponselist() {
		return seresponselist;
	}
	public void setSeresponselist(List<SEissuanceResponseData> seresponselist) {
		this.seresponselist = seresponselist;
	}
	public String getTopUpAmount() {
		return topUpAmount;
	}
	public void setTopUpAmount(String topUpAmount) {
		this.topUpAmount = topUpAmount;
	}
	public Integer getRechargeStatus() {
		return rechargeStatus;
	}
	public void setRechargeStatus(Integer rechargeStatus) {
		this.rechargeStatus = rechargeStatus;
	}
	public String getWalletTypeId() {
		return walletTypeId;
	}
	public void setWalletTypeId(String walletTypeId) {
		this.walletTypeId = walletTypeId;
	}
	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getUserMobile() {
		return userMobile;
	}
	public void setUserMobile(String userMobile) {
		this.userMobile = userMobile;
	}
	
	public String getwPin() {
		return wPin;
	}
	public void setwPin(String wPin) {
		this.wPin = wPin;
	}

	
	public String getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public String getOtp() {
		return otp;
	}
	public void setOtp(String otp) {
		this.otp = otp;
	}
	
	public String getCreationTime() {
		return creationTime;
	}
	public void setCreationTime(String creationTime) {
		this.creationTime = creationTime;
	}

}
