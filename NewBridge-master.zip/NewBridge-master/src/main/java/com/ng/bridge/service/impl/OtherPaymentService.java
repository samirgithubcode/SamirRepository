/**
 * 
 */
package com.ng.bridge.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ng.bridge.service.IOtherPaymentService;
import com.ng.bridge.service.IPartnerManagementService;
import com.ng.bridge.util.NewConstants;
import com.ng.sb.common.dataobject.BridgeDataObject;
import com.ng.sb.common.exception.BridgeObjectDataException;
import com.ng.sb.common.util.SystemConstant;

/**
 * @author gaurav
 *
 */
@Service(value=SystemConstant.BRIDGE_OTHER_PAYMENT_SERVICE)
public class OtherPaymentService extends FundTransferMgtService implements	IOtherPaymentService {

	private static final Logger LOGGER = LoggerFactory.getLogger(BankingService.class);
	@Autowired
	IPartnerManagementService partnerManagementService;
	
	/* (non-Javadoc)
	 * @see com.ng.transaction.service.IOtherPaymentService#fundTransferToIndividual(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject fundTransferToIndividual(BridgeDataObject bridgeDataObject) {
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge OtherPaymentService -  fundTransferToIndividual method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in fundTransferToIndividual:"+ e);
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ng.transaction.service.IOtherPaymentService#fundTransferToMerchant(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject fundTransferToMerchant(BridgeDataObject bridgeDataObject) {
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge OtherPaymentService -  fundTransferToMerchant method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in fundTransferToMerchant:"+ e);
		}
		return null;
	}

	@Override
	public BridgeDataObject fundTransferWalletToWallet(BridgeDataObject bridgeDataObject) {
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge OtherPaymentService -  fundTransferWalletToWallet method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in fundTransferWalletToWallet:"+ e);
		}
		return null;
	}

	@Override
	public BridgeDataObject fundTransferBankToWallet(BridgeDataObject bridgeDataObject) {
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge OtherPaymentService -  fundTransferBankToWallet method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in fundTransferBankToWallet:"+ e);
		}
		return null;
	}

	@Override
	public BridgeDataObject fundTransferWalletToBank(BridgeDataObject bridgeDataObject) {
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge OtherPaymentService -  fundTransferWalletToBank method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in fundTransferWalletToWallet:"+ e);
		}
		return null;
	}

}
