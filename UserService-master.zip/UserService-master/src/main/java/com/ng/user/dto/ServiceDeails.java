/**
 * 
 */
package com.ng.user.dto;

import com.ng.sb.common.dataobject.ValidationBean;

/**
 * @author gopal
 *
 */
public class ServiceDeails implements ValidationBean {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2001479078911874089L;

	private String serviceName;
	
	private String serviceCategory;
	
	private String serviceUri;

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getServiceCategory() {
		return serviceCategory;
	}

	public void setServiceCategory(String serviceCategory) {
		this.serviceCategory = serviceCategory;
	}

	public String getServiceUri() {
		return serviceUri;
	}

	public void setServiceUri(String serviceUri) {
		this.serviceUri = serviceUri;
	}
	
	
}
