/**
 * 
 */
package com.ng.transaction.util;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.ng.sb.common.dataobject.BridgeDataObject.ServiceCall;
import com.ng.sb.common.dataobject.BridgeDataObject.ServiceType;
import com.ng.sb.common.dataobject.ReflectionData;
import com.ng.sb.common.dataobject.ServiceQualifier;
import com.ng.sb.common.util.SpringContextUtil;
import com.ng.sb.common.util.SystemConstant;

/**
 * @author gaurav
 *
 */
public class ServiceIdentifierMetaData {

	private Map<ServiceType,ServiceQualifier> transactionMap = new HashMap<>();
	private Map<ServiceType,ServiceQualifier> bridgeMap = new HashMap<>();
	private Map<String,ReflectionData> transactionServiceMap = new HashMap<>();
	private Map<String,ReflectionData> bridgeServiceMap = new HashMap<>();
	private static ServiceIdentifierMetaData instance = new ServiceIdentifierMetaData();
	private ServiceIdentifierMetaData(){
		fillMaps();
		addMethodsForAllServices();
	}
	public static ServiceIdentifierMetaData getInstance(){
		try {
			if(instance == null) {
				instance = new ServiceIdentifierMetaData();
			}
			return instance;
		}catch(Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}
	
	public ServiceQualifier getServiceQualifier(ServiceType serviceType){
		if(serviceType!=null){
			return transactionMap.get(serviceType);
		}
		return null;
	}
	
	private void fillMaps(){
		fillTransactionMap();
		fillBridgeMap();
	}
	
	private void fillTransactionMap(){
		
		// For Transaction Call
		
		transactionMap.put(ServiceType.BANKING_FT_B_TO_B, new ServiceQualifier(SystemConstant.BANKING_SERVICE, SystemConstant.FT_B_T_B_METHOD));
		transactionMap.put(ServiceType.BANKING_FT_B_TO_CC, new ServiceQualifier(SystemConstant.BANKING_SERVICE, SystemConstant.FT_B_T_CC_METHOD));
		transactionMap.put(ServiceType.BANKING_FT_B_TO_IMPS, new ServiceQualifier(SystemConstant.BANKING_SERVICE, SystemConstant.FT_B_T_IMPS_METHOD));
		transactionMap.put(ServiceType.BANKING_FT_B_TO_WALLET, new ServiceQualifier(SystemConstant.BANKING_SERVICE, SystemConstant.FT_B_T_W_METHOD));
		
	
		transactionMap.put(ServiceType.MONEY_TRANSFER, new ServiceQualifier(SystemConstant.BANKING_SERVICE, SystemConstant.MONEY_TRANSFER_METHOD));

		// For UPI calls
		transactionMap.put(ServiceType.BANKING_FT_UPI_TO_UPI, new ServiceQualifier(SystemConstant.BANKING_SERVICE, SystemConstant.FT_UPI_T_UPI_METHOD));

		// Ends here
		
		// Starts 14-03-2017 Gaurav Bhandari
		
		// Other-Payments Agent Bank to Any Instrument 
		transactionMap.put(ServiceType.OTH_PAY_RET_B_TO_B,  new ServiceQualifier(SystemConstant.OTHER_PAYMENT_SERVICE, SystemConstant.PAY_AGENT_B_T_B_METHOD));
		transactionMap.put(ServiceType.OTH_PAY_RET_B_TO_WALLET,   new ServiceQualifier(SystemConstant.OTHER_PAYMENT_SERVICE, SystemConstant.PAY_AGENT_B_T_W_METHOD));
		transactionMap.put(ServiceType.OTH_PAY_RET_B_TO_CC,  new ServiceQualifier(SystemConstant.OTHER_PAYMENT_SERVICE, SystemConstant.PAY_AGENT_B_T_C_METHOD));
		transactionMap.put(ServiceType.OTH_PAY_RET_B_TO_IMPS,   new ServiceQualifier(SystemConstant.OTHER_PAYMENT_SERVICE, SystemConstant.PAY_AGENT_B_T_I_METHOD));
		
		// Other-Payments Agent Wallet to Any Instrument 
		transactionMap.put(ServiceType.OTH_PAY_RET_WALLET_TO_B,  new ServiceQualifier(SystemConstant.OTHER_PAYMENT_SERVICE, SystemConstant.PAY_AGENT_W_T_B_METHOD));
		transactionMap.put(ServiceType.OTH_PAY_RET_WALLET_TO_WALLET,  new ServiceQualifier(SystemConstant.OTHER_PAYMENT_SERVICE, SystemConstant.PAY_AGENT_W_T_W_METHOD));
		//transactionMap.put(ServiceType.OTH_PAY_RET_WALLET_TO_CC,  new ServiceQualifier(SystemConstant.OTHER_PAYMENT_SERVICE, SystemConstant.FT_W_T_CC_METHOD));
		//transactionMap.put(ServiceType.OTH_PAY_RET_WALLET_TO_IMPS,  new ServiceQualifier(SystemConstant.OTHER_PAYMENT_SERVICE, SystemConstant.FT_W_T_IMPS_METHOD));
		
		// Other-Payments Agent IMPS to Any Instrument 
		transactionMap.put(ServiceType.OTH_PAY_RET_IMPS_TO_B,  new ServiceQualifier(SystemConstant.OTHER_PAYMENT_SERVICE, SystemConstant.PAY_AGENT_I_T_B_METHOD));
		transactionMap.put(ServiceType.OTH_PAY_RET_IMPS_TO_WALLET,  new ServiceQualifier(SystemConstant.OTHER_PAYMENT_SERVICE, SystemConstant.PAY_AGENT_I_T_W_METHOD));
		transactionMap.put(ServiceType.OTH_PAY_RET_IMPS_TO_CC,  new ServiceQualifier(SystemConstant.OTHER_PAYMENT_SERVICE, SystemConstant.PAY_AGENT_I_T_C_METHOD));
		transactionMap.put(ServiceType.OTH_PAY_RET_IMPS_TO_IMPS,  new ServiceQualifier(SystemConstant.OTHER_PAYMENT_SERVICE, SystemConstant.PAY_AGENT_I_T_I_METHOD));
		
		
		// Other-Payments Agent CC to Any Instrument 
		transactionMap.put(ServiceType.OTH_PAY_RET_CC_TO_B,  new ServiceQualifier(SystemConstant.OTHER_PAYMENT_SERVICE, SystemConstant.PAY_AGENT_C_T_B_METHOD));
		transactionMap.put(ServiceType.OTH_PAY_RET_CC_TO_WALLET,  new ServiceQualifier(SystemConstant.OTHER_PAYMENT_SERVICE, SystemConstant.PAY_AGENT_C_T_W_METHOD));
		transactionMap.put(ServiceType.OTH_PAY_RET_CC_TO_CC,  new ServiceQualifier(SystemConstant.OTHER_PAYMENT_SERVICE, SystemConstant.PAY_AGENT_C_T_C_METHOD));
		transactionMap.put(ServiceType.OTH_PAY_RET_CC_TO_IMPS,  new ServiceQualifier(SystemConstant.OTHER_PAYMENT_SERVICE, SystemConstant.PAY_AGENT_C_T_I_METHOD));
		
		
		
		// Other-Payments Individual Bank to Any Instrument 
		transactionMap.put(ServiceType.OTH_PAY_INDI_B_TO_B,  new ServiceQualifier(SystemConstant.OTHER_PAYMENT_SERVICE, SystemConstant.PAY_INDIVIDUAL_B_T_B_METHOD));
		transactionMap.put(ServiceType.OTH_PAY_INDI_B_TO_WALLET,  new ServiceQualifier(SystemConstant.OTHER_PAYMENT_SERVICE, SystemConstant.PAY_INDIVIDUAL_B_T_W_METHOD));
		transactionMap.put(ServiceType.OTH_PAY_INDI_B_TO_CC,  new ServiceQualifier(SystemConstant.OTHER_PAYMENT_SERVICE, SystemConstant.PAY_INDIVIDUAL_B_T_C_METHOD));
		transactionMap.put(ServiceType.OTH_PAY_INDI_B_TO_IMPS,  new ServiceQualifier(SystemConstant.OTHER_PAYMENT_SERVICE, SystemConstant.PAY_INDIVIDUAL_B_T_I_METHOD));
		
		
		// Other-Payments Individual Wallet to Any Instrument 
		transactionMap.put(ServiceType.OTH_PAY_INDI_WALLET_TO_B,  new ServiceQualifier(SystemConstant.OTHER_PAYMENT_SERVICE, SystemConstant.PAY_INDIVIDUAL_W_T_B_METHOD));
		transactionMap.put(ServiceType.OTH_PAY_INDI_WALLET_TO_WALLET,  new ServiceQualifier(SystemConstant.OTHER_PAYMENT_SERVICE, SystemConstant.PAY_INDIVIDUAL_W_T_W_METHOD));
		//transactionMap.put(ServiceType.OTH_PAY_INDI_WALLET_TO_CC,  new ServiceQualifier(SystemConstant.OTHER_PAYMENT_SERVICE, SystemConstant.FT_B_T_B_METHOD));
		//transactionMap.put(ServiceType.OTH_PAY_INDI_WALLET_TO_IMPS,  new ServiceQualifier(SystemConstant.OTHER_PAYMENT_SERVICE, SystemConstant.FT_B_T_B_METHOD));
		
		
		// Other-Payments Individual IMPS to Any Instrument 
		transactionMap.put(ServiceType.OTH_PAY_INDI_IMPS_TO_B,  new ServiceQualifier(SystemConstant.OTHER_PAYMENT_SERVICE, SystemConstant.PAY_INDIVIDUAL_I_T_B_METHOD));
		transactionMap.put(ServiceType.OTH_PAY_INDI_IMPS_TO_WALLET,  new ServiceQualifier(SystemConstant.OTHER_PAYMENT_SERVICE, SystemConstant.PAY_INDIVIDUAL_I_T_W_METHOD));
		transactionMap.put(ServiceType.OTH_PAY_INDI_IMPS_TO_CC,  new ServiceQualifier(SystemConstant.OTHER_PAYMENT_SERVICE, SystemConstant.PAY_INDIVIDUAL_I_T_C_METHOD));
		transactionMap.put(ServiceType.OTH_PAY_INDI_IMPS_TO_IMPS,  new ServiceQualifier(SystemConstant.OTHER_PAYMENT_SERVICE, SystemConstant.PAY_INDIVIDUAL_I_T_I_METHOD));
		
		
		// Other-Payments Individual CC to Any Instrument 
		transactionMap.put(ServiceType.OTH_PAY_INDI_CC_TO_B,  new ServiceQualifier(SystemConstant.OTHER_PAYMENT_SERVICE, SystemConstant.PAY_INDIVIDUAL_C_T_B_METHOD));
		transactionMap.put(ServiceType.OTH_PAY_INDI_CC_TO_WALLET,  new ServiceQualifier(SystemConstant.OTHER_PAYMENT_SERVICE, SystemConstant.PAY_INDIVIDUAL_C_T_W_METHOD));
		transactionMap.put(ServiceType.OTH_PAY_INDI_CC_TO_CC,  new ServiceQualifier(SystemConstant.OTHER_PAYMENT_SERVICE, SystemConstant.PAY_INDIVIDUAL_C_T_C_METHOD));
		transactionMap.put(ServiceType.OTH_PAY_INDI_CC_TO_IMPS,  new ServiceQualifier(SystemConstant.OTHER_PAYMENT_SERVICE, SystemConstant.PAY_INDIVIDUAL_C_T_I_METHOD));
		// M-Wallet Agent Check Balance 
		transactionMap.put(ServiceType.MWALLET_AG_CHK_BAL,  new ServiceQualifier(SystemConstant.MWALLET_SERVICE, SystemConstant.AGENT_WALLET_CHECK_BALANCE_METHOD));
		
		transactionMap.put(ServiceType.MWALLET_CUST_CHK_BAL,  new ServiceQualifier(SystemConstant.MWALLET_SERVICE, SystemConstant.CUST_WALLET_CHECK_BALANCE_METHOD));
		
		transactionMap.put(ServiceType.MWALLET_CUST_CASH_OUT_WALLET,  new ServiceQualifier(SystemConstant.MWALLET_SERVICE, SystemConstant.CUST_WALLET_CASH_OUT_TO_WALLET_METHOD));
		
		// M-Wallet Agent Top-Up Online Bank to Wallet
		transactionMap.put(ServiceType.MWALLET_AG_TOP_UP_ONLINE_B_T_W,  new ServiceQualifier(SystemConstant.MWALLET_SERVICE, SystemConstant.AGENT_TOP_UP_ONLINE_B_T_W_METHOD));
				
		// M-Wallet Agent Top-Up Online Wallet to Wallet
		transactionMap.put(ServiceType.MWALLET_AG_TOP_UP_ONLINE_W_T_W,  new ServiceQualifier(SystemConstant.MWALLET_SERVICE, SystemConstant.AGENT_TOP_UP_ONLINE_W_T_W_METHOD));

		// M-Wallet Agent Top-Up Online IMPS to Wallet
		transactionMap.put(ServiceType.MWALLET_AG_TOP_UP_ONLINE_I_T_W,  new ServiceQualifier(SystemConstant.MWALLET_SERVICE, SystemConstant.AGENT_TOP_UP_ONLINE_I_T_W_METHOD));

		// M-Wallet Agent Top-Up Online CC to Wallet
		transactionMap.put(ServiceType.MWALLET_AG_TOP_UP_ONLINE_CC_T_W,  new ServiceQualifier(SystemConstant.MWALLET_SERVICE, SystemConstant.AGENT_TOP_UP_ONLINE_C_T_W_METHOD));
		
		// M-Wallet Agent Top-Up Account Bank to Any Instrument
		transactionMap.put(ServiceType.MWALLET_AG_TOP_UP_ACCOUNT_B_T_B,  new ServiceQualifier(SystemConstant.MWALLET_SERVICE, SystemConstant.AGENT_TOP_UP_ACCOUNT_B_T_B_METHOD));		
		transactionMap.put(ServiceType.MWALLET_AG_TOP_UP_ACCOUNT_B_T_W,  new ServiceQualifier(SystemConstant.MWALLET_SERVICE, SystemConstant.AGENT_TOP_UP_ACCOUNT_B_T_W_METHOD));
		transactionMap.put(ServiceType.MWALLET_AG_TOP_UP_ACCOUNT_B_T_CC,  new ServiceQualifier(SystemConstant.MWALLET_SERVICE, SystemConstant.AGENT_TOP_UP_ACCOUNT_B_T_C_METHOD));
		transactionMap.put(ServiceType.MWALLET_AG_TOP_UP_ACCOUNT_B_T_I,  new ServiceQualifier(SystemConstant.MWALLET_SERVICE, SystemConstant.AGENT_TOP_UP_ACCOUNT_B_T_I_METHOD));
		

		
		// M-Wallet Agent Top-Up Account IMPS to Any Instrument
		transactionMap.put(ServiceType.MWALLET_AG_TOP_UP_ACCOUNT_I_T_B,  new ServiceQualifier(SystemConstant.MWALLET_SERVICE, SystemConstant.AGENT_TOP_UP_ACCOUNT_I_T_B_METHOD));		
		transactionMap.put(ServiceType.MWALLET_AG_TOP_UP_ACCOUNT_I_T_W,  new ServiceQualifier(SystemConstant.MWALLET_SERVICE, SystemConstant.AGENT_TOP_UP_ACCOUNT_I_T_W_METHOD));
		transactionMap.put(ServiceType.MWALLET_AG_TOP_UP_ACCOUNT_I_T_CC,  new ServiceQualifier(SystemConstant.MWALLET_SERVICE, SystemConstant.AGENT_TOP_UP_ACCOUNT_I_T_C_METHOD));
		transactionMap.put(ServiceType.MWALLET_AG_TOP_UP_ACCOUNT_I_T_I,  new ServiceQualifier(SystemConstant.MWALLET_SERVICE, SystemConstant.AGENT_TOP_UP_ACCOUNT_I_T_I_METHOD));
	
		
		// M-Wallet Agent Top-Up Account CC to Any Instrument
		transactionMap.put(ServiceType.MWALLET_AG_TOP_UP_ACCOUNT_CC_T_B,  new ServiceQualifier(SystemConstant.MWALLET_SERVICE, SystemConstant.AGENT_TOP_UP_ACCOUNT_C_T_B_METHOD));		
		transactionMap.put(ServiceType.MWALLET_AG_TOP_UP_ACCOUNT_CC_T_W,  new ServiceQualifier(SystemConstant.MWALLET_SERVICE, SystemConstant.AGENT_TOP_UP_ACCOUNT_C_T_W_METHOD));
		transactionMap.put(ServiceType.MWALLET_AG_TOP_UP_ACCOUNT_CC_T_CC,  new ServiceQualifier(SystemConstant.MWALLET_SERVICE, SystemConstant.AGENT_TOP_UP_ACCOUNT_C_T_C_METHOD));
		transactionMap.put(ServiceType.MWALLET_AG_TOP_UP_ACCOUNT_CC_T_I,  new ServiceQualifier(SystemConstant.MWALLET_SERVICE, SystemConstant.AGENT_TOP_UP_ACCOUNT_C_T_I_METHOD));
			
		
		
		
		// M-Wallet Customer Top-Up Online Bank to Wallet
		transactionMap.put(ServiceType.MWALLET_CUST_TOP_UP_ONLINE_B_T_W,  new ServiceQualifier(SystemConstant.MWALLET_SERVICE, SystemConstant.CUST_TOP_UP_ONLINE_B_T_W_METHOD));
				
		// M-Wallet Customer Top-Up Online IMPS to Wallet
		transactionMap.put(ServiceType.MWALLET_CUST_TOP_UP_ONLINE_I_T_W,  new ServiceQualifier(SystemConstant.MWALLET_SERVICE, SystemConstant.FT_B_T_B_METHOD));

		// M-Wallet Customer Top-Up Online CC to Wallet
		transactionMap.put(ServiceType.MWALLET_CUST_TOP_UP_ONLINE_CC_T_W,  new ServiceQualifier(SystemConstant.MWALLET_SERVICE, SystemConstant.FT_B_T_B_METHOD));
		
		// M-Wallet Customer Top-Up Online Via SMS to Wallet
		transactionMap.put(ServiceType.MWALLET_CUST_TOP_UP_ONLINE_VIA_SMS_T_W,  new ServiceQualifier(SystemConstant.MWALLET_SERVICE, SystemConstant.FT_B_T_B_METHOD));
		
		
		
		
		// End 14-03-2017 Gaurav Bhandari
		
		
		//FOR MOM
		
		
		transactionMap.put(ServiceType.BANKING_CASH_WD_FROM_B, new ServiceQualifier(SystemConstant.BANKING_SERVICE, SystemConstant.CASH_WITHDRAW_METHOD));
		transactionMap.put(ServiceType.BANKING_CASH_WD_FROM_CC, new ServiceQualifier(SystemConstant.BANKING_SERVICE, SystemConstant.CASH_WITHDRAW_METHOD));
		transactionMap.put(ServiceType.BANKING_CHECK_BAL, new ServiceQualifier(SystemConstant.NON_BANKING_SERVICE, SystemConstant.CHECK_BALANCE_METHOD));
		transactionMap.put(ServiceType.BANKING_CHQ_BOOK_REQUEST, new ServiceQualifier(SystemConstant.NON_BANKING_SERVICE, SystemConstant.CHEQUE_BOOK_REQUEST_METHOD));
		transactionMap.put(ServiceType.BANKING_CHQ_STATUS, new ServiceQualifier(SystemConstant.NON_BANKING_SERVICE, SystemConstant.CHEQUE_STATUS_METHOD));
		transactionMap.put(ServiceType.BANKING_STOP_CHEQUE, new ServiceQualifier(SystemConstant.NON_BANKING_SERVICE, SystemConstant.CHEQUE_STOP_METHOD));
		transactionMap.put(ServiceType.BANKING_LAST_5_TRANS, new ServiceQualifier(SystemConstant.NON_BANKING_SERVICE, SystemConstant.BANKING_LAST_5_TRANS_METHOD));
		transactionMap.put(ServiceType.BANKING_IMPS_IMPS_TO_B, new ServiceQualifier(SystemConstant.BANKING_SERVICE, SystemConstant.FT_IMPS_T_B_METHOD));
		transactionMap.put(ServiceType.BANKING_IMPS_IMPS_TO_CC, new ServiceQualifier(SystemConstant.BANKING_SERVICE, SystemConstant.FT_IMPS_T_CC_METHOD));
		transactionMap.put(ServiceType.BANKING_IMPS_IMPS_TO_IMPS, new ServiceQualifier(SystemConstant.BANKING_SERVICE, SystemConstant.FT_IMPS_T_IMPS_METHOD));
		transactionMap.put(ServiceType.BANKING_IMPS_IMPS_TO_WALLET, new ServiceQualifier(SystemConstant.BANKING_SERVICE, SystemConstant.FUND_TRANSFER_METHOD));
		
		
		
		
		
		// TOP UP
		transactionMap.put(ServiceType.TOP_UP_RECH_BY_B, new ServiceQualifier(SystemConstant.BILLER_MGT_SERVICE, SystemConstant.TOPUP_RECHARGE_BY_BANK_METHOD));
		transactionMap.put(ServiceType.TOP_UP_RECH_BY_CC, new ServiceQualifier(SystemConstant.BILLER_MGT_SERVICE, SystemConstant.TOPUP_RECHARGE_BY_CREDITCARD_METHOD));
		transactionMap.put(ServiceType.TOP_UP_RECH_BY_IMPS, new ServiceQualifier(SystemConstant.BILLER_MGT_SERVICE, SystemConstant.TOPUP_RECHARGE_BY_IMPS_METHOD));
		transactionMap.put(ServiceType.TOP_UP_RECH_BY_WALLET, new ServiceQualifier(SystemConstant.BILLER_MGT_SERVICE, SystemConstant.TOPUP_RECHARGE_BY_WALLET_METHOD));
		
		transactionMap.put(ServiceType.BILL_PAY_BY_B, new ServiceQualifier(SystemConstant.BILLER_MGT_SERVICE, SystemConstant.FT_BILLER_BANK_METHOD));
		transactionMap.put(ServiceType.BILL_PAY_BY_CC, new ServiceQualifier(SystemConstant.BILLER_MGT_SERVICE, SystemConstant.FT_BILLER_CC_METHOD));
		transactionMap.put(ServiceType.BILL_PAY_BY_IMPS, new ServiceQualifier(SystemConstant.BILLER_MGT_SERVICE, SystemConstant.FT_BILLER_IMPS_METHOD));
		transactionMap.put(ServiceType.BILL_PAY_BY_WALLET, new ServiceQualifier(SystemConstant.BILLER_MGT_SERVICE, SystemConstant.FT_BILLER_WALLET_METHOD));
		
		transactionMap.put(ServiceType.SETTINGS_BANK_ACC_ADD, new ServiceQualifier(SystemConstant.SETTING_SERVICE, SystemConstant.SAVE_BANK_ACCOUNT_METHOD));
		transactionMap.put(ServiceType.SETTINGS_BANK_ACC_EDIT, new ServiceQualifier(SystemConstant.SETTING_SERVICE, SystemConstant.EDIT_BANK_ACCOUNT_METHOD));
		transactionMap.put(ServiceType.SETTINGS_BANK_ACC_DELETE, new ServiceQualifier(SystemConstant.SETTING_SERVICE, SystemConstant.DELETE_BANK_ACCOUNT_METHOD));
		transactionMap.put(ServiceType.SETTINGS_CC_ADD, new ServiceQualifier(SystemConstant.SETTING_SERVICE, SystemConstant.SAVE_CC_ACCOUNT_METHOD));
		transactionMap.put(ServiceType.SETTINGS_CC_EDIT, new ServiceQualifier(SystemConstant.SETTING_SERVICE, SystemConstant.EDIT_CC_ACCOUNT_METHOD));
		transactionMap.put(ServiceType.SETTINGS_CC_DELETE, new ServiceQualifier(SystemConstant.SETTING_SERVICE, SystemConstant.DELETE_CC_ACCOUNT_METHOD));
		transactionMap.put(ServiceType.SETTINGS_MY_BILLER_ADD, new ServiceQualifier(SystemConstant.SETTING_SERVICE, SystemConstant.SAVE_BILLER_ACCOUNT_METHOD));
		transactionMap.put(ServiceType.SETTINGS_MY_BILLER_EDIT, new ServiceQualifier(SystemConstant.SETTING_SERVICE, SystemConstant.EDIT_BILLER_ACCOUNT_METHOD));
		transactionMap.put(ServiceType.SETTINGS_MY_BILLER_DELETE, new ServiceQualifier(SystemConstant.SETTING_SERVICE, SystemConstant.DELETE_BILLER_ACCOUNT_METHOD));
		transactionMap.put(ServiceType.SETTINGS_MY_MERCHANT_ADD, new ServiceQualifier(SystemConstant.SETTING_SERVICE, SystemConstant.SAVE_MERCHANT_ACCOUNT_METHOD));
		transactionMap.put(ServiceType.SETTINGS_MY_MERCHANT_EDIT, new ServiceQualifier(SystemConstant.SETTING_SERVICE, SystemConstant.EDIT_MERCHANT_ACCOUNT_METHOD));
		transactionMap.put(ServiceType.SETTINGS_MY_MERCHANT_DELETE, new ServiceQualifier(SystemConstant.SETTING_SERVICE, SystemConstant.DELETE_MERCHANT_ACCOUNT_METHOD));
		transactionMap.put(ServiceType.SETTINGS_MY_PAYEE_ADD, new ServiceQualifier(SystemConstant.SETTING_SERVICE, SystemConstant.SAVE_INDIVIDUAL_ACCOUNT_METHOD));
		transactionMap.put(ServiceType.SETTINGS_MY_PAYEE_EDIT, new ServiceQualifier(SystemConstant.SETTING_SERVICE, SystemConstant.EDIT_INDIVIDUAL_ACCOUNT_METHOD));
		transactionMap.put(ServiceType.SETTINGS_MY_PAYEE_DELETE, new ServiceQualifier(SystemConstant.SETTING_SERVICE, SystemConstant.DELETE_INDIVIDUAL_ACCOUNT_METHOD));
		transactionMap.put(ServiceType.SETTINGS_FOREX_BENEFICIARY_ADD, new ServiceQualifier(SystemConstant.SETTING_SERVICE, SystemConstant.SAVE_FOREX_BENEFICIARY_METHOD));
		transactionMap.put(ServiceType.SETTINGS_FOREX_BENEFICIARY_EDIT, new ServiceQualifier(SystemConstant.SETTING_SERVICE, SystemConstant.EDIT_FOREX_BENEFICIARY_METHOD));
		transactionMap.put(ServiceType.SETTINGS_FOREX_BENEFICIARY_DELETE, new ServiceQualifier(SystemConstant.SETTING_SERVICE, SystemConstant.DELETE_FOREX_BENEFICIARY_METHOD));
		transactionMap.put(ServiceType.SETTINGS_LAST_5_TRANS, new ServiceQualifier(SystemConstant.SETTING_SERVICE, SystemConstant.SETTING_LAST_5_TRANSACTION_METHOD));
		transactionMap.put(ServiceType.SETTINGS_CHANGE_PIN_LOGIN, new ServiceQualifier(SystemConstant.SETTING_SERVICE, SystemConstant.SETTING_CHANGE_PIN_METHOD));
		transactionMap.put(ServiceType.SETTINGS_CHANGE_PIN_TRANSACTION, new ServiceQualifier(SystemConstant.SETTING_SERVICE, SystemConstant.SETTING_CHANGE_PIN_METHOD));
		
		transactionMap.put(ServiceType.SETTINGS_CREATE_PIN_TRANSACTION, new ServiceQualifier(SystemConstant.SETTING_SERVICE, SystemConstant.SETTING_CREATE_PIN_METHOD));
		transactionMap.put(ServiceType.SETTINGS_CHANGE_PIN_TRANSACTION, new ServiceQualifier(SystemConstant.SETTING_SERVICE, SystemConstant.SETTING_CHANGE_PIN_METHOD));
		
		transactionMap.put(ServiceType.SETTINGS_CREATE_PIN_WALLET, new ServiceQualifier(SystemConstant.SETTING_SERVICE, SystemConstant.SETTING_CREATE_WALLET_PIN_METHOD));
		transactionMap.put(ServiceType.SETTINGS_CHANGE_PIN_WALLET, new ServiceQualifier(SystemConstant.SETTING_SERVICE, SystemConstant.SETTING_CHANGE_WALLET_PIN_METHOD));
		
		
		
		transactionMap.put(ServiceType.SETTINGS_RECOVER_SETTING, new ServiceQualifier(SystemConstant.SETTING_SERVICE, SystemConstant.RECOVER_MY_SETTINGS_METHOD));
		transactionMap.put(ServiceType.SETTINGS_OTP_CONF, new ServiceQualifier(SystemConstant.SETTING_SERVICE, SystemConstant.CONFIGURE_OTP_METHOD));
		
		// OTHER SERVICE
		transactionMap.put(ServiceType.SETTINGS_OTP_CONF, new ServiceQualifier(SystemConstant.SETTING_SERVICE, SystemConstant.CONFIGURE_OTP_METHOD));
	}
	
	private void fillBridgeMap(){
		
		// For Bridge Call
		
		// Source is Bank
		bridgeMap.put(ServiceType.BANKING_FT_B_TO_B, new ServiceQualifier(SystemConstant.BRIDGE_BANKING_SERVICE, SystemConstant.FT_B_T_B_METHOD));
		bridgeMap.put(ServiceType.BANKING_FT_B_TO_CC, new ServiceQualifier(SystemConstant.BRIDGE_BANKING_SERVICE, SystemConstant.FT_B_T_CC_METHOD));
		bridgeMap.put(ServiceType.BANKING_FT_B_TO_IMPS, new ServiceQualifier(SystemConstant.BRIDGE_BANKING_SERVICE, SystemConstant.FT_B_T_IMPS_METHOD));
		bridgeMap.put(ServiceType.BANKING_FT_B_TO_WALLET, new ServiceQualifier(SystemConstant.BRIDGE_BANKING_SERVICE, SystemConstant.FT_B_T_W_METHOD));
		
		//New
		bridgeMap.put(ServiceType.OTH_PAY_RET_B_TO_B,  new ServiceQualifier(SystemConstant.BRIDGE_BANKING_SERVICE, SystemConstant.FT_B_T_B_METHOD));
		bridgeMap.put(ServiceType.OTH_PAY_RET_B_TO_WALLET,   new ServiceQualifier(SystemConstant.BRIDGE_BANKING_SERVICE, SystemConstant.FT_B_T_W_METHOD));
		bridgeMap.put(ServiceType.OTH_PAY_RET_WALLET_TO_WALLET,   new ServiceQualifier(SystemConstant.BRIDGE_BANKING_SERVICE, SystemConstant.FT_W_T_W_METHOD));
		bridgeMap.put(ServiceType.OTH_PAY_RET_WALLET_TO_B,   new ServiceQualifier(SystemConstant.BRIDGE_OTHER_PAYMENT_SERVICE, SystemConstant.FT_W_T_B_METHOD));
		bridgeMap.put(ServiceType.OTH_PAY_INDI_B_TO_B,   new ServiceQualifier(SystemConstant.BRIDGE_BANKING_SERVICE, SystemConstant.FT_B_T_B_METHOD));
		bridgeMap.put(ServiceType.OTH_PAY_INDI_B_TO_WALLET,   new ServiceQualifier(SystemConstant.BRIDGE_OTHER_PAYMENT_SERVICE, SystemConstant.FT_B_T_W_METHOD));
		bridgeMap.put(ServiceType.OTH_PAY_INDI_WALLET_TO_WALLET,   new ServiceQualifier(SystemConstant.BRIDGE_OTHER_PAYMENT_SERVICE, SystemConstant.FT_W_T_W_METHOD));
		bridgeMap.put(ServiceType.OTH_PAY_INDI_WALLET_TO_B,   new ServiceQualifier(SystemConstant.BRIDGE_OTHER_PAYMENT_SERVICE, SystemConstant.FT_W_T_B_METHOD));
		// FOR OXIGEN
		bridgeMap.put(ServiceType.MONEY_TRANSFER, new ServiceQualifier(SystemConstant.BRIDGE_BANKING_SERVICE, SystemConstant.MONEY_TRANSFER_METHOD));
				
		
		//FOR W-W
		bridgeMap.put(ServiceType.MWALLET_AG_TOP_UP_ONLINE_W_T_W, new ServiceQualifier(SystemConstant.BRIDGE_BANKING_SERVICE, SystemConstant.FT_W_T_W_METHOD));
		
		bridgeMap.put(ServiceType.BANKING_CASH_WD_FROM_B, new ServiceQualifier(SystemConstant.BRIDGE_BANKING_SERVICE, SystemConstant.CASH_WITHDRAW_METHOD));
		bridgeMap.put(ServiceType.BANKING_CASH_WD_FROM_CC, new ServiceQualifier(SystemConstant.BRIDGE_BANKING_SERVICE, SystemConstant.CASH_WITHDRAW_METHOD));
		bridgeMap.put(ServiceType.BANKING_CHECK_BAL, new ServiceQualifier(SystemConstant.BRIDGE_NON_BANKING_SERVICE, SystemConstant.CHECK_BALANCE_METHOD));
		bridgeMap.put(ServiceType.BANKING_CHQ_BOOK_REQUEST, new ServiceQualifier(SystemConstant.BRIDGE_NON_BANKING_SERVICE, SystemConstant.CHEQUE_BOOK_REQUEST_METHOD));
		bridgeMap.put(ServiceType.BANKING_CHQ_STATUS, new ServiceQualifier(SystemConstant.BRIDGE_NON_BANKING_SERVICE, SystemConstant.CHEQUE_STATUS_METHOD));
		bridgeMap.put(ServiceType.BANKING_STOP_CHEQUE, new ServiceQualifier(SystemConstant.BRIDGE_NON_BANKING_SERVICE, SystemConstant.CHEQUE_STOP_METHOD));
		bridgeMap.put(ServiceType.BANKING_LAST_5_TRANS, new ServiceQualifier(SystemConstant.BRIDGE_NON_BANKING_SERVICE, SystemConstant.BANKING_LAST_5_TRANS_METHOD));
		bridgeMap.put(ServiceType.BANKING_IMPS_IMPS_TO_B, new ServiceQualifier(SystemConstant.BRIDGE_BANKING_SERVICE, SystemConstant.FT_IMPS_T_B_METHOD));
		bridgeMap.put(ServiceType.BANKING_IMPS_IMPS_TO_CC, new ServiceQualifier(SystemConstant.BRIDGE_BANKING_SERVICE, SystemConstant.FT_IMPS_T_CC_METHOD));
		bridgeMap.put(ServiceType.BANKING_IMPS_IMPS_TO_IMPS, new ServiceQualifier(SystemConstant.BRIDGE_BANKING_SERVICE, SystemConstant.FT_IMPS_T_IMPS_METHOD));
		bridgeMap.put(ServiceType.BANKING_IMPS_IMPS_TO_WALLET, new ServiceQualifier(SystemConstant.BRIDGE_BANKING_SERVICE, SystemConstant.FUND_TRANSFER_METHOD));
		//bridgeMap.put(ServiceType.MWALLET_CHECK_BALANCE, new ServiceQualifier(SystemConstant.BRIDGE_AGENT_WALLET_SERVICE, SystemConstant.MWALLET_CHK_BAL_METHOD));
		
		bridgeMap.put(ServiceType.MWALLET_AG_CHK_BAL, new ServiceQualifier(SystemConstant.BRIDGE_AGENT_SERVICE, SystemConstant.MWALLET_CHK_BAL_METHOD));
		bridgeMap.put(ServiceType.MWALLET_CUST_CHK_BAL, new ServiceQualifier(SystemConstant.BRIDGE_CUST_SERVICE, SystemConstant.MWALLET_CHK_BAL_METHOD));
		bridgeMap.put(ServiceType.MWALLET_CUST_CASH_OUT_WALLET, new ServiceQualifier(SystemConstant.BRIDGE_CUST_SERVICE, SystemConstant.CUST_CASH_OUT_METHOD));
		
		bridgeMap.put(ServiceType.MWALLET_CUST_TOP_UP_ONLINE_B_T_W, new ServiceQualifier(SystemConstant.BRIDGE_CUST_SERVICE, SystemConstant.FT_B_T_W_METHOD));
		
		// TOP UP
		bridgeMap.put(ServiceType.TOP_UP_RECH_BY_B, new ServiceQualifier(SystemConstant.BRIDGE_BILLER_MGT_SERVICE, SystemConstant.TOPUP_RECHARGE_BY_BANK_METHOD));
		bridgeMap.put(ServiceType.TOP_UP_RECH_BY_CC, new ServiceQualifier(SystemConstant.BRIDGE_BILLER_MGT_SERVICE, SystemConstant.TOPUP_RECHARGE_BY_CREDITCARD_METHOD));
		bridgeMap.put(ServiceType.TOP_UP_RECH_BY_IMPS, new ServiceQualifier(SystemConstant.BRIDGE_BILLER_MGT_SERVICE, SystemConstant.TOPUP_RECHARGE_BY_IMPS_METHOD));
		bridgeMap.put(ServiceType.TOP_UP_RECH_BY_WALLET, new ServiceQualifier(SystemConstant.BRIDGE_BILLER_MGT_SERVICE, SystemConstant.TOPUP_RECHARGE_BY_WALLET_METHOD));
		
		
		// Bill Pay
		bridgeMap.put(ServiceType.BILL_PAY_BY_B, new ServiceQualifier(SystemConstant.BRIDGE_BILLER_MGT_SERVICE, SystemConstant.FT_BILLER_BANK_METHOD));
		bridgeMap.put(ServiceType.BILL_PAY_BY_CC, new ServiceQualifier(SystemConstant.BRIDGE_BILLER_MGT_SERVICE, SystemConstant.FT_BILLER_CC_METHOD));
		bridgeMap.put(ServiceType.BILL_PAY_BY_IMPS, new ServiceQualifier(SystemConstant.BRIDGE_BILLER_MGT_SERVICE, SystemConstant.FT_BILLER_IMPS_METHOD));
		bridgeMap.put(ServiceType.BILL_PAY_BY_WALLET, new ServiceQualifier(SystemConstant.BRIDGE_BILLER_MGT_SERVICE, SystemConstant.FT_BILLER_WALLET_METHOD));
		
		bridgeMap.put(ServiceType.SETTINGS_BANK_ACC_ADD, new ServiceQualifier(SystemConstant.BRIDGE_SETTING_SERVICE, SystemConstant.SAVE_BANK_ACCOUNT_METHOD));
		bridgeMap.put(ServiceType.SETTINGS_BANK_ACC_EDIT, new ServiceQualifier(SystemConstant.BRIDGE_SETTING_SERVICE, SystemConstant.EDIT_BANK_ACCOUNT_METHOD));
		bridgeMap.put(ServiceType.SETTINGS_BANK_ACC_DELETE, new ServiceQualifier(SystemConstant.BRIDGE_SETTING_SERVICE, SystemConstant.DELETE_BANK_ACCOUNT_METHOD));
		bridgeMap.put(ServiceType.SETTINGS_CC_ADD, new ServiceQualifier(SystemConstant.BRIDGE_SETTING_SERVICE, SystemConstant.SAVE_CC_ACCOUNT_METHOD));
		bridgeMap.put(ServiceType.SETTINGS_CC_EDIT, new ServiceQualifier(SystemConstant.BRIDGE_SETTING_SERVICE, SystemConstant.EDIT_CC_ACCOUNT_METHOD));
		bridgeMap.put(ServiceType.SETTINGS_CC_DELETE, new ServiceQualifier(SystemConstant.BRIDGE_SETTING_SERVICE, SystemConstant.DELETE_CC_ACCOUNT_METHOD));
		bridgeMap.put(ServiceType.SETTINGS_MY_BILLER_ADD, new ServiceQualifier(SystemConstant.BRIDGE_SETTING_SERVICE, SystemConstant.SAVE_BILLER_ACCOUNT_METHOD));
		bridgeMap.put(ServiceType.SETTINGS_MY_BILLER_EDIT, new ServiceQualifier(SystemConstant.BRIDGE_SETTING_SERVICE, SystemConstant.EDIT_BILLER_ACCOUNT_METHOD));
		bridgeMap.put(ServiceType.SETTINGS_MY_BILLER_DELETE, new ServiceQualifier(SystemConstant.BRIDGE_SETTING_SERVICE, SystemConstant.DELETE_BILLER_ACCOUNT_METHOD));
		bridgeMap.put(ServiceType.SETTINGS_MY_MERCHANT_ADD, new ServiceQualifier(SystemConstant.BRIDGE_SETTING_SERVICE, SystemConstant.SAVE_MERCHANT_ACCOUNT_METHOD));
		bridgeMap.put(ServiceType.SETTINGS_MY_MERCHANT_EDIT, new ServiceQualifier(SystemConstant.BRIDGE_SETTING_SERVICE, SystemConstant.EDIT_MERCHANT_ACCOUNT_METHOD));
		bridgeMap.put(ServiceType.SETTINGS_MY_MERCHANT_DELETE, new ServiceQualifier(SystemConstant.BRIDGE_SETTING_SERVICE, SystemConstant.DELETE_MERCHANT_ACCOUNT_METHOD));
		bridgeMap.put(ServiceType.SETTINGS_MY_PAYEE_ADD, new ServiceQualifier(SystemConstant.BRIDGE_SETTING_SERVICE, SystemConstant.SAVE_INDIVIDUAL_ACCOUNT_METHOD));
		bridgeMap.put(ServiceType.SETTINGS_MY_PAYEE_EDIT, new ServiceQualifier(SystemConstant.BRIDGE_SETTING_SERVICE, SystemConstant.EDIT_INDIVIDUAL_ACCOUNT_METHOD));
		bridgeMap.put(ServiceType.SETTINGS_MY_PAYEE_DELETE, new ServiceQualifier(SystemConstant.BRIDGE_SETTING_SERVICE, SystemConstant.DELETE_INDIVIDUAL_ACCOUNT_METHOD));
		bridgeMap.put(ServiceType.SETTINGS_FOREX_BENEFICIARY_ADD, new ServiceQualifier(SystemConstant.BRIDGE_SETTING_SERVICE, SystemConstant.SAVE_FOREX_BENEFICIARY_METHOD));
		bridgeMap.put(ServiceType.SETTINGS_FOREX_BENEFICIARY_EDIT, new ServiceQualifier(SystemConstant.BRIDGE_SETTING_SERVICE, SystemConstant.EDIT_FOREX_BENEFICIARY_METHOD));
		bridgeMap.put(ServiceType.SETTINGS_FOREX_BENEFICIARY_DELETE, new ServiceQualifier(SystemConstant.BRIDGE_SETTING_SERVICE, SystemConstant.DELETE_FOREX_BENEFICIARY_METHOD));
		bridgeMap.put(ServiceType.SETTINGS_LAST_5_TRANS, new ServiceQualifier(SystemConstant.BRIDGE_SETTING_SERVICE, SystemConstant.SETTING_LAST_5_TRANSACTION_METHOD));
		bridgeMap.put(ServiceType.SETTINGS_CHANGE_PIN_LOGIN, new ServiceQualifier(SystemConstant.BRIDGE_SETTING_SERVICE, SystemConstant.SETTING_CHANGE_PIN_METHOD));
		bridgeMap.put(ServiceType.SETTINGS_CHANGE_PIN_TRANSACTION, new ServiceQualifier(SystemConstant.BRIDGE_SETTING_SERVICE, SystemConstant.SETTING_CHANGE_PIN_METHOD));
		
		bridgeMap.put(ServiceType.SETTINGS_CREATE_PIN_TRANSACTION, new ServiceQualifier(SystemConstant.BRIDGE_SETTING_SERVICE, SystemConstant.SETTING_CREATE_PIN_METHOD));
		bridgeMap.put(ServiceType.SETTINGS_CHANGE_PIN_TRANSACTION, new ServiceQualifier(SystemConstant.BRIDGE_SETTING_SERVICE, SystemConstant.SETTING_CHANGE_PIN_METHOD));

		bridgeMap.put(ServiceType.SETTINGS_CREATE_PIN_WALLET, new ServiceQualifier(SystemConstant.BRIDGE_SETTING_SERVICE, SystemConstant.SETTING_CREATE_WALLET_PIN_METHOD));
		bridgeMap.put(ServiceType.SETTINGS_CHANGE_PIN_WALLET, new ServiceQualifier(SystemConstant.BRIDGE_SETTING_SERVICE, SystemConstant.SETTING_CHANGE_WALLET_PIN_METHOD));
		
		bridgeMap.put(ServiceType.SETTINGS_RECOVER_SETTING, new ServiceQualifier(SystemConstant.BRIDGE_SETTING_SERVICE, SystemConstant.RECOVER_MY_SETTINGS_METHOD));
		bridgeMap.put(ServiceType.SETTINGS_OTP_CONF, new ServiceQualifier(SystemConstant.BRIDGE_SETTING_SERVICE, SystemConstant.CONFIGURE_OTP_METHOD));
	}
	
	private void addMethodsForAllServices(){
		addMethods(transactionMap,transactionServiceMap);
		addMethods(bridgeMap,bridgeServiceMap);
	}
	
	private void addMethods(Map<ServiceType,ServiceQualifier> map,Map<String,ReflectionData> serviceMap){
		for(Iterator<ServiceType> itr=map.keySet().iterator();itr.hasNext();){
			ServiceQualifier serviceQualifier = map.get(itr.next());
			if(serviceQualifier!=null){
				if(serviceMap.containsKey(serviceQualifier.getClassIdentifier())==false){
					Object classIdentifier = SpringContextUtil.getApplicationContext().getBean(serviceQualifier.getClassIdentifier());
					serviceMap.put(serviceQualifier.getClassIdentifier(), new ReflectionData(serviceQualifier.getClassIdentifier(),classIdentifier,getMethods(classIdentifier)));
				}
			}
		}
	}
	
	
	private Map<String,Method> getMethods(Object classIdentifier){
		if(classIdentifier!=null){
			Method[] methods= classIdentifier.getClass().getDeclaredMethods();
			Map<String,Method> methodMap = new HashMap<>();
			for(Method method : methods){
				if(method!=null){
					methodMap.put(method.getName().toLowerCase(), method);
				}
			}
			return methodMap;
		}
		return null;
	}
	
	private ReflectionData getMethodToInvoke(ServiceCall serviceCall,ServiceType serviceType,Map<ServiceType,ServiceQualifier> map,Map<String,ReflectionData> serviceMap){
		ReflectionData rd = serviceMap.get(map.get(serviceType).getClassIdentifier());
		return new ReflectionData(rd.getClassIdentifier(),rd.getMethodMap().get(map.get(serviceType).getMethodName().toLowerCase()));
	}
	public ReflectionData getMethodToInvoke(ServiceCall serviceCall,ServiceType serviceType){
		if(serviceCall!=null && serviceType!=null){
			if(serviceCall==ServiceCall.TRANSACTION){
				return getMethodToInvoke(serviceCall, serviceType, transactionMap, transactionServiceMap);
			}else if(serviceCall==ServiceCall.BRIDGE){
				return getMethodToInvoke(serviceCall, serviceType, bridgeMap, bridgeServiceMap);
			}
			
		}
		return null;
	}
	
}
