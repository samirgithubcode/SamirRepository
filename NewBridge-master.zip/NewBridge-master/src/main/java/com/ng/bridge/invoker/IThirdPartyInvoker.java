/**
 * 
 */
package com.ng.bridge.invoker;

import com.ng.sb.common.dataobject.BridgeDataObject;

/**
 * @author gaurav
 *
 */
public interface IThirdPartyInvoker {
	
	
	/************************************************* Instrument Deduction Section Starts **************************************************************************************/
	/***
	 * Deduct amount through Bank
	 * @param bridgeDataObject
	 * @return
	 */
	public BridgeDataObject deductAmountThruBankDirect(BridgeDataObject bridgeDataObject);
	/***
	 * Deduct amount through CreditCard
	 * @param bridgeDataObject
	 * @return
	 */
	public BridgeDataObject deductAmountThruCreditCardDirect(BridgeDataObject bridgeDataObject);
	/***
	 * Deduct amount through IMPS
	 * @param bridgeDataObject
	 * @return
	 */
	public BridgeDataObject deductAmountThruIMPSDirect(BridgeDataObject bridgeDataObject);
	/***
	 * Deduct amount through Wallet
	 * @param bridgeDataObject
	 * @return
	 */
	public BridgeDataObject deductAmountThruWalletDirect(BridgeDataObject bridgeDataObject);
	
	/************************************************* Instrument Deduction Section Ends **************************************************************************************/
	
	/************************************************* Instrument Add Section Starts **************************************************************************************/
	/***
	 * Add amount in Bank
	 * @param bridgeDataObject
	 * @return
	 */
	public BridgeDataObject addAmountInBankDirect(BridgeDataObject bridgeDataObject);
	/***
	 * Add amount through CreditCard
	 * @param bridgeDataObject
	 * @return
	 */
	public BridgeDataObject addAmountInCreditCardDirect(BridgeDataObject bridgeDataObject);
	/***
	 * Add amount through IMPS
	 * @param bridgeDataObject
	 * @return
	 */
	public BridgeDataObject addAmountInIMPSDirect(BridgeDataObject bridgeDataObject);
	/***
	 * Add amount through Wallet
	 * @param bridgeDataObject
	 * @return
	 */
	public BridgeDataObject addAmountInWalletDirect(BridgeDataObject bridgeDataObject);
	
	/************************************************* Instrument Add Section Ends **************************************************************************************/
	
	
	/************************************************* FSP Fund Transfer Service Section Starts **************************************************************************************/
	/***
	 * Money Transfer special case
	 * @param bridgeDataObject
	 * @return
	 */
	public BridgeDataObject moneyTransferFSP(BridgeDataObject bridgeDataObject);
	
	/***
	 * Bank To Bank Fund Transfer FSP Service
	 * @param bridgeDataObject
	 * @return
	 */
	public BridgeDataObject bankToBankFundTransferFSP(BridgeDataObject bridgeDataObject);
	
	/***
	 * Bank To Wallet Fund Transfer FSP Service
	 * @param bridgeDataObject
	 * @return
	 */
	public BridgeDataObject bankToWalletFundTransferFSP(BridgeDataObject bridgeDataObject);
	
	/***
	 * Bank To IMPS Fund Transfer FSP Service
	 * @param bridgeDataObject
	 * @return
	 */
	public BridgeDataObject bankToIMPSFundTransferFSP(BridgeDataObject bridgeDataObject);
	
	/***
	 * Bank To Credit Card Fund Transfer FSP Service
	 * @param bridgeDataObject
	 * @return
	 */
	public BridgeDataObject bankToCreditCardFundTransferFSP(BridgeDataObject bridgeDataObject);
	
	/***
	 * Wallet To Bank Fund Transfer FSP Service
	 * @param bridgeDataObject
	 * @return
	 */
	public BridgeDataObject walletToBankFundTransferFSP(BridgeDataObject bridgeDataObject);
	
	/***
	 * Wallet To Wallet Fund Transfer FSP Service
	 * @param bridgeDataObject
	 * @return
	 */
	public BridgeDataObject walletToWalletFundTransferFSP(BridgeDataObject bridgeDataObject);
	
	/***
	 * Wallet To IMPS Fund Transfer FSP Service
	 * @param bridgeDataObject
	 * @return
	 */
	public BridgeDataObject walletToIMPSFundTransferFSP(BridgeDataObject bridgeDataObject);
	
	/***
	 * Wallet To Credit Card Fund Transfer FSP Service
	 * @param bridgeDataObject
	 * @return
	 */
	public BridgeDataObject walletToCreditCardFundTransferFSP(BridgeDataObject bridgeDataObject);
	
	
	/***
	 * IMPS To Bank Fund Transfer FSP Service
	 * @param bridgeDataObject
	 * @return
	 */
	public BridgeDataObject impsToBankFundTransferFSP(BridgeDataObject bridgeDataObject);
	
	/***
	 * IMPS To Wallet Fund Transfer FSP Service
	 * @param bridgeDataObject
	 * @return
	 */
	public BridgeDataObject impsToWalletFundTransferFSP(BridgeDataObject bridgeDataObject);
	
	/***
	 * IMPS To IMPS Fund Transfer FSP Service
	 * @param bridgeDataObject
	 * @return
	 */
	public BridgeDataObject impsToIMPSFundTransferFSP(BridgeDataObject bridgeDataObject);
	
	/***
	 * IMPS To Credit Card Fund Transfer FSP Service
	 * @param bridgeDataObject
	 * @return
	 */
	public BridgeDataObject impsToCreditCardFundTransferFSP(BridgeDataObject bridgeDataObject);
	
	
	/***
	 * Credit Card To Bank Fund Transfer FSP Service
	 * @param bridgeDataObject
	 * @return
	 */
	public BridgeDataObject creditCardToBankFundTransferFSP(BridgeDataObject bridgeDataObject);
	
	/***
	 * Credit Card To Wallet Fund Transfer FSP Service
	 * @param bridgeDataObject
	 * @return
	 */
	public BridgeDataObject creditCardToWalletFundTransferFSP(BridgeDataObject bridgeDataObject);
	
	/***
	 * Credit Card To IMPS Fund Transfer FSP Service
	 * @param bridgeDataObject
	 * @return
	 */
	public BridgeDataObject creditCardToIMPSFundTransferFSP(BridgeDataObject bridgeDataObject);
	
	/***
	 * Credit Card To Credit Card Fund Transfer FSP Service
	 * @param bridgeDataObject
	 * @return
	 */
	public BridgeDataObject creditCardToCreditCardFundTransferFSP(BridgeDataObject bridgeDataObject);
	
	/************************************************* FSP Fund Transfer Service Section Ends **************************************************************************************/
	
	
	/************************************************* FSP Other Service Section Starts **************************************************************************************/
	/****
	 * To check the balance of wallet
	 * @param bridgeDataObject
	 * @return
	 */
	
	public BridgeDataObject walletBalanceEnquiryFSP(BridgeDataObject bridgeDataObject);
	/****
	 * To check the balance of bank
	 * @param bridgeDataObject
	 * @return
	 */
	public BridgeDataObject balanceEnquiryFSP(BridgeDataObject bridgeDataObject);
	
	/****
	 * To change the PIN of particular Instrument
	 * @param bridgeDataObject
	 * @return
	 */
	
	/****
	 * To request the Cheque Book of Bank
	 * @param bridgeDataObject
	 * @return
	 */
	public BridgeDataObject chequeBookRequestFSP(BridgeDataObject bridgeDataObject);
	
	/****
	 * To make a request for canceling the cheque
	 * @param bridgeDataObject
	 * @return
	 */
	public BridgeDataObject cancelChequeFSP(BridgeDataObject bridgeDataObject);
	
	/****
	 * To make a request for last 5 transaction
	 * @param bridgeDataObject
	 * @return
	 */
	public BridgeDataObject last5TransactionFSP(BridgeDataObject bridgeDataObject);
	
	
	
	/************************************************* FSP Other Service Section Ends **************************************************************************************/
	
	
	/************************************************* Bill Payment Section Starts **************************************************************************************/ 
	/**
	 * Only Recipient Bill payment to Biller part
	 * @param bridgeDataObject
	 * @return
	 */
	public BridgeDataObject billPaymentToBillerDirect(BridgeDataObject bridgeDataObject);
	/***
	 * FSP Bill Payment by Wallet
	 * @param bridgeDataObject
	 * @return
	 */
	public BridgeDataObject billPaymentByWalletFSP(BridgeDataObject bridgeDataObject);
	/***
	 * FSP Bill Payment by Bank
	 * @param bridgeDataObject
	 * @return
	 */
	public BridgeDataObject billPaymentByBankFSP(BridgeDataObject bridgeDataObject);
	/***
	 * FSP Bill Payment by IMPS
	 * @param bridgeDataObject
	 * @return
	 */
	public BridgeDataObject billPaymentByIMPSFSP(BridgeDataObject bridgeDataObject);
	/***
	 * FSP Bill Payment by CreditCard
	 * @param bridgeDataObject
	 * @return
	 */
	public BridgeDataObject billPaymentByCreditCardFSP(BridgeDataObject bridgeDataObject);
	
	/************************************************* Bill Payment Section Ends **************************************************************************************/
	
	/************************************************* Top Up Recharge Section Starts **************************************************************************************/ 
	/**
	 * Only Top Up Recharge Part to Biller
	 * @param bridgeDataObject
	 * @return
	 */
	public BridgeDataObject topUpRechargeToBillerDirect(BridgeDataObject bridgeDataObject);
	
	/**
	 * Top Up Recharge by Wallet
	 * @param bridgeDataObject
	 * @return
	 */
	public BridgeDataObject topUpRechargeByWalletFSP(BridgeDataObject bridgeDataObject);
	
	/**
	 * Top Up Recharge by Bank
	 * @param bridgeDataObject
	 * @return
	 */
	public BridgeDataObject topUpRechargeByBankFSP(BridgeDataObject bridgeDataObject);
	
	/**
	 * Top Up Recharge by IMPS
	 * @param bridgeDataObject
	 * @return
	 */
	public BridgeDataObject topUpRechargeByIMPSFSP(BridgeDataObject bridgeDataObject);
	
	/**
	 * Top Up Recharge by CreditCard
	 * @param bridgeDataObject
	 * @return
	 */
	public BridgeDataObject topUpRechargeByCreditCardFSP(BridgeDataObject bridgeDataObject);
	
	/************************************************* Top Up Recharge Section Ends **************************************************************************************/
}
