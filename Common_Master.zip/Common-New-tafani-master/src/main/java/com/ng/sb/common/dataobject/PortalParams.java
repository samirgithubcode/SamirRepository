/**
 * 
 */
package com.ng.sb.common.dataobject;

/**
 * @author gaurav
 *
 */
public class PortalParams extends BaseObjectData {
	private static final long serialVersionUID = 1L;
	private String storeId;
	private String businessDate;
	private String counterNo;
	private String operatorId;
	private String portalTransactionId;
	private String prevPortalTransactionId;
	public String getStoreId() {
		return storeId;
	}
	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}
	public String getBusinessDate() {
		return businessDate;
	}
	public void setBusinessDate(String businessDate) {
		this.businessDate = businessDate;
	}
	public String getCounterNo() {
		return counterNo;
	}
	public void setCounterNo(String counterNo) {
		this.counterNo = counterNo;
	}
	public String getOperatorId() {
		return operatorId;
	}
	public void setOperatorId(String operatorId) {
		this.operatorId = operatorId;
	}
	public String getPortalTransactionId() {
		return portalTransactionId;
	}
	public void setPortalTransactionId(String portalTransactionId) {
		this.portalTransactionId = portalTransactionId;
	}
	public String getPrevPortalTransactionId() {
		return prevPortalTransactionId;
	}
	public void setPrevPortalTransactionId(String prevPortalTransactionId) {
		this.prevPortalTransactionId = prevPortalTransactionId;
	}
	
	
}
