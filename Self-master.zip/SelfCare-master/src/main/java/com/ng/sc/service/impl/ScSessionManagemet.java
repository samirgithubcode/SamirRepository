package com.ng.sc.service.impl;

import java.util.Locale;

import javax.servlet.http.HttpSession;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;

import com.ng.sb.common.cache.MemCacheManager;
import com.ng.sb.common.cache.MemCacheUtils;
import com.ng.sb.common.dataobject.LoginData;
import com.ng.sb.common.dataobject.UserAccountData;
import com.ng.sb.common.util.SystemConstant;
import com.ng.sc.dao.IScLoginDAO;
import com.ng.sc.service.IScSessionService;


@Service
public class ScSessionManagemet  extends SelfCareService implements IScSessionService
{
	@Autowired
	IScLoginDAO loginDAO;
	@Autowired
	private MessageSource messageSource;
	
	@Autowired
    private MemCacheManager cacheManager;
	
	@Transactional
	public LoginData getSessionInfo(HttpSession session) throws Exception{
		
		LoginData loginData = new LoginData();
		if (session != null) {
			loginData = (LoginData)session.getAttribute("loginData");
			if(loginData!=null){

				UserAccountData accountData = cacheManager.getFromCache(loginData.getTokenId(), UserAccountData.class, MemCacheUtils.AUTHTOKENCACHE);

				if(accountData!=null)
				{
					loginData.setSessionInfo(true);
				}
				else
				{
					loginData.setSessionInfo(false)
;
					loginData.setStatusMessage(setDisabledFiledName(SystemConstant.SESSION_NOT_VALID));
					loginData.setView(SystemConstant.LOGIN_TRANSFER_PAGE);
				}
			}

			
		}
		return loginData;
	}
	

		public  String  setDisabledFiledName(String msg)
		{
		    return messageSource.getMessage(msg, null, Locale.getDefault());
		}
	
}
