/**
 * 
 */
package com.ng.user.dto;

import org.hibernate.validator.constraints.NotBlank;

import com.ng.sb.common.dataobject.ValidationBean;

/**
 * @author gopal
 *
 */
public class SignUpRequest implements ValidationBean {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6138683653774118945L;
	
	@NotBlank(message="Channel Id cannot be blank")
	private String channelId;
	
	@NotBlank(message="Activation code cannot be blank")
	private String activationCode;
	
	@NotBlank(message="Password cannot be blank")
	private String passwd;        //in sha256
	
	@NotBlank(message="Device Id cannot be blank")
	private String deviceSerialNumber;   //Mobile IMEI
	
	//@NotBlank(message="SKU Id cannot be blank")
	private String skuId;           //SD Card Serial No

	//@NotBlank(message="SKU Id cannot be blank")
	private String custId;           //SD Card Serial No

	public String getActivationCode() {
		return activationCode;
	}

	public void setActivationCode(String activationCode) {
		this.activationCode = activationCode;
	}

	public String getPasswd() {
		return passwd;
	}

	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}

	public String getDeviceSerialNumber() {
		return deviceSerialNumber;
	}

	public void setDeviceSerialNumber(String deviceSerialNumber) {
		this.deviceSerialNumber = deviceSerialNumber;
	}

	public String getSkuId() {
		return skuId;
	}

	public void setSkuId(String skuId) {
		this.skuId = skuId;
	}

	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public String getCustId() {
		return custId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}
	
}
