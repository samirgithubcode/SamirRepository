package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name = "cardapps")
@XmlRootElement
@NamedQueries({ @NamedQuery(name = "CardApps.findAll", query = "SELECT c FROM CardApps c"), 
				@NamedQuery(name = "CardApps.getByCardNameId", query = "SELECT c FROM CardApps c WHERE c.cardNameId=:id"),})
public class CardApps implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "id")
	private Integer id;

	

	@JoinColumn(name = "cardNameId", referencedColumnName = "id")
	@ManyToOne
	private CardDetails cardNameId;

	@JoinColumn(name = "appId", referencedColumnName = "id")
	@ManyToOne
	private PayCardApps appId;
	
	@JoinColumn(name = "productId", referencedColumnName = "id")
	@ManyToOne
	private Products productId;

	@Column(name = "partnerIds")
	private String partnerIds;

	@Column(name = "isDefault")
	private Integer isDefault;

	@Column(name = "appConstant")
	private String appConstantId;
	
	@Column(name = "status")
	private Integer status;
	public CardApps() {
		// empty
	}

	public CardApps(Integer id) {
		this.id = id;
	}

	public CardDetails getCardNameId() {
		return cardNameId;
	}

	public void setCardNameId(CardDetails cardNameId) {
		this.cardNameId = cardNameId;
	}

	public PayCardApps getAppId() {
		return appId;
	}

	public void setAppId(PayCardApps appId) {
		this.appId = appId;
	}

	public String getPartnerIds() {
		return partnerIds;
	}

	public void setPartnerIds(String partnerIds) {
		this.partnerIds = partnerIds;
	}

	public Integer getStatus() {
		return status;
	}

	public Integer getIsDefault() {
		return isDefault;
	}

	public void setIsDefault(Integer isDefault) {
		this.isDefault = isDefault;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Products getProductId() {
		return productId;
	}

	public void setProductId(Products productId) {
		this.productId = productId;
	}

	

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getAppConstantId() {
		return appConstantId;
	}

	public void setAppConstantId(String appConstantId) {
		this.appConstantId = appConstantId;
	}

	
	@Override
	public boolean equals(Object object) {
		boolean checkStatus = true;
		if (object != null) {
			if (!(object instanceof CardApps)) {
				checkStatus = false;
			}
			CardApps other = (CardApps) object;
			if ((this.id == null && other.id != null)
					|| (this.id != null && !this.id.equals(other.id))) {
				checkStatus = false;
			}
		}
		return checkStatus;
	}

	@Override
	public int hashCode() {
		int hash = 0;
		hash += (id != null ? id.hashCode() : 0);
		return hash;
	}

	
}
