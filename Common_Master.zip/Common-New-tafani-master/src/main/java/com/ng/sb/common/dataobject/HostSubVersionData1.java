package com.ng.sb.common.dataobject;

import com.ng.sb.common.model.AccountInfo;
import com.ng.sb.common.model.MasterVersion;

public class HostSubVersionData1 extends BaseObjectData {

	private static final long serialVersionUID = 1L;
	
	private String name;
	private MasterVersion mvId;
	private AccountInfo hostId;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public MasterVersion getMvId() {
		return mvId;
	}
	public void setMvId(MasterVersion mvId) {
		this.mvId = mvId;
	}
	public AccountInfo getHostId() {
		return hostId;
	}
	public void setHostId(AccountInfo hostId) {
		this.hostId = hostId;
	}
	
	
	
	
	
}
