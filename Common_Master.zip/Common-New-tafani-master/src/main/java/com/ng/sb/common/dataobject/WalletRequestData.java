/**
 * 
 */
package com.ng.sb.common.dataobject;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author gaurav
 *
 */
@XmlRootElement(name = "WalletRequestData")
public class WalletRequestData extends PlatformRequestData {
	private static final long serialVersionUID = 1L;
	private PortalParams portalParams;
	private String key;
	private Integer amount;
	private String mobileNo;
	private String transactionId;
	private Integer customerOTP;
	private String transactionType;
	private Integer walletCode;
	public Integer getWalletCode() {
		return walletCode;
	}
	public void setWalletCode(Integer walletCode) {
		this.walletCode = walletCode;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public Integer getCustomerOTP() {
		return customerOTP;
	}
	public void setCustomerOTP(Integer customerOTP) {
		this.customerOTP = customerOTP;
	}
	public PortalParams getPortalParams() {
		return portalParams;
	}
	public void setPortalParams(PortalParams portalParams) {
		this.portalParams = portalParams;
	}
	public Integer getAmount() {
		return amount;
	}
	public void setAmount(Integer amount) {
		this.amount = amount;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	
}
