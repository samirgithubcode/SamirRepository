package com.ng.sb.common.exception;

public class CustomInvalidMsisdnException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CustomInvalidMsisdnException(String message){
		super(message);
	}

}
