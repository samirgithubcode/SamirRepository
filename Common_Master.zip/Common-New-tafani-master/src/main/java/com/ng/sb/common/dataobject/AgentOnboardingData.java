package com.ng.sb.common.dataobject;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author abhishek
 *
 */
@XmlRootElement(name="AgentOnboardingData")
public class AgentOnboardingData extends BaseObjectData {

	private static final long serialVersionUID = 1L;

	private String userLoginName;
	private String password;
	private String email;
	private String userMobile;
	private String altMobile;
	private String countryCode;
	private String altCountryCode;
	private String settlementCycle;
	public String getSettlementCycle() {
		return settlementCycle;
	}
	public void setSettlementCycle(String settlementCycle) {
		this.settlementCycle = settlementCycle;
	}
	public String getUserLoginName() {
		return userLoginName;
	}
	public void setUserLoginName(String userLoginName) {
		this.userLoginName = userLoginName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getUserMobile() {
		return userMobile;
	}
	public void setUserMobile(String userMobile) {
		this.userMobile = userMobile;
	}
	public String getAltMobile() {
		return altMobile;
	}
	public void setAltMobile(String altMobile) {
		this.altMobile = altMobile;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getAltCountryCode() {
		return altCountryCode;
	}
	public void setAltCountryCode(String altCountryCode) {
		this.altCountryCode = altCountryCode;
	}
	@Override
	public String toString() {
		return "AgentOnboardingData [userMobile=" + userMobile + "]";
	}
	
	@Override
	public int hashCode() {
	   int prime = 31;
		int result = 1;
		result = prime * result
				+ ((userMobile == null) ? 0 : userMobile.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AgentOnboardingData other = (AgentOnboardingData) obj;
		if (userMobile == null) {
			if (other.userMobile != null)
				return false;
		} else if (!userMobile.equals(other.userMobile))
			return false;
		return true;
	}
	
	
	
}
