package com.ng.sb.common.dataobject;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;


@JsonInclude(Include.NON_EMPTY)
public class CommissionInfosPayload implements ValidationBean{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7739114661296334295L;

	@JsonProperty("commissionList")
	private List<CommissionInfosResponse> commInfoList = new ArrayList<>();

	public List<CommissionInfosResponse> getCommInfoList() {
		return commInfoList;
	}

	public void setCommInfoList(List<CommissionInfosResponse> commInfoList) {
		this.commInfoList = commInfoList;
	}
	
}
