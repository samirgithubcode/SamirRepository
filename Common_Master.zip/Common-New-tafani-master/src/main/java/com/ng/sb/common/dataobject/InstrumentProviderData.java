/**
 * 
 */
package com.ng.sb.common.dataobject;

import com.ng.sb.common.dataobject.HostSubVersionData.ProviderRelation;
import com.ng.sb.common.dataobject.InstrumentData.Sequence;

/**
 * @author gaurav
 *
 */
public class InstrumentProviderData extends BaseObjectData {
	private static final long serialVersionUID = 1L;

	private InstrumentData instrumentData;
	private ProviderRelation directProvider;
	
	private Sequence sequence;
	public InstrumentProviderData(){
		//default constructor
	}
	
	public InstrumentProviderData(InstrumentData instrumentData){
		this.instrumentData=instrumentData;
	}
	public InstrumentProviderData(ProviderRelation directProvider){
		this.directProvider=directProvider;
	}
	
	public InstrumentProviderData(InstrumentData instrumentData,Sequence sequence){
		this.instrumentData=instrumentData;
		this.sequence=sequence;
	}
	
	public InstrumentProviderData(ProviderRelation directProvider,Sequence sequence){
		this.directProvider=directProvider;
		this.sequence=sequence;
	}

	public Sequence getSequence() {
		return sequence;
	}

	public void setSequence(Sequence sequence) {
		this.sequence = sequence;
	}
	public InstrumentData getInstrumentData() {
		return instrumentData;
	}

	public void setInstrumentData(InstrumentData instrumentData) {
		this.instrumentData = instrumentData;
	}

	public ProviderRelation getDirectProvider() {
		return directProvider;
	}

	public void setDirectProvider(ProviderRelation directProvider) {
		this.directProvider = directProvider;
	}

}
