package com.ng.bridge.dataobject.eko;

public class RefundResendOTPRes {

	private String responseTypeId;

    private String message;

    private String responseStatusId;

    private String status;

    private RefundResendOTPResData data;

  

    public String getMessage ()
    {
        return message;
    }

    public void setMessage (String message)
    {
        this.message = message;
    }
    public String getResponseTypeId ()
    {
        return responseTypeId;
    }

    public void setResponseTypeId (String responseTypeId)
    {
        this.responseTypeId = responseTypeId;
    }
    public String getResponseStatusId ()
    {
        return responseStatusId;
    }

    public void setResponseStatusId (String responseStatusId)
    {
        this.responseStatusId = responseStatusId;
    }

    

	public RefundResendOTPResData getData() {
		return data;
	}

	public void setData(RefundResendOTPResData data) {
		this.data = data;
	}

	public String getStatus ()
    {
        return status;
    }

    public void setStatus (String status)
    {
        this.status = status;
    }

 
}
