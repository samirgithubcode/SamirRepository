package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.*;



/**
 * @author abhishek
 *
 */
@Entity
@Table(name="Denomination")
@NamedQueries
({
	@NamedQuery(name="Denomination.findById", query="SELECT d FROM Denomination d where d.id = :id"),
	@NamedQuery(name="Denomination.findAll", query="SELECT d FROM Denomination d order by d.denominationValue"),
	@NamedQuery(name="Denomination.findByDenominationValue", query="SELECT count(*) FROM Denomination d where d.denominationValue=:denominationValue"),
	@NamedQuery(name="Denomination.findBydenominationValue", query="SELECT d FROM Denomination d where d.denominationValue=:denominationValue")
})

public class Denomination implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Basic(optional = false)
	private Integer id;
	
	@Basic(optional = false)
	@Column(name="denomination_value")
	private Integer denominationValue;

	public Denomination() {
		//empty
	}
	
	public Denomination(Integer id)
	{
		this.id = id;
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getDenominationValue() {
		return this.denominationValue;
	}

	public void setDenominationValue(Integer denominationValue) {
		this.denominationValue = denominationValue;
	}

}