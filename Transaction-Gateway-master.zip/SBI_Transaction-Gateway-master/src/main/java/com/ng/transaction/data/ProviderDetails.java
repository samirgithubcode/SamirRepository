/**
 * 
 */
package com.ng.transaction.data;

import com.ng.sb.common.dataobject.ValidationBean;

/**
 * @author gopal
 *
 */
public class ProviderDetails implements ValidationBean 
{
	
  /**
	 * 
	 */
	private static final long serialVersionUID = 5316811485563648352L;

private int providerCode;
private String providerName;
  private String subscriberId;

public int getProviderCode() {
	return providerCode;
}

public void setProviderCode(int providerCode) {
	this.providerCode = providerCode;
}

public String getSubscriberId() {
	return subscriberId;
}

public void setSubscriberId(String subscriberId) {
	this.subscriberId = subscriberId;
}

public String getProviderName() {
	return providerName;
}

public void setProviderName(String providerName) {
	this.providerName = providerName;
}
  
  
}
