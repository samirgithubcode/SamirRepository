/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author amardeep
 */
@Entity
@Table(name = "InventorySummary")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "InventorySummary.findAll", query = "SELECT i FROM InventorySummary i"),
    @NamedQuery(name = "InventorySummary.findById", query = "SELECT i FROM InventorySummary i WHERE i.id = :id"),
    @NamedQuery(name = "InventorySummary.findByAvailableStock", query = "SELECT i FROM InventorySummary i WHERE i.availableStock = :availableStock"),
    @NamedQuery(name = "InventorySummary.findByTotalStockTillDate", query = "SELECT i FROM InventorySummary i WHERE i.totalStockTillDate = :totalStockTillDate")})
public class InventorySummary implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "availableStock")
    private int availableStock;
    @Column(name = "totalStockTillDate")
    private Integer totalStockTillDate;
    @JoinColumn(name = "mvId", referencedColumnName = "id")
    @ManyToOne
    private MasterVersion mvId;
    @JoinColumn(name = "productId", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Products productId;
    @JoinColumn(name = "accountId", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private AccountInfo accountId;

    public InventorySummary() {
    	//default constructor
    }

    public InventorySummary(Integer id) {
        this.id = id;
    }

    public InventorySummary(Integer id, int availableStock) {
        this.id = id;
        this.availableStock = availableStock;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public int getAvailableStock() {
        return availableStock;
    }

    public void setAvailableStock(int availableStock) {
        this.availableStock = availableStock;
    }

    public Integer getTotalStockTillDate() {
        return totalStockTillDate;
    }

    public void setTotalStockTillDate(Integer totalStockTillDate) {
        this.totalStockTillDate = totalStockTillDate;
    }

    public MasterVersion getMvId() {
        return mvId;
    }

    public void setMvId(MasterVersion mvId) {
        this.mvId = mvId;
    }

    public Products getProductId() {
        return productId;
    }

    public void setProductId(Products productId) {
        this.productId = productId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    
    public AccountInfo getAccountId() {
        return accountId;
    }

    public void setAccountId(AccountInfo accountId) {
        this.accountId = accountId;
    }

  
    @Override
    public boolean equals(Object object) {
        if (!(object instanceof InventorySummary)) {
            return false;
        }
        InventorySummary other = (InventorySummary) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.InventorySummary[ id=" + id + " ]";
    }
    
}
