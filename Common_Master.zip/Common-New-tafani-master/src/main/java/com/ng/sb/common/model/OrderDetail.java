package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name = "OrderDetail")
@XmlRootElement
@NamedQueries({
		@NamedQuery(name = "OrderDetail.findAll", query = "SELECT o FROM OrderDetail o"),
		@NamedQuery(name = "OrderDetail.findallByorderId", query = "SELECT o FROM OrderDetail o where o.orderId=:order"),
		@NamedQuery(name = "OrderDetail.findallwithorderId", query = "SELECT o FROM OrderDetail o where o.orderId=:order and o.productId=:productid"),
		@NamedQuery(name = "OrderDetail.findallByorderIdandentity", query = "SELECT o FROM OrderDetail o where o.orderId=:order"),
		@NamedQuery(name = "OrderDetail.findByOrderId", query = "SELECT o FROM OrderDetail o WHERE o.orderId = :orderId "),
		@NamedQuery(name = "OrderDetail.findById", query = "SELECT o FROM OrderDetail o WHERE o.id = :orderId"),
		@NamedQuery(name = "OrderDetail.findAllByOrderNumberProductAndMV", query = "SELECT o FROM OrderDetail o WHERE o.orderId = :orderId AND o.productId = :productId AND o.masterVersionId = :masterVersionId"),
		@NamedQuery(name = "OrderDetail.setStatusById", query = "SELECT o FROM OrderDetail o WHERE o.id=:id"),
		@NamedQuery(name = "OrderDetail.findodernobyorderid", query = "SELECT o.productId.id FROM OrderDetail o WHERE o.orderId.id=:id AND o.masterVersionId.id=:masterId"),
		
		
		
		// @NamedQuery(name = "OrderDetail.findAllbyaccountidandproducttype",
		// query="SELECT o FROM OrderDetail o WHERE o.productId.type=:type AND o.orderId.createdBy=:createdBy"),
		@NamedQuery(name = "OrderDetail.findAllbyaccountidandproducttype", query = "SELECT o FROM OrderDetail o WHERE o.productId=:productId AND o.orderId.createdBy=:createdBy AND o.status='PENDING' order by o.id desc"), })
public class OrderDetail implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;

	@Basic(optional = false)
	@JoinColumn(name = "orderId", referencedColumnName = "id")
	@ManyToOne
	private Order orderId;

	@Basic(optional = false)
	@JoinColumn(name = "productId", referencedColumnName = "id")
	@ManyToOne
	private Products productId;

	@JoinColumn(name = "cardType", referencedColumnName = "id")
	@ManyToOne
	private CardDetails cardType;

	@Basic(optional = false)
	@JoinColumn(name = "masterVersionId", referencedColumnName = "id")
	@ManyToOne
	private MasterVersion masterVersionId;

	@Column(name = "unitsOrdered")
	private Integer unitsOrdered;

	@Column(name = "unitsDispatched")
	private Integer unitsDispatched;

	@Basic(optional = false)
	@Column(name = "status")
	private String status;

	@Basic(optional = false)
	@Column(name = "createDate")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createDate;

	@Basic(optional = false)
	@Column(name = "editDate")
	@Temporal(TemporalType.TIMESTAMP)
	private Date editDate;

	public OrderDetail() {
		// empty
	}

	public OrderDetail(Integer id) {
		this.id = id;
	}

	public OrderDetail(Integer id, Order orderId, Products productId, MasterVersion masterVersionId,
			Integer unitsOrdered, Integer unitsDispatched, String status) {
		this.id = id;
		this.orderId = orderId;
		this.productId = productId;
		this.masterVersionId = masterVersionId;
		this.unitsOrdered = unitsOrdered;
		this.unitsDispatched = unitsDispatched;
		this.status = status;
	}

	public CardDetails getCardType() {
		return cardType;
	}

	public void setCardType(CardDetails cardType) {
		this.cardType = cardType;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getEditDate() {
		return editDate;
	}

	public void setEditDate(Date editDate) {
		this.editDate = editDate;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Order getOrderId() {
		return orderId;
	}

	public void setOrderId(Order orderId) {
		this.orderId = orderId;
	}

	public Products getProductId() {
		return productId;
	}

	public void setProductId(Products productId) {
		this.productId = productId;
	}

	public MasterVersion getMasterVersionId() {
		return masterVersionId;
	}

	public void setMasterVersionId(MasterVersion masterVersionId) {
		this.masterVersionId = masterVersionId;
	}

	public Integer getUnitsOrdered() {
		return unitsOrdered;
	}

	public void setUnitsOrdered(Integer unitsOrdered) {
		this.unitsOrdered = unitsOrdered;
	}

	public Integer getUnitsDispatched() {
		return unitsDispatched;
	}

	public void setUnitsDispatched(Integer unitsDispatched) {
		this.unitsDispatched = unitsDispatched;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "OrderDetail [id=" + id + "]";
	}

	@Override
	public boolean equals(Object object) {
		boolean check = true;
		if (object != null) {
			if (!(object instanceof OrderDetail)) {
				check = false;
			}
			OrderDetail other = (OrderDetail) object;
			if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
				check = false;
			}
		}
		return check;
	}

	@Override
	public int hashCode() {
		int hash = 0;
		hash += (id != null ? id.hashCode() : 0);
		return hash;
	}
}
