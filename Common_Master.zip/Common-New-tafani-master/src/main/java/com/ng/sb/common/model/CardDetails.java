package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

	@Entity
	@Table(name = "carddetails")
	@XmlRootElement
	@NamedQueries({
		@NamedQuery(name="CardDetails.findAll", query="SELECT c FROM CardDetails c"),
		@NamedQuery(name="CardDetails.findbyStatus", query="SELECT c FROM CardDetails c order by c.status desc, c.cardName"),
		@NamedQuery(name="CardDetails.findByCode", query="SELECT c FROM CardDetails c where c.code=:code"),
		@NamedQuery(name="CardDetails.findById", query="SELECT c FROM CardDetails c where c.id=:id"),
		@NamedQuery(name="CardDetails.findByProductId", query="SELECT c FROM CardDetails c where c.productId=:productId"),
	})
	public class CardDetails implements Serializable {
		private static final long serialVersionUID = 1L;
		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		@Basic(optional = false)
		@Column(name = "id")
		private Integer id;
		

		@JoinColumn(name = "productId", referencedColumnName = "id")
		@ManyToOne
		private Products productId;

		@Column(name = "cardName")
		private String cardName;

		@Column(name = "code")
		private Integer code;
		
	
		@JoinColumn(name = "bankId", referencedColumnName = "id")
		@ManyToOne
		private Banks bankId;

		@Column(name = "cardType")
	    private String cardType;
		
		@Column(name = "startDate")
	    @Temporal(TemporalType.DATE)
	    private Date startDate;
	    
	    @Column(name = "endDate")
	    @Temporal(TemporalType.DATE)
	    private Date endDate;
		
	    @Column(name = "status")
	    private Integer status;

		@Column(name = "filePath")
	    private String filePath;
		
		@OneToMany(cascade = CascadeType.ALL, mappedBy = "cardNameId", fetch=FetchType.EAGER)
	    private Set<CardWallets> mappedWallets;
		
		@OneToMany(cascade = CascadeType.ALL, mappedBy = "cardNameId",fetch=FetchType.EAGER)
	    private Set<CardApps> mappedApps;
		
			public CardDetails() {
		    	//empty
		    }

		    public CardDetails(Integer id) {
		        this.id = id;
		    }
		public Integer getCode() {
			return code;
		}

		public void setCode(Integer code) {
			this.code = code;
		}

	    public Products getProductId() {
			return productId;
		}

		public void setProductId(Products productId) {
			this.productId = productId;
		}

		public String getCardName() {
			return cardName;
		}

		public void setCardName(String cardName) {
			this.cardName = cardName;
		}

		public Banks getBankId() {
			return bankId;
		}

		public void setBankId(Banks bankId) {
			this.bankId = bankId;
		}

		public Date getStartDate() {
			return startDate;
		}

		public void setStartDate(Date startDate) {
			this.startDate = startDate;
		}

		public Date getEndDate() {
			return endDate;
		}

		public void setEndDate(Date endDate) {
			this.endDate = endDate;
		}

		public Integer getStatus() {
			return status;
		}

		public void setStatus(Integer status) {
			this.status = status;
		}

		public String getFilePath() {
			return filePath;
		}

		public void setFilePath(String filePath) {
			this.filePath = filePath;
		}

	
	    
		
		public Integer getId() {
			return id;
		}

		public void setId(Integer id) {
			this.id = id;
		}


		@Override
		public boolean equals(Object object) {
			boolean checkStatus = true;	
			if (object != null) {
				if (!(object instanceof CardDetails)) {
					checkStatus = false;
				}
				CardDetails other = (CardDetails) object;
				if ((this.id == null && other.id != null)
						|| (this.id != null && !this.id.equals(other.id))) {
					checkStatus = false;
				}
			}
			return checkStatus;
		}

		@Override
		public int hashCode() {
			int hash = 0;
			hash += (id != null ? id.hashCode() : 0);
			return hash;
		}

		public Set<CardWallets> getMappedWallets() {
			return mappedWallets;
		}

		public void setMappedWallets(Set<CardWallets> mappedWallets) {
			this.mappedWallets = mappedWallets;
		}

		public Set<CardApps> getMappedApps() {
			return mappedApps;
		}

		public void setMappedApps(Set<CardApps> mappedApps) {
			this.mappedApps = mappedApps;
		}

		public String getCardType() {
			return cardType;
		}

		public void setCardType(String cardType) {
			this.cardType = cardType;
		}

		
		
	}
	
	
	
	
	
	
	
	
	
	
