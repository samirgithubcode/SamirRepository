/**
 * 
 */
package com.ng.transaction.dao;


/**
 * @author gaurav
 *
 */
public interface IPaymentInstrumentDAO extends ITransactionDAO {

}
