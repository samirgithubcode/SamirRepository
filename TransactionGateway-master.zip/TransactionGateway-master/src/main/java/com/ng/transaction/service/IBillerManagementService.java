/**
 * 
 */
package com.ng.transaction.service;

import com.ng.sb.common.dataobject.BridgeDataObject;

/**
 * @author gaurav
 *
 */
public interface IBillerManagementService extends IFundTransferMgtService {
	// Bill Pay
	public BridgeDataObject fundTransferToBillerByBank(BridgeDataObject bridgeDataObject);
	public BridgeDataObject fundTransferToBillerByCC(BridgeDataObject bridgeDataObject);
	public BridgeDataObject fundTransferToBillerByIMPS(BridgeDataObject bridgeDataObject);
	public BridgeDataObject fundTransferToBillerByWallet(BridgeDataObject bridgeDataObject);
	public BridgeDataObject fundTransferToBillerByRI(BridgeDataObject bridgeDataObject);
	
	// Recharge
	public BridgeDataObject topUpRechargeByWallet(BridgeDataObject bridgeDataObject);
	public BridgeDataObject topUpRechargeByCC(BridgeDataObject bridgeDataObject);
	public BridgeDataObject topUpRechargeByIMPS(BridgeDataObject bridgeDataObject);
	public BridgeDataObject topUpRechargeByBank(BridgeDataObject bridgeDataObject);
	
}
