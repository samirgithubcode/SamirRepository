/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "TransactionFundTransfer")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "TransactionFundTransfer.findAll", query = "SELECT t FROM TransactionFundTransfer t"),
    @NamedQuery(name = "TransactionFundTransfer.findById", query = "SELECT t FROM TransactionFundTransfer t WHERE t.id = :id"),
    @NamedQuery(name = "TransactionFundTransfer.findByMsisdn", query = "SELECT t FROM TransactionFundTransfer t WHERE t.msisdn = :msisdn"),
    @NamedQuery(name = "TransactionFundTransfer.findByTxnId", query = "SELECT t FROM TransactionFundTransfer t WHERE t.txnId = :txnId"),
    @NamedQuery(name = "TransactionFundTransfer.findByServiceDefnitioon", query = "SELECT t FROM TransactionFundTransfer t WHERE t.serviceDefnitioon = :serviceDefnitioon"),
    @NamedQuery(name = "TransactionFundTransfer.findByPayerBAAcc", query = "SELECT t FROM TransactionFundTransfer t WHERE t.payerBAAcc = :payerBAAcc"),
    @NamedQuery(name = "TransactionFundTransfer.findByPayerIFSCCode", query = "SELECT t FROM TransactionFundTransfer t WHERE t.payerIFSCCode = :payerIFSCCode"),
    @NamedQuery(name = "TransactionFundTransfer.findByPayerMmid", query = "SELECT t FROM TransactionFundTransfer t WHERE t.payerMmid = :payerMmid"),
    @NamedQuery(name = "TransactionFundTransfer.findByPayerCCNumber", query = "SELECT t FROM TransactionFundTransfer t WHERE t.payerCCNumber = :payerCCNumber"),
    @NamedQuery(name = "TransactionFundTransfer.findByPayerCCName", query = "SELECT t FROM TransactionFundTransfer t WHERE t.payerCCName = :payerCCName"),
    @NamedQuery(name = "TransactionFundTransfer.findByPayerCCExpDate", query = "SELECT t FROM TransactionFundTransfer t WHERE t.payerCCExpDate = :payerCCExpDate"),
    @NamedQuery(name = "TransactionFundTransfer.findByPayerWCode", query = "SELECT t FROM TransactionFundTransfer t WHERE t.payerWCode = :payerWCode"),
    @NamedQuery(name = "TransactionFundTransfer.findBySubAccId", query = "SELECT t FROM TransactionFundTransfer t WHERE t.subAccId = :subAccId"),
    @NamedQuery(name = "TransactionFundTransfer.findByProviderCode", query = "SELECT t FROM TransactionFundTransfer t WHERE t.providerCode = :providerCode"),
    @NamedQuery(name = "TransactionFundTransfer.findByProviderName", query = "SELECT t FROM TransactionFundTransfer t WHERE t.providerName = :providerName"),
    @NamedQuery(name = "TransactionFundTransfer.findByPCatCode", query = "SELECT t FROM TransactionFundTransfer t WHERE t.pCatCode = :pCatCode"),
    @NamedQuery(name = "TransactionFundTransfer.findByPCatName", query = "SELECT t FROM TransactionFundTransfer t WHERE t.pCatName = :pCatName"),
    @NamedQuery(name = "TransactionFundTransfer.findByDate", query = "SELECT t FROM TransactionFundTransfer t WHERE t.date = :date")})
public class TransactionFundTransfer implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
    @Column(name = "msisdn", length = 25)
    private String msisdn;
    @Column(name = "txnId", length = 25)
    private String txnId;
    @Column(name = "serviceDefnitioon", length = 50)
    private String serviceDefnitioon;
    @Column(name = "payerBAAcc", length = 25)
    private String payerBAAcc;
    @Column(name = "payerIFSCCode", length = 15)
    private String payerIFSCCode;
    @Column(name = "payerMmid")
    private Integer payerMmid;
    @Column(name = "payerCCNumber", length = 25)
    private String payerCCNumber;
    @Column(name = "payerCCName", length = 25)
    private String payerCCName;
    @Column(name = "payerCCExpDate")
    private Integer payerCCExpDate;
    @Column(name = "payerWCode")
    private Integer payerWCode;
    @Column(name = "subAccId", length = 25)
    private String subAccId;
    @Column(name = "providerCode")
    private Integer providerCode;
    @Column(name = "providerName", length = 25)
    private String providerName;
    @Column(name = "pCatCode")
    private Integer pCatCode;
    @Column(name = "pCatName", length = 25)
    private String pCatName;
    @Basic(optional = false)
    @Column(name = "date", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date date;
    @JoinColumn(name = "userId", referencedColumnName = "id")
    @ManyToOne
    private Subscriber userId;

    public TransactionFundTransfer() {
    	//default constructor
    }

    public TransactionFundTransfer(Integer id) {
        this.id = id;
    }

    public TransactionFundTransfer(Integer id, Date date) {
        this.id = id;
        this.date = date;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    
    public String getTxnId() {
        return txnId;
    }

    public void setTxnId(String txnId) {
        this.txnId = txnId;
    }

    public String getServiceDefnitioon() {
        return serviceDefnitioon;
    }

    public void setServiceDefnitioon(String serviceDefnitioon) {
        this.serviceDefnitioon = serviceDefnitioon;
    }

    public String getPayerBAAcc() {
        return payerBAAcc;
    }

    public void setPayerBAAcc(String payerBAAcc) {
        this.payerBAAcc = payerBAAcc;
    }

    public String getPayerIFSCCode() {
        return payerIFSCCode;
    }

    public void setPayerIFSCCode(String payerIFSCCode) {
        this.payerIFSCCode = payerIFSCCode;
    }

    public Integer getPayerMmid() {
        return payerMmid;
    }

    public void setPayerMmid(Integer payerMmid) {
        this.payerMmid = payerMmid;
    }

    public String getPayerCCNumber() {
        return payerCCNumber;
    }

    public void setPayerCCNumber(String payerCCNumber) {
        this.payerCCNumber = payerCCNumber;
    }

    public String getPayerCCName() {
        return payerCCName;
    }

    public void setPayerCCName(String payerCCName) {
        this.payerCCName = payerCCName;
    }

    public Integer getPayerCCExpDate() {
        return payerCCExpDate;
    }

    public void setPayerCCExpDate(Integer payerCCExpDate) {
        this.payerCCExpDate = payerCCExpDate;
    }
    
    public String getMsisdn() {
        return msisdn;
    }

    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }


    public Integer getPayerWCode() {
        return payerWCode;
    }

    public void setPayerWCode(Integer payerWCode) {
        this.payerWCode = payerWCode;
    }
    
    public Subscriber getUserId() {
        return userId;
    }

    public void setUserId(Subscriber userId) {
        this.userId = userId;
    }


    public String getSubAccId() {
        return subAccId;
    }

    public void setSubAccId(String subAccId) {
        this.subAccId = subAccId;
    }

    public Integer getProviderCode() {
        return providerCode;
    }

    public void setProviderCode(Integer providerCode) {
        this.providerCode = providerCode;
    }

    public String getProviderName() {
        return providerName;
    }

    public void setProviderName(String providerName) {
        this.providerName = providerName;
    }

    public Integer getPCatCode() {
        return pCatCode;
    }

    public void setPCatCode(Integer pCatCode) {
        this.pCatCode = pCatCode;
    }

    public String getPCatName() {
        return pCatName;
    }

    public void setPCatName(String pCatName) {
        this.pCatName = pCatName;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof TransactionFundTransfer)) {
            return false;
        }
        TransactionFundTransfer other = (TransactionFundTransfer) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.TransactionFundTransfer[ id=" + id + " ]";
    }
    
}
