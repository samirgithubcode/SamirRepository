/**
 * 
 */
package com.ng.sb.common.dataobject;

/**
 * @author gaurav
 *
 */
public class HSVProvPartnerMapping extends BaseObjectData{
	private static final long serialVersionUID = 1L;
	private Integer catId;
	private String catName;
	private Integer provId;
	private Integer provCode;
	private String provName;
	private Integer partnerId;
	private String partnerName;
	private String partnerNickName;
	private Integer partnerCode;
	private Integer hostSubVersId;
	private Integer sequence;
	private Integer commissionId;
	public Integer getCommissionId() {
		return commissionId;
	}
	public void setCommissionId(Integer commissionId) {
		this.commissionId = commissionId;
	}
	
	public Integer getCatId() {
		return catId;
	}
	public void setCatId(Integer catId) {
		this.catId = catId;
	}
	public String getCatName() {
		return catName;
	}
	public void setCatName(String catName) {
		this.catName = catName;
	}
	public Integer getProvId() {
		return provId;
	}
	public void setProvId(Integer provId) {
		this.provId = provId;
	}
	public Integer getProvCode() {
		return provCode;
	}
	public void setProvCode(Integer provCode) {
		this.provCode = provCode;
	}
	public String getProvName() {
		return provName;
	}
	public void setProvName(String provName) {
		this.provName = provName;
	}
	public Integer getPartnerId() {
		return partnerId;
	}
	public void setPartnerId(Integer partnerId) {
		this.partnerId = partnerId;
	}
	public String getPartnerName() {
		return partnerName;
	}
	public void setPartnerName(String partnerName) {
		this.partnerName = partnerName;
	}
	public String getPartnerNickName() {
		return partnerNickName;
	}
	public void setPartnerNickName(String partnerNickName) {
		this.partnerNickName = partnerNickName;
	}
	public Integer getHostSubVersId() {
		return hostSubVersId;
	}
	public void setHostSubVersId(Integer hostSubVersId) {
		this.hostSubVersId = hostSubVersId;
	}
	public Integer getSequence() {
		return sequence;
	}
	public void setSequence(Integer sequence) {
		this.sequence = sequence;
	}
	public Integer getPartnerCode() {
		return partnerCode;
	}
	public void setPartnerCode(Integer partnerCode) {
		this.partnerCode = partnerCode;
	}
	
}
