package com.ng.sb.common.dataobject;

/***
 * 
 * @author gaurav
 *
 */
public class Merchant extends BaseObjectData {
	private static final long serialVersionUID = 1L;
	private String nickName;
	private Wallet wallet;
	private BankAccount bankAccount;
	private CreditCard creditCard;
	private IMPS imps;

	

	public Wallet getWallet() {
		return wallet;
	}

	public void setWallet(Wallet wallet) {
		this.wallet = wallet;
	}

	public String getNickName() {
		return nickName;
	}

	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	
	public BankAccount getBankAccount() {
		return bankAccount;
	}

	public void setBankAccount(BankAccount bankAccount) {
		this.bankAccount = bankAccount;
	}

	

	public IMPS getImps() {
		return imps;
	}

	public void setImps(IMPS imps) {
		this.imps = imps;
	}
	
	public CreditCard getCreditCard() {
		return creditCard;
	}

	public void setCreditCard(CreditCard creditCard) {
		this.creditCard = creditCard;
	}

}
