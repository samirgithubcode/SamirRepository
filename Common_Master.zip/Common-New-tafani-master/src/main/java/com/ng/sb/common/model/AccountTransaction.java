package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the accountTransaction database table.
 * 
 */
/**
 * @author abhishek
 *
 */
@Entity
@Table(name="accountTransaction")
@NamedQueries({
@NamedQuery(name="AccountTransaction.findAll", query="SELECT a FROM AccountTransaction a"),
@NamedQuery(name="AccountTransaction.findByPayerAccIdOrPayeeAccId", query = "SELECT a FROM AccountTransaction a WHERE a.payerAccId =:payerAccId OR a.payeeAccId =:payeeAccId ORDER BY a.createDate DESC")
})
public class AccountTransaction implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false)
	private Integer id;

	@Column(nullable=false)
	@Temporal(TemporalType.TIMESTAMP)
    private Date createDate;

	private Integer txnAmount;

	//bi-directional many-to-one association to Account
	@ManyToOne
	@JoinColumn(name="payerAccId")
	private Account payerAccId;

	//bi-directional many-to-one association to Account
	@ManyToOne
	@JoinColumn(name="payeeAccId")
	private Account payeeAccId;
	public AccountTransaction() {
		//empty
	}

	public AccountTransaction(Integer id) {
		this.id = id;
	}
	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public void setTxnAmount(Integer txnAmount) {
		this.txnAmount = txnAmount;
	}
	
	
	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}


	public int getTxnAmount() {
		return this.txnAmount;
	}

	public void setTxnAmount(int txnAmount) {
		this.txnAmount = txnAmount;
	}

	public Account getPayerAccId() {
		return this.payerAccId;
	}

	public void setPayerAccId(Account payerAccId) {
		this.payerAccId = payerAccId;
	}

	/**
	 * @return
	 */
	public Account getPayeeAccId() {
		return this.payeeAccId;
	}

	@Override
	public String toString() {
		return "AccountTransaction [id=" + id + "]";
	}

	public void setPayeeAccId(Account payeeAccId) {
		this.payeeAccId = payeeAccId;
	}

	@Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof AccountTransaction)) {
            return false;
        }
        AccountTransaction other = (AccountTransaction) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }
	
}