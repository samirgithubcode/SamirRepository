package com.ng.sb.common.dataobject;

import java.util.List;
import java.util.Map;


/**
 * @author amardeep
 *
 */
public class HostPartnerPreferenceData  extends BaseObjectData{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private List<String> type;
	private Map<Integer, String> hsvMap;
	private Integer hsvId;
	private Integer seq1;
	private Integer seq2;
	private Integer seq3;
	private Integer seq4;
	private String typeName1;
	private String typeName2;
	private String typeName3;
	private String typeName4;
	private String statusMessage;
	private String hsvName;
	private String typeName;
	private Integer seq;
	
	public Integer getSeq() {
		return seq;
	}
	public void setSeq(Integer seq) {
		this.seq = seq;
	}
	public String getHsvName() {
		return hsvName;
	}
	public void setHsvName(String hsvName) {
		this.hsvName = hsvName;
	}
	public String getTypeName() {
		return typeName;
	}
	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}
	public String getStatusMessage() {
		return statusMessage;
	}
	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}
	public String getTypeName1() {
		return typeName1;
	}
	public void setTypeName1(String typeName1) {
		this.typeName1 = typeName1;
	}
	public String getTypeName2() {
		return typeName2;
	}
	public void setTypeName2(String typeName2) {
		this.typeName2 = typeName2;
	}
	public String getTypeName3() {
		return typeName3;
	}
	public void setTypeName3(String typeName3) {
		this.typeName3 = typeName3;
	}
	public String getTypeName4() {
		return typeName4;
	}
	public void setTypeName4(String typeName4) {
		this.typeName4 = typeName4;
	}
	public Integer getSeq1() {
		return seq1;
	}
	public void setSeq1(Integer seq1) {
		this.seq1 = seq1;
	}
	public Integer getSeq2() {
		return seq2;
	}
	public void setSeq2(Integer seq2) {
		this.seq2 = seq2;
	}
	public Integer getSeq3() {
		return seq3;
	}
	public void setSeq3(Integer seq3) {
		this.seq3 = seq3;
	}
	public Integer getSeq4() {
		return seq4;
	}
	public void setSeq4(Integer seq4) {
		this.seq4 = seq4;
	}
	public Integer getHsvId() {
		return hsvId;
	}
	public void setHsvId(Integer hsvId) {
		this.hsvId = hsvId;
	}
	public List<String> getType() {
		return type;
	}
	public void setType(List<String> type) {
		this.type = type;
	}
	public Map<Integer, String> getHsvMap() {
		return hsvMap;
	}
	public void setHsvMap(Map<Integer, String> hsvMap) {
		this.hsvMap = hsvMap;
	}
}
