/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "Banks")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Banks.findAll", query = "SELECT b FROM Banks b"),
    @NamedQuery(name = "Banks.findById", query = "SELECT b FROM Banks b WHERE b.id = :id"),
    @NamedQuery(name = "Banks.findByName", query = "SELECT b FROM Banks b WHERE b.name = :name"),
    @NamedQuery(name = "Banks.findByNameandId", query = "SELECT b FROM Banks b WHERE b.name = :name  AND b.id=:id"),
    @NamedQuery(name = "Banks.findByDescription", query = "SELECT b FROM Banks b WHERE b.description = :description"),
    @NamedQuery(name = "Banks.findByCode", query = "SELECT b FROM Banks b WHERE b.code = :code"),
    @NamedQuery(name = "Banks.findActiveBank", query = "SELECT b FROM Banks b WHERE b.status = 1"),
    @NamedQuery(name = "Banks.findByCreateDate", query = "SELECT b FROM Banks b WHERE b.createDate = :createDate")})
public class Banks implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;   
    @Column(name = "code")
    private String code;
    @Column(name = "createDate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createDate;
    @Column(name = "description")
    private String description;
    @Basic(optional = false)
    @Column(name = "name")
    private String name;
    @ManyToOne
    @JoinColumn(name="addressId", referencedColumnName="id")
    private Address addressId;
	@Column(name = "altMobileNo")
    private String altMobileNo;
    @Column(name = "emailId")
    private String emailId;
    @Column(name = "country")
    private String country;
    @Column(name = "state")
    private String state;
    @Column(name = "landMark")
    private String landMark;
    

	@Column(name = "houseNo_Street")
    private String houseNoStreet;
    @Column(name = "city")
    private String city;
    @Column(name = "pincode")
    private Integer pincode;
    @Column(name="mobileNumber")
    private String mobileNumber;
    @Column(name = "locality")
    private String locality;
    @Column(name = "district") 
	private String district;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "bankId")
    private Collection<BankBranches> bankBranchesCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "bankId")
    private Collection<PartnerBankMapping> partnerBankMappingCollection;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "bankId")
    private Collection<CardDetails> cards;
    
    @Column(name = "firstname")
    private String fisrtname;
    @Column(name = "lastname")
    private String lastname;
    
    @Column(name = "status")
    private int status;
    
    public Banks() {
    	//empty
    }

    public Banks(Integer id) {
        this.id = id;
    }

    public Banks(Integer id, String name) {
        this.id = id;
        this.name = name;
    }

    
    public Address getAddressId() {
		return addressId;
	}
	public void setAddressId(Address addressId) {
		this.addressId = addressId;
	}
	public String getLocality() {
		return locality;
	}

	public void setLocality(String locality) {
		this.locality = locality;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}
	public String getLandMark() {
		return landMark;
	}

	public void setLandMark(String landMark) {
		this.landMark = landMark;
	}
	
    public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getAltMobileNo() {
		return altMobileNo;
	}

	public void setAltMobileNo(String altMobileNo) {
		this.altMobileNo = altMobileNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

   

	public String getHouseNoStreet() {
		return houseNoStreet;
	}

	public void setHouseNoStreet(String houseNoStreet) {
		this.houseNoStreet = houseNoStreet;
	}
	
	 

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public Integer getPincode() {
		return pincode;
	}

	public void setPincode(Integer pincode) {
		this.pincode = pincode;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	
   

   

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

   
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    @XmlTransient
    public Collection<BankBranches> getBankBranchesCollection() {
        return bankBranchesCollection;
    }

    public void setBankBranchesCollection(Collection<BankBranches> bankBranchesCollection) {
        this.bankBranchesCollection = bankBranchesCollection;
    }

    @XmlTransient
    public Collection<PartnerBankMapping> getPartnerBankMappingCollection() {
        return partnerBankMappingCollection;
    }

    public void setPartnerBankMappingCollection(Collection<PartnerBankMapping> partnerBankMappingCollection) {
        this.partnerBankMappingCollection = partnerBankMappingCollection;
    }

    public Collection<CardDetails> getCards() {
		return cards;
	}

	public void setCards(Collection<CardDetails> cards) {
		this.cards = cards;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	@Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
    	boolean checkStaus= true;
    	if(object!=null){
        if (!(object instanceof Banks)) {
        	checkStaus= false;
        }
        Banks other = (Banks) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	checkStaus= false;
        }
    	}
        return checkStaus;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.Banks[ id=" + id + " ]";
    }

	public String getFisrtname() {
		return fisrtname;
	}

	public void setFisrtname(String fisrtname) {
		this.fisrtname = fisrtname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
    
}
