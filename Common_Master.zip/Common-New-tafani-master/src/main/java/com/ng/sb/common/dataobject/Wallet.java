package com.ng.sb.common.dataobject;

/**
 * @author gaurav
 *
 */
public class Wallet extends BaseObjectData {

	

	private static final long serialVersionUID = 1L;
	private String msisdn;
	private Integer walletCode;
	private Integer walletPin;
	private Integer oldWalletPin;
	private String accountId;
	private String telcoTransationId;
	private String sPin;
	private String merchantId;
	private Integer amount;
	
	public String getTelcoTransationId() {
		return telcoTransationId;
	}

	public void setTelcoTransationId(String telcoTransationId) {
		this.telcoTransationId = telcoTransationId;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getMsisdn() {
		return msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	public Integer getWalletCode() {
		return walletCode;
	}  

	public void setWalletCode(Integer walletCode) {
		this.walletCode = walletCode;
	}

	public Integer getWalletPin() {
		return walletPin;
	}

	public void setWalletPin(Integer walletPin) {
		this.walletPin = walletPin;
	}

	public String getsPin() {
		return sPin;
	}

	public void setsPin(String sPin) {
		this.sPin = sPin;
	}

	public Integer getOldWalletPin() {
		return oldWalletPin;
	}

	public void setOldWalletPin(Integer oldWalletPin) {
		this.oldWalletPin = oldWalletPin;
	}

	public String getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

	public Integer getAmount() {
		return amount;
	}

	public void setAmount(Integer amount) {
		this.amount = amount;
	}

	

}
