package com.ng.bridge.dataobject.eko;

import java.util.List;

public class AccountTransactionData {

	private String errorMessage;
	private String successMessage;
	private List<String> messageList;
	public enum EListOrString{
		L,
		S
	}
	private EListOrString listOrString;
	private boolean isSuccess;
	
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public String getSuccessMessage() {
		return successMessage;
	}
	public void setSuccessMessage(String successMessage) {
		this.successMessage = successMessage;
	}
	public List<String> getMessageList() {
		return messageList;
	}
	public void setMessageList(List<String> messageList) {
		this.messageList = messageList;
	}
	public boolean isSuccess() {
		return isSuccess;
	}
	public EListOrString getListOrString() {
		return listOrString;
	}
	public void setListOrString(EListOrString listOrString) {
		this.listOrString = listOrString;
	}
	public void setSuccess(boolean isSuccess) {
		this.isSuccess = isSuccess;
	}
	
}
