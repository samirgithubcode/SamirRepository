/**
 * 
 */
package com.ng.transaction.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ng.bridge.service.IPartnerManagementService;
import com.ng.sb.common.dataobject.BridgeDataObject;
import com.ng.sb.common.exception.BridgeObjectDataException;
import com.ng.sb.common.util.SystemConstant;
import com.ng.transaction.service.INonFundTransferBankingService;

/**
 * @author gaurav
 *
 */
@Service(value=SystemConstant.NON_BANKING_SERVICE)
public class NonFundTransferBankingService extends TransactionService implements INonFundTransferBankingService {

	private static final Logger LOGGER = LoggerFactory.getLogger(NonFundTransferBankingService.class);
	
	@Autowired
	IPartnerManagementService partnerManagementService;
	
	
	/* (non-Javadoc)
	 * @see com.ng.transaction.service.INonBankingService#balanceEnquiry(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject balanceEnquiry(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction NonBankingService -  balanceEnquiry method. ");
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in checkBalance:"+ e);
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ng.transaction.service.INonBankingService#chequeBookRequest(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject chequeBookRequest(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction NonBankingService -  chequeBookRequest method. ");
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in checkBalance:"+ e);
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ng.transaction.service.INonBankingService#chequeStatus(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject chequeStatus(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction NonBankingService -  chequeStatus method. ");
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in checkBalance:"+ e);
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ng.transaction.service.INonBankingService#stopCheque(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject stopCheque(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction NonBankingService -  stopCheque method. ");
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in checkBalance:"+ e);
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see com.ng.transaction.service.INonBankingService#last5Transaction(com.ng.sb.common.dataobject.BridgeDataObject)
	 */
	@Override
	public BridgeDataObject last5Transaction(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction NonBankingService -  last5Transaction method. ");
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in checkBalance:"+ e);
		}
		return null;
	}

}
