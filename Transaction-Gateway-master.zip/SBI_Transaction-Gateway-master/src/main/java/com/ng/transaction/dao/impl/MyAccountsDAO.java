/**
 * 
 */
package com.ng.transaction.dao.impl;

import org.springframework.stereotype.Repository;

import com.ng.sb.common.util.SystemConstant;
import com.ng.transaction.dao.IMyAccountsDAO;

/**
 * @author gaurav
 *
 */
@Repository(value=SystemConstant.MY_ACCOUNTS_DAO)
public class MyAccountsDAO extends SettingsDAO implements IMyAccountsDAO {
	private static final long serialVersionUID = 1L;

}
