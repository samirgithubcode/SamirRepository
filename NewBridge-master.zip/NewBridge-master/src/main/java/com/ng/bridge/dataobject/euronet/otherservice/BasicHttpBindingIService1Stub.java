/**
 * BasicHttpBinding_IService1Stub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ng.bridge.dataobject.euronet.otherservice;

import java.util.Enumeration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class BasicHttpBindingIService1Stub extends org.apache.axis.client.Stub implements com.ng.bridge.dataobject.euronet.otherservice.IService1 {
	private static final Logger LOGGER = LoggerFactory.getLogger(BasicHttpBindingIService1Stub.class);
	private static final String URL="http://tempuri.org/";
	 static org.apache.axis.description.OperationDesc [] operations;
	 public BasicHttpBindingIService1Stub() throws org.apache.axis.AxisFault {
         this(null);
    }

    public BasicHttpBindingIService1Stub(java.net.URL endpointURL, javax.xml.rpc.Service service) {
         this(service);
         super.cachedEndpoint = endpointURL;
    }

    public BasicHttpBindingIService1Stub(javax.xml.rpc.Service service) {
        if (service == null) {
            super.service = new org.apache.axis.client.Service();
        } else {
            super.service = service;
        }
        ((org.apache.axis.client.Service)super.service).setTypeMappingVersion("1.2");
    }


   

    static {
        operations = new org.apache.axis.description.OperationDesc[1];
        initoperationDesc1();
    }

    private static void initoperationDesc1(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("SendEuroVasRequest");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName(URL, "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        oper.setReturnClass(java.lang.String.class);
        oper.setReturnQName(new javax.xml.namespace.QName(URL, "SendEuroVasRequestResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        operations[0] = oper;

    }

   
    protected org.apache.axis.client.Call createCall() throws java.rmi.RemoteException {
        try {
            org.apache.axis.client.Call call = super._createCall();
            if (super.maintainSessionSet) {
                call.setMaintainSession(super.maintainSession);
            }
            if (super.cachedUsername != null) {
                call.setUsername(super.cachedUsername);
            }
            if (super.cachedPassword != null) {
                call.setPassword(super.cachedPassword);
            }
            if (super.cachedEndpoint != null) {
                call.setTargetEndpointAddress(super.cachedEndpoint);
            }
            if (super.cachedTimeout != null) {
                call.setTimeout(super.cachedTimeout);
            }
            if (super.cachedPortName != null) {
                call.setPortName(super.cachedPortName);
            }
            Enumeration keys = super.cachedProperties.keys();
            while (keys.hasMoreElements()) {
                java.lang.String key = (java.lang.String) keys.nextElement();
                call.setProperty(key, super.cachedProperties.get(key));
            }
            return call;
        }
        catch (Exception t) {
            throw new org.apache.axis.AxisFault("Failure trying to get the Call object", t);
        }
    }

    public java.lang.String sendEuroVasRequest(java.lang.String request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call call = createCall();
        call.setOperation(operations[0]);
        call.setUseSOAPAction(true);
        call.setSOAPActionURI("http://tempuri.org/IService1/SendEuroVasRequest");
        call.setEncodingStyle(null);
        call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        call.setOperationName(new javax.xml.namespace.QName(URL, "SendEuroVasRequest"));

        setRequestHeaders(call);
        setAttachments(call);
 try {     
	 java.lang.Object resp = call.invoke(new java.lang.Object[] {request});

        if (resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)resp;
        }
        else {
            extractAttachments(call);
                return (java.lang.String) resp;
            
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
	  LOGGER.debug("exception occured:"+axisFaultException);
  throw axisFaultException;
}
    }

}
