package com.ng.sb.common.dataobject;

public class ProductCategoryData extends BaseObjectData{
		private static final long serialVersionUID = 1L;
		private String newcategoryname;
		private String newbriefdesc;
		private String newfulldesc;
		private Boolean newstatus;
		public String getNewcategoryname() {
			return newcategoryname;
		}
		public void setNewcategoryname(String newcategoryname) {
			this.newcategoryname = newcategoryname;
		}
		public String getNewbriefdesc() {
			return newbriefdesc;
		}
		public void setNewbriefdesc(String newbriefdesc) {
			this.newbriefdesc = newbriefdesc;
		}
		public String getNewfulldesc() {
			return newfulldesc;
		}
		public void setNewfulldesc(String newfulldesc) {
			this.newfulldesc = newfulldesc;
		}
		public Boolean getNewstatus() {
			return newstatus;
		}
		public void setNewstatus(Boolean newstatus) {
			this.newstatus = newstatus;
		}
	
	}
