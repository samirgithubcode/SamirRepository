package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author abhishek
 *
 */
@Entity
@Table(name="mvWallet")
@XmlRootElement
@NamedQueries({
	@NamedQuery(name="MVWalletMapping.findAll", query="SELECT m FROM MVWalletMapping m"),	
	@NamedQuery(name="MVWalletMapping.findByMvId", query="SELECT m FROM MVWalletMapping m WHERE m.mvId=:mvId"),
})
public class MVWalletMapping implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @JoinColumn(name = "mvId", referencedColumnName="id")
    @ManyToOne
    private MasterVersion mvId;
    @JoinColumn(name = "walletId", referencedColumnName="id")
    @ManyToOne
    private Partner walletId;
    
	public MVWalletMapping(){
		//empty
    }
    
    public MVWalletMapping(Integer id){
    	this.id = id;
    }
	    
    public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public MasterVersion getMvId() {
		return mvId;
	}

	public void setMvId(MasterVersion mvId) {
		this.mvId = mvId;
	}

	public Partner getWalletId() {
		return walletId;
	}

	public void setWalletId(Partner walletId) {
		this.walletId = walletId;
	}

	@Override
   	public String toString() {
   		return "MVWalletMapping [id=" + id + "]";
   	}
}
