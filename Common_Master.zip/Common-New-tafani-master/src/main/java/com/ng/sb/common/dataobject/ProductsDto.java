package com.ng.sb.common.dataobject;

public class ProductsDto extends CustomerInfo {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private  String externalNumber;

	
	private String remark;
	private Integer bankId;

	/**
	 * @param externalNumber the externalNumber to set
	 */
	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Integer getBankId() {
		return bankId;
	}

	public void setBankId(Integer bankId) {
		this.bankId = bankId;
	}

	/**
	 * @return the externalNumber
	 */
	public String getExternalNumber() {
		return externalNumber;
	}
	public void setExternalNumber(String externalNumber) {
		this.externalNumber = externalNumber;
	}

}
