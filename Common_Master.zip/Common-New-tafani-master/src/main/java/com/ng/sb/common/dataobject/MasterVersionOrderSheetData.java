package com.ng.sb.common.dataobject;

import java.util.List;

public class MasterVersionOrderSheetData {

	private List<MasterVersionData> masterVersiondata;
	
	private Integer masterVersionId;
	

	
	public Integer getMasterVersionId() {
		return masterVersionId;
	}

	public void setMasterVersionId(Integer masterVersionId) {
		this.masterVersionId = masterVersionId;
	}

	public List<MasterVersionData> getMasterVersiondata() {
		return masterVersiondata;
	}

	public void setMasterVersiondata(List<MasterVersionData> masterVersiondata) {
		this.masterVersiondata = masterVersiondata;
	}
	
	
	
	
}
