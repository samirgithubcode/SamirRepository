/**
 * 
 */
package com.ng.transaction.service;

import com.ng.sb.common.dataobject.BridgeDataObject;

/**
 * @author gaurav
 *
 */
public interface IWalletService extends IBankingService {

	public BridgeDataObject fundTransferWalletToWallet(BridgeDataObject bridgeDataObject);
	public BridgeDataObject fundTransferWalletToBank(BridgeDataObject bridgeDataObject);
	public BridgeDataObject fundTransferWalletToIMPS(BridgeDataObject bridgeDataObject);
	public BridgeDataObject fundTransferWalletToCC(BridgeDataObject bridgeDataObject);
	
	public BridgeDataObject walletCheckBalance(BridgeDataObject bridgeDataObject);
	
}
