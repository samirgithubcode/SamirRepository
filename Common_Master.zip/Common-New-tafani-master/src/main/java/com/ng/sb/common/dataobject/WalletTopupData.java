package com.ng.sb.common.dataobject;

import java.util.Map;

/**
 * @author abhishek
 *
 */
	public class WalletTopupData extends BaseObjectData{

	private static final long serialVersionUID = 1L;
	private String type;	
	private String contactNumber;
	private String customerName;
	private String houseNo;
	private String city;
	private String landMark;
	private String countryId;
	private String stateId;
	private String pinCode;
	private String walletName;
	private Integer cashBalance;
	private String rechargeAmount;
	private Map<Integer,WalletTopupData> walletData;
	private Map<Integer,String> countryMap;
	private Map<Integer,String> stateMap;
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}	
	public Map<Integer, String> getCountryMap() {
		return countryMap;
	}
	public void setCountryMap(Map<Integer, String> countryMap) {
		this.countryMap = countryMap;
	}
	public Map<Integer, String> getStateMap() {
		return stateMap;
	}
	public void setStateMap(Map<Integer, String> stateMap) {
		this.stateMap = stateMap;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getRechargeAmount() {
		return rechargeAmount;
	}
	public void setRechargeAmount(String rechargeAmount) {
		this.rechargeAmount = rechargeAmount;
	}
	public String getWalletName() {
		return walletName;
	}
	public void setWalletName(String walletName) {
		this.walletName = walletName;
	}
	public Integer getCashBalance() {
		return cashBalance;
	}
	public void setCashBalance(Integer cashBalance) {
		this.cashBalance = cashBalance;
	}
	public Map<Integer, WalletTopupData> getWalletData() {
		return walletData;
	}
	public void setWalletData(Map<Integer, WalletTopupData> walletData) {
		this.walletData = walletData;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getHouseNo() {
		return houseNo;
	}
	public void setHouseNo(String houseNo) {
		this.houseNo = houseNo;
	}
	public String getLandMark() {
		return landMark;
	}
	public void setLandMark(String landMark) {
		this.landMark = landMark;
	}
	public String getCountryId() {
		return countryId;
	}
	public void setCountryId(String countryId) {
		this.countryId = countryId;
	}
	public String getStateId() {
		return stateId;
	}
	public void setStateId(String stateId) {
		this.stateId = stateId;
	}
	public String getPinCode() {
		return pinCode;
	}
	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}
	
}
