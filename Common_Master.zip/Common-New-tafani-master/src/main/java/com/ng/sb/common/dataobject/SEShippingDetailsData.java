package com.ng.sb.common.dataobject;

import java.util.Date;

/**
 * @author rajiv
 *
 */

public class SEShippingDetailsData {

	private String orderNumber;
	private Integer pendingItems;
	private Date shippingDate;
	
	public String getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public Integer getPendingItems() {
		return pendingItems;
	}

	public void setPendingItems(Integer pendingItems) {
		this.pendingItems = pendingItems;
	}

	public Date getShippingDate() {
		return shippingDate;
	}

	public void setShippingDate(Date shippingDate) {
		this.shippingDate = shippingDate;
	}

	
	
	
}
