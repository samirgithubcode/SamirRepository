function removeError(){
	
	$("#statusMessage").html("");
	 $("#showMessage").hide();
}

function validateForgetPass(formId){
	 var check = true;
		
	 		var	mobile = $('#mobile').val();
			var username = $('#mobile').val();	
			var dob = $('#dateOfBirth').val();
			
			var otp = $('#otpOnForgotPass').val().trim();
			
			var newPassword=$('#newPassword').val().trim();
			var cnfPassword = $('#cnfPassword').val();
			
			
			if(username.length == 0)
			{
				$('#div_mobile').addClass("has-error");
				return false;
			}
			if(dob.length == 0)
			{
				$('#div_dateOfBirth').addClass("has-error");
				return false;
			}
			if(otp.length == 0)
			{
				$('#div_otp').addClass("has-error");
				return false;
			}
			if(newPassword.length == 0)
			{
				$('#div_newPassword').addClass("has-error");
				return false;
			}
			
			if(cnfPassword.length == 0)
			{
				$('#div_cnfPassword').addClass("has-error");
				return false;
			}
			if(cnfPassword.length> 0){
				if(newPassword!=cnfPassword)
				
				{
					 $('#newPassword').val("");
					 $('#cnfPassword').val("");
					$('#label_newPassword').hide();
					$('#newPassword_ErrorId').show();
					$('#newPassword_ErrorId').html("<b><font color='red'>Passwords does not Match !</font></b>");
					
					return false;
				}
				
			}
			
			var ajaxResponse = ajaxCall1(mobile, newPassword, otp);
			
				return false;
			
			
			
			
}

function ajaxCall1(mobile,newPassword,otp ){
	var responseObj = 0;
	var requestData = {
			
			"mobilenumber":mobile,
			"newPassword":newPassword,
			"otpOnForgotPass":otp
	};
	console.log(requestData);
	/*requestData.mobilenumber=mobile;
	requestData.newPassword=newPassword;
	requestData.otpOnForgotPass=otp;*/
	$.ajax({
		url :"ajax/verifyAndUpdateWalletPin",
		type :"POST",
		async:false,
		headers: { 
	        'Accept': 'application/json',
	        'Content-Type': 'application/json' 
	    },
		dataType:"json",
		data :JSON.stringify(requestData),
		success:function(response){
	
			
			$("#statusMessage1").html(response.message);
			$("#statusMessage").empty();
			$('#otpOnForgotPass').val('');
			$('#newPassword').val('');
			$('#cnfPassword').val('');
		},
		error : function(error) {
			responseObj = 0;
		}
			
		});
	return responseObj;
}

function ajaxCall(mobile,newPassword,otp ){
	var responseObj = 0;
	
	$.ajax({
		url :"forgetPassword1",
		type :"POST",
		async:false,
		dataType:"json",
		data :"mobile="+mobile+"&newPassword="+newPassword+"&otpOnForgotPass="+otp,
		success:function(response){
	
			if(response==1){
				
				event.preventDefault;
				responseObj = 1;
			}
			if(response==0){
				responseObj = 0;
			}
		},
		error : function(error) {
			responseObj = 0;
		}
			
		});
	return responseObj;
}

function resetWalletPin(event){
	
	
	var check=true;
	var	mobile = $('#mobile').val();
	var	dateOfBirth = $('#dateOfBirth').val();
	
	if(mobile.length==0)
	{
		$('#div_mobile').addClass('has-error');
		
		check= false;
	}
	
	if(dateOfBirth.length==0)
	{	
		$('#div_dateOfBirth').addClass('has-error');
		
		check= false;
	}
	
	else if(mobile.length!=0 && dateOfBirth.length!=0)
		{ 
		
		$('#myModal').modal('show'); 



		
	
	}
 return check;
}


function getOtpOnForgotPass(event){
	var check=true;
	var	mobile = $('#mobile').val();
	var	dateOfBirth = $('#dateOfBirth').val();
	$.ajax({
	url :"getOtpOnForgotPass",
	type :"POST",
	data :"mobile="+mobile+"&dateOfBirth="+dateOfBirth,
	
	success:function(response){
	     
	     if(response.startsWith("Enter") ){
	    	 alert("not equal to "+response);
	    	 $("#statusMessage").html(response);
	    	  $("#showotp").hide();
		      $("#hideotp").show();
		      $('#dateOfBirth').attr('disabled',true);
		      $("#showMessage").show();
	     	}else {
	    	 alert("equal to "+response);
	    	 $("#statusMessage").html("<font color='red'>"+response+"</font>");
	    	 $("#showMessage").show();
	     	}
	      

		}
 		
	
	});
	 return check;
} 
function resendOtpOnForgotPass(event){
	var	mobile = $('#mobile').val();
	var dateOfBirth =$('#dateOfBirth').val();
	$.ajax({
		url :"resendOtpOnForgotPass",
		type :"GET",
		data :{
			"mobile" : mobile,
			"dateOfBirth":dateOfBirth
		},
		 
		success:function(response){
		    //  alert(response);


		      $("#showotp").attr("class","hide");
		      $("#hideotp").attr("class","show");
		      $("#showMessage").attr("class","show");
		      $("#statusMessage").html(response);
		      
		      


     },
     error : function(e) {
     
     }
			
		
	});
	event.preventDefault();
}

function validateEmailDob()
{
	var emailorusername = $('#userNameorEmail').val();	
	var dob = $('#lab_dob').val();
	var check = true;
	if(emailorusername.length<=0)
	{
		$('#lab_userNameorEmailErrorId').html("<b><font color='red'>Kindly Fill UserName / E-mail / Mobile </font></b>");
		check = false;
	}
	if(dob.length<=0)
	{
		$('#lab_dobErrorId').html("<b><font color='red'>Kindly Fill Date Of Birth</font></b>");
		check = false;
	}
	if(check == true)
	{
		$.ajax({
			type : "POST",
			url : "validateEmailDob",
			data : 'emailorusername='+emailorusername+'&dob='+dob,
			success:function(response)
			{
				$.each(response, function (key, val) {
				if(key==1||key==4||key==5)
				{
					$('#userNameorEmail').val('');
					$('#lab_dob').val('');
					$('#lab_userNameorEmailErrorId').html("<b><font color='red'>"+val+"</font></b>");
				}
				if(key==2)
				{
					$('#question').show();
					$('#securityQuestion').val(val);
					$('#userNameorEmail').attr('readonly',true);
				}
				if(key==3)
				{
					$('#userNameorEmail').val('');
					$('#lab_dob').val('');
					$('#lab_userNameorEmailErrorId').html("<b><font color='red'>"+val+"</font></b>");
				}
				});
			}
		});
	}	
}

function validateUser()
{
	var emailorusername = $('#userNameorEmail').val();	
	var dob = $('#lab_dob').val();
	var answer = $('#answer').val();
	var check = true;
	if(answer.length<=0)
	{
		$('#lab_answerErrorId').html("<b><font color='red'>Kindly Fill Answer !</font></b>");
		check = false;
	}
	if(check == true)
	{
		$.ajax({
			type : "POST",
			url  :  "validateEmailDobAns",
			data : 'emailorusername='+emailorusername+'&dob='+dob+'&answer='+answer,
			success:function(response)
			{
				$.each(response, function (key, val) {
					if(key==='accountId')
					{
						$('#accountId').val(val);
						$('#userPassword').attr('readonly',false);
						$('#rePassword').attr('readonly',false);
					}	
					if(key==='invalidLoginCount')
					{
						if(val<2)
						{
							$('#lab_answerErrorId').html("<b><font color='red'>Wrong Answer! Try Again!!</font></b>");
						}
						else if(val==2)
						{
							$('#lab_answerErrorId').html("<b><font color='red'>Its your last Attempt</font></b>");
						}
						else if(val==3)
						{
							$('#lab_answerErrorId').html("<b><font color='red'>Contact Customer Care!! You are Blocked!</font></b>");
						}
						$('#answer').val("");
					}
					if(key==='blockId')
					{
						$('#lab_answerErrorId').html("<b><font color='red'>Contact Customer Care!! You are Blocked!</font></b>");
						$('#answer').val("");
					}
				});
			}
		});
	}
}

function forgetPassOrFTLoginCheck(event,formId)
{
   var check = true;
	
	if(formId=='firstTimeLoginPage'){
		var username = $('#lab_userName').val();	
		var dob = $('#lab_dob').val();
		var sequerityQuestion=$("#securityQuestion").val().trim();
		var answer = $('#securityAnswer').val().trim();
		var currentPassword = $('#currentPassword').val().trim();
		var newPassword=$('#newPassword').val().trim();
		var rePassword = $('#rePassword').val();
		
		
		if(username.length == 0)
		{
			$('#lab_userNameorEmailErrorId').html("<b><font color='red'>User name can not be blank </font></b>");
			check = false;
		}
		if(dob.length == 0)
		{
			$('#lab_dobErrorId').html("<b><font color='red'>DOB can not be blank </font></b>");
			check = false;
		}
		if(sequerityQuestion.length<=0){
			$("#lab_securityQuestionErrorId").html("<b><font color='red'>Security question can not be blank </font></b>");
		   check=false;
		}
		if(answer.length == 0)
		{
			$('#lab_answerErrorId').html("<b><font color='red'>Answer can not be blank </font></b>");
			check = false;
		}
		if(currentPassword.length == 0)
		{
			$('#lab_currentPasswordErrorId').html("<b><font color='red'>User current password can not be blank </font></b>");
			check = false;
		}
		if(newPassword.length == 0)
		{
			$('#lab_passwordErrorId').html("<b><font color='red'>User new password cannot be blank </font></b>");
			check = false;
		}
		
		if(rePassword.length == 0)
		{
			$('#lab_repasswordErrorId').html("<b><font color='red'>Retype new password can not be blank </font></b>");
			check = false;
		}
		if(rePassword.length> 0){
			if(newPassword===rePassword)
			{}
			else
			{
				$('#lab_repasswordErrorId').html("<b><font color='red'>Passwords does not Match !</font></b>");
				 $('#'+newPassword).val("");
				 $('#'+rePassword).val("");
				 check = false;
			}
			
		}
		
		if(!(check))
		{
			event.preventDefault();
			return false;
		}
		else
		{
			$('#'+formId).submit();
		}
		
		
		
	}
	else{
	var emailorusername = $('#userNameorEmail').val();	
	var dob = $('#lab_dob').val();
	var answer = $('#answer').val();
	var rePassword = $('#rePassword').val();
	var userPassword = $('#userPassword').val();
	if(emailorusername.length == 0)
	{
		$('#lab_userNameorEmailErrorId').html("<b><font color='red'>Kindly Fill UserName / E-mail / Mobile </font></b>");
		check = false;
	}
	if(dob.length == 0)
	{
		$('#lab_dobErrorId').html("<b><font color='red'>Kindly Fill Date Of Birth</font></b>");
		check = false;
	}
	if(answer.length == 0)
	{
		$('#lab_answerErrorId').html("<b><font color='red'>Answer Cannot be Blank !</font></b>");
		check = false;
	}
	if(rePassword.length == 0)
	{
		$('#lab_repasswordErrorId').html("<b><font color='red'>Re-Password Cannot be Blank !</font></b>");
		check = false;
	}
	if(userPassword.length == 0)
	{
		$('#lab_passwordErrorId').html("<b><font color='red'>User Password Cannot be Blank !</font></b>");
		check = false;
	}
	if(!(check))
	{
		event.preventDefault();
		return false;
	}
	else
	{
		$('#'+formId).submit();
	}
	}
}

function matchPassword(newPassword,rePassword)
{
	var newPass = $('#'+newPassword).val();
	var rePass = $('#'+rePassword).val();
	if(newPass===rePass)
	{}
	else
	{
		$('#lab_repasswordErrorId').html("<b><font color='red'>Passwords does not Match </font></b>");
		$('#'+newPassword).val("");
		$('#'+rePassword).val("");
	}
}
function dateValidate(datetext)
{
	var currentdate=  moment().format('YYYY-MM-DD');
	if(datetext>currentdate)
		{
		$('#lab_dobErrorId').html("<b><font color='red'>Date Can Not More Than Current Date </font></b>");
		$('#lab_dob').val('');
		}
	
	
	
}
function matchPassword(){
			var check = true;
			var mobile = $('#mobile').val();	
			var dob = $('#dateOfBirth').val();
			var otp=$("#otpOnForgotPass").val().trim();
			var confirmPassword = $('#cnfPassword').val().trim();
			var newPassword=$('#newPassword').val().trim();
			
			
			
			if(mobile.length == 0)
			{
				$('#lab_userNameorEmailErrorId').html("<b><font color='red'>User name can not be blank </font></b>");
				check = false;
			}
			if(dob.length == 0)
			{
				$('#lab_dobErrorId').html("<b><font color='red'>DOB can not be blank </font></b>");
				check = false;
			}
			if(otp.length<=0){
				$("#lab_securityQuestionErrorId").html("<b><font color='red'>Security question can not be blank </font></b>");
			   check=false;
			}
			if(newPassword.length == 0)
			{
				$('#lab_userNameorEmailErrorId').html("<b><font color='red'>User name can not be blank </font></b>");
				check = false;
			}
			if(confirmPassword.length == 0)
			{
				$('#lab_userNameorEmailErrorId').html("<b><font color='red'>User name can not be blank </font></b>");
				check = false;
			}
			if(newPassword!=confirmPassword)
			{
				$('#lab_repasswordErrorId').html("<b><font color='red'>Passwords does not Match </font></b>");
				$('#newPassword').val("");
				$('#confirmPassword').val("");
			}
}

function onlyNumeric(id,errorId,labelid){
	 $('#'+errorId).html('');
	 $('#'+labelid).show();
	var str=$('#'+id).val().trim();
	if(str.length!=0){
	for(var i=0;i<str.length;i++){
		 var asciiValue=str.charCodeAt(i);
		 if((asciiValue >= 97 && asciiValue <= 122)||(asciiValue >= 65 && asciiValue <= 90) ||(asciiValue >= 34 && asciiValue <= 38) || (asciiValue >= 40 && asciiValue <= 46) || asciiValue == 47 || asciiValue == 58 || asciiValue == 32 || asciiValue == 59  ||  asciiValue == 60 ||  asciiValue == 61 || asciiValue == 63 || asciiValue == 39 || asciiValue == 62 ||asciiValue == 64 ||asciiValue == 33 || ( asciiValue >= 91 && asciiValue <= 95 ) || asciiValue==96 || (asciiValue >=123 && asciiValue<=126) ){
			 
			 $('#'+id).val('');
			 $('#'+errorId).html('<font color="red">Only Numeric are allowed</font>');
			 $('#'+labelid).hide();
			 $('#'+errorId).show();
			
				event.preventDefault();
				return false;
		 }
	}
	 
	}
	
	
}

function selectDatepicker(id,errorId,labelid){
	// $('#'+errorId).html('');
	// $('#'+labelid).show();
	
	$("#"+id).val('');
	$("#"+errorId).show();
	/*$("#"+labelid).hide();*/
/*	 $('#'+errorId).html('<font color="red">Please Select Datepicker</font>');*/
}
 function checkMobileLength(){
	 $('#username').val('');
	 if(username.length<12){
		
		$('#mobileDiv').addClass('has-error');
		 $('#mobileErrorId').show();
	      $('#mobileId').hide();
	     $('#mobileErrorId').html("<font color='red'>Mobile Number Should Be 12 Digit</font>");
		check=false;
	} 
 }
