package com.ng.bridge.util;

import java.io.FileInputStream;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Utility {
	private static final Logger LOGGER = LoggerFactory.getLogger(Utility.class);
	private Utility(){}
	
	public static String getValue(String key,String fileName){
		String url=null;
		try {
			Properties props = new Properties();
			props.load(new FileInputStream("src/main/resources/"+fileName));
			url=props.getProperty(key);
		} catch (Exception e) {
			LOGGER.info(""+e);
		}
		return url;
	}
}
