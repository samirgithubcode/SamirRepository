function validation(){
	
	var txnCount=$('#txnCount').val();
	var txnType=$('#txnType').val();
	var txnStatus=$('#txnStatus').val();
	var endDate=$('#endDate').val();
	var startDate=$('#startDate').val();
	
	if((txnCount.length==0)&&(txnType.length==0)&&(txnStatus.length==0)&&(endDate.length==0)&&(startDate.length==0)){
		
	
		$('#statusMessage').show();
		$('#statusMessage').html("<font color='red'>Select a field before submit</font>");
		/*event.preventDefault();*/
		 return false;
		 
	}
	
	/*if(((txnCount.length!=0)||(txnType.length!=0)||(txnStatus.length!=0))&&(endDate.length!=0)||(startDate.length==0)){
		$('#DIV_startDate').addClass("has-error");
		$('#DIV_endDate').addClass("has-error");
		$('#statusMessage').show();
		$('#statusMessage').html("Choose both start date and end date before submit");
		 return false;
		 event.preventDefault();
	}*/
	
	if((endDate.length!=0)&&(startDate.length!=0))
		{
		
		var formatedEndDate = endDate.split("-");
		var endDateObj = new Date(formatedEndDate[2], formatedEndDate[1] - 1, formatedEndDate[0]);
		
		var formatedstartDate = startDate.split("-");
		var startDateObj = new Date(formatedstartDate[2], formatedstartDate[1] - 1, formatedstartDate[0]);
		
		if(endDateObj.getTime()<startDateObj.getTime()){
			
			
			$('#DIV_startDate').addClass("has-error");
			$('#DIV_endDate').addClass("has-error");
			$('#statusMessage').show();
			$('#statusMessage').html("<font color='red'>From date should less than To date</font>");
			 event.preventDefault();
			 return false;
			
		}
	}
	if(((endDate.length!=0)&&(startDate.length==0))||((endDate.length==0)&&(startDate.length!=0)))
	{
		/*$('#'+formIdAddress).submit();*/
		$('#DIV_startDate').addClass("has-error");
		$('#DIV_endDate').addClass("has-error");
		event.preventDefault();
		return false;
	
	}
	return true;
	
}
function clearMessage(){

	$('#statusMessage').show();
	$('#statusMessage').html("");
}

function submitPersonalInfoForm(event,formId){
	
	var check=true;
	var name=$('#name').val();
	var lastName=$('#lastName').val();
	var dob=$('#dob').val();
	var emailId=$('#emailId').val();
	if(name.length==0){
		$('#firstnameDiv').addClass('has-error');
		check=false;
	}
	/*if(lastName.length==0){
		$('#lastNameDiv').addClass('has-error');
		check=false;
	}*/
	
	if(dob.length==0){
		 $('#DIV_dob').addClass('has-error');
	    check = false;
	}else{
		
		var date=new Date();
		var validdob=date.getFullYear()-18;
		var year=eval(dob.substr(dob.length-4));
		
	if(year>validdob){
		
		$('#dobId').hide();
		 $('#dobIdErrorId').show();
		 $('#DIV_dob').addClass('has-error');
		 $('#dobIdErrorId').html("<font color='red'>Subscriber Age should be greater than 18</font>");
		 $('#dob').val('');
		 check = false;
		
		
	}
	}
	
	
	
	
	if(emailId.length==0){
		$('#emailDiv').addClass('has-error');
	}
	if(emailId.length!=0){
		var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
	    if (emailReg.test(emailId)) {
	    	$('#lab_emailError').html("");
	    }
	    else {
	    	$('#lab_email').hide()
			$('#lab_emailError').html("<b><font color='red'>Kindly enter valid Email Id</font></b>");
			check=false;
			event.preventDefault();

		}
		
		
	}
	if(check==true){
	$('#'+formId).submit();
	 return true;
	}else{
		return false;
	}
}


function submitAddressForm(event,formIdAddress,deploymenttype){
	var completeCheck=true;
	
	if($('#pinCode').val().length==0)
	{
		$("#div_pinCode").addClass('has-error');
		completeCheck =false;

	}
	if ($('#region').val().length==0)
	{
		$("#div_region").addClass('has-error');
		completeCheck=false;
	}
	if($('#locality').val().length==0)
	{
		$("#div_locality").addClass('has-error');
		completeCheck =false;

	}
	
	
	if($('#state').val().length==0)
	{
		$("#div_state").addClass('has-error');
		completeCheck =false;

	}
	if($('#country').val().length==0)
	{
		$("#div_country").addClass('has-error');
		completeCheck =false;

	}
	
	
	
	
	//if(deploymenttype==="TAFANI"){
		/*if(country.length<=0){
			 $('#countrydivId').addClass('has-error');
			 return false;
		}
		if(state.length<=0){
			$('#statedivId').addClass('has-error');
			return false;
		}*/
	//}
	
	if(completeCheck !=false)
		{
		$('#'+formIdAddress).submit();
		return true;
		
		}
	else
		{
		 event.preventDefault();
		}
	/*if((address.length==0)||(state.length==0)||(country.lenght==0)){
		 $('#div_address').addClass('has-error');
		 $('#div_state').addClass('has-error');
		 $('#div_country').addClass('has-error');
		 event.preventDefault();
		 return false;
		
	}
	else{
		alert("gghj")
		$('#'+formIdAddress).submit();
		return true;
	}*/

}

function checkPassword(){

	var userPassword = $("#currentPassword").val();
var check = function(){	
var completeCheck=true;
$.ajax({
	async: false,
	url: 'checkPassword1',
	type:'POST',
	data:'userPassword='+userPassword,
	success:function(response)
	{
		
		if(response=="0")
		{
			$('#lab_currentPasswordErrorId').html("");
			
			completeCheck = true;
		}else
		{
			$('#oldPswd').hide();
			$('#oldErrorId').show();
			$('#oldErrorId').html("<font color='red'>Current Password does not match</font>");
			$('#currentPassword').val('');
			completeCheck = false;
		}
	},
	  error: function(e) {
										
			  }
});
return completeCheck;
}();

return check;
}

function submitChangePasswordForm(event,formIdchangePassword){
	
	var check=true;
	var	currentPassword=$('#currentPassword').val().trim();
	
	var	newPassword=$('#newPassword').val().trim();
	if(currentPassword.length>0 && newPassword.length>0){
	if(currentPassword==newPassword){
		$('#newPasswdErrorId').html("<font color='red'>New Password is same as Current Password.</font>");
		$('#newPasswdErrorId').show();
		$('#newPassword').val('');
		check = false;
	}
	}
	var cnfPassword=$('#cnfPassword').val().trim();
	if(currentPassword.length==0){
		 $('#oldDiv').addClass('has-error');
	    check = false;
	}
	
	if(newPassword.length==0){
		 $('#newPasswordDiv').addClass('has-error');
	    check = false;
	}else if(newPassword.length<6){
		$('#newPasswdErrorId').html("<font color='red'>Password should be atleast 6 digits long</font>");
		$('#newPasswdErrorId').show();
		$('#newPassword').val('');
		check = false;
	}

	if(cnfPassword.length==0){
		 $('#cnfPasswordDiv').addClass('has-error');
	    check = false;
	}else if(newPassword.length!=cnfPassword.length){
		
		$('#newPasswdErrorId').html("<font color='red'>Password does not match</font>");
		$('#newPasswdErrorId').show();
		$('#newPassword').val('');
		$('#cnfPassword').val('');
		check = false;
	}
	if(check==false){
		event.preventDefault();
		return check;
	}
	
	
	
	if(check==true)
	{
	$('#'+formIdchangePassword).submit();
	 return true;
	}
	
}


function submitChangeWalletPinForm(event,formIdchangePassword)
{
	
	var check=true;
	var	currentPassword=$('#currentWalletPin').val().trim();
	
	var	newPassword=$('#newWalletPin').val().trim();
	if(currentPassword.length>0 && newPassword.length>0){
	if(currentPassword==newPassword){
		$('#newPasswdErrorId').html("<font color='red'>New Wallet PIN is same as Current Wallet PIN.</font>");
		$('#newPasswdErrorId').show();
		$('#newWalletPin').val('');
		check = false;
	}
	}
	var cnfPassword=$('#cnfWalletPin').val().trim();
	if(currentPassword.length==0){
		 $('#oldDiv').addClass('has-error');
	    check = false;
	}
	
	if(newPassword.length==0){
		 $('#newPasswordDiv').addClass('has-error');
	    check = false;
	}else if(newPassword.length<4){
		$('#newPasswdErrorId').html("<font color='red'>Wallet PIN should be 4 digits long.</font>");
		$('#newPasswdErrorId').show();
		$('#newWalletPin').val('');
		check = false;
	}

	if(cnfPassword.length==0){
		 $('#cnfPasswordDiv').addClass('has-error');
	    check = false;
	}else if(newPassword != cnfPassword ){
		
		$('#newPasswdErrorId').html("<font color='red'>Wallet PIN does not match</font>");
		$('#newPasswdErrorId').show();
		$('#newWalletPin').val('');
		$('#cnfWalletPin').val('');
		check = false;
	}
	if(check==false){
		event.preventDefault();
		return check;
	}
	
	
	
	if(check==true)
	{
	$('#'+formIdchangePassword).submit();
	 return true;
	}
	
}


function getPersonalInfoPage(){
	$('#personalinfo').trigger('click');
	$("#personalinfo").attr("class","tab-pane fade in active");
	$("#address").attr("class","tab-pane");
	$("#changepassword").attr("class","hide");
	$("#upgradeaccount").attr("class","tab-pane");
	$("#statusMessage").hide();
	$("#errorstatusMessage").hide();
	$("#showHidePersonalInfo").attr("class","hide");
    $("#showHidePersonalInfodefault").attr("class","show");
    $("#showHidePersonalInfo1").attr("class","hide");
    $("#showHidePersonalInfodefault1").attr("class","show");
}

/*function getAddressPage(){
	$('#address').trigger('click');
	$("#address").attr("class","tab-pane fade in active");
	$("#personalinfo").attr("class","tab-pane");
	$("#changepassword").attr("class","tab-pane");
	$("#upgradeaccount").attr("class","tab-pane");
	$("#statusMessage").hide();
	$("#errorstatusMessage").hide();
}*/

function getChangePasswordPage(){
	
	
	$("#address").attr("class","hide");
	$('#changepassword').trigger('click');
	$("#changepassword").attr("class","tab-pane fade in active");
	$("#personalinfo").attr("class","tab-pane");
	//$("#address").attr("class","tab-pane");
	$("#upgradeaccount").attr("class","tab-pane");
	$("#statusMessage").hide();
	$("#errorstatusMessage").hide();
}

function getUpgradeAccountPage(){
	$('#upgradeaccount').trigger('click');
	$("#upgradeaccount").attr("class","tab-pane fade in active");
	$("#personalinfo").attr("class","tab-pane");
	$("#address").attr("class","tab-pane");
	$("#changepassword").attr("class","tab-pane");
	$("#statusMessage").hide();
	$("#errorstatusMessage").hide();
}

function editPersonalInfo()
{
	$("#showHidePersonalInfo").attr("class","show");
    $("#showHidePersonalInfodefault").attr("class","hide");
    $("#showHidePersonalInfo1").attr("class","show");
    $("#showHidePersonalInfodefault1").attr("class","hide");
   
    $("#statusMessage").hide();
	$("#errorstatusMessage").hide();
}

function editAddress()
{
	$("#tableRes").attr("class","hide");
	$("#Addressdefault1").attr("class","hide");
	$("#addressPage").attr("class","show");
	$("#Addressdefault").attr("class","show");
	$("#showHideAddress").attr("class","show");
    $("#showHideAddressdefault").attr("class","hide");
    $("#showHideAddress1").attr("class","show");
    $("#showHideAddressdefault1").attr("class","hide");
    $('#address').trigger('click');
    $("#statusMessage").hide();
	$("#errorstatusMessage").hide();
}

function fetchAddress(){
	
	$('#buttonClickErrorId').html("");
	var pinCode = $('#pinCode').val().trim(); 
	if(pinCode.length==0){
		$('#lab_pinCodeErrorId').html("<b><font color='red'>Kindly enter PIN Code.</font></b>");
		$('#lab_pinCodeErrorId').show();
		return false;
	}
	else if((pinCode<=110000)||(pinCode>=855118)){
		$('#pinCode').val("");
		$('#lab_pinCodeErrorId').html("<b><font color='red'>Kindly enter valid PIN Code.</font></b>");
		return false;
	}

	
	if(pinCode.length<6){
		
		$('#lab_pinCodeErrorId').html("<b><font color='red'>PIN Code should be 6 digit long.</font></b>");
		return false;
	}
	else{
	if(pinCode.length>0){ 	
	   $.ajax({
		   url: "fetchAddress",
		   type: "POST",
		   data: "pinCode="+pinCode,
		   success:function(response){
			   var addressData = response;
			   if(addressData.length>0){
			   $('#addressSelectTableId').html("<tr><td align='center' width='100%' colspan='6'><b>Select Address</b></td></tr>");
			   $('#addressSelectTableId').append("<tr><td align='center'><table border='2' width='100%'  cellspacing='1' cellpadding='0' class='tableMain'>");
			   $('#addressSelectTableId').append("<tr><td width='10%'>Select</td><td width='25%'>Location</td><td width='15%'>PIN Code</td><td width='20%'>District</td><td width='15%'>State</td><td width='10%'>Country</td></tr>");
			   for(var i=0;i<addressData.length;i++){
				   $('#addressSelectTableId').append('<tr><td><input type="radio" id="addressSelectionId'+addressData[i].id+'" name="addressSelectionId" value='+addressData[i].id+' onchange="fillAddressDetail(\''+addressData[i].id+'\',\''+addressData[i].location+'\',\''+addressData[i].pincode+'\',\''+addressData[i].district+'\',\''+addressData[i].state+'\',\''+addressData[i].country+'\',\''+addressData[i].region+'\');"/></td><td>'+addressData[i].location+'</td><td>'+addressData[i].pincode+'</td><td>'+addressData[i].district+'</td><td>'+addressData[i].state+'</td><td>'+addressData[i].country+'</td></tr>');
			   }
			   $('#addressSelectTableId').append("</table></td></tr>");
			   $('#addressSelectDivId').dialog({
					width: 550,
					height: 400,
					
					title: '\tSelect Address',
					buttons : {
						"OK" : function (response)
						{
							$(this).dialog("close");
						}/*,
			   "CANCEL" : function(response){
				   $(this).dialog("close");
			   }*/
					}
			   });
			   $("#pinCodeFlag").val("0");
				
				}else{
					
					$('#addressErrorId').html("<font color='red'>Change PinCode to Fetch Address or Fill Address Manually</font>");
					$('#addressSelectTableId').html("");
					$("#pinCodeFlag").val('1');
					$('#pinaddressId').val("");
					$('#locality').attr('readonly', false);
					$('#district').attr('readonly', false);
					$('#region').attr('readonly', false);
					$('#state').attr('readonly', false);
					$('#country').attr('readonly', false);
					
					completeCheck=false;
				}
		   }
	   });	
	   
	}
	}
	}
	


function fillAddressDetail(id,location,pincode,district,state,country,region){
	
	if($('#addressSelectionId'+id).is(':checked')){
		
		$('#address').val(pincode);
		$('#div_address').removeClass("has-error");
		
		$('#pinCode').val(pincode);
		$('#div_pinCode').removeClass("has-error");
		$('#locality').val(location);
		$('#div_locality').removeClass("has-error");
		$('#region').val(region);
		$('#div_region').removeClass("has-error");
		/*$('#city').val(district);
		$('').removeClass("has-error");*/
		$('#state').val(state);
		$('#div_state').removeClass("has-error");
		$('#country').val(country);
		$('#div_country').removeClass("has-error");
		$('#pinaddressId').val(id);
		$('#addressSelectTableId').html("");
		//alert(id);
		
	
	}
}



// Function for backToLoginListPage
function backToLoginListPage(event){

}
function reload(){
	/*alert('hi');
	$('#hostId').find('option:first').attr('selected', 'selected');
*/
}	

//Function for User Edit form validation
function validateUserEditForm(event){
	var completeCheck = true;
	var userName = $.trim($("#userName").val());
	if(userName.length==0){
		
		$('#userNameErrorId').html("<b><font color='red'>Kindly enter person name</font></b>");
		completeCheck = false;
		event.preventDefault();
	}else{
		
		$('#userNameErrorId').html("");
	}
	
	var userEmailId = $.trim($("#userEmailId").val());
	if(userEmailId.length==0){
		$('#userEmailIdErrorId').html("<b><font color='red'>Kindly enter user E-mail id</font></b>");
		completeCheck = false;
		event.preventDefault();
	}else{
		
		$('#userEmailIdErrorId').html("");
		 var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
	    if (emailReg.test(userEmailId)) {
	    	$('#userEmailIdErrorId').html("");
	    }
	    else {
			$('#userEmailIdErrorId').html("<b><font color='red'>Kindly enter valid E-mail id</font></b>");
			completeCheck = false;
			event.preventDefault();
		}
	    
		var orgEmailId=$('#userEmailIdOrg').val();
		if(orgEmailId!=userEmailId){
			$('#emailMsg').val("1");
			if(validateEmail(userEmailId)){
				if(completeCheck){
					//if(!(checkUniqueUserEmailId()))
						//completeCheck=false;
				}
			}else{
				$('#userEmailIdErrorId').html("<b><font color='red'>Kindly enter valid E-mail id</font></b>");
				completeCheck = false;
				event.preventDefault();
			}
			//completeCheck=checkUniqueUserEmailId(event);
		}else{
			$('#userMobileErrorId').html("");
			//alert("Same email id");
		}
	}
	
	//User mobile number		
	var userMobile = $.trim($("#userMobile").val());
	var countryCode = $.trim($("#countryCodeId").val());
	if(userMobile.length==0 || userMobile.length<10){
		
		$('#userMobileErrorId').html("<b><font color='red'>Kindly enter valid mobile number</font></b>");
		completeCheck = false;
		event.preventDefault();
	}else{
		$('#userMobileErrorId').html("");
		var orgMobNo=$('#userMobile').val();
		if(orgMobNo!=userMobile){
			$('#mobileMsg').val("1");
			if(completeCheck){
				if(!(checkUniqueUserMobileNumber()))
					completeCheck=false;
			}
			completeCheck=checkUniqueUserMobileNumber(event);
		}else{
			$('#userMobileErrorId').html("");
		}
		if((countryCode.length==0)&&(userMobile.length!=0)){
			$('#userMobileErrorId').html("<b><font color='red'>Kindly select Country Code.</font></b>");
			flag="false";
			completeCheck = false;
			event.preventDefault();
		}
	}
	
	
	if(!(completeCheck)){
		event.preventDefault();
		return check;
	}
	else{
		return true;
	}
}



//Function for User Creation form validation
function validateUserCreationForm(event){
	var completeCheck = true;
	
	$("#userPassword").prop('required',true);
	
	var userAccountType=$.trim($('#accountTypeId').val());
	         var host=   $("#hostId").val().trim();
	
	if(host.length==0)
			{
		
		/*$('#hostIdErrorId').html("<b><font color='red'>Kindly select Host</font></b>");*/
		completeCheck =false;
		
			}
	
		
	 //$("#userCreateSubmit").attr('value', 'Loading...').prop('disabled', true);
	 if(userAccountType.length==0){
		/*$('#accountTypeErrorId').html("<b><font color='red'>Kindly select role type</font></b>");
		 $('#accountTypeErrorId').show();*/
		completeCheck = false;
	}
//		$('#accountTypeErrorId').html("");
		var hostId = "";
		var distributorId = "";
		var subDistributorId = "";
		var retailerId = "";
		//alert("selectedUserType : "+selectedUserType);
		hostId = $.trim($("#hostId").val());
		if(hostId.length==0){
			/*$('#hostIdErrorId').html("<b><font color='red'>Kindly select Host</font></b>");*/
			completeCheck = false;
		}
		if (userAccountType.indexOf(",HO") >-1) {
			hostId = $.trim($("#hostId").val());
			if(hostId.length==0){
				/*$('#hostIdErrorId').html("<b><font color='red'>Kindly select Host</font></b>");*/
				completeCheck = false;
			}else {
				/*$('#hostIdErrorId').html("");	*/
			}
			/*$('#distributorIdErrorId').html("");
			$('#subDistributorIdErrorId').html("");
			$('#retailerIdErrorId').html("");*/
		}

		if (userAccountType.indexOf(",DI") >-1) {
			hostId = $.trim($("#hostId").val());
			distributorId = $.trim($("#distributorId").val());
			if(hostId.length==0){
				/*$('#hostIdErrorId').html("<b><font color='red'>Kindly select Host</font></b>");*/
				completeCheck = false;
			}else {
				/*$('#hostIdErrorId').html("");	*/
			}

			if(distributorId.length==0){
				/*$('#distributorIdErrorId').html("<b><font color='red'>Kindly select Distributor</font></b>");*/
				completeCheck = false;
			}else{
				/*$('#distributorIdErrorId').html("");*/
			}
			/*$('#subDistributorIdErrorId').html("");
			$('#retailerIdErrorId').html("");*/
		}
		if (userAccountType.indexOf(",SD") >-1) {
			hostId = $.trim($("#hostId").val());
			distributorId = $.trim($("#distributorId").val());
			subDistributorId = $.trim($("#subDistributorId").val());
			if(hostId.length==0){
				/*$('#hostIdErrorId').html("<b><font color='red'>Kindly select Host</font></b>");*/
				completeCheck = false;
			}else {
				/*$('#hostIdErrorId').html("");	*/
			}
			if(distributorId.length==0 && $('#subDistributorId2').is(':visible')){
				$('#distributorIdErrorId').html("<b><font color='red'>Kindly select Distributor</font></b>");
				completeCheck = false;
			}else{
				$('#distributorIdErrorId').html("");
			}
			if(subDistributorId.length==0 && $('#subDistributorId2').is(':visible')){
				$('#subDistributorIdErrorId').html("<b><font color='red'>Kindly select Sub-Distributor</font></b>");
				completeCheck = false;
			}else{
				$('#subDistributorIdErrorId').html("");
			}
			$('#retailerIdErrorId').html("");
		}
		if (userAccountType.indexOf(",RE") >-1) {
			hostId = $.trim($("#hostId").val());
			distributorId = $.trim($("#distributorId").val());
			subDistributorId = $.trim($("#subDistributorId").val());
			retailerId = $.trim($("#retailerId").val());
			if(hostId.length==0){
				$('#hostIdErrorId').html("<b><font color='red'>Kindly select Host</font></b>");
				completeCheck = false;
			}else {
				$('#hostIdErrorId').html("");	
			}
			
			if(distributorId.length==0 && $('#distributorId2').is(':visible')){
				$('#distributorIdErrorId').html("<b><font color='red'>Kindly select Distributor</font></b>");
				completeCheck = false;
			}else{
				$('#distributorIdErrorId').html("");
			}
			
			if(subDistributorId.length==0 && $('#subDistributorId2').is(':visible')){
				$('#subDistributorIdErrorId').html("<b><font color='red'>Kindly select Sub-Distributor</font></b>");
				completeCheck = false;
			}else{
				$('#subDistributorIdErrorId').html("");
			}
			if(retailerId.length==0 && $('#retailerId2').is(':visible')){
				$('#retailerIdErrorId').html("<b><font color='red'>Kindly select Agent</font></b>");
				completeCheck = false;
			}else{
				$('#retailerIdErrorId').html("");
			}
		}
//		alert("completeCheck after : "+completeCheck);
		//Person Name
		var userName = $.trim($("#userName").val());
		if(userName.length==0){
			$('#userNameErrorId').html("<b><font color='red'>Kindly enter person name</font></b>");
			completeCheck = false;
			event.preventDefault();
		}else{
			$('#userNameErrorId').html("");
		}
		
		//User email id
		var userEmailId = $.trim($("#userEmailId").val());
		//alert(userEmailId)
		//alert(userEmailId.length);
		
		if(userEmailId.length==0){
			$('#userEmailIdErrorId').html("<b><font color='red'>Kindly enter Email id</font></b>");
			completeCheck = false;
			event.preventDefault();

		}else{
			var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
		    if (emailReg.test(userEmailId)) {
		    	$('#userEmailIdErrorId').html("");
		    }
		    else {
				$('#userEmailIdErrorId').html("<b><font color='red'>Kindly enter valid Email Id</font></b>");
				completeCheck = false;
				event.preventDefault();

			}
		}
		var userMobile = $.trim($("#userMobile").val());
		var countryCodeId = $.trim($("#countryCodeId").val());
		if(userMobile.length==0 || userMobile.length<10){
			$('#userMobileErrorId').html("<b><font color='red'>Kindly enter mobile number</font></b>");
			completeCheck = false;
			event.preventDefault();

		}else if(userMobile.length<10){
			$('#userMobileErrorId').html("<b><font color='red'>Kindly enter valid mobile number of length 10</font></b>");
			completeCheck = false;
			event.preventDefault();

		}else{
			$('#userMobileErrorId').html("");
		}
		
		
		if((countryCodeId.length==0)&&(userMobile.length!=0)){
			$('#userMobileErrorId').html("<b><font color='red'>Kindly select Country Code.</font></b>");
			flag="false";
			
		}
		
		var userLoginName = $.trim($("#userLoginName").val());
		if(userLoginName.length==0){
			$('#userLoginNameErrorId').html("<b><font color='red'>Kindly enter user login</font></b>");
			completeCheck = false;
		}else{
			$('#userLoginNameErrorId').html("");
		}
		
		var userPassword = $.trim($("#userPassword").val());
		if(userPassword.length==0){
			$('#userPasswordErrorId').html("<b><font color='red'>Kindly enter password</font></b>");
			completeCheck = false;
		}
		else if(userPassword.length<6){
			$('#userPasswordErrorId').html("<b><font color='red'>Password should be atleast 6 digits long</font></b>");
			completeCheck = false;
		}else{
			$('#userPasswordErrorId').html("");
		}
		
		var rPassword = $.trim($("#rPassword").val());
		if(rPassword.length==0){
			$('#rPasswordErrorId').html("<b><font color='red'>Kindly enter confirm password</font></b>");
			completeCheck = false;
		}else{
			$('#rPasswordErrorId').html("");
		}
		
		//alert("completeCheck afetr confirm password check : "+completeCheck);
		if(userPassword!="" && rPassword!=""){
			if(userPassword!=rPassword){
				$('#rPasswordErrorId').html("<b><font color='red'>Password does not match.</font></b>");
				completeCheck = false;
			}
		}
		
		//alert("completeCheck afetr same password check : "+completeCheck); 
		//alert("$(#finalFlag).val()--- : "+$("#finalFlag").val());
		if(completeCheck){
			completeCheck=checkUniqueUserIDEmailIdAndMSISDN();
			//alert("completeCheck : "+completeCheck);
			//if(!checkUniqueUserIDEmailIdAndMSISDN(event)){
			//	completeCheck = false;
			//}
		}
		//alert(" final === $(#finalFlag).val()--- : "+$("#finalFlag").val());
	
	
	//alert("completeCheck afetr final check : "+completeCheck);
	/*alert("$(#finalFlag).val() : "+$("#finalFlag").val());*/
	//var res=$("#finalFlag").val();
	
	if(!(completeCheck)){
		//$("#userCreateSubmit").attr('value', 'Submit').prop('disabled', false);
		//alert("Fail...");
		event.preventDefault();
		return false;
	}
	else
	{
		/*//$('#userLoginCreation').submit();
		if($("#finalFlag").val()==false){
			$("#finalFlag").val("");
			event.preventDefault();
			return false;
		}else{*/
			return true;
		/*}*/
		
	}
}

function clearPageOnChangeRole(loginGroupCode,selectedRoleCode) {
	if ( loginGroupCode == "PP") {
		$('#hostId').val("");
	}

	if ( loginGroupCode == "HO") {
		if (selectedRoleCode != "HO") {
			$('#distributorId').val("");
		}
	}
	
	if (loginGroupCode == "DI") {
		if (selectedRoleCode != "DI") {
			$('#subDistributorId').val("");
		}
	}
	
	if (loginGroupCode == "SD") {
		if (selectedRoleCode != "SD") {
			$('#retailerId').val("");
		}
	}
	
	
}

// Show Hide Drop Down boxs
function showHideFunction() {
	  
	var accountType = $("#accountTypeId").val();
	var groupCode = $("#groupCode").val();
	$("#errorstatusMessage").html("");
	$("#statusMessage").html("");
	$("#userName").val('');
	
	
	if (accountType != "") {
		$('#accountTypeErrorId').html("");
		var msg = accountType.split(",");
		// alert("Msg : "+msg);
		if (msg[1] != "") {
			if (msg[1] == "HO") {
				$('#distributorId2').hide();
				$('#distributorId2').hide();
				$('#distributorIdErrorId').html("");
				$('#subDistributorId2').hide();
				$('#subDistributorId2').hide();
				$('#subDistributorIdErrorId').html("");
				$('#retailerId2').hide();
				$('#retailerId2').hide();
				$('#retailerIdErrorId').html("");
				//$('#hostId').val("");
			}
			if (msg[1] == "DI") {
				$('#subDistributorId2').hide();
				$('#subDistributorId2').hide();
				$('#subDistributorIdErrorId').html("");
				$('#retailerId2').hide();
				$('#retailerId2').hide();
				$('#retailerIdErrorId').html("");

				if (groupCode == "HO") {
					$('#distributorId2').show();
					$('#distributorId2').show();
					$('#distributorId').val("");
				}
				if (groupCode == "PP") {
					$('#distributorId2').hide();
					$('#distributorId2').hide();
					//$('#hostId').val("");
					getAccountListByParentId('hostId', 'distributorId','subDistributorId','retailerId');
				}
			}
			if (msg[1] == "SD") {
				$('#retailerId2').hide();
				$('#retailerId2').hide();
				$('#retailerIdErrorId').html("");

				if (groupCode == "DI") {
					$('#subDistributorId2').show();
					$('#subDistributorId2').show();
					$('#subDistributorId').val("");
				}
				if (groupCode == "HO") {
					$('#subDistributorId2').hide();
					$('#subDistributorId2').hide();
					$('#distributorId2').show();
					$('#distributorId2').show();
					$('#distributorId').val("");
				}
				if (groupCode == "PP") {
					$('#subDistributorId2').hide();
					$('#subDistributorId2').hide();
					$('#distributorId2').hide();
					$('#distributorId2').hide();
				//	$('#hostId').val("");
					getAccountListByParentId('hostId', 'distributorId','subDistributorId','retailerId');
				}
			}
			if (msg[1] == "RE") {
				if (groupCode == "SD") {
					$('#retailerId2').show();
					$('#retailerId2').show();
					$('#retailerId').val("");
				}
				if (groupCode == "DI") {
					$('#retailerId2').hide();
					$('#retailerId2').hide();
					$('#subDistributorId2').show();
					$('#subDistributorId2').show();
					$('#subDistributorId').val("");
				}
				if (groupCode == "HO") {
					$('#retailerId2').hide();
					$('#retailerId2').hide();
					$('#subDistributorId2').hide();
					$('#subDistributorId2').hide();
					$('#distributorId2').show();
					$('#distributorId2').show();
					$('#distributorId').val("");
				}
				if (groupCode == "PP") {
					$('#retailerId2').hide();
					$('#retailerId2').hide();
					$('#subDistributorId2').hide();
					$('#subDistributorId2').hide();
					$('#distributorId2').hide();
					$('#distributorId2').hide();
					//$('#hostId').val("");
					getAccountListByParentId('hostId', 'distributorId','subDistributorId','retailerId');
				}
			}
			//clearPageOnChangeRole(groupCode,msg[1]);

		} else {
			$('#accountTypeErrorId').html("<b><font color='red'>Kindly select account type</font></b>");
			
		}
	}else{
		$('#hostId').val("");
		$('#distributorId').val("");
		$('#distributorId2').hide();
		$('#distributorId2').hide();
		$('#subDistributorId').val("");
		$('#subDistributorId2').hide();
		$('#subDistributorId2').hide();
		$('#retailerId').val("");
		$('#retailerId2').hide();
		$('#retailerId2').hide();
	}
}

// Function for getting all Host List
function getHostList(){
	//alert("Host List");
	$.ajax({
		type: "post",
		url: 'getAllHostList',
		cache: false,
		success: function(response){
			var obj = response;
			if(obj.msg=="1"){
				var hostList = obj.hostMap;
				var select = $('#hostId');
				select.find('option').remove();
				$('<option>').val("").text("<---select--->").appendTo(select);
				$.each(hostList, function( index, value ) {
					var select = $('#hostId');
					$('<option>').val(index).text(value).appendTo(select);
				});
			}
		},	error: function(errorThrown){
		    var select = $('#hostId');
			select.find('option').remove();
			$('<option>').val("").text("<---select--->").appendTo(select);
		}
	});
}



//Function for getting all child List by parent id
function getAccountListByParentId(sourceId, targetId, node1, node2){
	
	//$("#distributorIdErrorId").hide();
	$("#"+sourceId+"ErrorId").show();
	$("#"+targetId+"ErrorId").show();
	$("#"+targetId+"ErrorId").html('');
	$("#"+node1+"ErrorId").hide();
	$("#"+node2+"ErrorId").hide();
//	$("#subDistributorIdErrorId").hide();
//	$("#retailerIdErrorId").hide();
     $("#accountTypeErrorId").hide();	
	$("#userName").val('');
	$("#distributorId").val();
	$("#subDistributorId").val();
	//$("#subDistributorId").val("");
	$("#retailerId").val("");
	$("#subDistributorId2").val();
	if(node1!=null){
		$("#"+node1).val('');
		$("#"+node1+"1").hide();
		$("#"+node1+"2").hide();
	}
	if(node2!=null){
		$("#"+node2).val('');
		$("#"+node2+"1").hide();
		$("#"+node2+"2").hide();
	}
	
	
//var sourceId =$("#sourceId").val();

	
	//alert("sourceId : "+sourceId);
	//alert("targetId : "+targetId);

	var parentId=$("#"+sourceId).val();
	var accountType=$("#accountTypeId").val();
	//alert("Parent ID : "+hostId);
	if (accountType != "") {
		if (parentId != "") {
			$('#' + sourceId + 'ErrorId').html("");
			$.ajax({
				type : "post",
				url : 'getAccountListByParentId',
				cache : false,
				data : {
					parentId : parentId,
					accountType : accountType
				},
				success : function(response) {
					var obj = response;
					var msg = obj.msg;
					if (msg == "1") {
						$('#' + targetId + '1').show();
						$('#' + targetId + '2').show();
						var select = $('#' + targetId);
						select.find('option').remove();
						$('<option>').val("").text("<---select--->").appendTo(select);
						var childAccountList = obj.childAccountListMap;
						$.each(childAccountList, function(index, value) {
							var select = $('#' + targetId);
							$('<option>').val(index).text(value).appendTo(select);
						});
					}/*
						 * else{ var select = $('#'+targetId);
						 * select.find('option').remove(); $('<option>').val("").text("<---select--->").appendTo(select); }
						 */
				},
				error : function(errorThrown) {
					/*
					 * var select = $('#'+targetId);
					 * select.find('option').remove(); $('<option>').val("").text("<---select--->").appendTo(select);
					 */
				}
			});
		} else {
			$('#' + sourceId + 'ErrorId').html(	"<b><font color='red'>Kindly select account </font></b>");
			$('#' + targetId + '1').hide();
			$('#' + targetId + '2').hide();
			$('#'+targetId).val("");
		}
	} else {
		$('#accountTypeErrorId').html("<b><font color='red'>Kindly select account type</font></b>");
	}
}

//Function for Check duplicate userId, emailId and MSISDN
function checkUniqueUserIDEmailIdAndMSISDN(){
	//alert("checkUniqueUserIDEmailIdAndMSISDN Check....");
	var check=true;
	var userEmailId=$("#userEmailId").val();
	var userMobile=$("#userMobile").val();
	var userLogin=$("#userLoginName").val();
	//alert("userEmailId : "+userEmailId);
	//alert("userMobile : "+userMobile);
	//alert("userLogin : "+userLogin);
	$.ajax({
		type: "post",
		url: 'checkUniqueUserIDEmailIdAndMSISDN',
		cache: false,
		data:{userEmailId :userEmailId, userMobile :userMobile, userLogin :userLogin},
		success: function(response){
			//alert(response);
			if(response!=""){
				var objVal = response;
				//alert("objVal.emailMsg : "+objVal.emailMsg);
				if(objVal.emailMsg!=""){
					$("#userEmailId").val("");
					$("#finalFlag").val("false");
					check= false;
					$("#userEmailId").val("");
					//alert("objVal.emailMsg objValaaaaaa : "+objValaaaaaa);
					$('#userEmailIdErrorId').html("<b><font color='red'>"+objVal.emailMsg+"</font></b>");
				}else{
					$("#finalFlag").val("");
					$('#userEmailIdErrorId').html("");
				}
				if(objVal.mobileMsg!=""){
					$("#finalFlag").val("false");
					check= false;
					$("#userMobile").val("");
					//alert("objVal.mobileMsg : "+objVal.mobileMsg);
					$('#userMobileErrorId').html("<b><font color='red'>"+objVal.mobileMsg+"</font></b>");
				}else{
					$("#finalFlag").val("");
					$('#userMobileErrorId').html("");
				}
				if(objVal.userIdMsg!=""){
					$("#finalFlag").val("false");
					check= false;
					$("#userLoginName").val("");
					//alert("objVal.userIdMsg : "+objVal.userIdMsg);
					$('#userLoginNameErrorId').html("<b><font color='red'>"+objVal.userIdMsg+"</font></b>");
				}else{
					$("#finalFlag").val("");
					$('#userLoginNameErrorId').html("");
				}
				//alert("check : "+check);
			}
		},	error: function(errorThrown){ return false;	}
	});
	return check;
}
var check=true;
//Function for Check user email id
function checkUniqueUserEmailId(){
	//alert("email Check....");
	
	var userEmailId=$("#userEmailId").val();
	
	var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
    if (emailReg.test(userEmailId)) {
    	$('#userEmailIdErrorId').html("");
    	
    	$.ajax({
    		type: "post",
    		async:false,
    		url: 'checkUniqueUserEmailId',
    		cache: false,
    		data:{userEmailId :userEmailId},
    		success: function(response){
    			//alert("Email Check R : "+response);
    			if(response!=""){
    				check=false;
    				$("#userEmailId").val('');
    				$("#finalFlag").val('false');
    				$('#userEmailIdErrorId').html("<b><font color='red'>"+response+"</font></b>");
    			}else{
    				$("#finalFlag").val("");
    			}
    		},	error: function(errorThrown){ return false;	}
    	});
    }
    else {
		$('#userEmailIdErrorId').html("<b><font color='red'>Kindly enter valid Email Id</font></b>");
		$("#userEmailId").val("");
		completeCheck = false;
		event.preventDefault();

	}
	
	//alert("userEmailId : "+userEmailId);
	
	//alert("emailid flag : "+flag);
	//alert("emailid Check : "+check);
	return check;
}

//Function for Check user mobile number
var check=true;
function checkUniqueUserMobileNumber(event){
	//alert("check unique mobile function"); 
	var check=true;
	var userMobile=$("#userMobile").val();
	//alert("userMobile : "+userMobile);
	$.ajax({
		type: "post",
		url: 'checkUniqueUserMobileNumber',
		async: false,
		cache: false,
		data:{userMobile :userMobile},
		success: function(response){
			if(response!=""){
				check= false;
				$("#userMobile").val('');
				$("#finalFlag").val('false');
				$('#userMobileErrorId').html("<b><font color='red'>"+response+"</font></b>");
			}else{
				$("#finalFlag").val("");
			}
		},	error: function(errorThrown){ 
		
			
			return false;	}
	});
	return check;
}

//Function for Check user login name
function checkUniqueUserLoginName(){
	var check=true;
	var userLoginName=$("#userLoginName").val();
	$.ajax({
		type: "post",
		url: 'checkUniqueUserLoginName',
		cache: false,
		data:{userLoginName :userLoginName},
		success: function(response){
			if(response!=""){
				check= false;
				$("#userLoginName").val('');
				$("#finalFlag").val('false');
				$('#userLoginNameErrorId').html("<b><font color='red'>"+response+"</font></b>");
			}else{
				$("#finalFlag").val("");
			}
		},	error: function(errorThrown){ return false;	}
	});
	return check;
}


function checkMobileNumberAlreadySignedUp(){
	var check=true;
	var mobileNumber=$("#mobile").val();
	$.ajax({
		type: "post",
		url: 'subscriberExist',
		cache: false,
		data:{mobile :mobileNumber},
		success: function(response){
			if(response == "1"){
				check= false;
				$("#mobile").val('');
				
				$('#mobileDiv').addClass('has-error');
				 $('#mobilenumber').val('');
				 $('#mobileErrorId').show();
			      $('#mobileId').hide();
			     $('#mobileErrorId').html("<font color='red'>You have already Signed-Up.Click to Forget Password link to reset password.</font>");
				
			}else{
				$("#finalFlag").val("");
			}
		},	error: function(errorThrown){ return false;	}
	});
	return check;
}
function validEmail(){
	var userPassword = $.trim($("#userPassword").val());
	if(userPassword.length<6){
		$('#userPasswordErrorId').html("<b><font color='red'>Password should be atleast 6 digits long</font></b>");
		completeCheck = false;
	}else{
		$('#userPasswordErrorId').html("");
	}
	return completeCheck;
}

var radioboxid;
function getRaioTextValue(selectedRadioTdId,divId){

    
	$("#newPassword").val('');
	$("#cnfPassword").val('');
	
	$("#lable_cnfPasswordErrorId").html('');
		$("#lable_emailOrUserIdErrorId").html('');
	$('#newPassword').attr("value", "");
	$('#cnfPassword').attr("value", "");
			$("#lable_emailOrUserIdErrorId").html('');
		 $("#lable_newPasswordErrorId").html("");
		$("#lable_cnfPasswordErrorId").html('');

	$("#emailMobileUserTextboxTable").remove();
	$('#notMatchMessage').html('');
	
	//$('#emailMobileUserTextbox').remove();
	var selectedRadioType=$("#"+selectedRadioTdId).text().trim();
	radioboxid=selectedRadioType;
	
	
	var errorId="'lable_emailOrUserIdErrorId'";
	if(selectedRadioType==='Mobile Number'){
		
		var html='<table id="emailMobileUserTextboxTable" width="60%">'+
        '<tr id="emailMobileUserTextbox">'+
	      '<td id="selectedRadioTypeId" align="right" width="45%"><font color="red">*&nbsp;</font>'+selectedRadioType+'&nbsp;:&nbsp;&nbsp;</td><td width="55%" align="left"><input type="text" id="emailOrUserId" name="'+selectedRadioType+'" maxlength="10" onkeypress="onlyNumric(event,'+errorId+');validatemob();" onclick="emptyerror(event,'+errorId+');" /></td>'+
	      '</tr>'+
	      '<tr><td  width="45%"></td><td width="55%" id="lable_emailOrUserIdErrorId" align="left"></td></tr>'+
	      '</table>';
	}else{
 var html='<table id="emailMobileUserTextboxTable" width="60%">'+
           '<tr id="emailMobileUserTextbox">'+
	      '<td id="selectedRadioTypeId" align="right" width="45%"><font color="red">*&nbsp;</font>'+selectedRadioType+'&nbsp;:&nbsp;&nbsp;</td><td width="55%" align="left"><input type="text" id="emailOrUserId" name="'+selectedRadioType+'" onclick="emptyerror(event,'+errorId+');" onkeypress="validatemob();"/></td>'+
	      '</tr>'+
	      '<tr><td  width="45%"></td><td width="55%" id="lable_emailOrUserIdErrorId" align="left"></td></tr>'+
	      '</table>';
	}
 $(html).appendTo($("#"+divId));
 $("#"+divId).show();
 
 
 
 
 
 $('#resetByErrorId').html("");
// $("#"+selectedRadioTdId).attr('checked', 'checked');
 //$('#emailMobileUserTextbox').remove();
	
}

function validateResetPasswordPage(){

var completeCheck = true;



//********************************* Check Radio Button ************************************************
if(!($('#email').is(":checked")) && (!($('#mobile').is(":checked"))) && (!($('#userName').is(":checked"))))
{
	$('#resetByErrorId').html("");
	$('#resetByErrorId').html("<b><font color='red'>Kindly check atleast one radio button !</font></b>");
	completeCheck = false;
}
else{
	var emailMobileUserId=$("#emailOrUserId").val().trim();
	var selectedRadioType=$("#selectedRadioTypeId").text().trim();
	if(emailMobileUserId.length<=0){
		
		$("#lable_emailOrUserIdErrorId").html('<b><font color=red>Kindly enter  '+selectedRadioType.substring(2,selectedRadioType.length-1)+ '</font></b>');
		 completeCheck = false;
	}
}


var newPassword=$("#newPassword").val();


if(newPassword.length<=0){
	
	 $("#lable_newPasswordErrorId").html("<b><font color='red'>Kindly enter new password</font></b>");
	 completeCheck = false;
 }
var cnfPassword =$("#cnfPassword").val();

if(cnfPassword.length<=0){
	$("#lable_cnfPasswordErrorId").html("<b><font color='red'>Kindly enter confirm password</font></b>");
	completeCheck = false;
}
if(newPassword!==cnfPassword){
	
	$("#lable_cnfPasswordErrorId").html("<b><font color='red'>Password does not match</font></b>");
	completeCheck = false;
}


if(!completeCheck){
	
	return false;
}





}

function validatemob()
{


//var emailId=$("#emailOrUserId").val();
//var emailId=	element.getElementsByTagName("Email").val;
var emailId=$("input[name='Email']").val();
var mobno=$("input[name='Mobile Number']").val();
var user=	$("input[name='UserName']").val();
//var selectedRadioType=$("#"+selectedRadioTdId).text().trim();
//alert(emailId);
//alert(mobno+"mob");
//alert(user+"user");
//alert(radioboxid+"radio");
//var emailId = document.getElementById("emailOrUserId");
if(radioboxid==='Mobile Number')
	{
	$("#emailOrUserId").autocomplete({  
		
	    source : function(request, response) {
	    	
	    	
	  	  $.ajax({
	            url : "userMobileNoUrl",
	            type : "GET",
	            data :'mobno='+mobno, 
	            success : function(data) {
	          	  response($.map(data, function (item) {
	          	        return item.split(",");
	          	    })); 
	            }
	    });
	}
	});
	
	}
if(radioboxid==='user'){
$("#emailOrUserId").autocomplete({  
		
	    source : function(request, response) {
	    	
	    	
	  	  $.ajax({
	            url : "userNameUrl",
	            type : "GET",
	            data :'user='+user, 
	            success : function(data) {
	          	  response($.map(data, function (item) {
	          	        return item.split(",");
	          	    })); 
	            }
	    });
	}
	});	
}
if(radioboxid==='Email')
{
$("#emailOrUserId").autocomplete({  

source : function(request, response) {
	
	
	  $.ajax({
        url : "useremailUrl",
        type : "GET",
        data :'emailId='+emailId, 
        success : function(data) {
      	  response($.map(data, function (item) {
      	        return item.split(",");
      	    })); 
        }
});
}
});
}
	}


function validatemobileData(event,errorId)
{
	var userMobile=$("#userMobile").val().trim();
	
	
	if(userMobile==0 || userMobile<10)
		{
		
		$("#userMobileErrorId").html("<b><font color='red'>Invalid Mobile number</font></b>");
		$("#userMobile").val('');
		}
	else
		{
		$("#userMobileErrorId").html("");
		}
	
	
}
function dateValidate(datetext)
{
}
 

function validRow(){
	var rowCount= $("#numberofrow").val().trim();
	if(rowCount==0){
		$("#validRowErrorId").html("<b><font color='red'>Please enter no of rows</b>");
		return false;
	}
	
}

function validPageNo(){
	  var pages = $('#pages').val();
	var enteredPageNo=$("#goToId").val();
	if(enteredPageNo>pages){
		$("#invalidPageErrorId").html("<b><font color='red'>Please enter valid page no</b>");
		return false;
	}
	
}

function mobileNoValidateCheck(){
	var userMobile=$("#userMobile").val().trim();
	if(userMobile.length<10){
		$('#userMobileErrorId').html("<b><font color='red'>Kindly enter valid mobile number of length 10</font></b>");
		completeCheck = false;
		event.preventDefault();

}}

var radio="";
function radioSelect(selectedRadioTdId)
{
	$("#select_onbehalf").val("");
	$("#validRowErrorId").val("");
	

	//radio=$("#"+selectedRadioTdId).text().trim();
	radio=selectedRadioTdId;
	//alert(radio);
	
}

/*function checkAjax()

{  
    
    	
    	
    			var tagName= $("#select_onbehalf").val();
    		
  	  $.ajax({
            url : "getTags",
            type : "GET",
            data :'personDetails=' + personDetails,
            success : function(data) {
            	if(data.length==0)
        		{
        			$('#onbehalfErrorId').html("<b><font color='red'>Not valid</font></b>");
            		$("input[type=button]").attr("disabled", "disabled");
        		}
        	else {
        			$("#input[type=button]").removeAttr("disabled","disabled");
        		}
            	
          	  response($.map(data, function (item) {
          	        return item.split(",");
          	    })); 
            }
    });

}*/

function getInformation()
{//alert("getinfo");
	
	var personDetails = $("#select_onbehalf").val();
	//alert(personDetails)
	var adminUi = "/AdminUI";
	var contextPath = $("#contextPath").val();
	var controllerPath = contextPath + adminUi
	
	
	$.ajax({
		type: "get",
		url : controllerPath
		+ "/autosearch/getGenericInfo",
		data : 'personDetails=' + personDetails,
		
		success: function(response){
			
			var valuess=response;
			
/*			if(valuess.length>0){
				
				
				for(var i=0;i<valuess.length;i++)
				{

				
				
				// alert(pn)
								
				$('#template_details').append('<tr><td align="center">'+valuess[i].productName+'</td><td align="center">'+valuess[i].productCode+'</td><td align="center">'+valuess[i].mvName+'</td><td align="center">'+valuess[i].mvCode+'</td><td align="center"><a href="'+linkVal+'/AdminUI/inventoryMgmtController/getBoxDetailsInventory?pn='+pn+'&mv='+mv+'"><font color="00000">'+valuess[i].availableStock+'</a></td><td align="center">'+valuess[i].availableUnits+'</td></tr>');
				}
			}
			else{
				$('#DataErrorId').html(	"<b><font color='red'>No Data Found.</font></b>");
			}
		 },
		 error: function(e) {
			
			  }*/
			
			
			
			if ($.isEmptyObject(response)) 
			{
				$('#validRowErrorId').html("<b><font color='red'>There are no information to display.</font></b>");
				//$('#template_details').html('');
			}
			
			
			else
				{
				
				/*alert("Success")*/
				$('#table_id').html("");
				$('#table_id').html('<thead><tr><th>User Name</th><th>Role Type</th><th>User Login</th><th>Email</th><th>Mobile Number</th><th>Host Name</th><th>Company Name</th>Distributor Name</tr><th>Sub-Distributor Name</th><th>Agent Name</th><th>Action</th></tr></thead>');
				$('#table_id').append('<tr><td align="center">'+valuess.userName+'</td><td align="center">'+valuess.accountTypeId+'</td></tr>');
					
					//$("#SearchByTable").show();
					/*$('#table_id').html("");
					$('#table_id').html('<thead><tr class="mainTableHeader"><th>Company Name</th><th>Account Type</th><th>Address</th><th>Phone Number</th><th>E-mail Id</th><th>Host</th><th>Distributor</th><th>Sub-Distributor</th><th>Agent</th><th>Action</th></tr></thead><tbody>');
					$('#table_id').append('<tr><td align="center">'+valuess.companyName+'</td><td align="center">'+valuess.accountType+'</td><td align="center">'+valuess.address+'</td><td align="center">'+valuess.mobileNo+'</td><td align="center">'+valuess.emailId+'</td><td align="center">'+valuess.hostName+'</td><td align="center">'+valuess.distributorName+'</td><td align="center">'+valuess.subDistributorName+'</td><td align="center">'+valuess.retailerName+'</td><td align="center"><a href='+controllerPath+'/account/edit?id='+valuess.id+'><img title="edit" src='+contextPath+'/images/edit.gif style="cursor: hand" align="center"></a></td></tr>');
				*/}		
		}
	});
}


function autosearch() {
	//alert(radio);
	$("#select_onbehalf")
			.autocomplete( 
					{ 
						source : function(request, response) {
							
							var adminUi = "/AdminUI";
							var tagName = $("#select_onbehalf").val();
							
							
							var contextPath = $("#contextPath").val();
							var controllerPath = contextPath + adminUi
							$
									.ajax({
										url : controllerPath
												+ "/autosearch/getGenericTags",
										type : "GET",
										data : 'tagName=' + tagName + '&radio=' + radio,
										success : function(data) {
											//alert(data)
											if (data.length == 0) {
												$('#validRowErrorId')
														.html(
																"<b><font color='red'>Name Does Not Exist</font></b>");
											}
											response($.map(data,
													function(item) {
														return item.split(",");
													}));
										}
									});
						},
						select: function (event, ui) { 
						//	alert("changed");
							//getInfo();
							}
					
					
					});

}

function removeMessage(errorId){
	
	 $('#'+errorId).html('');
}

function onlyNumeric(id,errorId,labelid){
	 $('#'+errorId).html('');
	 $('#'+labelid).show();
	var str=$('#'+id).val().trim();
	if(str.length!=0){
	for(var i=0;i<str.length;i++){
		 var asciiValue=str.charCodeAt(i);
		 if((asciiValue >= 97 && asciiValue <= 122)||(asciiValue >= 65 && asciiValue <= 90) ||(asciiValue >= 34 && asciiValue <= 38) || (asciiValue >= 40 && asciiValue <= 46) || asciiValue == 47 || asciiValue == 58 || asciiValue == 32 || asciiValue == 59  ||  asciiValue == 60 ||  asciiValue == 61 || asciiValue == 63 || asciiValue == 39 || asciiValue == 62 ||asciiValue == 64 ||asciiValue == 33 || ( asciiValue >= 91 && asciiValue <= 95 ) || asciiValue==96 || (asciiValue >=123 && asciiValue<=126) ){
			 
			 $('#'+id).val('');
			 $('#'+errorId).html('<font color="red">Only Numeric are allowed</font>');
			 $('#'+labelid).hide();
			 $('#'+errorId).show();
			
				event.preventDefault();
				return false;
		 }
	}
	 
	}
	
	
}

function validateWalletToWallet(event){
	var check=true;
	var walletType=$('#walletType').val().trim();
	var userMobile=$('#userMobile').val().trim();
	var amount=$('#amount').val().trim();
	var loginMobileNumber=$('#loginMobileNumber').val();
	if(userMobile===loginMobileNumber){
		$("#mobileNoId").hide();
		$("#mobileNoErrorId").show(); 
		 $("#mobileNoErrorId").html('<font color="red" size="2">Enter different Mobile Number</font>');
		$('#mobileNoDiv').addClass('has-error');
		$('#userMobile').val('');
		check=false;	
	}
	if(amount<10){
		$("#txnAmountId").hide();
		$("#txnAmountErrorId").show(); 
		 $("#txnAmountErrorId").html('<font color="red" size="2"> Minimum amount is LYD 10</font>');
		 check = false;
		 $('#amount').val('');
	}
	
	if(walletType.length==0)
{
		$('#label_walletType').removeClass('valid');
		$('#walletTypeDiv').addClass('has-error');
check=false;
		}	
	if(userMobile.length==0){
		$('#mobileNoDiv').addClass('has-error');
	check=false;
	}
if(amount.length==0){
	$('#txnAmountDiv').addClass('has-error');
	check=false;
	}


/*$('#radioValuetErrorId').show();
$('#radioValuetErrorId').html('<font color="red" size="2"> Kindly Select Radio Button.</font>');*/
var result;
//var userMobile1= $('#loginMobileNumber').val().trim();
var walletId=$("#walletType  option:selected").val();
$.ajax({
	type: "post",
	url: "ajax/sendOtpforWallet",

	async:false,
	data: 'senderMobile='+loginMobileNumber+'&userMobile='+userMobile+"&walletId="+walletId,
	success: function(response){
		result=response;
		
	},
	error:function(ex){
	} 
});  		

if(result!="true")
	{
	check=false;
	if(result!="false")
	$('#errorMessage').html("<font color='red'>"+ result+"</font");
	}

if(check==false){
	
	return false;
}
else
	{
	
	var finalcheck=dialoguebox(event);
	return false;
	}



}




function dialoguebox(event)
{
	
	  $('#confirmwalletId').dialog({
		 
			width: 460,
			height: 180,
			title: 'Transaction Confirmation',
			buttons : {
				"OK" : function ()
				{
					
					CallBack(true);
						
					
				},
	   "CANCEL" : function(){
		   
		   CallBack(false);
	   }
			},
	   });
	
}

function CallBack(result) {
	 if(result==false)
		 {
			$('#errorMessage').html("");
		 $("#confirmwalletId").dialog("close");
		 }
	 else {
		$('#errorMessage').empty();
		var otp= $('#ConfirmOtp').val();
		var userMobile= $('#loginMobileNumber').val().trim();
		
		
		
			 $.ajax({
					type: "post",
					url: "ajax/validateWalletOtp",
					dataType: 'json',
					async:false,
					data: 'ConfirmOtp='+otp+"&userMobile="+userMobile,
					success: function(response){
						
						if(response==true){
							
							$('#formid').submit();
						}
						else{
						$('#errorMessage').html("Wrong OTP");
						}
						
					},
					error:function(ex){
						
					} 
				});
	 
}

}

function sendOtp()
{
	
	var userMobile1= $('#loginMobileNumber').val().trim();

	$.ajax({
		type: "post",
		url: "ajax/sendOtpforWallet",
		async:false,
		data: 'userMobile='+userMobile1,
		success: function(response){
			
			
			return response
		},
		error:function(ex){
			
		} 
	});  		
}



function removeError(){
	$('#errorMessage').html('');
	 $('#statusMessage').html('');
}
function selct(id){
	$("#"+id).addClass('valid');	
}
function refresh(){
	$("#walletType").val('');
	$("#userMobile").val('');
	$("#amount").val('');
}
function validateLogin(){
	$('#message').html('');
	var check=true;
	var username=$('#username').val();
	
	var password=$('#password').val()
	if(username.length==0){
		$('#mobileDiv').addClass('has-error');
		check=false;
	}
	
	if(password.length==0){
		$('#passwdDiv').addClass('has-error');
		check=false;
	}
	if(check==true){
	 return true;
	}else{
		return false;
	}
	
	
}

function validateUserForm(event){
	var check=true;
var	mobile=$('#mobile').val().trim();

var emailId=$('#emailId').val().trim();
var	userPassword=$('#userPassword').val().trim();
var	dob=$('#dob').val().trim();
var confirmpassword=$('#confirmPassword').val().trim();
var length=mobile.length;

if(length==10 || length==12)
{
	var table="Subscriber";
	var field="aamsisdn";
	
	$.ajax({
		   url: "checkfieled",
		   type: "GET",
		   dataType:"json",
		   async:false,
		   data: "val="+mobile+'&table='+table+'&field='+field,
		   success:function(response)
		   {
			   if(response == 1)
				{
					  $('#mobileErrorId').show();
				      $('#mobileId').hide();
				     $('#mobileErrorId').html("<font color='red'>Subscriber is already registered.</font>");
				     $("#mobile").val('');
				     event.preventDefault();
					check= false;
				}
			   
			   if(response == 0)
				{
					  $('#mobileErrorId').show();
				      $('#mobileId').hide();
				     $('#mobileErrorId').html("<font color='red'>Invalid Mobile Number.</font>");
				     $("#mobile").val('');
				     event.preventDefault();
					check= false;
				}
			   
				if(response==2)
				{
					
					 $('#mobileErrorId').addClass("valid");
					  $('#mobileErrorId').show();
				     
					  $('#mobileId').hide();
				     $('#mobileErrorId').html("<font color='green'>Subscriber available</font>");
				     check=true;
				}
			   
			   
			   
			   
		   },
		   error:function(e)
		   {
			//   alert(e);
		   }
		  
		   
	
		   });
            	
}
else
{
	 $('#mobileDiv').addClass('has-error');
			 $('#mobilenumber').val('');
			 $('#mobileErrorId').show();
		      $('#mobileId').hide();
		     $('#mobileErrorId').html("<font color='red'>Mobile Number Should Be 10/12 Digit</font>");
			check=false;

}
	
if(emailId.length==0){
	 $('#emailDiv').addClass('has-error');
    check = false;
}else{
	var reg = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
	 if (!reg.test(emailId)){
		 
		 
		 $('#emailID').hide();
		 $('#emailErrorId').show();
		 
		 $('#emailErrorId').html("<font color='red'> Invalid Id</font>");
		 $('#emailId').val('');
		 check = false;
	 }
	
	
}
if(userPassword.length==0){
	 $('#passwordDiv').addClass('has-error');
    check = false;
}else if(userPassword.length<6){
	$('#passwdId').hide();
	 $('#passwordErrorId').show();
	 $('#passwordDiv').addClass('has-error');
	 $('#passwordErrorId').html("<font color='red'>Password should be atleast 6 digits long </font>");
	 $('#userPassword').val('');
	 check = false;
}
else if(userPassword!=confirmpassword)
	{
	$('#cnfpasswdId').hide();
	 $('#cnfpasswordErrorId').show();
	 $('#passwordDiv').addClass('has-error');
	 $('#confirmpaswrdDiv').addClass('has-error');
	 $('#cnfpasswordErrorId').html("<font color='red'>Password should not matched </font>");
	 $('#userPassword').val('');
	 $('#confirmPassword').val('');
	 check = false;
	}
if(dob.length==0){
	 $('#DIV_dob').addClass('has-error');
    check = false;
}else{
	var date=new Date();
	var validdob=date.getFullYear()-18;
	var year=eval(dob.substring(0,4));
if(year>validdob){
	
	$('#dobId').hide();
	 $('#dobIdErrorId').show();
	 $('#DIV_dob').addClass('has-error');
	 $('#dobIdErrorId').html("<font color='red'>Subscriber Age should be greater than 18</font>");
	 $('#dob').val('');
	 check = false;
	
	
}
}

if(check==false){
	event.preventDefault();
	return check;
}
return check;

}

function validateformotp(event){
	var check=true;
	var	name=$('#name').val().trim();

	var otpOnSignUp=$('#otpOnSignUp').val().trim();
	/*var	lastName=$('#lastName').val().trim();*/
	if(otpOnSignUp.length==0){
		 $('#otpDiv').addClass('has-error');
	    check = false;
	}
	if(name.length==0){
		 $('#firstDiv').addClass('has-error');
	    check = false;
	}

	/*if(lastName.length==0){
		 $('#lastNameDiv').addClass('has-error');
	    check = false;
	}*/
	if(check==false){
		event.preventDefault();
		return check;
	}
	return check;
	
	
}
function clear(id){
	$('#'+id).val('');
}
function removeHasError(divId)
{
	
	$("#"+divId).removeClass("has-error");
	
	}
function chcekbox(){
	 var check=true;
	 var box=$('#Deactivatecomment').val().trim();
	 if(box.length==0){
		 $('#dialog').addClass('has-error');
		 check =false;
	 }
	 else{
		 productsInfo();
	 }
return check;
} 
function clearStatus()
{
	$('#statusMessage').html("");
}
function validateQuery(event){
	

	var txnStatus=$('#txnStatus').val();
	var endDate=$('#endDate').val();
	var startDate=$('#startDate').val();
	
	if((endDate.length==0)||(startDate.length==0)){
		$('#statusMessage').show();
	$('#statusMessage').html("<font color='red'>Select date before submit.</font>");
	 event.preventDefault();
	 return false;
	 
	}
	else if(txnStatus==null)
		{
		$('#statusMessage').html("<font color='red'>Select status before submit.</font>");
		 event.preventDefault();
		 return false;
		}else{
	if((endDate.length!=0)&&(startDate.length!=0))
		{
		if((endDate<startDate)){
			
			$('#statusMessage').show();
			$('#statusMessage').html("<font color=red>End date should be greater than start Date</font");
			event.preventDefault();
			return false;
			 
		}
	}
	if((endDate.length!=0)&&(startDate.length==0))
	{
		$('#DIV_startDate').addClass("has-error");
		
		event.preventDefault();
		return false;
	}
	if((endDate.length==0)&&(startDate.length!=0))
	{
		$('#DIV_endDate').addClass("has-error");
		
		event.preventDefault();
		return false;
	}
	}
	
	
}

function selectDatepicker(id,errorId,labelid){
	// $('#'+errorId).html('');
	// $('#'+labelid).show();
	
	$("#"+id).val('');
	$("#"+errorId).show();
	/*$("#"+labelid).hide();*/
	/* $('#'+errorId).html('<font color="red">Please Select Datepicker</font>');*/
}
var instrument;
var id;
function dialoguebx(event,instrumentvalue,idvalue,productId,products)
{
	instrument=instrumentvalue;
	id=idvalue;
	$.ajax({
		type: "post",
		url: "findsubquery",
		dataType: 'json',
		async:false,
		data: 'products='+products,
		success: function(response){
			//var obj=response;
			var obj=response;
			
			var select = $('#subqueryi');
			select.find('option').remove();
			$('<option>').val('').text('').appendTo(select);
			$.each(obj, function( index, value ) {
				$('<option>').val(index).text(value).appendTo(select);
			});
			
			
	
		
			
		},
		error:function(ex){
			
		} 
	});
	
	$("#divId").show();

	
	
}
function hideElement(){
	$('.radioButton').prop('checked', false);
	$("#divId").hide();
}

function saveTransactionIssue()
{
	if(!validation1()){
		return false;
	}
	
	
	$("#btnYes").attr('disabled','disabled');
	
	var remarks=$("#remarks").val();
	var subqueryid=$('#subqueryi').val();
	var checkedArray=[];
var checkbox=$("input[name='checkBox']:checked");

	for(var i=0;i<checkbox.length;i++){
		checkedArray.push(checkbox[i].value);
	}
	var check = function(){	
		var completeCheck=true;
		$.ajax({
			async: false,
			url: 'saveTransactionIssue',
			type:'POST',
			data:'instrument='+instrument + '&id=' + id+ '&remarks=' + remarks+ '&subqueryid=' + subqueryid+ '&sms=' + checkedArray,
			success:function(response)
			{
				var link=$("input[name=link]:hidden").val();
				link=link+"/AdminUI/UserMgmt/getMyQueries?flag="+response;
				
				
				
					window.location.replace(link);
				
				
				$('#remarks').val('');
			},
			  error: function(e) {
					  }
		});
		return completeCheck;
		}();

		return check;
	
}
function validation1(){
 var descrptn=$('#remarks').val();
 var subqueryId=$('#subqueryi').val();
 var check=true;
 if(descrptn.length==0){
	 $('#commentDiv').addClass("has-error");
		check= false;
		 
	}
	if(subqueryId.length==0){
		 $('#subQueryIdDiv').addClass("has-error");
			check=false;
			 
		}
	if(!check){
		event.preventDefault();
	}
 	return check;
}
 
function clearStatusMssg(){
	$('#statusMessage').show();
	$('#statusMessage').html("");

}
function productsInfo(){
	
	//var productId=$(datasublist.id).val();
	var comment=$('#Deactivatecomment').val();
	
$.ajax({
	async: true,
	url: 'productsInfoAjax',
	type:'POST',
	data:'productId='+idd+'&comment='+comment,
	success:function(response)
	{
		
		//var a=response;
		window.location.reload()
		
	},
	  error: function(e) {
										
			  }
});

 event.preventDefault();
 return true;
}

function funActivate(){
	
	$('#productdiv').parent('div').html('<b>Please Contact Customer Care</b> ');
}












var idd;
function deactivationbox(event,productId)
{
	
	idd=productId;
	
	
	$.confirm({
	    title: 'Are You Sure !',
	    content: 'Once the card is De-Activated, can not be acivated again.<br>Do you still wants to proceed ?',
	    buttons: {
	        confirm: function () {
	        	$('#productIdd').val(productId);
	        	$("#dialog").dialog("open");
	        },
	        cancel: function () {
	            
	        }
	    }
	});
	
	
	/*
	
	  $('#commentpopup').dialog({
			width: 250,
			height: 140,
			title: 'Reason for Deactivation',
			buttons : {
				"OK" : function ()
				{
					
					CallBack(true);
						
					
				},
	   "CANCEL" : function(){
		   
		   CallBack(false);
	   }
			},
	   });
	 function CallBack(result) {
         $('#commentpopup').dialog("close");
         if(result==true)
        	 {
        	 $('#productdiv').submit();
        	 }
       
}
 	 
     */}
function removemsg(){
	$("#blanklistMessage").html("");
	$('#addressErrorId').html("");
	$('#errorMessage').html("");
}
	
