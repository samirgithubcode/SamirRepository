package com.ng.sb.common.dataobject;

import java.util.List;

public class ServiceConfigData extends BaseObjectData {


	private static final long serialVersionUID = 1L;
	private String serviceName;
	private String serviceDesc;
	private String serviceDefinition;
	private Integer requiredInputParam;
	private Integer status;
	private Integer parentId;
	private Integer mvCode;
	private Integer mvId;
	private String menuId;
	private String serviceCode;
	private List<ServiceParamsMappingData> paramMappings;
	private List<ServiceConfigData> subServiceList;
	private Integer validationReq;
	private Integer categoryId;
	public ServiceConfigData() {
		//default constructor
	}

	public ServiceConfigData(Integer mvId, String serviceCode) {
		this.serviceCode = serviceCode;
		this.mvId=mvId;

	}
	public Integer getMvId() {
		return mvId;
	}

	public String getMenuId() {
		return menuId;
	}

	public Integer getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(Integer categoryId) {
		this.categoryId = categoryId;
	}

	public void setMenuId(String menuId) {
		this.menuId = menuId;
	}

	public void setMvId(Integer mvId) {
		this.mvId = mvId;
	}

	public List<ServiceConfigData> getSubServiceList() {
		return subServiceList;
	}

	public void setSubServiceList(List<ServiceConfigData> subServiceList) {
		this.subServiceList = subServiceList;
	}

	public List<ServiceParamsMappingData> getParamMappings() {
		return paramMappings;
	}

	public void setParamMappings(List<ServiceParamsMappingData> paramMappings) {
		this.paramMappings = paramMappings;
	}

	public String getServiceCode() {
		return serviceCode;
	}

	public void setServiceCode(String serviceCode) {
		this.serviceCode = serviceCode;
	}

	public Integer getMvCode() {
		return mvCode;
	}

	public void setMvCode(Integer mvCode) {
		this.mvCode = mvCode;
	}



	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getServiceDesc() {
		return serviceDesc;
	}

	public void setServiceDesc(String serviceDesc) {
		this.serviceDesc = serviceDesc;
	}

	public String getServiceDefinition() {
		return serviceDefinition;
	}

	public void setServiceDefinition(String serviceDefinition) {
		this.serviceDefinition = serviceDefinition;
	}

	public Integer getRequiredInputParam() {
		return requiredInputParam;
	}

	public void setRequiredInputParam(Integer requiredInputParam) {
		this.requiredInputParam = requiredInputParam;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Integer getParentId() {
		return parentId;
	}

	public void setParentId(Integer parentId) {
		this.parentId = parentId;
	}

	public Integer getValidationReq() {
		return validationReq;
	}

	public void setValidationReq(Integer validationReq) {
		this.validationReq = validationReq;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		}
		boolean check=false;
		if (obj instanceof ServiceConfigData) 
		{
			ServiceConfigData other = (ServiceConfigData) obj;
			boolean condition3=false;
			boolean condition4=false;
			
			if( this.serviceCode.equalsIgnoreCase(other.getServiceCode()) && this.mvId != null)
			{
				condition3=true;
			}
			if(other.getMvId() != null && this.mvId == other.getMvId()) 
			{
				condition4=true;
			}
			
			if (checkCondition1() && checkCondition2(other)	&& condition3 && condition4) 
			{
				check= true;
			}
			return check;
		}
		return super.equals(obj);
	}
	
	private boolean checkCondition1()
	{
		boolean condition1=false;
		
		if (this.serviceCode != null && !this.serviceCode.isEmpty())
		{
			condition1=true;
		}
		return condition1;
	}

	private boolean checkCondition2(ServiceConfigData other)
	{
		boolean condition2=false;
		
		if (other.getServiceCode() != null && !other.getServiceCode().isEmpty())
		{
			condition2=true;
		}
		return condition2;
	}
	@Override
	public int hashCode() {
		if (this.serviceCode != null
				&& !this.serviceCode.isEmpty() && this.mvId != null) {
			return this.serviceCode.hashCode() * this.mvId * 7;
		} else {
			return 0;
		}

	}

	@Override
	public String toString() {
		return "ServiceConfigData [serviceName=" + serviceName
				+ ", serviceDesc=" + serviceDesc + ", mvCode=" + mvCode
				+ ", mvId=" + mvId + ", menuId=" + menuId + "]";
	}
	
	

}