package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;


/**
 * @author amardeep
 *
 */
@Entity
@Table(name="menu")
@XmlRootElement
@NamedQueries({
		@NamedQuery(name = "Menu.findAllActive", query = "SELECT m FROM Menu m WHERE m.status=1 "),
	  	@NamedQuery(name = "Menu.findById", query = "SELECT m FROM Menu m WHERE m.accountTypeId LIKE :id AND m.isMenu=1 AND m.status=1 ORDER BY m.menuIndex"),
		@NamedQuery(name = "Menu.findbyparentId", query = "SELECT m FROM Menu m WHERE m.parentId=:parent_menu"),
		@NamedQuery(name = "Menu.findAll", query = "SELECT m FROM Menu m"),
		@NamedQuery(name = "Menu.findByMenuId", query = "SELECT m FROM Menu m where m.id=:id"),
		@NamedQuery(name = "Menu.findParentMenu", query = "SELECT m FROM Menu m where m.isMenu=1 AND (m.parentId='' OR m.parentId=null)"),
		@NamedQuery(name = "Menu.findbyMenuName", query = "SELECT m FROM Menu m where m.menuName=:menuName"),
		@NamedQuery(name = "Menu.findParentMenuId", query = "SELECT m FROM Menu m where m.parentId=:id AND m.action=:action AND m.isMenu=1  "),
		
})
public class Menu implements Serializable{

    private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
    @Column(name="id")
    private Integer id;
    @Column(name="menu_name")
    private String menuName;
    @Column(name="menu_desc")
    private String menuDesc;
   	@Column(name="menu_index")
    private Integer menuIndex;
    @Column(name="status")
    private Integer status;
    @Column(name="priority")
    private Integer priority;
    @Column(name="action")
    private String action;
    @Column(name="accountType_id")
    private String accountTypeId;
    @ManyToOne(cascade={CascadeType.ALL}) 
    @NotFound(action = NotFoundAction.IGNORE) 
    @JoinColumn(name="parent_id", insertable=false, updatable= false)	 
    private Menu parentMenu;
    @Column(name="parent_id")
    private String parentId;
    @Column(name="add_time")
    private Date addTime;
    @Column(name="ismenu")
    private Integer isMenu;
    @Column(name="weightage",columnDefinition = "int default 0")
    private Integer weightage=0;
    @Column(name="placement")
    private Integer placement;

	public Menu() {
    	//default constructor
    }   
    public Menu(Integer id) {
        this.id = id;
    }
    public Integer getPriority() {
		return priority;
	}
    public Date getAddTime() {
		return addTime;
	}
	public void setAddTime(Date addTime) {
		this.addTime = addTime;
	}
	public void setPriority(Integer priority) {
		this.priority = priority;
	}
    public Integer getPlacement() {
		return placement;
	}
	public void setPlacement(Integer placement) {
		this.placement = placement;
	}

    public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getMenuName() {
		return menuName;
	}
	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}
	public String getMenuDesc() {
		return menuDesc;
	}
	public void setMenuDesc(String menuDesc) {
		this.menuDesc = menuDesc;
	}
	public Integer getMenuIndex() {
		return menuIndex;
	}
	public void setMenuIndex(Integer menuIndex) {
		this.menuIndex = menuIndex;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getAccountTypeId() {
		return accountTypeId;
	}
	public void setAccountTypeId(String accountTypeId) {
		this.accountTypeId = accountTypeId;
	}
	public Menu getParentMenu() {
		return parentMenu;
	}
	
	public void setParentMenu(Menu parentMenu) {
		this.parentMenu = parentMenu;
	}
	public String getParentId() {
		return parentId;
	}

	public void setParentId(String parentId) {
		this.parentId = parentId;
	}
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof Menu)) {
            return false;
        }
        Menu other = (Menu) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
        
    }

    @Override
    public String toString() {
        return "com.ng.sb.model.Menu[ id=" + id + " ]";
    }
	public Integer getIsMenu() {
		return isMenu;
	}
	public void setIsMenu(Integer isMenu) {
		this.isMenu = isMenu;
	}
	public Integer getWeightage() {
		return weightage;
	}
	public void setWeightage(Integer weightage) {
		this.weightage = weightage;
	}


}
