package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

@Entity
@Table(name = "commission_subscription_distribution")
@NamedQueries({
	@NamedQuery(name="CommissionSubscriptionDistribution.findAll",  query="SELECT csd FROM CommissionSubscriptionDistribution csd order by csd.transactionTime desc "),
	@NamedQuery(name="CommissionSubscriptionDistribution.findAllByDate",  query="SELECT csd FROM CommissionSubscriptionDistribution csd where Date(csd.transactionTime)>=:startDate AND  Date(csd.transactionTime)<=:endDate order by csd.transactionTime desc "),
	@NamedQuery(name="CommissionSubscriptionDistribution.findByTxnId", query="SELECT csd FROM CommissionSubscriptionDistribution csd where csd.transactionId=:txnid"),
	@NamedQuery(name="CommissionSubscriptionDistribution.findById", query="SELECT csd FROM CommissionSubscriptionDistribution csd where csd.id=:id")
})
public class CommissionSubscriptionDistribution implements Serializable{

	private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    
    @JoinColumn(name = "txn_id", referencedColumnName = "id")
    @ManyToOne(fetch=FetchType.LAZY)
    @Fetch(FetchMode.SELECT)
    private ProductTransactions transactionId;
    
    @Column(name = "txn_date")
    @Temporal(TemporalType.TIMESTAMP)
	private Date transactionTime;
    
    @Column(name = "txn_amt")
    private String txnAmount;
    
    @Column(name = "net_txn_amt")
    private String netTxnAmount;
    
    @Column(name = "distribution_amt")
    private String distributionAmount = "0.0";
    
    @Column(name = "distribution_type")
    private String distributionType;
    
    @Column(name = "txn_type")
    private String txnType;
	
    @Column(name = "agent_user_id")
	private Integer agentUserId;
    
	@JoinColumn(name = "agent_id", referencedColumnName = "id")
    @ManyToOne(fetch=FetchType.LAZY)
    @Fetch(FetchMode.SELECT)
    private AccountInfo agentId;
	
	@Column(name = "portal_id")
	private Integer portalId;
	
	@Column(name = "agentportal_amt")
    private String agentAmount = "0.0";
	
	@Column(name = "host_id")
	private Integer hostId;
	
	@Column(name = "host_amt")
    private String hostAmount = "0.0";
	
	@JoinColumn(name = "dist_id", referencedColumnName = "id")
    @ManyToOne(fetch=FetchType.LAZY)
    @Fetch(FetchMode.SELECT)
    private AccountInfo distId;
	
	@Column(name = "dist_amt")
    private String distAmount = "0.0";
	
	@Column(name = "subdist_id")
	private Integer subDistId;
	
	@Column(name = "subdist_amt")
    private String subDistAmount = "0.0";
	
	@Column(name = "bank_id")
	private Integer bankId;
	
	@Column(name = "bank_amt")
    private String bankAmount = "0.0";
	
	@Column(name = "total_amt")
    private String totalCommission = "0.0";
	
	@Column(name = "comm_id")
    private Integer commissionId;
	
	@Column(name = "subs_id")
    private Integer subscriptionId;
	
	@Column(name = "entry_date")
    @Temporal(TemporalType.TIMESTAMP)
	private Date entryDate;
	
	@Column(name = "issettled")
    private int isSettled;
    
	@Column(name = "settled_on")
	@Temporal(TemporalType.TIMESTAMP)
	private Date settledOn;
	
	@Column(name = "isActive")
    private int isActive;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Date getTransactionTime() {
		return transactionTime;
	}

	public void setTransactionTime(Date transactionTime) {
		this.transactionTime = transactionTime;
	}

	public String getTxnAmount() {
		return txnAmount;
	}

	public void setTxnAmount(String txnAmount) {
		this.txnAmount = txnAmount;
	}

	public String getNetTxnAmount() {
		return netTxnAmount;
	}

	public void setNetTxnAmount(String netTxnAmount) {
		this.netTxnAmount = netTxnAmount;
	}

	public String getDistributionAmount() {
		return distributionAmount;
	}

	public void setDistributionAmount(String distributionAmount) {
		this.distributionAmount = distributionAmount;
	}

	public String getDistributionType() {
		return distributionType;
	}

	public void setDistributionType(String distributionType) {
		this.distributionType = distributionType;
	}

	public String getTxnType() {
		return txnType;
	}

	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}

	public Integer getAgentUserId() {
		return agentUserId;
	}

	public void setAgentUserId(Integer agentUserId) {
		this.agentUserId = agentUserId;
	}

	

	public Integer getPortalId() {
		return portalId;
	}

	public void setPortalId(Integer portalId) {
		this.portalId = portalId;
	}

	public String getAgentAmount() {
		return agentAmount;
	}

	public void setAgentAmount(String agentAmount) {
		this.agentAmount = agentAmount;
	}

	public Integer getHostId() {
		return hostId;
	}

	public void setHostId(Integer hostId) {
		this.hostId = hostId;
	}

	public String getHostAmount() {
		return hostAmount;
	}

	public void setHostAmount(String hostAmount) {
		this.hostAmount = hostAmount;
	}

	
	public String getDistAmount() {
		return distAmount;
	}

	public void setDistAmount(String distAmount) {
		this.distAmount = distAmount;
	}

	public Integer getSubDistId() {
		return subDistId;
	}

	public void setSubDistId(Integer subDistId) {
		this.subDistId = subDistId;
	}

	public String getSubDistAmount() {
		return subDistAmount;
	}

	public void setSubDistAmount(String subDistAmount) {
		this.subDistAmount = subDistAmount;
	}

	public Integer getBankId() {
		return bankId;
	}

	public void setBankId(Integer bankId) {
		this.bankId = bankId;
	}

	public String getBankAmount() {
		return bankAmount;
	}

	public void setBankAmount(String bankAmount) {
		this.bankAmount = bankAmount;
	}

	public String getTotalCommission() {
		return totalCommission;
	}

	public void setTotalCommission(String totalCommission) {
		this.totalCommission = totalCommission;
	}

	public Integer getCommissionId() {
		return commissionId;
	}

	public void setCommissionId(Integer commissionId) {
		this.commissionId = commissionId;
	}

	public Integer getSubscriptionId() {
		return subscriptionId;
	}

	public void setSubscriptionId(Integer subscriptionId) {
		this.subscriptionId = subscriptionId;
	}

	public Date getEntryDate() {
		return entryDate;
	}

	public void setEntryDate(Date entryDate) {
		this.entryDate = entryDate;
	}

	public int getIsSettled() {
		return isSettled;
	}

	public void setIsSettled(int isSettled) {
		this.isSettled = isSettled;
	}

	public Date getSettledOn() {
		return settledOn;
	}

	public void setSettledOn(Date settledOn) {
		this.settledOn = settledOn;
	}

	public int getIsActive() {
		return isActive;
	}

	public void setIsActive(int isActive) {
		this.isActive = isActive;
	}

	public AccountInfo getAgentId() {
		return agentId;
	}

	public void setAgentId(AccountInfo agentId) {
		this.agentId = agentId;
	}

	public AccountInfo getDistId() {
		return distId;
	}

	public void setDistId(AccountInfo distId) {
		this.distId = distId;
	}

	public ProductTransactions getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(ProductTransactions transactionId) {
		this.transactionId = transactionId;
	}

	
}
