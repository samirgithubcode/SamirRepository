/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "OTAManagement")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "OTAManagement.findAll", query = "SELECT o FROM OTAManagement o"),
    @NamedQuery(name = "OTAManagement.findByHostIdAndOtaStatus", query = "SELECT o FROM OTAManagement o WHERE o.hsvId = :hsvId"),
    @NamedQuery(name = "OTAManagement.findByhsvId", query = "SELECT o FROM OTAManagement o WHERE o.hsvId = :hsvId"),
    @NamedQuery(name = "OTAManagement.findById", query = "SELECT o FROM OTAManagement o WHERE o.id = :id"),
    @NamedQuery(name = "OTAManagement.findByOtaDate", query = "SELECT o FROM OTAManagement o WHERE o.otaDate = :otaDate")})
public class OTAManagement implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Column(name = "smsCode")
    private String smsCode;
    @Basic(optional = false)
    @Column(name = "otaDate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date otaDate;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "otaMgmtId")
    private Collection<OTASubscriber> oTASubscriberCollection;
    @JoinColumn(name = "hostId", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private AccountInfo hostId;
    @JoinColumn(name = "hsvId", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private HostSubVersion hsvId;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "otaMgmtId")
    private Collection<OTAServiceConfigMapping> oTAServiceConfigMappingCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "otaMgmtId")
    private Collection<OTACatProviderMapping> oTACatProviderMappingCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "otaMgmtId")
    private Collection<OTAWalletMapping> oTAWalletMappingCollection;
    @Basic(optional = false)
    @Column(name = "smsChange")
    private short smsChange;
    @Basic(optional = false)
    @Column(name = "walletChange")
    private short walletChange;
    @OneToMany(mappedBy = "otaMgmtId")
    private List<HostSVWalletHistory> hostSvWalletHistroies;
	public OTAManagement() {
		//default constructor
    }

    public OTAManagement(Integer id) {
        this.id = id;
    }

    public OTAManagement(Integer id, Date otaDate) {
        this.id = id;
        this.otaDate = otaDate;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSmsCode() {
        return smsCode;
    }

    public void setSmsCode(String smsCode) {
        this.smsCode = smsCode;
    }

    public Date getOtaDate() {
        return otaDate;
    }

    public void setOtaDate(Date otaDate) {
        this.otaDate = otaDate;
    }

    @XmlTransient
    public Collection<OTASubscriber> getOTASubscriberCollection() {
        return oTASubscriberCollection;
    }

    public void setOTASubscriberCollection(Collection<OTASubscriber> oTASubscriberCollection) {
        this.oTASubscriberCollection = oTASubscriberCollection;
    }

    public AccountInfo getHostId() {
        return hostId;
    }

    public void setHostId(AccountInfo hostId) {
        this.hostId = hostId;
    }

    public HostSubVersion getHsvId() {
        return hsvId;
    }

    public void setHsvId(HostSubVersion hsvId) {
        this.hsvId = hsvId;
    }

    @XmlTransient
    public Collection<OTAServiceConfigMapping> getOTAServiceConfigMappingCollection() {
        return oTAServiceConfigMappingCollection;
    }

    public void setOTAServiceConfigMappingCollection(Collection<OTAServiceConfigMapping> oTAServiceConfigMappingCollection) {
        this.oTAServiceConfigMappingCollection = oTAServiceConfigMappingCollection;
    }

    @XmlTransient
    public Collection<OTACatProviderMapping> getOTACatProviderMappingCollection() {
        return oTACatProviderMappingCollection;
    }

    public void setOTACatProviderMappingCollection(Collection<OTACatProviderMapping> oTACatProviderMappingCollection) {
        this.oTACatProviderMappingCollection = oTACatProviderMappingCollection;
    }

    @XmlTransient
    public Collection<OTAWalletMapping> getOTAWalletMappingCollection() {
        return oTAWalletMappingCollection;
    }

    public void setOTAWalletMappingCollection(Collection<OTAWalletMapping> oTAWalletMappingCollection) {
        this.oTAWalletMappingCollection = oTAWalletMappingCollection;
    }
    public short getSmsChange() {
		return smsChange;
	}

	public void setSmsChange(short smsChange) {
		this.smsChange = smsChange;
	}

	public short getWalletChange() {
		return walletChange;
	}

	public void setWalletChange(short walletChange) {
		this.walletChange = walletChange;
	}
  

	public List<HostSVWalletHistory> getHostSvWalletHistroies() {
		return hostSvWalletHistroies;
	}

	public void setHostSvWalletHistroies(List<HostSVWalletHistory> hostSvWalletHistroies) {
		this.hostSvWalletHistroies = hostSvWalletHistroies;
	}

	@Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof OTAManagement)) {
            return false;
        }
        OTAManagement other = (OTAManagement) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.OTAManagement[ id=" + id + " ]";
    }
    
}

