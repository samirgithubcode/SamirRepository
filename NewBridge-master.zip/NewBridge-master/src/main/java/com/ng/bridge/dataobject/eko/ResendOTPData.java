package com.ng.bridge.dataobject.eko;

public class ResendOTPData {
	private String otp;

    public String getOtp ()
    {
        return otp;
    }

    public void setOtp (String otp)
    {
        this.otp = otp;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [otp = "+otp+"]";
    }
}
