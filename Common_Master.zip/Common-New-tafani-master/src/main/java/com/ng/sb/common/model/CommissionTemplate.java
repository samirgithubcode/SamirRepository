/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
*
* @author Simran
* 
* The persistent class for the commission template database table.
*/
@Entity
@Table(name = "Commissiontemplate")
@XmlRootElement
@NamedQueries({
	@NamedQuery(name="CommissionTemplate.findById", query="SELECT c FROM CommissionTemplate c where c.id=:id"),
	@NamedQuery(name="CommissionTemplate.findByStatus", query="SELECT c FROM CommissionTemplate c where c.isActive=:isActive"),
	@NamedQuery(name="CommissionTemplate.findByEndDate", query="SELECT c FROM CommissionTemplate c where c.isActive=:isActive AND c.endDate=NULL"),
	@NamedQuery(name="CommissionTemplate.findByCommissionCode", query="SELECT c FROM CommissionTemplate c where c.isActive=1 AND c.commissionCode=:commissionCode"),
	@NamedQuery(name="CommissionTemplate.findByCommCodeInDuration", query="SELECT ct FROM CommissionTemplate ct where ct.isActive=1 AND ct.commissionCode=:comm AND ct.startDate <= :tDate AND (ct.endDate IS NULL OR ct.endDate >= :tDate)"),
	@NamedQuery(name="CommissionTemplate.findAll", query="SELECT c FROM CommissionTemplate c"),
	@NamedQuery(name="CommissionTemplate.findByCommissionName", query="SELECT c FROM CommissionTemplate c where c.name=:tempName"),
	@NamedQuery(name="CommissionTemplate.findCountBytemplateName", query = "SELECT count(c) FROM CommissionTemplate c WHERE c.name = :templateName"),
})

public class CommissionTemplate implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Column(name = "name")
    private String name;
    @Column(name = "commission_code")
    private String commissionCode;
	@Column(name = "host_commission_percentage")
    private Double hostPercentage=0.0;
    @Column(name = "distributor_commission_percentage")
    private Double distributorPercentage=0.0;
    @Column(name = "sub_distributor_commission_percentage")
    private Double subDistributorPercentage=0.0;
    @Column(name = "agent_commission_percentage")
    private Double agentPercentage=0.0;
    @Column(name = "total_commission_percentage")
    private Double totalPercentage=0.0;
    @Column(name = "bank_commission_percentage")
    private Double bankPercentage=0.0;
    @Column(name = "start_date")
    @Temporal(TemporalType.DATE)
    private Date startDate;
    @Column(name = "end_date")
    @Temporal(TemporalType.DATE)
    private Date endDate;
	@Column(name = "created_on")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createDate;
    @Column(name = "created_by") 
    private Integer createdBy;
    @Column(name = "updated_on")
    @Temporal(TemporalType.TIMESTAMP)
    private Date modifiedDate;
    @Column(name = "updated_by") 
    private Integer updatedBy;
    @Column(name = "isActive")
    private Integer isActive;
    @Column(name="commission_type")
    private String commission;
    public CommissionTemplate() {
 		//default
 	}
    public CommissionTemplate(Integer id) {
        this.id = id;
    }
 
	public String getCommission() {
		return commission;
	}
    public Date getStartDate() {
		return startDate;
	}
	public String getCommissionCode() {
		return commissionCode;
	}
	public void setCommissionCode(String commissionCode) {
		this.commissionCode = commissionCode;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public void setCommission(String commission) {
		this.commission = commission;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getHostPercentage() {
		return hostPercentage;
	}

	public void setHostPercentage(Double hostPercentage) {
		this.hostPercentage = hostPercentage;
	}

	public Double getDistributorPercentage() {
		return distributorPercentage;
	}

	public void setDistributorPercentage(Double distributorPercentage) {
		this.distributorPercentage = distributorPercentage;
	}

	public Double getSubDistributorPercentage() {
		return subDistributorPercentage;
	}

	public void setSubDistributorPercentage(Double subDistributorPercentage) {
		this.subDistributorPercentage = subDistributorPercentage;
	}

	public Double getAgentPercentage() {
		return agentPercentage;
	}

	public void setAgentPercentage(Double agentPercentage) {
		this.agentPercentage = agentPercentage;
	}

	public Double getTotalPercentage() {
		return totalPercentage;
	}

	public void setTotalPercentage(Double totalPercentage) {
		this.totalPercentage = totalPercentage;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Integer getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Integer getIsActive() {
		return isActive;
	}

	public void setIsActive(Integer isActive) {
		this.isActive = isActive;
	}

	public Double getBankPercentage() {
		return bankPercentage;
	}
	
	public void setBankPercentage(Double bankPercentage) {
		this.bankPercentage = bankPercentage;
	}
	
	@Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
    	boolean check=true;
    	if(object!=null){
        if (!(object instanceof CommissionTemplate)) {
        	check= false;
        }
        CommissionTemplate other = (CommissionTemplate) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
    	}
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.CommissionTemplate[ id=" + id + " ]";
    }
    
}
