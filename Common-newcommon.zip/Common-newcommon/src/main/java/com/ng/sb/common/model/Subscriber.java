/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.ColumnTransformer;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "subscriber")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Subscriber.findAll", query = "SELECT s FROM Subscriber s"),
    @NamedQuery(name = "Subscriber.findAllByAccountLoginId", query = "SELECT s FROM Subscriber s where accountLoginId IN :ids"),
    @NamedQuery(name = "Subscriber.findByHSVId", query = "SELECT s FROM Subscriber s WHERE s.hsvId = :hsvId and s.status =:status"),
    @NamedQuery(name = "Subscriber.findById", query = "SELECT s FROM Subscriber s WHERE s.id = :id"),
    @NamedQuery(name = "Subscriber.findByMobileCode", query = "SELECT s FROM Subscriber s WHERE s.mobileCode = :mobileCode"),
    @NamedQuery(name = "Subscriber.findByMsisdn", query = "SELECT s FROM Subscriber s WHERE s.aamsisdn = :msisdn"),
    @NamedQuery(name = "Subscriber.findByMsisdnOrCustomerId", query = "SELECT s FROM Subscriber s WHERE s.aamsisdn = :msisdn OR custId =:msisdn"),
    @NamedQuery(name = "Subscriber.findByParentMSISDN", query = "SELECT s FROM Subscriber s WHERE s.parentMSISDN = :parentMSISDN"),
    @NamedQuery(name = "Subscriber.findByName", query = "SELECT s FROM Subscriber s WHERE s.name = :name"),
    @NamedQuery(name = "Subscriber.findBySurname", query = "SELECT s FROM Subscriber s WHERE s.surname = :surname"),
    @NamedQuery(name = "Subscriber.findByDateOfBirth", query = "SELECT s FROM Subscriber s WHERE s.dateOfBirth = :dateOfBirth"),
    @NamedQuery(name = "Subscriber.findByAddress", query = "SELECT s FROM Subscriber s WHERE s.address = :address"),
    @NamedQuery(name = "Subscriber.findByEmailId", query = "SELECT s FROM Subscriber s WHERE s.emailId = :emailId"),
    @NamedQuery(name = "Subscriber.findByAddDate", query = "SELECT s FROM Subscriber s WHERE s.addDate = :addDate"),
    @NamedQuery(name = "Subscriber.findByEditDate", query = "SELECT s FROM Subscriber s WHERE s.editDate = :editDate"),
    @NamedQuery(name = "Subscriber.findByInvalidLPinCount", query = "SELECT s FROM Subscriber s WHERE s.invalidLPinCount = :invalidLPinCount"),
    @NamedQuery(name = "Subscriber.findByInvalidTPinCount", query = "SELECT s FROM Subscriber s WHERE s.invalidTPinCount = :invalidTPinCount"),
    @NamedQuery(name = "Subscriber.findByStatus", query = "SELECT s FROM Subscriber s WHERE s.status = :status"),
    @NamedQuery(name = "Subscriber.findByKycGiven", query = "SELECT s FROM Subscriber s WHERE s.kycGiven = :kycGiven"),
    @NamedQuery(name = "Subscriber.findByKycValidated", query = "SELECT s FROM Subscriber s WHERE s.kycValidated = :kycValidated"),
    @NamedQuery(name = "Subscriber.findByCustId", query = "SELECT s FROM Subscriber s WHERE s.custId = :customerId"),
    @NamedQuery(name = "Subscriber.findByAnyId", query = "SELECT s FROM Subscriber s WHERE s.custId = :userId or s.aamsisdn = :userId or s.emailId=:userId "),
    @NamedQuery(name = "Subscriber.findByPassword", query = "SELECT s FROM Subscriber s WHERE s.aamsisdn = :msisdn "),//and s.userPassword IS NOT NULL
    @NamedQuery(name = "Subscriber.UpdateByMsisdn", query ="Update Subscriber s SET s.emailId = :emailId, s.userPassword = :userPassword , s.status= :status, s.name=:name, s.surname=:lastName, s.dateOfBirth =:dob, s.invalidLoginCount=0, s.firstTimeLogin=1  where s.aamsisdn = :msisdn"),
    @NamedQuery(name = "Subscriber.FindSubscriberByInventoryId", query ="SELECT s from Subscriber s where s.status=:status AND s.invMgtId=:invMgtId"),
    @NamedQuery(name = "Subscriber.FindSubscriberByMsdn", query ="SELECT s from Subscriber s where s.status='ACTIVE' AND s.aamsisdn=:msisdn"),
    @NamedQuery(name = "Subscriber.FindSubscriberByMsdnWithoutStatus", query ="SELECT s from Subscriber s where  s.aamsisdn=:msisdn AND s.status='INACTIVE'"),
    @NamedQuery(name = "Subscriber.findByOverlayHSV", query = "SELECT s.mobileCode, s.aamsisdn FROM Subscriber s WHERE s.invMgtId IS NOT NULL AND s.hsvId IS NOT NULL AND s.hsvId.id = :hsvId"),
    @NamedQuery(name = "Subscriber.findByAgentId", query = "SELECT s FROM Subscriber s WHERE s.accountLoginId = :id"),
    
})
public class Subscriber implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "msisdn")
    private String aamsisdn;
    @Column(name = "mobileCode")
    private Integer mobileCode;
    @Column(name = "parentMSISDN")
    private String parentMSISDN;
    @Basic(optional = false)
    @Column(name = "name")
    @ColumnTransformer(write="AES_ENCRYPT(?, msisdn)",read="AES_DECRYPT(name, msisdn)")
    private String name;
    @Column(name = "surname")
    @ColumnTransformer(write="AES_ENCRYPT(?, msisdn)",read="AES_DECRYPT(surname, msisdn)")
    private String surname;
    @Column(name = "dateOfBirth")
    @ColumnTransformer(write="AES_ENCRYPT(?, msisdn)",read="AES_DECRYPT(dateOfBirth, msisdn)")
    @Temporal(TemporalType.DATE)
    private Date dateOfBirth;
    @Column(name = "address")
    @ColumnTransformer(write="AES_ENCRYPT(?, msisdn)",read="AES_DECRYPT(address, msisdn)")
    private String address;
    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name="addressId", referencedColumnName="id")
    private Address addressId;
    @Column(name = "emailId")
    @ColumnTransformer(write="AES_ENCRYPT(?, msisdn)",read="AES_DECRYPT(emailId, msisdn)")
    private String emailId;
    @Basic(optional = false)
    @Column(name = "addDate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date addDate;
    @Column(name = "editDate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date editDate;
    @Column(name = "invalidLPinCount")
    private Integer invalidLPinCount;
    @Column(name = "invalidTPinCount")
    private Integer invalidTPinCount;
    @Basic(optional = false)
    @Column(name = "status")
    private String status;
    @Basic(optional = false)
    @Column(name = "kycGiven")
    private short kycGiven;
    @Basic(optional = false)
    @Column(name = "kycValidated")
    private short kycValidated;
    @Basic(optional = false)
    @JoinColumn(name = "kycDescriptorId", referencedColumnName = "id")
    private KYCDescriptor kycDescriptorId;
    @Basic(optional = false)
    @Column(name = "subscriberType")
    private String subscriberType;
    @Basic(optional = false)
    @Column(name = "custId")
    private String custId;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "userId")
    private Collection<UserAccounts> userAccountsCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "userId")
    private Collection<SimTempBlockHistory> simTempBlockHistoryCollection;
    @JoinColumn(name = "invMgtId", referencedColumnName = "id")
    @ManyToOne(fetch=FetchType.LAZY)
    private InventoryMgmt invMgtId;
    @JoinColumn(name = "accountLoginId", referencedColumnName = "id")
    @ManyToOne(fetch=FetchType.LAZY)
    @Fetch(FetchMode.SELECT)
    private AccountLoginInfo accountLoginId;
    @JoinColumn(name = "hsvId", referencedColumnName = "id")
    @ManyToOne(fetch=FetchType.LAZY)
    private HostSubVersion hsvId;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "subscriberId", fetch = FetchType.LAZY)
    @Fetch(FetchMode.SELECT)
    private Collection<SubscriberIdProofs> subscriberIdProofsCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "subscriberId", fetch = FetchType.LAZY)
    @Fetch(FetchMode.SELECT)
    private Collection<Otp> otpCollection;
    @OneToMany(mappedBy = "userId")
    private Collection<SimReplacementDetails> simReplacementDetailsCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "subscriberId")
    private Collection<SubscriberWallet> subscriberWalletCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "userId")
    private Collection<UserIndvMerchant> userIndvMerchantCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "userId")
    private Collection<WalletTransaction> walletTransactionCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "userId")
    private Collection<SimPermanentBlockHistory> simPermanentBlockHistoryCollection;
    @OneToMany(mappedBy = "userId")
    private Collection<TransactionFundTransfer> transactionFundTransferCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "userId")
    private Collection<UserBiller> userBillerCollection;
    @OneToMany(mappedBy = "userId")
    private Collection<TransactionCommition> transactionCommitionCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "subscriberId")
    private Collection<OTASubscriber> oTASubscriberCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "subscriberId")
    private Collection<SubscriberInventoryMapping> subscriberInventoryMapping;

	@Column(name = "passwordDate")
	@Temporal(TemporalType.DATE)
	private Date passwordDate;

	@Basic(optional = false)
	@Column(name = "user_password")
	private String userPassword;
	
	@Column(name = "mpin")
	private String loginPin;
	
	@Column(name = "first_time_login")
	private Boolean firstTimeLogin;
	@Basic(optional = false)
	@Column(name = "invalid_login_count")
	private Integer invalidLoginCount;
	@Column(name = "region")
	@ColumnTransformer(write="AES_ENCRYPT(?, msisdn)",read="AES_DECRYPT(region, msisdn)")
	private String region;
	@Column(name = "address1")
	@ColumnTransformer(write="AES_ENCRYPT(?, msisdn)",read="AES_DECRYPT(address1, msisdn)")
	private String address1;
	
	@Column(name = "city")
	@ColumnTransformer(write="AES_ENCRYPT(?, msisdn)",read="AES_DECRYPT(city, msisdn)")
	private String city;
	@Column(name = "pinCode")
	private Integer pinCode;
	@Column(name = "gender")
	@ColumnTransformer(write="AES_ENCRYPT(?, msisdn)",read="AES_DECRYPT(gender, msisdn)")
	private String gender;
	@Column(name = "state")
	@ColumnTransformer(write="AES_ENCRYPT(?, msisdn)",read="AES_DECRYPT(state, msisdn)")
    private String state;
	@Column(name="country")
	@ColumnTransformer(write="AES_ENCRYPT(?, msisdn)",read="AES_DECRYPT(country, msisdn)")
    private String country;
	@Column(name="locality")
	@ColumnTransformer(write="AES_ENCRYPT(?, msisdn)",read="AES_DECRYPT(locality, msisdn)")
    private String locality;

	@Column(name="district")
	@ColumnTransformer(write="AES_ENCRYPT(?, msisdn)",read="AES_DECRYPT(district, msisdn)")
    private String district;
	
	@Column(name="profileImage")
	private String profileImage;
	
//	@Column(name = "national_id")
//	private String customerNid;
	
	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	@OneToMany(mappedBy = "accountId")
    private Collection<AccountSessionInfoSelfCare> accountSessionInfoSelfCareCollection;
	

	public Subscriber() {
    	//default constructor
    }

	public Subscriber(Integer id) {
		this.id = id;
	}

	public Subscriber(Integer id, String msisdn, String name, Date addDate, String status, short kycGiven,
			short kycValidated) {
		this.id = id;
		this.aamsisdn = msisdn;
		this.name = name;
		this.addDate = addDate;
		this.status = status;
		this.kycGiven = kycGiven;
		this.kycValidated = kycValidated;
	}
	
	public String getLocality() {
		return locality;
	}
	public void setLocality(String locality) {
		this.locality = locality;
	}
	
	
	@XmlTransient
	public Collection<AccountSessionInfoSelfCare> getAccountSessionInfoSelfCareCollection() {
		return accountSessionInfoSelfCareCollection;
	}
	public void setAccountSessionInfoSelfCareCollection(
			Collection<AccountSessionInfoSelfCare> accountSessionInfoSelfCareCollection) {
		this.accountSessionInfoSelfCareCollection = accountSessionInfoSelfCareCollection;
	}
	
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}
	public Integer getPinCode() {
		return pinCode;
	}

	public void setPinCode(Integer pinCode) {
		this.pinCode = pinCode;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}


	public Integer getInvalidLoginCount() {

		return invalidLoginCount;
	}
	public void setInvalidLoginCount(Integer invalidLoginCount) {
		this.invalidLoginCount = invalidLoginCount;
	}
	public Boolean getFirstTimeLogin() {
		return firstTimeLogin;
	}

	public void setFirstTimeLogin(Boolean firstTimeLogin) {
		this.firstTimeLogin = firstTimeLogin;
	}

	public Date getPasswordDate() {
		return passwordDate;
	}

	public void setPasswordDate(Date passwordDate) {
		this.passwordDate = passwordDate;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	
	public String getLoginPin() {
		return loginPin;
	}

	public void setLoginPin(String loginPin) {
		this.loginPin = loginPin;
	}

	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}


    

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getMsisdn() {
		return aamsisdn;
	}

	public void setMsisdn(String msisdn) {
		this.aamsisdn = msisdn;
	}
	
	public Integer getMobileCode() {
		return mobileCode;
	}

	public void setMobileCode(Integer mobileCode) {
		this.mobileCode = mobileCode;
	}

	public String getParentMSISDN() {
		return parentMSISDN;
	}

	public void setParentMSISDN(String parentMSISDN) {
		this.parentMSISDN = parentMSISDN;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	
	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	

	public Address getAddressId() {
		return addressId;
	}

	public void setAddressId(Address addressId) {
		this.addressId = addressId;
	}
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	
	
	
	public void setAddDate(Date addDate) {
		this.addDate = addDate;
	}
	public Date getEditDate() {
		return editDate;
	}
	

	public void setEditDate(Date editDate) {
		this.editDate = editDate;
	}
	

	public Integer getInvalidTPinCount() {
		return invalidTPinCount;
	}
	public Date getAddDate() {
		return addDate;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setInvalidTPinCount(Integer invalidTPinCount) {
		this.invalidTPinCount = invalidTPinCount;
	}
	public Integer getInvalidLPinCount() {
		return invalidLPinCount;
	}

	public void setInvalidLPinCount(Integer invalidLPinCount) {
		this.invalidLPinCount = invalidLPinCount;
	}
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	

	public short getKycValidated() {
		return kycValidated;
	}

	public void setKycValidated(short kycValidated) {
		this.kycValidated = kycValidated;
	}
	public short getKycGiven() {
		return kycGiven;
	}

	public void setKycGiven(short kycGiven) {
		this.kycGiven = kycGiven;
	}
	public KYCDescriptor getKycDescriptorId() {
		return kycDescriptorId;
	}

	public void setKycDescriptorId(KYCDescriptor kycDescriptorId) {
		this.kycDescriptorId = kycDescriptorId;
	}

	

	public String getCustId() {
		return custId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}
	public String getSubscriberType() {
		return subscriberType;
	}

	public void setSubscriberType(String subscriberType) {
		this.subscriberType = subscriberType;
	}
	@XmlTransient
	public Collection<UserAccounts> getUserAccountsCollection() {
		return userAccountsCollection;
	}

	public void setUserAccountsCollection(Collection<UserAccounts> userAccountsCollection) {
		this.userAccountsCollection = userAccountsCollection;
	}

	@XmlTransient
	public Collection<SimTempBlockHistory> getSimTempBlockHistoryCollection() {
		return simTempBlockHistoryCollection;
	}

	public void setSimTempBlockHistoryCollection(Collection<SimTempBlockHistory> simTempBlockHistoryCollection) {
		this.simTempBlockHistoryCollection = simTempBlockHistoryCollection;
	}

	public InventoryMgmt getInvMgtId() {
		return invMgtId;
	}

	public void setInvMgtId(InventoryMgmt invMgtId) {
		this.invMgtId = invMgtId;
	}

	public AccountLoginInfo getAccountLoginId() {
		return accountLoginId;
	}

	public void setAccountLoginId(AccountLoginInfo accountLoginId) {
		this.accountLoginId = accountLoginId;
	}

	public HostSubVersion getHsvId() {
		return hsvId;
	}

	public void setHsvId(HostSubVersion hsvId) {
		this.hsvId = hsvId;
	}

	@XmlTransient
	public Collection<SubscriberIdProofs> getSubscriberIdProofsCollection() {
		return subscriberIdProofsCollection;
	}

	public void setSubscriberIdProofsCollection(Collection<SubscriberIdProofs> subscriberIdProofsCollection) {
		this.subscriberIdProofsCollection = subscriberIdProofsCollection;
	}

	@XmlTransient
	public Collection<SimReplacementDetails> getSimReplacementDetailsCollection() {
		return simReplacementDetailsCollection;
	}

	public void setSimReplacementDetailsCollection(Collection<SimReplacementDetails> simReplacementDetailsCollection) {
		this.simReplacementDetailsCollection = simReplacementDetailsCollection;
	}

	@XmlTransient
	public Collection<SubscriberWallet> getSubscriberWalletCollection() {
		return subscriberWalletCollection;
	}

	public void setSubscriberWalletCollection(Collection<SubscriberWallet> subscriberWalletCollection) {
		this.subscriberWalletCollection = subscriberWalletCollection;
	}

	@XmlTransient
	public Collection<UserIndvMerchant> getUserIndvMerchantCollection() {
		return userIndvMerchantCollection;
	}

	public void setUserIndvMerchantCollection(Collection<UserIndvMerchant> userIndvMerchantCollection) {
		this.userIndvMerchantCollection = userIndvMerchantCollection;
	}

	@XmlTransient
	public Collection<WalletTransaction> getWalletTransactionCollection() {
		return walletTransactionCollection;
	}

	public void setWalletTransactionCollection(Collection<WalletTransaction> walletTransactionCollection) {
		this.walletTransactionCollection = walletTransactionCollection;
	}

	@XmlTransient
	public Collection<SimPermanentBlockHistory> getSimPermanentBlockHistoryCollection() {
		return simPermanentBlockHistoryCollection;
	}

	public void setSimPermanentBlockHistoryCollection(
			Collection<SimPermanentBlockHistory> simPermanentBlockHistoryCollection) {
		this.simPermanentBlockHistoryCollection = simPermanentBlockHistoryCollection;
	}

	@XmlTransient
	public Collection<TransactionFundTransfer> getTransactionFundTransferCollection() {
		return transactionFundTransferCollection;
	}

	public void setTransactionFundTransferCollection(
			Collection<TransactionFundTransfer> transactionFundTransferCollection) {
		this.transactionFundTransferCollection = transactionFundTransferCollection;
	}

	@XmlTransient
	public Collection<UserBiller> getUserBillerCollection() {
		return userBillerCollection;
	}

	public void setUserBillerCollection(Collection<UserBiller> userBillerCollection) {
		this.userBillerCollection = userBillerCollection;
	}

	@XmlTransient
	public Collection<TransactionCommition> getTransactionCommitionCollection() {
		return transactionCommitionCollection;
	}

	public void setTransactionCommitionCollection(Collection<TransactionCommition> transactionCommitionCollection) {
		this.transactionCommitionCollection = transactionCommitionCollection;
	}

	@XmlTransient
	public Collection<OTASubscriber> getOTASubscriberCollection() {
		return oTASubscriberCollection;
	}

	public void setOTASubscriberCollection(Collection<OTASubscriber> oTASubscriberCollection) {
		this.oTASubscriberCollection = oTASubscriberCollection;
	}

	public Collection<Otp> getOtpCollection() {
		return otpCollection;
	}

	public void setOtpCollection(Collection<Otp> otpCollection) {
		this.otpCollection = otpCollection;
	}

	@Override
	public int hashCode() {
		int hash = 0;
		hash += (id != null ? id.hashCode() : 0);
		return hash;
	}

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof Subscriber)) {
			return false;
		}
		Subscriber other = (Subscriber) object;
		   boolean check=true;
	        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
	        	check= false;
	        }
	        return check;
	}

	@Override
	public String toString() {
		return "com.ng.sb.common.model.Subscriber[ id=" + id + " ]";
	}

	public String getProfileImage() {
		return profileImage;
	}

	public void setProfileImage(String profileImage) {
		this.profileImage = profileImage;
	}

//	public String getCustomerNid() {
//		return customerNid;
//	}
//
//	public void setCustomerNid(String customerNid) {
//		this.customerNid = customerNid;
//	}

}
