
	package com.ng.sb.common.dataobject;

	import java.sql.Date;
	import java.util.List;
	import java.util.Map;
	import java.util.Set;

	import org.springframework.web.multipart.MultipartFile;

	import com.ng.sb.common.model.MerchantKyc;

	/**
	 * @author abhishek
	 *
	 */





	/*"merchantId"    : 101,
	"merchantName"	: "Deepak",
	"merchantType"	: "CORPORATE_MERCHANT",
	"address" : "D-443, New Usmanpur",
	"locality" : "sdfsfgsgfs",
	"district" : "North East",
	"city" : "Delhi",
	"state" : "Delhi",
	"country" : "India",
	"pincode" : 110053,
	"longitude": "45dfg3",
	"lattitude" : "5235ss",
	"noOfTill"	: 5,
	"parentMerchantId" :1,
	"mobileNumber" : "9811221010",
	"status"	: "ACTIVE",
	"email"	: "amar@nextgentele.in",
	"loginPin" : "ssdfewrfgsewrsdfserws",
	"invoice" : "manual",
	"ifsc" : "SBIN00001189",
	"accountNumber" : "343455434535",
	"accountType" : "Saving",
	"currencyCode" : "AU",
	"merchantCategory": "Telecommunications",*/
public class MerchantTmsDto {
		private static final long serialVersionUID = 1L;
		private String merchantName;
		private String merchantType;
		private String city;
		private String landmark;
		private String merchantCategoryId;
		private Integer pin;
		private int noOfTill;
		private String region;
		private String address;
		private String  parentMerchantId;
		private Integer pinCode;
		private String locality;
		private String district;
		private String email;
		private String mobileNumber;
		private String loginPin;
		private String invoice;
		private String statess;
		private String countrys;
		private List<TillDescription> tillDescriptions;
		private Integer under;
		private String status;
		private String encryptionKey;
		private String contactNumber;
		private String merchantCategory;
		private String currencyCode;
		private Date addedOn;
		private Date addedBy;
		private String accountNumber;
		private String ifscCode;
		private String parameterName;
		private String accountType;
		private List<MerchantKycDto> kyc;
		private List<MerchantSetting> settingDto;
		private String merchantId;
		private String longitude;
		private String latitude;
		private List<InventoryDto> inventoryDto;
		public String getMerchantName() {
			return merchantName;
		}
		public void setMerchantName(String merchantName) {
			this.merchantName = merchantName;
		}
		public String getMerchantType() {
			return merchantType;
		}
		public void setMerchantType(String merchantType) {
			this.merchantType = merchantType;
		}
		public String getCity() {
			return city;
		}
		public void setCity(String city) {
			this.city = city;
		}
		public String getLandmark() {
			return landmark;
		}
		public void setLandmark(String landmark) {
			this.landmark = landmark;
		}
		public String getMerchantCategoryId() {
			return merchantCategoryId;
		}
		public void setMerchantCategoryId(String merchantCategoryId) {
			this.merchantCategoryId = merchantCategoryId;
		}
		public Integer getPin() {
			return pin;
		}
		public void setPin(Integer pin) {
			this.pin = pin;
		}
		public int getNoOfTill() {
			return noOfTill;
		}
		public void setNoOfTill(int noOfTill) {
			this.noOfTill = noOfTill;
		}
		public String getRegion() {
			return region;
		}
		public void setRegion(String region) {
			this.region = region;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		public String getParentMerchantId() {
			return parentMerchantId;
		}
		public void setParentMerchantId(String parentMerchantId) {
			this.parentMerchantId = parentMerchantId;
		}
		public Integer getPinCode() {
			return pinCode;
		}
		public void setPinCode(Integer pinCode) {
			this.pinCode = pinCode;
		}
		public String getLocality() {
			return locality;
		}
		public void setLocality(String locality) {
			this.locality = locality;
		}
		public String getDistrict() {
			return district;
		}
		public void setDistrict(String district) {
			this.district = district;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getMobileNumber() {
			return mobileNumber;
		}
		public void setMobileNumber(String mobileNumber) {
			this.mobileNumber = mobileNumber;
		}
		public String getLoginPin() {
			return loginPin;
		}
		public void setLoginPin(String loginPin) {
			this.loginPin = loginPin;
		}
		public String getInvoice() {
			return invoice;
		}
		public void setInvoice(String invoice) {
			this.invoice = invoice;
		}
		public String getStatess() {
			return statess;
		}
		public void setStatess(String statess) {
			this.statess = statess;
		}
		public String getCountrys() {
			return countrys;
		}
		public void setCountrys(String countrys) {
			this.countrys = countrys;
		}
		public List<TillDescription> getTillDescriptions() {
			return tillDescriptions;
		}
		public void setTillDescriptions(List<TillDescription> tillDescriptions) {
			this.tillDescriptions = tillDescriptions;
		}
		public Integer getUnder() {
			return under;
		}
		public void setUnder(Integer under) {
			this.under = under;
		}
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		public String getEncryptionKey() {
			return encryptionKey;
		}
		public void setEncryptionKey(String encryptionKey) {
			this.encryptionKey = encryptionKey;
		}
		public String getContactNumber() {
			return contactNumber;
		}
		public void setContactNumber(String contactNumber) {
			this.contactNumber = contactNumber;
		}
		public String getMerchantCategory() {
			return merchantCategory;
		}
		public void setMerchantCategory(String merchantCategory) {
			this.merchantCategory = merchantCategory;
		}
		public String getCurrencyCode() {
			return currencyCode;
		}
		public void setCurrencyCode(String currencyCode) {
			this.currencyCode = currencyCode;
		}
		public Date getAddedOn() {
			return addedOn;
		}
		public void setAddedOn(Date addedOn) {
			this.addedOn = addedOn;
		}
		public Date getAddedBy() {
			return addedBy;
		}
		public void setAddedBy(Date addedBy) {
			this.addedBy = addedBy;
		}
		public String getAccountNumber() {
			return accountNumber;
		}
		public void setAccountNumber(String accountNumber) {
			this.accountNumber = accountNumber;
		}
		public String getIfscCode() {
			return ifscCode;
		}
		public void setIfscCode(String ifscCode) {
			this.ifscCode = ifscCode;
		}
		public String getParameterName() {
			return parameterName;
		}
		public void setParameterName(String parameterName) {
			this.parameterName = parameterName;
		}
		public String getAccountType() {
			return accountType;
		}
		public void setAccountType(String accountType) {
			this.accountType = accountType;
		}
		public List<MerchantKycDto> getKyc() {
			return kyc;
		}
		public void setKyc(List<MerchantKycDto> kyc) {
			this.kyc = kyc;
		}
		public List<MerchantSetting> getSettingDto() {
			return settingDto;
		}
		public void setSettingDto(List<MerchantSetting> settingDto) {
			this.settingDto = settingDto;
		}
		public String getMerchantId() {
			return merchantId;
		}
		public void setMerchantId(String merchantId) {
			this.merchantId = merchantId;
		}
		public String getLongitude() {
			return longitude;
		}
		public void setLongitude(String longitude) {
			this.longitude = longitude;
		}
		public String getLatitude() {
			return latitude;
		}
		public void setLatitude(String latitude) {
			this.latitude = latitude;
		}
		public List<InventoryDto> getInventoryDto() {
			return inventoryDto;
		}
		public void setInventoryDto(List<InventoryDto> inventoryDto) {
			this.inventoryDto = inventoryDto;
		}
		@Override
		public String toString() {
			return "MerchantTmsDto [merchantName=" + merchantName + ", merchantType=" + merchantType + ", city=" + city
					+ ", landmark=" + landmark + ", merchantCategoryId=" + merchantCategoryId + ", pin=" + pin
					+ ", noOfTill=" + noOfTill + ", region=" + region + ", address=" + address + ", parentMerchantId="
					+ parentMerchantId + ", pinCode=" + pinCode + ", locality=" + locality + ", district=" + district
					+ ", email=" + email + ", mobileNumber=" + mobileNumber + ", loginPin=" + loginPin + ", invoice="
					+ invoice + ", statess=" + statess + ", countrys=" + countrys + ", tillDescriptions="
					+ tillDescriptions + ", under=" + under + ", status=" + status + ", encryptionKey=" + encryptionKey
					+ ", contactNumber=" + contactNumber + ", merchantCategory=" + merchantCategory + ", currencyCode="
					+ currencyCode + ", addedOn=" + addedOn + ", addedBy=" + addedBy + ", accountNumber="
					+ accountNumber + ", ifscCode=" + ifscCode + ", parameterName=" + parameterName + ", accountType="
					+ accountType + ", kyc=" + kyc + ", settingDto=" + settingDto + ", merchantId=" + merchantId
					+ ", longitude=" + longitude + ", latitude=" + latitude + ", inventoryDto=" + inventoryDto + "]";
		}
		
		
	}

