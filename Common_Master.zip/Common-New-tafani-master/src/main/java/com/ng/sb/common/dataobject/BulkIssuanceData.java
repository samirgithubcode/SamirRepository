package com.ng.sb.common.dataobject;

import java.util.List;
import java.util.Map;

public class BulkIssuanceData  extends BaseObjectData  {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Map<Integer,String> mvMap;
	private Integer hsvId;
	private Map<Integer,String> hsvMap;
	private Integer mvId;
	private Integer productId;
	private Map<Integer,String> productMap;
	private Integer distributerId;
	private Map<Integer,String> distributerMap;
	private String distributershow;
	private Integer subDistributerId;
	private String subDistributershow;
	private String agentshow;
	private Integer agentId;
	private Map<Integer,String> subAgentMap;
	private List<AccountLoginInfoData> accountLoginInfoDatas;
	private Map<Integer,String> subDistributerMap;
	private Map<Integer,String> sEMap;
	
	public Map<Integer, String> getSEMap() {
		return sEMap;
	}
	public void setSEMap(Map<Integer, String> sEMap) {
		this.sEMap = sEMap;
	}
	public List<AccountLoginInfoData> getAccountLoginInfoDatas() {
		return accountLoginInfoDatas;
	}
	public void setAccountLoginInfoDatas(
			List<AccountLoginInfoData> accountLoginInfoDatas) {
		this.accountLoginInfoDatas = accountLoginInfoDatas;
	}
	public String getDistributershow() {
		return distributershow;
	}
	public void setDistributershow(String distributershow) {
		this.distributershow = distributershow;
	}
	public String getAgentshow() {
		return agentshow;
	}
	public void setAgentshow(String agentshow) {
		this.agentshow = agentshow;
	}
	public Integer getAgentId() {
		return agentId;
	}
	public void setAgentId(Integer agentId) {
		this.agentId = agentId;
	}
	
	public Map<Integer, String> getSubAgentMap() {
		return subAgentMap;
	}
	public void setSubAgentMap(Map<Integer, String> subAgentMap) {
		this.subAgentMap = subAgentMap;
	}
	public String getSubDistributershow() {
		return subDistributershow;
	}
	public void setSubDistributershow(String subDistributershow) {
		this.subDistributershow = subDistributershow;
	}
	public Integer getDistributerId() {
		return distributerId;
	}
	public void setDistributerId(Integer distributerId) {
		this.distributerId = distributerId;
	}
	public Map<Integer, String> getDistributerMap() {
		return distributerMap;
	}
	public void setDistributerMap(Map<Integer, String> distributerMap) {
		this.distributerMap = distributerMap;
	}
	public Integer getSubDistributerId() {
		return subDistributerId;
	}
	public void setSubDistributerId(Integer subDistributerId) {
		this.subDistributerId = subDistributerId;
	}
	public Map<Integer, String> getSubDistributerMap() {
		return subDistributerMap;
	}
	public void setSubDistributerMap(Map<Integer, String> subDistributerMap) {
		this.subDistributerMap = subDistributerMap;
	}

	
	public Integer getMvId() {
		return mvId;
	}
	public void setMvId(Integer mvId) {
		this.mvId = mvId;
	}
	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	public Map<Integer, String> getMvMap() {
		return mvMap;
	}
	public void setMvMap(Map<Integer, String> mvMap) {
		this.mvMap = mvMap;
	}
	
	public Map<Integer, String> getHsvMap() {
		return hsvMap;
	}
	public void setHsvMap(Map<Integer, String> hsvMap) {
		this.hsvMap = hsvMap;
	}
	
	public Integer getHsvId() {
		return hsvId;
	}
	public void setHsvId(Integer hsvId) {
		this.hsvId = hsvId;
	}
	public Map<Integer, String> getProductMap() {
		return productMap;
	}
	public void setProductMap(Map<Integer, String> productMap) {
		this.productMap = productMap;
	}

}
