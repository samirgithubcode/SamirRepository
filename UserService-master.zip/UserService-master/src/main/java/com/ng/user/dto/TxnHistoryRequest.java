/**
 * 
 */
package com.ng.user.dto;

import com.ng.sb.common.dataobject.ValidationBean;

/**
 * @author gopal
 *
 */
public class TxnHistoryRequest implements ValidationBean {

	/**
	 * 
	 */
	private static final long serialVersionUID = -550310756865106319L;

	private String startDate;    //yyyy-mm-dd format
	
	private String endDate;  //yyyy-mm-dd format
	
	private String txnType ;
	
	private Integer txnStatus;
	
	private String subscriberMsisdn;
	
	private Integer txnCount = 5;

	private Integer agentId;
	
	private Integer userTypeId;
	
	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getTxnType() {
		return txnType;
	}

	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}

	public Integer getTxnStatus() {
		return txnStatus;
	}

	public void setTxnStatus(Integer txnStatus) {
		this.txnStatus = txnStatus;
	}

	public String getSubscriberMsisdn() {
		return subscriberMsisdn;
	}

	public void setSubscriberMsisdn(String subscriberMsisdn) {
		this.subscriberMsisdn = subscriberMsisdn;
	}

	public Integer getTxnCount() {
		return txnCount;
	}

	public void setTxnCount(Integer txnCount) {
		this.txnCount = txnCount;
	}

	public Integer getAgentId() {
		return agentId;
	}

	public void setAgentId(Integer agentId) {
		this.agentId = agentId;
	}

	public Integer getUserTypeId() {
		return userTypeId;
	}

	public void setUserTypeId(Integer userTypeId) {
		this.userTypeId = userTypeId;
	}
	
	
}
