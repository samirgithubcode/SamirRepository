package com.ng.sb.common.dataobject;

import java.math.BigDecimal;
import java.math.BigInteger;

public class SubsAccountDetails {
	private BigDecimal simInternalNumber;
	private BigInteger simExternalNumber;
	private String encryptionKey;
	private Integer mvId;
	private Integer hsvId;
	public Integer getMvId() {
		return mvId;
	}
	public void setMvId(Integer mvId) {
		this.mvId = mvId;
	}
	public Integer getHsvId() {
		return hsvId;
	}
	public void setHsvId(Integer hsvId) {
		this.hsvId = hsvId;
	}

	
	
	public BigDecimal getSimInternalNumber() {
		return simInternalNumber;
	}
	public void setSimInternalNumber(BigDecimal simInternalNumber) {
		this.simInternalNumber = simInternalNumber;
	}
	public String getEncryptionKey() {
		return encryptionKey;
	}
	public void setEncryptionKey(String encryptionKey) {
		this.encryptionKey = encryptionKey;
	}
	public BigInteger getSimExternalNumber() {
		return simExternalNumber;
	}
	public void setSimExternalNumber(BigInteger simExternalNumber) {
		this.simExternalNumber = simExternalNumber;
	}
	
}
