package com.ng.sb.common.dataobject;

import java.util.Date;
import java.util.List;
import java.util.Map;

public class KYCDescriptorData extends BaseObjectData {

	private static final long serialVersionUID = 1L;
	private String kycName;
	private String kycDescription;
	private Integer maxBalance;
	private Integer perTxnLimit;
	private Integer dailyTxnLimit;
	private Integer monthlyTxnLimit;
	private Integer kycLevel;
	private Map<Integer,String> levels;
	private List<KYCDescriptorData> kycDescriptorDataList;
	private String subscriberType;
	private Integer kycWeight;
	private Integer dailyDebitLimit;
	private Integer dailyCreditLimit;
	private Integer dailyTransactionCount;
	private Integer monthlyDebitLimit;
	private Integer monthlyCreditLimit;
	private Integer monthlyTransactionCount;
	private Integer yearlyDebitLimit;
	private Integer yearlyCreditLimit;
	private Integer yearlyTransactionCount;
	private Integer weightage;
	private List<KYCDescriptorData> pendingkycDescriptorDataList;
	private String kycDocumentName;
	private String verifiedBy;
	
	private String createdBy;
	private Date createdOn;
	private Date verifiedOn;
	
	public String getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}
	private String creationDate;
	private String verifiedOnDate;
	
	
	private String comment;
	
	
	public Integer getWeightage() {
		return weightage;
	}
	public void setWeightage(Integer weightage) {
		this.weightage = weightage;
	}
	private String status;
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getKycName() {
		return kycName;
	}
	public void setKycName(String kycName) {
		this.kycName = kycName;
	}
	public String getKycDescription() {
		return kycDescription;
	}
	public void setKycDescription(String kycDescription) {
		this.kycDescription = kycDescription;
	}
	
		public Integer getDailyTxnLimit() {
		return dailyTxnLimit;
	}
	public void setDailyTxnLimit(Integer dailyTxnLimit) {
		this.dailyTxnLimit = dailyTxnLimit;
	}
	public Integer getPerTxnLimit() {
		return perTxnLimit;
	}
	public void setPerTxnLimit(Integer perTxnLimit) {
		this.perTxnLimit = perTxnLimit;
	}

	public Integer getMonthlyTxnLimit() {
		return monthlyTxnLimit;
	}
	public void setMonthlyTxnLimit(Integer monthlyTxnLimit) {
		this.monthlyTxnLimit = monthlyTxnLimit;
	}
	public Integer getMaxBalance() {
		return maxBalance;
	}
	public void setMaxBalance(Integer maxBalance) {
		this.maxBalance = maxBalance;
	}
	public Integer getKycLevel() {
		return kycLevel;
	}
	public void setKycLevel(Integer kycLevel) {
		this.kycLevel = kycLevel;
	}
	public Map<Integer, String> getLevels() {
		return levels;
	}
	public void setLevels(Map<Integer, String> levels) {
		this.levels = levels;
	}
	public List<KYCDescriptorData> getKycDescriptorDataList() {
		return kycDescriptorDataList;
	}
	public void setKycDescriptorDataList(List<KYCDescriptorData> kycDescriptorDataList) {
		this.kycDescriptorDataList = kycDescriptorDataList;
	}
	public String getSubscriberType() {
		return subscriberType;
	}
	public void setSubscriberType(String subscriberType) {
		this.subscriberType = subscriberType;
	}
	public Integer getKycWeight() {
		return kycWeight;
	}
	public void setKycWeight(Integer kycWeight) {
		this.kycWeight = kycWeight;
	}
	public Integer getDailyDebitLimit() {
		return dailyDebitLimit;
	}
	public void setDailyDebitLimit(Integer dailyDebitLimit) {
		this.dailyDebitLimit = dailyDebitLimit;
	}
	public Integer getDailyCreditLimit() {
		return dailyCreditLimit;
	}
	public void setDailyCreditLimit(Integer dailyCreditLimit) {
		this.dailyCreditLimit = dailyCreditLimit;
	}
	public Integer getDailyTransactionCount() {
		return dailyTransactionCount;
	}
	public void setDailyTransactionCount(Integer dailyTransactionCount) {
		this.dailyTransactionCount = dailyTransactionCount;
	}
	public Integer getMonthlyDebitLimit() {
		return monthlyDebitLimit;
	}
	public void setMonthlyDebitLimit(Integer monthlyDebitLimit) {
		this.monthlyDebitLimit = monthlyDebitLimit;
	}
	public Integer getMonthlyCreditLimit() {
		return monthlyCreditLimit;
	}
	public void setMonthlyCreditLimit(Integer monthlyCreditLimit) {
		this.monthlyCreditLimit = monthlyCreditLimit;
	}
	public Integer getMonthlyTransactionCount() {
		return monthlyTransactionCount;
	}
	public void setMonthlyTransactionCount(Integer monthlyTransactionCount) {
		this.monthlyTransactionCount = monthlyTransactionCount;
	}
	public Integer getYearlyDebitLimit() {
		return yearlyDebitLimit;
	}
	public void setYearlyDebitLimit(Integer yearlyDebitLimit) {
		this.yearlyDebitLimit = yearlyDebitLimit;
	}
	public Integer getYearlyCreditLimit() {
		return yearlyCreditLimit;
	}
	public void setYearlyCreditLimit(Integer yearlyCreditLimit) {
		this.yearlyCreditLimit = yearlyCreditLimit;
	}
	public Integer getYearlyTransactionCount() {
		return yearlyTransactionCount;
	}
	public void setYearlyTransactionCount(Integer yearlyTransactionCount) {
		this.yearlyTransactionCount = yearlyTransactionCount;
	}
	public List<KYCDescriptorData> getPendingkycDescriptorDataList() {
		return pendingkycDescriptorDataList;
	}
	public void setPendingkycDescriptorDataList(List<KYCDescriptorData> pendingkycDescriptorDataList) {
		this.pendingkycDescriptorDataList = pendingkycDescriptorDataList;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public Date getVerifiedOn() {
		return verifiedOn;
	}
	public void setVerifiedOn(Date verifiedOn) {
		this.verifiedOn = verifiedOn;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getKycDocumentName() {
		return kycDocumentName;
	}
	public void setKycDocumentName(String kycDocumentName) {
		this.kycDocumentName = kycDocumentName;
	}
	public String getVerifiedBy() {
		return verifiedBy;
	}
	public void setVerifiedBy(String verifiedBy) {
		this.verifiedBy = verifiedBy;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getVerifiedOnDate() {
		return verifiedOnDate;
	}
	public void setVerifiedOnDate(String verifiedOnDate) {
		this.verifiedOnDate = verifiedOnDate;
	}
	
	
}
