package com.ng.sb.common.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="msisdn_change_history")



public class MsisdnChangeHistory {
	@Id
	@GeneratedValue
	private Integer id;
	
	@ManyToOne
	@JoinColumn(name="subsciberId", referencedColumnName="id")
	private Subscriber subsciberId;
	@ManyToOne
	@JoinColumn(name="inventoryId", referencedColumnName="id")
	private InventoryMgmt inventoryId;
	@Column(name="deviceId")
	private String deviceId;
	@Column(name="status")
	private boolean status;
	@Column(name="productType")
	private String productType;
	@Column(name="remark")
	private String remark;
	@Column(name="externalNo")
	private Long externalNo; 
	@Column(name="creationDate")
	private Date creationDate;
	@Column(name="old_mobile_number")
	private String oldMobileNumber;
	@Column(name="new_mobile_number")
	private String mobileNumber;
	
	public String getOldMobileNumber() {
		return oldMobileNumber;
	}
	public void setOldMobileNumber(String oldMobileNumber) {
		this.oldMobileNumber = oldMobileNumber;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public Long getExternalNo() {
		return externalNo;
	}
	public void setExternalNo(Long externalNo) {
		this.externalNo = externalNo;
	}
	public Date getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Subscriber getSubsciberId() {
		return subsciberId;
	}
	public void setSubsciberId(Subscriber subsciberId) {
		this.subsciberId = subsciberId;
	}
	public InventoryMgmt getInventoryId() {
		return inventoryId;
	}
	public void setInventoryId(InventoryMgmt inventoryId) {
		this.inventoryId = inventoryId;
	}
	public String getDeviceId() {
		return deviceId;
	}
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	

}
