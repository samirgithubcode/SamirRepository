package com.ng.sb.common.dataobject;

public class TransactionProviderData extends BaseObjectData{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String subscriberId;
	private String providerTransactionId;
	public String getProviderTransactionId() {
		return providerTransactionId;
	}
	public void setProviderTransactionId(String providerTransactionId) {
		this.providerTransactionId = providerTransactionId;
	}
	public String getSubscriberId() {
		return subscriberId;
	}
	public void setSubscriberId(String subscriberId) {
		this.subscriberId = subscriberId;
	}

}
