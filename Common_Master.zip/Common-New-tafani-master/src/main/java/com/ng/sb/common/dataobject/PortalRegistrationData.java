package com.ng.sb.common.dataobject;

import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

public class PortalRegistrationData  extends BaseObjectData {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String companyName;
	private String houseNo;
	private String city;
	private String landMark;
	private String countryId;
	private Map<Integer,String> countryMap;
	private String stateId;
	private Map<Integer,String> stateMap;
	private String region;
	private Integer pinCode;
	private String encryptionKey;
	private Integer status;
	private boolean flag;
	private Map<Integer,String> commissionMap;
	private Integer commissionId;
	private List<PortalUrlListData> urlList;
	
	private String personName;
	private String email;
	private String phoneNumberOne;
	private String phoneNumberTwo;
	private String phoneNumberThree;
	private String callBackUrl;
	private String companyUrl;
	private String portalurls;
	
	public MultipartFile getUploadFilePath() {
		return uploadFilePath;
	}
	
	public void setUploadFilePath(MultipartFile uploadFilePath) {
		this.uploadFilePath = uploadFilePath;
	}
	private transient MultipartFile uploadFilePath;
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	
	public String getPortalurls() {
		return portalurls;
	}
	public void setPortalurls(String portalurls) {
		this.portalurls = portalurls;
	}
	
	
	public String getCallBackUrl() {
		return callBackUrl;
	}
	public void setCallBackUrl(String callBackUrl) {
		this.callBackUrl = callBackUrl;
	}
	public String getPersonName() {
		return personName;
	}
	public void setPersonName(String personName) {
		this.personName = personName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getPhoneNumberOne() {
		return phoneNumberOne;
	}
	public void setPhoneNumberOne(String phoneNumberOne) {
		this.phoneNumberOne = phoneNumberOne;
	}
	public String getPhoneNumberTwo() {
		return phoneNumberTwo;
	}
	public void setPhoneNumberTwo(String phoneNumberTwo) {
		this.phoneNumberTwo = phoneNumberTwo;
	}
	public String getPhoneNumberThree() {
		return phoneNumberThree;
	}
	public void setPhoneNumberThree(String phoneNumberThree) {
		this.phoneNumberThree = phoneNumberThree;
	}
	public Map<Integer, String> getCommissionMap() {
		return commissionMap;
	}
	public void setCommissionMap(Map<Integer, String> commissionMap) {
		this.commissionMap = commissionMap;
	}
	public Integer getCommissionId() {
		return commissionId;
	}
	public void setCommissionId(Integer commissionId) {
		this.commissionId = commissionId;
	}
	public boolean isFlag() {
		return flag;
	}
	public void setFlag(boolean flag) {
		this.flag = flag;
	}
	
	public String getCompanyUrl() {
		return companyUrl;
	}
	public void setCompanyUrl(String companyUrl) {
		this.companyUrl = companyUrl;
	}
	public String getHouseNo() {
		return houseNo;
	}
	public void setHouseNo(String houseNo) {
		this.houseNo = houseNo;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getLandMark() {
		return landMark;
	}
	public void setLandMark(String landMark) {
		this.landMark = landMark;
	}
	public String getCountryId() {
		return countryId;
	}
	public void setCountryId(String countryId) {
		this.countryId = countryId;
	}
	public Map<Integer, String> getCountryMap() {
		return countryMap;
	}
	public void setCountryMap(Map<Integer, String> countryMap) {
		this.countryMap = countryMap;
	}
	public String getStateId() {
		return stateId;
	}
	public void setStateId(String stateId) {
		this.stateId = stateId;
	}
	public Map<Integer, String> getStateMap() {
		return stateMap;
	}
	public void setStateMap(Map<Integer, String> stateMap) {
		this.stateMap = stateMap;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public Integer getPinCode() {
		return pinCode;
	}
	public void setPinCode(Integer pinCode) {
		this.pinCode = pinCode;
	}
	public String getEncryptionKey() {
		return encryptionKey;
	}
	public void setEncryptionKey(String encryptionKey) {
		this.encryptionKey = encryptionKey;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public List<PortalUrlListData> getUrlList() {
		return urlList;
	}
	public void setUrlList(List<PortalUrlListData> urlList) {
		this.urlList = urlList;
	}

}
