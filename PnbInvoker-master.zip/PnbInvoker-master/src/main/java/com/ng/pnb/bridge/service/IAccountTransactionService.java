package com.ng.pnb.bridge.service;

import com.ng.pnb.invoker.util.AccountTransactionData;
import com.ng.sb.common.dataobject.BridgeDataObject;

public interface IAccountTransactionService {

	public AccountTransactionData performTransaction(BridgeDataObject bridgeDataObject)throws Exception;
	
	public AccountTransactionData deductAmountFromBank(BridgeDataObject bridgeDataObject)throws Exception;
	
	public AccountTransactionData billPayFromWallet(BridgeDataObject bridgeDataObject)throws Exception;
	
	public AccountTransactionData topUpFromWallet(BridgeDataObject bridgeDataObject)throws Exception;
	
	public AccountTransactionData topUpFromBank(BridgeDataObject bridgeDataObject)throws Exception;
}
