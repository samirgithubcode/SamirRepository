package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name = "OrderInfo")
@XmlRootElement
@NamedQueries({
		@NamedQuery(name = "Order.findAll", query = "SELECT o FROM Order o"),
		// @NamedQuery(name = "Order.findByorderFor", query =
		// "SELECT o FROM Order o WHERE o.orderFor = :orderFor"),
		@NamedQuery(name = "Order.findByorderFor", query = "SELECT o FROM Order o WHERE o.orderFor = :orderFor"),
		@NamedQuery(name = "Order.findAllbyOrderby", query = "SELECT x FROM Order x WHERE x.orderBy = :orderby"),
		@NamedQuery(name = "Order.findallById", query = "SELECT x FROM Order x where x.orderTo=:orderTo"),
		@NamedQuery(name = "Order.setStatusById", query = "SELECT x FROM Order x WHERE x.id=:id"),
		@NamedQuery(name = "Order.findshippinbyid", query = "SELECT x FROM Order x WHERE x.orderTo=:id"),
		@NamedQuery(name = "Order.findbydate&status", query = "SELECT x FROM Order x WHERE x.orderTo = :orderTo AND x.poDate >= :fromDate AND x.poDate <= :toDate AND x.status= :status ORDER BY x.createDate DESC"),
		@NamedQuery(name = "Order.findbydate&All", query = "SELECT x FROM Order x WHERE x.orderTo = :orderTo AND x.poDate >= :fromDate AND x.poDate<= :toDate ORDER BY x.createDate DESC"),
		@NamedQuery(name = "Order.findAllByOrderNumber", query = "SELECT x FROM Order x WHERE x.poNumber=:poNumber"),
		/*
		 * @NamedQuery(name = "Order.findByAccountIdAndDate", query =
		 * "SELECT o FROM Order o where o.orderBy = :orderBy AND o.orderFor = :orderFor AND o.poDate >= :fromDate AND o.poDate <= :endDate AND o.status= :status"
		 * ),
		 */
		@NamedQuery(name = "Order.findByAccountIdAndDate", query = "SELECT o FROM Order o WHERE o.orderBy = :orderBy  AND o.status= :status AND o.poDate BETWEEN :fromDate AND :endDate AND o.orderFor.accountGroupId=:accountGroupId"),
		@NamedQuery(name = "Order.findByAccountIdAndDate&OrderNo", query = "SELECT o FROM Order o WHERE o.orderBy = :orderBy AND o.orderFor = :orderFor  AND o.status= :status AND o.poDate BETWEEN :fromDate AND :endDate AND o.poNumber=:pono"),
		@NamedQuery(name = "Order.findByAccountIdAndDateForSelfAndOnbehalf", query = "SELECT o FROM Order o where o.orderBy IS NOT :orderBy AND o.orderFor = :orderFor AND o.poDate >= :fromDate AND o.poDate <= :endDate AND o.status= :status"),
		@NamedQuery(name = "Order.findByAccountIdAndDateForAllAnyStatus", query = "SELECT o FROM Order o where o.orderFor = :orderFor AND o.poDate >= :fromDate AND o.poDate <= :endDate AND o.status= :status"),
		@NamedQuery(name = "Order.findByAccountIdAndDateForStatusAll", query = "SELECT o FROM Order o where o.orderBy = :orderBy AND o.poDate >= :fromDate AND o.poDate <= :endDate AND o.orderFor.accountGroupId=:accountGroupId ORDER BY o.createDate DESC "),
		@NamedQuery(name = "Order.findByAccountIdAndDate&OrderNoForStatusAll", query = "SELECT o FROM Order o where o.orderBy = :orderBy AND o.orderFor = :orderFor AND o.poDate >= :fromDate AND o.poDate <= :endDate AND o.poNumber=:pono"),

		@NamedQuery(name = "Order.findallForReceipt", query = "SELECT o FROM Order o WHERE o.orderFor = :orderFor AND o.status IN ('PENDING','INPROGRESS') "),
		@NamedQuery(name = "Order.findallForCntrlWareHouse", query = "SELECT o FROM Order o WHERE o.orderFor = :orderFor AND o.orderBy = :orderBy AND o.status IN ('PENDING','INPROGRESS')"),
		@NamedQuery(name = "Order.findAllByOrderId", query = "SELECT o FROM Order o where o.id = :id"),
		@NamedQuery(name = "Order.findByOrderNumber", query = "SELECT o FROM Order o where o.poNumber = :poNumber"),
		@NamedQuery(name = "Order.findorderNoBYId", query = "SELECT o.poNumber FROM Order o where o.id=:id"),
		@NamedQuery(name = "Order.findByorderForAndStatus", query = "SELECT o FROM Order o WHERE o.orderFor = :orderFor AND status= :status"),
		@NamedQuery(name = "Order.findByAccountIdAndDateForSelfAndOnbehalfForRE", query = "SELECT o FROM Order o where o.orderBy IS NOT :orderBy AND o.orderFor = :orderFor AND o.poDate >= :fromDate AND o.poDate <= :endDate AND o.status= :status"),
		@NamedQuery(name = "Order.findorderidbyorderno", query = "SELECT o FROM Order o where o.poNumber =:pono"),
		@NamedQuery(name = "Order.findByAccountIdAndDateForAll", query = "SELECT o FROM Order o where o.orderFor = :orderFor AND o.poDate >= :fromDate AND o.poDate <= :endDate ORDER BY o.createDate DESC"),
		@NamedQuery(name = "Order.findByAccountIdAndDateForSelfAndOnbehalfForAll", query = "SELECT o FROM Order o where o.orderBy IS NOT :orderBy AND o.orderFor = :orderFor AND o.poDate >= :fromDate AND o.poDate <= :endDate"),
		@NamedQuery(name = "Order.findByOrder", query = "SELECT o FROM Order o where o.poNumber = :poNumber"),
		@NamedQuery(name = "Order.findOrderbyByorderid", query = "SELECT o FROM Order o where o.id = :id"),
		@NamedQuery(name = "Order.countorderbyid", query = "SELECT o FROM Order o where o.orderTo = :orderTo"),
		@NamedQuery(name = "Order.maxId", query = "SELECT max(id) FROM Order o"),
		@NamedQuery(name = "Order.findAllOrderNumber", query = "SELECT a.poNumber FROM Order a where a.poNumber LIKE :poNumber and a.orderFor=:orderfor"), })
public class Order implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "id")
	private Integer id;
	@Basic(optional = false)
	@Column(name = "poNumber")
	private String poNumber;
	@Basic(optional = false)
	@JoinColumn(name = "orderBy", referencedColumnName = "id")
	@ManyToOne
	private AccountInfo orderBy;
	@Basic(optional = false)
	@JoinColumn(name = "orderFor", referencedColumnName = "id")
	@ManyToOne
	private AccountInfo orderFor;
	@Basic(optional = false)
	@JoinColumn(name = "orderTo", referencedColumnName = "id")
	@ManyToOne
	private AccountInfo orderTo;
	@Basic(optional = false)
	@JoinColumn(name = "createdBy", referencedColumnName = "id")
	@ManyToOne
	private AccountLoginInfo createdBy;
	@Basic(optional = false)
	@Column(name = "poDate")
	@Temporal(TemporalType.DATE)
	private Date poDate;
	@Basic(optional = false)
	@Column(name = "createDate")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createDate;
	
	
	
public Collection<OrderDetail> getOrderdetailsCollection() {
		return orderdetailsCollection;
	}

	public void setOrderdetailsCollection(
			Collection<OrderDetail> orderdetailsCollection) {
		this.orderdetailsCollection = orderdetailsCollection;
	}

@OneToMany(mappedBy = "orderId",fetch=FetchType.LAZY)
private Collection<OrderDetail> orderdetailsCollection;

	@Column(name = "version")
	private Integer version;

	@Basic(optional = false)
	@Column(name = "status")
	private String status;
	public Order() {
		// empty
	}

	public Order(Integer id) {
		this.id = id;
	}
	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStatus() {
		return status;
	}

	

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getPoNumber() {
		return poNumber;
	}

	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}

	public AccountInfo getOrderBy() {
		return orderBy;
	}

	public void setOrderBy(AccountInfo orderBy) {
		this.orderBy = orderBy;
	}

	public AccountInfo getOrderFor() {
		return orderFor;
	}

	public void setOrderFor(AccountInfo orderFor) {
		this.orderFor = orderFor;
	}

	public AccountInfo getOrderTo() {
		return orderTo;
	}

	public void setOrderTo(AccountInfo orderTo) {
		this.orderTo = orderTo;
	}

	public AccountLoginInfo getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(AccountLoginInfo createdBy) {
		this.createdBy = createdBy;
	}

	public Date getPoDate() {
		return poDate;
	}

	public void setPoDate(Date poDate) {
		this.poDate = poDate;
	}

	@Override
	public int hashCode() {
		int hash = 0;
		hash += (id != null ? id.hashCode() : 0);
		return hash;
	}

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof Order)) {
			return false;
		}
		Order other = (Order) object;
		   boolean check=true;
	        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
	        	check= false;
	        }
	        return check;
	}

	@Override
	public String toString() {
		return "Order [id=" + id + "]";
	}

}
