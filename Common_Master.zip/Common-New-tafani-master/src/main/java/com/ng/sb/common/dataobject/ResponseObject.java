/**
 * 
 */
package com.ng.sb.common.dataobject;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * @author gopal
 *
 */
@JsonInclude(Include.NON_DEFAULT)
public class ResponseObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8229346397298607074L;

	private Integer status;
	
	private String message;
	 private transient Object payload;
	 private  transient Object errorList;
	 private String currentBalance;
	 
	private double refundAmount;
	
	private String activationCode;
	
	public Object getErrorList() {
		return errorList;
	}

	public void setErrorList(Object errorList) {
		this.errorList = errorList;
	}

	

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Object getPayload() {
		return payload;
	}

	public void setPayload(Object payload) {
		this.payload = payload;
	}

	public double getRefundAmount() {
		return refundAmount;
	}

	public void setRefundAmount(double refundAmount) {
		this.refundAmount = refundAmount;
	}
	public ResponseObject(){
		
	}
	public ResponseObject(Object payload , Integer status , String message){
		this.payload = payload;
		this.status = status;
		this.message = message;
	}

	public String getCurrentBalance() {
		return currentBalance;
	}

	public void setCurrentBalance(String currentBalance) {
		this.currentBalance = currentBalance;
	}

	public String getActivationCode() {
		return activationCode;
	}

	public void setActivationCode(String activationCode) {
		this.activationCode = activationCode;
	}
		
}
