package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Himanshu
 */
@Entity
@Table(name = "PortalUrls")
@XmlRootElement
@NamedQueries({
	 @NamedQuery(name = "PortalUrls.findAll", query = "SELECT p FROM PortalUrls p"),
	 @NamedQuery(name = "PortalUrls.findById", query = "SELECT p FROM PortalUrls p WHERE p.id = :id"),
	 @NamedQuery(name = "PortalUrls.findByPortalID", query = "SELECT p FROM PortalUrls p WHERE p.portalId = :portalId"),
	 @NamedQuery(name = "PortalUrls.deleteUrls", query = "DELETE FROM PortalUrls p WHERE p.portalId = :portalId"),
	 @NamedQuery(name = "PortalUrls.findByCompanyUrl", query = "SELECT p FROM PortalUrls p WHERE p.url = :url"),
})
public class PortalUrls implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Column(name = "url")
    private String url;
    @JoinColumn(name = "portalId", referencedColumnName = "id")
    @ManyToOne()
    private PortalRegistration portalId;
    public PortalUrls() {
    	//empty
    }
    public PortalUrls(Integer id) {
        this.id = id;
    }

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public PortalRegistration getPortalId() {
		return portalId;
	}

	public void setPortalId(PortalRegistration portalId) {
		this.portalId = portalId;
	}

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof PortalUrls)) {
            return false;
        }
        PortalUrls other = (PortalUrls) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.PortalUrls[ id=" + id + " ]";
    }
}
