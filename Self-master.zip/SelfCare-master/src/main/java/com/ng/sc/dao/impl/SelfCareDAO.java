package com.ng.sc.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.ng.sb.common.dao.impl.SuperParentDAO;
import com.ng.sb.common.model.Country;
import com.ng.sb.common.model.State;
import com.ng.sc.dao.ISelfCareDAO;

/**
 * 
 * @author Satyendra
 *
 */

@Repository
public class SelfCareDAO extends SuperParentDAO implements ISelfCareDAO {
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = LoggerFactory.getLogger(SuperParentDAO.class);
	@Override
	public boolean saveObject(Object obj) throws Exception {
		boolean flag = false;
		try {
			entityManager.persist(obj);
			flag = true;
		} catch (Exception e) {
			LOGGER.info(""+e);
		}
		return flag;
	}

	@Override
	public boolean deleteObject(Object obj) throws Exception {
		boolean flag = false;
		try {
			entityManager.remove(obj);
			flag = true;
		} catch (Exception e) {
			LOGGER.info(""+e);
		}
		return flag;
	}

	public List<Country> getCountries() throws Exception {
		List<Country> list = new ArrayList<>();
		try {
			TypedQuery<Country> query = entityManager.createNamedQuery("Country.findAll", Country.class);
			list = query.getResultList();
		} catch (Exception e) {
			LOGGER.info(""+e);
		}
		return list;
	}

	public List<State> getState(Integer countryId) throws Exception {
		List<State> list = new ArrayList<>();
		try {
			TypedQuery<State> query = entityManager.createNamedQuery("State.findByCountryId", State.class);
			query.setParameter("countryId", new Country(countryId));
			list = query.getResultList();
		} catch (Exception e) {
			LOGGER.info(""+e);
		}
		return list;
	}

}
