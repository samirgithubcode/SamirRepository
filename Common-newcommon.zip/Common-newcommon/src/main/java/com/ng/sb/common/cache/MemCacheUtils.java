/**
 * 
 */
package com.ng.sb.common.cache;

/**
 * @author gopal
 *
 */
public enum MemCacheUtils {

	AUTHTOKENCACHE("authTokenCache", 1800, false), //For 30 Minutes (60 * 30)
	
	USERCACHE("userCache", 1800, false), //For 30 Minutes (60 * 30)
	
	CARDISSUANCECACHE("cardIssuanceCache", 900, false),
	
	CARDRECHARGECACHE("cardRechargeCache", 900, false),
	
	AUTHORIZATIONCACHE("authorizationCache", 0, true),
	
	OTPCACHE("otpCache", 300, false), //For 15 Minutes (60 * 5)
	
	ACTIVATION_CACHE("activationCache", 900, false),
	
	DEMO_CACHE("demoCache", 900, false),
	
	COMMISSIONINFOCACHE("commissionInfoCache", 1800, true);

	private String cacheName;
	private int timeToLive;
	private boolean allowClear;
	
	MemCacheUtils(String cacheName, int timeToLive, boolean allowClear)
	{
		this.cacheName = cacheName;
		this.timeToLive = timeToLive;
		this.allowClear = allowClear;
	}
	
	
	public String getCacheName() {
		return cacheName;
	}

    public int getTimeToLive() {
		return timeToLive;
	}

	public boolean isAllowClear() {
		return allowClear;
	}
	
	
}
