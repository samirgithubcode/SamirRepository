package com.ng.sb.common.model;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name = "masterversionallocatedservice")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "MasterVersionAllocatedService.findAll", query = "SELECT m FROM MasterVersionAllocatedService m"),
    @NamedQuery(name = "MasterVersionAllocatedService.findAllByMvId", query = "SELECT m FROM MasterVersionAllocatedService m WHERE m.mvId = :mvId"),
    @NamedQuery(name = "MasterVersionAllocatedService.deleteAllByMvId", query = "DELETE FROM MasterVersionAllocatedService s WHERE s.mvId = :mvId"),
})
public class MasterVersionAllocatedService {
	
	private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    
    @JoinColumn(name = "mvId", referencedColumnName = "id")
    @ManyToOne
    private MasterVersion mvId;
    
    
    @Basic(optional = false)
    @Column(name = "name")
    private String name;
    
    @Basic(optional = false)
    @Column(name = "description")
    private String description;
    
    
    @JoinColumn(name = "serviceId", referencedColumnName = "id")
    @ManyToOne
    private ServiceConfig serviceId;
    
	public MasterVersion getMvId() {
		return mvId;
	}

	public void setMvId(MasterVersion mvId) {
		this.mvId = mvId;
	}


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}



	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public ServiceConfig getServiceId() {
		return serviceId;
	}

	public void setServiceId(ServiceConfig serviceId) {
		this.serviceId = serviceId;
	}

	

	@Override
	public String toString() {
		return "MasterVersionAllocatedServices [mvId=" + mvId + ", name=" + name + ", description=" + description
				+ ", serviceId=" + serviceId + "]";
	}
    
    

}
