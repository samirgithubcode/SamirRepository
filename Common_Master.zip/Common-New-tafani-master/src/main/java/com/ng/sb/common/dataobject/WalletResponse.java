package com.ng.sb.common.dataobject;

import com.ng.sb.common.dataobject.ValidationBean;

public class WalletResponse implements ValidationBean {
	private static final long serialVersionUID = 1L;
	private Integer status;
	private String message;
	private transient Object payload;
	private transient Object errorList;

	private Integer refundAmount;

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Object getPayload() {
		return payload;
	}

	public void setPayload(Object payload) {
		this.payload = payload;
	}

	public Object getErrorList() {
		return errorList;
	}

	public void setErrorList(Object errorList) {
		this.errorList = errorList;
	}

	public Integer getRefundAmount() {
		return refundAmount;
	}

	public void setRefundAmount(Integer refundAmount) {
		this.refundAmount = refundAmount;
	}

}
