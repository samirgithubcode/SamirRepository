package com.ng.sb.common.dataobject;

import java.sql.Date;

public class ViewOrderData extends BaseObjectData{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer viewfor;
	private Integer orderBy;
	private Integer status;
	private Date toDate;
	private Date fromDate;
	private String statusType;
	private String product;
	private String masterVersion;
	private Integer unitQuantity;
	private Integer unitReceived;
	private Integer pendingQuantity;
	private String orderStatus;
	private String orderDoneBy;
	private String orderDoneFor;
	private String orderDoneTo;
	private String orderNumber;
	private String orderDate;
	private String cardType;
	private Integer mvId;
	private String productCode;
	private String masterVersionCode;
	private Long unitStock;
	
	public Integer getMvId() {
		return mvId;
	}
	public void setMvId(Integer mvId) {
		this.mvId = mvId;
	}
	public Long getUnitStock() {
		return unitStock;
	}
	public void setUnitStock(Long unitStock) {
		this.unitStock = unitStock;
	}
	public String getCardType() {
		return cardType;
	}
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}
	public String getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}
	
	
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	
	public String getMasterVersionCode() {
		return masterVersionCode;
	}
	public void setMasterVersionCode(String masterVersionCode) {
		this.masterVersionCode = masterVersionCode;
	}
	public String getOrderNumber() {
		return orderNumber;
	}
	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public String getMasterVersion() {
		return masterVersion;
	}
	public void setMasterVersion(String masterVersion) {
		this.masterVersion = masterVersion;
	}
	
	
	public Integer getUnitReceived() {
		return unitReceived;
	}
	public void setUnitReceived(Integer unitReceived) {
		this.unitReceived = unitReceived;
	}
	
	public Integer getUnitQuantity() {
		return unitQuantity;
	}
	public void setUnitQuantity(Integer unitQuantity) {
		this.unitQuantity = unitQuantity;
	}
	public Integer getPendingQuantity() {
		return pendingQuantity;
	}
	public void setPendingQuantity(Integer pendingQuantity) {
		this.pendingQuantity = pendingQuantity;
	}
	public String getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	
	public String getOrderDoneFor() {
		return orderDoneFor;
	}
	public void setOrderDoneFor(String orderDoneFor) {
		this.orderDoneFor = orderDoneFor;
	}
	
	public String getOrderDoneBy() {
		return orderDoneBy;
	}
	public void setOrderDoneBy(String orderDoneBy) {
		this.orderDoneBy = orderDoneBy;
	}
	public String getOrderDoneTo() {
		return orderDoneTo;
	}
	public void setOrderDoneTo(String orderDoneTo) {
		this.orderDoneTo = orderDoneTo;
	}
	public String getStatusType() {
		return statusType;
	}
	public void setStatusType(String statusType) {
		this.statusType = statusType;
	}
	public Integer getViewfor() {
		return viewfor;
	}
	public void setViewfor(Integer viewfor) {
		this.viewfor = viewfor;
	}
	public Integer getOrderBy() {
		return orderBy;
	}
	public void setOrderBy(Integer orderBy) {
		this.orderBy = orderBy;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public Date getToDate() {
		return toDate;
	}
	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}
	public Date getFromDate() {
		return fromDate;
	}
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}
}
