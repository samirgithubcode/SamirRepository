package com.ng.sb.common.dataobject;

import java.util.Date;

public class CacheBean {
private Date transactionDate;
private String transactionId;
private String key;
private String depcryptedString;
private PgStringRequestObject referString;
private String refId;
public PgStringRequestObject getReferString() {
	return referString;
}
public void setReferString(PgStringRequestObject referString) {
	this.referString = referString;
}
public String getDepcryptedString() {
	return depcryptedString;
}
public void setDepcryptedString(String depcryptedString) {
	this.depcryptedString = depcryptedString;
}
public Date getTransactionDate() {
	return transactionDate;
}
public void setTransactionDate(Date transactionDate) {
	this.transactionDate = transactionDate;
}
public String getTransactionId() {
	return transactionId;
}
public void setTransactionId(String transactionId) {
	this.transactionId = transactionId;
}
public String getKey() {
	return key;
}
public void setKey(String key) {
	this.key = key;
}
public String getRefId() {
	return refId;
}
public void setRefId(String refId) {
	this.refId = refId;
}



}
