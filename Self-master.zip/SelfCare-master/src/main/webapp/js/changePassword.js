function checkChangePass(event)
{
	
	var currPass = $('#userPassword').val();
	var newPass = $('#newPassword').val();
	var rePass = $('#rePassword').val();
	var check = true;
	if(currPass.length> 0){
		check = checkPassword();
		if(!check){
			$('#userPassword').val('');
			$('#lab_currentPasswordErrorId').html("<b><font color='red'>Invalid Passowrd !</font></b>");
		}
	}
	
	if(currPass.length == 0)
	{
		$('#lab_currentPasswordErrorId').html("<b><font color='red'>Current Password Cannot be Blank !</font></b>");
		check = false;
	}
	if(newPass.length == 0)
	{
		$('#lab_newPasswordErrorId').html("<b><font color='red'>New Password Cannot be Blank !</font></b>");
		check = false;
	}
	if(rePass.length == 0)
	{
		$('#lab_repasswordErrorId').html("<b><font color='red'>Re-Password Cannot be Blank !</font></b>");
		check = false;
	}
	if(rePass.length> 0){
		if(newPass===rePass)
		{}
		else
		{
			$('#lab_repasswordErrorId').html("<b><font color='red'>Passwords does not Match !</font></b>");
			$('#'+newPassword).val("");
			$('#'+rePassword).val("");
			 check = false;
		}
		
	}
	if(!(check))
	{	
		event.preventDefault();
		return false;
	}
	else
	{
		//$('#changePasswordForm').submit();
	}
}

function matchPassword(newPassword,rePassword)
{
	var newPass = $('#'+newPassword).val();
	var rePass = $('#'+rePassword).val();
	if(newPass===rePass)
	{}
	else
	{
		$('#lab_repasswordErrorId').html("<b><font color='red'>Passwords does not Match !</font></b>");
		$('#'+newPassword).val("");
		$('#'+rePassword).val("");
	}

}

function emptySuccessmessage(){
	$('#successMessageId').html("");
}

function checkPassword(){
	
			var userPassword = $("#userPassword").val();
		var check = function(){	
		var completeCheck=true;
		$.ajax({
			async: false,
			url: 'checkPassword',
			type:'POST',
			data:'userPassword='+userPassword,
			success:function(response)
			{
				if(response=="0")
				{
					//$("#userPassword").val('');
					$('#lab_currentPasswordErrorId').html("");
					completeCheck = true;
				}else
				{
					$('#lab_currentPasswordErrorId').html("<font color='red'><b>Current Password does not match.</b></font>");
					$('#userPassword').val('');
					completeCheck = false;
				}
			},
			  error: function(e) {
												
					  }
		});
		return completeCheck;
		}();

return check;
	}


