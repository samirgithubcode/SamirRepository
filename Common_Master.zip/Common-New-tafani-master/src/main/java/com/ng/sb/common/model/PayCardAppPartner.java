/**
 * 
 */
package com.ng.sb.common.model;

import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.ng.sb.common.util.CustomJsonDateSerializer;

/**
 * @author gopal
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true, value = {"payCardAppId","primaryKey", "value"})
@Entity
@Table(name = "paycard_app_partner")
@NamedQueries({
	@NamedQuery(name = "PayCardAppPartner.findAll", query = "select p from PayCardAppPartner p"),
	@NamedQuery(name = "PayCardAppPartner.getByAppId", query = "select appPartners from PayCardAppPartner appPartners WHERE CURRENT_DATE between appPartners.payCardAppId.startDate and appPartners.payCardAppId.endDate and appPartners.payCardAppId.appStatus=1 and appPartners.payCardAppId.id=:payCardAppId "),
	@NamedQuery(name = "PayCardAppPartner.getBypayCardAppId", query = "select appPartners from PayCardAppPartner appPartners WHERE appPartners.payCardAppId.id=:payCardAppId "),
	@NamedQuery(name = "PayCardAppPartner.getById", query = "select appPartners from PayCardAppPartner appPartners WHERE appPartners.id=:id "),
	@NamedQuery(name = "PayCardAppPartner.getByOrder", query = "select appPartners from PayCardAppPartner appPartners order by appPartners.partnerStatus desc,appPartners.payCardPartnerName"),

})
public class PayCardAppPartner implements IBasePojo {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6834750726322049962L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "id")
	private Integer id;
	
	@JoinColumn(name = "paycard_app_id", referencedColumnName = "id", nullable = false)
    @ManyToOne(optional = false)
	private PayCardApps payCardAppId;
	
	@Column(name = "paycard_partner_name")
	private String payCardPartnerName;
	
	@Column(name = "paycard_partner_description")
	private String payCardPartnerDescription;
	
	@JsonSerialize(using = CustomJsonDateSerializer.class)
	@Column(name = "start_date")
	private Date startDate;
	
	@JsonSerialize(using = CustomJsonDateSerializer.class)
	@Column(name = "end_date")
	private Date endDate;
	
	@Column(name = "status")
	private Boolean partnerStatus;

	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public PayCardApps getPayCardAppId() {
		return payCardAppId;
	}

	public void setPayCardAppId(PayCardApps payCardAppId) {
		this.payCardAppId = payCardAppId;
	}

	public String getPayCardPartnerName() {
		return payCardPartnerName;
	}

	public void setPayCardPartnerName(String payCardPartnerName) {
		this.payCardPartnerName = payCardPartnerName;
	}

	public String getPayCardPartnerDescription() {
		return payCardPartnerDescription;
	}

	public void setPayCardPartnerDescription(String payCardPartnerDescription) {
		this.payCardPartnerDescription = payCardPartnerDescription;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Boolean getPartnerStatus() {
		return partnerStatus;
	}

	public void setPartnerStatus(Boolean partnerStatus) {
		this.partnerStatus = partnerStatus;
	}

	@Override
	public Object getPrimaryKey() {
		return this.id;
	}

	@Override
	public String getValue() {
		return null;
	}

	@Override
	public void setCreatedOn(Date createdDate) {
		//empty
	}

	@Override
	public void setLastUpdatedOn(Date updatedOn) {
		//empty
	}

	@Override
	public void setCreatedBy(String createdBy) {
		//empty
	}

	@Override
	public void setLastUpdatedBy(String lastUpdatedBy) {
		//empty
	}
	
	@Override
    public int hashCode() 
	{
        int result = 17;
        result = 31 * result + payCardPartnerName.hashCode();
        result = 31 * result + id;
        
        return result;
    }
	
	 @Override
	public boolean equals(Object anotherObject) {
		 boolean result = false;
	        if (anotherObject == null || !(anotherObject instanceof PayCardAppPartner))
	        {
	            result = false;
	        }else{
	        	PayCardAppPartner user = (PayCardAppPartner) anotherObject;
	        	if(this.id == user.id)
	        		result = true;
	        }
	        
	        return result;
	}
}
