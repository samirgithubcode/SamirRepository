package com.ng.sb.common.dataobject;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

public class AccountCreationData extends BaseObjectData {
	private static final long serialVersionUID = 1L;
	private Integer companyId;	
	private Integer hostId;
	private String commissionname;
	private List<AccountCreationData> dataAll;
	private String chk;
	private Integer distributorId;
	private Integer subDistributorId;
	private Integer retailerId;
	protected Integer commissionId;
	private String companyName;
	private String houseNo;
	private String city;
	private String landMark;
	private Integer countryId;
	private Map<Integer,String> countryMap;
	private Integer stateId;
	private Map<Integer,String> stateMap;
	private String address;
	private String addressTwo;
	private String locality;
	private String district;
	private String state;
	private String country;
    private String firstName;
	private String lastName;
	private java.sql.Date dob;
	private String email;
	private String mobileNumber;
	private String alternateMobileNumber;
	private String hiddenAddressId;
	private Integer countryCodeId;
	private Integer altCountryCodeId;
	private String resetBy;
	private String landmark1;
    private String landmark2;
    private String companyNameEdit;
    private String emailIdEdit;
    private String status;
    private Date createDate;
    private transient List<AccountList> hostlist;
    private transient List<TreeView> treeview;
	private Integer protocolId;
	private Map<Integer,String> protocolMap;
	private Integer retryNo;
	private Integer trnxTimeOut;
	private String encryptionKey;
	private String[] nameArr;
	private String[] emailArr;
	private String[] mobileArr;
	private String[] loginNameArr;
	private String[] passwordArr;
	private Integer[] statusArr;
	private Integer[] accountTypeArr;
	private transient PlatformChain platformChain;
	private transient MultipartFile uploadCompanyLogoImage;
	private String groupCode;
	private Map<Integer,String> sysAccountTypeMap;
	private Integer accountTypeId;
	private Integer accountStatus;
	private Integer sysAccountGroupId;
	private Integer loginId;
	private Integer accountId;
	private boolean flag;
	private String mobile;
	private String deploymentType;
	private String smsShortCode;
	private String gatewayIp;
	private Integer port;
	private String url;
	private transient List<AccountList> accountList;
	private String companyLogo;
	private Integer accountCode;
	private String sysAccountGroupName;
	private String hostvendor;
	private Integer pinaddressId;
	private transient List<AccountList> vendorlist;
	private String region;
	private Integer pinCode;
	private Integer parentId;
	private boolean agentstatus;
	private String parentName;
	private String contactPersonName;
	private String txnType;
	private Double hostCommission;
	private Double distributorCommission;
	 private String subcategories;
	private Double subdistributorCommission;
	private String txnNature;
    private Integer agentId;
    private String hierarchy;
    private Integer[] serviceCheck;
    private List<AccountCreationData> companyList;
    private String profileImageName;
    private String comment;
    private String serviceCategory;
    private MultipartFile image;
    public Integer[] getServiceCheck() {
		return serviceCheck;
	}

	public void setServiceCheck(Integer[] serviceCheck) {
		this.serviceCheck = serviceCheck;
	}
    public String getServiceCategory() {
		return serviceCategory;
	}

	public void setServiceCategory(String serviceCategory) {
		this.serviceCategory = serviceCategory;
	}

	
	public String getComment() {
		return comment;
	}

	public MultipartFile getImage() {
		return image;
	}

	public void setImage(MultipartFile image) {
		this.image = image;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}
    
    
    
    
	public String getProfileImageName() {
		return profileImageName;
	}

	public void setProfileImageName(String profileImageName) {
		this.profileImageName = profileImageName;
	}

	public String getHierarchy() {
		return hierarchy;
	}

	public void setHierarchy(String hierarchy) {
		this.hierarchy = hierarchy;
	}


	public Integer getAgentId() {
		return agentId;
	}

	public void setAgentId(Integer agentId) {
		this.agentId = agentId;
	}

	public String getTxnNature() {
		return txnNature;
	}

	public void setTxnNature(String txnNature) {
		this.txnNature = txnNature;
	}

	public Integer getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}

	public String getCommissionname() {
		return commissionname;
	}

	public void setCommissionname(String commissionname) {
		this.commissionname = commissionname;
	}

	public Integer getCommissionId() {
		return commissionId;
	}

	public void setCommissionId(Integer commissionId) {
		this.commissionId = commissionId;
	}
		
	public List<AccountCreationData> getDataAll() {
		return dataAll;
	}

	public void setDataAll(List<AccountCreationData> dataAll) {
		this.dataAll = dataAll;
	}

	public String getChk() {
		return chk;
	}

	public void setChk(String chk) {
		this.chk = chk;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	

    
    public List<TreeView> getTreeview() {
		return treeview;
	}

	public void setTreeview(List<TreeView> treeview) {
		this.treeview = treeview;
	}
 

    
	public List<AccountList> getVendorlist() {
		return vendorlist;
	}

	public void setVendorlist(List<AccountList> vendorlist) {
		this.vendorlist = vendorlist;
	}

	public List<AccountList> getHostlist() {
		return hostlist;
	}

	public void setHostlist(List<AccountList> hostlist) {
		this.hostlist = hostlist;
	}

	public String getEmailIdEdit() {
		return emailIdEdit;
	}

	public void setEmailIdEdit(String emailIdEdit) {
		this.emailIdEdit = emailIdEdit;
	}

	public String getCompanyNameEdit() {
		return companyNameEdit;
	}

	public void setCompanyNameEdit(String companyNameEdit) {
		this.companyNameEdit = companyNameEdit;
	}

	public String getLandmark2() {
		return landmark2;
	}

	public void setLandmark2(String landmark2) {
		this.landmark2 = landmark2;
	}

	public String getLandmark1() {
		return landmark1;
	}

	public void setLandmark1(String landmark1) {
		this.landmark1 = landmark1;
	}

	public String getResetBy() {
		return resetBy;
	}

	public void setResetBy(String resetBy) {
		this.resetBy = resetBy;
	}

	public String getAddressTwo() {
		return addressTwo;
	}

	public void setAddressTwo(String addressTwo) {
		this.addressTwo = addressTwo;
	}
	
	public Integer getAltCountryCodeId() {
		return altCountryCodeId;
	}

	public void setAltCountryCodeId(Integer altCountryCodeId) {
		this.altCountryCodeId = altCountryCodeId;
	}

	public Integer getCountryCodeId() {
		return countryCodeId;
	}

	public void setCountryCodeId(Integer countryCodeId) {
		this.countryCodeId = countryCodeId;
	}

	public String getHiddenAddressId() {
		return hiddenAddressId;
	}
	
	public void setHiddenAddressId(String hiddenAddressId) {
		this.hiddenAddressId = hiddenAddressId;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getAlternateMobileNumber() {
		return alternateMobileNumber;
	}
	public void setAlternateMobileNumber(String alternateMobileNumber) {
		this.alternateMobileNumber = alternateMobileNumber;
	}
	public java.sql.Date getDob() {
		return dob;
	}
	public void setDob(java.sql.Date dob) {
		this.dob = dob;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Map<Integer, String> getStateMap() {
		return stateMap;
	}
	public void setStateMap(Map<Integer, String> stateMap) {
		this.stateMap = stateMap;
	}

	
	
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public String getLocality() {
		return locality;
	}
	public void setLocality(String locality) {
		this.locality = locality;
	}
	
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Integer getPinaddressId() {
		return pinaddressId;
	}
	public void setPinaddressId(Integer pinaddressId) {
		this.pinaddressId = pinaddressId;
	}
	public String getHostvendor() {
		return hostvendor;
	}
	public void setHostvendor(String hostvendor) {
		this.hostvendor = hostvendor;
	}
	public String getSysAccountGroupName() {
		return sysAccountGroupName;
	}
	public void setSysAccountGroupName(String sysAccountGroupName) {
		this.sysAccountGroupName = sysAccountGroupName;
	}
	public Integer getAccountCode() {
		return accountCode;
	}
	public void setAccountCode(Integer accountCode) {
		this.accountCode = accountCode;
	}
	public String getCompanyLogo() {
		return companyLogo;
	}
	public void setCompanyLogo(String companyLogo) {
		this.companyLogo = companyLogo;
	}
	public List<AccountList> getAccountList() {
		return accountList;
	}
	public void setAccountList(List<AccountList> accountList) {
		this.accountList = accountList;
	}
	public String getSmsShortCode() {
		return smsShortCode;
	}
	public void setSmsShortCode(String smsShortCode) {
		this.smsShortCode = smsShortCode;
	}
	public String getGatewayIp() {
		return gatewayIp;
	}
	public void setGatewayIp(String gatewayIp) {
		this.gatewayIp = gatewayIp;
	}
	public Integer getPort() {
		return port;
	}
	public void setPort(Integer port) {
		this.port = port;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getDeploymentType() {
		return deploymentType;
	}
	public void setDeploymentType(String deploymentType) {
		this.deploymentType = deploymentType;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public boolean isFlag() {
		return flag;
	}
	public void setFlag(boolean flag) {
		this.flag = flag;
	}
	public Integer getAccountId() {
		return accountId;
	}
	public void setAccountId(Integer accountId) {
		this.accountId = accountId;
	}
	public Integer getLoginId() {
		return loginId;
	}
	public void setLoginId(Integer loginId) {
		this.loginId = loginId;
	}
	public Integer getSysAccountGroupId() {
		return sysAccountGroupId;
	}
	public void setSysAccountGroupId(Integer sysAccountGroupId) {
		this.sysAccountGroupId = sysAccountGroupId;
	}
	public Integer getAccountStatus() {
		return accountStatus;
	}
	public void setAccountStatus(Integer accountStatus) {
		this.accountStatus = accountStatus;
	}
	public Integer getAccountTypeId() {
		return accountTypeId;
	}
	public void setAccountTypeId(Integer accountTypeId) {
		this.accountTypeId = accountTypeId;
	}
	public Map<Integer, String> getSysAccountTypeMap() {
		return sysAccountTypeMap;
	}
	public void setSysAccountTypeMap(Map<Integer, String> sysAccountTypeMap) {
		this.sysAccountTypeMap = sysAccountTypeMap;
	}
	public String getGroupCode() {
		return groupCode;
	}
	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}
	public MultipartFile getUploadCompanyLogoImage() {
		return uploadCompanyLogoImage;
	}
	public void setUploadCompanyLogoImage(MultipartFile uploadCompanyLogoImage) {
		this.uploadCompanyLogoImage = uploadCompanyLogoImage;
	}
	
	public Integer getDistributorId() {
		return distributorId;
	}
	public void setDistributorId(Integer distributorId) {
		this.distributorId = distributorId;
	}
	public Integer getHostId() {
		return hostId;
	}
	public void setHostId(Integer hostId) {
		this.hostId = hostId;
	}
	public Integer getSubDistributorId() {
		return subDistributorId;
	}
	public void setSubDistributorId(Integer subDistributorId) {
		this.subDistributorId = subDistributorId;
	}
	public Integer getRetailerId() {
		return retailerId;
	}
	public void setRetailerId(Integer retailerId) {
		this.retailerId = retailerId;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getHouseNo() {
		return houseNo;
	}
	public void setHouseNo(String houseNo) {
		this.houseNo = houseNo;
	}
	
	
	
	public Integer getCountryId() {
		return countryId;
	}
	public void setCountryId(Integer countryId) {
		this.countryId = countryId;
	}
	
	public String getLandMark() {
		return landMark;
	}
	public void setLandMark(String landMark) {
		this.landMark = landMark;
	} 
	
	public Map<Integer, String> getCountryMap() {
		return countryMap;
	}
	public void setCountryMap(Map<Integer, String> countryMap) {
		this.countryMap = countryMap;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public Integer getStateId() {
		return stateId;
	}
	public void setStateId(Integer stateId) {
		this.stateId = stateId;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public Integer getProtocolId() {
		return protocolId;
	}
	public void setProtocolId(Integer protocolId) {
		this.protocolId = protocolId;
	}
	public Map<Integer, String> getProtocolMap() {
		return protocolMap;
	}
	public void setProtocolMap(Map<Integer, String> protocolMap) {
		this.protocolMap = protocolMap;
	}
	public Integer getRetryNo() {
		return retryNo;
	}
	public void setRetryNo(Integer retryNo) {
		this.retryNo = retryNo;
	}
	public Integer getTrnxTimeOut() {
		return trnxTimeOut;
	}
	public void setTrnxTimeOut(Integer trnxTimeOut) {
		this.trnxTimeOut = trnxTimeOut;
	}
	public String getEncryptionKey() {
		return encryptionKey;
	}
	public void setEncryptionKey(String encryptionKey) {
		this.encryptionKey = encryptionKey;
	}
	public String[] getNameArr() {
		return nameArr;
	}
	public void setNameArr(String[] nameArr) {
		this.nameArr = nameArr;
	}
	public String[] getEmailArr() {
		return emailArr;
	}
	public void setEmailArr(String[] emailArr) {
		this.emailArr = emailArr;
	}
	public String[] getMobileArr() {
		return mobileArr;
	}
	public void setMobileArr(String[] mobileArr) {
		this.mobileArr = mobileArr;
	}
	public String[] getLoginNameArr() {
		return loginNameArr;
	}
	public void setLoginNameArr(String[] loginNameArr) {
		this.loginNameArr = loginNameArr;
	}
	public String[] getPasswordArr() {
		return passwordArr;
	}
	public void setPasswordArr(String[] passwordArr) {
		this.passwordArr = passwordArr;
	}
	public Integer[] getStatusArr() {
		return statusArr;
	}
	public void setStatusArr(Integer[] statusArr) {
		this.statusArr = statusArr;
	}
	public Integer[] getAccountTypeArr() {
		return accountTypeArr;
	}
	public void setAccountTypeArr(Integer[] accountTypeArr) {
		this.accountTypeArr = accountTypeArr;
	}
	public PlatformChain getPlatformChain() {
		return platformChain;
	}
	public void setPlatformChain(PlatformChain platformChain) {
		this.platformChain = platformChain;
	}
	public Integer getPinCode() {
		return pinCode;
	}
	public void setPinCode(Integer pinCode) {
		this.pinCode = pinCode;
	}

	public Integer getParentId() {
		return parentId;
	}

	public void setParentId(Integer parentId) {
		this.parentId = parentId;
	}

	public boolean isAgentstatus() {
		return agentstatus;
	}

	public void setAgentstatus(boolean agentstatus) {
		this.agentstatus = agentstatus;
	}

	public String getParentName() {
		return parentName;
	}

	public void setParentName(String parentName) {
		this.parentName = parentName;
	}

	public String getContactPersonName() {
		return contactPersonName;
	}

	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	

	public String getTxnType() {
		return txnType;
	}

	public Double getHostCommission() {
		return hostCommission;
	}

	public String getSubcategories() {
		return subcategories;
	}

	public void setSubcategories(String subcategories) {
		this.subcategories = subcategories;
	}

	public void setHostCommission(Double hostCommission) {
		this.hostCommission = hostCommission;
	}

	public Double getDistributorCommission() {
		return distributorCommission;
	}

	public void setDistributorCommission(Double distributorCommission) {
		this.distributorCommission = distributorCommission;
	}

	public Double getSubdistributorCommission() {
		return subdistributorCommission;
	}

	public void setSubdistributorCommission(Double subdistributorCommission) {
		this.subdistributorCommission = subdistributorCommission;
	}

	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}

	public List<AccountCreationData> getCompanyList() {
		return companyList;
	}

	public void setCompanyList(List<AccountCreationData> companyList) {
		this.companyList = companyList;
	}

	

	

	

}
