package com.ng.sc.dao.impl;

import java.util.List;

import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.ng.sb.common.dataobject.LoginData;
import com.ng.sb.common.model.AccountLoginInfo;
import com.ng.sb.common.model.AccountSessionInfoSelfCare;
import com.ng.sb.common.model.CountryCode;
import com.ng.sb.common.model.SecurityQuestion;
import com.ng.sb.common.model.SignUpOtp;
import com.ng.sb.common.model.Subscriber;
import com.ng.sb.common.model.SysAccountGroup;
import com.ng.sb.common.model.SysAccountType;
import com.ng.sc.dao.IScLoginDAO;

/**
 * 
 * @author 
 *
 */
@Repository
public class ScLoginDAO extends SelfCareDAO implements IScLoginDAO {

	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = LoggerFactory.getLogger(ScLoginDAO.class);
	public static final String MSISDN = "msisdn";
	/**
	 * @param accountLoginInfo
	 * @returns
	 */
	@Override
	@Transactional
	public boolean updateAccountLoginInfo(Subscriber subscriber) {
		LOGGER.debug("updateAccountLoginInfo");
		boolean flag = false;
		try {
			entityManager.merge(subscriber);
			flag = true;
		} catch (Exception e) {
			LOGGER.info("Exception Occure In Method updateAccountLoginInfo() in ScLoginDAO :" + e);
		}
		return flag;
	}

	/**
	 * @param accountSessionInfo
	 * @return
	 */
	@Override
	@Transactional
	public boolean insertAccountSessionInfo(AccountSessionInfoSelfCare accountSessionInfo) {
		LOGGER.debug("insertAccountSessionInfo");
		boolean flag = false;
		try {
			entityManager.merge(accountSessionInfo);
			flag = true;
		} catch (Exception e) {
			LOGGER.info("Exception Occure In Method insertAccountSessionInfo() in ScLoginDAO :" + e);
		}
		return flag;
	}

	/**
	 * @param accountSessionInfo
	 * @return
	 */
	@Override
	@Transactional
	public boolean updateAccountSessionInfo(AccountSessionInfoSelfCare accountSessionInfo) {
		LOGGER.debug("updateAccountSessionInfo");
		boolean flag = false;
		try {
			LOGGER.info("******Start Method updateAccountSessionInfo() in ScLoginDAO");
			entityManager.merge(accountSessionInfo);
			flag = true;
		} catch (Exception e) {
			LOGGER.info("Exception Occure In Method updateAccountSessionInfo()Execution in updateAccountSessionInfo() :"
					+ e);
		}
		return flag;
	}

	/**
	 * @param accountId
	 * @return
	 */
	@Override
	public List<AccountSessionInfoSelfCare> sessionInfo(int accountId) {
		LOGGER.debug("sessionInfo accountId");
		List<AccountSessionInfoSelfCare> accountLoginInfo ;
		TypedQuery<AccountSessionInfoSelfCare> query = null;
		try {
			LOGGER.info("*********Start Execution of Method sessionInfo() in LoginDAO ");
			query = entityManager.createNamedQuery("AccountSessionInfoSelfCare.findByAccountId",
					AccountSessionInfoSelfCare.class);
			query.setParameter("accountId", new Subscriber(accountId));
			return query.getResultList();

		} catch (Exception exp) {
			accountLoginInfo = null;
			LOGGER.debug("Exception Occure in Method sessionInfo() in LoginDAO : " + exp);
		}

		return accountLoginInfo;
	}

	/**
	 * @return
	 */
	@Override
	public List<SysAccountGroup> accountGroupList() {
		List<SysAccountGroup> sysAccountType = null;
		TypedQuery<SysAccountGroup> query = null;
		LOGGER.info("*****Start Executions Of Method accountList() in LoginDAO ");
		try {
			query = entityManager.createNamedQuery("SysAccountGroup.findByIndex", SysAccountGroup.class);
			return query.getResultList();

		} catch (Exception exp) {
			LOGGER.debug("Exceptions Occure In Method accountList() Execution in LoginDAO"+exp );
		}
		return sysAccountType;
	}

	@Override
	public List<SysAccountGroup> SysAccountGroupByName(String groupName) {
		List<SysAccountGroup> sysAccountType = null;
		TypedQuery<SysAccountGroup> query = null;
		LOGGER.info("*****Start Executions Of Method accountList() in LoginDAO ");
		try {
			query = entityManager.createNamedQuery("SysAccountGroup.findByGroupName", SysAccountGroup.class);
			query.setParameter("groupName", groupName);
			return query.getResultList();

		} catch (Exception exp) {
			LOGGER.debug("Exceptions Occure In Method accountList() Execution in LoginDAO"+exp);
		}
		return sysAccountType;
	}

	@Override
	public List<SysAccountType> accountById(int groupId) {
		List<SysAccountType> sysAccountType = null;
		TypedQuery<SysAccountType> query = null;
		LOGGER.info("*****Start Execution Of Method accountList() in LoginDAO ");
		try {
			query = entityManager.createNamedQuery("SysAccountType.findByGroupId", SysAccountType.class);
			query.setParameter("groupId", groupId);
			return query.getResultList();

		} catch (Exception exp) {
			LOGGER.debug("Exception Occure In Method accountList() Execution in LoginDAO"+exp);
		}
		return sysAccountType;
	}

	@Override
	public List<SysAccountType> accountList() {
		List<SysAccountType> sysAccountType = null;
		TypedQuery<SysAccountType> query = null;
		LOGGER.info("*****Start Execution Of Method accountList() in LoginDAO ");
		try {
			query = entityManager.createNamedQuery("SysAccountType.findAll", SysAccountType.class);
			return query.getResultList();

		} catch (Exception exp) {
			LOGGER.debug("Exception Occure In Method accountList() Execution in LoginDAO"
					+ exp);
		}
		return sysAccountType;
	}

	/**
	 * @param loginName
	 * @return
	 * @throws Exception
	 */
	@Override
	public AccountLoginInfo accountLoginInfo(String loginName) throws Exception {
		LOGGER.debug("AccountLoginInfo");
		AccountLoginInfo accountLoginInfo ;
		TypedQuery<AccountLoginInfo> query = null;
		try {
			LOGGER.info("***************Start Method accountLoginInfo() in LoginDAO");
			query = entityManager.createNamedQuery("AccountLoginInfo.findByLoginName", AccountLoginInfo.class);
			query.setParameter("loginName", loginName);
			return query.getSingleResult();

		} catch (Exception exp) {
			LOGGER.info("Exception Occure in Method accountLoginInfo() in loginDAO :" + exp);
			accountLoginInfo = null;
		}

		return accountLoginInfo;
	}

	@Override
	public Subscriber accountByLoginInfo(String loginName) throws Exception {
		LOGGER.debug("Subscriber");
		Subscriber subscriber = null;
		TypedQuery<Subscriber> query = null;
		try {
			LOGGER.info("***************Start Method accountByLoginInfo() in ScLoginDAO");
			query = entityManager.createNamedQuery("Subscriber.findByMsisdn", Subscriber.class);
			query.setParameter(MSISDN, loginName);
			subscriber = query.getSingleResult();

		} catch (Exception exp) {
			LOGGER.info("Exception Occure in Method accountByLoginInfo() in ScloginDAO :" + exp);
		}

		return subscriber;
	}
	/**
	 * @param loginData
	 * @return
	 * @throws Exception
	 */
	@Override
	public AccountSessionInfoSelfCare accountSessionInfo(LoginData loginData) throws Exception {
		LOGGER.debug("sessionInfo getAccountTypeId:: " + loginData.getAccountTypeId()
				+ " ::: loginData.getSessionId():: " + loginData.getSessionId() + " ::: loginData.getUserLoginId():: "
				+ loginData.getUserLoginId());

		AccountSessionInfoSelfCare accountLoginInfoSelfCare = new AccountSessionInfoSelfCare();
		TypedQuery<AccountSessionInfoSelfCare> query = null;
		try {
			
			
			
			LOGGER.info("***********Start Method accountSessionInfo() in ScLoginDAO");
			query = entityManager.createNamedQuery("AccountSessionInfoSelfCare.findByAccountIdAndSessionKey",
					AccountSessionInfoSelfCare.class);
			
			
			query.setParameter("accountId", new Subscriber(loginData.getAccountTypeId()));
			query.setParameter("randSessionKey", loginData.getSessionId());
			
			
			
			accountLoginInfoSelfCare = query.getSingleResult();

		} catch (Exception exp) {
			LOGGER.debug("Exception Occure in Method  AccountSessionInfoSelfCare() Execution in ScLoginDao :" + exp);
		}
		return accountLoginInfoSelfCare;
	}

	@Override
	public List<SecurityQuestion> getSecurityQuestion() throws Exception {
		List<SecurityQuestion> questionList = null;
		TypedQuery<SecurityQuestion> query = null;
		try {
			LOGGER.info("**********Start Method getSecurityQuestion() in DAO");

			query = entityManager.createNamedQuery("SecurityQuestion.findAllQuestion", SecurityQuestion.class);
			questionList = query.getResultList();
			LOGGER.info("*****Method getSecurityQuestion()  Execution done successfully in DAO");
		} catch (Exception e) {
			LOGGER.info("***Exception Ocure in Method getSecurityQuestion()  Execution in DAO  :"
					+ e);
		}
		return questionList;
	}

	@Override
	public AccountLoginInfo validatePassExp(String username) throws Exception {

		TypedQuery<AccountLoginInfo> query = null;
		AccountLoginInfo accountLoginInfo=null;
		try {
			query = entityManager.createNamedQuery("AccountLoginInfo.findByloginName", AccountLoginInfo.class);
			query.setParameter("name", username);
			accountLoginInfo=query.getSingleResult();
		} catch (Exception e) {
			LOGGER.info(""+e);
		}
		
			return accountLoginInfo;
		
	}

	@Override
	public List<SysAccountType> getRoleAccountistByWeightage(Integer loginWeightage) throws Exception {
		List<SysAccountType> sysAccountTypeList = null;
		TypedQuery<SysAccountType> query = null;
		try {
			LOGGER.info("**********Start Method getRoleAccountistByWeightage() in UserMgmntDAO");
			query = entityManager.createNamedQuery("SysAccountType.findByWeightage", SysAccountType.class);
			query.setParameter("hWeight", loginWeightage);
			query.setParameter("lWeight", 0);
			sysAccountTypeList = query.getResultList();
			LOGGER.info("*****Method getRoleAccountistByWeightage()  Execution done successfully in UserMgmntDAO");
		} catch (Exception e) {
			LOGGER.info("***Exception Ocure in Method getRoleAccountistByWeightage()  Execution in UserMgmntDAO  :"
					+ e);
		}
		return sysAccountTypeList;
	}

	@Override
	public List<Subscriber> checkUniqueMobileNo(String userMobile) throws Exception {
		TypedQuery<Subscriber> query = null;
		List<Subscriber> subscriber = null;
		LOGGER.info("***** start of checkUniqueMobileNo() method in ScLoginDAO *****");
		try {
			LOGGER.info("***** start of checkUniqueMobileNo() method in ScLoginDAO *****");
			query = entityManager.createNamedQuery("Subscriber.findByMsisdn", Subscriber.class);
			query.setParameter(MSISDN, userMobile);
			subscriber = query.getResultList();
		} catch (Exception ex) {
			LOGGER.info("Exception occurred in checkUniqueMobileNo() method in ScLoginDAO--->" + ex);
		}
		LOGGER.info("***** End of checkUniqueMobileNo() method in ScLoginDAO *****");
		return subscriber;
	}

	@Override
	public List<AccountLoginInfo> checkUniqueLoginId(String userLoginName) throws Exception {
		TypedQuery<AccountLoginInfo> query = null;
		List<AccountLoginInfo> accountLoginInfoList = null;
		LOGGER.info("***** start of validateSecurityQuestionCheckv() method in UserMgmntDAO *****");
		try {
			LOGGER.info("***** start of validateSecurityQuestionCheck() dmethod in UserMgmntDAO *****");
			query = entityManager.createNamedQuery("AccountLoginInfo.findByLoginName", AccountLoginInfo.class);
			query.setParameter("loginName", userLoginName);
			accountLoginInfoList = query.getResultList();
		} catch (Exception ex) {
			LOGGER.info("Exception occurred in validateSecurityQuestionCheck() method in UserMgmntDAO--->"
					+ ex);
		}
		LOGGER.info("***** End of validateSecurityQuestionCheck() method in UserMgmntDAO *****");
		return accountLoginInfoList;
	}

	@Override
	public List<AccountLoginInfo> checkUniqueEmailId(String userEmailId) throws Exception {
		TypedQuery<AccountLoginInfo> query = null;
		List<AccountLoginInfo> accountLoginInfoList = null;
		LOGGER.info("***** start of validateSecurityQuestionCheck() method in UserMgmntDAO *****");
		try {
			LOGGER.info("***** start of validateSecurityQuestionCheck() method in UserMgmntDAO *****");
			query = entityManager.createNamedQuery("AccountLoginInfo.findByEmailId", AccountLoginInfo.class);
			query.setParameter("emailId", userEmailId);
			accountLoginInfoList = query.getResultList();
		} catch (Exception ex) {
			LOGGER.info("Exception occurred in validateSecurityQuestionCheck() method in UserMgmntDAO--->"
					+ ex);
		}
		LOGGER.info("***** End of validateSecurityQuestionCheck() method in UserMgmntDAO *****");
		return accountLoginInfoList;
	}

	@Override
	public Subscriber saveUserCreation(Subscriber subscriber) throws Exception {
		LOGGER.info("*****Start Execution Of Method saveUserCreation() in UserMgmntDAO ");
		try {
			LOGGER.debug("<**************** Execution start for saveUserCreation() *******************>");
			entityManager.persist(subscriber);
			LOGGER.debug("<**************** Exit from saveUserCreation() *******************>");
		} catch (Exception exp) {
			LOGGER.debug("Exception Occure In Method saveUserCreation() Execution in UserMgmntDAO : " + exp);
		}
		LOGGER.info("*****Successfully executed Method saveUserCreation() in UserMgmntDAO ");
		return subscriber;
	}

	@Override
	public List<CountryCode> getCountryCodeMap() {
		List<CountryCode> codeList = null;
		TypedQuery<CountryCode> query = null;

		try {
			LOGGER.info("**********Start Method getCountryCodeMap() in DAO");

			query = entityManager.createNamedQuery("CountryCode.findAll", CountryCode.class);
			codeList = query.getResultList();
			LOGGER.info("*****Method getCountryCodeMap()  Execution done successfully in DAO");
		} catch (Exception e) {
			LOGGER.info("***Exception Ocure in Method getCountryCodeMap()  Execution in DAO  :"
					+ e);
		}
		return codeList;

	}

	@Override
	@Transactional
	public void saveSignupDetails(SignUpOtp signupDetails) throws Exception {
		LOGGER.info("****Start Execution Of Method saveSignupDetails() ");
		try {
			LOGGER.debug("<********** Execution start for saveSignupDetails() *******************>");
			entityManager.persist(signupDetails);
			LOGGER.debug("<**************** Exit from saveSignupDetails() *****************>");
		} catch (Exception exp) {
			LOGGER.debug("Exception Occure In Method saveSignupDetails(): " + exp);
		}
		LOGGER.info("*****Successfully executed Method saveSignupDetails() ");
		
	}

	@Override
	public SignUpOtp getSignUpinfo(String mobile) throws Exception {
		TypedQuery<SignUpOtp> query = null;
		SignUpOtp signUpOtpInfo = null;
		LOGGER.info("***** start of getSignUpinfo() method *****");
		try {
			LOGGER.info("***** start of getSignUpinfo() method in UserMgmntDAO *****");
			query = entityManager.createNamedQuery("SignUpOtp.findByMobileNumberAndStatus", SignUpOtp.class);
			query.setParameter("mobileNumber", mobile);
			signUpOtpInfo = query.getSingleResult();
		} catch (Exception ex) {
			LOGGER.info("Exception occurred in getSignUpinfo() method--->"
					+ ex);
		}
		LOGGER.info("***** End of getSignUpinfo() method*****");
		return signUpOtpInfo;
	}

	@Override
	public void updateSignUpDetails(String mobile) throws Exception {
		LOGGER.info("*********** updateSignUpDetails() starts executing in DAO *************");
		try{
			String sql = "Update SignUpOtp s SET s.status=0 where s.mobileNumber=:mobileNumber";
			Query query;
			query = entityManager.createQuery(sql);
			query.setParameter("mobileNumber", mobile);
			query.executeUpdate();
		}catch(Exception e){
			LOGGER.info("Exception in  updateSignUpDetails "+e);
		}
		
	}

	@Override
	@Transactional
	public void updateTimeoutOtp(int otp) throws Exception {
		LOGGER.info("*********** updateTimeoutOtp() starts executing in DAO *************");
		try{
			String sql = "Update SignUpOtp s SET s.status=0 where s.otpp=:otp";
			Query query;
			query = entityManager.createQuery(sql);
			query.setParameter("otp",otp);
			query.executeUpdate();
		}catch(Exception e){
			LOGGER.info("Exception in  updateTimeoutOtp "+e);
		}
		
	}

	@Override
	public Subscriber updateSubscriberInfo(Subscriber subscriber) {
		LOGGER.info("*********** updateTimeoutOtp() starts executing in DAO *************");
		try{
			
			
			String sql = "Update Subscriber s SET s.emailId = aes_encrypt(:emailId, s.aamsisdn), s.userPassword = :userPassword, s.status= :status, s.name=aes_encrypt(:name, s.aamsisdn), s.surname=aes_encrypt(:lastName, s.aamsisdn), s.dateOfBirth =aes_encrypt(:dob, s.aamsisdn), s.invalidLoginCount=0, s.firstTimeLogin=1 where s.aamsisdn = :msisdn";Query query;
			query = entityManager.createQuery(sql);
			query.setParameter(MSISDN,subscriber.getMsisdn());
			query.setParameter("name",subscriber.getName());
			query.setParameter("lastName",subscriber.getSurname());
			query.setParameter("dob",subscriber.getDateOfBirth());
			query.setParameter("emailId",subscriber.getEmailId());
			query.setParameter("userPassword",subscriber.getUserPassword());
			query.setParameter("status","ACTIVE");
			
			query.executeUpdate();
		}catch(Exception e){
			LOGGER.info("Exception in  updateTimeoutOtp "+e);
		}
		return subscriber;
		
	}

}
