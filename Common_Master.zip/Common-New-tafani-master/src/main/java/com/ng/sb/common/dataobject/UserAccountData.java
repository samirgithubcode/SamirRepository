package com.ng.sb.common.dataobject;

import java.sql.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.ng.sb.common.model.AccountLoginInfo;
import com.ng.sb.common.model.Subscriber;

/**
 * 
 * @author Amar Creating a data object to set the acountLoginInfoData for the
 *         iteration in the list
 */
public class UserAccountData extends BaseObjectData {

	private static final long serialVersionUID = 1L;
	private String tokenId;
	private String rePassword;
	private String newPassword;
	private String dateOfBirth;
	private Date dob;
	private String userNameorEmail;
	private String securityQuestion;
	private Integer securityQuestionId;
	private String answer;
	private String accountTypeId;
	private transient Map accountTypeMap;

	private String secretKey;
	private int channelId;
	private int loginId;
	private int userType;
	private int accountId;
	private int parentId;
	private Integer companyId;

	private Integer countryCodeId;
	private Integer altCountryCodeId;
	private Integer numberofrow;
	private Integer gotopage;
	private Integer settlementType;
	private Integer hostId;
	private String hostName;
	private Integer distributorId;
	private String distName;
	private Integer subDistributorId;
	private String subDistName;
	private Integer retailerId;
	private String retailerName;
	private Integer bcId;
	private String bcName;
	private String userName;
	private String userLoginName;
	private String userPassword;
	private String userEmailId;
	private String userMobile;
	private String altMobile;
	private int userTypeId;
	private String newPasswd;
	private String currentPasswd;
	private Integer otpOnSignUp;
	private String firstName;
	private String lastName;
	private String view;
	private Map hostMap;
	private Map distributorMap;
	private Map subDistributorMap;
	private Map retailorMap;
	private Map bcMap;
	private Map childAccountListMap;
	private String userGroupCode;
	private String msg;
	private String errorMsg;
	private String emailMsg;
	private String mobileMsg;
	private String userIdMsg;
	private String groupCode;
	private String nickName;
	private List<UserAccountData> accountTypeList;
	private String resetBy;
	private String userCredintial;

	private String mobileNo;
	private String emailId;
	private String loginName;
	private String cnfPassword;
	private String securityAnswer;
	private String currentPassword;

	private boolean validUserStatus;
	private boolean changePasswordStatus;
	private String address;
	private String locality;
	private String district;
	private String state;
	private String country;
	private String region;
	
	private Integer pinCode;
	private String txnNature;
	private List<SubscriberData> subscriberList;
	private List<AccountLoginInfo> userlist;
	
	private Set<String> mappedServices;
	
	private String estelDestination;
	
	private String estelPin;
	
	private String deviceId; 
	
	public String getTokenId() {
		return tokenId;
	}
	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}
	public String getTxnNature() {
		return txnNature;
	}

	public void setTxnNature(String txnNature) {
		this.txnNature = txnNature;
	}

	public String getNewPasswd() {
		return newPasswd;
	}

	public void setNewPasswd(String newPasswd) {
		this.newPasswd = newPasswd;
	}

	public String getCurrentPasswd() {
		return currentPasswd;
	}

	public void setCurrentPasswd(String currentPasswd) {
		this.currentPasswd = currentPasswd;
	}

	public int getUserTypeId() {
		return userTypeId;
	}

	public void setUserTypeId(int userTypeId) {
		this.userTypeId = userTypeId;
	}

	public Integer getSettlementType() {
		return settlementType;
	}

	public void setSettlementType(Integer settlementType) {
		this.settlementType = settlementType;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Integer getOtpOnSignUp() {
		return otpOnSignUp;
	}

	public void setOtpOnSignUp(Integer otpOnSignUp) {
		this.otpOnSignUp = otpOnSignUp;
	}

	public String getView() {
		return view;
	}

	public void setView(String view) {
		this.view = view;
	}

	public Integer getGotopage() {
		return gotopage;
	}

	public void setGotopage(Integer gotopage) {
		this.gotopage = gotopage;
	}

	public Integer getNumberofrow() {
		return numberofrow;
	}

	public void setNumberofrow(Integer numberofrow) {
		this.numberofrow = numberofrow;
	}

	public Integer getCountryCodeId() {
		return countryCodeId;
	}

	public void setCountryCodeId(Integer countryCodeId) {
		this.countryCodeId = countryCodeId;
	}

	public Integer getAltCountryCodeId() {
		return altCountryCodeId;
	}

	public void setAltCountryCodeId(Integer altCountryCodeId) {
		this.altCountryCodeId = altCountryCodeId;
	}

	public Integer getSecurityQuestionId() {
		return securityQuestionId;
	}

	public void setSecurityQuestionId(Integer securityQuestionId) {
		this.securityQuestionId = securityQuestionId;
	}

	public String getNickName() {
		return nickName;
	}

	public void setNickName(String nickName) {
		this.nickName = nickName;
	}

	public String getGroupCode() {
		return groupCode;
	}

	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	/**
	 * @return the emailMsg
	 */
	public String getEmailMsg() {
		return emailMsg;
	}

	/**
	 * @param emailMsg
	 *            the emailMsg to set
	 */
	public void setEmailMsg(String emailMsg) {
		this.emailMsg = emailMsg;
	}

	/**
	 * @return the mobileMsg
	 */
	public String getMobileMsg() {
		return mobileMsg;
	}

	/**
	 * @param mobileMsg
	 *            the mobileMsg to set
	 */
	public void setMobileMsg(String mobileMsg) {
		this.mobileMsg = mobileMsg;
	}

	/**
	 * @return the userIdMsg
	 */
	public String getUserIdMsg() {
		return userIdMsg;
	}

	/**
	 * @param userIdMsg
	 *            the userIdMsg to set
	 */
	public void setUserIdMsg(String userIdMsg) {
		this.userIdMsg = userIdMsg;
	}

	public List<UserAccountData> getAccountTypeList() {
		return accountTypeList;
	}

	public void setAccountTypeList(List<UserAccountData> accountTypeList) {
		this.accountTypeList = accountTypeList;
	}

	public String getHostName() {
		return hostName;
	}

	public void setHostName(String hostName) {
		this.hostName = hostName;
	}

	public String getDistName() {
		return distName;
	}

	public void setDistName(String distName) {
		this.distName = distName;
	}

	public String getSubDistName() {
		return subDistName;
	}

	public void setSubDistName(String subDistName) {
		this.subDistName = subDistName;
	}

	public String getRetailerName() {
		return retailerName;
	}

	public void setRetailerName(String retailerName) {
		this.retailerName = retailerName;
	}

	public String getBcName() {
		return bcName;
	}

	public void setBcName(String bcName) {
		this.bcName = bcName;
	}

	// ******Reset password Data*****

	// ********FirstTime Login Data******

	public String getResetBy() {
		return resetBy;
	}

	public void setResetBy(String resetBy) {
		this.resetBy = resetBy;
	}

	public String getUserCredintial() {
		return userCredintial;
	}

	public void setUserCredintial(String userCredintial) {
		this.userCredintial = userCredintial;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getLoginName() {
		return loginName;
	}

	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	public String getCnfPassword() {
		return cnfPassword;
	}

	public void setCnfPassword(String cnfPassword) {
		this.cnfPassword = cnfPassword;
	}

	public String getSecurityAnswer() {
		return securityAnswer;
	}

	public void setSecurityAnswer(String securityAnswer) {
		this.securityAnswer = securityAnswer;
	}

	public String getCurrentPassword() {
		return currentPassword;
	}

	public void setCurrentPassword(String currentPassword) {
		this.currentPassword = currentPassword;
	}

	public boolean isValidUserStatus() {
		return validUserStatus;
	}

	public void setValidUserStatus(boolean validUserStatus) {
		this.validUserStatus = validUserStatus;
	}

	public boolean isChangePasswordStatus() {
		return changePasswordStatus;
	}

	public void setChangePasswordStatus(boolean changePasswordStatus) {
		this.changePasswordStatus = changePasswordStatus;
	}

	public String getAccountTypeId() {
		return accountTypeId;
	}

	public void setAccountTypeId(String accountTypeId) {
		this.accountTypeId = accountTypeId;
	}

	public Map getAccountTypeMap() {
		return accountTypeMap;
	}

	public void setAccountTypeMap(Map accountTypeMap) {
		this.accountTypeMap = accountTypeMap;
	}

	public Map getHostMap() {
		return hostMap;
	}

	public void setHostMap(Map hostMap) {
		this.hostMap = hostMap;
	}

	public Map getDistributorMap() {
		return distributorMap;
	}

	public void setDistributorMap(Map distributorMap) {
		this.distributorMap = distributorMap;
	}

	public Map getSubDistributorMap() {
		return subDistributorMap;
	}

	public void setSubDistributorMap(Map subDistributorMap) {
		this.subDistributorMap = subDistributorMap;
	}

	public Map getRetailorMap() {
		return retailorMap;
	}

	public void setRetailorMap(Map retailorMap) {
		this.retailorMap = retailorMap;
	}

	public Map getBcMap() {
		return bcMap;
	}

	public void setBcMap(Map bcMap) {
		this.bcMap = bcMap;
	}

	public Map getChildAccountListMap() {
		return childAccountListMap;
	}

	public void setChildAccountListMap(Map childAccountListMap) {
		this.childAccountListMap = childAccountListMap;
	}

	public String getUserGroupCode() {
		return userGroupCode;
	}

	public void setUserGroupCode(String userGroupCode) {
		this.userGroupCode = userGroupCode;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public String getUserNameorEmail() {
		return userNameorEmail;
	}

	public void setUserNameorEmail(String userNameorEmail) {
		this.userNameorEmail = userNameorEmail;
	}

	public String getNewPassword() {
		return newPassword;
	}

	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public String getSecurityQuestion() {
		return securityQuestion;
	}

	public void setSecurityQuestion(String securityQuestion) {
		this.securityQuestion = securityQuestion;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getRePassword() {
		return rePassword;
	}

	public void setRePassword(String rePassword) {
		this.rePassword = rePassword;
	}

	public Integer getDistributorId() {
		return distributorId;
	}

	public void setDistributorId(Integer distributorId) {
		this.distributorId = distributorId;
	}

	public Integer getSubDistributorId() {
		return subDistributorId;
	}

	public void setSubDistributorId(Integer subDistributorId) {
		this.subDistributorId = subDistributorId;
	}

	public Integer getHostId() {
		return hostId;
	}

	public void setHostId(Integer hostId) {
		this.hostId = hostId;
	}

	public Integer getRetailerId() {
		return retailerId;
	}

	public void setRetailerId(Integer retailerId) {
		this.retailerId = retailerId;
	}

	public Integer getBcId() {
		return bcId;
	}

	public void setBcId(Integer bcId) {
		this.bcId = bcId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserLoginName() {
		return userLoginName;
	}

	public void setUserLoginName(String userLoginName) {
		this.userLoginName = userLoginName;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public String getUserEmailId() {
		return userEmailId;
	}

	public void setUserEmailId(String userEmailId) {
		this.userEmailId = userEmailId;
	}

	public String getUserMobile() {
		return userMobile;
	}

	public void setUserMobile(String userMobile) {
		this.userMobile = userMobile;
	}

	public String getAltMobile() {
		return altMobile;
	}

	public void setAltMobile(String altMobile) {
		this.altMobile = altMobile;
	}

	public String getSecretKey() {
		return secretKey;
	}

	public void setSecretKey(String secretKey) {
		this.secretKey = secretKey;
	}

	public int getChannelId() {
		return channelId;
	}

	public void setChannelId(int channelId) {
		this.channelId = channelId;
	}

	public int getLoginId() {
		return loginId;
	}

	public void setLoginId(int loginId) {
		this.loginId = loginId;
	}

	public int getUserType() {
		return userType;
	}

	public void setUserType(int userType) {
		this.userType = userType;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getLocality() {
		return locality;
	}

	public void setLocality(String locality) {
		this.locality = locality;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public Integer getPinCode() {
		return pinCode;
	}

	public void setPinCode(Integer pinCode) {
		this.pinCode = pinCode;
	}

	public int getAccountId() {
		return accountId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}

	public int getParentId() {
		return parentId;
	}

	public void setParentId(int parentId) {
		this.parentId = parentId;
	}

	public Integer getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public List<SubscriberData> getSubscriberList() {
		return subscriberList;
	}

	public void setSubscriberList(List<SubscriberData> subscriberList) {
		this.subscriberList = subscriberList;
	}

	public List<AccountLoginInfo> getUserlist() {
		return userlist;
	}

	public void setUserlist(List<AccountLoginInfo> userlist) {
		this.userlist = userlist;
	}
	public Set<String> getMappedServices() {
		return mappedServices;
	}
	public void setMappedServices(Set<String> mappedServices) {
		this.mappedServices = mappedServices;
	}
	public String getEstelDestination() {
		return estelDestination;
	}
	public void setEstelDestination(String estelDestination) {
		this.estelDestination = estelDestination;
	}
	public String getEstelPin() {
		return estelPin;
	}
	public void setEstelPin(String estelPin) {
		this.estelPin = estelPin;
	}
	public String getDeviceId() {
		return deviceId;
	}
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	

}
