/**
 * 
 */
package com.ng.bridge.dao;

import com.ng.sb.common.model.ThirdPartySubsRecipient;
import com.ng.sb.common.model.ThirdPartySubscriber;

/**
 * @author ram
 * This dao deals with the customer data
 *
 */
public interface ICustomerDAO {
	public ThirdPartySubscriber checkMobileNumber(String mobile,Integer walletId) ;
	public ThirdPartySubsRecipient getRecipient(int tpsId,String bankAccount,String ifscCode) ;
	public Object saveObject(Object object) ;
}
