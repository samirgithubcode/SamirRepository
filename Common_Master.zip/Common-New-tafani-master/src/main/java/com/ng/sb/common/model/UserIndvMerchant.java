/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "userIndvMerchant")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "UserIndvMerchant.findAll", query = "SELECT u FROM UserIndvMerchant u"),
    @NamedQuery(name = "UserIndvMerchant.findById", query = "SELECT u FROM UserIndvMerchant u WHERE u.id = :id"),
    @NamedQuery(name = "UserIndvMerchant.findByMsisdn", query = "SELECT u FROM UserIndvMerchant u WHERE u.msisdn = :msisdn"),
    @NamedQuery(name = "UserIndvMerchant.findByIndvName", query = "SELECT u FROM UserIndvMerchant u WHERE u.indvName = :indvName"),
    @NamedQuery(name = "UserIndvMerchant.findByIndvNickName", query = "SELECT u FROM UserIndvMerchant u WHERE u.indvNickName = :indvNickName"),
    @NamedQuery(name = "UserIndvMerchant.findByIndvIFSC", query = "SELECT u FROM UserIndvMerchant u WHERE u.indvIFSC = :indvIFSC"),
    @NamedQuery(name = "UserIndvMerchant.findByIndvBankAccNumber", query = "SELECT u FROM UserIndvMerchant u WHERE u.indvBankAccNumber = :indvBankAccNumber"),
    @NamedQuery(name = "UserIndvMerchant.findByIndvWCode", query = "SELECT u FROM UserIndvMerchant u WHERE u.indvWCode = :indvWCode"),
    @NamedQuery(name = "UserIndvMerchant.findByIndvMsisdn", query = "SELECT u FROM UserIndvMerchant u WHERE u.indvMsisdn = :indvMsisdn"),
    @NamedQuery(name = "UserIndvMerchant.findByIndvMmid", query = "SELECT u FROM UserIndvMerchant u WHERE u.indvMmid = :indvMmid"),
    @NamedQuery(name = "UserIndvMerchant.findByIndvCCNickName", query = "SELECT u FROM UserIndvMerchant u WHERE u.indvCCNickName = :indvCCNickName"),
    @NamedQuery(name = "UserIndvMerchant.findByIndvCCNumber", query = "SELECT u FROM UserIndvMerchant u WHERE u.indvCCNumber = :indvCCNumber"),
    @NamedQuery(name = "UserIndvMerchant.findByIndvCCName", query = "SELECT u FROM UserIndvMerchant u WHERE u.indvCCName = :indvCCName"),
    @NamedQuery(name = "UserIndvMerchant.findByIndvCCExpDate", query = "SELECT u FROM UserIndvMerchant u WHERE u.indvCCExpDate = :indvCCExpDate"),
    @NamedQuery(name = "UserIndvMerchant.findByType", query = "SELECT u FROM UserIndvMerchant u WHERE u.type = :type")})
public class UserIndvMerchant implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
    @Basic(optional = false)
    @Column(name = "msisdn", nullable = false, length = 25)
    private String msisdn;
    @Basic(optional = false)
    @Column(name = "indvName", nullable = false, length = 50)
    private String indvName;
    @Column(name = "indvNickName", length = 50)
    private String indvNickName;
    @Column(name = "indvIFSC", length = 15)
    private String indvIFSC;
    @Column(name = "indvBankAccNumber", length = 25)
    private String indvBankAccNumber;
    @Column(name = "indvWCode")
    private Integer indvWCode;
    @Column(name = "indvMsisdn", length = 25)
    private String indvMsisdn;
    @Column(name = "indvMmid")
    private Integer indvMmid;
    @Column(name = "indvCCNickName", length = 25)
    private String indvCCNickName;
    @Column(name = "indvCCNumber", length = 16)
    private String indvCCNumber;
    @Column(name = "indvCCName", length = 50)
    private String indvCCName;
    @Column(name = "indvCCExpDate")
    private Integer indvCCExpDate;
    @Basic(optional = false)
    @Column(name = "type", nullable = false, length = 11)
    private String type;
    @JoinColumn(name = "userId", referencedColumnName = "id", nullable = false)
    @ManyToOne(optional = false)
    private Subscriber userId;

    public UserIndvMerchant() {
    	//default constructor
    }

    public UserIndvMerchant(Integer id) {
        this.id = id;
    }

    public UserIndvMerchant(Integer id, String msisdn, String indvName, String type) {
        this.id = id;
        this.msisdn = msisdn;
        this.indvName = indvName;
        this.type = type;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMsisdn() {
        return msisdn;
    }

    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }

    public String getIndvName() {
        return indvName;
    }

    public void setIndvName(String indvName) {
        this.indvName = indvName;
    }

    public String getIndvNickName() {
        return indvNickName;
    }

    public void setIndvNickName(String indvNickName) {
        this.indvNickName = indvNickName;
    }

    public String getIndvIFSC() {
        return indvIFSC;
    }

    public void setIndvIFSC(String indvIFSC) {
        this.indvIFSC = indvIFSC;
    }

    public String getIndvBankAccNumber() {
        return indvBankAccNumber;
    }

    public void setIndvBankAccNumber(String indvBankAccNumber) {
        this.indvBankAccNumber = indvBankAccNumber;
    }

    public Integer getIndvWCode() {
        return indvWCode;
    }

    public void setIndvWCode(Integer indvWCode) {
        this.indvWCode = indvWCode;
    }

    public String getIndvMsisdn() {
        return indvMsisdn;
    }

    public void setIndvMsisdn(String indvMsisdn) {
        this.indvMsisdn = indvMsisdn;
    }

    public Integer getIndvMmid() {
        return indvMmid;
    }

    public void setIndvMmid(Integer indvMmid) {
        this.indvMmid = indvMmid;
    }

    public String getIndvCCNickName() {
        return indvCCNickName;
    }

    public void setIndvCCNickName(String indvCCNickName) {
        this.indvCCNickName = indvCCNickName;
    }

    public String getIndvCCNumber() {
        return indvCCNumber;
    }

    public void setIndvCCNumber(String indvCCNumber) {
        this.indvCCNumber = indvCCNumber;
    }

    public String getIndvCCName() {
        return indvCCName;
    }

    public void setIndvCCName(String indvCCName) {
        this.indvCCName = indvCCName;
    }

    public Integer getIndvCCExpDate() {
        return indvCCExpDate;
    }
    

    public Subscriber getUserId() {
        return userId;
    }

    public void setUserId(Subscriber userId) {
        this.userId = userId;
    }

    public void setIndvCCExpDate(Integer indvCCExpDate) {
        this.indvCCExpDate = indvCCExpDate;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }


    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof UserIndvMerchant)) {
            return false;
        }
        UserIndvMerchant other = (UserIndvMerchant) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;	
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.UserIndvMerchant[ id=" + id + " ]";
    }
    
}
