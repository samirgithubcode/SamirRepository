/**
 * 
 */
package com.ng.transaction.service.impl;

import java.lang.reflect.InvocationTargetException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ng.sb.common.dataobject.BridgeDataObject;
import com.ng.sb.common.dataobject.ReflectionData;
import com.ng.transaction.service.IServiceInvoker;
import com.ng.transaction.util.ServiceIdentifierMetaData;

/**
 * @author gaurav
 *
 */
public class ServiceInvoker extends TransactionService implements IServiceInvoker {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ServiceInvoker.class);
	
	private static IServiceInvoker instance = new ServiceInvoker();
	public ServiceInvoker(){
		
	}
	
	public static IServiceInvoker getInstance(){
		return instance;
	}
	
	@Override
	public BridgeDataObject invoke(BridgeDataObject bridgeDataObject) throws IllegalAccessException,IllegalArgumentException,InvocationTargetException{
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In ServiceInvoker -  invoke method. ");
		if(bridgeDataObject!=null && bridgeDataObject.getServiceType()!=null && bridgeDataObject.getServiceCall()!=null){
			return invoker(bridgeDataObject);
		}
		return null;
	}
	
	
	private BridgeDataObject invoker(BridgeDataObject bridgeDataObject) throws IllegalAccessException,IllegalArgumentException,InvocationTargetException {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In ServiceInvoker -  invoker method. ");
		ReflectionData reflectionData = ServiceIdentifierMetaData.getInstance().getMethodToInvoke(bridgeDataObject.getServiceCall(),bridgeDataObject.getServiceType());
		//try {
			if(reflectionData!=null && reflectionData.getClassIdentifier()!=null && reflectionData.getMethod()!=null){
				return (BridgeDataObject)reflectionData.getMethod().invoke(reflectionData.getClassIdentifier(), bridgeDataObject);
			}

		return null;
	}
	
}
