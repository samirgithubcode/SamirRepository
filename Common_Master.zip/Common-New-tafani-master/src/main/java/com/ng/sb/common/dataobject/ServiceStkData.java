package com.ng.sb.common.dataobject;

import java.io.Serializable;

public class ServiceStkData implements Serializable{

	private int serviceId;
	private String serviceName;
	
	public int getServiceId() {
		return serviceId;
	}
	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}
	public String getServiceName() {
		return serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
}
