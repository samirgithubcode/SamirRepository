package com.ng.sb.common.dataobject;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "WalletListResponseData")

public class WalletListResponseData  implements ValidationBean {

private static final long serialVersionUID = 1L;
private String message;
private String status;
private String errorList;
private String name;
private String walletbalance;
private String walletid;
private Integer refundAmount;
public String getMessage() {
	return message;
}
public void setMessage(String message) {
	this.message = message;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}

public String getErrorList() {
	return errorList;
}
public void setErrorList(String errorList) {
	this.errorList = errorList;
}
public Integer getRefundAmount() {
	return refundAmount;
}
public void setRefundAmount(Integer refundAmount) {
	this.refundAmount = refundAmount;
}
public String getWalletbalance() {
	return walletbalance;
}
public void setWalletbalance(String walletbalance) {
	this.walletbalance = walletbalance;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getWalletid() {
	return walletid;
}
public void setWalletid(String walletid) {
	this.walletid = walletid;
}
	
	
	
}
