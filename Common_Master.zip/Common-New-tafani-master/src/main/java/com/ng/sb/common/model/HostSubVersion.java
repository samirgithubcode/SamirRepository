/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Collection;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "HostSubVersion")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "HostSubVersion.findAll", query = "SELECT h FROM HostSubVersion h"),
    @NamedQuery(name = "HostSubVersion.findById", query = "SELECT h FROM HostSubVersion h WHERE h.id = :id"),
    @NamedQuery(name = "HostSubVersion.findByName", query = "SELECT h FROM HostSubVersion h WHERE h.name = :name"),
    @NamedQuery(name = "HostSubVersion.findByHostId", query = "SELECT h FROM HostSubVersion h WHERE h.hostId = :hostId"),
    @NamedQuery(name = "HostSubVersion.findByHostIdAndMvId", query = "SELECT h FROM HostSubVersion h WHERE h.mvId=:mvId AND  h.hostId = :hostId"),
    @NamedQuery(name = "HostSubVersion.findAllForCommission", query = "SELECT h.id ,h.name FROM HostSubVersion h"),
    @NamedQuery(name = "HostSubVersion.findByHostIdAndOtaStatus", query = "SELECT h FROM HostSubVersion h WHERE h.mvId=:mvId AND  h.otaStatus = :otaStatus"),
    @NamedQuery(name = "HostSubVersion.findByMasterVersionId", query = "SELECT h FROM HostSubVersion h WHERE h.mvId=:masterVersionId"),
})
public class HostSubVersion implements Serializable {
	 private static final long serialVersionUID = 1L;
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Basic(optional = false)
	    @Column(name = "id")
	    private Integer id;
	   
	    @Column(name = "otaStatus")
	    private String otaStatus;
	    
	    @Basic(optional = false)
	    @Column(name = "name")
	    private String name;
	    
	    @Basic(optional = false)
	    @Column(name = "smsCode")
	    private String smsCode;
	   
	    @OneToMany(mappedBy = "hsvId")
	    private Collection<HostSVProviderPartnerMapping> hostSVProviderPartnerMappingCollection;
	    @OneToMany(mappedBy = "hsvId")
	    private Collection<HostSVFinInstrumentPartnerMapping> hostSVFinInstrumentPartnerMappingCollection;
	    @OneToMany(cascade = CascadeType.ALL, mappedBy = "hsvId")
	    private Collection<PartnerPreference> partnerPreferenceCollection;
	    @OneToMany(mappedBy = "hsvId")
	    private Collection<ProductInventorySummary> productInventorySummaryCollection;
	    @OneToMany(mappedBy = "hsvId")
	    private Collection<TransactionInfo> transactionInfoCollection;
	    @OneToMany(mappedBy = "hsvId")
	    private Collection<HostSVFspServicesPartnerMapping> hostSVFspServicesPartnerMappingCollection;
	    @JoinColumn(name = "mvId", referencedColumnName = "id")
	    @ManyToOne(optional = false)
	    private MasterVersion mvId;
	    @JoinColumn(name = "hostId", referencedColumnName = "id")
	    @ManyToOne(optional = false)
	    private AccountInfo hostId;
	    @OneToMany(mappedBy = "hsvId")
	    private Collection<HostSVServiceConfigMapping> hostSVServiceConfigMappingCollection;
	    @OneToMany(cascade = CascadeType.ALL, mappedBy = "hsvId")
	    private Collection<Subscriber> subscriberCollection;
	    @OneToMany(mappedBy = "hsvId")
	    private Collection<HostSVWalletMapping> hostSVWalletMappingCollection;

	    public HostSubVersion() {
	    	//default constructor
	    }

	    public HostSubVersion(Integer id) {
	        this.id = id;
	    }

	    public HostSubVersion(Integer id, String name, String smsCode) {
	        this.id = id;
	        this.name = name;
	        this.smsCode = smsCode;
	    }

	    public Integer getId() {
	        return id;
	    }

	    public void setId(Integer id) {
	        this.id = id;
	    }

	    public String getName() {
	        return name;
	    }

	    public void setName(String name) {
	        this.name = name;
	    }

	    public String getOtaStatus() {
	        return otaStatus;
	    }

	    public void setOtaStatus(String otaStatus) {
	        this.otaStatus = otaStatus;
	    }

	    public String getSmsCode() {
	        return smsCode;
	    }

	    public void setSmsCode(String smsCode) {
	        this.smsCode = smsCode;
	    }

	  
	    @XmlTransient
	    public Collection<HostSVProviderPartnerMapping> getHostSVProviderPartnerMappingCollection() {
	        return hostSVProviderPartnerMappingCollection;
	    }

	    public void setHostSVProviderPartnerMappingCollection(Collection<HostSVProviderPartnerMapping> hostSVProviderPartnerMappingCollection) {
	        this.hostSVProviderPartnerMappingCollection = hostSVProviderPartnerMappingCollection;
	    }

	    @XmlTransient
	    public Collection<HostSVFinInstrumentPartnerMapping> getHostSVFinInstrumentPartnerMappingCollection() {
	        return hostSVFinInstrumentPartnerMappingCollection;
	    }

	    public void setHostSVFinInstrumentPartnerMappingCollection(Collection<HostSVFinInstrumentPartnerMapping> hostSVFinInstrumentPartnerMappingCollection) {
	        this.hostSVFinInstrumentPartnerMappingCollection = hostSVFinInstrumentPartnerMappingCollection;
	    }

	    @XmlTransient
	    public Collection<PartnerPreference> getPartnerPreferenceCollection() {
	        return partnerPreferenceCollection;
	    }

	    public void setPartnerPreferenceCollection(Collection<PartnerPreference> partnerPreferenceCollection) {
	        this.partnerPreferenceCollection = partnerPreferenceCollection;
	    }

	    @XmlTransient
	    public Collection<ProductInventorySummary> getProductInventorySummaryCollection() {
	        return productInventorySummaryCollection;
	    }

	    public void setProductInventorySummaryCollection(Collection<ProductInventorySummary> productInventorySummaryCollection) {
	        this.productInventorySummaryCollection = productInventorySummaryCollection;
	    }

	    @XmlTransient
	    public Collection<TransactionInfo> getTransactionInfoCollection() {
	        return transactionInfoCollection;
	    }

	    public void setTransactionInfoCollection(Collection<TransactionInfo> transactionInfoCollection) {
	        this.transactionInfoCollection = transactionInfoCollection;
	    }

	    @XmlTransient
	    public Collection<HostSVFspServicesPartnerMapping> getHostSVFspServicesPartnerMappingCollection() {
	        return hostSVFspServicesPartnerMappingCollection;
	    }

	    public void setHostSVFspServicesPartnerMappingCollection(Collection<HostSVFspServicesPartnerMapping> hostSVFspServicesPartnerMappingCollection) {
	        this.hostSVFspServicesPartnerMappingCollection = hostSVFspServicesPartnerMappingCollection;
	    }

	    public MasterVersion getMvId() {
	        return mvId;
	    }

	    public void setMvId(MasterVersion mvId) {
	        this.mvId = mvId;
	    }

	    public AccountInfo getHostId() {
	        return hostId;
	    }

	    public void setHostId(AccountInfo hostId) {
	        this.hostId = hostId;
	    }

	    @XmlTransient
	    public Collection<HostSVServiceConfigMapping> getHostSVServiceConfigMappingCollection() {
	        return hostSVServiceConfigMappingCollection;
	    }

	    public void setHostSVServiceConfigMappingCollection(Collection<HostSVServiceConfigMapping> hostSVServiceConfigMappingCollection) {
	        this.hostSVServiceConfigMappingCollection = hostSVServiceConfigMappingCollection;
	    }

	    @XmlTransient
	    public Collection<Subscriber> getSubscriberCollection() {
	        return subscriberCollection;
	    }

	    public void setSubscriberCollection(Collection<Subscriber> subscriberCollection) {
	        this.subscriberCollection = subscriberCollection;
	    }

	    @XmlTransient
	    public Collection<HostSVWalletMapping> getHostSVWalletMappingCollection() {
	        return hostSVWalletMappingCollection;
	    }

	    public void setHostSVWalletMappingCollection(Collection<HostSVWalletMapping> hostSVWalletMappingCollection) {
	        this.hostSVWalletMappingCollection = hostSVWalletMappingCollection;
	    }

	  
		

		@Override
	    public int hashCode() {
	        int hash = 0;
	        hash += (id != null ? id.hashCode() : 0);
	        return hash;
	    }

	    @Override
	    public boolean equals(Object object) {
	       if (!(object instanceof HostSubVersion)) {
	            return false;
	        }
	        HostSubVersion other = (HostSubVersion) object;
	        boolean check=true;
	        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
	        	check= false;
	        }
	        return check;
	    }

	    @Override
	    public String toString() {
	        return "com.ng.sb.common.model.HostSubVersion[ id=" + id + " ]";
	    }
    
}
