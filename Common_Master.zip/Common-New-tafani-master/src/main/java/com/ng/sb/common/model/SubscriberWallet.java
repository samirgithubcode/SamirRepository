/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Collection;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author ram
 */
@Entity
@Table(name = "SubscriberWallet")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "SubscriberWallet.findAll", query = "SELECT s FROM SubscriberWallet s"),
    @NamedQuery(name = "SubscriberWallet.findById", query = "SELECT s FROM SubscriberWallet s WHERE s.id = :id"),
    @NamedQuery(name = "SubscriberWallet.findByMsisdn", query = "SELECT s FROM SubscriberWallet s WHERE s.msisdn = :msisdn"),
    @NamedQuery(name = "SubscriberWallet.findByRespWalletId", query = "SELECT s FROM SubscriberWallet s WHERE s.respWalletId = :respWalletId"),
    @NamedQuery(name = "SubscriberWallet.findByExistingUser", query = "SELECT s FROM SubscriberWallet s WHERE s.existingUser = :existingUser")})
public class SubscriberWallet implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
   
    @Column(name = "respWalletId", length = 50)
    private String respWalletId;
    @Basic(optional = false)
    @Column(name = "msisdn", nullable = false, length = 10)
    private String msisdn;
    @Column(name = "existingUser")
    private short existingUser;
    @JoinColumn(name = "subscriberId", referencedColumnName = "id", nullable = false)
    @ManyToOne(optional = false)
    private Subscriber subscriberId;
    @JoinColumn(name = "walletId", referencedColumnName = "id", nullable = false)
    @ManyToOne(optional = false)
    private Partner walletId;
    @OneToMany(mappedBy = "parentWallet")
    private Collection<SubscriberWallet> subscriberWalletCollection;
    @JoinColumn(name = "parentWallet", referencedColumnName = "id")
    @ManyToOne
    private SubscriberWallet parentWallet;

    public SubscriberWallet() {
    	//default constructor
    }

    public SubscriberWallet(Integer id) {
        this.id = id;
    }

    public SubscriberWallet(Integer id, String msisdn, short existingUser) {
        this.id = id;
        this.msisdn = msisdn;
        this.existingUser = existingUser;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMsisdn() {
        return msisdn;
    }

    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }

    public String getRespWalletId() {
        return respWalletId;
    }

    public void setRespWalletId(String respWalletId) {
        this.respWalletId = respWalletId;
    }

    public short getExistingUser() {
        return existingUser;
    }

    public void setExistingUser(short existingUser) {
        this.existingUser = existingUser;
    }

    public Subscriber getSubscriberId() {
        return subscriberId;
    }

    public void setSubscriberId(Subscriber subscriberId) {
        this.subscriberId = subscriberId;
    }

    public Partner getWalletId() {
        return walletId;
    }

    public void setWalletId(Partner walletId) {
        this.walletId = walletId;
    }

    @XmlTransient
    public Collection<SubscriberWallet> getSubscriberWalletCollection() {
        return subscriberWalletCollection;
    }

    public void setSubscriberWalletCollection(Collection<SubscriberWallet> subscriberWalletCollection) {
        this.subscriberWalletCollection = subscriberWalletCollection;
    }

    public SubscriberWallet getParentWallet() {
        return parentWallet;
    }

    public void setParentWallet(SubscriberWallet parentWallet) {
        this.parentWallet = parentWallet;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof SubscriberWallet)) {
            return false;
        }
        SubscriberWallet other = (SubscriberWallet) object;
        boolean check=true;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
        	check= false;
        }
        return check;
    }

    @Override
    public String toString() {
        return "com.ng.sb.common.model.SubscriberWallet[ id=" + id + " ]";
    }
    
}
