/**
 * 
 */
package com.ng.transaction.data;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.ng.sb.common.dataobject.AccountInfo;
import com.ng.sb.common.dataobject.OverlayIssuance;
import com.ng.sb.common.model.CustomerAccountHistory;

/**
 * @author gopal
 *
 */
@JsonInclude(Include.NON_DEFAULT)
public class CustomerDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4226489214233985263L;

	private String name;
	
	private String msisdn;
	
	private String customerId;
	
	private String userId;
	
	private String createdOn;
	
	private List<CustomerAccountHistory> accountInfo;
	
	private List<OverlayIssuance> overlayInfo;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMsisdn() {
		return msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}

	public List<CustomerAccountHistory> getAccountInfo() {
		return accountInfo;
	}

	public void setAccountInfo(List<CustomerAccountHistory> accountInfo) {
		this.accountInfo = accountInfo;
	}

	public List<OverlayIssuance> getOverlayInfo() {
		return overlayInfo;
	}

	public void setOverlayInfo(List<OverlayIssuance> overlayInfo) {
		this.overlayInfo = overlayInfo;
	}
	
	
	
}
