package com.ng.sc.service.impl;
/**
 * 
 */

import java.util.concurrent.Callable;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.annotation.PreDestroy;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ng.sc.service.IScLoginService;
import com.ng.sc.service.IScUserMgmntService;
import com.ng.sc.service.ISchedulerService;

/**
 * @author gaurav
 *
 */
@Service(value="schedulerService")
public class SchedulerService implements ISchedulerService {
	private ScheduledExecutorService scheduledThreadPool = Executors.newScheduledThreadPool(10);
	
	
	@Autowired
	IScLoginService iScLoginService;
	@Autowired
	IScUserMgmntService iScUserMgmtService;

	
	
	
	@PreDestroy
	public void cleanUp() throws Exception {
	  scheduledThreadPool.shutdown();
	}

	
	@Override
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Transactional
	public void schedule(int timeout,int otp) {
		
				scheduledThreadPool.schedule(new Callable(){
					@Override
			        public Object call() throws Exception {
					iScLoginService.updateTimeoutOtp(otp);
			        	return "";
			        }
			    },				
				timeout,
				TimeUnit.SECONDS);
		
	}
	
}

