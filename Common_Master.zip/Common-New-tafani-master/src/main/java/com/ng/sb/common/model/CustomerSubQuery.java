package com.ng.sb.common.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name = "customersubquery")
@XmlRootElement

@NamedQueries({
	@NamedQuery(name="CustomerSubQuery.findAll", query="SELECT c FROM CustomerSubQuery c"),
	@NamedQuery(name="CustomerSubQuery.findbyid", query="SELECT c FROM CustomerSubQuery c where c.id=:id"),
	@NamedQuery(name="CustomerSubQuery.findAllbyId", query="SELECT c FROM CustomerSubQuery c where c.id=:id"),
	@NamedQuery(name="CustomerSubQuery.findAllProductType", query="SELECT c FROM CustomerSubQuery c where c.productType=:productType"),
	@NamedQuery(name="CustomerSubQuery.findAllProductTypeSubquery", query="SELECT c FROM CustomerSubQuery c where c.productType=:productType and c.subquery=:subquery"),
/*	@NamedQuery(name="CustomerSubQuery.findAllbyproductId", query="SELECT c FROM CustomerSubQuery c where c.productid=:productid"),*/
	
	
})

public class CustomerSubQuery implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	  
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "id")
	private Integer id;

	@Column(name = "filePath")
	private String filePath;
	
	@Basic(optional = false)
	@Column(name = "subquery")
	private String subquery;
	@Basic(optional = true)
	@JoinColumn(name = "product_id", referencedColumnName = "id")

	@Column(name = "productType")
	private String productType;

	
	@Basic(optional = true)
	@JoinColumn(name = "priorityId", referencedColumnName = "id")
	@ManyToOne
	private Customerpriority customerpriority;
	
	 public CustomerSubQuery() {
			// default
		}
	public CustomerSubQuery(Integer id)
	{
		
		
		this.id=id;
	}
	public CustomerSubQuery(Integer id, String subquery,
			String productType) {
		super();
		this.id = id;
		this.subquery = subquery;
		this.productType = productType;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	@Override
	public int hashCode() {
		 int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	public Customerpriority getCustomerpriority() {
		return customerpriority;
	}

	public void setCustomerpriority(Customerpriority customerpriority) {
		this.customerpriority = customerpriority;
	}

	public String getSubquery() {
		return subquery;
	}
	@Override
	public String toString() {
		return "CustomerSubQuery [id=" + id + "]";
	}

	public void setSubquery(String subquery) {
		this.subquery = subquery;
	}

	public String getFilePath() {
		return filePath;
	}
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
		
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CustomerSubQuery other = (CustomerSubQuery) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
	
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}





	

}
