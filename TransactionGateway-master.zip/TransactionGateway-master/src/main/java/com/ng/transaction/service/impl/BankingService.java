package com.ng.transaction.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ng.bridge.service.IPartnerManagementService;
import com.ng.sb.common.dataobject.BridgeDataObject;
import com.ng.sb.common.exception.BridgeObjectDataException;
import com.ng.sb.common.util.SystemConstant;
import com.ng.transaction.service.IBankingService;

/**
 * @author gaurav
 *
 */
@Service(value=SystemConstant.BANKING_SERVICE)
public class BankingService extends FundTransferMgtService implements IBankingService {
	private static final Logger LOGGER = LoggerFactory.getLogger(BankingService.class);
	
	@Autowired
	IPartnerManagementService partnerManagementService;
	
	@Override
	public BridgeDataObject fundTransferBankToBank(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction BankingService -  fundTransferBankToBank method. ");
		
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in checkBalance:"+ e);
		}
		return null;
		
	}

	@Override
	public BridgeDataObject fundTransferBankToCC(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction BankingService -  fundTransferBankToCC method. ");
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in checkBalance:"+ e);
		}
		return null;
	}

	@Override
	public BridgeDataObject fundTransferBankToIMPS(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction BankingService -  fundTransferBankToIMPS method. ");
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in checkBalance:"+ e);
		}
		return null;
	}

	@Override
	public BridgeDataObject fundTransferBankToWallet(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction BankingService -  fundTransferBankToWallet method. ");
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in checkBalance:"+ e);
		}
		return null;
	}

	@Override
	public BridgeDataObject fundTransferIMPSToBank(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction BankingService -  fundTransferIMPSToBank method. ");
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in checkBalance:"+ e);
		}
		return null;
	}

	@Override
	public BridgeDataObject fundTransferIMPSToIMPS(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction BankingService -  fundTransferIMPSToIMPS method. ");
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in checkBalance:"+ e);
		}
		return null;
	}

	@Override
	public BridgeDataObject fundTransferIMPSToCC(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction BankingService -  fundTransferIMPSToCC method. ");
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in checkBalance:"+ e);
		}
		return null;
	}

	@Override
	public BridgeDataObject fundTransferIMPSToWallet(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction BankingService -  fundTransferIMPSToWallet method. ");
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in checkBalance:"+ e);
		}
		return null;
	}

	@Override
	public BridgeDataObject fundTransferCCToBank(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction BankingService -  fundTransferCCToBank method. ");
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in checkBalance:"+ e);
		}
		return null;
	}

	@Override
	public BridgeDataObject fundTransferCCToIMPS(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction BankingService -  fundTransferCCToIMPS method. ");
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in checkBalance:"+ e);
		}
		return null;
	}

	@Override
	public BridgeDataObject fundTransferCCToCC(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction BankingService -  fundTransferCCToCC method. ");
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in checkBalance:"+ e);
		}
		return null;
	}

	@Override
	public BridgeDataObject fundTransferCCToWallet(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction BankingService -  fundTransferCCToWallet method. ");
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in checkBalance:"+ e);
		}
		return null;
	}

	

	@Override
	public BridgeDataObject cashWithdraw(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction BankingService -  cashWithdraw method. ");
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in checkBalance:"+ e);
		}
		return null;
	}

	@Override
	public BridgeDataObject moneyTransfer(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction BankingService -  moneyTransfer method. ");
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in checkBalance:"+ e);
		}
		return null;
	}

	@Override
	public BridgeDataObject fundTransferUpiToUpi(BridgeDataObject bridgeDataObject) {
		LOGGER.info("TransactionId : "+ bridgeDataObject.getTransactionData().getTransactionId() + " In Transaction BankingService -  moneyTransfer upi to upi method. ");
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in checkBalance:"+ e);
		}
		return null;
	}
	
}
