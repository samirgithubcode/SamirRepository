/**
 * 
 */
package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author gopal
 *
 */
@Entity
@Table(name = "wallet_credit_txn")
@NamedQueries({
    @NamedQuery(name = "WalletCredit.findByWalletId", query = "SELECT walletCredit FROM WalletCredit walletCredit where walletCredit.walletId=:walletId"),
    @NamedQuery(name = "WalletCredit.findByTxnId", query = "SELECT walletCredit FROM WalletCredit walletCredit where walletCredit.requestTxnId=:reqTxnId order by walletCredit.id ")
    })
public class WalletCredit implements Serializable
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1369373702452933923L;

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;
    
    @Column(name = "subscriberId")
    private Integer subscriberId;
    
    @Column(name = "walletId")
    private String walletId;
    
    @Column(name = "amount")
    private String amount;
    
    @Column(name = "req_txn_id")
    private String requestTxnId;
    
    @Column(name = "resp_code")
    private Integer responseCode;
        
    @Column(name = "resp_txn_id")
    private String responseTxnId;
    
    @Column(name = "resp_msg")
    private String responseMessage;
    
    @Column(name = "request_on", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date requestOn;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getSubscriberId() {
		return subscriberId;
	}

	public void setSubscriberId(Integer subscriberId) {
		this.subscriberId = subscriberId;
	}

	public String getWalletId() {
		return walletId;
	}

	public void setWalletId(String walletId) {
		this.walletId = walletId;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getRequestTxnId() {
		return requestTxnId;
	}

	public void setRequestTxnId(String requestTxnId) {
		this.requestTxnId = requestTxnId;
	}

	public Integer getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(Integer responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseTxnId() {
		return responseTxnId;
	}

	public void setResponseTxnId(String responseTxnId) {
		this.responseTxnId = responseTxnId;
	}

	public String getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}

	public Date getRequestOn() {
		return requestOn;
	}

	public void setRequestOn(Date requestOn) {
		this.requestOn = requestOn;
	}
    
}
