package com.ng.sb.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name="remapAudit")
@NamedQueries({ @NamedQuery(name = "RemapAudit.findAll", query = "SELECT r FROM RemapAudit r"),
@NamedQuery(name="RemapAudit.newMSISDN", query="SELECT r FROM RemapAudit r where r.externalNo= :externalNo"),

})
public class RemapAudit implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
	
	
	
	@Column(name="externalNo")
	private String externalNo;
	
	@Column(name = "oldMSISDN")
	private String oldMSISDN;
	
	@Column(name = "newMSISDN")
	private String newMSISDN;
	
	@Column(name="resionCode")
	private String resionCode;
	
	@Column(name="remarks")
	private String remarks;
	
    @Column(name = "addDate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date addDate;
    

	public RemapAudit() {
		
	}
	

	public String getResionCode() {
		return resionCode;
	}


	public void setResionCode(String resionCode) {
		this.resionCode = resionCode;
	}


	public String getRemarks() {
		return remarks;
	}


	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}


	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getExternalNo() {
		return externalNo;
	}

	public void setExternalNo(String externalNo) {
		this.externalNo = externalNo;
	}

	public String getOldMSISDN() {
		return oldMSISDN;
	}

	public void setOldMSISDN(String oldMSISDN) {
		this.oldMSISDN = oldMSISDN;
	}

	public String getNewMSISDN() {
		return newMSISDN;
	}

	public void setNewMSISDN(String newMSISDN) {
		this.newMSISDN = newMSISDN;
	}

	public Date getAddDate() {
		return addDate;
	}

	public void setAddDate(Date addDate) {
		this.addDate = addDate;
	}


    
   
	

}
