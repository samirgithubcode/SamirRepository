/**
 * 
 */
package com.ng.bridge.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ng.bridge.service.IBillerManagementService;
import com.ng.bridge.service.IPartnerManagementService;
import com.ng.bridge.util.NewConstants;
import com.ng.sb.common.dataobject.BridgeDataObject;
import com.ng.sb.common.exception.BridgeObjectDataException;
import com.ng.sb.common.util.SystemConstant;

/**
 * @author gaurav
 *
 */
@Service(value=SystemConstant.BRIDGE_BILLER_MGT_SERVICE)
public class BillerManagementService extends FundTransferMgtService implements	IBillerManagementService {

	private static final Logger LOGGER = LoggerFactory.getLogger(BillerManagementService.class);
	
	@Autowired
	IPartnerManagementService partnerManagementService;
	
	@Override
	public BridgeDataObject fundTransferToBillerByBank(BridgeDataObject bridgeDataObject) {
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge BillerManagementService -  fundTransferToBillerByBank method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in fundTransferToBillerByBank:"+ e);
		}
		return null;
	}

	@Override
	public BridgeDataObject fundTransferToBillerByCC(BridgeDataObject bridgeDataObject) {
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge BillerManagementService -  fundTransferToBillerByCC method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in fundTransferToBillerByCC:"+ e);
		}
		return null;
	}

	@Override
	public BridgeDataObject fundTransferToBillerByIMPS(BridgeDataObject bridgeDataObject) {
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge BillerManagementService -  fundTransferToBillerByIMPS method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in fundTransferToBillerByIMPS:"+ e);
		}
		return null;
	}

	@Override
	public BridgeDataObject fundTransferToBillerByWallet(BridgeDataObject bridgeDataObject) {
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge BillerManagementService -  fundTransferToBillerByWallet method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in fundTransferToBillerByWallet:"+ e);
		}
		return null;
	}

	@Override
	public BridgeDataObject fundTransferToBillerByRI(BridgeDataObject bridgeDataObject) {
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge BillerManagementService -  fundTransferToBillerByRI method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in fundTransferToBillerByRI:"+ e);
		}
		return null;
	}

	@Override
	public BridgeDataObject topUpRechargeByWallet(BridgeDataObject bridgeDataObject) {
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge BillerManagementService -  topUpDTHRechargeByWallet method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in topUpRechargeByWallet:"+ e);
		}
		return null;
	}

	@Override
	public BridgeDataObject topUpRechargeByCC(BridgeDataObject bridgeDataObject) {
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge BillerManagementService -  topUpRechargeByCC method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in topUpRechargeByCC:"+ e);
		}
		return null;
	}
	
	@Override
	public BridgeDataObject topUpRechargeByIMPS(BridgeDataObject bridgeDataObject) {
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge BillerManagementService -  topUpRechargeByIMPS method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in topUpRechargeByIMPS:"+ e);
		}
		return null;
	}
	
	@Override
	public BridgeDataObject topUpRechargeByBank(BridgeDataObject bridgeDataObject) {
		LOGGER.info("%s"+ bridgeDataObject.getTransactionData().getTransactionId() + " In Bridge BillerManagementService -  topUpRechargeByBank method. ",NewConstants.TRANSACTIONID);
		try {
			return partnerManagementService.partnerExecution(bridgeDataObject);
		} catch (BridgeObjectDataException e) {
			LOGGER.debug("exception occured in topUpRechargeByBank:"+ e);
		}
		return null;
	}
	

}
