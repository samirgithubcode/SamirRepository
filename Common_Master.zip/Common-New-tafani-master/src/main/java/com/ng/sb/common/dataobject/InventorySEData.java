package com.ng.sb.common.dataobject;

import org.springframework.web.multipart.MultipartFile;

public class InventorySEData extends BaseObjectData {
	private static final long serialVersionUID = 1L;

	private String seInternalNumber;
	private String seExternalNumber;
	private String desKey;
	private String seStatus;
	private String pukCode;
	private MultipartFile uploadFilePath;
	private Integer mvId;
	private Integer boxId;
	private Integer boxQtyType;
	
	private String errorMsg;
	private String successMsg;
	private Integer poNo;
	private Integer productType;

	

	public Integer getProductType() {
		return productType;
	}

	public void setProductType(Integer productType) {
		this.productType = productType;
	}

	public Integer getPoNo() {
		return poNo;
	}

	public void setPoNo(Integer poNo) {
		this.poNo = poNo;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getSuccessMsg() {
		return successMsg;
	}

	public void setSuccessMsg(String successMsg) {
		this.successMsg = successMsg;
	}

	public MultipartFile getUploadFilePath() {
		return uploadFilePath;
	}

	public void setUploadFilePath(MultipartFile uploadFilePath) {
		this.uploadFilePath = uploadFilePath;
	}

	public Integer getBoxQtyType() {
		return boxQtyType;
	}

	public void setBoxQtyType(Integer boxQtyType) {
		this.boxQtyType = boxQtyType;
	}

	public String getSeInternalNumber() {
		return seInternalNumber;
	}

	public void setSeInternalNumber(String seInternalNumber) {
		this.seInternalNumber = seInternalNumber;
	}

	public String getSeExternalNumber() {
		return seExternalNumber;
	}

	public void setSeExternalNumber(String seExternalNumber) {
		this.seExternalNumber = seExternalNumber;
	}

	public String getDesKey() {
		return desKey;
	}

	public void setDesKey(String desKey) {
		this.desKey = desKey;
	}

	public String getSeStatus() {
		return seStatus;
	}

	public void setSeStatus(String seStatus) {
		this.seStatus = seStatus;
	}

	public String getPukCode() {
		return pukCode;
	}

	public void setPukCode(String pukCode) {
		this.pukCode = pukCode;
	}

	public Integer getMvId() {
		return mvId;
	}

	public void setMvId(Integer mvId) {
		this.mvId = mvId;
	}

	public Integer getBoxId() {
		return boxId;
	}

	public void setBoxId(Integer boxId) {
		this.boxId = boxId;
	}

}
