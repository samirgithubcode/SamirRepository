/**
 * 
 */
package com.ng.transaction.service;

import com.ng.sb.common.dataobject.BridgeDataObject;

/**
 * @author gaurav
 *
 */
public interface IOtherPaymentService extends IWalletService,INonFundTransferBankingService {
	public BridgeDataObject fundTransferToMerchant(BridgeDataObject bridgeDataObject);
	
	
	
}
