/**
 * 
 */
package com.ng.transaction.conf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;

import com.ng.sb.common.util.SpringContextUtil;

/**
 * @author gopal
 *
 */
@ComponentScan({ "com.ng"})
@SpringBootApplication
public class BootApplication extends SpringBootServletInitializer { 

	public static void main(String[] args) {
		System.setProperty("spring.devtools.restart.enabled", "false");
		//System.setProperty("catalina.home", "/home/gopal/Downloads/apache-tomcat-8.0.44");
        ApplicationContext applicationContext =  SpringApplication.run(BootApplication.class, args);
        // Setting the application context for further references 
        SpringContextUtil.setApplicationContextBoot(applicationContext);
	}
}