package com.ng.sb.common.dataobject;

import java.sql.Date;
import java.util.Map;

/**
 * @author abhishek
 *
 */
public class KycValidationData extends BaseObjectData {

	private static final long serialVersionUID = 1L;
	private String distributorName;
	private Integer status;
	private String subDistributorName;
	private String agentName;
	private Map<Integer,String> distributor;
	private String agent;
	private Date fromDate;
	private Date toDate;
	private String firstName;
	private String lastName;
	private String mobileNumber;
	private String subDistributor;
	private String documentStatus;
	private String distributorData;
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getDocumentStatus() {
		return documentStatus;
	}

	public void setDocumentStatus(String documentStatus) {
		this.documentStatus = documentStatus;
	}

	public String getDistributorData() {
		return distributorData;
	}

	public void setDistributorData(String distributorData) {
		this.distributorData = distributorData;
	}

	public Date getFromDate() {
		return fromDate;
	}
	
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}
	
	public Date getToDate() {
		return toDate;
	}
	
	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}
	
	public String getAgent() {
		return agent;
	}
	public void setAgent(String agent) {
		this.agent = agent;
	}
	public String getSubDistributorName() {
		return subDistributorName;
	}
	public void setSubDistributorName(String subDistributorName) {
		this.subDistributorName = subDistributorName;
	}
	public Map<Integer,String> getDistributor() {
		return distributor;
	}
	public void setDistributor(Map<Integer,String> distributor) {
		this.distributor = distributor;
	}
	public String getDistributorName() {
		return distributorName;
	}
	public void setDistributorName(String distributorName) {
		this.distributorName = distributorName;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public String getSubDistributor() {
		return subDistributor;
	}
	public void setSubDistributor(String subDistributor) {
		this.subDistributor = subDistributor;
	}
	public String getAgentName() {
		return agentName;
	}
	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}
}
