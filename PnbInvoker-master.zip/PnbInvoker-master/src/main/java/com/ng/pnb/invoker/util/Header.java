package com.ng.pnb.invoker.util;

public class Header {

	Status status;

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}
    
}
