package com.ng.sb.common.logger;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ApiLogger {
	private File logFile;
	private static final Logger LOGGER = LoggerFactory.getLogger(ApiLogger.class);

	public ApiLogger() {
	}

	public ApiLogger(String fileName) {
		logFile = new File(fileName);
	}


	public ApiLogger(File f) {
		logFile = f;

	}
	public void log(String s) {
		try (FileWriter fw = new FileWriter(this.logFile, true);){
			String date = new Date().toString();
			fw.write(date + " : " + s);
			fw.write(System.lineSeparator());
			fw.close();
		} catch (IOException ex) {
			
			ex.printStackTrace();
			LOGGER.error("Couldn't log this: " + s);
		}

	}

}
