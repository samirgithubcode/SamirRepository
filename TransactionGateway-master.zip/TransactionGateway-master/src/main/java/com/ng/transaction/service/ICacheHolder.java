
package com.ng.transaction.service;

import com.ng.sb.common.dataobject.HostSubVersionData;
import com.ng.sb.common.dataobject.ServiceConfigData;

/**
 * @author gaurav
 *
 */
public interface ICacheHolder {
	public ServiceConfigData getServiceInfo(Integer mvCode,String serviceCode);
	public HostSubVersionData getHostSubVersion(Integer code);
	
}
